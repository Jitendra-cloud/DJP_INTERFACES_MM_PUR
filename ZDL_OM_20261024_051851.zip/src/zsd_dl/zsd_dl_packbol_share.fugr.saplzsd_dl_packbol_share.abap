*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_PACKBOL_SHARETOP.          " Global Data
  INCLUDE LZSD_DL_PACKBOL_SHAREUXX.          " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_PACKBOL_SHAREF...          " Subprograms
* INCLUDE LZSD_DL_PACKBOL_SHAREO...          " PBO-Modules
* INCLUDE LZSD_DL_PACKBOL_SHAREI...          " PAI-Modules

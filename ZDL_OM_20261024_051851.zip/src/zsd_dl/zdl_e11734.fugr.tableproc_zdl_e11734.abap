*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_E11734
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_E11734          .

  PERFORM TABLEPROC.

ENDFUNCTION.

class ZCL_IM_SHIPMENT_PGI definition
  public
  final
  create public .

*"* public components of class ZCL_IM_SHIPMENT_PGI
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_BADI_LE_SHIPMENT .
protected section.
*"* protected components of class ZCL_IM_SHIPMENT_PGI
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_SHIPMENT_PGI
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_SHIPMENT_PGI IMPLEMENTATION.


method IF_EX_BADI_LE_SHIPMENT~AT_SAVE .
endmethod.


method IF_EX_BADI_LE_SHIPMENT~BEFORE_UPDATE .

* Change History:                                                      *
*
* 06/28/05  This code was not used because changing the batch status
* creates a material movement document.  The material movement document
* caused a problem with the posting of the shipment status idoc.  It
* caused the BDC session to unexpectedly exit before processing was
* complete.  I did not delete everything because we may need to use this
* in the future.  (Maureen)                                            *

* include ZDL_E3074_BATCH_STATUS_CONSIG.
*if sy-uname = 'SKOCHER'.
*  break-POINT.
**  message e001(ZDL_SHPSTAT).
*endif.
endmethod.


method IF_EX_BADI_LE_SHIPMENT~IN_UPDATE .
endmethod.
ENDCLASS.

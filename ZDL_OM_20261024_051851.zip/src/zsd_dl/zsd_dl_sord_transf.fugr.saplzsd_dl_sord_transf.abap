*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_SORD_TRANSFTOP.            " Global Data
  INCLUDE LZSD_DL_SORD_TRANSFUXX.            " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_SORD_TRANSFF...            " Subprograms
* INCLUDE LZSD_DL_SORD_TRANSFO...            " PBO-Modules
* INCLUDE LZSD_DL_SORD_TRANSFI...            " PAI-Modules

INCLUDE LZSD_DL_SORD_TRANSFSUB.

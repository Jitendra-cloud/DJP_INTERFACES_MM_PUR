*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSD_ASN_3RDPARY
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSD_ASN_3RDPARY     .

  PERFORM TABLEPROC.

ENDFUNCTION.

FUNCTION-POOL ZDL_NMFC.                     "MESSAGE-ID .
TABLES    : vttk, vtts, vttp.
TYPE-POOLS: znmfr.            "Type Pool for NMFC Freight Code & Class
************************************************************************
*                          DATA DECLARATION                            *
************************************************************************
DATA: gt_vttk LIKE vttk OCCURS 0 WITH HEADER LINE,  "Shipment Header
      gt_vttp LIKE vttp OCCURS 0 WITH HEADER LINE,  "Shipment Item
      gt_vtts LIKE vtts OCCURS 0 WITH HEADER LINE.  "Stage of Shipment
**For Shipment data
DATA: BEGIN OF gt_shipment OCCURS 0,
        tknum TYPE tknum,                 "Shipment Number
        vsart TYPE VSARTTR,               "Shipping type
        abland1 TYPE ABLAND1,             "Country of departure
        vbeln TYPE VBELN_VL,              "Delivery
        matnr TYPE matnr,                 "Material Number
        mfrgr TYPE mfrgr,                 "Material freight group
        garvz TYPE garvz,                 "Freight code set
        gtart TYPE gtart,                 "Freight code
        gtkls TYPE gtkls,                 "Freight class
      END OF gt_shipment,
* For Delivery data
      BEGIN OF gt_delivery OCCURS 0,
        vbeln TYPE VBELN_VL,              "Delivery
        matnr TYPE matnr,                 "Material Number
        mfrgr TYPE mfrgr,                 "Material freight group
      END OF gt_delivery,
* For Freight Code
      gt_frcode LIKE tgavf OCCURS 0 WITH HEADER LINE,
* For Freight Group
      gt_frgroup LIKE tgaf OCCURS 0 WITH HEADER LINE,
* For Freight Class
      gt_frclass LIKE tgar OCCURS 0 WITH HEADER LINE,
* Final Output table
     BEGIN OF gt_final OCCURS 0,
        tknum TYPE tknum,                 "Shipment Number
        vbeln TYPE VBELN_VL,              "Delivery
        matnr TYPE matnr,                 "Material Number
        garvz TYPE garvz,                 "Freight code set
        mfrgr TYPE mfrgr,                 "Material freight group
        gtart TYPE gtart,                 "Freight code
        gtkls TYPE gtkls,                 "Freight class
      END OF gt_final.

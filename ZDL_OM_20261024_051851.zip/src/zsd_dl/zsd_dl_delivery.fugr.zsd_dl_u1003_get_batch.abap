************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**            COPYRIGHT (C) 2003 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                      2003, 2005, 20nn                              **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Function Name: ZSD_DL_U1003_GET_BATCH               Date: 12/17/2003 *
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(L_MATNR) TYPE  MATNR
*"     REFERENCE(L_WERKS) TYPE  WERKS_D
*"     REFERENCE(L_CHARG) TYPE  CHARG_D
*"  EXPORTING
*"     REFERENCE(L_ZZAIRDRY) TYPE  ZZAIRDRY
*"     REFERENCE(L_ZZLINFEET) TYPE  ZZLINFEET
*"     REFERENCE(L_ZZVRKME) TYPE  VRKME
*"     REFERENCE(L_ZZROLLWEIGHTMETRIC) TYPE  ZZROLLWEIGHTMETRIC
*"     REFERENCE(L_ZZROLLWEIGHTMETRIC_UNIT) TYPE
*"        ZZROLLWEIGHTMETRIC_UNIT
*"     REFERENCE(L_ZZLINEARMETERS) TYPE  ZZLINEARMETERS
*"     REFERENCE(L_ZZLINEARMETERS_UNIT) TYPE  ZZLINEARMETERS_UNIT
*"     REFERENCE(L_ZZROLLWEIGHTMES) TYPE  ZZROLLWEIGHTMES
*"     REFERENCE(L_ZZROLLWEIGHTMES_UNIT) TYPE  ZZROLLWEIGHTMES_UNIT
*"----------------------------------------------------------------------
* Programmer  : Charles M. Ramey                                       *
*______________________________________________________________________*
* Description :                                                        *
*  Function to take intake batch identification and then read thru the *
* batch characteristics to get the lineal feet and air dry percent     *
* which is passed back to the calling program.                         *
*______________________________________________________________________*
* Change History:                                                      *
* MACARTE     03/28/05  add MES weight/UOM to characteristics on LIPS  *
* MACARTE     09/26/05  change name of characteristic for weight       *
*                                                                      *
* BBALLEH     08/16/06  EDEK906139 for R8                              *
*                       Add logic for the retrieval of characteristics *
*                       SCALED_WEIGHT_LBS & SCALED_WEIGHT_KG. This     *
*                       function is called from two Z includes:        *
*                       1) ZSD_DL_U1003_ACM_BTCH_CHAR_INC - does not   *
*                            get called from this program for batch    *
*                            split items on the Outbound Delivery.     *
*                       2) ZZSD_DL_U1003_APPEND_CHAR_INC - is called   *
*                            for batch split items.                    *
*                                                                      *
* MACARTE     09/26/06  ESBK9A0371 for V4 bale pulp                    *
*             if WEIGHT_OF_ROLL_IN_LBS not found, use BATCH_WEIGHT     *
*
* jpieri      04/05/2010 CR#10683 EDVK979845  Add logic to retrieve    *
*             values for characteristic SHEETS_PER_PACKAGING_UNIT      *
* Amit Maole 07/24/2017 CMS32311 Add new characteristics for Madrid Prj*
* Amit Maole 09/21/2017 CMS32568 Fix dump for ZDL_RETRUNS transaction. *
*                       Change was made to convert european format to  *
*                       raw format(Madrid). The program could not      *
*                       interpret 0,00 as a number                     *

*______________________________________________________________________*
*
************************************************************************
* External Calls                                                       *
*   Function Modules: VB_BATCH_VALUES_FOR_OUTPUT                       *
*______________________________________________________________________*

FUNCTION zsd_dl_u1003_get_batch.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(L_MATNR) TYPE  MATNR
*"     REFERENCE(L_WERKS) TYPE  WERKS_D
*"     REFERENCE(L_CHARG) TYPE  CHARG_D
*"  EXPORTING
*"     REFERENCE(L_ZZAIRDRY) TYPE  ZZAIRDRY
*"     REFERENCE(L_ZZLINFEET) TYPE  ZZLINFEET
*"     REFERENCE(L_ZZVRKME) TYPE  VRKME
*"     REFERENCE(L_ZZROLLWEIGHTMETRIC) TYPE  ZZROLLWEIGHTMETRIC
*"     REFERENCE(L_ZZROLLWEIGHTMETRIC_UNIT) TYPE
*"        ZZROLLWEIGHTMETRIC_UNIT
*"     REFERENCE(L_ZZLINEARMETERS) TYPE  ZZLINEARMETERS
*"     REFERENCE(L_ZZLINEARMETERS_UNIT) TYPE  ZZLINEARMETERS_UNIT
*"     REFERENCE(L_ZZROLLWEIGHTMES) TYPE  ZZROLLWEIGHTMES
*"     REFERENCE(L_ZZROLLWEIGHTMES_UNIT) TYPE  ZZROLLWEIGHTMES_UNIT
*"     REFERENCE(L_ZZSCALEDWGT) TYPE  ZZSCALEDWEIGHTLB
*"     REFERENCE(L_ZZSCALEDWGT_UOM) TYPE  ZZSCALEDWEIGHTLB_UOM
*"     REFERENCE(L_ZZSCALEDWGTKG) TYPE  ZZSCALEDWEIGHTKG
*"     REFERENCE(L_ZZSCALEDWGTKGUOM) TYPE  ZZSCALEDWEIGHTKG_UOM
*"     REFERENCE(L_ZZMSHEETS) TYPE  ZZMSHEETS
*"     REFERENCE(L_ZZMSHEETSUNIT) TYPE  ZZMSHEETS_UNIT
*"----------------------------------------------------------------------

  TYPE-POOLS: zsdc.

  CONSTANTS: c_decimal_fix          TYPE i     VALUE 10,
             c_zzrollweightmes_kg   TYPE unit VALUE 'KG',   "CMS32568
             c_zzrollweightmes_unit TYPE unit VALUE 'LB'.

  DATA BEGIN OF t_characteristics OCCURS 0.
          INCLUDE STRUCTURE conf_out.
  DATA END OF t_characteristics.
  DATA: l_linfeet(8)   TYPE n,
        l_weight(10)   TYPE n,
        l_ctnpal(03)   TYPE n,
        l_msh(7)       TYPE n,
        l_airdry       TYPE p DECIMALS 2,
        l_quantity(30) TYPE c,
        l_units(30)    TYPE c.

  CALL FUNCTION 'VB_BATCH_VALUES_FOR_OUTPUT'
    EXPORTING
      material               = l_matnr
      plant                  = l_werks
      batch                  = l_charg
      language               = sy-langu
    TABLES
      classification         = t_characteristics
    EXCEPTIONS
      no_classification_data = 1
      OTHERS                 = 2.

  IF sy-subrc IS INITIAL.

    PERFORM get_plants_zdl_fields.                          "CMS32311

    PERFORM get_plant_specific_char USING l_werks.          "CMS32311

    PERFORM check_decimal_nomation CHANGING gv_convert_to_raw. "CMS32568

    SORT t_characteristics BY atnam.
    READ TABLE t_characteristics
        WITH KEY atnam = zsdc_air_dry_percent
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.

      IF gv_convert_to_raw EQ 'X'.                          "CMS32568
        PERFORM convert_to_raw CHANGING t_characteristics-atwrt. "CMS32568
      ELSE.                                                 "CMS32568
        l_airdry   = t_characteristics-atwrt.
      ENDIF.                                                "CMS32568

      l_zzairdry = l_airdry.
    ENDIF.
    READ TABLE t_characteristics
*        WITH KEY atnam = zsdc_lineal_footage               "CMS32311
        WITH KEY atnam = gv_lineal_char                     "CMS32311
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
      l_linfeet   = l_quantity.
      l_zzlinfeet = l_linfeet.
      l_zzvrkme   = l_units.
    ENDIF.
    READ TABLE t_characteristics
        WITH KEY atnam = zsdc_roll_weight_metric
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
      l_weight                  = l_quantity.
* weight is supposed to have a decimal but since they put the unit after
* we must use a numeric field to pull - and then convert by dividing by
* 10
      l_zzrollweightmetric      = l_weight / c_decimal_fix.
      l_zzrollweightmetric_unit = l_units.
    ENDIF.
    READ TABLE t_characteristics
        WITH KEY atnam = zsdc_linear_footage_metric
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
      l_linfeet             = l_quantity.
* meters is supposed to have a decimal but since they put the unit after
* we must use a numeric field to pull - and then convert by dividing by
* 10
      l_zzlinearmeters      = l_linfeet / c_decimal_fix.
      l_zzlinearmeters_unit = l_units.
    ENDIF.

    READ TABLE t_characteristics
*        WITH KEY atnam = zsdc_weight_of_roll_in_lbs        "CMS32311
        WITH KEY atnam = gv_weight_of_roll                  "CMS32311
*   WITH KEY atnam = zsdc_weight_of_roll_in_lbs_mes "replaced 9/26/05 MAC
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      IF gv_convert_to_raw EQ 'X'.                          "CMS32568
        PERFORM convert_to_raw CHANGING t_characteristics-atwrt. "CMS32568
        l_zzrollweightmes_unit = c_zzrollweightmes_kg.      "CMS32568
      ELSE.                                                 "CMS32568
        l_zzrollweightmes_unit = c_zzrollweightmes_unit.
      ENDIF.                                                "CMS32568

      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
      REPLACE ',' IN l_quantity WITH '' .
      l_zzrollweightmes      = l_quantity.

*   begin of ESBK9A0371
    ELSE.
      READ TABLE t_characteristics
          WITH KEY atnam = zsdc_batch_weight
          BINARY SEARCH.
      IF sy-subrc IS INITIAL.
        SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
        REPLACE ',' IN l_quantity WITH '' .
        l_zzrollweightmes      = l_quantity.
        l_zzrollweightmes_unit = c_zzrollweightmes_unit.
      ENDIF.
*   end of ESBK9A0371
    ENDIF.

*--> Begin EDEK906139
*   Scaled Weight LBS
    READ TABLE t_characteristics
        WITH KEY atnam = zsdc_scaled_weight_lbs
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
*     l_quantity = t_characteristics-atwrt.
      REPLACE ',' IN l_quantity WITH '' .
      l_zzscaledwgt      = l_quantity.
      l_zzscaledwgt_uom  = l_units.
    ENDIF.

*   Scaled Weight KG
    READ TABLE t_characteristics
        WITH KEY atnam = zsdc_scaled_weight_kg
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      IF gv_convert_to_raw EQ 'X'.                          "CMS32568
        PERFORM convert_to_raw CHANGING t_characteristics-atwrt. "CMS32568
      ENDIF.                                                "CMS32568

      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
*     l_quantity = t_characteristics-atwrt.
      REPLACE ',' IN l_quantity WITH '' .
      l_zzscaledwgtkg      = l_quantity.
      l_zzscaledwgtkguom   = l_units.
    ENDIF.
*--> End EDEK906139

**--> Begin of E0VK988478 and CR#10683 EDVK979845
    CLEAR: l_ctnpal, l_msh.
    READ TABLE t_characteristics
      WITH KEY atnam = zsdc_cartons_per_pallet
      BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      SHIFT t_characteristics-atwrt LEFT DELETING LEADING space.
      l_ctnpal   = t_characteristics-atwrt.
    ENDIF.

    READ TABLE t_characteristics
      WITH KEY atnam = zsdc_sheets_per_packaging_unit
      BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      SPLIT t_characteristics-atwrt AT ' ' INTO l_quantity l_units.
      REPLACE ',' IN l_quantity WITH '' .
      SHIFT l_quantity LEFT DELETING LEADING space.
      l_msh = l_quantity.
    ENDIF.

    READ TABLE t_characteristics
        WITH KEY atnam = zsdc_unit_code
        BINARY SEARCH.
    IF sy-subrc IS INITIAL.
      IF ( t_characteristics-atwrt = 'C' OR t_characteristics-atwrt = 'D' ).
        l_zzmsheets             = l_msh * l_ctnpal / 1000.
        l_zzmsheetsunit         = 'MSH'.
      ELSEIF t_characteristics-atwrt = 'S'.
        l_zzmsheets             = l_msh / 1000.
        l_zzmsheetsunit         = 'MSH'.
      ENDIF.
    ENDIF.
**--> End of E0VK988478 and CR#10683 EDVK979845
  ENDIF.

ENDFUNCTION.

*

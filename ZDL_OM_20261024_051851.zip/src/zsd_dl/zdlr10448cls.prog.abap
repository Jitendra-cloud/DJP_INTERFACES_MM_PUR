*&---------------------------------------------------------------------*
*&  Include           ZDLR10448CLS
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       CLASS lcl_rpt DEFINITION
*----------------------------------------------------------------------*
class lcl_rpt definition final.

  public section.

    methods:
      process_output.


    class-methods:

      initialization,

      sel_screen_pbo,

      fcat_build exporting et_fcat type lvc_t_fcat
                  changing ct_tab type  standard table,

      fcat_adjust importing iv_fgrid type char1
                   changing ct_fcat type lvc_t_fcat,

      select_data returning value(rv_selected) type char1,

      process_data_by_batch returning value(rv_selected) type char1,

      process_data_by_shipment returning value(rv_selected) type char1,

      check_input_data returning value(rv_error) type char1,

      create_grid.

    class-data:
      gt_tab              type tt_tab,
      gt_tab_r            type tt_tab,
      gs_tab              type t_tab,

      go_cont_spl         type ref to cl_gui_easy_splitter_container,
      go_cust_cont        type ref to cl_gui_custom_container,

      gt_fcat             type lvc_t_fcat,
      gt_fcat_r           type lvc_t_fcat,

      go_grid             type ref to cl_gui_alv_grid,
      go_grid_r           type ref to cl_gui_alv_grid,


      gs_layout           type lvc_s_layo,
      gs_layout_r         type lvc_s_layo,
      gt_excl             type ui_functions,
      gt_excl_ucomm       type table of sy-ucomm,

      gv_okcode           type syst-ucomm,
      gv_ucomm            type syst-ucomm,

      "range for Sales Document Item Category
      gr_pstyv            type range of pstyv.



  private section.


endclass.

*----------------------------------------------------------------------*
*       CLASS lcl_event_receiver DEFINITION
*----------------------------------------------------------------------*
* event receiver for grid events
class lcl_event_receiver definition final.
  public section.
    methods:

      double_click  for event double_click of cl_gui_alv_grid
        importing sender e_row e_column,

      top_of_page
         for event print_top_of_page of cl_gui_alv_grid.

endclass.

*----------------------------------------------------------------------*
*       CLASS lcl_event_receiver IMPLEMENTATION
*----------------------------------------------------------------------*
class lcl_event_receiver implementation.

  method double_click.

    case sender.
      when lcl_rpt=>go_grid.
        read table lcl_rpt=>gt_tab index e_row-index
          into lcl_rpt=>gs_tab.

      when lcl_rpt=>go_grid_r.
        read table lcl_rpt=>gt_tab_r index e_row-index
          into lcl_rpt=>gs_tab.

      when others.
        return.

    endcase.

    if sy-subrc = 0.

      case e_column-fieldname.

        when 'DLVNR'.
          if lcl_rpt=>gs_tab-dlvnr is not initial.
            set parameter id 'VL' field lcl_rpt=>gs_tab-dlvnr.
            call transaction 'VL03N' and skip first screen.
          endif.

        when 'SODNR'.
          if lcl_rpt=>gs_tab-sodnr is not initial.
            set parameter id 'AUN' field lcl_rpt=>gs_tab-sodnr.
            call transaction 'VA03' and skip first screen.
          endif.

        when 'SOBNR'.
          if lcl_rpt=>gs_tab-sobnr is not initial.
            set parameter id 'AUN' field lcl_rpt=>gs_tab-sobnr.
            call transaction 'VA03' and skip first screen.
          endif.

        when 'TKNUM'.
          if lcl_rpt=>gs_tab-tknum is not initial.
            set parameter id 'TNR' field lcl_rpt=>gs_tab-tknum.
            call transaction 'VT03N' and skip first screen.
          endif.

      endcase.

    endif.


  endmethod.

*-----------------------------------------------------------------------

  method top_of_page.

    zcl_gl_alv_std=>top_of_page( ).

  endmethod.

*-----------------------------------------------------------------------

endclass.                    "lcl_event_receiver IMPLEMENTATION


class lcl_rpt implementation.

*&---------------------------------------------------------------------*
*&      method  INITIALIZATION
*&---------------------------------------------------------------------*
*       Initialization
*----------------------------------------------------------------------*
  method initialization.

    "Read range from ZDL_FIELDS for PSTYV (Item Category)
    select
      sign
      optn
      lowval
      highval
    from zdl_fields into table gr_pstyv
      where category  = 'EMTS'
        and fieldname = 'PSTYV'.

    if gr_pstyv[] is initial.
      append 'ICP*' to gr_pstyv.
    endif.

  endmethod.

*----------------------------------------------------------------------*
*       method SEL_SCREEN_PBO
*----------------------------------------------------------------------*
*       Selection screen PBO
*----------------------------------------------------------------------*
  method sel_screen_pbo.

    loop at screen.

      case screen-group1.
        when 'F1'.

          if rb_2 = 'X'.
            screen-input = 1.
          else.
            screen-input = 0.
            refresh so_tknum.
          endif.

      endcase.

      modify screen.

    endloop.

  endmethod.

*----------------------------------------------------------------------*
*       method SELECT_DATA
*----------------------------------------------------------------------*
*       Select Data
*----------------------------------------------------------------------*
  method select_data.

    if rb_1 = 'X'. "----- By Batch

      select
        vbeln as dlvnr
        posnr as dlvit
        matnr
        charg
        vgtyp
        vgbel as sodnr
        vgpos as sodit
      from lips
        into corresponding fields of table gt_tab
      where charg in so_charg
        and vgtyp in ('C', 'V').

    else. "----- By Shipment

      select
        v~tknum
        v~tpnum
        v~vbeln as dlvnr
        l~posnr as dlvit
        l~matnr
        l~charg
        l~vgtyp
        l~vgbel as sodnr
        l~vgpos as sodit
      from vttp as v join lips as l on v~vbeln = l~vbeln
        into corresponding fields of table gt_tab
      where v~tknum in so_tknum
        "and l~charg in so_charg
        and vgtyp in ('C', 'V').

      select
        matnr
        werks
        charg
        vbeln as sobnr
        posnr as sobit
        kalab
      from mska into corresponding fields of table gt_tab_r
      where charg in so_charg
        and kalab > 0.

      select
        matnr
        werks
        charg
        clabs
      from mchb appending corresponding fields of table gt_tab_r
      where charg in so_charg
        and clabs > 0.

    endif.

    if gt_tab[] is initial. return. endif.

    "Pull Sales Order & SOLI from EKKN
    select
      ebeln,
      ebelp,
      vbeln,
      vbelp
    from ekkn into table @data(lt_ekkn)
      for all entries in @gt_tab
    where ebeln = @gt_tab-sodnr
      and ebelp = @gt_tab-sodit+1(5).

    sort lt_ekkn by ebeln ebelp.

    loop at gt_tab assigning field-symbol(<ls_tab>).
      if <ls_tab>-vgtyp = 'V'.

        read table lt_ekkn into data(ls_ekkn)
          with key ebeln = <ls_tab>-sodnr
                   ebelp = <ls_tab>-sodit+1(5)
                   binary search.

        if sy-subrc = 0.
          <ls_tab>-sodnr = ls_ekkn-vbeln.
          <ls_tab>-sodit = ls_ekkn-vbelp.
        endif.

      endif.
    endloop.

    "Pull Item Category PSTYV from VBAP
    "Get Production Order & Line Item from AFPO
    select
      v~vbeln as vbap_sodnr,
      v~posnr as vbap_sodit,
      v~pstyv as vbap_pstyv,
      a~aufnr as afpo_aufnr,
      a~posnr as afpo_aufit
    from vbap as v left join afpo as a
      on v~vbeln = a~kdauf and
         v~posnr = a~kdpos and
         v~charg = a~charg
      into table @data(lt_vbap_afpo)
      for all entries in @gt_tab
    where v~vbeln = @gt_tab-sodnr
      and v~posnr = @gt_tab-sodit.
      "and v~charg = @gt_tab-charg ??? |This condition is not described
      "and v~matnr = @gt_tab-matnr.??? |in program logic but exists in
                                      "|Data Selection schema
    "Check if batch is EMTS-relevant
    loop at lt_vbap_afpo into data(ls_vbap_afpo).

      if ls_vbap_afpo-vbap_pstyv not in gr_pstyv[].
        "Batch is not EMTS-relevant. No data selected
        message text-m01 type 'E'.
      endif.
    endloop.

    sort lt_vbap_afpo by vbap_sodnr vbap_sodit.

    loop at gt_tab into gs_tab.

      read table lt_vbap_afpo into ls_vbap_afpo with key
                                   vbap_sodnr = gs_tab-sodnr
                                   vbap_sodit = gs_tab-sodit
                                   binary search.

      if sy-subrc = 0.
        gs_tab-pstyv = ls_vbap_afpo-vbap_pstyv.
        gs_tab-aufnr = ls_vbap_afpo-afpo_aufnr.
        gs_tab-aufit = ls_vbap_afpo-afpo_aufit.

        modify gt_tab from gs_tab.
      else.
        "delete gt_tab.
      endif.

    endloop.
    " endif.

    if gt_tab[] is not initial.
      rv_selected = 'X'.
    endif.

  endmethod.

*----------------------------------------------------------------------*
*       method PRECESS_DATA_BY_BATCH
*----------------------------------------------------------------------*
*       Process Data - By Batch Option
*----------------------------------------------------------------------*
  method process_data_by_batch.

    types: begin of t_batch,
             matnr  type matnr,
             werks  type werks_d,
             charg  type charg_d,
             sobnr  type vbeln,
             sobit  type posnr,
             kalab  type labst,
             clabs  type labst,
           end of t_batch.

    types: tt_batch_u type sorted table of t_batch
             with non-unique key primary_key components matnr charg.

    types: tt_batch_a type sorted table of t_batch
             with non-unique key primary_key components
               matnr charg sobnr sobit.

    data: lt_mska type tt_batch_a.
    data: lt_mchb type tt_batch_u.
    data: lv_exists type char1.
    data: lv_count type i.
    data: lt_tab type tt_tab.

    if gt_tab[] is not initial.

      select
        matnr,
        werks,
        charg,
*     sobkz,
        vbeln as sobnr,
        posnr as sobit,
        kalab
      from mska into corresponding fields of table @lt_mska
        for all entries in @gt_tab
      where charg = @gt_tab-charg
        and matnr = @gt_tab-matnr
        and vbeln = @gt_tab-sodnr
        and posnr = @gt_tab-sodit
        and kalab > 0.

      select
        matnr,
        werks,
        charg,
        clabs
      from mchb into corresponding fields of table @lt_mchb
        for all entries in @gt_tab
      where charg = @gt_tab-charg
        and matnr = @gt_tab-matnr
        and clabs > 0.

    endif.

    loop at gt_tab into gs_tab.

      gs_tab-color_line = 'C500'.
      modify gt_tab from gs_tab transporting color_line.

      clear: lv_exists.

      loop at lt_mska into data(ls_mska) where matnr = gs_tab-matnr
                                           and charg = gs_tab-charg
                                           and sobnr = gs_tab-sodnr
                                           and sobit = gs_tab-sodit.
        lv_count = lv_count + 1.
        "Sales Order exists for BATCH
        "Line item for that batch number will be highlighted in RED
        gs_tab-color_line = 'C600'.
        gs_tab-werks = ls_mska-werks.
        gs_tab-kalab = ls_mska-kalab.
        gs_tab-sobnr = ls_mska-sobnr.
        gs_tab-sobit = ls_mska-sobit.
        lv_exists = 'X'.
        if lv_count = 1.
          modify gt_tab from gs_tab.
        else.
          append gs_tab to lt_tab.
        endif.
      endloop.

      if lv_exists is initial.

        clear: lv_count.

        loop at lt_mchb into data(ls_mchb) where matnr = gs_tab-matnr
                                             and charg = gs_tab-charg.
          lv_count = lv_count + 1.
          "Line item for batch number will be highlighted in GREEN
          gs_tab-color_line = 'C500'.
          gs_tab-werks = ls_mchb-werks.
          gs_tab-clabs = ls_mchb-clabs.
          if lv_count = 1.
            modify gt_tab from gs_tab.
          else.
            append gs_tab to lt_tab.
          endif.
        endloop.
      endif.

    endloop.

    append lines of lt_tab to gt_tab.


    delete gt_tab where not ( dlvnr in so_vbeln and
                              matnr in so_matnr and
                              sodnr in so_sbeln ).


  endmethod.

*----------------------------------------------------------------------*
*       method PREOCESS_DATA_BY_SHIPMENT
*----------------------------------------------------------------------*
*       Process Data - By Shipment Option
*----------------------------------------------------------------------*
  method process_data_by_shipment.



    sort gt_tab by sodnr sodit charg.


    loop at gt_tab_r into gs_tab.

      if gs_tab-sobnr is initial.
        "Sales Order do not exist in MSKA - batch is unassigned - RED
        gs_tab-color_line = 'C600'.

      else.
        "Check if Batch Sales Order is the same as Ship/Del SO
        read table gt_tab into data(ls_tab)
          with key sodnr = gs_tab-sobnr
                   sodit = gs_tab-sobit
                   charg = gs_tab-charg
                   binary search.

        if sy-subrc = 0.
          "Account assigment for Batch is correct - GREEN
          gs_tab-color_line = 'C500'.
          "Production Order
          gs_tab-aufnr = ls_tab-aufnr.
          gs_tab-aufit = ls_tab-aufit.
        else.
          gs_tab-color_line = 'C600'.
        endif.

      endif.

      modify gt_tab_r from gs_tab.

    endloop.

    delete gt_tab where not ( dlvnr in so_vbeln and
                              matnr in so_matnr and
                              sodnr in so_sbeln ).


  endmethod.

*----------------------------------------------------------------------*
*       method check_data
*----------------------------------------------------------------------*
*       Check Input Data
*----------------------------------------------------------------------*
  method check_input_data.

    if sscrfields-ucomm <> 'USR' and sscrfields-ucomm(1) <> '%'.

      if so_charg[] is initial.
        set cursor field 'SO_CHARG-LOW'.
        "Field & is a required field
        message e884(63) with 'SO_CHARG'.
      endif.

      if rb_2 = 'X'. "By Shipment

        if so_tknum[] is initial.
          set cursor field 'SO_TKNUM-LOW'.
          "Field & is a required field
          message e884(63) with 'SO_TKNUM'.
        endif.

      endif.

    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  CREATE_GRID
*&---------------------------------------------------------------------*
*       Create ALV grid
*----------------------------------------------------------------------*
  method create_grid .

    data: lv_cont_pos type i.
    data: lo_event_receiver type ref to lcl_event_receiver.
    data: lo_event_receiver_r type ref to lcl_event_receiver.
    data: lv_header type lvc_title.
    data: lv_header_r type lvc_title.
    data: ls_variant  type disvariant.
    data: ls_variant_r type disvariant.

    if go_grid is initial.

      "create custom container
      go_cust_cont = new #( container_name = 'CONTAINER'
                            repid          = sy-repid
                            dynnr          = '0100' ).

      if rb_1 = 'X'. "----- By Batch
        lv_cont_pos = 99.
      else.
        lv_cont_pos = 50.
      endif.

      "create splitter container
      go_cont_spl = new #( parent = go_cust_cont
                           orientation   = 0
                           sash_position = lv_cont_pos ).

      go_grid   =
          new #( i_parent = go_cont_spl->top_left_container ).

      go_grid_r =
          new #( i_parent = go_cont_spl->bottom_right_container ).

      lv_header   = 'Sales Order Assigned to Shipment'(002).
      lv_header_r = 'Sales Order Assigned to Batch'(001).

      "gs_layout-smalltitle    = 'X'.
      gs_layout-sel_mode      = 'A'.
      "Field that identify color line in internal table
      gs_layout-info_fname    = 'COLOR_LINE'.
      "gs_layout-cwidth_opt = 'X'.

      "gs_layout_r-smalltitle  = 'X'.
      "gs_layout_r-cwidth_opt  = 'X'.
      "gs_layout_r-no_toolbar  = 'X'.
      gs_layout_r-sel_mode    = 'A'.
      "Field that identify color line in internal table
      gs_layout_r-info_fname    = 'COLOR_LINE'.

      "layout variant
      ls_variant-report  = sy-repid.
      ls_variant-variant = sp_var1.

      if rb_2 = 'X'.
        gs_layout-grid_title  = lv_header.
        gs_layout_r-grid_title  = lv_header_r.
        ls_variant_r-report  = sy-repid.
        ls_variant_r-variant = sp_var2.
      endif.

      "gs_variant-report = sy-repid.

      lo_event_receiver = new #( ).

      set handler lo_event_receiver->top_of_page for go_grid.
      set handler lo_event_receiver->double_click for go_grid.

      append cl_gui_alv_grid=>mc_fc_graph  to gt_excl.
      append cl_gui_alv_grid=>mc_fc_info   to gt_excl.
      append cl_gui_alv_grid=>mc_fc_help   to gt_excl.
      append cl_gui_alv_grid=>mc_fc_loc_append_row   to gt_excl.
      append cl_gui_alv_grid=>mc_fc_loc_insert_row   to gt_excl.

      lo_event_receiver_r = new #( ).

      set handler lo_event_receiver_r->top_of_page for go_grid_r.
      set handler lo_event_receiver_r->double_click for go_grid_r.

      go_grid->set_table_for_first_display(
                        exporting
                              is_layout            = gs_layout
                              it_toolbar_excluding = gt_excl[]
                              i_save               = 'A'
                              is_variant           = ls_variant
                         changing
                              it_outtab            = gt_tab
                              it_fieldcatalog      = gt_fcat[] ).


      if rb_2 = 'X'.

        go_grid_r->set_table_for_first_display(
                          exporting
                              is_layout            = gs_layout_r
                              it_toolbar_excluding = gt_excl[]
                              i_save               = 'A'
                              is_variant           = ls_variant_r
                          changing
                              it_outtab            = gt_tab_r
                              it_fieldcatalog      = gt_fcat_r[] ).

*        go_grid_r->set_gridtitle( i_gridtitle = lv_header_r ).
*        go_grid->set_gridtitle( i_gridtitle = lv_header ).

        go_grid_r->register_edit_event(
         exporting i_event_id = cl_gui_alv_grid=>mc_evt_enter ).

      endif.

      go_grid->register_edit_event(
         exporting i_event_id = cl_gui_alv_grid=>mc_evt_enter ).

    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      method  FIELDCAT_BUILD
*&---------------------------------------------------------------------*
*       Build field catalog
*----------------------------------------------------------------------*
  method fcat_build.

    zcl_gl_alv_std=>build_fcat_lvc( importing et_fcat = et_fcat
                                     changing ct_tab  = ct_tab ).

  endmethod.

*----------------------------------------------------------------------*
*       method  FIELDCAT_ADJUST
*----------------------------------------------------------------------*
*       Adjust Field Catalog
*----------------------------------------------------------------------*
  method fcat_adjust.
    constants: lc_len type i value 19.
    data: ls_fcat type lvc_s_fcat.

    loop at ct_fcat into ls_fcat.

      case ls_fcat-fieldname.

        when 'VGTYP' or 'PSTYV'.
          ls_fcat-no_out = 'X'.

        when 'TKNUM' or 'TPNUM'.
          if rb_1 = 'X' or iv_fgrid = space.
            ls_fcat-no_out = 'X'.
          endif.

        when 'CHARG' or 'WERKS'.
          if rb_2 = 'X' and iv_fgrid = 'X'.
            ls_fcat-no_out = 'X'.
          endif.

        when 'SODNR'. "Sales Order – Delivery
          if rb_1 = 'X'.
            ls_fcat-reptext   = 'Sales Ord - Delivery'(004).
            ls_fcat-coltext   = 'Sales Ord - Delivery'(004).
          else.
            ls_fcat-reptext   = 'Sales Ord - Shipment'(011).
            ls_fcat-coltext   = 'Sales Ord - Shipment'(011).
          endif.
          ls_fcat-outputlen = lc_len.
          if iv_fgrid = space.
            ls_fcat-no_out = 'X'.
          endif.

        when 'SODIT'. "Sales Order Line – Delivery
          if rb_1 = 'X'.
            ls_fcat-reptext   = 'Sales Ord Line - Delivery'(006).
            ls_fcat-coltext   = 'Sales Ord Line - Delivery'(006).
          else.
            ls_fcat-reptext   = 'Sales Ord Line - Shipment'(012).
            ls_fcat-coltext   = 'Sales Ord Line - Shipment'(012).
          endif.
          ls_fcat-outputlen = lc_len.
          if iv_fgrid = space.
            ls_fcat-no_out = 'X'.
          endif.

        when 'SOBIT'. "Sales Order Line – Batch
          ls_fcat-reptext   = 'Sales Ord Line - Batch'(009).
          ls_fcat-coltext   = 'Sales Ord Line - Batch'(009).
          ls_fcat-outputlen = lc_len.
          if rb_2 = 'X' and iv_fgrid = 'X'.
            ls_fcat-no_out = 'X'.
          endif.

        when 'SOBNR'. "Sales Order – Batch
          ls_fcat-reptext   = 'Sales Ord - Batch'(010).
          ls_fcat-coltext   = 'Sales Ord - Batch'(010).
          ls_fcat-outputlen = lc_len.
          if rb_2 = 'X' and iv_fgrid = 'X'.
            ls_fcat-no_out = 'X'.
          endif.

        when 'KALAB'.
          "Assigned Qty
          ls_fcat-reptext   = 'Assigned Batch Qty'(005)."55
          ls_fcat-coltext   = 'Assigned Batch Qty'(005)."40
          ls_fcat-outputlen = lc_len.
          if rb_2 = 'X' and iv_fgrid = 'X'.
            ls_fcat-no_out = 'X'.
          endif.

        when 'CLABS'.
          "Unassigned Qty
          ls_fcat-reptext   = 'Unassigned Batch Qty'(003).
          ls_fcat-coltext   = 'Unassigned Batch Qty'(003).
          ls_fcat-outputlen = lc_len.
          if rb_2 = 'X' and iv_fgrid = 'X'.
            ls_fcat-no_out = 'X'.
          endif.

        when 'AUFNR'.
          "Production Order'
          ls_fcat-reptext   = 'Production Order'(007).
          ls_fcat-coltext   = 'Production Order'(007).
          ls_fcat-outputlen = lc_len.

        when 'AUFIT'.
          "Production Order Item'
          ls_fcat-reptext   = 'Production Ord Item'(008) .
          ls_fcat-coltext   = 'Production Ord Item'(008) .
          ls_fcat-outputlen = lc_len.

        when 'DLVNR'.
          if iv_fgrid = space.
            ls_fcat-no_out = 'X'.
          endif.

        when 'DLVIT'.
          if iv_fgrid = space.
            ls_fcat-no_out = 'X'.
          endif.


        when others.

          "ls_fcat-no_out = 'X'.
      endcase.

      modify ct_fcat from ls_fcat.
    endloop.

  endmethod.

*----------------------------------------------------------------------*
*      PROCESS_OUTPUT
*----------------------------------------------------------------------*
  method process_output.

    call screen 100.

  endmethod.


endclass.


process before output.
  module status_0200.
*
process after input.
  module exit_0200 at exit-command.
  module user_command_0200.

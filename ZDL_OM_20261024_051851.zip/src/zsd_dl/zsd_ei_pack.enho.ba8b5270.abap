"Name: \PR:SAPLV51P\EX:V51P_ADD_HU_TO_OBJEKT_02\EN:AUTO_VHU_PO_V51P_ADD_HU_TO_000\SE:END\EI
ENHANCEMENT 0 ZSD_EI_PACK.
*

  data: begin of lt_delivery occurs 10,
         lfart like likp-lfart,
         vbeln like likp-vbeln,
         bookdoc like likp-zzbookdoc,
        end of lt_delivery.

  data: begin of lt_huwt occurs 10,
         venum like vepovb-venum,
         unvel like vepovb-unvel,
         brgew like vepovb-brgew,
        end of lt_huwt.

  data: begin of lt_items occurs 10,
         unvel like vepovb-unvel,
         venum like vepovb-venum,
         brgew like vepovb-brgew,
        end of lt_items.

  data: lv_shtyp(4)   type c,
        lv_type(10) type c,
        lv_tabix like sy-tabix,
        lv_stmshpline like zsd_book_hdr-stmshpline,
        lv_bb_ind like zsd_book_shp_cfg-bb_ind,
        ls_objects like line of gt_objects,
        ls_pkcmp like line of lt_xvekp,
        ls_v51vp like line of gt_v51vp,
        ls_xvekp like line of lt_xvekp,
        ls_huwt like line of lt_huwt,
        ls_items like line of lt_items,
        ls_delivery like line of lt_delivery,
        lv_sums like vekp-brgew,
        lv_exit type c,
        lv_vbelv like vbfa-vbelv,
        lv_auart like vbak-auart,
        lv_werks like zplant-werks.


   IF gs_header51-object = '01'.  "outbound delivery
   Clear: lv_shtyp, lv_type, lv_exit.
   READ table gt_objects into ls_objects with key object = '04'. "shpmt
   IF sy-subrc = 0.
    SELECT a~lfart a~vbeln a~zzbookdoc into table lt_delivery
      From LIKP as a
      Inner join VTTP as b on a~vbeln = b~vbeln
      Where b~tknum = ls_objects-objkey.

    " check that it is an export shpmt or return delivery
    SELECT single shtyp
      Into lv_shtyp
      From VTTK
      Where tknum = ls_objects-objkey.

    IF lv_shtyp <> 'ZEXP'.
        lv_exit = 'X'.
    ENDIF.

    READ table lt_delivery into ls_delivery with key vbeln = gs_header51-objkey
                                                       binary search.
      "check if delivery is breakbulk
      IF sy-subrc = 0.
       SELECT single stmshpline
       Into lv_stmshpline
       From zsd_book_hdr
       Where bookdoc = ls_delivery-bookdoc.

       If lv_stmshpline is not initial.
        SELECT single bb_ind
        Into lv_bb_ind
        From zsd_book_shp_cfg
        Where stmshpline = lv_stmshpline.
       endif.
        If lv_bb_ind = 'X'.
          lv_exit = 'X'.          "do not process breakbulk
        endif.
      endif.

     " check that we’re processing container handling unit in a port
    READ table lt_xvekp into ls_xvekp with key vhart = 'CONT'.
    IF sy-subrc = 0.
       SELECT single type
      Into lv_type
      From ZPLANT
      Where werks = ls_xvekp-werks.

      If lv_type <> 'PORT'.
        lv_exit = 'X'.
      Endif.
    else.
      lv_exit = 'X'.
    ENDIF.

  IF lv_exit is initial.   "process remaining enhanc. code
   Sort lt_xvepo by unvel.
   Sort gt_v51vp by charg vbeln.
   LOOP at lt_xvekp into ls_pkcmp where vhart = 'PKG'.
    Lv_tabix = sy-tabix.
   IF ls_pkcmp-vpobj = '01'.   "outbound delivery or return delivery
    READ table lt_delivery with key vbeln = ls_pkcmp-vpobjkey binary search.
    IF sy-subrc = 0.
     Ls_huwt-brgew = ls_pkcmp-brgew.
     Ls_huwt-unvel = ls_pkcmp-venum.
      READ table lt_xvepo into ls_vepo with key unvel = ls_pkcmp-venum binary search.
      If sy-subrc = 0.
        ls_huwt-venum = ls_vepo-venum.
        clear ls_vepo.
      endif.
     Append ls_huwt to lt_huwt.
     Clear ls_huwt.
     DELETE lt_xvekp index lv_tabix.
     DELETE lt_xvepo where venum = ls_pkcmp-venum.
     DELETE lt_xvepo where unvel = ls_pkcmp-venum.
    ELSE.
      READ table lt_xvepo into ls_vepo with key venum = ls_pkcmp-venum.
      If sy-subrc = 0.
        ls_pkcmp-charg = ls_vepo-charg.
      endif.
      READ table Gt_v51vp into ls_v51vp with key charg = ls_pkcmp-charg
                                        vbeln = gs_header51-objkey binary search.
      IF sy-subrc = 0.
        Continue.
      Else.
       DELETE lt_xvekp index lv_tabix.
       DELETE lt_xvepo where venum = ls_pkcmp-venum.
       DELETE lt_xvepo where unvel = ls_pkcmp-venum.
      Endif.
    Endif.
   elseif ls_pkcmp-vpobj = '12'.
      READ table lt_xvepo into ls_vepo with key venum = ls_pkcmp-venum.
      If sy-subrc = 0.
        ls_pkcmp-charg = ls_vepo-charg.
      endif.
     READ table Gt_v51vp into ls_v51vp with key charg = ls_pkcmp-charg
                                       vbeln = gs_header51-objkey binary search.
      IF sy-subrc = 0.
        Continue.
      Else.
       DELETE lt_xvekp index lv_tabix.
       DELETE lt_xvepo where venum = ls_pkcmp-venum.
       DELETE lt_xvepo where unvel = ls_pkcmp-venum.
      Endif.
   Endif.

 ENDLOOP.
Endif.
Endif.
Sort lt_xvepo by venum vepos.
Endif.   "lv_exit

  "Un-assign all handling units
  IF gs_header51-object = '03' and  "export consignment return delivery
     gs_header51-lfart = 'LR' and
     gs_header51-vtweg = '20'.
    Clear: lv_type, lv_exit, ls_xvekp.

     "check that we’re processing a return delivery to a port
     SELECT single werks
      Into lv_werks
      From TVSWZ
      Where vstel = gs_header51-vstel.

     check lv_werks is not initial.
     SELECT single type
      Into lv_type
      From ZPLANT
      Where werks = lv_werks.

      If lv_type <> 'PORT'.
        lv_exit = 'X'.
      Endif.
     "check preceding doc. type for delivery currently being processed
    If lv_exit is initial.
     SELECT single vbelv
      Into lv_vbelv
      From VBFA
      Where vbeln = gs_header51-objkey
        and posnn = '000010'
        and vbtyp_n = 'T'.

     If lv_vbelv is not initial.
     SELECT single auart
      Into lv_auart
      From VBAK
      Where vbeln = lv_vbelv.

      If lv_auart = 'ZKA'.     "consignment pick-up order
       Loop at lt_xvekp into ls_xvekp where vhart = 'PKG'.
         ls_xvekp-vpobj = '12'.
         modify lt_xvekp from ls_xvekp.
       endloop.
      endif.
     endif.
    endif.
   endif.

ENDENHANCEMENT.

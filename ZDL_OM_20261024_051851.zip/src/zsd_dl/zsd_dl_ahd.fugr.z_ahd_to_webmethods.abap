FUNCTION Z_AHD_TO_WEBMETHODS.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(SENDER) TYPE  CHAR10
*"     VALUE(RECEIVER) TYPE  CHAR10
*"     VALUE(DOCTYPE) TYPE  CHAR30
*"     VALUE(DOCID) TYPE  CHAR16
*"     VALUE(SERIAL) TYPE  CHAR20
*"     VALUE(GROUPNAME) TYPE  CHAR30
*"     VALUE(PRIORITY) TYPE  CHAR1
*"     VALUE(SEVERITY) TYPE  CHAR1 OPTIONAL
*"     VALUE(TEXT) TYPE  ZCHAR400
*"     VALUE(KEYID) TYPE  CHAR30
*"     VALUE(SEQID) TYPE  CHAR1
*"  EXPORTING
*"     VALUE(RETURN) LIKE  RFCTEST-RFCDATA1
*"----------------------------------------------------------------------





ENDFUNCTION.

*&---------------------------------------------------------------------*
*&  Include           LZSD_DL_REQ_FIELDSF01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  SUBROUTINES
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  REQ_FIELDS_GET_DATA
*&---------------------------------------------------------------------*
* Perform SELECT queries to populate i_req_fields and i_edsappl,
*  using the segnam values from i_idoc_data and message type.
*----------------------------------------------------------------------*
*      <--PI_REQ_FIELDS   Required fields table to populate
*      <--PI_EDSAPPL      IDoc Segment Application Structures
*      -->PI_IDOC_DATA    IDoc Data
*      -->PG_MESSAGE_TYPE Message Type
*----------------------------------------------------------------------*
FORM req_fields_get_data  TABLES   pi_req_fields STRUCTURE zreq_fields
                                   pi_edsappl    STRUCTURE edsappl
                                   pi_idoc_data  STRUCTURE edidd
                          USING    pg_message_type
                                   pg_aux_key1.

  DATA: l_idx TYPE i,
        li_edsappl_key LIKE edidd OCCURS 0,
        lt_req_fields_excl LIKE pi_req_fields OCCURS 0 WITH HEADER LINE.

*** Use message type from the control record to select required
*    fields into internal table I_REQFIELD from ZREQ_FIELDS.
  SELECT *
      FROM zreq_fields
      INTO TABLE pi_req_fields
      WHERE zmsg_type = pg_message_type.

* We are only concerned with 'keyless' and, if applicable the
*  required fields associated with key pg_aux_key1
  SORT pi_req_fields BY zaux_key1.
  DELETE pi_req_fields WHERE NOT ( zaux_key1 = ' '
                              OR   zaux_key1 = pg_aux_key1 ).

* Fields marked with the zexcl_flag (EXCLUDE FLAG), do not
*  need to be validated, and so may be removed from the table
*  This is based on Message type, Segment Name, Fieldname and Value,
*  allowing the multiple Aux Keys that might normally be associated to
*  be ignored.

* If there are entries to exclude, loop through and delete all Aux Key
*  field records associated with each exclusion by Field and Value
  SORT pi_req_fields BY zexcl_flag DESCENDING.
  CLEAR pi_req_fields.
  READ TABLE pi_req_fields INDEX 1.
  IF NOT pi_req_fields-zexcl_flag IS INITIAL.

* Begin with creating an internal table of EXCLUDE entries:
    lt_req_fields_excl[] = pi_req_fields[].
    DELETE lt_req_fields_excl WHERE zexcl_flag IS INITIAL.

    SORT: pi_req_fields BY zmsg_type zseg_name zfieldname zvalue,
     lt_req_fields_excl BY zmsg_type zseg_name zfieldname zvalue.

    LOOP AT lt_req_fields_excl.
      DELETE pi_req_fields WHERE
             zmsg_type  = lt_req_fields_excl-zmsg_type
         AND zseg_name  = lt_req_fields_excl-zseg_name
         AND zfieldname = lt_req_fields_excl-zfieldname
         AND zvalue     = lt_req_fields_excl-zvalue.
    ENDLOOP. " AT lt_req_fields_excl.

  ENDIF. "NOT pi_req_fields-zexcl_flag IS INITIAL.

  FREE lt_req_fields_excl.

* If it turns out that there are no required fields left either by
*  selection from SAP or programatic exclusion, raise the exception
  IF pi_req_fields[] IS INITIAL.
    RAISE no_required_values.
  ENDIF. " pi_req_fields[] is initial.

*----------------------------------------------------------------------*
*** retrieve lengths on IDoc data fields from EDSAPPL
  li_edsappl_key[] = pi_idoc_data[].
  SORT li_edsappl_key BY segnam.
  DELETE ADJACENT DUPLICATES FROM li_edsappl_key COMPARING segnam.

  SELECT *
    FROM edsappl
    INTO TABLE pi_edsappl
    FOR ALL ENTRIES IN li_edsappl_key
    WHERE segtyp = li_edsappl_key-segnam.
  IF sy-subrc <> 0.
    RAISE unidentifiable_idoc_structure.
  ENDIF.

ENDFORM.                    " REQ_FIELDS_GET_DATA

*&---------------------------------------------------------------------*
*&      Form  req_fields_app_log
*&---------------------------------------------------------------------*
*       Write out required field application log
*----------------------------------------------------------------------*
*      -->PI_REQ_FIELDS  Contains all failed validations (zfieldname)
*      -->P_IDOC_NUMBER       IDoc Number for log output
*      -->P_APP_LOG_OBJECT    Necessary for Application Logging
*      -->P_APP_LOG_SUBOBJECT Necessary for Application Logging
*      <--P_APP_LOG_EXT_ID    Identifies App Log (For AHD ticket)
*----------------------------------------------------------------------*
FORM req_fields_app_log  TABLES   pi_req_fields STRUCTURE zreq_fields
                         USING    p_idoc_number TYPE edi_docnum
                                  p_app_log_object TYPE balobj_d
                                  p_app_log_subobject TYPE balsubobj
                                  text4 TYPE char50
                                  text5 TYPE char50
                                  text6 TYPE char50
                                  p_ahd_tkt_skip_flag       "<<< SC02
                         CHANGING p_app_log_ext_id TYPE balnrext
                                  p_appl_log_nbr   TYPE balognr.

  DATA:
    pst_req_fields  LIKE zreq_fields,
*    g_dummy         TYPE string,                            " <<< SC02

    l_err_count     TYPE i,
    lt_return       TYPE STANDARD TABLE OF bapiret2,
    l_fieldname(30) TYPE c.



*// Set the application logging parameters
*// Most important to specify the logging object and subobject
  l_log-alprog    = sy-repid.
  l_log-aluser    = sy-uname.
  l_log-object    = p_app_log_object.
  l_log-subobject = p_app_log_subobject.

  CLEAR g_dummy .                                           " <<< SC02
**// open the application log
  PERFORM applog_log_open USING l_log.
  l_log_open = 'X' .                                        "<<< SC02.
* Capture external ID application number for AHD ticket ref.
  p_app_log_ext_id = l_log-extnumber.

*/----------------------------------------------------------------------
* List IDoc number before looping through fields
*
  IF NOT p_idoc_number IS INITIAL.
    MESSAGE s000 WITH 'IDoc'(m01)
                       p_idoc_number
                      'failed validation on the following fields:'(m02)
                 INTO g_dummy.
    PERFORM return_applog USING g_dummy.
    PERFORM applog_mess_add_simple.
  ENDIF.

  IF NOT text4 IS INITIAL.
    MESSAGE s000 WITH text4 INTO g_dummy.
    PERFORM return_applog USING g_dummy.
    PERFORM applog_mess_add_simple.
  ENDIF.
  IF NOT text5 IS INITIAL.
    MESSAGE s000 WITH text5 INTO g_dummy.
    PERFORM return_applog USING g_dummy.
    PERFORM applog_mess_add_simple.
  ENDIF.
  IF NOT text6 IS INITIAL.
    MESSAGE s000 WITH text6 INTO g_dummy.
    PERFORM return_applog USING g_dummy.
    PERFORM applog_mess_add_simple.
  ENDIF.


*** Loop through records, creating a ticket for each.
  CLEAR l_err_count.
  LOOP AT pi_req_fields INTO pst_req_fields.
    CONCATENATE pst_req_fields-zseg_name
                pst_req_fields-zfieldname
                           INTO l_fieldname SEPARATED BY '-'.

    IF pst_req_fields-zvalue IS INITIAL.
      IF NOT pst_req_fields-zrequired_all IS INITIAL.
        MESSAGE e000 WITH 'Field'(m03)
                          l_fieldname
         'is empty or invalid, but required on all occurrences.'(m07)
                     INTO g_dummy.
      ELSE.
        MESSAGE e000 WITH 'Field'(m03)
                          l_fieldname
                          'is empty or invalid, but required'(m04)
                     INTO g_dummy.
      ENDIF.

    ELSE.
      IF NOT pst_req_fields-zrequired_all IS INITIAL.
        MESSAGE e000 WITH 'Field'(m03)
                          l_fieldname
                          'on all occurrences requires value:'(m08)
                          pst_req_fields-zvalue
                     INTO g_dummy.
      ELSE.
        MESSAGE e000 WITH 'Field'(m03)
                          l_fieldname
                          'is missing required value:'(m05)
                          pst_req_fields-zvalue
                     INTO g_dummy.
      ENDIF.
    ENDIF.
    IF NOT pst_req_fields-zrequired_all IS INITIAL.
      CONCATENATE g_dummy
                  ' on all occurrences.'(m07) INTO g_dummy.
    ENDIF.
    PERFORM return_applog USING g_dummy.
    PERFORM applog_mess_add_simple.

    l_err_count = l_err_count + 1.

  ENDLOOP. " AT pi_req_fields into pst_req_fields.

* Total number of errors recorded to log:
  MESSAGE s000 WITH  l_err_count
                     'missing/invalid field values within IDoc'(m06)
               INTO g_dummy.
  PERFORM return_applog USING g_dummy.
  PERFORM applog_mess_add_simple.

*// Saves the contents of the application log to database
*/  Do not close the appl log if the ahd ticket needs to be created i.e
*/  when ahd_tkt_skip_flag is initial .
  IF p_ahd_tkt_skip_flag IS INITIAL.                        "<<< SC02
  ELSE.                                                     "<<< SC02
    PERFORM applog_log_close_with_return CHANGING l_lognum.

    READ TABLE l_lognum INDEX 1 INTO wa_lognum.
    CHECK sy-subrc IS INITIAL.
    p_appl_log_nbr  = wa_lognum-lognumber.
    l_log_open = ' ' .                                      "<<< SC02
  ENDIF.
ENDFORM.                    " req_fields_app_log

*&---------------------------------------------------------------------*
*&      Form  RETURN_APPLOG
*&---------------------------------------------------------------------*
*       Collects messages sent to the application log for return
*   to calling program
*----------------------------------------------------------------------*
*      -->P_STRING  Application log message line
*----------------------------------------------------------------------*
FORM return_applog  USING    p_string.

  g_line = g_line + 1.

  CLEAR gt_return.
  gt_return-line = g_line.
  gt_return-text = p_string.
  APPEND gt_return.
  CLEAR gt_return.

ENDFORM.                    " RETURN_APPLOG

*&---------------------------------------------------------------------*
*&      Form  req_fields_ahd_tkt
*&---------------------------------------------------------------------*
*       Build the output and generate the AHD ticket, linking back
*   to the Application Logs
*----------------------------------------------------------------------*
FORM req_fields_ahd_tkt TABLES applog_output STRUCTURE zret_text"<<<SC0
                        USING text2 TYPE char50
                              text3 TYPE char50
                              text4 TYPE char50
                              text5 TYPE char50
                              text6 TYPE char50
                              p_app_log_skip_flag TYPE char1
                              p_app_log_object TYPE balobj_d"<<SC02
                              p_app_log_subobject TYPE balsubobj"<<SC02
                       CHANGING p_app_log_ext_id TYPE balnrext
                                p_appl_log_nbr   TYPE balognr.

  DATA: l_zsp_fieldvalue LIKE zsp_value-fieldvalue.

  CLEAR : l_zsp_fieldvalue ,
          g_dummy .

  SELECT fieldvalue
    UP TO 1 ROWS
    INTO l_zsp_fieldvalue
    FROM zsp_value
    WHERE pgrmid = 'R3_PARTNER'.
  ENDSELECT.
  IF sy-subrc <> 0.
* This is the R/3 system, just call the function module

    CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
      EXPORTING
        inventory_code         = g_inventory_code
        idoc_number            = g_idoc_number
        message_type           = g_message_type
        receiver_number        = g_receiver_num
        sender_number          = g_sender_num
        text_1                 = text-a01
        text_2                 = text2
        text_3                 = text3
        text_4                 = text4
        text_5                 = text5
        text_6                 = text6
      EXCEPTIONS
        invalid_inv_code       = 1
        ahdgrp_not_found       = 2
        invalid_idoc_number    = 3
        webmd_connection_error = 4
        OTHERS                 = 5.
    IF sy-subrc <> 0.
*// check if the user has already set the parameter for application log
      PERFORM validation_application_logging USING          "<<< SC02
                                               p_app_log_skip_flag
                                               p_app_log_object
                                               p_app_log_subobject
                                               sy-subrc
                                               p_app_log_ext_id
                                               p_appl_log_nbr.

      applog_output[] = gt_return[].                        "<<< SC02

    ENDIF. " sy-subrc <> 0.

  ELSE.
* This is a system other than R/3, so make a RFC.

    CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
      DESTINATION l_zsp_fieldvalue
      EXPORTING
        inventory_code         = g_inventory_code
        idoc_number            = g_idoc_number
        message_type           = g_message_type
        receiver_number        = g_receiver_num
        sender_number          = g_sender_num
        text_1                 = text-a01
        text_2                 = text2
        text_3                 = text3
        text_4                 = text4
        text_5                 = text5
        text_6                 = text6
      EXCEPTIONS
        invalid_inv_code       = 1
        ahdgrp_not_found       = 2
        invalid_idoc_number    = 3
        webmd_connection_error = 4
        OTHERS                 = 5.
    IF sy-subrc <> 0.
*// check if the user has already set the parameter for application log
      PERFORM validation_application_logging USING          "<<< SC02
                                             p_app_log_skip_flag
                                             p_app_log_object
                                             p_app_log_subobject
                                             sy-subrc
                                             p_app_log_ext_id
                                             p_appl_log_nbr.

      applog_output[] = gt_return[].                        "<<< SC02
    ENDIF.
  ENDIF.
  IF l_log_open = 'X' .
    PERFORM applog_log_close_with_return CHANGING l_lognum.

    READ TABLE l_lognum INDEX 1 INTO wa_lognum.
    CHECK sy-subrc IS INITIAL.
    p_appl_log_nbr  = wa_lognum-lognumber.
    l_log_open = ' ' .                                      "<<< SC02
  ENDIF.

ENDFORM.                    " req_fields_ahd_tkt

*&---------------------------------------------------------------------*
*&      Form  validation_application_logging
*&---------------------------------------------------------------------*
*// <<< SC01 start of schaudh 10/06/2005 .
*/  changes made to catch the sy-subrc error. The case statement should
*/  help prevent the short dumps .
*// <<< SC02 : Rectifying possible cause of update error. Now writing
*/  message ids to the application log.
*----------------------------------------------------------------------*
FORM validation_application_logging USING
                              p_app_log_skip_flag TYPE char1
                              p_app_log_object TYPE balobj_d
                              p_app_log_subobject TYPE balsubobj
                              sy_subrc TYPE sy-subrc
                         CHANGING p_app_log_ext_id TYPE balnrext
                                  p_appl_log_nbr   TYPE balognr.

  CLEAR g_dummy .
*// Set the application logging parameters
*// Most important to specify the logging object and subobject
  IF NOT l_log_open = 'X' .
    l_log-alprog    = sy-repid.
    l_log-aluser    = sy-uname.
    IF  p_app_log_object    IS INITIAL
    AND p_app_log_subobject IS INITIAL .
      l_log-object    = 'ZDL_INTERFACE' .
      l_log-subobject = 'ZDL_AHD_CREATE' .
    ENDIF.
    PERFORM applog_log_open USING l_log.
    l_log_open = 'X' .
  ENDIF.

  CASE sy_subrc .
    WHEN '1' .
      MESSAGE i086(zsd_dl) INTO g_dummy .                   " <<< SC02
      PERFORM return_applog USING g_dummy.                  " <<< SC02
      PERFORM applog_mess_add_simple.                       " <<< SC02

    WHEN '2' .
      MESSAGE i087(zsd_dl) INTO g_dummy .                   " <<< SC02
      PERFORM return_applog USING g_dummy.                  " <<< SC02
      PERFORM applog_mess_add_simple.                       " <<< SC02

    WHEN '3'.
      MESSAGE i088(zsd_dl) INTO g_dummy .                   " <<< SC02
      PERFORM return_applog USING g_dummy.                  " <<< SC02
      PERFORM applog_mess_add_simple.                       " <<< SC02

    WHEN '4'.
      MESSAGE i089(zsd_dl) INTO g_dummy .                   " <<< SC02
      PERFORM return_applog USING g_dummy.                  " <<< SC02
      PERFORM applog_mess_add_simple.                       " <<< SC02

    WHEN OTHERS.
      MESSAGE i090(zsd_dl) INTO g_dummy .                   " <<< SC02
      PERFORM return_applog USING g_dummy.                  " <<< SC02
      PERFORM applog_mess_add_simple.                       " <<< SC02

  ENDCASE.
*// Saves the contents of the application log to database
  IF l_log_open = 'X' .
    PERFORM applog_log_close_with_return CHANGING l_lognum.

    READ TABLE l_lognum INDEX 1 INTO wa_lognum.
    CHECK sy-subrc IS INITIAL.
    p_appl_log_nbr  = wa_lognum-lognumber.
    l_log_open = ' ' .                                      "<<< SC02
  ENDIF.

ENDFORM.                    "validation_application_logging

* <<<SR01 - Start
*&---------------------------------------------------------------------*
*&      Form  sub_mail
*&---------------------------------------------------------------------*
* If there is an entry in the table ZZMAILTAB for the current
* Message Type and Segment, then send mail
*----------------------------------------------------------------------*
*  -->  pi_req_fields  Required Fields table
*  -->  pi_mailkey     Mailkey (MessageType_SegmentName) to identify
*                      receivers
*  -->  pl_text4       Key field
*----------------------------------------------------------------------*
FORM sub_mail TABLES pi_req_fields STRUCTURE zreq_fields
                     pi_mailkey    STRUCTURE zzmailtab
              USING  pl_text4      TYPE      char50.

* Email Receivers for the given Message & Segment
  IF NOT pi_mailkey[] IS INITIAL.
    SELECT *
        INTO CORRESPONDING FIELDS OF TABLE i_mailtab
        FROM zzmailtab
        FOR ALL ENTRIES IN pi_mailkey
        WHERE mailkey = pi_mailkey-mailkey.

    IF sy-subrc = 0.
* If found, send mail
      PERFORM send_mail TABLES pi_req_fields
                        USING  pl_text4.
    ENDIF.
  ENDIF.


ENDFORM.                    " sub_mail
*&---------------------------------------------------------------------*
*&      Form  send_mail
*&---------------------------------------------------------------------*
* Sends mail
*----------------------------------------------------------------------*
*      -->PI_REQ_FIELDS  Error Messages
*      -->PL_TEXT4       Keyfield
*----------------------------------------------------------------------*
FORM send_mail TABLES   pi_req_fields STRUCTURE zreq_fields
               USING    pl_text4      TYPE      char50.

* Local internal table to hold email recipients
  DATA:
    i_mailrec TYPE TABLE OF zrecmail WITH HEADER LINE,

* table to hold required field(s), messages per person
    i_req_rec LIKE TABLE OF soli WITH HEADER LINE,
    i_rpt_hdr  LIKE zrptheader OCCURS 0 WITH HEADER LINE,
* Message type & Segment name
    l_seg   TYPE edilsegtyp,
    l_msg   TYPE edi_mestyp,
* Mail type - this is required because of control level op
    l_mailtype LIKE zzmailtab-mail_type,
* Date and Time
    l_date(10),
    l_time(8),
* Subject
    s_subject LIKE sood1-objdes.

* Build Subject of the mail
  WRITE sy-datum TO l_date MM/DD/YYYY.
  WRITE sy-uzeit TO l_time USING EDIT MASK '__:__:__'.

  CONCATENATE sy-sysid sy-mandt
              l_date
              l_time
              'Req.Field'(i02)
      INTO s_subject SEPARATED BY '-'.

  SORT i_mailtab BY mail_addr mailkey.
  LOOP AT i_mailtab.
    SPLIT i_mailtab-mailkey AT ':' INTO l_msg l_seg.
    CONCATENATE l_seg '*' INTO l_seg.

* Get all relevant missed or invalid segment per person
    REFRESH i_req_rec.
*  Header information in the mail
    IF NOT pl_text4 IS INITIAL.
      CONCATENATE 'For'(i01)
                  pl_text4
                  INTO i_req_rec-line
                  SEPARATED BY space.
      APPEND i_req_rec.
      CLEAR  i_req_rec.
    ENDIF.


    CONCATENATE 'The following required fields of message type'(e01)
                l_msg
                'are missing or invalid:'(e02)
                INTO i_req_rec-line
                SEPARATED BY space.
    APPEND i_req_rec.
    CLEAR  i_req_rec.
    APPEND i_req_rec.
* Header Label
    CONCATENATE 'Message Type'(h01)
                'Segment Type'(h02)
                'Field Name'(h03)
                'Field Value'(h04)
                INTO i_req_rec-line
                SEPARATED BY '/'.
    APPEND i_req_rec.
    CLEAR  i_req_rec.
    APPEND i_req_rec.
* Append each missed field - Group all messages for a person
    LOOP AT pi_req_fields
        WHERE zmsg_type =  l_msg
          AND zseg_name CP l_seg.

* Build Content/Error message
      CONCATENATE pi_req_fields-zmsg_type
                  pi_req_fields-zseg_name
                  pi_req_fields-zfieldname
                  pi_req_fields-zvalue
             INTO i_req_rec-line
        SEPARATED BY '/'.
* Store it in a table
      APPEND i_req_rec.
      CLEAR  i_req_rec.
    ENDLOOP.

    APPEND i_req_rec.
    MOVE '*********END OF REPORT**********'(h05) TO i_req_rec-line.
    APPEND i_req_rec.

*  Keep track of Mail type.
    l_mailtype = i_mailtab-mail_type.
    AT END OF mail_addr.
      REFRESH i_mailrec.
* Get receivers in the format of ZREC_MAIL
      i_mailrec-receiver   = i_mailtab-mail_addr.
      i_mailrec-mail_type  = l_mailtype.
      APPEND i_mailrec.

* Send Mail
      CALL FUNCTION 'Z_SEND_ALL_MAIL'
        EXPORTING
          subject      = s_subject
          express      = 'X'
          owner        = sy-uname
          name         = 'MIS_REQFIELD'
        TABLES
          contents     = i_req_rec
          rec_list     = i_mailrec
        EXCEPTIONS
          send_failure = 1
          folder_error = 2
          OTHERS       = 3.
    ENDAT.
  ENDLOOP.

ENDFORM.                    " send_mail
* <<<SR01 - end

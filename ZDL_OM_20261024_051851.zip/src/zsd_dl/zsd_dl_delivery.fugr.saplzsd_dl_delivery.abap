*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_DELIVERYTOP.               " Global Data
  INCLUDE LZSD_DL_DELIVERYUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_DELIVERYF...               " Subprograms
* INCLUDE LZSD_DL_DELIVERYO...               " PBO-Modules
* INCLUDE LZSD_DL_DELIVERYI...               " PAI-Modules

INCLUDE lzsd_dl_deliveryf01.

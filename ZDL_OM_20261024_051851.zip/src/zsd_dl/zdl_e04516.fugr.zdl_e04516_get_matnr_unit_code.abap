FUNCTION zdl_e04516_get_matnr_unit_code.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  TABLES
*"      MATNR_IN STRUCTURE  ZMATNR_IN
*"      MATNR_OUT STRUCTURE  ZMATNR_OUT
*"      MATNR_ERR STRUCTURE  ZMATNR_ERR
*"----------------------------------------------------------------------
  DATA: lt_mat_obj TYPE tt_mat_obj,
        ls_mat_obj TYPE typ_mat_obj,
        lv_cuobf   TYPE cuobm,
        lv_atinn   TYPE atinn,
        lt_charac  TYPE STANDARD TABLE OF zsd_characteristic_name,
        ls_charac  TYPE zsd_characteristic_name,
        lt_conf    TYPE STANDARD TABLE OF ibvalue0,
        ls_conf    TYPE ibvalue0.
  CONSTANTS : lc_unit_code(9) VALUE 'UNIT_CODE',
              lc_check        VALUE 'X'.

* Get the internal object number of the material.
  LOOP AT matnr_in INTO ls_mat_obj.

    lv_cuobf = ls_mat_obj-cuobf.
    REFRESH lt_charac.
    ls_charac-atnam = lc_unit_code.
    APPEND ls_charac TO lt_charac.
    CLEAR ls_charac.

    CALL FUNCTION 'ZSD_GET_SINGLE_VALUES_OF_INST'
      EXPORTING
        instance                             = lv_cuobf
*   I_SORT_ON_NAME                       = 'X'
*   I_EXTRA_FIELDS_OPTION                = ' '
*   I_NUMBER_OF_DECIMAL_PTS              = '5'
       i_ignore_exceptions                  = lc_check
     IMPORTING
       et_values                            = lt_conf
     TABLES
       t_get_specific_characteristics       = lt_charac
*   T_CHARACTERISTIC_VALUES              =
     EXCEPTIONS
       instance_not_found                   = 1
       no_configuration_data_found          = 2
       characteristic_not_found             = 3
       OTHERS                               = 4.

*If no variant configuration details are found, then return an error
*flag
    IF sy-subrc NE 0.
      matnr_err-matnr = ls_mat_obj-matnr.
      matnr_err-error =
      'No material configuration is maintained'(009).
      APPEND matnr_err.
      CLEAR  matnr_err.
    ELSE.

*If variant configuration data is found, then check the characteristic
*supplied by IV_ATNAM
      SORT lt_conf BY atwrt .
      CLEAR lv_atinn.
      CALL FUNCTION 'CONVERSION_EXIT_ATINN_INPUT'
        EXPORTING
          input  = lc_unit_code
        IMPORTING
          output = lv_atinn.
      READ TABLE lt_conf INTO ls_conf WITH KEY atinn = lv_atinn.
      IF sy-subrc <> 0.
        matnr_err-matnr = ls_mat_obj-matnr.
        matnr_err-error =
        'No unit code material configuration is maintained'(010).
        APPEND matnr_err.
        CLEAR  matnr_err.
      ELSE.
        matnr_out-matnr     = ls_mat_obj-matnr.
        matnr_out-unit_code = ls_conf-atwrt.
        APPEND matnr_out.
        CLEAR  matnr_out.
      ENDIF.
    ENDIF.
  ENDLOOP.
ENDFUNCTION.

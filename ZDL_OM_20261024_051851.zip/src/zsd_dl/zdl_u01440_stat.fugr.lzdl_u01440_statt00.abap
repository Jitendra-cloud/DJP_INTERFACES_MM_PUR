*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_U01440_STAT.................................*
DATA:  BEGIN OF STATUS_ZDL_U01440_STAT               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_U01440_STAT               .
CONTROLS: TCTRL_ZDL_U01440_STAT
            TYPE TABLEVIEW USING SCREEN '0100'.
*.........table declarations:.................................*
TABLES: *ZDL_U01440_STAT               .
TABLES: ZDL_U01440_STAT                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

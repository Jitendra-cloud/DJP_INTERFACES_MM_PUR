FUNCTION-POOL zdl_container.             "MESSAGE-ID ..

***********************************************************************
* TYPE DECLARATIONS                                                   *
***********************************************************************
TYPES:

* Booking header info
  BEGIN OF gts_book_hdr,
    bookdoc TYPE zsd_book_bookdoc,  "booking document number
  END OF gts_book_hdr.


***********************************************************************
* DATA DECLARATIONS                                                   *
***********************************************************************
DATA:

*   Booking header info
  gt_book_hdr    TYPE STANDARD TABLE OF gts_book_hdr,
  gs_book_hdr    TYPE gts_book_hdr,

*   Table of hus to be packed into container
  gt_hus_to_pack TYPE zdl_exidv_tab,
  gs_hus_to_pack TYPE zdl_exidv,

*   Bapi Return Parameter
  gt_return      TYPE STANDARD TABLE OF bapiret2,
  gs_return      TYPE bapiret2.


DATA : gt_hus_to_pack_cont  TYPE zdl_exidv_tab.
TABLES : e1edk01,
         e1edk02,
         e1edp01,
         z1subitm.

************************************************************************
*--- Global Internal Tables
************************************************************************
DATA: gt_idoc_status  TYPE STANDARD TABLE OF bdidocstat.

DATA:    BEGIN OF gs_segm.
        INCLUDE STRUCTURE edidd.
DATA:    END   OF gs_segm.

DATA : BEGIN OF gt_book_itm OCCURS 0 ,
         bookdoc TYPE zsd_book_bookdoc,
         bookitm TYPE zsd_book_bookitm,
         vbeln   TYPE vbeln,
         posnr   TYPE posnr,
       END OF gt_book_itm.

DATA : BEGIN OF gt_charg OCCURS 0 ,
         charg TYPE charg_d,
       END OF gt_charg.

DATA : BEGIN OF gt_vepo OCCURS 0 ,
         venum TYPE venum,
         matnr TYPE matnr,
         vbeln TYPE vbeln,
         werks TYPE werks_d,
         charg TYPE charg_d,
         lgort TYPE lgort_d,
       END OF gt_vepo.

DATA : BEGIN OF gt_ekko OCCURS 0 ,
         ebeln TYPE ebeln,
       END OF gt_ekko.

DATA : BEGIN OF gt_ekes OCCURS 0 ,
         ebeln TYPE ebeln,
         charg TYPE charg_d,
       END OF gt_ekes.


DATA: gs_e1edk01  LIKE edidd-segnam VALUE 'E1EDK01',
      gs_e1edk02  LIKE edidd-segnam VALUE 'E1EDK02',
      gs_z1subitm LIKE edidd-segnam VALUE 'Z1SUBITM',
      gs_e1edp01  LIKE edidd-segnam VALUE 'E1EDP01',
      gc_error    TYPE edids-status VALUE '51',
      gc_success  TYPE edids-status VALUE '53',
      gv_sord     TYPE vbeln,
      gs_control  TYPE edidc.


DATA: gc_e         TYPE c            VALUE 'E',
      gc_s         TYPE c            VALUE 'S',
      gc_msgid(13) TYPE c            VALUE 'ZDL_CONTAINER',
      gv_check(1).

DATA: gv_signi           TYPE zdl_signi,
      gv_seal            TYPE zdl_seal_no,
      gv_cont_size       TYPE zsd_book_con_size,
      gv_booknum         TYPE zsd_book_booknum,
      gv_bookdoc_i       TYPE zsd_book_bookdoc,
      gv_bookdoc         TYPE zsd_book_bookdoc,
      gv_container_exidv TYPE exidv,  "container HU created external
      gv_container_venum TYPE venum , "container HU created internal
      gv_matnr           TYPE matnr.

DATA: gv_tare TYPE zsd_cont_tare,
      gv_uom  TYPE zsd_uom.

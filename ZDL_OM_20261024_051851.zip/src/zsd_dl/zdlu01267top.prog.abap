*&---------------------------------------------------------------------*
*&  Include           ZSDU01267TOP                                     *
*&---------------------------------------------------------------------*
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**           COPYRIGHT (C) 2003 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                           **
**             REVISIONS COPYRIGHT (C) 2007, 20nn                    **
**                    by INTERNATIONAL PAPER                         **
*_____________________________________________________________________*
* Report Name: ZSDU01267_CREATE_CONTAINER_HU         Date: 04/16/2007 *
* Programmer : Bruce Ballehr                                          *
*_____________________________________________________________________*
* Description :                                                       *
*_____________________________________________________________________*
* Change History:                                                     *
*   Programmer       Date     Req. #            Action                *
* ===============  ========  =========  ==============================*
* Bruce Ballehr    04/16/07  EDEK907765 Initial creation              *
* Kishor Thakur    09/15/07  EDEK909275 Changes for SKIDS & CARTONS   *
*                                                                     *
***********************************************************************
PROGRAM zsdu01267_create_container MESSAGE-ID zdl_container.

TYPE-POOLS: slis.

***********************************************************************
* TABLES                                                              *
***********************************************************************
TABLES: vbap,                  "Sales Order item
        zdlu01267_0100,        "screen 0100 fields
        zdlu01267_0200,        "screen 0200 fields
        t001l,                 "Plant/Sloc table
        zsd_book_hdr.          "Booking Header fields

***********************************************************************
* CONSTANTS                                                           *
***********************************************************************
CONSTANTS:

  gc_true              TYPE  boolean VALUE 'X',   "True
  gc_false             TYPE  boolean VALUE '-',   "False

* Screen 0100 Modes
  gc_main_processing   TYPE  char1   VALUE '1', "Main Processing mode
  gc_selection_screen  TYPE  char1   VALUE '2', "Selection Screen

* Screen 0200 Modes
  gc_list_selection    TYPE  char1   VALUE '1', "Selection List screen
  gc_list_confirmation TYPE  char1   VALUE '2', "List Confirmation scr
  gc_status            TYPE  char1   VALUE '3', "Status after Save

* Material group constants
  gc_skid              TYPE fieldname VALUE 'MATKL_SKID',
  gc_bales             TYPE fieldname VALUE 'MATKL_BALES',
  gc_carton            TYPE fieldname VALUE 'MATKL_CARTON'.

***********************************************************************
* TYPE DECLARATIONS                                                   *
***********************************************************************
TYPES:

* Booking header info
  BEGIN OF gts_book_hdr,
    bookdoc TYPE zsd_book_bookdoc,  "booking document number
  END OF gts_book_hdr,

* Sales Order Materials
  BEGIN OF gts_matnr,
    matnr TYPE matnr,  "material
  END OF gts_matnr.

*----------------------------------------------------------------------*
*       CLASS gcl_event_handler DEFINITION
*----------------------------------------------------------------------*
CLASS gcl_event_handler DEFINITION.

  PUBLIC SECTION.

    METHODS:

      handle_double_click FOR EVENT double_click OF cl_gui_alv_grid
        IMPORTING e_row
                    e_column
                    es_row_no.

ENDCLASS.
***********************************************************************
* DATA DECLARATIONS                                                   *
***********************************************************************
DATA:

  gv_0100_mode         TYPE char1,   "Screen 0100 mode
  gv_0200_mode         TYPE char1,   "Screen 0200 mode

* Flag to indicate whether Container HU was created successfully
  gv_container_created TYPE boolean,

* Field to capture sy-ucomm for screen processing
  ok_code              TYPE char20,

  gv_container_exidv   TYPE exidv, "container HU created external
  gv_container_venum   TYPE venum, "container HU created internal

  gv_vbeln             TYPE vbeln_va, "sales order assoc with container
  gv_booking_vbeln     TYPE vbeln_va. "booking doc sales order


DATA:

* ALV Grid field tables and structures
  gt_alv         TYPE STANDARD TABLE OF zdlu01267_alv_struct1,
  gs_alv         TYPE zdlu01267_alv_struct1,

  gt_alv_confirm TYPE STANDARD TABLE OF zdlu01267_alv_struct1,
  gt_alv_save    TYPE STANDARD TABLE OF zdlu01267_alv_struct1.


DATA:

*   Booking header info
  gt_book_hdr TYPE STANDARD TABLE OF gts_book_hdr,
  gs_book_hdr TYPE gts_book_hdr,

*   Sales Order Material info
  gt_matnr    TYPE STANDARD TABLE OF gts_matnr,
  gs_matnr    TYPE gts_matnr,

*   Table to hold syucomms to exclude from app toolbar
  gt_exclude  TYPE TABLE OF sy-ucomm.


*--> ALV Object Related Data
DATA:

  gs_layout          TYPE lvc_s_layo,  "Layout Structure
  gt_fieldcat        TYPE lvc_t_fcat,  "Field Catalog Table

*   For ALV Grid parameter IS_VARIANT to determine the layout to be used
  gv_is_variant      TYPE disvariant,

  go_grid            TYPE REF TO cl_gui_alv_grid,  "ALV Grid object
  go_custom_control  TYPE scrfname VALUE 'CC_ALV', "Screen 0200 control
  go_container       TYPE REF TO cl_gui_custom_container, "ALV Contner

  go_event_handler   TYPE REF TO gcl_event_handler,

*   Internal table of row indexes selected by user
  gt_index_rows      TYPE lvc_t_row,

*   Information about 1 row
  gs_selected_row    LIKE lvc_s_row,

*   Hide Buttons on the Standard Menu Control
  gt_exclude_toolbar TYPE ui_functions,
  gs_exclude_toolbar TYPE ui_func.


***********************************************************************
* RANGES
***********************************************************************
RANGES: gr_matnr FOR vbap-matnr.   "Material number on sales order

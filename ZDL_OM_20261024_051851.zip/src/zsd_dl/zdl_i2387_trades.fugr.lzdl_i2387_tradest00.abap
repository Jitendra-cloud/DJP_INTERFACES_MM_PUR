*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_TRADES......................................*
DATA:  BEGIN OF STATUS_ZDL_TRADES                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_TRADES                    .
CONTROLS: TCTRL_ZDL_TRADES
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZDL_TRADES_ARCH.................................*
DATA:  BEGIN OF STATUS_ZDL_TRADES_ARCH               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_TRADES_ARCH               .
CONTROLS: TCTRL_ZDL_TRADES_ARCH
            TYPE TABLEVIEW USING SCREEN '0011'.
*.........table declarations:.................................*
TABLES: *ZDL_TRADES                    .
TABLES: *ZDL_TRADES_ARCH               .
TABLES: ZDL_TRADES                     .
TABLES: ZDL_TRADES_ARCH                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

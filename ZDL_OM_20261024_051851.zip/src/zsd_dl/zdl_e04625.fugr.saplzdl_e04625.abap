*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E04625TOP.                    " Global Data
  INCLUDE LZDL_E04625UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E04625F...                    " Subprograms
* INCLUDE LZDL_E04625O...                    " PBO-Modules
* INCLUDE LZDL_E04625I...                    " PAI-Modules

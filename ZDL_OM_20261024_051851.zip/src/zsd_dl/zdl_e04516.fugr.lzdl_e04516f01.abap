*----------------------------------------------------------------------*
***INCLUDE LZDL_E04516F01 .
*----------------------------------------------------------------------*


***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2009 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
************************************************************************
**Include Name:      LZDL_E04516_F01              Create Date: 10/28/09
*
* Supports Function: ZDL_E04516_WEIGHT_DIMEN_CAL
*
**Programmer  : Mark Tomazin                      Last Update: 10/28/09
*
************************************************************************
*
*eject.
*
************************************************************************
*
**Change History:
*
**  Description:                         EDVK         User-Id  Date:
*
*     1) Created by Mark Tomazin         EDVK974096   MTOMAZ1  10/28/09
*
************************************************************************

*eject.

*&---------------------------------------------------------------------*
*&      Form  CK_4_MULT_SALES_ORDS_IN_BATCH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_MSKA_WITH_ORDER_INFO  text
*      -->P_GS_BATCH  text
*      <--P_GW_VALIDATION_FG  text
*----------------------------------------------------------------------*
FORM ck_4_mult_sales_ords_in_batch
                        TABLES    p_t_mska_with_order_info
                        STRUCTURE gs_mska_with_order_info
                        USING     p_gs_batch
                        STRUCTURE gs_batch
                        CHANGING  p_w_validation_fg.


  DATA: lt_mska_with_order_info
                 TYPE STANDARD TABLE OF ts_mska_with_order_info.

  DATA: lv_length_of_table_before TYPE i,
        lv_length_of_table_after  TYPE i.

*eject.

************************************************************************
* Initialization
************************************************************************
  CLEAR p_w_validation_fg.  "Set later on an error

  lt_mska_with_order_info[] = p_t_mska_with_order_info[].

  SORT lt_mska_with_order_info
    BY matnr
*      werks
*      lgort
       charg.

  DESCRIBE TABLE lt_mska_with_order_info
           LINES lv_length_of_table_before.

  DELETE ADJACENT DUPLICATES FROM lt_mska_with_order_info
         COMPARING matnr
                   charg.

  DESCRIBE TABLE lt_mska_with_order_info
         LINES lv_length_of_table_after.


  IF lv_length_of_table_before <> lv_length_of_table_after.

    p_w_validation_fg = 'F'.

  ENDIF.

ENDFORM.                    " CK_4_MULT_SALES_ORDS_IN_BATCH

*eject.

*&---------------------------------------------------------------------*
*&      Form  get_vc_characteristics
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_BATCH_CHAR  text
*      -->P_GS_BATCH  text
*----------------------------------------------------------------------*
FORM get_vc_characteristics
                  TABLES    p_t_vc_characteristics
                  STRUCTURE zsd_characteristic_value
                            p_t_mska_with_order_info
                  STRUCTURE gs_mska_with_order_info
                            lt_get_these_characteristics    " CHG135212
                  STRUCTURE zsd_characteristic_name         " CHG135212
                  USING     p_s_batch
                  STRUCTURE gs_batch
                  CHANGING  p_error_message
                            p_w_validation_fg.

*eject.

************************************************************************
* Data - Support Function: 'ZSD_GET_SINGLE_VALUES_OF_INST'
* Data - Configuration
************************************************************************

************************************************************************
* Internal Tables:
************************************************************************

  DATA: gt_values_from_config TYPE STANDARD TABLE OF ibvalue0.

  DATA: BEGIN OF gt_get_these_characteristics OCCURS 0.
          INCLUDE STRUCTURE zsd_characteristic_name.
  DATA: END   OF gt_get_these_characteristics.

  DATA: BEGIN OF gt_characteristic_values OCCURS 0.
          INCLUDE STRUCTURE zsd_characteristic_value.
  DATA: END   OF gt_characteristic_values.


************************************************************************
* General Data
************************************************************************

  DATA: lv_material_type TYPE mtart.

*   DATA: lv_cuobj         TYPE cuobj.  " CHG135212
*eject.

************************************************************************
* Initialization
************************************************************************
  CLEAR:   p_w_validation_fg,   "Set later on an error
           p_error_message.

*  CLEAR:   p_t_vc_characteristics.     " CHG135212
*  REFRESH: p_t_vc_characteristics.     " CHG135212

************************************************************************
* Load item fields to capture Configurable Material MTART Value
************************************************************************
  IF gr_configurable_material[] IS INITIAL. "If Range ' ', fill it

    get-value-range
         gc_zsdomfld_e04516_cat        " ('E04516_MTART')
         gc_zsdomfld_e04516_fieldname  " ('CONFIGURABLE_MATERIAL')
         gr_configurable_material.     "   RANGE TABLE

  ENDIF.


  IF gr_configurable_material[] IS INITIAL. "Error Condition

    p_w_validation_fg = 'F'.

    "No ZSDOMFLD Entries for Category: E04516_MTART Field Name:
    "CONFIGURABLE_MATERIAL
    MOVE text-016 TO  p_error_message.
    EXIT.

  ENDIF.

*eject.

***********************************************************************
** Get Material Type from MARA - Determine if we have a Configurable
* Matl
***********************************************************************
  SELECT SINGLE mtart FROM mara
         INTO   lv_material_type
         WHERE  matnr = p_s_batch-matnr.

* If we have a Configurable Material - go get the CUOBJ #
  IF lv_material_type IN gr_configurable_material.

* Commented for TPR # 05559.
* CUOBJ is passed to the input structure, so no need to determine same.
*    READ TABLE p_t_mska_with_order_info
*    WITH KEY       matnr = p_s_batch-matnr
*                   werks = p_s_batch-werks
**                  lgort = p_s_batch-lgort
*                   charg = p_s_batch-charg.
*
*    "Did we find a valid Order # in the MSKA
*    IF sy-subrc = 0.
*
*      "Pick up CUOBJ from VBAP
*      SELECT SINGLE cuobj FROM vbap
*             INTO   lv_cuobj
*             WHERE  vbeln = p_t_mska_with_order_info-vbeln
*             AND    posnr = p_t_mska_with_order_info-posnr.
*
*      "Order # NOT Found in MSKA - get it from MARC
*    ELSE.
*
*      "Pick up CUOBJ from MARC
*      SELECT SINGLE cuobj FROM marc
*             INTO   lv_cuobj
*             WHERE  matnr = p_s_batch-matnr
*             AND    werks = p_s_batch-werks.
*
*    ENDIF.
*
*  ELSE.
*
*    "Pick up CUOBJ from MARC
*    SELECT SINGLE cuobj FROM marc
*           INTO   lv_cuobj
*           WHERE  matnr = p_s_batch-matnr
*           AND    werks = p_s_batch-werks.
*
*  ENDIF.

*eject.

************************************************************************
* Check if we got a CUOBJ # - If NOT Set Error & Get Out
************************************************************************

*  IF lv_cuobj IS INITIAL.
*
*    p_w_validation_fg = 'F'.
*
*    "Cannot Obtain CUOBJ from VBAP or MARC Hence,
*    "NO VC Characteristics Found
*    MOVE text-017 TO  p_error_message.
*
*    EXIT.
*
*  ENDIF.

*eject.

* New additions for TPR # 05559 to process input CUOBJ.
* Volume is determined only when CUOBJ is passed to input structure.
    READ TABLE gt_batch_in INTO gs_batch_in WITH KEY matnr = p_s_batch-matnr
                                    charg = p_s_batch-charg.
    IF sy-subrc = 0 AND NOT gs_batch_in-cuobj IS INITIAL.
      IF gs_batch_in-cuobj NE gv_cuobj.                     " CHG135212
         CLEAR:   p_t_vc_characteristics.     " CHG135212
         REFRESH: p_t_vc_characteristics.     " CHG135212
           gv_cuobj = gs_batch_in-cuobj.
*-----------------------------------------------------------------------
* Call Wrapper Function to Get the Specific Characteristics necessary:
*-----------------------------------------------------------------------
        CALL FUNCTION 'ZSD_GET_SINGLE_VALUES_OF_INST'
          EXPORTING
            instance                       = gv_cuobj    "Object Key
            i_sort_on_name                 = 'X'
            i_extra_fields_option          = 'X' "Needed for Loop Below
            i_number_of_decimal_pts        = '5'
            i_ignore_exceptions            = 'X'
          IMPORTING
            et_values                      = gt_values_from_config
          TABLES
            t_get_specific_characteristics = lt_get_these_characteristics "CHG135212
            t_characteristic_values        = gt_characteristic_values
          EXCEPTIONS
            instance_not_found             = 1
            no_configuration_data_found    = 2
            characteristic_not_found       = 3
            OTHERS                         = 4.

************************************************************************
* Check if we got a good return from the Function,
* If NOT Set Error & Get Out
************************************************************************

        IF sy-subrc <> 0.

          p_w_validation_fg = 'F'.

          "Error Obtaining  VC Characteristics Values from
          "FM: ZSD_GET_SINGLE_VALUES_OF_INST
          MOVE text-015 TO  p_error_message.

          EXIT.

        ENDIF.

*eject.

************************************************************************
* Check if we got some Characteristics Data,
* If NOT Set Error & Get Out
************************************************************************

        IF gt_characteristic_values[] IS INITIAL.

          p_w_validation_fg = 'F'.

          "No VC Characteristics Returned from
          "FM: ZSD_GET_SINGLE_VALUES_OF_INST
          MOVE text-018 TO  p_error_message.

          EXIT.

        ENDIF.


*-----------------------------------------------------------------------
* Pass Back Characteristic Data
*-----------------------------------------------------------------------
        p_t_vc_characteristics[] = gt_characteristic_values[].
      ENDIF.                                                " CHG135212
    ENDIF.
  ENDIF.

ENDFORM.                    " get_vc_characteristics

*eject.

*&---------------------------------------------------------------------*
*&      Form  GET_MSKA_WITH_ORDER_INFO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_MSKA_WITH_ORDER_INFO  text
*      -->P_GT_BATCH  text
*----------------------------------------------------------------------*
FORM get_mska_with_order_info
                       TABLES    p_gt_mska_with_order_info
                       STRUCTURE gs_mska_with_order_info
                                 p_t_batch
                       STRUCTURE gs_batch.

*-----------------------------------------------------------------------
* NOT Used - Save for Reference
* NOT Used - Save for Reference
* NOT Used - Save for Reference
*-----------------------------------------------------------------------

  CLEAR:   p_gt_mska_with_order_info.
  REFRESH: p_gt_mska_with_order_info.

*eject.

* Getting batch data & Order Data from table MSKA based on material
* and batch number

  SELECT matnr werks lgort charg kalab
         vbeln
         posnr
    FROM mska
    INTO TABLE gt_mska_with_order_info
     FOR ALL ENTRIES IN p_t_batch
       WHERE matnr = p_t_batch-matnr
         AND charg = p_t_batch-charg.

*    delete gt_mska_with_Order_info WHERE kalab is initial.

  LOOP AT gt_mska_with_order_info INTO gs_mska_with_order_info.

    READ TABLE p_t_batch INTO gs_batch
         WITH KEY matnr = gs_mska_with_order_info-matnr
                  charg = gs_mska_with_order_info-charg.

    CHECK sy-subrc = 0.

    MOVE gs_batch-kalab TO gs_mska_with_order_info-kalab.
    MODIFY gt_mska_with_order_info FROM gs_mska_with_order_info.

  ENDLOOP.
  DELETE gt_mska_with_order_info WHERE kalab IS INITIAL.
ENDFORM.                    " GET_MSKA_WITH_ORDER_INFO

*End-of-Include

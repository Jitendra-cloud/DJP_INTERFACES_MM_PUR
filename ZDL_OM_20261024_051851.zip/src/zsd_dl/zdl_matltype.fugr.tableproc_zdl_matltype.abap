*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_MATLTYPE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_MATLTYPE        .

  PERFORM TABLEPROC.

ENDFUNCTION.

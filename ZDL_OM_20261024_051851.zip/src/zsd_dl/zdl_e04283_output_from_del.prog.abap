*&---------------------------------------------------------------------*
*& Report  ZDL_E04283_OUTPUT_FROM_DEL                                  *
*&                                                                     *
*&---------------------------------------------------------------------*
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2008  by                          **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                        20zz                                        **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*----------------------------------------------------------------------*
* Program Name: ZDL_E04283_OUTPUT_FROM_DEL            Date: 09/16/2008 *
*                                                                      *
* SAP Name    : ZDL_E04283_OUTPUT_FROM_DEL                             *
*                                                                      *
* Programmer  : Danny Mohamedy                                         *
* Transport No: E0VK943394                                             *
* Functional  : The custom transaction ZDL_E04283 will be used to run  *
*  Requirement: as a background job to process the output type ZWEB, or*
*             : any other output type setup as a variant in the batch  *
*             : job. The custom transaction will select the entries    *
*             : from NAST for the output type, example ZWEB, where the *
*             : output has not yet been processed, status "0", and the *
*             : deliveries are completely goods issued. Goods issue    *
*             : date from LIKP-WADAT_IST is not blank and VBUK-WBSTK = *
*             : "C". The deliveries selected will then be populated as *
*             : input for the default VL71 transaction and be executed *
*             : for the selected deliveries.                           *
*             :                                                        *
* Description : The intends and purposes of this facility is purely to *
*             : help retrieve Delivery Numbers based on the Message    *
*             : Type. Once ALL the non-PGIed deliveries are retrieved, *
*             : the program submits the SAP standard program for       *
*             : further processing.                                    *
*             : SAP Standard Program : 'SD70AV2A'                      *
*             :                                                        *
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Danny Mohamedy      09-15-2008        Initial version                *
*                                                                      *
* Change Reference : E04283 (Custom Transaction for Output from        *
*                  : Deliveries as batch job.
*----------------------------------------------------------------------*
*----------------------------------------------------------------------*
* Includes          : None                                             *
*                                                                      *
*----------------------------------------------------------------------*
* Logical Databases : None                                             *
*                                                                      *
*----------------------------------------------------------------------*
* External Calls    :                                                  *
*                                                                      *
*       Transactions     : None                                        *
*       Programs         : None                                        *
*                                                                      *
*----------------------------------------------------------------------*
* Size Limitations  :                                                  *
*       Max Number Recs  : No size limitations                         *
*                                                                      *
*----------------------------------------------------------------------*
************************************************************************

REPORT  ZDL_E04283_OUTPUT_FROM_DEL MESSAGE-ID zsd_dl.

Tables:
    Likp,  "SD Document: Delivery Header Data
    Nase,  "Parameter for Selecting Messages
    Nast,  "Message Status
    Vbuk.  "Sales Document: Header Status and Administrative Data

Data: Gt_Nast like Nast Occurs 0 with Header Line.

Data: Begin of Gt_Nast_Ex Occurs 0,
      Vbeln like Likp-vbeln,             "Delivery Number
      End of Gt_Nast_Ex.

Data: Begin of Gt_Likp_Ex Occurs 0,
      Vbeln like Likp-vbeln,             "Delivery Number
      End of Gt_Likp_Ex.

Constants:
      Gc_Kschl_Zweb  Like Nast-Kschl Value 'ZWEB', "
      Gc_Vstat_Zero  Like Nast-Vstat Value '0',    "Not Processed
      Gc_Wbstk_C     Like Vbuk-Wbstk Value 'C'.    "Completely Processed

Data: Gv_Objky       Like Nast-Objky.    "Object key


*Begin of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352
Data: Begin of Gt_vttp Occurs 0,
      tknum type TKNUM,
      Vbeln type VBELN_VL,
      End of Gt_vttp.

Data: Begin of Gt_vttk Occurs 0,
      tknum type TKNUM,
      frkrl type KFRKRL,
      FBGST type FBGST,
      End of Gt_vttk.

data: lv_Tabix like sy-tabix.

*End of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352

*=====================================================================
* A1. messages
SELECTION-SCREEN BEGIN OF BLOCK MESSAGE WITH FRAME TITLE TEXT-001.
SELECT-OPTIONS:
  RG_KSCHL FOR NASE-KSCHL MEMORY ID NAC,
  RG_NACHA FOR NASE-NACHA.
PARAMETERS:
  PM_NSORT LIKE NASE-SORV2 DEFAULT '01'  OBLIGATORY,
  PM_VERMO LIKE NASE-VERMO DEFAULT '1'   OBLIGATORY,
  PM_VERDI LIKE NASE-VERDI NO-DISPLAY.

SELECTION-SCREEN END OF BLOCK MESSAGE.
* A2. deliveries
SELECTION-SCREEN BEGIN OF BLOCK DELIVERY WITH FRAME TITLE TEXT-002.
SELECT-OPTIONS:
  RG_VSTEL FOR LIKP-VSTEL MEMORY ID VST,
  RG_VBELN FOR LIKP-VBELN MEMORY ID VL MATCHCODE OBJECT VMVL,
  RG_LIFEX FOR LIKP-LIFEX,
  RG_KUNNR FOR LIKP-KUNNR,
  RG_WADAT FOR LIKP-WADAT,
  RG_LFDAT FOR LIKP-LFDAT,
  RG_ROUTE FOR LIKP-ROUTE,
  RG_AULWE FOR LIKP-AULWE MODIF ID AUL.

*Begin of changes pragupa 09/12/2011 Change Order #126398 - USD #5972352
SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN COMMENT 1(31) text-004 .
parameters:   PM_FRKRL type KFRKRL.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN COMMENT 1(31) text-005 .
parameters:   pm_FBGST type FBGST.
SELECTION-SCREEN END OF LINE.
*End of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352

SELECTION-SCREEN END OF BLOCK DELIVERY.

* A3. printer profile and printer definition via RF-transaction.
SELECTION-SCREEN BEGIN OF BLOCK PROFILE WITH FRAME TITLE TEXT-003.
PARAMETERS: GF_DPROF LIKE LEDRUCKPROFIL-PROFILNAME MEMORY ID PPT.
PARAMETERS: GF_RFPRT LIKE LEDRUCKPROFIL-PADEST_NEW.
SELECTION-SCREEN END OF BLOCK PROFILE.

*=====================================================================
At Selection-Screen Output.

  Loop at screen.
    If Screen-Name eq 'RG_KSCHL-LOW' or
       Screen-Name eq 'RG_KSCHL-HIGH' or
       Screen-Name eq 'PM_FRKRL' or
       Screen-Name eq  'PM_FBGST'.
      screen-input = '1'.
    Else.
      screen-input = '0'.
    Endif.
    modify screen.
  endloop.


*=====================================================================
start-of-selection.
*Begin of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352
  if pm_FBGST is not initial.
    if pm_FBGST NE 'A' AND pm_FBGST NE  'B' AND pm_FBGST NE 'C' .
      Message S000 DISPLAY LIKE 'E' with 'Invalid Entry'.
      STOP.
    endif.
  endif.
*END of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352

  Select  * into table Gt_Nast
    From  Nast
    Where Kschl in Rg_Kschl      "Gc_Kschl_Zweb
    And   Vstat eq Gc_Vstat_Zero.

  if sy-subrc ne 0.
    Message i000 WITH 'No entries found with Msg type selected' .
    Stop.
  endif.

  Clear Gt_Nast_Ex.
  Loop at Gt_Nast.
    Gt_Nast_Ex-Vbeln = Gt_Nast-Objky.
    Append Gt_Nast_Ex.
  Endloop.

  Select  A~Vbeln into table Gt_Likp_Ex
    From  Likp as A inner join Vbuk as B
    on    A~Vbeln Eq B~Vbeln
    For   all entries in Gt_Nast_Ex
    Where A~Vbeln     eq Gt_Nast_Ex-Vbeln
    And   A~Wadat_Ist ne space
    And   B~WBSTK     eq Gc_Wbstk_C.

  if sy-subrc ne 0.
    Message i000 WITH 'No Deliveries found'.
    Stop.
  endif.

*Begin of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352
*This logic should be executed for Output Type ‘ZPFC’.
  if RG_KSCHL-low = 'ZPFC' or RG_KSCHL-high = 'ZPFC'.

*Based on deliveries get the shipments from table VTTP
    if Gt_Likp_Ex[] is not initial.
      select tknum vbeln
             from vttp
             into table gt_vttp
             for all entries in gt_likp_ex
             where vbeln = gt_likp_ex-vbeln.

*Get unique shipment/delivery
      sort gt_vttp by tknum vbeln.
      delete adjacent duplicates from gt_vttp comparing tknum vbeln.

*Get the relevant data from the shipment header table
      if gt_vttp[] is not initial.
        select tknum frkrl fbgst
               from vttk
               into table gt_vttk
               for all entries in gt_vttp
               where tknum = gt_vttp-tknum.

*Delete the shipments which does not match the selection criteria
        delete gt_vttk where frkrl ne PM_FRKRL or
                             fbgst ne pm_fbgst.

*Rebuild the deliveries table
        clear gt_likp_ex[].
        loop at gt_vttp.
          lv_tabix = sy-tabix.
          read table gt_vttk with key tknum = gt_vttp-tknum.
          if sy-subrc eq 0.
            gt_likp_ex-vbeln = gt_Vttp-vbeln.
            append gt_likp_ex.
          else.
            delete gt_vttp index lv_tabix.
          endif.
        endloop.

      endif.

    endif.

  endif.

  if gt_likp_ex[] is initial.
    Message i000 WITH 'No Deliveries found'.
    Stop.
  endif.

*End of changes pragupa 09/12/2011  Change Order #126398 - USD #5972352


  Clear RG_VBELN[].
  Rg_Vbeln-Sign   = 'I'.
  Rg_Vbeln-Option = 'EQ'.

  Loop at Gt_Likp_Ex.
    Gv_Objky            = Gt_Likp_Ex-Vbeln.
    Read table Gt_Nast
         with Key Objky = Gv_Objky.
    Rg_Vbeln-Low        = Gt_Likp_Ex-Vbeln.
    append Rg_Vbeln.
  Endloop.

  Submit SD70AV2A via selection-screen
                  With RG_KSCHL in RG_KSCHL
                  With RG_NACHA in RG_NACHA
                  With PM_NSORT eq PM_NSORT
                  With PM_VERMO eq PM_VERMO
                  With PM_VERDI eq PM_VERDI
                  With RG_VSTEL in RG_VSTEL
                  With Rg_Vbeln in Rg_Vbeln
                  With RG_LIFEX in RG_LIFEX
                  With RG_KUNNR in RG_KUNNR
                  With RG_WADAT in RG_WADAT
                  With RG_LFDAT in RG_LFDAT
                  With RG_ROUTE in RG_ROUTE
                  With RG_AULWE in RG_AULWE
                  With GF_DPROF eq GF_DPROF
                  With GF_RFPRT eq GF_RFPRT
         And Return.

end-of-selection.

*&---------------------------------------------------------------------*
*&  Include           ZDL_E04022_FLEX_TRIG                             *
*&---------------------------------------------------------------------*
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2008 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2008, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Badi Implementation Name : ZSD_DL_SHP_DELIVERY     Date: 01/16/2008  *
* Program Name: ZDL_E04022_FLEX_TRIG                                   *
*                                                                      *
* Programmer  : Padma Sunkara                                          *
*______________________________________________________________________*
* Description :                                                        *
*  This implementation is for V2-Custom trigger for STO based on       *
*  Delivery Creation and is implemented   in this BADI                 *
*                                                                      *
*  BADI:    LE_SHP_DELIVERY_PROC                                       *
*  METHOD:  SAVE_AND_PUBLISH_DOCUMENT                                  *
*____________________________________________________________________  *
* Change History:                                                      *
*                                                                      *
*                                                                      *
************************************************************************
* External Calls :   ZDL_E04010_FLEX_STO_TRIG_CHECK                    *
*                    ZDL_I02539_FLEX_STO_TRIGGER                       *
*______________________________________________________________________*
************************************************************************
* This Process will be triggered when delivery is Created for the      *
* intra-company stock transfer order from specific container plants, it*
* is necessary to "POKE" the STO interface so it updates Apriso. If the*
* delivery meets valid criteria(checked in ZDL_E04010_FLEX_STO_TRIG_   *
* _CHECK) then the program should call ZDL_I02539_FLEX_STO_TRIGGER,    *
* to trigger the IDoc to change the STO thereby sending an update      *
* to Apriso.                                                           *
*----------------------------------------------------------------------*


  types: begin of tt_ekbe,
            ebeln  type ekbe-ebeln,
            ebelp  type ekbe-ebelp,
            vgabe  type ekbe-vgabe,
            belnr  type ekbe-belnr,
            "buzei  type ekbe-buzei,
            trsta  type vbuk-trsta,
         end of tt_ekbe,
         begin of tt_vbfa,
           vbelv type vbfa-vbelv,
           vbeln type vbfa-vbeln,
         end of tt_vbfa,
         begin of tt_vttk,
           tknum type vttk-tknum,
           sdabw type vttk-sdabw,
         end of tt_vttk.
  data: gt_sto_result type table of ZDL_FPEDSTAT,
        gs_sto_result type ZDL_FPEDSTAT.
  data: gv_ebeln type  ebeln,
        gv_ebelp type  ebelp,
        gv_status type  flag,
        gs_xlikp          like line of it_xlikp,
        gt_xlips          type table of lipsvb,
        gs_xlips          type lipsvb,
        gs_xvbuk          like line of it_xvbuk,
        gs_zsp_value      type zsp_value,
        gs_zdl_fped_loc   type zdl_fped_loc,
        gt_ekbe           type table of  tt_ekbe,
        gs_ekbe           type tt_ekbe,
        gt_vbfa type table of tt_vbfa,
        gs_vbfa type tt_vbfa,
        gt_vttk type table of tt_vttk,
        gs_vttk type tt_vttk.


  constants: gc_prog_id type programm      value 'ZDL_E03167',
             gc_lfart   type zsp_fieldname value 'LFART%',
             gc_f       type zdl_fped_loc-z_flex_ind value 'F',
   	         gc_b        type zdl_fped_loc-z_flex_ind value 'B',
             gc_zdl(3) type c value 'FDL'. "Reference Delivery No.


  data: gv_vgabe type vgabe,
        gv_poke type c,
        gv_exception type char30.
  clear gv_vgabe.
* For every delivery that is being created do the following
  loop at it_xlikp into gs_xlikp where updkz = 'I'.
* Validate the delv.type in zsp_value whether delivery belongs to STO
    select single *
    from zsp_value
    into gs_zsp_value
    where pgrmid = gc_prog_id
    and   fieldname like gc_lfart
    and   fieldvalue = gs_xlikp-lfart.
    if sy-subrc <> 0.
      continue.
      "Not a valid Delivry type, do not poke, go to next delivery.
    endif.
    loop at it_xlips into gs_xlips where vbeln = gs_xlikp-vbeln.
      gv_poke = 'N'.
* Validate the Shipping Point
      select single *
      from zdl_fped_loc
      into gs_zdl_fped_loc
      where werks = gs_xlips-werks
      and   vstel = gs_xlikp-vstel
      and z_flex_ind in (gc_f, gc_b).
      if sy-subrc <> 0.
        continue.
      else.
*  Select all previous deliveries for STO line items
        refresh gt_ekbe.
        select a~ebeln a~ebelp a~vgabe a~belnr b~trsta
        into table gt_ekbe
        from ekbe as a
        inner join vbuk as b
        on a~belnr = b~vbeln
        where a~ebeln = gs_xlips-vgbel
        and   a~ebelp = gs_xlips-vgpos
        and   a~vgabe in ('8',gv_vgabe).
* For some reason the current delivery that is being created
* is also selected in the above select statement. We should not
* consider the current delivery being created, for the rest of
* the logic to work.
        delete gt_ekbe where belnr = gs_xlikp-vbeln.
*        describe table gt_ekbe lines sy-tabix.
        if gt_ekbe[] is initial.
* It is the first delivery for the STO, so PoKE the STO
*        if sy-tabix le 1.
          gv_poke = 'Y'.
        else.

          delete gt_ekbe where vgabe = gv_vgabe.
          if gt_ekbe[] is initial.
            continue.
          else.
            read table gt_ekbe into gs_ekbe with key trsta = 'A'.
            if sy-subrc = 0.
              "No poking necessary as one of the earler deliveries is
              " not transportation planned.
              continue.
            endif.
          endif.
*          delete gt_ekbe where trsta = 'A'.
          if gt_ekbe[] is initial.
            continue.
          else.
* select shipments of previous deliveries
            refresh gt_vbfa.
            select vbelv vbeln
                   into table gt_vbfa
                   from vbfa
                   for all entries in gt_ekbe
                   where vbelv = gt_ekbe-belnr
                   and vbtyp_n = '8'.
            if gt_vbfa[] is initial.
              gv_poke = 'Y'.  "This scenario will not arise
            else.
              refresh gt_vttk.
              select tknum sdabw into table gt_vttk
                     from vttk
                     for all entries in gt_vbfa
                     where tknum = gt_vbfa-vbeln
                     and   sdabw = 'FLEX'.
              if gt_vttk[] is initial.
                gv_poke = 'Y'.
              else.
                continue.
              endif.
            endif.
          endif.
        endif.
      endif.
      if gv_poke = 'Y'.
        gv_ebeln = gs_xlips-vgbel.
        gv_ebelp = gs_xlips-vgpos.
        clear: gv_status,gv_exception, gs_sto_result.
        refresh gt_sto_result.
        call function 'ZDL_E04010_FLEX_STO_TRIG_CHECK'
          exporting
            sto_header                       = gv_ebeln
            sto_item                         = gv_ebelp
            delv_docu                        = gs_xlikp-vbeln
            ref_type                         = gc_zdl
*            ref_docu                         = gs_vttk-tknum
         importing
           status                           = gv_status
           exception                        = gv_exception
         TABLES
           STO_RESULTS                      = gt_sto_result

                  .
        if gv_status is initial.
          continue.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
        else.
          read table gt_sto_result into gs_sto_result
               with key sto_header = gv_ebeln
                        sto_item   = gv_ebelp
                        DELV_DOCU  = gs_xlikp-vbeln.
          call function 'ZDL_I02539_FLEX_STO_TRIGGER'
            exporting
              iv_dlvry_doc         = gs_xlikp-vbeln
              iv_ref_type          = gc_zdl
              iv_sto_no            = gv_ebeln
              iv_sto_line          = gv_ebelp
              IV_FPED_CURR         = gs_sto_result-CURR_STATUS
              IV_FPED_PREV         = gs_sto_result-PREV_STATUS
*             IV_FPED_DATE        =
*             IV_FPED_TIME        =
*             IV_PROD_ORDER       =
*              iv_shpmnt           =
                    .
        endif.

      endif.
    endloop.  "on delivery item
  endloop.   "on delivery header

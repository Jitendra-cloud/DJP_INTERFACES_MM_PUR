*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_PROACTTOP.                    " Global Data
  INCLUDE LZDL_PROACTUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_PROACTF...                    " Subprograms
* INCLUDE LZDL_PROACTO...                    " PBO-Modules
* INCLUDE LZDL_PROACTI...                    " PAI-Modules

INCLUDE LZDL_PROACTF01.

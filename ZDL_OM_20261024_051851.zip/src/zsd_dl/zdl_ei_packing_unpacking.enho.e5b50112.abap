"Name: \PR:SAPLV51P\EX:HU_PACKING_AND_UNPACKING_11\EI
ENHANCEMENT 0 ZDL_EI_PACKING_UNPACKING.

* INV:U10061| CMS:28317| Changed By:AMAOLE1| Changed On:03/16/2015
  DATA ls_objects LIKE LINE OF gt_objects.
  DATA ls_xvekp TYPE VEKPVB.
  DATA lv_vbelv TYPE vbeln_von.
  DATA lv_auart TYPE auart.
  DATA lv_shtyp TYPE shtyp.
  DATA lv_flag1 TYPE char1.
  DATA lv_flag2 TYPE char1.
  DATA lv_flag3 TYPE char1.
  DATA lv_index TYPE sy-index.

* Check order type = ZKB
  CLEAR: lv_flag1, lv_flag2, lv_flag3.
  READ TABLE gt_objects INTO ls_objects WITH KEY object = '01'.
  IF sy-subrc EQ 0.

    SELECT SINGLE vbelv FROM vbfa INTO lv_vbelv
       WHERE vbeln = ls_objects-objkey AND
             posnn = '000010' AND
             vbtyp_n = 'J'.

    SELECT SINGLE auart FROM vbak INTO lv_auart
      WHERE vbeln = lv_vbelv AND
      auart = 'ZKB'.
    IF sy-subrc EQ 0.
      lv_flag1 = 'Y'.
    ENDIF.

  ENDIF.

* Check shipment type = ZEXP
  IF lv_flag1 EQ 'Y'.

    READ TABLE gt_objects INTO ls_objects WITH KEY object = '04'.
    IF sy-subrc EQ 0.

      SELECT SINGLE shtyp FROM vttk INTO lv_shtyp
        WHERE tknum = ls_objects-objkey AND
              shtyp = 'ZEXP'.
      IF sy-subrc EQ 0.
        lv_flag2 = 'Y'.
      ENDIF.

    ENDIF.
  ENDIF.

* Checking batch level HU has been unassigned
  IF lv_flag2 EQ 'Y'.

    READ TABLE gt_xvekp INTO ls_xvekp
     WITH KEY venum = is_packing_request-sub_hu_venum
              vpobj = '12'.

    lv_index = sy-tabix.

    IF sy-subrc EQ 0.

      ls_xvekp-vpobj = '01'.

      MODIFY gt_xvekp INDEX lv_index FROM ls_xvekp
       TRANSPORTING vpobj.

      lv_flag3 = 'Y'.
    ENDIF.

  ENDIF.

  IF lv_flag3 EQ 'Y'.
    RETURN.
  ENDIF.


ENDENHANCEMENT.

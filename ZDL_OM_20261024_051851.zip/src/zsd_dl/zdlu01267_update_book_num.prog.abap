*&--------------------------------------------------------------------*
*& Report  ZSDU01267_UPDATE_BOOK_NUM                              *
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**           COPYRIGHT (C) 2007 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                           **
**             REVISIONS COPYRIGHT (C) 2007, 20nn                    **
**                    by INTERNATIONAL PAPER                         **
*_____________________________________________________________________*
* Report Name: ZSDU01267_UPDATE_BOOK_NUM             Date: 05/04/2007 *
* Programmer : Lance Vialpando                                        *
*_____________________________________________________________________*
* Description :                                                       *
*   This program will allow the user to update the booking            *
*   booking confirmation number.                                      *
*_____________________________________________________________________*
* Change History:                                                     *
*   Programmer       Date     Req. #            Action                *
* ===============  ========  ========== ==============================*
* Lance Vialpando  05/04/07  EDEK907912 Initial creation              *
*                                                                     *
***********************************************************************

INCLUDE ZDLU01267BKNUMTOP.
*INCLUDE ZSDU01267BKNUMTOP.
*INCLUDE zsdu01267top.

INCLUDE ZDLU01267BKNUMO01.
*INCLUDE ZSDU01267BKNUMO01.
*INCLUDE ZSDU01267O01.

INCLUDE ZDLU01267BKNUMI01.
*INCLUDE ZSDU01267BKNUMI01.
*INCLUDE ZSDU01267I01.

INCLUDE ZDLU01267BKNUMF01.
*INCLUDE ZSDU01267BKNUMF01.
*INCLUDE ZSDU01267F01.

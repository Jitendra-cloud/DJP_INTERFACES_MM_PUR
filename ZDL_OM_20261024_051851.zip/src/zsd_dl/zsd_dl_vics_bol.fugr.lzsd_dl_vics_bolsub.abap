*&---------------------------------------------------------------------*
*&  Include           LZSD_DL_VICS_BOLSUB                              *
*&---------------------------------------------------------------------*
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2006                                    **
**                             by                                     **
**                    INTERNATIONAL PAPER                             **
************************************************************************
*______________________________________________________________________*
* Program Name: LZSD_DL_VICS_BOLSUB           Create Date: 11/14/2006  *
*                                                                      *
* SAP Name    : LZSD_DL_VICS_BOLSUB           Version    : Final       *
*                                                                      *
* Programmer  : Randall Wainwright              Last Update: 11/14/2006*
*______________________________________________________________________*
*
* Description: Subroutines for Function group:
*                ZSD_DL_VICS_BOL Retain VICS Bol Function and related
*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======      ========================   *
* Randall Wainwright  11/16/06  ESBK9A03JP  Initial                    *
*______________________________________________________________________*

*&---------------------------------------------------------------------*
*&      Form  query_kot2902
*&---------------------------------------------------------------------*
*       Attempt to retrieve conditional record via conditional
*   table KOT2902.
*----------------------------------------------------------------------*
*      -->LP_SHIPPOINT
*      -->LP_SHIPTO
*      -->LP_SHIPCOND
*      -->LP_ROUTE
*      <--LP_CONTRACT_NBR  Contract Number
*----------------------------------------------------------------------*
FORM query_kot2902  USING    lp_shippoint TYPE vstel
                             lp_shipto    TYPE kunwe
                             lp_ship_cond TYPE vsbed
                             lp_route     LIKE /saprgx/kond2p-route
                 CHANGING lp_contract_nbr TYPE /saprgx/contract_nbr.

* Condition Table
* Attempt to retrieve conditional record via conditional
*   table KOT2902.
  DATA: x_kot2902 LIKE kot2902,
        t_kot2902 LIKE kot2902 OCCURS 0.

  REFRESH t_kot2902.
  SELECT *
    FROM kot2902
    INTO TABLE t_kot2902
    WHERE vstel = lp_shippoint
      AND kunwe = lp_shipto
      AND vsbed = lp_ship_cond.
  CHECK sy-subrc = 0.
* Record must have an end date greater than or equal to today:
  SORT t_kot2902 BY datbi.
  DELETE t_kot2902 WHERE datbi < sy-datum.

* Record must have a begin date less than or equal to today:
  SORT t_kot2902 BY datab.
  DELETE t_kot2902 WHERE datab > sy-datum.

* Condition record number is required to proceed
  SORT t_kot2902 BY knumh.
  DELETE t_kot2902 WHERE knumh IS INITIAL.

  CHECK NOT t_kot2902[] IS INITIAL.

  CLEAR x_kot2902.
  READ TABLE t_kot2902 INTO x_kot2902 INDEX 1.

* Refer to the Routing Guide Condition Record Item for the
*  actual contract number
  PERFORM query_route_guide USING lp_route
                                  x_kot2902-knumh
                         CHANGING lp_contract_nbr.

ENDFORM.                    " query_kot2902

*&---------------------------------------------------------------------*
*&      Form  QUERY_ROUTE_GUIDE
*&---------------------------------------------------------------------*
* Refer to the Routing Guide Condition Record Item for the
*  actual contract number
*----------------------------------------------------------------------*
*      -->LP_ROUTE
*      -->LP_KNUMH
*      <--LP_CONTRACT_NBR  Contract Number
*----------------------------------------------------------------------*
FORM query_route_guide  USING    lp_route LIKE /saprgx/kond2p-route
                                 lp_knumh TYPE knumh
                 CHANGING lp_contract_nbr TYPE /saprgx/contract_nbr.

  DATA: lx_kond2  LIKE /saprgx/kond2,
        lx_kond2p LIKE /saprgx/kond2p,
        lt_kond2p LIKE /saprgx/kond2p OCCURS 0.

* First try the items level, using the ROUTE to determine the
*   correct conditional record
  SELECT *
    FROM /saprgx/kond2p
    INTO TABLE lt_kond2p
    WHERE knumh = lp_knumh
      AND route = lp_route.
  IF sy-subrc = 0.

* Take the first items record if for some reason there is more thatn
*   one
    SORT lt_kond2p BY contract_nbr.
    DELETE lt_kond2p WHERE contract_nbr IS INITIAL.
    READ TABLE lt_kond2p INTO lx_kond2p INDEX 1.

  ENDIF.

* If there's a contract number at the item level, use it
  IF NOT lx_kond2p-contract_nbr IS INITIAL.

    lp_contract_nbr = lx_kond2p-contract_nbr.

  ELSE.

* Otherwise, try to retrieve the contract number from the route guide
*   conditional header
    SELECT SINGLE *
      FROM /saprgx/kond2
      INTO lx_kond2
      WHERE knumh = lp_knumh.
    IF sy-subrc = 0.
      lp_contract_nbr = lx_kond2-contract_nbr.
    ENDIF.

  ENDIF.

ENDFORM.                    " QUERY_ROUTE_GUIDE

*&---------------------------------------------------------------------*
*&      Form  query_kot2909
*&---------------------------------------------------------------------*
*       Attempt to retrieve conditional record via conditional
*   table KOT2909.
*----------------------------------------------------------------------*
*      -->LP_SHIPPOINT
*      -->LP_SHIPTO
*      -->LP_ZIPCODE
*      -->LP_ROUTE
*      <--LP_CONTRACT_NBR  Contract Number
*----------------------------------------------------------------------*
FORM query_kot2909  USING    lp_shippoint TYPE vstel
                             lp_shipto    TYPE kunwe
                             lp_zipcode   TYPE /saprgx/cstvnd_zip5
                             lp_route     LIKE /saprgx/kond2p-route
                 CHANGING lp_contract_nbr TYPE /saprgx/contract_nbr.

* Condition Table
  DATA: x_kot2909 LIKE kot2909,
        t_kot2909 LIKE kot2909 OCCURS 0.

  REFRESH t_kot2909.
  SELECT *
    FROM kot2909
    INTO TABLE t_kot2909
    WHERE vstel       = lp_shippoint
      AND kunwe       = lp_shipto
      AND cstvnd_zip5 = lp_zipcode.
  CHECK sy-subrc = 0.
* Record must have an end date greater than or equal to today:
  SORT t_kot2909 BY datbi.
  DELETE t_kot2909 WHERE datbi < sy-datum.

* Record must have a begin date less than or equal to today:
  SORT t_kot2909 BY datab.
  DELETE t_kot2909 WHERE datab > sy-datum.

* Condition record number is required to proceed
  SORT t_kot2909 BY knumh.
  DELETE t_kot2909 WHERE knumh IS INITIAL.

  CHECK NOT t_kot2909[] IS INITIAL.

  CLEAR x_kot2909.
  READ TABLE t_kot2909 INTO x_kot2909 INDEX 1.

* Refer to the Routing Guide Condition Record Item for the
*  actual contract number
  PERFORM query_route_guide USING lp_route
                                  x_kot2909-knumh
                         CHANGING lp_contract_nbr.

ENDFORM.                    " query_kot2909

*&---------------------------------------------------------------------*
*&      Form  query_kot2907
*&---------------------------------------------------------------------*
*       Attempt to retrieve conditional record via conditional
*   table KOT2907.
*----------------------------------------------------------------------*
*      -->LP_SHIPPOINT
*      -->LP_SHIPTO
*      -->LP_ROUTE
*      <--LP_CONTRACT_NBR  Contract Number
*----------------------------------------------------------------------*
FORM query_kot2907  USING    lp_shippoint TYPE vstel
                             lp_shipto    TYPE kunwe
                             lp_route     LIKE /saprgx/kond2p-route
                 CHANGING lp_contract_nbr TYPE /saprgx/contract_nbr.

* Condition Table
  DATA: x_kot2907 LIKE kot2907,
        t_kot2907 LIKE kot2907 OCCURS 0.

  REFRESH t_kot2907.
  SELECT *
    FROM kot2907
    INTO TABLE t_kot2907
    WHERE vstel       = lp_shippoint
      AND kunwe       = lp_shipto.
  CHECK sy-subrc = 0.
* Record must have an end date greater than or equal to today:
  SORT t_kot2907 BY datbi.
  DELETE t_kot2907 WHERE datbi < sy-datum.

* Record must have a begin date less than or equal to today:
  SORT t_kot2907 BY datab.
  DELETE t_kot2907 WHERE datab > sy-datum.

* Condition record number is required to proceed
  SORT t_kot2907 BY knumh.
  DELETE t_kot2907 WHERE knumh IS INITIAL.

  CHECK NOT t_kot2907[] IS INITIAL.

  CLEAR x_kot2907.
  READ TABLE t_kot2907 INTO x_kot2907 INDEX 1.

* Refer to the Routing Guide Condition Record Item for the
*  actual contract number
  PERFORM query_route_guide USING lp_route
                                  x_kot2907-knumh
                         CHANGING lp_contract_nbr.

ENDFORM.                    " query_kot2907

*&---------------------------------------------------------------------*
*&      Form  query_kot2908
*&---------------------------------------------------------------------*
*       Attempt to retrieve conditional record via conditional
*   table KOT2908.
*----------------------------------------------------------------------*
*      -->LP_SHIPCOND
*      -->LP_ROUTE
*      <--LP_CONTRACT_NBR  Contract Number
*----------------------------------------------------------------------*
FORM query_kot2908  USING    lp_ship_cond TYPE vsbed
                             lp_route     LIKE /saprgx/kond2p-route
                 CHANGING lp_contract_nbr TYPE /saprgx/contract_nbr.

* Condition Table
  DATA: x_kot2908 LIKE kot2908,
        t_kot2908 LIKE kot2908 OCCURS 0.

  REFRESH t_kot2908.
  SELECT *
    FROM kot2908
    INTO TABLE t_kot2908
    WHERE vsbed       = lp_ship_cond.
  CHECK sy-subrc = 0.
* Record must have an end date greater than or equal to today:
  SORT t_kot2908 BY datbi.
  DELETE t_kot2908 WHERE datbi < sy-datum.

* Record must have a begin date less than or equal to today:
  SORT t_kot2908 BY datab.
  DELETE t_kot2908 WHERE datab > sy-datum.

* Condition record number is required to proceed
  SORT t_kot2908 BY knumh.
  DELETE t_kot2908 WHERE knumh IS INITIAL.

  CHECK NOT t_kot2908[] IS INITIAL.

  CLEAR x_kot2908.
  READ TABLE t_kot2908 INTO x_kot2908 INDEX 1.

* Refer to the Routing Guide Condition Record Item for the
*  actual contract number
  PERFORM query_route_guide USING lp_route
                                  x_kot2908-knumh
                         CHANGING lp_contract_nbr.

ENDFORM.                    " query_kot2908

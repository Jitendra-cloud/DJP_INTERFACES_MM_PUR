*"* use this source file for any type declarations (class
*"* definitions, interfaces or data types) you need for method
*"* implementation or private method's signature
*TYPES: zwmpp_typ_source_hu TYPE xxxxxx.
*TYPES: ZCA_BAL_S_MSG TYPE xxxxxx.

TYPES: BEGIN OF TYP_MAT_OBJ,
          MATNR TYPE MARA-MATNR,
          CUOBF TYPE MARA-CUOBF,
       END   OF TYP_MAT_OBJ.

TYPES: TT_MAT_OBJ TYPE STANDARD TABLE OF TYP_MAT_OBJ,
       TT_CONF    TYPE STANDARD TABLE OF CONF_OUT.

TYPES : BEGIN OF TYP_SHIP_DELIVERY,
                TKNUM TYPE TKNUM,
                TPNUM TYPE TPNUM,
                VBELN TYPE VBELN_VL,
                tplst type tplst,
             END   OF TYP_SHIP_DELIVERY.
  TYPES : BEGIN OF TYP_DELIVERY,
                VBELN TYPE VBELN_VL,
                POSNR TYPE POSNR_VL,
                LGNUM TYPE LGNUM,
             END   OF TYP_DELIVERY.

  TYPES: TT_SHIP_DELIVERY TYPE STANDARD TABLE OF TYP_SHIP_DELIVERY,
         TT_DELIVERY      TYPE STANDARD TABLE OF TYP_DELIVERY.

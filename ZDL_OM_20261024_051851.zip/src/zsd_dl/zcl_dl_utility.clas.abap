class ZCL_DL_UTILITY definition
  public
  final
  create public .

public section.

  methods CHECK_LOCK
    importing
      !IV_RETRY type ZSP_LOWVAL
      !IV_WAIT type ZSP_LOWVAL
      !IV_FIELD_VALUE type SEQG3-GARG optional
    returning
      value(RS_LOCK_DETAILS) type SEQG3 .
  methods CHECK_ROUTE_EXISTS
    importing
      !IS_RTG_COMM type /SAPRGX/RTG_COMM
      !IV_DOCTYPE type CHAR1
      !IV_LOG_LEVEL type /SAPRGX/PROTLEVEL
      !IS_LIKP type LIKP
      !IT_VBPA_TAB type TAB_VBPA
      !IT_LIPS_TAB type TAB_LIPS
    exporting
      !E_CONDITION_HEADER type /SAPRGX/KOND2
      !E_CONDITION_ITEM type /SAPRGX/KOND2P .
  class-methods READ_SHIPMENT_CONDITION_RECORD
    importing
      !IV_KAPPL type KAPPL
      !IV_KSCHL type NA_KSCHL
      !IS_SHIPMENTOUTPUT type KOMKBV7
    exporting
      !ES_NACH type NACH .
protected section.
private section.
ENDCLASS.



CLASS ZCL_DL_UTILITY IMPLEMENTATION.


  METHOD check_lock.
    DATA: lv_field_value TYPE seqg3-garg,
          lt_lock_detail TYPE pssct_seqg3.

    CHECK iv_field_value IS NOT INITIAL.
    CLEAR: rs_lock_details.

    lv_field_value = |{ sy-mandt }{ iv_field_value }|.
    DO iv_retry TIMES.
      CALL FUNCTION 'ENQUEUE_READ'
        EXPORTING
          guname                = space
          gname                 = space
          garg                  = lv_field_value
        TABLES
          enq                   = lt_lock_detail
        EXCEPTIONS
          communication_failure = 1
          system_failure        = 2
          OTHERS                = 3.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE /personas/cx_db_lock_error
          EXPORTING
            textid = /personas/cx_db_lock_error=>read_failed
            entity = /personas/cx_db_lock_error=>co_entity-flavor.
      ENDIF.
      IF lt_lock_detail IS NOT INITIAL.
        WAIT UP TO iv_wait SECONDS.
        DATA(lv_lock_error) = abap_true.
        CONTINUE.
      ELSE.
        CLEAR rs_lock_details.
        EXIT.
      ENDIF.
    ENDDO.
    IF lv_lock_error = abap_true.
      rs_lock_details = VALUE #( lt_lock_detail[ garg = |{ sy-mandt }{ iv_field_value }| ] OPTIONAL ).
    ENDIF.
  ENDMETHOD.


  METHOD check_route_exists.
    CLEAR: e_condition_header,
           e_condition_item.

    CALL FUNCTION '/SAPRGX/ROUTING_GUIDE'
      EXPORTING
        i_rtg_comm                 = is_rtg_comm
        i_doctype                  = iv_doctype
        i_likp                     = is_likp
        i_log_level                = iv_log_level
      IMPORTING
        e_condition_header         = e_condition_header
        e_condition_item           = e_condition_item
      TABLES
        i_vbpa_tab                 = it_vbpa_tab
        i_lips_tab                 = it_lips_tab
      EXCEPTIONS
        rtg_procedure_not_found    = 1
        condition_date_not_found   = 2
        condition_header_not_found = 3
        condition_item_not_found   = 4
        OTHERS                     = 5.
    IF sy-subrc <> 0.
      CLEAR: e_condition_header,
             e_condition_item.
    ENDIF.

  ENDMETHOD.


  METHOD read_shipment_condition_record.
* Data declaration for Dynamic WHERE Clause
    DATA: ls_where_clause  TYPE string.

* Data declaration for Dynamic structure
    DATA: lo_structure TYPE REF TO data.

* Initialize Expoting parameter
    CLEAR: es_nach.

* Get access sequence from the output type given.
    SELECT SINGLE kozgf
      FROM t685
      INTO @DATA(lv_access_sequence)
      WHERE kvewe = 'B' AND
            kappl = 'V7' AND
            kschl = @iv_kschl.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

* Get all the table name number maintained in the configuration
* for the Access Sequence.
    SELECT *
      FROM t682i
      INTO TABLE @DATA(lt_t682i)
      WHERE kappl = 'V7' AND
            kozgf = @lv_access_sequence.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

* Loop through each table number record
    LOOP AT lt_t682i INTO DATA(ls_t682i).

* Add Prefix B to the table name.
      DATA(lv_table_name) = |B{ ls_t682i-kotabnr }|.

* Create dynamic structure
      CREATE DATA lo_structure TYPE (lv_table_name).
      ASSIGN lo_structure->* TO FIELD-SYMBOL(<ls_structure>).

* Get all the fields name from the table.
      SELECT *
        FROM dd03l
        INTO TABLE @DATA(lt_table_fields)
        WHERE tabname = @lv_table_name.
      IF sy-subrc <> 0.
        CONTINUE.
      ENDIF.

* Delete below table fields as these fields are not required to consider for
* building dynamic where clause
      DELETE lt_table_fields WHERE keyflag <> abap_true OR
                                   fieldname = 'MANDT'  OR
                                   fieldname = 'KAPPL'  OR
                                   fieldname = 'KSCHL'.

* Build Dynamic where clause to get query the B tables.
      LOOP AT lt_table_fields INTO DATA(ls_table_fields).

* Get the key field name and its value
        ASSIGN COMPONENT ls_table_fields-fieldname
        OF STRUCTURE is_shipmentoutput
        TO FIELD-SYMBOL(<lv_value>).

        IF <lv_value> IS ASSIGNED.
* Build dynamic where clase
          ls_where_clause = COND #( WHEN sy-tabix = 1
                      THEN | { ls_table_fields-fieldname } = '{ <lv_value> }'|
                     ELSE | { ls_where_clause } AND { ls_table_fields-fieldname } = '{ <lv_value> }'| ).
        ENDIF.
      ENDLOOP.

* Read B tables table with the build dynamic where clause.
      IF ls_where_clause IS NOT INITIAL.
        SELECT SINGLE *
          FROM (lv_table_name)
          INTO @<ls_structure>
          WHERE kappl = @iv_kappl AND
                kschl = @iv_kschl AND
                (ls_where_clause).
        IF sy-subrc = 0.
          ASSIGN COMPONENT 'KNUMH'
              OF STRUCTURE <ls_structure>
              TO FIELD-SYMBOL(<lv_knumh>).
          IF <lv_knumh> IS ASSIGNED.
            SELECT SINGLE *
              FROM nach
              INTO @es_nach
              WHERE knumh = @<lv_knumh>.
            IF sy-subrc = 0.
              EXIT.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.

      UNASSIGN: <lv_knumh>,
                <ls_structure>.
      FREE: lo_structure.
      CLEAR: lv_table_name,
             ls_where_clause.

    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

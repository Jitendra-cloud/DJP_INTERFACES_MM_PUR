FUNCTION zdl_create_container.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_SIGNI) TYPE  SIGNI
*"     REFERENCE(IV_SEAL) TYPE  ZDL_SEAL_NO
*"     REFERENCE(IV_SIZE) TYPE  ZSD_BOOK_CON_SIZE
*"     REFERENCE(IV_BOOKNUM) TYPE  ZSD_BOOK_BOOKNUM
*"     REFERENCE(IV_BOOKDOC) TYPE  ZSD_BOOK_BOOKDOC OPTIONAL
*"     REFERENCE(IV_WERKS) TYPE  WERKS_D
*"     REFERENCE(IV_VBELN) TYPE  VBELN_VA
*"     REFERENCE(IV_TARE) TYPE  ZSD_CONT_TARE OPTIONAL
*"     REFERENCE(IV_VGM) TYPE  ZSD_VGM OPTIONAL
*"     REFERENCE(IV_UOM) TYPE  ZSD_UOM DEFAULT 'KG'
*"  EXPORTING
*"     VALUE(EV_CONTAINER_EXIDV) TYPE  EXIDV
*"     VALUE(EV_CONTAINER_VENUM) TYPE  VENUM
*"     REFERENCE(EV_BAPI_ERROR_MSG) TYPE  BAPI_MSG
*"  TABLES
*"      IT_HUS_TO_PACK TYPE  ZDL_EXIDV_TAB OPTIONAL
*"      ET_RETURN STRUCTURE  BAPIRET2
*"  EXCEPTIONS
*"      ERROR_RETRIEVING_UNIQUE_EXIDV
*"      ERROR_CALLING_UNIQUE_EXIDV
*"      NO_CONTAINER_PACKING_MATERIAL
*"      BAPI_HU_CREATE_FAILED
*"      BAPI_TRANSACTION_COMMIT_FAILED
*"      BAPI_HU_PACK_FAILED
*"      ERROR_INSERTING_ZDLU01267_VEKP
*"      ERROR_RETRIEVING_CONTAINER
*"      HANDLING_UNIT_LOCKED
*"      INVALID_HU_PASSED
*"      CONTAINERID_SEAL_ALREADY_EXIST
*"      INVALID_BOOKING_NUMBER
*"      INVALID_BOOKING_DOCUMENT
*"      INVALID_CON_SIZE
*"----------------------------------------------------------------------
*&--------------------------------------------------------------------*
*& Report  ZSDU01267_CREATE_CONTAINER_HU                              *
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**           COPYRIGHT (C) 2003 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                           **
**             REVISIONS COPYRIGHT (C) 2007, 20nn                    **
**                    by INTERNATIONAL PAPER                         **
*_____________________________________________________________________*
* Function Module: ZSDU01267_CREATE_CONTAINER_HU     Date: 06/04/2007 *
* Programmer :     Bruce Ballehr                                      *
*_____________________________________________________________________*
* Description :                                                       *
*   This function module creates a Container Handling Unit and        *
*   sub-HU's to it ("stuffs" HU's into the Container HU).             *
*_____________________________________________________________________*
* Change History:                                                     *
*   Programmer       Date     Req. #            Action                *
* ===============  ========  =========  ==============================*
* Bruce Ballehr    06/04/07  EDEK907765 Initial creation              *
* Maureen Carter   05/2015   CR#13267   add container size            *
* Maureen Carter   05/2016   PDP44945   SOLAS - container tare & VGM  *
* AMAOLE1| 10/25/2017| CMS31689  Add UOM to MARA selection(Madrid)    *
*                                                                     *
***********************************************************************

  TYPES:

    BEGIN OF lts_pack_hus,
      venum TYPE venum,      "internal HU
      exidv TYPE exidv,      "external HU
      brgew TYPE brgew_vekp, "weight of HU
      gewei TYPE gewei,      "Weight Unit
    END OF lts_pack_hus.

  DATA:

    lt_pack_hus   TYPE STANDARD TABLE OF lts_pack_hus,
    ls_pack_hus   TYPE lts_pack_hus,
    lt_pack_hus_2 TYPE STANDARD TABLE OF lts_pack_hus.

  DATA:

    lv_lines TYPE i,        "line count of a table
    lv_venum TYPE venum.    "hu

  DATA:

    lv_bookdoc  TYPE zsd_book_bookdoc, "booking document
    lv_matnr    TYPE matnr,    "work field for material
    lv_con_size TYPE zsd_book_con_size, "container size key value
    lv_subrc    TYPE sysubrc.

  DATA:

*   Work table for generating unique HU number
    lt_hu             TYPE STANDARD TABLE OF zdl_uniqueid,
    ls_hu             TYPE zdl_uniqueid,

*   Structure of our Z table
    ls_zdlu01267_vekp TYPE zdlu01267_vekp,

*   Header Data for Creating a Handling Unit
    ls_headerproposal TYPE bapihuhdrproposal,

*   Item data for HU Item Creation
    lt_itemsproposal  TYPE STANDARD TABLE OF bapihuitmproposal,
    ls_itemsproposal  TYPE bapihuitmproposal.


  CONSTANTS:

*   Attributes of a Packaging Material for a Container HU
    lc_verp       TYPE mtart  VALUE 'VERP',
    lc_cont       TYPE vhiart VALUE 'CONT',

*   HU Status
    lc_planned_hu TYPE  hu_st_init   VALUE 'A'.
  "Physical Status of the Handling Unit

* Clear export parms
  CLEAR: ev_bapi_error_msg,
         ev_container_exidv,
         ev_container_venum.

  CLEAR: gt_book_hdr[],
         gt_hus_to_pack[],
         gt_return[].

  gt_hus_to_pack[] = it_hus_to_pack[].


* Validate Container Id and Seal Number
  SELECT SINGLE venum INTO lv_venum FROM zdlu01267_vekp
    WHERE signi = iv_signi
      AND seal  = iv_seal.
  IF sy-subrc = 0.
    RAISE containerid_seal_already_exist.
  ENDIF.

* Validate Booking Number / Booking Document
  lv_bookdoc = iv_bookdoc.
  CLEAR: lv_subrc.
  PERFORM validate_booking USING iv_bookdoc  "booking document
                                 iv_booknum  "booking confirmation num
                                 iv_werks    "plant
                     CHANGING lv_bookdoc
                              lv_subrc.
  IF lv_subrc = 1.
    RAISE invalid_booking_document.
  ELSEIF lv_subrc = 2.
    RAISE invalid_booking_number.
  ENDIF.

* Validate Container Size
  SELECT SINGLE con_size FROM zsd_book_csz_cfg INTO lv_con_size
    WHERE con_size = iv_size.
  IF sy-subrc <> 0.
    RAISE invalid_con_size.
  ENDIF.

* Determine number of HUS to pack into Container
  DESCRIBE TABLE gt_hus_to_pack LINES lv_lines.

* Validate HU's if they were passed in to function
  IF lv_lines > 0.
*   Do some validation on the imported parms and gt_hus_to_pack.
*   We want to do this prior to creating a Container, etc...
*   Make sure HU's to be packed into Container HU are NOT locked
    SELECT venum
           exidv
           brgew
           gewei
      FROM vekp
      INTO TABLE lt_pack_hus
      FOR ALL ENTRIES IN gt_hus_to_pack
      WHERE exidv = gt_hus_to_pack-exidv.
    SORT lt_pack_hus BY exidv.

*   Make sure all HU's passed in a valid
    IF lv_lines = sy-dbcnt.

      LOOP AT lt_pack_hus INTO ls_pack_hus.
        CALL FUNCTION 'ENQUEUE_EVVEKPE'
          EXPORTING
            mandt          = sy-mandt
            venum          = ls_pack_hus-venum
          EXCEPTIONS
            foreign_lock   = 1
            system_failure = 2.
        IF sy-subrc NE 0.
*         Put the external Container HU into the message variable 1
          gs_return-message_v1 = ls_pack_hus-exidv.
          APPEND gs_return TO gt_return.

          RAISE handling_unit_locked.

        ELSE. "unlock the HU

          CALL FUNCTION 'DEQUEUE_EVVEKPE'
            EXPORTING
              mandt = sy-mandt
              venum = ls_pack_hus-venum.

        ENDIF.

      ENDLOOP.

    ELSE.

*     Determine which HU is invalid
      LOOP AT gt_hus_to_pack INTO gs_hus_to_pack.
        READ TABLE lt_pack_hus INTO ls_pack_hus
          WITH KEY exidv = gs_hus_to_pack-exidv
          BINARY SEARCH.
        IF sy-subrc NE 0.
*         Put the external Container HU into the message variable 1
          gs_return-message_v1 = gs_hus_to_pack-exidv.
          APPEND gs_return TO gt_return.
          RAISE invalid_hu_passed.
        ENDIF.
      ENDLOOP.

    ENDIF.  "compare num of HUs sent in with valid HUs

  ENDIF. "HUs passed in



* Generate a NEW HU number to be used as the Container HU number.
  CALL FUNCTION 'Z_DL_E03126_UNIT_ID_CHECK'
    EXPORTING
      iv_only_gen_unique_no  = 'X'
    TABLES
      it_batch               = lt_hu
    EXCEPTIONS
      number_range_not_found = 1
      OTHERS                 = 2.
  IF sy-subrc <> 0 OR lt_hu IS INITIAL.
*   Error retrieving unique HU number from function
*   Z_DL_E03126_UNIT_ID_CHECK
    RAISE error_calling_unique_exidv.
  ELSE.
    READ TABLE lt_hu INTO ls_hu INDEX 1.
    IF ls_hu-exidv IS INITIAL.
*     Function Z_DL_E03126_UNIT_ID_CHECK returned a blank Container
*     HU number
      RAISE error_retrieving_unique_exidv.
    ENDIF.
  ENDIF.

* Retrieve Packing Material for Container HU
  SELECT SINGLE matnr INTO lv_matnr
    FROM mara
    WHERE  mtart = lc_verp
      AND  gewei = ls_pack_hus-gewei                        "CMS31689
      AND  vhart = lc_cont.
  IF sy-subrc NE 0.
    RAISE no_container_packing_material.
  ENDIF.

* Prior to the Container HU being created, export the related Sales
* Order to memory so that the Output Determination user exit can
* retrieve the related Sales Order partner information and build that
* partner data into the user-exit enhanced communication structure.
  EXPORT iv_vbeln TO MEMORY ID 'ZCONTAINER'.

* Create the Container HU. Only the Header structure is populated - no
* need to populate the Item Proposal table parm
  CLEAR: ls_headerproposal.
  ls_headerproposal-hu_status_init = lc_planned_hu. "A = Planned HU
  ls_headerproposal-pack_mat       = lv_matnr.      "HU packing mat
  ls_headerproposal-hu_exid        = ls_hu-exidv.   "Container HU #
  ls_headerproposal-plant          = iv_werks.      "Plant

  CLEAR gt_return[]. "refresh error table
  CALL FUNCTION 'BAPI_HU_CREATE'
    EXPORTING
      headerproposal = ls_headerproposal  "Hdr data
    TABLES
      return         = gt_return.
  IF NOT gt_return[] IS INITIAL.

*   Retrieve error message if exists
    READ TABLE gt_return INTO gs_return INDEX 1.
    IF sy-subrc = 0.

*     Format the Bapi error message to present to the screen
      CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
        EXPORTING
          id         = gs_return-id "message id
          number     = gs_return-number "msg no
          language   = sy-langu
          textformat = 'ASC'            "ascii
          message_v1 = gs_return-message_v1
          message_v2 = gs_return-message_v2
          message_v3 = gs_return-message_v3
          message_v4 = gs_return-message_v4
        IMPORTING
          message    = ev_bapi_error_msg.

      RAISE bapi_hu_create_failed.
    ENDIF.
  ENDIF.

* Commit data to database
  CLEAR: gs_return.
  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
    EXPORTING
      wait   = 'X'      "wait for update
    IMPORTING
      return = gs_return.
  IF NOT gs_return IS INITIAL.
*   Format the Bapi error message to present to the screen
    CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
      EXPORTING
        id         = gs_return-id "message id
        number     = gs_return-number "msg no
        language   = sy-langu
        textformat = 'ASC'            "ascii
        message_v1 = gs_return-message_v1
        message_v2 = gs_return-message_v2
        message_v3 = gs_return-message_v3
        message_v4 = gs_return-message_v4
      IMPORTING
        message    = ev_bapi_error_msg.

*   Raise bapi failed
    RAISE bapi_transaction_commit_failed.

  ENDIF.

* Pack all selected sub-HU's into the Container HU
  LOOP AT gt_hus_to_pack INTO gs_hus_to_pack.
    CLEAR: gt_return[]. "refresh error table

    CLEAR: ls_itemsproposal.
    ls_itemsproposal-hu_item_type     = '3'. "type of HU
    ls_itemsproposal-lower_level_exid = gs_hus_to_pack-exidv. "sub-HUs
    "to pack

    CALL FUNCTION 'BAPI_HU_PACK'
      EXPORTING
        hukey        = ls_headerproposal-hu_exid  "container hu
        itemproposal = ls_itemsproposal  "HU item pck
      TABLES
        return       = gt_return. "error messages
    IF NOT gt_return[] IS INITIAL.

*       Retrieve error message
      READ TABLE gt_return INTO gs_return INDEX 1.
      IF sy-subrc = 0.

*         Format the Bapi error message to present to the screen
        CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
          EXPORTING
            id         = gs_return-id "message id
            number     = gs_return-number "msg no
            language   = sy-langu
            textformat = 'ASC'            "ascii
            message_v1 = gs_return-message_v1
            message_v2 = gs_return-message_v2
            message_v3 = gs_return-message_v3
            message_v4 = gs_return-message_v4
          IMPORTING
            message    = ev_bapi_error_msg.

        RAISE bapi_hu_pack_failed.
      ENDIF.
    ENDIF.

*     Commit data to database
    CLEAR: gs_return.
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait   = 'X'      "wait for update
      IMPORTING
        return = gs_return.
    IF NOT gs_return IS INITIAL.
*       Format the Bapi error message to present to the screen
      CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
        EXPORTING
          id         = gs_return-id "message id
          number     = gs_return-number "msg no
          language   = sy-langu
          textformat = 'ASC'            "ascii
          message_v1 = gs_return-message_v1
          message_v2 = gs_return-message_v2
          message_v3 = gs_return-message_v3
          message_v4 = gs_return-message_v4
        IMPORTING
          message    = ev_bapi_error_msg.

      RAISE bapi_transaction_commit_failed.

    ENDIF.

  ENDLOOP.


* Insert new record into our custom Container HU table
  CLEAR: ls_zdlu01267_vekp.

* Retrieve internal HU number for the Container HU just created
  SELECT SINGLE venum INTO ls_zdlu01267_vekp-venum FROM vekp
    WHERE exidv = ls_headerproposal-hu_exid
      AND erdat = sy-datum. "just in case dup ext hu nums exist
  IF sy-subrc NE 0.
*   Put the external Container HU into the message variable 1
    gs_return-message_v1 = ls_headerproposal-hu_exid.
    APPEND gs_return TO et_return.

    RAISE error_retrieving_container.
  ENDIF.

  ls_zdlu01267_vekp-signi  = iv_signi.     "container id
  ls_zdlu01267_vekp-seal  =  iv_seal.      "seal number
  ls_zdlu01267_vekp-bookdoc  = lv_bookdoc. "booking doc number
  ls_zdlu01267_vekp-booknum  = iv_booknum. "booking conf num
  ls_zdlu01267_vekp-aedat    = sy-datum.   "change date
  ls_zdlu01267_vekp-con_size = iv_size.    "container size

* 6/2016 SOLAS changes
  DATA: lv_brgew TYPE brgew.
  ls_zdlu01267_vekp-tare = iv_tare.
  ls_zdlu01267_vekp-uom  = iv_uom.

  "calculate container VGM (if IV_VGM was not passed into this function) by getting weight for each HU
  CLEAR lv_brgew.

  break macarte.

  IF iv_vgm IS NOT INITIAL.
    "use the VGM value in the parameter
    ls_zdlu01267_vekp-vgm = iv_vgm.

  ELSE.
    "calculate the VGM from VEKP data for the batches/HUs
    "are all the HUs in the same UOM?
    lt_pack_hus_2[] = lt_pack_hus[].
    SORT lt_pack_hus_2 BY gewei.
    DELETE ADJACENT DUPLICATES FROM lt_pack_hus_2 COMPARING gewei.
    DESCRIBE TABLE lt_pack_hus_2 LINES lv_lines.
    IF lv_lines > 1.

      "convert, then sum
      LOOP AT lt_pack_hus INTO ls_pack_hus.
        CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
          EXPORTING
            input    = ls_pack_hus-brgew
            unit_in  = ls_pack_hus-gewei
            unit_out = iv_uom
          IMPORTING
            output   = ls_pack_hus-brgew
          EXCEPTIONS
            OTHERS   = 1.
        IF sy-subrc = 0.
          lv_brgew = lv_brgew + ls_pack_hus-brgew.
        ENDIF.
      ENDLOOP.

    ELSE.

      "sum, then convert
      LOOP AT lt_pack_hus INTO ls_pack_hus.
        lv_brgew = lv_brgew + ls_pack_hus-brgew.
      ENDLOOP.
      "convert total weight to same UOM as the tare weight using the UOM on the last HU processed
      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
        EXPORTING
          input    = lv_brgew
          unit_in  = ls_pack_hus-gewei
          unit_out = iv_uom
        IMPORTING
          output   = lv_brgew
        EXCEPTIONS
          OTHERS   = 1.

    ENDIF.

    ls_zdlu01267_vekp-vgm = lv_brgew + iv_tare.

  ENDIF.


  INSERT zdlu01267_vekp FROM ls_zdlu01267_vekp.

  IF sy-subrc NE 0.
*   Put the internal Container HU into the message variable 1
    gs_return-message_v1 = ls_zdlu01267_vekp-venum.
    APPEND gs_return TO et_return.

    RAISE error_inserting_zdlu01267_vekp.
  ENDIF.

* Set Export Parameters
  ev_container_exidv = ls_hu-exidv.
  ev_container_venum = ls_zdlu01267_vekp-venum.

ENDFUNCTION.

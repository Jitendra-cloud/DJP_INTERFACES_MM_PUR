*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSD_DL_SHIP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSD_DL_SHIP         .

  PERFORM TABLEPROC.

ENDFUNCTION.

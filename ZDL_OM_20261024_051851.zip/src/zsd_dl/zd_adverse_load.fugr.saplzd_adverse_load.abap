*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZD_ADVERSE_LOADTOP.               " Global Declarations
  INCLUDE LZD_ADVERSE_LOADUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZD_ADVERSE_LOADF...               " Subroutines
* INCLUDE LZD_ADVERSE_LOADO...               " PBO-Modules
* INCLUDE LZD_ADVERSE_LOADI...               " PAI-Modules
* INCLUDE LZD_ADVERSE_LOADE...               " Events
* INCLUDE LZD_ADVERSE_LOADP...               " Local class implement.
* INCLUDE LZD_ADVERSE_LOADT99.               " ABAP Unit tests
  INCLUDE LZD_ADVERSE_LOADF00                     . " subprograms
  INCLUDE LZD_ADVERSE_LOADI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_U01249TOP.                    " Global Data
  INCLUDE LZDL_U01249UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_U01249F...                    " Subprograms
* INCLUDE LZDL_U01249O...                    " PBO-Modules
* INCLUDE LZDL_U01249I...                    " PAI-Modules

INCLUDE LZDL_U01249F01.

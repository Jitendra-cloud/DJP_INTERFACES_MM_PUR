class ZCL_F01276_TALLY_IDOC_READ definition
  public
  final
  create public .

*"* public components of class ZCL_F01276_TALLY_IDOC_READ
*"* do not include other source files here!!!
public section.

  methods CONSTRUCTOR .
  methods FORMAT_CHARACTERISTIC
    importing
      value(IV_ATWRT) type ATWRT
    returning
      value(ATWRT) type ATWRT .
  methods IDOC_DELVRY_SEGMENTS
    importing
      value(IV_VBELN) type VBELN
    returning
      value(SHIPMENT_RETURN) type ZDL_F01276_FLAT_DTL .
  methods GET_MORE_DETAILS
    importing
      value(IV_FLAT) type ZDL_F01276_FLAT_DTL
    returning
      value(FLAT_RETURN) type ZDL_F01276_FLAT_DTL .
  methods IDOC_SHPMNT_READ
    importing
      !IV_TKNUM type TKNUM
    returning
      value(SHIPMENT_RETURN) type ZDL_F01276_FLAT_DTL .
protected section.
*"* protected components of class ZCL_F01276_TALLY_IDOC_SHPMNT
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_F01276_TALLY_IDOC_READ
*"* do not include other source files here!!!

  constants GC_NACHA_A type NAST-NACHA value 'A' ##NO_TEXT.
  constants GC_NACHA_6 type NAST-NACHA value '6' ##NO_TEXT.
  constants GC_E1EDL20 type CHAR07 value 'E1EDL20' ##NO_TEXT.
  data GS_OBJECT type NAST .
  data GS_OBJECT_TYPE type WFAS1-ASGTP .
  data GS_CONTROL_RECORD_IN type EDIDC .
  data GS_CONTROL_RECORD_OUT type EDIDC .
  data GS_INT_EDIDD type EDIDD .
  constants GC_PALLETS_FLD type FIELDNAME value 'PSTYV_PALLETS' ##NO_TEXT.
  constants GC_PALLETS_CAT type ZCATGORY value 'F01276' ##NO_TEXT.
  data GS_ADNL_PAL_PSTYV type ZDL_FIELDS .
  constants GC_E1EDL24 type CHAR07 value 'E1EDL24' ##NO_TEXT.
  constants GC_E1EDL26 type CHAR07 value 'E1EDL26' ##NO_TEXT.
  constants GC_E1ADRM1 type CHAR07 value 'E1ADRM1' ##NO_TEXT.
  constants GC_Z1EDL19 type CHAR07 value 'Z1EDL19' ##NO_TEXT.
  constants GC_E1EDL15 type CHAR07 value 'E1EDL15' ##NO_TEXT.
  constants GC_E1EDL43 type CHAR07 value 'E1EDL43' ##NO_TEXT.
  constants GC_E1EDL41 type CHAR07 value 'E1EDL41' ##NO_TEXT.
  constants GC_E1EDL12 type CHAR07 value 'E1EDL12' ##NO_TEXT.
  constants GC_E1EDL44 type CHAR07 value 'E1EDL44' ##NO_TEXT.
  constants GC_E1EDL39 type CHAR07 value 'E1EDL39' ##NO_TEXT.
  constants GC_E1EDL37 type CHAR07 value 'E1EDL37' ##NO_TEXT.
  data GS_STR2_E1EDL20 type E1EDL20 .
  data GS_STR2_E1EDL43 type E1EDL43 .
  data GS_STR2_E1EDL15 type E1EDL15 .
  data GS_STR2_Z1EDL19 type Z1EDL19 .
  constants GC_E1TXTP9 type CHAR07 value 'E1TXTP9' ##NO_TEXT.
  constants GC_E1TXTH9 type CHAR07 value 'E1TXTH9' ##NO_TEXT.
  constants GC_E1EDL18 type E1EDL18 value 'E1EDL18' ##NO_TEXT.
  data GR_SYL_KUNAG type TDT_RG_KUNAG .

  methods BUILD_HU_EDIDD
    changing
      value(IT_EDIDD) type EDIDD_TT
      value(ET_HU_EDIDD) type EDIDD_TT .
  methods BUILD_Z1EDSTP_EDIDD
    changing
      !IT_EDIDD type EDIDD_TT
      !ET_Z1EDSTP_TAB type Z1EDSTP_TAB .
  methods GET_DIVISION_DESC
    importing
      value(IV_FLAT) type ZDL_F01276_FLAT_DTL
    returning
      value(FLAT_RETURN) type ZDL_F01276_FLAT_DTL .
  methods IDOC_MAPSEG_E1EDT20
    importing
      value(IS_E1EDT20) type E1EDT20
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_Z1EDSTZ
    importing
      value(IS_Z1EDSTZ) type Z1EDSTZ
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDT22
    importing
      value(IS_E1EDT22) type E1EDT22
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDT18
    importing
      value(IS_E1EDT18) type E1EDT18
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1ADRM4
    importing
      !IS_E1ADRM4 type E1ADRM4
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT
      value(EV_E1ADRM4_FLG) type CHAR1 .
  methods IDOC_MAPSEG_E1ADRE4
    importing
      !IS_E1ADRE4 type E1ADRE4
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods CLEAR_DELIVERY_HEAD
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT .
  methods CLEAR_DELIVERY_ITEM
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods CLEAR_HANDLING_UNIT
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL20
    importing
      !IS_E1EDL20 type E1EDL20
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1ADRM1
    importing
      value(IS_E1ADRM1) type E1ADRM1
      value(IT_Z1EDSTP) type Z1EDSTP_TAB
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL24
    importing
      !IS_E1EDL24 type E1EDL24
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_Z1EDL19
    importing
      !IS_Z1EDL19 type Z1EDL19
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL15
    importing
      !IS_E1EDL15 type E1EDL15
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL43
    importing
      !IS_E1EDL43 type E1EDL43
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL41
    importing
      !IS_E1EDL41 type E1EDL41
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL12
    importing
      !IS_E1EDL12 type E1EDL12
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_APPEND_BY_HU
    importing
      value(IT_HU_EDIDD) type EDIDD_TT
      value(IS_E1EDL20) type E1EDL20
      value(IS_E1EDL24) type E1EDL24
    changing
      value(ES_ZDL_F01276FLAT) type ZDL_F01276FLAT
      value(ET_ZDL_F01276FLAT) type ZDL_F01276_FLAT_DTL .
  methods IDOC_MAPSEG_E1EDL24_RL_PAL
    importing
      !IS_E1EDL24 type E1EDL24
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL26_RL_PAL
    importing
      !IS_E1EDL26 type E1EDL26
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1TXTP9
    importing
      !IS_E1TXTP9 type E1TXTP9
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1TXTH9
    importing
      !IS_E1TXTH9 type E1TXTH9
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
  methods IDOC_MAPSEG_E1EDL18
    importing
      !IS_E1EDL18 type E1EDL18
    changing
      !ES_ZDL_F01276FLAT type ZDL_F01276FLAT .
ENDCLASS.



CLASS ZCL_F01276_TALLY_IDOC_READ IMPLEMENTATION.


METHOD build_hu_edidd .

  CONSTANTS:
    lc_1                    TYPE e1edl44-velin VALUE '1',
    lc_zhl(3)               TYPE c             VALUE 'ZHL'.

  DATA: gs_e1edl37 TYPE e1edl37,
        gs_e1edl39 TYPE e1edl39,
        gs_e1edl44 TYPE e1edl44.

  FIELD-SYMBOLS: <it_edidd> TYPE edidd.

*--Pass data from segment 37,39 and 44 into gt_seg_37_39_44 table
  LOOP AT it_edidd ASSIGNING <it_edidd>.

*--Check the segment and map the data accordingly in flat table
    CASE <it_edidd>-segnam.
      WHEN Gc_e1edl37. " Without QUALF/ATNAM
        APPEND <it_edidd> TO et_hu_edidd.
        DELETE it_edidd.

* since PARAM does not exist in E1EDL37.
      WHEN Gc_e1edl39.
        MOVE <it_edidd>-sdata TO gs_e1edl39.
        IF gs_e1edl39-qualf = lc_zhl.
          APPEND <it_edidd> TO et_hu_edidd.
          DELETE it_edidd.
        ENDIF.

      WHEN Gc_e1edl44.                             "(VELIN = '1')
* Pass sdata to structure eledl44 to check if VELIN = '1'
        MOVE <it_edidd>-sdata TO  gs_e1edl44.
        IF gs_e1edl44-velin = lc_1.
          APPEND <it_edidd> TO et_hu_edidd.
          DELETE it_edidd.
        ENDIF.

    ENDCASE.
  ENDLOOP.

ENDMETHOD.


METHOD build_z1edstp_edidd .

  CONSTANTS:
      lc_z1edstp(7) TYPE c VALUE 'Z1EDSTP'.

  DATA: ls_str2_z1edstp TYPE z1edstp.

  FIELD-SYMBOLS: <it_edidd> TYPE edidd.

*--Pass data from segment 37,39 and 44 into gt_seg_37_39_44 table
  LOOP AT it_edidd ASSIGNING <it_edidd>.
*--Check the segment and map the data accordingly in flat table
    IF <it_edidd>-segnam = lc_z1edstp.
      MOVE <it_edidd>-sdata TO ls_str2_z1edstp.
      APPEND ls_str2_z1edstp TO et_z1edstp_tab.
      DELETE it_edidd.
    ENDIF.

  ENDLOOP.

ENDMETHOD.


METHOD clear_delivery_head .

* Delivery Level
  CLEAR:
  es_zdl_f01276flat-vbeln,

  es_zdl_f01276flat-tsnum,
  es_zdl_f01276flat-kunwe,
  es_zdl_f01276flat-name1_we,
  es_zdl_f01276flat-stras_we,
  es_zdl_f01276flat-ort01_we,
  es_zdl_f01276flat-regio_we,
  es_zdl_f01276flat-pstlz_we,
  es_zdl_f01276flat-land1_we,

  es_zdl_f01276flat-kunag,
  es_zdl_f01276flat-name1_ag,
  es_zdl_f01276flat-stras_ag,
  es_zdl_f01276flat-ort01_ag,
  es_zdl_f01276flat-regio_ag,
  es_zdl_f01276flat-pstlz_ag,
  es_zdl_f01276flat-land1_ag,

  es_zdl_f01276flat-name1_sf,
  es_zdl_f01276flat-street_sf,
  es_zdl_f01276flat-city1_sf,
  es_zdl_f01276flat-region_sf,
  es_zdl_f01276flat-post_code_sf,
  es_zdl_f01276flat-land1_sf,

  es_zdl_f01276flat-pernr_ae,
  es_zdl_f01276flat-pernr_sr.

ENDMETHOD.


method clear_delivery_item .

* Delivery Item Level
  clear:
  es_zdl_f01276flat-posnr,
  es_zdl_f01276flat-hipos,
  es_zdl_f01276flat-vemng,
  es_zdl_f01276flat-altme,
  es_zdl_f01276flat-idnkd,
  es_zdl_f01276flat-arktx,
  es_zdl_f01276flat-matwa,
  es_zdl_f01276flat-matnr,
  es_zdl_f01276flat-matkl,
  es_zdl_f01276flat-division,
  es_zdl_f01276flat-zzveslname,
  es_zdl_f01276flat-zzvoygnum,
  es_zdl_f01276flat-zzstmshpline,
  es_zdl_f01276flat-zzbooknum,
  es_zdl_f01276flat-set_position,
  es_zdl_f01276flat-pulp_scaled_weight_kg,
  es_zdl_f01276flat-pulp_scaled_weight_lb,
  es_zdl_f01276flat-rolls_in_package,
  es_zdl_f01276flat-lineal_footage_m,
  es_zdl_f01276flat-lineal_footage_ft,
  es_zdl_f01276flat-roll_weight_kg,
  es_zdl_f01276flat-roll_weight_lb,
  es_zdl_f01276flat-pulp_moisture,
  es_zdl_f01276flat-air_dry_percent,
  es_zdl_f01276flat-bales_per_batch,
  es_zdl_f01276flat-bales_per_unit,
  es_zdl_f01276flat-batch_weight,
  es_zdl_f01276flat-cartons_sheets,
  es_zdl_f01276flat-tare_weight,
  es_zdl_f01276flat-weight_of_skid_in_lbs,
  es_zdl_f01276flat-wgt_of_pallet_in_lbs_net,
  es_zdl_f01276flat-ream_weight,
  es_zdl_f01276flat-roll_diameter_in,
  es_zdl_f01276flat-roll_diameter_cm,
  es_zdl_f01276flat-roll_width_in_ext,
  es_zdl_f01276flat-roll_width_in,
  es_zdl_f01276flat-roll_width_cm,

  es_zdl_f01276flat-sales_order,
  es_zdl_f01276flat-sales_order_item,
  es_zdl_f01276flat-vgbel,
  es_zdl_f01276flat-vgpos_numc6,
  es_zdl_f01276flat-vgpos,
  es_zdl_f01276flat-sto,
  es_zdl_f01276flat-sto_item,
  es_zdl_f01276flat-bstnk,
  es_zdl_f01276flat-item_length_in,
*  es_zdl_f01276flat-item_length_cm,
  es_zdl_f01276flat-item_width_in,
  es_zdl_f01276flat-item_width_cm,
  es_zdl_f01276flat-ream_weight,
  es_zdl_f01276flat-customer_facing_nbr,
  es_zdl_f01276flat-sales_grade,
  es_zdl_f01276flat-sales_basis_weight,
  es_zdl_f01276flat-sales_surface,
  es_zdl_f01276flat-sales_color,
  es_zdl_f01276flat-sales_grade_description,
  es_zdl_f01276flat-caliper,
  es_zdl_f01276flat-label_format,
  es_zdl_f01276flat-unit_code,
  es_zdl_f01276flat-certification_ind.



endmethod.


METHOD clear_handling_unit .

* HU Level
  CLEAR:
  es_zdl_f01276flat-sum_package_wt,
  es_zdl_f01276flat-exidv,
  es_zdl_f01276flat-charg,
  es_zdl_f01276flat-vemng,
  es_zdl_f01276flat-vemeh.

ENDMETHOD.


  METHOD constructor.

    CLEAR gr_syl_kunag.

    SELECT 'I' AS sign,
           'EQ' AS optio,
           lowval AS low INTO TABLE @gr_syl_kunag FROM zsdomfld
    WHERE category EQ 'SYLVAMO'
      AND fieldname EQ 'KUNAG'.

  ENDMETHOD.


method format_characteristic .

  data:
   lv_cha_data    type conf_out-atwrt,
   lv_cha_garbage type conf_out-atwrt.

  check not iv_atwrt is initial.
  clear: lv_cha_data, lv_cha_garbage.

*--Skipping leading spaces, take the first string, separated by the
*  subsequent string with a space into a new field, throwing out
*  subsequent data. We are only concerned with the first.

  CONDENSE iv_atwrt.
  SPLIT iv_atwrt AT space INTO lv_cha_data lv_cha_garbage.
*
** Remove commas, if applicable
*  REPLACE ALL OCCURRENCES OF ',' IN lv_cha_data WITH ' '.
*  CONDENSE lv_cha_data NO-GAPS.


  call function '/GCDS04/OS_CONVERT_TEXT_TO_NUM'
    exporting
      i_formatted_text = lv_cha_data
    importing
      e_numeric_value  = atwrt.

*  atwrt = lv_cha_data.

endmethod.


METHOD get_division_desc .

  DATA: ls_flat TYPE zdl_f01276flat.

  DATA: lt_div_key TYPE zdl_f01276_flat_dtl.

* Organizational Unit: Sales Divisions: Texts
  DATA: ls_tspat TYPE tspat,
        lt_tspat TYPE STANDARD TABLE OF tspat.

  DATA: l_index TYPE i.

  lt_div_key[] = iv_flat[].

* Create a Unique List of Divisions
  SORT lt_div_key BY division.
  DELETE lt_div_key WHERE division IS INITIAL.
  DELETE ADJACENT DUPLICATES FROM lt_div_key COMPARING division.

  IF NOT lt_div_key[] IS INITIAL.

* Retrieve Division Descriptions for the current language
    SELECT *
      FROM tspat
      INTO TABLE lt_tspat
      FOR ALL ENTRIES IN lt_div_key
      WHERE spras = sy-langu
        AND spart = lt_div_key-division.
    IF sy-subrc <> 0.
* If the local language select fails, default to English
      SELECT *
        FROM tspat
        INTO TABLE lt_tspat
        FOR ALL ENTRIES IN lt_div_key
        WHERE spras = 'EN'
          AND spart = lt_div_key-division.
    ENDIF.

* If descriptions were found
    IF NOT lt_tspat[] IS INITIAL.

      CLEAR l_index.
      SORT iv_flat BY division.
      SORT lt_tspat BY spart.
      LOOP AT iv_flat INTO ls_flat.

        l_index = sy-tabix.

* Read the descriptions for each populated division and modify the flat table
        IF NOT ls_flat-division IS INITIAL.
          CLEAR ls_tspat.
          READ TABLE lt_tspat INTO ls_tspat WITH KEY
              spart = ls_flat-division.
          IF sy-subrc = 0.
            ls_flat-division_desc = ls_tspat-vtext.
            MODIFY iv_flat FROM ls_flat INDEX l_index.
          ENDIF.
        ENDIF.

      ENDLOOP. "AT iv_flat INTO ls_flat.

    ENDIF. " NOT lt_tspat[] IS INITIAL.

  ENDIF. "NOT lt_div_key[] IS INITIAL.

ENDMETHOD.


method GET_MORE_DETAILS .

* Retrieve and inject Devision Descriptions
CALL METHOD me->get_division_desc
  EXPORTING
    iv_flat     = iv_flat
  receiving
    flat_return = flat_return.


endmethod.


METHOD idoc_append_by_hu .

  CONSTANTS:
      lc_x          TYPE c VALUE 'X'.

  FIELD-SYMBOLS: <it_hu_edidd> TYPE edidd.

  DATA: gs_e1edl37 TYPE e1edl37,
        gs_e1edl39 TYPE e1edl39,
        gs_e1edl44 TYPE e1edl44.

  DATA: lv_found_hu_flg,
        lv_slength TYPE i,
        lv_dlength TYPE i,
        lv_offset TYPE i.
*--pass data from segment 37, 39, 44 into flat structure for every
*  respective segment 24
  CLEAR lv_found_hu_flg.
  LOOP AT it_hu_edidd ASSIGNING <it_hu_edidd>.

    CASE <it_hu_edidd>-segnam.
      WHEN Gc_e1edl37.
        gs_e1edl37 = <it_hu_edidd>-sdata.
        CLEAR gs_e1edl39.

      WHEN Gc_e1edl39.
        gs_e1edl39 = <it_hu_edidd>-sdata.

      WHEN Gc_e1edl44.
        gs_e1edl44 = <it_hu_edidd>-sdata .

*--Check delivery no of seg44 with seg 20 and line item of seg 44 with
*  line item of seg 24.
        IF gs_e1edl44-vbeln =  is_e1edl20-vbeln  AND
           gs_e1edl44-posnr =  is_e1edl24-posnr.

* Pass seg 37 data for field EXIDV to get higher level hu
* Note all 39 records not Qualf = ZHL have already been filtered out
          IF NOT gs_e1edl39-param IS INITIAL.
            es_zdl_f01276flat-exidv = gs_e1edl39-param.
            SHIFT es_zdl_f01276flat-exidv RIGHT DELETING TRAILING space."DM
          ELSE.
            SHIFT gs_e1edl37-exidv RIGHT DELETING TRAILING space.
            DESCRIBE FIELD gs_e1edl37-exidv
                     LENGTH lv_slength IN CHARACTER MODE.
            DESCRIBE FIELD es_zdl_f01276flat-exidv
                     LENGTH lv_dlength IN CHARACTER MODE.
            lv_offset = lv_slength - lv_dlength.
            es_zdl_f01276flat-exidv =
                     gs_e1edl37-exidv+lv_offset(lv_dlength).
          ENDIF.
          SHIFT es_zdl_f01276flat-exidv left deleting leading space.

          es_zdl_f01276flat-charg = gs_e1edl44-charg.
          es_zdl_f01276flat-vemng = gs_e1edl44-vemng.
          es_zdl_f01276flat-vemeh = gs_e1edl44-vemeh.

          APPEND es_zdl_f01276flat TO et_zdl_f01276flat.

          CALL METHOD me->clear_handling_unit
            CHANGING
              es_zdl_f01276flat = es_zdl_f01276flat.

          lv_found_hu_flg = lc_x.
        ENDIF.
    ENDCASE.
  ENDLOOP.

  IF lv_found_hu_flg IS INITIAL.
    IF NOT is_e1edl24-charg IS INITIAL
       OR  es_zdl_f01276flat-pstyv eq Gs_Adnl_pal_pstyv-lowval.
      es_zdl_f01276flat-charg = is_e1edl24-charg.
      APPEND es_zdl_f01276flat TO et_zdl_f01276flat.

      CALL METHOD me->clear_handling_unit
        CHANGING
          es_zdl_f01276flat = es_zdl_f01276flat.

    ENDIF.
    If es_zdl_f01276flat-pstyv eq Gs_Adnl_pal_pstyv-lowval.
       clear es_zdl_f01276flat-pstyv.
    Endif.
  ENDIF.

ENDMETHOD.


METHOD idoc_delvry_segments .
*----------------------------------------------------------------------*
* This method                                                          *
*                                                                      *
*----------------------------------------------------------------------*
* Inventory Code : F01276 - Packing List, Partial Pallets              *
*                  Delivery TALLY                                      *
*----------------------------------------------------------------------*
* Change History                                                       *
* ==============                                                       *
* Programmer              Date               Description               *
* ===================  ===========  ================================== *
* Danny Mohamedy       02/19/2009   Initial Version                    *
*                                                                      *
*-----------------------------------------------------------------------

  TYPE-POOLS:
    zsdc. "Batch Characteristics - Constants

  DATA:
    gt_int_edidd            TYPE STANDARD TABLE OF edidd,
    gt_hu_edidd             TYPE STANDARD TABLE OF edidd,
    gt_z1edstp              TYPE STANDARD TABLE OF z1edstp,
    gs_zdl_f01276flat       TYPE zdl_f01276flat,
    gt_zdl_f01276flat       TYPE STANDARD TABLE OF zdl_f01276flat,
    Gt_Adnl_pal_pstyv       Type Standard Table of Zdl_Fields.

* Segment data declaration
  DATA:
    gs_str2_e1adrm1         TYPE e1adrm1,
    gs_str2_e1edl24         TYPE e1edl24,
    gs_str2_e1edl26         TYPE e1edl26,
    gs_str2_e1edl41         TYPE e1edl41,
    gs_str2_e1edl12         TYPE e1edl12,
    gs_str2_e1edl18         TYPE e1edl18. " TPR 37758

  DATA :
    lv_tknum                TYPE vttp-tknum,
    lv_e1adrm4_flg          TYPE char1,
    lv_index20              TYPE i,
    lv_index24              TYPE i,
    lv_index26              TYPE i.

*Constant Declaration
  CONSTANTS :
    lc_idoctp               TYPE edidc-idoctp  VALUE 'DELVRY02',
    lc_idoccm               TYPE edidc-idoctp  VALUE 'ZDELVRY03'. "TPR 37758

* Populate data in GS_OBJECT
  gs_object-mandt  = sy-mandt.
  gs_object-objky  = iv_vbeln.
  gs_object-spras  = sy-langu.
  gs_object-nacha  = gc_nacha_6.

* Populate data in control structure
  gs_control_record_in-mandt   = sy-mandt.
  gs_control_record_in-idoctp  = lc_idoctp. "'DELVRY02'.
  gs_control_record_in-cimtyp  = lc_idoccm. "'DELVRY02'. "TPR 37758

*Clear the Structures/variable and refresh the table.
  CLEAR : gs_object_type, gs_control_record_out.
  REFRESH gt_int_edidd.

  CALL FUNCTION 'IDOC_OUTPUT_DELVRY'
    EXPORTING
      object                 = gs_object
      control_record_in      = gs_control_record_in
    IMPORTING
      object_type            = gs_object_type
      control_record_out     = gs_control_record_out
    TABLES
      int_edidd              = gt_int_edidd
    EXCEPTIONS
      error_message_received = 1
      OTHERS                 = 2.

  CHECK NOT gt_int_edidd[] IS INITIAL.


  Select * into table Gt_Adnl_pal_pstyv
    from Zdl_Fields
   Where category  eq GC_PALLETS_CAT
   and   Fieldname eq GC_PALLETS_FLD.
  If sy-subrc eq 0.
     read table Gt_Adnl_pal_pstyv into Gs_Adnl_pal_pstyv index 1.
  Else.
     Gs_Adnl_pal_pstyv-Lowval = 'XXXX'.
  Endif.

* Separate HU segments 37, 39 and 44
  CALL METHOD me->build_hu_edidd
    CHANGING
      it_edidd    = gt_int_edidd
      et_hu_edidd = gt_hu_edidd.

* Separate segment Z1EDSTP for Stages/Stops
  CALL METHOD me->build_z1edstp_edidd
    CHANGING
      it_edidd       = gt_int_edidd
      et_z1edstp_tab = gt_z1edstp.
  SORT gt_z1edstp BY kunnr tsnum DESCENDING.

  CHECK NOT gt_int_edidd[] IS INITIAL.

  lv_index20 = 0.
  lv_index24 = 0.

*--Pass the data from edidd table to flat structre for required
*  segements
  LOOP AT gt_int_edidd INTO gs_int_edidd.

* Check the segment and map the data accordingly in flat table
    CASE gs_int_edidd-segnam.

* Delivery header
      WHEN Gc_e1edl20.                       " Without QUALF/ATNAM

        lv_index24 = lv_index26 = 0.

        lv_index20 = lv_index20 + 1.
        IF lv_index20 <> 1.

          CALL METHOD me->idoc_append_by_hu
            EXPORTING
              it_hu_edidd       = gt_hu_edidd
              is_e1edl20        = gs_str2_e1edl20
              is_e1edl24        = gs_str2_e1edl24
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat
              et_zdl_f01276flat = gt_zdl_f01276flat.

          CALL METHOD me->clear_delivery_head
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.

          CALL METHOD me->clear_delivery_item
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.

        ENDIF.

* Delivery header
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl20.
        CALL METHOD me->idoc_mapseg_e1edl20
          EXPORTING
            is_e1edl20        = gs_str2_e1edl20
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

* Begin of change / TPR 37758
* In case of deleivery IDOC the metric indictor will be read from
* segment E1EDL18

     WHEN Gc_e1edl18.
       CLEAR gs_str2_e1edl18.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl18.
        CALL METHOD me->idoc_mapseg_e1edl18
          EXPORTING
            is_e1edl18        = gs_str2_e1edl18
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
* end of change / TPR 37758


* Central Address Segment Group, Main Segment
      WHEN Gc_e1adrm1.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1adrm1.
        CALL METHOD me->idoc_mapseg_e1adrm1
          EXPORTING
            is_e1adrm1        = gs_str2_e1adrm1
            it_z1edstp        = gt_z1edstp
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

* Delivery Item
      WHEN Gc_e1edl24.

        lv_index24 = lv_index24 + 1.
        If lv_index24 eq 1.
*--Exception to the Rule (for Rolls on Pallets) although Line Item detail,
*  but treated like a Header Information.
           MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl24.

           CALL METHOD me->idoc_mapseg_e1edl24_rl_pal
             EXPORTING
               is_e1edl24        = gs_str2_e1edl24
             CHANGING
               es_zdl_f01276flat = gs_zdl_f01276flat.

        Else." lv_index24 <> 1.

          CALL METHOD me->idoc_append_by_hu
            EXPORTING
              it_hu_edidd       = gt_hu_edidd
              is_e1edl20        = gs_str2_e1edl20
              is_e1edl24        = gs_str2_e1edl24
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat
              et_zdl_f01276flat = gt_zdl_f01276flat.

          CALL METHOD me->clear_delivery_item
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.

        ENDIF. " lv_index24 <> 1.

* Delivery Item
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl24.
        CALL METHOD me->idoc_mapseg_e1edl24
          EXPORTING
            is_e1edl24        = gs_str2_e1edl24
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

      WHEN Gc_e1edl26.
        lv_index26 = lv_index26 + 1.
        If lv_index26 eq 1.
           MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl26.

        CALL METHOD me->idoc_mapseg_e1edl26_rl_pal
          EXPORTING
            is_e1edl26        = gs_str2_e1edl26
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

        Endif.


* IDOC: Controlling (Delivery Item) (IP)
      WHEN Gc_z1edl19.
        MOVE  gs_int_edidd-sdata TO  gs_str2_z1edl19.
        CALL METHOD me->idoc_mapseg_z1edl19
          EXPORTING
            is_z1edl19        = gs_str2_z1edl19
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_z1edl19.

* IDOC: Batch Characteristic
      WHEN Gc_e1edl15.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl15.
        CALL METHOD me->idoc_mapseg_e1edl15
          EXPORTING
            is_e1edl15        = gs_str2_e1edl15
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl15.

* IDoc: Reference
      WHEN Gc_e1edl43.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl43.
        CALL METHOD me->idoc_mapseg_e1edl43
          EXPORTING
            is_e1edl43        = gs_str2_e1edl43
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl43.

* Reference data ordering party
      WHEN Gc_e1edl41.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl41.
        CALL METHOD me->idoc_mapseg_e1edl41
          EXPORTING
            is_e1edl41        = gs_str2_e1edl41
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl41.

* IDOC: Configuration
      WHEN Gc_e1edl12.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl12.
        CALL METHOD me->idoc_mapseg_e1edl12
          EXPORTING
            is_e1edl12        = gs_str2_e1edl12
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl12.

    ENDCASE.

  ENDLOOP.

  CALL METHOD me->idoc_append_by_hu
    EXPORTING
      it_hu_edidd       = gt_hu_edidd
      is_e1edl20        = gs_str2_e1edl20
      is_e1edl24        = gs_str2_e1edl24
    CHANGING
      es_zdl_f01276flat = gs_zdl_f01276flat
      et_zdl_f01276flat = gt_zdl_f01276flat.

  Read table gt_zdl_f01276flat
       into gs_zdl_f01276flat
       with key ADTNL_ITM_PSTYV = Gs_Adnl_pal_pstyv-lowval.
  If sy-subrc eq 0.
     Loop at gt_zdl_f01276flat into gs_zdl_f01276flat
          where ADTNL_ITM_PSTYV ne Gs_Adnl_pal_pstyv-lowval.
       gs_zdl_f01276flat-ADTNL_ITM_PSTYV =
       gs_zdl_f01276flat-pstyv = Gs_Adnl_pal_pstyv-lowval.
       modify gt_zdl_f01276flat from gs_zdl_f01276flat.
     Endloop.
  Endif.

  shipment_return[] = gt_zdl_f01276flat[].

ENDMETHOD.


METHOD idoc_mapseg_e1adre4 .

  CONSTANTS:
    lc_304 TYPE e1adre4-extend_q  VALUE '304',
    lc_sp  TYPE e1adre4-extend_q  VALUE 'SP'.

  IF ( is_e1adre4-extend_q = lc_304 OR
       is_e1adre4-extend_q = lc_sp ).
*Move data from Structure is_e1adre4 to GS_ZDL_F01276FLAT.
    es_zdl_f01276flat-scacd =  is_e1adre4-extend_d.
  ENDIF.

ENDMETHOD.


METHOD idoc_mapseg_e1adrm1 .

  DATA : lc_string(40) VALUE '1234567890'.

  CONSTANTS:
    lc_we  TYPE e1adrm1-partner_q VALUE 'WE',
    lc_ag  TYPE e1adrm1-partner_q VALUE 'AG',
    lc_zag TYPE e1adrm1-partner_q VALUE 'ZAG',
    lc_osp TYPE e1adrm1-partner_q VALUE 'OSP',
    lc_zs  TYPE e1adrm1-partner_q VALUE 'ZS',
    lc_zu  TYPE e1adrm1-partner_q VALUE 'ZU'.

  FIELD-SYMBOLS: <it_z1edstp> TYPE z1edstp.

**Move data from Structure is_e1adrm1 to es_zdl_f01276flat.
*Ship-to name and address (QUALF/PARTNER_Q ==> WE)
  CASE is_e1adrm1-partner_q.

    WHEN lc_we.
* Read the Shipment Stage from the STP segment via the Ship-To on
*   the delivery
      UNASSIGN <it_z1edstp>.
      READ TABLE it_z1edstp ASSIGNING <it_z1edstp> WITH KEY
          kunnr = is_e1adrm1-partner_id.
      IF sy-subrc = 0.
        es_zdl_f01276flat-tsnum = <it_z1edstp>-tsnum.
      ENDIF.

      es_zdl_f01276flat-kunwe      = is_e1adrm1-partner_id.
      es_zdl_f01276flat-name1_we   = is_e1adrm1-name1.
      es_zdl_f01276flat-stras_we   = is_e1adrm1-street1.
      es_zdl_f01276flat-ort01_we   = is_e1adrm1-city1.
      es_zdl_f01276flat-regio_we   = is_e1adrm1-region.
      es_zdl_f01276flat-pstlz_we   = is_e1adrm1-postl_cod1.
      es_zdl_f01276flat-land1_we   = is_e1adrm1-country1.

*Sold-to name and address   (QUALF/PARTNER_Q ==> AG)
    WHEN lc_ag OR lc_zag.
      es_zdl_f01276flat-kunag     = is_e1adrm1-partner_id.
      es_zdl_f01276flat-name1_ag  = is_e1adrm1-name1.
      es_zdl_f01276flat-stras_ag  = is_e1adrm1-street1.
      es_zdl_f01276flat-ort01_ag  = is_e1adrm1-city1.
      es_zdl_f01276flat-regio_ag  = is_e1adrm1-region.
      es_zdl_f01276flat-pstlz_ag  = is_e1adrm1-postl_cod1.
* LAND1_AG field is not available in ZDL_F01276FLAT.
      es_zdl_f01276flat-land1_ag  = is_e1adrm1-country1.

*->CD2000015197:Sylvamo Swirl Branding / Check for Sylvamo Sold to
      IF es_zdl_f01276flat-kunag IS NOT INITIAL AND gr_syl_kunag IS NOT INITIAL AND
         es_zdl_f01276flat-kunag IN gr_syl_kunag.
        es_zdl_f01276flat-syl_ind = abap_true.
      ENDIF.
*-<CD2000015197:Sylvamo Swirl Branding
*Origin Shipping Point  (QUALF/PARTNER_Q ==> OSP)
    WHEN lc_osp.
      es_zdl_f01276flat-name1_sf     = is_e1adrm1-name1.

      IF is_e1adrm1-street1+0(4) CA lc_string.
        es_zdl_f01276flat-street_sf    = is_e1adrm1-street1.
      ELSE.
        CONCATENATE: is_e1adrm1-house_supl is_e1adrm1-street1
               INTO  es_zdl_f01276flat-street_sf
               SEPARATED BY space.  "DMABAP
      ENDIF.
*          es_zdl_f01276flat-street_sf    = is_e1adrm1-street1.   DMABAP
      es_zdl_f01276flat-city1_sf     = is_e1adrm1-city1.
      es_zdl_f01276flat-region_sf    = is_e1adrm1-region.
      es_zdl_f01276flat-post_code_sf = is_e1adrm1-postl_cod1.
      es_zdl_f01276flat-land1_sf     = is_e1adrm1-country1.

*Account Exec  (QUALF/PARTNER_Q==>ZS)
    WHEN lc_zs.
      es_zdl_f01276flat-pernr_ae = is_e1adrm1-partner_id.

*Sales Rep (QUALF/PARTNER_Q ==>ZU)
    WHEN lc_zu.
      es_zdl_f01276flat-pernr_sr = is_e1adrm1-partner_id.

  ENDCASE.

ENDMETHOD.


METHOD idoc_mapseg_e1adrm4 .

  CONSTANTS:
      lc_sp TYPE e1adrm4-partner_q VALUE 'SP'.

  CLEAR ev_e1adrm4_flg.

*--Move data from Structure is_e1adrm4 to es_zdl_f01276flat.
  IF is_e1adrm4-partner_q = lc_sp.
    es_zdl_f01276flat-name1 =  is_e1adrm4-name1.
*--Need to pass it to check condition IN E1adre4 SEGMENT
    ev_e1adrm4_flg = 'X'.
  ENDIF.

ENDMETHOD.


METHOD idoc_mapseg_e1edl12 .

  DATA: lv_atwrt TYPE atwrt.


*Move data from Structure is_e1edl12 to es_zdl_f01276flat..
*Material Diameter Inches
  CASE is_e1edl12-atnam.

*Material Length inches
    WHEN zsdc_item_length.
      es_zdl_f01276flat-item_length_in = is_e1edl12-atwrt.
*Material Length centimeters
    WHEN zsdc_item_length_metric.
      es_zdl_f01276flat-item_length_cm = is_e1edl12-atwrt.
*avelayu starts
    WHEN zsdc_item_length_whole.
      es_zdl_f01276flat-item_length_whole = is_e1edl12-atwrt.
    WHEN zsdc_item_length_numerator.
      es_zdl_f01276flat-item_length_num = is_e1edl12-atwrt.
    WHEN zsdc_item_length_denominator.
      es_zdl_f01276flat-item_length_den = is_e1edl12-atwrt.
*avelayu ends

*Material Width inches
    WHEN zsdc_item_width.
      es_zdl_f01276flat-item_width_in = is_e1edl12-atwrt.
*** Change on 8/23 by CRAMEY - make all widths ordered width
      es_zdl_f01276flat-roll_width_in = is_e1edl12-atwrt.

    WHEN zsdc_roll_width.
      es_zdl_f01276flat-item_width_in = is_e1edl12-atwrt.
      es_zdl_f01276flat-roll_width_in = is_e1edl12-atwrt.



*Material Width centimeters
    WHEN zsdc_item_width_metric .
      es_zdl_f01276flat-item_width_cm = is_e1edl12-atwrt.
*avelayu starts
    WHEN zsdc_item_width_whole.
      es_zdl_f01276flat-item_width_whole = is_e1edl12-atwrt.
    WHEN zsdc_item_width_numerator.
      es_zdl_f01276flat-item_width_num = is_e1edl12-atwrt.
    WHEN zsdc_item_width_denominator.
      es_zdl_f01276flat-item_width_den = is_e1edl12-atwrt.

    WHEN zsdc_roll_width_whole.
      es_zdl_f01276flat-roll_width_whole = is_e1edl12-atwrt.
    WHEN zsdc_roll_width_num.
      es_zdl_f01276flat-roll_width_num = is_e1edl12-atwrt.
    WHEN zsdc_roll_width_den.
      es_zdl_f01276flat-roll_width_den = is_e1edl12-atwrt.
*avelayu ends



*Material RM weight LB
    WHEN zsdc_sheet_m_weight.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = is_e1edl12-atwrt
        RECEIVING
          atwrt    = lv_atwrt.
      es_zdl_f01276flat-ream_weight = lv_atwrt / 2.
*Customer Facing Number
    WHEN zsdc_customer_facing_nbr.
      es_zdl_f01276flat-customer_facing_nbr =
         is_e1edl12-atwrt.
*Material Grade
    WHEN zsdc_sales_grade.
      es_zdl_f01276flat-sales_grade = is_e1edl12-atwrt.
*Material Basis Weight
    WHEN zsdc_sales_basis_weight.
      es_zdl_f01276flat-sales_basis_weight =
         is_e1edl12-atwrt.
*Metric Basis Weight
    WHEN zsdc_metric_sales_basis_weight.
      es_zdl_f01276flat-metric_sales_basis_weight =
         is_e1edl12-atwrt.

     WHEN zsdc_metric_pulp_basis_weight.             "CD2000013740
      es_zdl_f01276flat-metric_pulp_basis_weight =   "CD2000013740
         is_e1edl12-atwrt.                           "CD2000013740

*Material Surface
    WHEN zsdc_sales_surface.
      es_zdl_f01276flat-sales_surface = is_e1edl12-atwrt.
*Material Color
    WHEN zsdc_sales_color.
      es_zdl_f01276flat-sales_color = is_e1edl12-atwrt.
*Material Grade Description
    WHEN zsdc_wp_kundenbezeichnung.
      es_zdl_f01276flat-sales_grade_description =
            is_e1edl12-atwrt.
*Material Caliper
    WHEN zsdc_caliper. " Char to decimal.
      CLEAR lv_atwrt.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = is_e1edl12-atwrt
        RECEIVING
          atwrt    = lv_atwrt.
      es_zdl_f01276flat-caliper = lv_atwrt.
*Label Format
    WHEN zsdc_label_format.
      es_zdl_f01276flat-label_format = is_e1edl12-atwrt.
* Unit Code
    WHEN zsdc_unit_code.
      es_zdl_f01276flat-unit_code = is_e1edl12-atwrt.
* begin of change / nparchu
* certification indicator
    WHEN zsdc_certification_ind.
      es_zdl_f01276flat-certification_ind = is_e1edl12-atwrt.
* end of change / nparchu

* avelayu starts
* stock indicator
    WHEN zsdc_stock_indicator.
      es_zdl_f01276flat-stock_indicator = is_e1edl12-atwrt.
* ordered diamter
    WHEN zsdc_ordered_diameter.
      es_zdl_f01276flat-ordered_diameter_in = is_e1edl12-atwrt.
* ordered diamter metric
    WHEN zsdc_ordered_diameter_metric.
      es_zdl_f01276flat-ordered_diameter_cm = is_e1edl12-atwrt.

* avelayu ends
* Begin of change / nparchu
* per TPR 05927 roll_width_cm to be read from material
* characteristics
    WHEN zsdc_roll_width_metric.
      es_zdl_f01276flat-roll_width_in_ext =
          is_e1edl12-atwtb.

      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = is_e1edl12-atwrt
        RECEIVING
          atwrt    = lv_atwrt.

      es_zdl_f01276flat-roll_width_cm = lv_atwrt.
*End of change / nparchu

* Begin of change / nparchu / TPR 38391
    WHEN zsdc_roll_diameter.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = is_e1edl12-atwrt
        RECEIVING
          atwrt    = lv_atwrt.

      es_zdl_f01276flat-roll_diameter_in = lv_atwrt.

**Material Diameter Metric
    WHEN zsdc_roll_diameter_metric.
      es_zdl_f01276flat-roll_diameter_cm = is_e1edl12-atwrt.

* Begin of change / JWILL68 / CMS 33750
* ROLL_DIAMETER_M
    WHEN zsdc_roll_diameter_m."'ROLL_DIAMETER_M'.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = is_e1edl12-atwrt
        RECEIVING
          atwrt    = lv_atwrt.

      es_zdl_f01276flat-roll_diameter_cm = lv_atwrt.
      es_zdl_f01276flat-roll_diameter_in = is_e1edl12-atwtb.

* ROLL_WIDTH_M
    WHEN zsdc_roll_width_m.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = is_e1edl12-atwrt
        RECEIVING
          atwrt    = lv_atwrt.
      es_zdl_f01276flat-roll_width_cm = lv_atwrt.
      es_zdl_f01276flat-roll_width_in = is_e1edl12-atwtb.
* End of change / JWILL68 / CMS 33750
  ENDCASE.
* End of change / nparchu / TPR 38391

ENDMETHOD.


METHOD idoc_mapseg_e1edl15 .

  DATA: ls_e1edl15 TYPE e1edl15.

  ls_e1edl15 = is_e1edl15.

  CASE ls_e1edl15-atnam.
*Move data from Structure lS_E1EDL15 to es_zdl_f01276flat Set.
    WHEN zsdc_set_position.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-set_position = ls_e1edl15-atwrt.
**Scaled weight KG
*    WHEN zsdc_scaled_weight_kg.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-pulp_scaled_weight_kg =
*          ls_e1edl15-atwrt.
**Scaled weight LB
*    WHEN zsdc_scaled_weight_lbs .
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-pulp_scaled_weight_lbs =
*          ls_e1edl15-atwrt.
*Rolls in unit
    WHEN zsdc_rolls_in_package.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-rolls_in_package = ls_e1edl15-atwrt.
*Length in M
*    WHEN zsdc_linear_footage_metric.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-lineal_footage_m = ls_e1edl15-atwrt.
**Length in FT
*    WHEN zsdc_lineal_footage.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-lineal_footage_ft = ls_e1edl15-atwrt.
**Air Dr weight KG
*    WHEN zsdc_roll_weight_metric.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-roll_weight_kg = ls_e1edl15-atwrt.
**Air Dr weight LB
*    WHEN zsdc_weight_of_roll_in_lbs.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-roll_weight_lb = ls_e1edl15-atwrt.
*Moist
    WHEN zsdc_actual_moisture_percent.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-pulp_moisture = ls_e1edl15-atwrt.
*Air dry%
    WHEN zsdc_air_dry_percent.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-air_dry_percent = ls_e1edl15-atwrt.

*# of Bales (Sum)
    WHEN zsdc_bales_per_batch.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-bales_per_batch = ls_e1edl15-atwrt.

*# of Bales per lot (Sum) "CD2000001172
    WHEN zsdc_bales_per_lot.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-bales_per_lot = ls_e1edl15-atwrt.

*# of units for Bales (Sum)
    WHEN zsdc_bales_per_unit .
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-bales_per_unit = ls_e1edl15-atwrt.

*Bale Air Dry Weight
    WHEN zsdc_batch_weight.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-batch_weight = ls_e1edl15-atwrt.

*#  Cartons  (Sum)
* TPR - 32393 - as we have scenarios where we may have both
* the below characteristics populated , we need to store it
* against two different fields

*    WHEN zsdc_cartons_per_pallet OR
*         zsdc_sheets_per_packaging_unit.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-cartons_sheets = ls_e1edl15-atwrt.

* sheets per packaging
    WHEN  zsdc_sheets_per_packaging_unit.
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-no_of_sheets = ls_e1edl15-atwrt.

* Number of cartons
    WHEN zsdc_cartons_per_pallet .
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-cartons_sheets = ls_e1edl15-atwrt.


*Wrapper Tare (Sum)
    WHEN zsdc_wrapper_tare_weight.
* Character value passing to decimal value
      CALL METHOD me->format_characteristic
        EXPORTING
          iv_atwrt = ls_e1edl15-atwrt
        RECEIVING
          atwrt    = ls_e1edl15-atwrt.

      es_zdl_f01276flat-tare_weight = ls_e1edl15-atwrt.

**Nominal weight in KG
* commented out as per change 9908
*    WHEN zsdc_weight_of_skid_in_lbs.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-weight_of_skid_in_lbs =
*          ls_e1edl15-atwrt.

*Nominal weight in LB
*    WHEN zsdc_weight_of_pallet_in_lbs.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-wgt_of_pallet_in_lbs_net =
*          ls_e1edl15-atwrt.
* end of comment

* Begin of change / nparchu / TPR 38391
* The Roll diameter characterstic will now be read from
* segment e1edl12.

*    WHEN zsdc_roll_diameter.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-roll_diameter_in = ls_e1edl15-atwrt.


**Material Diameter Metric
*    WHEN zsdc_roll_diameter_metric.
*      es_zdl_f01276flat-roll_diameter_cm = ls_e1edl15-atwrt.

* end of change / nparchu / TPR 38391

*** Commented out by CRAMEY 8/23 - change to use ordered for
* all widths
**Roll Width Inches
*    WHEN zsdc_roll_width.
*      es_zdl_f01276flat-roll_width_in_ext =
*          ls_e1edl15-atwtb.
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*      es_zdl_f01276flat-roll_width_in = ls_e1edl15-atwrt.

*Roll Width Metric
* Begin of change / nparchu
* per TPR 05927 the roll_width cm will always b populated
* from material char in segment e1edl12
*    WHEN zsdc_roll_width_metric.
*      es_zdl_f01276flat-roll_width_in_ext =
*          ls_e1edl15-atwtb.
*
*      CALL METHOD me->format_characteristic
*        EXPORTING
*          iv_atwrt = ls_e1edl15-atwrt
*        RECEIVING
*          atwrt    = ls_e1edl15-atwrt.
*
*      es_zdl_f01276flat-roll_width_cm = ls_e1edl15-atwrt.
* End of change / nparchu
  ENDCASE.

ENDMETHOD.


METHOD idoc_mapseg_e1edl18 .

  DATA : lc_metric_indicator     TYPE e1edt18-qualf VALUE 'ZMI'.

*Move data from Structure is_e1edt18 to es_zdl_f01276flat.
  CASE is_e1edl18-qualf.
    WHEN lc_metric_indicator.
      es_zdl_f01276flat-metric_indicator = is_e1edl18-param.
  ENDCASE.
ENDMETHOD.


METHOD idoc_mapseg_e1edl20 .

  es_zdl_f01276flat-vbeln  =  is_e1edl20-vbeln.
  es_zdl_f01276flat-vstel  =  is_e1edl20-vstel. "CD2000001172

ENDMETHOD.


METHOD idoc_mapseg_e1edl24 .

*Move data from Structure is_e1edl24 to es_zdl_f01276flat.
*Delivery Line item #
  es_zdl_f01276flat-posnr = is_e1edl24-posnr.
*Batch Split Higher Level Delivery Line item #
  es_zdl_f01276flat-hipos = is_e1edl24-hipos.
*Line Item Sales Qty
  es_zdl_f01276flat-vemng = is_e1edl24-lfimg.
*Line item sales UOM
  es_zdl_f01276flat-altme = is_e1edl24-vrkme.
*Customer Material#
  es_zdl_f01276flat-idnkd = is_e1edl24-kdmat35.
*Material Description
  es_zdl_f01276flat-arktx = is_e1edl24-arktx.
*Material Entered
  es_zdl_f01276flat-matwa = is_e1edl24-matwa.
*IP Material#
  es_zdl_f01276flat-matnr = is_e1edl24-matnr.
*Material Group
  es_zdl_f01276flat-matkl = is_e1edl24-matkl.
*Division
  es_zdl_f01276flat-division = is_e1edl24-spart.
* Gross Weight (Always LBS)
* avelayu starts
*  es_zdl_f01276flat-gross_weight_lbs = is_e1edl24-brgew.
* avelayu ends
*  es_zdl_f01276flat-brgew = is_e1edl24-brgew.  "DM
* begin of change / npachu / CR 9908
  es_zdl_f01276flat-wgt_of_pallet_in_lbs_net  = is_e1edl24-ntgew.
  es_zdl_f01276flat-weight_of_skid_in_lbs  = is_e1edl24-ntgew.


ENDMETHOD.


METHOD IDOC_MAPSEG_E1EDL24_RL_PAL .

Data: Lv_Iso_Code Type ISOCD_UNIT,
      Lv_Sap_Code Type MSEHI.

*Move data from Structure is_e1edl24 to es_zdl_f01276flat.
*Additional Item Gross Weight
  Es_zdl_f01276flat-ADTNL_ITM_WT        = Is_e1edl24-brgew.
  Es_zdl_f01276flat-brgew               = Is_e1edl24-brgew.

*Additional Item Weight Unit
  Lv_Iso_Code = Is_e1edl24-gewei.
  CALL FUNCTION 'UNIT_OF_MEASURE_ISO_TO_SAP'
       EXPORTING
         ISO_CODE        = Lv_Iso_Code
       IMPORTING
         SAP_CODE        = Lv_Sap_Code
       EXCEPTIONS
         NOT_FOUND       = 1
         OTHERS          = 2.
     IF SY-SUBRC eq 0.
        Es_zdl_f01276flat-brgew_uom = Lv_Sap_Code.
     Else.
        Es_zdl_f01276flat-brgew_uom = Is_e1edl24-gewei.
     ENDIF.

*--Additional Item Actual quantity Delivered
  Es_zdl_f01276flat-ADTNL_ITM_QTY       = Is_e1edl24-lfimg.
*--August-12-2009
*--Consider the actual quanitity delivered only if the material number
*  entry is not blank.
  if Is_e1edl24-matnr is initial.
    Es_zdl_f01276flat-Pallets           = Is_e1edl24-lfimg.
  Endif.
*--Additional Item Sales Unit
  Es_zdl_f01276flat-ADTNL_ITM_UNT       = Is_e1edl24-vrkme.

  Lv_Iso_Code = Is_e1edl24-vrkme.
  CALL FUNCTION 'UNIT_OF_MEASURE_ISO_TO_SAP'
       EXPORTING
         ISO_CODE        = Lv_Iso_Code
       IMPORTING
         SAP_CODE        = Lv_Sap_Code
       EXCEPTIONS
         NOT_FOUND       = 1
         OTHERS          = 2.
     IF SY-SUBRC eq 0.
        Es_zdl_f01276flat-pallets_uom = Lv_Sap_Code.
     Else.
        Es_zdl_f01276flat-pallets_uom = Is_e1edl24-vrkme.
     ENDIF.



*--Additional Item short text for Sales Order Item
  Es_zdl_f01276flat-ADTNL_ITM_TEXT      = Is_e1edl24-arktx.

ENDMETHOD.


METHOD IDOC_MAPSEG_E1EDL26_RL_PAL .

*Move data from Structure is_e1edl26 to es_zdl_f01276flat.
*Additional Items, Delivery item category
  Es_zdl_f01276flat-ADTNL_ITM_PSTYV = Is_e1edl26-PSTYV.
  Es_zdl_f01276flat-PSTYv = Is_e1edl26-PSTYV.

ENDMETHOD.


METHOD idoc_mapseg_e1edl41 .

  CONSTANTS:
      lc_001 TYPE e1edl41-quali VALUE '001'.

*Customer PO#
  IF is_e1edl41-quali = lc_001.
    es_zdl_f01276flat-bstnk = is_e1edl41-bstnr.
  ENDIF.

ENDMETHOD.


METHOD idoc_mapseg_e1edl43 .

  CONSTANTS:
      lc_c                    TYPE e1edl43-qualf VALUE 'C',
      lc_i                    TYPE e1edl43-qualf VALUE 'I',
      lc_v                    TYPE e1edl43-qualf VALUE 'V',
      lc_2                    TYPE e1edl43-qualf VALUE '2'.

*Sales Order#
  IF is_e1edl43-qualf = lc_c OR
* begin of change / nparchu
     is_e1edl43-qualf = lc_i.
* end of change / nparchu
    IF es_zdl_f01276flat-sales_order IS INITIAL.
      es_zdl_f01276flat-sales_order = is_e1edl43-belnr.
**Sales Order Item#
      es_zdl_f01276flat-sales_order_item =
         is_e1edl43-posnr.
* default the Reference Document and Reference Document Line Item,
      es_zdl_f01276flat-vgbel       = is_e1edl43-belnr.
      es_zdl_f01276flat-vgpos_numc6 = is_e1edl43-posnr.
      es_zdl_f01276flat-vgpos       = is_e1edl43-posnr+2(4).
    ENDIF.
*STO #
  ELSEIF is_e1edl43-qualf = lc_v.
    es_zdl_f01276flat-sto = is_e1edl43-belnr.
*STO Item #
    es_zdl_f01276flat-sto_item = is_e1edl43-posnr.

* default the Reference Document and Reference Document Line Item,
*  only if no sales order was found
    IF es_zdl_f01276flat-sales_order IS INITIAL.
      es_zdl_f01276flat-vgbel       = is_e1edl43-belnr.
      es_zdl_f01276flat-vgpos_numc6 = is_e1edl43-posnr.
      es_zdl_f01276flat-vgpos       = is_e1edl43-posnr+2(4).
    ENDIF.

  ELSEIF is_e1edl43-qualf = lc_2.
     es_zdl_f01276flat-bstnk = is_e1edl43-belnr.
  ENDIF.

ENDMETHOD.


METHOD idoc_mapseg_e1edt18 .

  CONSTANTS:
      lc_exp                  TYPE e1edt18-qualf VALUE 'EXP',
      lc_true                 TYPE e1edt18-param VALUE 'TRUE',
      lc_t                    TYPE c             VALUE 'T',
      lc_f                    TYPE c             VALUE 'F',
      lc_mos                  TYPE e1edt18-qualf VALUE 'MOS',
      lc_2                    TYPE e1edt18-param VALUE '2',
      lc_4                    TYPE e1edt18-param VALUE '4',
      lc_pos                  TYPE e1edt18-qualf VALUE 'POS',
      lc_vbl                  TYPE e1edt18-qualf VALUE 'VBL',
      lc_sea                  TYPE e1edt18-qualf VALUE 'SEA',
      lc_metric_indicator     type e1edt18-qualf VALUE 'ZMI'.

*Move data from Structure is_e1edt18 to es_zdl_f01276flat.
  CASE is_e1edt18-qualf.

    WHEN lc_exp.
      IF is_e1edt18-param = lc_true.
*    es_zdl_f01276flat structure doesn't have the ZEXPORT_FLG field.
        es_zdl_f01276flat-zexport_flg = lc_t.
      ELSE.
*    es_zdl_f01276flat structure doesn't have the ZEXPORT_FLG field.
        es_zdl_f01276flat-zexport_flg = lc_f.
      ENDIF.

    WHEN lc_mos.
      IF is_e1edt18-param EQ lc_2 OR
         is_e1edt18-param EQ lc_4.
        es_zdl_f01276flat-zmulti_origin_flg =
             is_e1edt18-param.
      ENDIF.
*Customer PO#

    WHEN lc_pos.
      es_zdl_f01276flat-bstnk = is_e1edt18-param.

    WHEN lc_vbl.
      es_zdl_f01276flat-bol_number = is_e1edt18-param.

    WHEN lc_sea.
      es_zdl_f01276flat-seal = is_e1edt18-param.
* avelayu starts
    when lc_metric_indicator.
      es_zdl_f01276flat-metric_indicator = is_e1edt18-param.
* avelayu ends
  ENDCASE.

ENDMETHOD.


METHOD IDOC_MAPSEG_E1EDT20 .

*Move data from Structure GS_STR2_E1EDT20 to gs_ZDL_F01276FLAT.
  es_zdl_f01276flat-tknum = is_e1edt20-tknum.
  es_zdl_f01276flat-signi = is_e1edt20-signi.

ENDMETHOD.


METHOD idoc_mapseg_e1edt22 .

*Move data from Structure GS_STR2_E1EDT22 to gs_ZDL_F01276FLAT.
  es_zdl_f01276flat-bezei  = is_e1edt22-shtyp_bez.

ENDMETHOD.


method idoc_mapseg_e1txth9 .
  es_zdl_f01276flat-tdid = is_e1txth9-tdid.
  es_zdl_f01276flat-tdobject = is_e1txth9-tdobject.
endmethod.


method idoc_mapseg_e1txtp9 .

  if es_zdl_f01276flat-tdid = '0001' and
    es_zdl_f01276flat-tdobject = 'VBBP'.
    es_zdl_f01276flat-arktx = is_e1txtp9-tdline.
  endif.

endmethod.


method idoc_mapseg_z1edl19 .

  constants:
      lc_vsl                  type z1edl19-qualf value 'VSL',
      lc_vnm                  type z1edl19-qualf value 'VNM',
      lc_ssl                  type z1edl19-qualf value 'SSL',
      lc_bkn                  type z1edl19-qualf value 'BKN',
      lc_glb                  type z1edl19-qualf value 'GLB',
      lc_gkg                  type z1edl19-qualf value 'GKG',
      lc_cgl                  type z1edl19-qualf value 'CGL',
      lc_cgk                  type z1edl19-qualf value 'CGK',
      lc_cnl                  type z1edl19-qualf value 'CNL',
      lc_cnk                  type z1edl19-qualf value 'CNK',
      lc_nlb                  type z1edl19-qualf value 'NLB',
      lc_nkg                  type z1edl19-qualf value 'NKG',
      lc_zlf                  type z1edl19-qualf value 'ZLF',
      lc_zlm                  type z1edl19-qualf value 'ZLM',
      lc_clf                  type z1edl19-qualf value 'CLF',
      lc_clm                  type z1edl19-qualf value 'CLM'.

*Move data from Structure is_z1edl19 to es_zdl_f01276flat.
  case is_z1edl19-qualf.
*Vessel name for export
    when lc_vsl.
      es_zdl_f01276flat-zzveslname = is_z1edl19-param.
*Voyage# for export
    when lc_vnm.
      es_zdl_f01276flat-zzvoygnum = is_z1edl19-param.
*SteamShipline
    when lc_ssl.
      es_zdl_f01276flat-zzstmshpline = is_z1edl19-param.
*Booking Conf# for export
    when lc_bkn.
      es_zdl_f01276flat-zzbooknum = is_z1edl19-param.
    when lc_glb.
      es_zdl_f01276flat-gross_weight_lbs = is_z1edl19-param.
      es_zdl_f01276flat-pulp_scaled_weight_lb = is_z1edl19-param.
    when lc_gkg.
      es_zdl_f01276flat-gross_weight_kg = is_z1edl19-param.
      es_zdl_f01276flat-pulp_scaled_weight_kg = is_z1edl19-param.
    when lc_cgl.
      es_zdl_f01276flat-sum_gross_weight_lb = is_z1edl19-param.
      es_zdl_f01276flat-sum_scaled_wt_lb = is_z1edl19-param.
    when lc_cgk.
      es_zdl_f01276flat-sum_gross_weight_kg = is_z1edl19-param.
      es_zdl_f01276flat-sum_scaled_wt_kg = is_z1edl19-param.
    when lc_nlb.
      es_zdl_f01276flat-roll_weight_lb = is_z1edl19-param.
      es_zdl_f01276flat-net_weight_lb = is_z1edl19-param.
*      es_zdl_f01276flat-air_dry_weight_lb = is_z1edl19-param.
    when lc_nkg.
      es_zdl_f01276flat-roll_weight_kg = is_z1edl19-param.
      es_zdl_f01276flat-net_weight_kg = is_z1edl19-param.
*      es_zdl_f01276flat-air_dry_weight_kg = is_z1edl19-param.
    when lc_cnl.
      es_zdl_f01276flat-sum_air_dry_lb = is_z1edl19-param.
      es_zdl_f01276flat-sum_net_weight_lb = is_z1edl19-param.
    when lc_cnk.
      es_zdl_f01276flat-sum_air_dry_kg = is_z1edl19-param.
      es_zdl_f01276flat-sum_net_weight_kg = is_z1edl19-param.
    when lc_zlf.
      es_zdl_f01276flat-lineal_footage_ft = is_z1edl19-param.
    when lc_zlm.
      es_zdl_f01276flat-lineal_footage_m = is_z1edl19-param.
    when lc_clf.
      es_zdl_f01276flat-sum_lnft_ft = is_z1edl19-param.
    when lc_clm.
      es_zdl_f01276flat-sum_lnft_m = is_z1edl19-param.
  endcase.

endmethod.


METHOD IDOC_MAPSEG_Z1EDSTZ .

  CONSTANTS: lc_z90 TYPE z1edstz-qualf VALUE 'Z90'.

  IF is_z1edstz-qualf = lc_z90.
*Move data from Structure GS_STR2_Z1EDSTZ to gs_ZDL_F01276FLAT.
    es_zdl_f01276flat-zzdate    = is_z1edstz-ntanf.
    es_zdl_f01276flat-zztime    = is_z1edstz-ntanz.
    es_zdl_f01276flat-ztimezone = is_z1edstz-tzonis.
  ENDIF.

ENDMETHOD.


METHOD idoc_shpmnt_read .
*----------------------------------------------------------------------*
* This method                                                          *
*                                                                      *
*----------------------------------------------------------------------*
* Inventory Code : F01276 - Packing List, Partial Pallets              *
*                  Shipment TALLY                                      *
*----------------------------------------------------------------------*
* Change History                                                       *
* ==============                                                       *
* Programmer              Date               Description               *
* ===================  ===========  ================================== *
* Danny Mohamedy       01/30/2009   Initial Version                    *
*                                                                      *
*-----------------------------------------------------------------------

  TYPE-POOLS:
    zsdc. "Batch Characteristics - Constants

  DATA:
    gt_int_edidd            TYPE STANDARD TABLE OF edidd,
    gt_hu_edidd             TYPE STANDARD TABLE OF edidd,
    gt_z1edstp              TYPE STANDARD TABLE OF z1edstp,
    gs_zdl_f01276flat       TYPE zdl_f01276flat,
    gt_zdl_f01276flat       TYPE STANDARD TABLE OF zdl_f01276flat,
    Gt_Adnl_pal_pstyv       Type Standard Table of Zdl_Fields.

* Segment data declaration
  DATA:
    gs_str2_e1edt20         TYPE e1edt20,
    gs_str2_z1edstz         TYPE z1edstz,
    gs_str2_e1edt22         TYPE e1edt22,
    gs_str2_e1edt18         TYPE e1edt18,
    gs_str2_e1adrm4         TYPE e1adrm4,
    gs_str2_e1adre4         TYPE e1adre4,
    gs_str2_e1adrm1         TYPE e1adrm1,
    gs_str2_e1edl24         TYPE e1edl24,
    gs_str2_e1edl26         TYPE e1edl26,
    gs_str2_e1edl41         TYPE e1edl41,
    gs_str2_e1edl12         TYPE e1edl12,
    gs_str2_e1txth9         TYPE e1txth9,
    gs_str2_e1txtp9         TYPE e1txtp9.

  DATA :
    lv_tknum                TYPE vttp-tknum,
    lv_e1adrm4_flg          TYPE char1,
    lv_index20              TYPE i,
    lv_index24              TYPE i,
    lv_index26              TYPE i.

*Constant Declaration
  CONSTANTS :
    lc_mestyp               TYPE edidc-mestyp  VALUE 'ZSDASN',
    lc_idoctp               TYPE edidc-idoctp  VALUE 'SHPMNT05',
    lc_cimtyp               TYPE edidc-cimtyp  VALUE 'ZSDSHPMNT',
    lc_rcvpfc               TYPE edidc-rcvpfc  VALUE 'SH',
    lc_e1edt20(7)           TYPE c             VALUE 'E1EDT20',
    lc_z1edstz(7)           TYPE c             VALUE 'Z1EDSTZ',
    lc_e1edt22(7)           TYPE c             VALUE 'E1EDT22',
    lc_e1edt18(7)           TYPE c             VALUE 'E1EDT18',
    lc_e1adrm4(7)           TYPE c             VALUE 'E1ADRM4',
    lc_e1adre4(7)           TYPE c             VALUE 'E1ADRE4',
    lc_e1txth9(7)           Type c             Value 'E1TXTH9',
    lc_e1txtp9(7)           Type c             Value 'E1TXTP9'.

Data: Gr_adnl_pal Type Range of PSTYV_VL,
      gs_adnl_pal Like line of Gr_adnl_pal.

* Populate data in GS_OBJECT
  gs_object-mandt              = sy-mandt.
  gs_object-objky              = iv_tknum.
  gs_object-spras              = sy-langu.
  gs_object-nacha              = gc_nacha_a.

* Populate data in control structure
  gs_control_record_in-mandt   = sy-mandt.
  gs_control_record_in-mestyp  = lc_mestyp. "'ZSDASN'.
  gs_control_record_in-idoctp  = lc_idoctp. "'SHPMNT05'.
  gs_control_record_in-cimtyp  = lc_cimtyp. "'ZSDSHPMNT'.
  gs_control_record_in-rcvpfc  = lc_rcvpfc. "'SH'.
  gs_control_record_in-test    = 'X'. "'SH'.

*Clear the Structures/variable and refresh the table.
  CLEAR : gs_object_type, gs_control_record_out.
  REFRESH gt_int_edidd.

  CALL FUNCTION 'IDOC_OUTPUT_SHPMNT'
    EXPORTING
      object                 = gs_object
      control_record_in      = gs_control_record_in
    IMPORTING
      object_type            = gs_object_type
      control_record_out     = gs_control_record_out
    TABLES
      int_edidd              = gt_int_edidd
    EXCEPTIONS
      error_message_received = 1
      OTHERS                 = 2.

  CHECK NOT gt_int_edidd[] IS INITIAL.

  Select * into table Gt_Adnl_pal_pstyv
    from Zdl_Fields
   Where category  eq GC_PALLETS_CAT
   and   Fieldname eq GC_PALLETS_FLD.
  Gs_adnl_pal-Sign   = 'I'.
  Gs_adnl_pal-Option = 'EQ'.
  If sy-subrc eq 0.
     read table Gt_Adnl_pal_pstyv into Gs_Adnl_pal_pstyv index 1.
     Loop at Gt_Adnl_pal_pstyv into Gs_Adnl_pal_pstyv.
       Gs_adnl_pal-Low = Gs_Adnl_pal_pstyv-Lowval.
       append Gs_adnl_pal to Gr_adnl_pal.
     Endloop.
  Else.
     Gs_Adnl_pal_pstyv-Lowval = 'XXXX'.
  Endif.

* Separate HU segments 37, 39 and 44
  CALL METHOD me->build_hu_edidd
    CHANGING
      it_edidd    = gt_int_edidd
      et_hu_edidd = gt_hu_edidd.

* Separate segment Z1EDSTP for Stages/Stops
  CALL METHOD me->build_z1edstp_edidd
    CHANGING
      it_edidd       = gt_int_edidd
      et_z1edstp_tab = gt_z1edstp.
  SORT gt_z1edstp BY kunnr tsnum DESCENDING.

  CHECK NOT gt_int_edidd[] IS INITIAL.

  lv_index20 = 0.
  lv_index24 = 0.

*--Pass the data from edidd table to flat structre for required
*  segements
  LOOP AT gt_int_edidd INTO gs_int_edidd.

* Check the segment and map the data accordingly in flat table
    CASE gs_int_edidd-segnam.

* IDoc: Shipment
      WHEN lc_e1edt20.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edt20.
        CALL METHOD me->idoc_mapseg_e1edt20
          EXPORTING
            is_e1edt20        = gs_str2_e1edt20
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edt20.

* Stop Date/Times
      WHEN lc_z1edstz.
        MOVE  gs_int_edidd-sdata TO gs_str2_z1edstz.
        CALL METHOD me->idoc_mapseg_z1edstz
          EXPORTING
            is_z1edstz        = gs_str2_z1edstz
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_z1edstz.

* IDoc: Shipment descriptions
      WHEN lc_e1edt22.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edt22.
        CALL METHOD me->idoc_mapseg_e1edt22
          EXPORTING
            is_e1edt22        = gs_str2_e1edt22
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edt22.

* IDoc: Control (Shipment)
      WHEN lc_e1edt18.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edt18.
        CALL METHOD me->idoc_mapseg_e1edt18
          EXPORTING
            is_e1edt18        = gs_str2_e1edt18
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edt18.

* Central Address Segment Group, Main Segment
      WHEN lc_e1adrm4.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1adrm4.
        CALL METHOD me->idoc_mapseg_e1adrm4
          EXPORTING
            is_e1adrm4        = gs_str2_e1adrm4
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat
            ev_e1adrm4_flg    = lv_e1adrm4_flg.

* Central Address Segment Group, Additional Data Segment
      WHEN lc_e1adre4.
        IF NOT lv_e1adrm4_flg IS INITIAL.
          MOVE  gs_int_edidd-sdata TO  gs_str2_e1adre4.
          CALL METHOD me->idoc_mapseg_e1adre4
            EXPORTING
              is_e1adre4        = gs_str2_e1adre4
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.
          CLEAR lv_e1adrm4_flg.
        ENDIF.

* Delivery header
      WHEN Gc_e1edl20.                       " Without QUALF/ATNAM

        lv_index24 = lv_index26 = 0.

        lv_index20 = lv_index20 + 1.
        IF lv_index20 <> 1.

          CALL METHOD me->idoc_append_by_hu
            EXPORTING
              it_hu_edidd       = gt_hu_edidd
              is_e1edl20        = gs_str2_e1edl20
              is_e1edl24        = gs_str2_e1edl24
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat
              et_zdl_f01276flat = gt_zdl_f01276flat.

          CALL METHOD me->clear_delivery_head
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.
*
          CALL METHOD me->clear_delivery_item
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.

        ENDIF.

* Delivery header
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl20.
        CALL METHOD me->idoc_mapseg_e1edl20
          EXPORTING
            is_e1edl20        = gs_str2_e1edl20
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

* Central Address Segment Group, Main Segment
      WHEN Gc_e1adrm1.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1adrm1.
        CALL METHOD me->idoc_mapseg_e1adrm1
          EXPORTING
            is_e1adrm1        = gs_str2_e1adrm1
            it_z1edstp        = gt_z1edstp
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

* Delivery Item
      WHEN Gc_e1edl24.

        lv_index24 = lv_index24 + 1.
        If lv_index24 eq 1.
*--Exception to the Rule (for Rolls on Pallets) although Line Item detail,
*  but treated like a Header Information.
           MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl24.

           CALL METHOD me->idoc_mapseg_e1edl24_rl_pal
             EXPORTING
               is_e1edl24        = gs_str2_e1edl24
             CHANGING
               es_zdl_f01276flat = gs_zdl_f01276flat.

        Else." lv_index24 <> 1.

          CALL METHOD me->idoc_append_by_hu
            EXPORTING
              it_hu_edidd       = gt_hu_edidd
              is_e1edl20        = gs_str2_e1edl20
              is_e1edl24        = gs_str2_e1edl24
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat
              et_zdl_f01276flat = gt_zdl_f01276flat.

          CALL METHOD me->clear_delivery_item
            CHANGING
              es_zdl_f01276flat = gs_zdl_f01276flat.

        ENDIF. " lv_index24 <> 1.

* Delivery Item
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl24.
        CALL METHOD me->idoc_mapseg_e1edl24
          EXPORTING
            is_e1edl24        = gs_str2_e1edl24
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

      WHEN Gc_e1edl26.
        lv_index26 = lv_index26 + 1.
        If lv_index26 eq 1.
           MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl26.

        CALL METHOD me->idoc_mapseg_e1edl26_rl_pal
          EXPORTING
            is_e1edl26        = gs_str2_e1edl26
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.

        Endif.


* IDOC: Controlling (Delivery Item) (IP)
      WHEN Gc_z1edl19.
        MOVE  gs_int_edidd-sdata TO  gs_str2_z1edl19.
        CALL METHOD me->idoc_mapseg_z1edl19
          EXPORTING
            is_z1edl19        = gs_str2_z1edl19
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_z1edl19.

* IDOC: Batch Characteristic
      WHEN Gc_e1edl15.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl15.
        CALL METHOD me->idoc_mapseg_e1edl15
          EXPORTING
            is_e1edl15        = gs_str2_e1edl15
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl15.

* IDoc: Reference
      WHEN Gc_e1edl43.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl43.
        CALL METHOD me->idoc_mapseg_e1edl43
          EXPORTING
            is_e1edl43        = gs_str2_e1edl43
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl43.

* Reference data ordering party
      WHEN Gc_e1edl41.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl41.
        CALL METHOD me->idoc_mapseg_e1edl41
          EXPORTING
            is_e1edl41        = gs_str2_e1edl41
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl41.

* IDOC: Configuration
      WHEN Gc_e1edl12.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1edl12.
        CALL METHOD me->idoc_mapseg_e1edl12
          EXPORTING
            is_e1edl12        = gs_str2_e1edl12
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1edl12.

* IDOC: General Text Header
        WHEN Gc_E1TXTH9.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1txtH9.
        CALL METHOD me->idoc_mapseg_e1txtH9
          EXPORTING
            is_e1txth9        = gs_str2_e1txth9
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1txth9.

* IDOC: Text
        WHEN Gc_E1TXTP9.
        MOVE  gs_int_edidd-sdata TO  gs_str2_e1txtp9.
        CALL METHOD me->idoc_mapseg_e1txtp9
          EXPORTING
            is_e1txtp9        = gs_str2_e1txtp9
          CHANGING
            es_zdl_f01276flat = gs_zdl_f01276flat.
        CLEAR gs_str2_e1txtp9.

    ENDCASE.

  ENDLOOP.

  CALL METHOD me->idoc_append_by_hu
    EXPORTING
      it_hu_edidd       = gt_hu_edidd
      is_e1edl20        = gs_str2_e1edl20
      is_e1edl24        = gs_str2_e1edl24
    CHANGING
      es_zdl_f01276flat = gs_zdl_f01276flat
      et_zdl_f01276flat = gt_zdl_f01276flat.

*  Loop at gt_zdl_f01276flat into gs_zdl_f01276flat
*    where ADTNL_ITM_PSTYV in Gr_adnl_pal.
*    Exit.
*  Endloop.
  Read table gt_zdl_f01276flat
       into gs_zdl_f01276flat
       with key ADTNL_ITM_PSTYV = Gs_Adnl_pal_pstyv-lowval.
  If sy-subrc eq 0.
     Loop at gt_zdl_f01276flat into gs_zdl_f01276flat
          where ADTNL_ITM_PSTYV ne Gs_Adnl_pal_pstyv-lowval.
       gs_zdl_f01276flat-ADTNL_ITM_PSTYV =
       gs_zdl_f01276flat-pstyv = Gs_Adnl_pal_pstyv-lowval.
       modify gt_zdl_f01276flat from gs_zdl_f01276flat.
     Endloop.
  Endif.

  shipment_return[] = gt_zdl_f01276flat[].

ENDMETHOD.                    "IDOC_SHPMNT_READ
ENDCLASS.

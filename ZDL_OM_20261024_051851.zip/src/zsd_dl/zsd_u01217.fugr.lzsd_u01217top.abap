FUNCTION-POOL zsd_u01217.                   "MESSAGE-ID ..


*Declaration of Constants
CONSTANTS :gc_pgrmid TYPE programm VALUE 'ZDL_E03167',
           gc_posnr_hdr TYPE posnr_va VALUE '000000',
           gc_ystk TYPE zz_fped_status_itm VALUE 'YSTK',
           gc_zitc TYPE zz_fped_status_itm VALUE 'ZITC',
           gc_litc TYPE zz_fped_status_itm VALUE 'LITC',
           gc_late TYPE zz_fped_status_itm VALUE 'LATE',
           gc_yfpe TYPE zz_fped_status_itm VALUE 'YFPE',
           gc_fped TYPE zz_fped_status_itm VALUE 'FPED',
           gc_space VALUE ' ',
           gc_n VALUE 'N',
           gc_i VALUE 'I',
           gc_p VALUE 'P',
           gc_x VALUE 'X',
           gc_* VALUE '*',
*------  Begin EDEK911357  EDEK911462  --------------------------------*
           gc_sc2v TYPE zz_fped_status_itm VALUE 'SC2V', "component
           gc_sc2c TYPE zz_fped_status_itm VALUE 'SC2C', "finished goods
           gc_f VALUE 'F',
           gc_30(02) VALUE '30',
           gc_LB(02) VALUE 'LB',         "Delivery Plant to Vendor
           gc_LF(02) VALUE 'LF'.         "Delivery Plant to Customer
*------  End   EDEK911357  EDEK911462  --------------------------------*


*Begin of Internal Table Declaration
DATA: gt_zppkiwifped TYPE TABLE OF zppkiwifped,
      gt_zppfped_status TYPE TABLE OF zppfped_status ,
      gt_zppfped_status_tmp LIKE zppfped_status
                        OCCURS 0 WITH HEADER  LINE ,
      gt_postab_temp LIKE lipov OCCURS 0 WITH HEADER LINE,
      gt_fped_loc LIKE zdl_fped_loc OCCURS 0 WITH HEADER LINE,
      gt_zsp_value LIKE zsp_value OCCURS 0 WITH HEADER LINE.

*begin of TPR 22705 EDVK960014 PRAGUPA 01/24/2008
DATA : BEGIN OF gt_zppkiwifped_tmp OCCURS 0.
        INCLUDE STRUCTURE zppkiwifped.
DATA:    dlvry TYPE vbeln,
       END OF gt_zppkiwifped_tmp.
*begin of TPR 22705 EDVK960014 PRAGUPA 01/24/2008


*End of Internal Table Declaration


*Begin of Structure Declaration
DATA: gs_zppfped_status LIKE zppfped_status,
      gs_zppfped_status_tmp LIKE zppfped_status,
      gs_lipov  LIKE lipov.
*End of Structure Declaration


*Begin of variable Declaration
DATA: gv_rec_count TYPE i,
      gv_status.
*End of variable Declaration

*------  Begin EDEK911357  EDEK911462  --------------------------------*
*------  Table for Delivery Type LF - Plant to Customer  --------------*
  TYPES: BEGIN of ts_dlv_lf,
           VBELN                       TYPE VBELN_VL,
           COUNT(09)                   TYPE N,
           FPED_START_DT_HDR           TYPE ZZ_FPED_START_DT_HDR,
           FPED_START_TM_HDR           TYPE ZZ_FPED_START_TM_HDR,
           FPED_END_DT_HDR             TYPE ZZ_FPED_END_DT_HDR,
           FPED_END_TM_HDR             TYPE ZZ_FPED_END_TM_HDR,
           FPED_STATUS_HDR             TYPE ZZ_FPED_STATUS_HDR,
         END   of ts_dlv_lf.

data:  gs_dlv_lf      type ts_dlv_lf.                      "work struc
data:  gt_dlv_lf      type standard table of ts_dlv_lf.    "table

*------  Table for MARC - Plant Data for Material  --------------------*
*------  This table is a SORTED table and is always in sequence  ------*
*------    by the UNIQUE KEY fields MATNR and WERKS              ------*
*------  DO NOT change the table type from SORTED                ------*
  TYPES: BEGIN of ts_marc,
           MATNR              TYPE MATNR,    "Matl
           WERKS              TYPE WERKS_D,  "Plant
           BESKZ              TYPE BESKZ,    "Proc Type
           SOBSL              TYPE SOBSL,    "Spec Proc Type
         END   of ts_marc.

data:  gs_marc        type ts_marc.                        "work struc
data:  gt_marc        type SORTED table of ts_marc         "table
                             WITH UNIQUE KEY MATNR WERKS.

*------  End   EDEK911357  EDEK911462  --------------------------------*

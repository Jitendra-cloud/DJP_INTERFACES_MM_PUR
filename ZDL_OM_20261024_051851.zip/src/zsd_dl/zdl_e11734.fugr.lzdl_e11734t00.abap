*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_E11734_NOTIF................................*
DATA:  BEGIN OF STATUS_ZDL_E11734_NOTIF              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_E11734_NOTIF              .
CONTROLS: TCTRL_ZDL_E11734_NOTIF
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_E11734_NOTIF              .
TABLES: ZDL_E11734_NOTIF               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

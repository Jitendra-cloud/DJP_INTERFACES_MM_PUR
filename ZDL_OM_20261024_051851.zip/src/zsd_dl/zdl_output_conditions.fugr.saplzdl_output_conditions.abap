*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_OUTPUT_CONDITIONSTOP.         " Global Data
  INCLUDE LZDL_OUTPUT_CONDITIONSUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_OUTPUT_CONDITIONSF...         " Subprograms
* INCLUDE LZDL_OUTPUT_CONDITIONSO...         " PBO-Modules
* INCLUDE LZDL_OUTPUT_CONDITIONSI...         " PAI-Modules

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_FPED_LOC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_FPED_LOC        .

  PERFORM TABLEPROC.

ENDFUNCTION.

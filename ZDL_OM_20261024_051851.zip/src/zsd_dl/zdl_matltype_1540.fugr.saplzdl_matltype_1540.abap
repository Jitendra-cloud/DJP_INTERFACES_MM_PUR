*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_MATLTYPE_1540TOP.             " Global Data
  INCLUDE LZDL_MATLTYPE_1540UXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_MATLTYPE_1540F...             " Subprograms
* INCLUDE LZDL_MATLTYPE_1540O...             " PBO-Modules
* INCLUDE LZDL_MATLTYPE_1540I...             " PAI-Modules

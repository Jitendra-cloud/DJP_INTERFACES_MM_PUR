FUNCTION ZSDI02529_VTTK_IMPORT .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  EXPORTING
*"     REFERENCE(E_VTTK) TYPE  VTTK
*"----------------------------------------------------------------------

*Import VTTK from global memory to use in all distance calculation
*programs.

 e_vttk = gs_vttk.

ENDFUNCTION.

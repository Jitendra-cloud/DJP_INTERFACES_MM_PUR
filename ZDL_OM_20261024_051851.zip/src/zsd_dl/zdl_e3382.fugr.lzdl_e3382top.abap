FUNCTION-POOL ZDL_E3382                    MESSAGE-ID zsd_dl.

* Traffic Light Values
CONSTANTS: c_green  VALUE '3',
           c_yellow VALUE '2',
           c_red    VALUE '1'.

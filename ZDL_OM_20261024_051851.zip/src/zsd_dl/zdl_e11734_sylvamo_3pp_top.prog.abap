*&---------------------------------------------------------------------*
*&  Include           ZDL_E11734_SYLVAMO_3PP_TOP                      *
*&---------------------------------------------------------------------


************************************************************************
*   DATA DECLARATION
************************************************************************

constants:
  gc_success  value 'S',
  gc_warrning value 'W',
  gc_error    value 'E',
  gc_msgid    type  symsgid  value 'ZSD_DL'.

tables:
  likp,    " Delivery Header
  lips,    " Delivery Item data
  ekko.                                                         "33303

data:
* Inbound deliveries and their shipping point
*  BEGIN OF gs_inb_dlvry,                             "JWILL68 CD#1626
*    vbeln       TYPE vbeln_vl,    "Inbound delivery
*    werks       TYPE werks_d,     "Plant
*    vgbel       TYPE vgbel,       "Doc.ref.no = Purchase order
*    vbelv       TYPE vbeln_von,   " CMS 29123
*    vkorg       TYPE likp-vkorg,                                      "33303
*    ekorg       TYPE ekko-ekorg,                                      "33303
*    zz_complete TYPE zdl_complete, "JWILL68 CD#2000000395
*  END OF gs_inb_dlvry,

*  gt_inb_dlvry LIKE TABLE OF gs_inb_dlvry,

* Sales order corresponding to a inbound delivery
  begin of gs_so,
    vbelv type vbeln_vl,   "Sales order
    vbeln type vbeln_vl,   "Purchase order
  end of gs_so,

  gt_so like table of gs_so.

* Error messages
***** 2000000330 - lines below commented out
*gt_messages type zca_bal_msg_tab.
***** 2000000330 - end lines commented out

***  hmalkow - start
types: begin of t_messages,
         notifno     type i,
         notifobj	   type znotifobj,
         notifobjtyp type znotifobjtyp,
         notifheader type string.
         include type bal_s_msg.
       types: end of t_messages.

data: gt_messages type standard table of t_messages.
***  hmalkow - end

constants c_werks type werks_d value '9427'.  " CR# 11871
ranges
* XREF table info for delivery type
  gr_xref for likp-lfart.

*** Start of change JWILL68 CD#1626 5/20/2019
types: begin of ty_s_inb_dlvry,
         vbeln           type vbeln_vl,
         erdat           type erdat,
         vstel           type vstel,
         zz_exit_pass_no type zz_exit_pass_no,
         zz_scac         type zdl_scac,
         zz_signi        type zdl_signi,
         zz_bale_cnt     type zdl_bales,
         zz_bol          type zz_dl_bol,
         zz_scale        type zdl_scale_ticket,
         zz_complete     type zdl_complete,
         zz_ship_date    type zdl_ship_date,
         zz_gross_wt     type zdl_gross_wt,
         zz_net_wt       type zdl_netwt,
         zz_tare_wt      type zdl_tare_wt,
         btgew           type gsgew,
         anzpk           type anzpk,
       end of ty_s_inb_dlvry,

       begin of ty_s_lips,
         vbeln type vbeln_vl,
         posnr type posnr_vl,
         matnr type matnr,
         werks type werks_d,
         lgort type lgort_d,
         charg type charg_d,
         lfimg type lfimg,
         meins type meins,
         vrkme type vrkme,
         umvkz type umvkz,
         umvkn type umvkn,
         ntgew type ntgew,
         brgew type brgew,
         gewei type gewei,
         lgmng type lgmng,
         vbelv type vbelv,
         posnv type posnv,
         vgbel type vgbel,
         vgpos type vgpos,
       end of ty_s_lips,

       begin of ty_s_so_org,
         vbeln type vbeln_va,
         vkorg type vkorg,
         vgbel type vgbel,
       end of ty_s_so_org,

       begin of ty_s_so_item,
         vbeln type vbeln_va,
         vbelv type vbelv,
         posnv type posnv,
         vrkme type vrkme,
         umvkz type umvkz,
         umvkn type umvkn,
       end of ty_s_so_item,

       begin of ty_s_filter_po,
         ebeln type ebeln,
         ekorg type ekorg,
       end of ty_s_filter_po,

       begin of ty_s_inb_dlvry_process,
         vbeln           type vbeln_vl,
         vbelv           type vbelv,
         posnv           type posnv,
         zz_complete     type zdl_complete,
         posnr           type posnr_vl,
         matnr           type matnr,
         werks           type werks_d,
         lgort           type lgort_d,
         charg           type charg_d,
         lfimg           type lfimg,
         vgbel           type vgbel,
         vgpos           type vgpos,
         ekorg           type ekorg,
         vkorg           type vkorg,
         lgmng           type lgmng,
         brgew           type brgew,
         ntgew           type ntgew,
         gewei           type gewei,
         meins           type meins,
         lips_vrkme      type vrkme,
         vbap_vrkme      type vrkme,
         umvkz           type umvkz,
         umvkn           type umvkn,
         zz_exit_pass_no type zz_exit_pass_no,
         zz_scac         type zdl_scac,
         zz_signi        type zdl_signi,
         zz_bale_cnt     type zdl_bales,
         zz_bol          type zz_dl_bol,
         zz_scale        type zdl_scale_ticket,
         zz_ship_date    type zdl_ship_date,
         zz_gross_wt     type zdl_gross_wt,
         zz_net_wt       type zdl_netwt,
         zz_tare_wt      type zdl_tare_wt,
       end of ty_s_inb_dlvry_process,

       begin of ty_s_obd_data,
         vbeln type vbeln_vl,
         vbelv type vbelv,
         vgbel type vgbel,
         posnv type posnv,
       end of ty_s_obd_data,

       begin of ts_dcgr,
         vbeln      type vbeln_vl,
         tknum      type tknum,
         dcgr       type char1,
         frkrl      type kfrkrl,
         fbsta      type fbsta,
         inb_assgnd type char1,
         ship_ref   type char1,
         ship_bolnr type char1,
       end of ts_dcgr,

       tt_dcgr_tab            type standard table of ts_dcgr,
       ty_t_obd_data          type standard table of ty_s_obd_data with empty key,
       ty_t_inb_dlvry_process type standard table of ty_s_inb_dlvry_process,
       ty_t_filter_po         type standard table of ty_s_filter_po,
       ty_t_so_item           type standard table of ty_s_so_item,
       ty_t_so_org            type standard table of ty_s_so_org,
       ty_t_lips              type standard table of ty_s_lips with empty key,
       ty_t_inb_dlvry         type standard table of ty_s_inb_dlvry with empty key.

data: gs_inb_dlvry type ty_s_inb_dlvry_process,
      gt_inb_dlvry type ty_t_inb_dlvry_process,
      gt_fields    type standard table of zdl_fields.

*** End of change JWILL68 CD#1626 5/20/2019

***** hmalkow - start
"---Shipment Create Bapi Data
data: gs_headerdata     type bapishipmentheader.
data: gt_headerdeadline type standard table of bapishipmentheaderdeadline.
data: gt_itemdata       type standard table of bapishipmentitem.
data: gt_stagedata      type standard table of bapishipmentstage.
data: gt_stagedeadline  type standard table of bapishipmentstagedeadline.
data: gt_itemonstage    type standard table of bapishipmentitemonstage.
***** hmalkow - end
************************************************************************
* SELECTION-SCREEN
************************************************************************

selection-screen begin of block b01 with frame.

selection-screen begin of block b02 with frame title text-t01.
selection-screen skip.
* Inbound delivery information
*PARAMETERS:     " CR# 11871
"Shipping /Receiving Point
*  sp_plant LIKE lips-werks DEFAULT '9427' OBLIGATORY.
" CR# 11871 09/10/2012

select-options:
  so_plant for lips-werks obligatory, " Shipping /Receiving Point
                                      " CR# 11871 09/10/2012
  so_erdat for lips-erdat obligatory, "CD#1626 JWILL68
  so_vbeln for likp-vbeln, " Inbound Delivery
  so_lifnr for likp-lifnr, " Vendor Accnt Num CR# 11871 09/10/2012
  so_vsbed for likp-vsbed, " Shipping Conditions CR# 11871 10/01/2012
  so_ekorg for ekko-ekorg,                                      "33303
  so_vkorg for likp-vkorg.                                      "33303
parameters:
  sp_vbeln like likp-vbeln
    modif id ody. "Out. Delivery in case of direct pick & pack
selection-screen skip.
selection-screen end of block b02.

* Action
selection-screen begin of block b03 with frame title text-t02.
selection-screen skip.
parameters:
  sp_posgr as checkbox default 'X',
  sp_vl01n as checkbox default 'X' modif id md1,
  sp_charg as checkbox default 'X' modif id md1,
***** hmalkow - start
  sp_shipm as checkbox default 'X' modif id msy user-command usy,
  sp_stats as checkbox default 'X' modif id msx user-command usy.
***** hmalkow - end
selection-screen skip.
selection-screen end of block b03.

selection-screen end of block b01.

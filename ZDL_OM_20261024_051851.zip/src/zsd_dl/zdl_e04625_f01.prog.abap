*&---------------------------------------------------------------------*
*&  Include           ZDL_E04625_F01                                   *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_ZDL_FIELDS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_zdl_fields .

  CLEAR: gt_zdl_fields.

  CONSTANTS : lc_e04625	TYPE zcatgory  VALUE 'E04625'.

* Retrieve the Message Id#s for which the #Change PO#
* button will be Active
  SELECT * FROM zdl_fields INTO TABLE gt_zdl_fields
     WHERE category = lc_e04625.

ENDFORM.                    " GET_ZDL_FIELDS
*&---------------------------------------------------------------------*
*&      Form  RETRIEVE_DATA_9100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM retrieve_data_9100 .

  CLEAR : gs_data,gs_edids.
* Call a common function module that accepts an Idoc number and
* retrieves the data
  CALL FUNCTION 'ZDL_E04625_GET_ASN_DATA'
    EXPORTING
      iv_docnum    = gv_docnum  "Idoc number
    IMPORTING
      es_data      = gs_data   "Various idoc data info
      es_edids     = gs_edids  "Idoc status record
    EXCEPTIONS
      invalid_idoc = 1
      OTHERS       = 2.
  IF sy-subrc NE 0.
*   IDoc & does not exist, processing not possible
    MESSAGE ID gc_b1 TYPE gc_i NUMBER '301' WITH gv_docnum.
  ENDIF.
* Format the screen fields from the returned data
  CLEAR: gs_9100.

* Format the error message string
  PERFORM generate_errmsg USING gs_edids CHANGING gs_9100-errmsg.

  gs_9100-docnum = gv_docnum. "idoc number
  gs_9100-lifnr  = gs_data-lifnr. "Vendor number
  gs_9100-bolnr  = gs_data-bolnr.  "BOL
  gs_9100-traid  = gs_data-traid.   "Transport Id
  gs_9100-werks  = gs_data-werks. "Plant
  gs_9100-ebeln  = gs_data-ebeln. "PO
  gs_9100-segnum = gs_edids-segnum."Segment number of error
  gs_9100-stamid = gs_edids-stamid.  "Error Message Class
  gs_9100-stamno = gs_edids-stamno. "Error number

ENDFORM.                    " RETRIEVE_DATA_9100

*&---------------------------------------------------------------------*
*&      Form  generate_errmsg
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->LS_EDIDS   text
*      -->CV_ERRMSG  text
*----------------------------------------------------------------------*
FORM generate_errmsg USING ls_edids STRUCTURE edids
        CHANGING cv_errmsg TYPE char70.

  DATA : gv_msg TYPE bapi_msg.
  CONSTANTS : gc_asc TYPE bapi_tfrmt VALUE 'ASC'.

* Formatting Message into Message Text
  CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
    EXPORTING
      id         = ls_edids-stamid
      number     = ls_edids-stamno
      language   = sy-langu
      textformat = gc_asc
      message_v1 = ls_edids-stapa1
      message_v2 = ls_edids-stapa2
      message_v3 = ls_edids-stapa3
      message_v4 = ls_edids-stapa4
    IMPORTING
      message    = gv_msg.

  IF sy-subrc = 0.
    cv_errmsg = gv_msg.
  ENDIF.

ENDFORM.                    "generate_errmsg
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_IDOC_NUMBER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_idoc_number .

  DATA: lv_docnum TYPE edi_docnum,
        lv_status TYPE edi_status,
        lv_mestyp TYPE edi_mestyp.


* Determine if the Idoc exists in the db
  SELECT SINGLE docnum status mestyp
    INTO: (lv_docnum, lv_status , lv_mestyp)
    FROM edidc WHERE docnum = gv_docnum.
  IF sy-subrc = 0.
* Make sure it#s a Vendor ASN idoc
    IF lv_mestyp NE gc_zdl_vasn.
      gv_error = gc_true.
* Idoc & is not a Vendor ASN
      MESSAGE ID gc_zsd_dl TYPE gc_e NUMBER '612' WITH gv_docnum.
    ENDIF.
* Make sure idoc is in a status of #51#
    IF lv_status NE '51'.
      gv_error = gc_true.
* Idoc & is not in status 51
      MESSAGE ID gc_zsd_dl TYPE gc_e NUMBER '611' WITH gv_docnum.
    ENDIF.
  ELSE.
    gv_error = gc_true.
* IDoc & does not exist, processing not possible
    MESSAGE ID gc_b1 TYPE gc_e NUMBER '301' WITH gv_docnum.
  ENDIF.


ENDFORM.                    " VALIDATE_IDOC_NUMBER
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_PO_NUMBER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_po_number .

* Convert New PO Number to Right Justified and Leading 0's
  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      input  = gv_new_ebeln
    IMPORTING
      output = gv_new_ebeln.

* Make sure new PO number is not blank
  IF gv_new_ebeln IS INITIAL.
* New PO number cannot be blank
    MESSAGE ID gc_zsd_dl TYPE gc_e NUMBER '608'.
    LEAVE PROGRAM.
  ENDIF.

* Make sure new PO number is not the same as the current PO number
  IF gv_new_ebeln = gs_9100-ebeln.
* New PO number is the same as the old one
    MESSAGE ID gc_zsd_dl TYPE gc_e NUMBER '609'.
    LEAVE PROGRAM.
  ENDIF.

* Make sure the new PO number exists in SAP
  SELECT SINGLE ebeln
    FROM ekko
    INTO gv_new_ebeln
   WHERE ebeln = gv_new_ebeln.
  IF sy-subrc <> 0.
* New PO number does not exist in SAP
    MESSAGE ID gc_zsd_dl TYPE gc_e NUMBER '610'.
    LEAVE PROGRAM.
  ENDIF.

ENDFORM.                    " VALIDATE_PO_NUMBER
*&---------------------------------------------------------------------*
*&      Form  CHANGE_PO_NUMBER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM change_po_number .

  TYPES : BEGIN OF ts_check,
          segnum TYPE edi_segnam,
          flag   TYPE c,
          END OF ts_check.

  DATA : lv_count  TYPE i,
         lv_count1 TYPE i,
         lv_diff   TYPE i.

  DATA : ls_check TYPE ts_check,
         lt_check TYPE TABLE OF ts_check.

  DATA : lt_edidd TYPE TABLE OF edidd,
         ls_edidd TYPE edidd,
         ls_edidd2 TYPE edidd,
         ls_edidd1 TYPE edidd,
         ls_edids TYPE edids,
         lt_edids TYPE STANDARD TABLE OF edids,
         ls_e1edl43 TYPE e1edl43,
         lt_data_rec40     TYPE TABLE OF edi_dd40,
         lt_idoc_data      TYPE TABLE OF edidd,
         ls_idoc_data      TYPE edidd,
         ls_control_rec40  TYPE edi_dc40,
         ls_data_rec40     TYPE edi_dd40,
         ls_edidc          TYPE edidc,
         lt_idocsyn        TYPE STANDARD TABLE OF idocsyn,
         lt_idocsyn1       TYPE STANDARD TABLE OF idocsyn,
         ls_idocsyn        TYPE idocsyn,
         lv_posno          TYPE posno,
         lv_flag           TYPE c,
         lv_index          TYPE sy-tabix,
         lv_tabix43        TYPE sytabix,
         lv_line           TYPE sy-tabix.

  DATA : lt_idoc_status TYPE STANDARD TABLE OF bdidocstat,
         ls_idoc_status TYPE bdidocstat.

  DATA :  lv_idoc_number   LIKE edidc-docnum,
          lv_error_appl LIKE edi_help-error_flag.

*** Note: to see some of the following function modules in action,
*  debug transaction WE19
* Retrieve Idoc Control Record
  CALL FUNCTION 'EDI_DOCUMENT_OPEN_FOR_READ'
    EXPORTING
      document_number         = gv_docnum
    IMPORTING
      idoc_control            = ls_edidc
    EXCEPTIONS
      document_foreign_lock   = 1
      document_not_exist      = 2
      document_number_invalid = 3
      OTHERS                  = 4.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    RETURN.
  ENDIF.

* Retrieve Idoc Data Records
  CALL FUNCTION 'EDI_SEGMENTS_GET_ALL'
    EXPORTING
      document_number         = gv_docnum
    TABLES
      idoc_containers         = lt_edidd
    EXCEPTIONS
      document_number_invalid = 1
      end_of_document         = 2
      OTHERS                  = 3.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    RETURN.
  ENDIF.
  CLEAR lv_count.
** Getting number of records from initial IDoc
  DESCRIBE TABLE lt_edidd LINES lv_count.

* Close Idoc after usage
  CALL FUNCTION 'EDI_DOCUMENT_CLOSE_READ'
    EXPORTING
      document_number   = gv_docnum
    EXCEPTIONS
      document_not_open = 1
      parameter_error   = 2
      OTHERS            = 3.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    RETURN.
  ENDIF.

* Determine what Segment Number was in error
*   by using the IDoc number & Statyp as Error
* Retrieve the latest Idoc Status record
* Getting Segment name based on Segment number
  READ TABLE lt_edidd INTO ls_edidd INDEX gs_edids-segnum.
  IF sy-subrc = 0.
* Scenario: the old PO number was bad (not valid in SAP or blank)
    IF ls_edidd-segnam = gc_e1edl43.
* This means that the PO number was invalid and we just have to:
*	Replace the E1EDL43-BELNR
      lv_tabix43 = gs_edids-segnum. "format itab index
      CLEAR: ls_e1edl43.
      ls_e1edl43-qualf = gc_v.
      ls_e1edl43-belnr = gv_new_ebeln.
      ls_edidd-sdata    = ls_e1edl43.
      MODIFY lt_edidd FROM ls_edidd INDEX lv_tabix43
        TRANSPORTING sdata.

** Getting Data records for Idoc
      LOOP AT lt_edidd INTO ls_edidd.
        CLEAR ls_edidd-docnum.
        MOVE-CORRESPONDING ls_edidd TO ls_data_rec40.
        APPEND ls_data_rec40 TO lt_data_rec40.
      ENDLOOP.
** Getting Control record for Idoc
      CLEAR : ls_edidc-docnum,ls_edidc-status.
      MOVE-CORRESPONDING ls_edidc TO ls_control_rec40.
      ls_control_rec40-idoctyp = ls_edidc-idoctp.
*  Call IDOC_INBOUND_SINGLE to kick off a new idoc
*   with the new PO number
      CALL FUNCTION 'IDOC_INBOUND_SINGLE'
        EXPORTING
          pi_idoc_control_rec_40        = ls_control_rec40
          pi_do_commit                  = gc_x
        IMPORTING
          pe_idoc_number                = lv_idoc_number
          pe_error_prior_to_application = lv_error_appl
        TABLES
          pt_idoc_data_records_40       = lt_data_rec40
        EXCEPTIONS
          idoc_not_saved                = 1
          OTHERS                        = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        RETURN.
      ELSE.
        CLEAR :ls_idoc_status,lt_idoc_status.
*  Add a New status record as 70 to the Old idoc
        ls_idoc_status-status = '70'.
        ls_idoc_status-msgv1 = lv_idoc_number.
        APPEND ls_idoc_status TO lt_idoc_status.
        CALL FUNCTION 'IDOC_STATUS_WRITE_TO_DATABASE'
          EXPORTING
            idoc_number               = gv_docnum
          TABLES
            idoc_status               = lt_idoc_status
          EXCEPTIONS
            idoc_foreign_lock         = 1
            idoc_not_found            = 2
            idoc_status_records_empty = 3
            idoc_status_invalid       = 4
            db_error                  = 5
            OTHERS                    = 6.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                  WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
          RETURN.
        ENDIF.
      ENDIF.

*Scenario: there was never an E1EDL43 segment (with PO qualifier #V#)
*for the corresponding Superior Delivery Item segment E1EDL24
    ELSEIF ls_edidd-segnam = gc_e1edl24.
      CLEAR : lt_idocsyn,lt_idocsyn1,lv_flag,lv_index.

***--- Mpathek Comment Start----******
*** Getting Sequence of Segment
*      SELECT *
*        FROM idocsyn
*        INTO TABLE lt_idocsyn
*        WHERE idoctyp = ls_edidc-idoctp
*          AND parseg  = gc_e1edl24.
*** Getting Sequence of Segment e1edl43
*      READ TABLE lt_idocsyn INTO ls_idocsyn WITH KEY segtyp = gc_e1edl43.
*      lv_posno = ls_idocsyn-nr.
*** Getting Sequence of Segment which greater than Segment e1edl43
*      LOOP AT lt_idocsyn INTO ls_idocsyn WHERE nr > lv_posno.
*        APPEND ls_idocsyn TO lt_idocsyn1.
*      ENDLOOP.
*** Getting Sequence of Segment which smaller than Segment e1edl43
*      DELETE lt_idocsyn WHERE nr >= lv_posno.
*      SORT lt_idocsyn DESCENDING BY nr.
*
*      LOOP AT lt_edidd INTO ls_edidd WHERE segnam = gc_e1edl24.
*        ls_check-flag = ''.
*        ls_check-segnum = ls_edidd-segnum.
*        APPEND ls_check TO lt_check.
*      ENDLOOP.

*** Checking Sequence of Segments which greater than Segment e1edl43
*      LOOP AT lt_idocsyn1 INTO ls_idocsyn.
*        LOOP AT lt_edidd INTO ls_edidd WHERE segnam = gc_e1edl24.
*          READ TABLE lt_edidd INTO ls_edidd2 WITH KEY segnam = gc_e1edl43
*          psgnum = ls_edidd-segnum.
*          CHECK sy-subrc <> 0.
*          LOOP AT lt_edidd INTO ls_edidd1
*          WHERE segnam = ls_idocsyn-segtyp
*            AND psgnum = ls_edidd-segnum.
*          ENDLOOP.
*          IF sy-subrc = 0.
*            IF lv_index IS INITIAL.
*              lv_index = ls_edidd1-segnum - 1.
*            ENDIF.

**Inser brand new E1EDL43 segment with a qualifier #V#
*          ls_edidd-psgnum  = ls_edidd-segnum.
*          ls_edidd-hlevel  = ls_edidd-hlevel + 1.
*          ls_edidd-segnam  = gc_e1edl43.
*          ls_edidd-segnum  = ls_edidd1-segnum - 1.
*          ls_e1edl43-qualf = gc_v.
*          ls_e1edl43-belnr = gv_new_ebeln.
*          ls_edidd-sdata   = ls_e1edl43.
*          APPEND ls_edidd TO lt_edidd.
*          lv_flag = 'X'.
*          ls_check-flag = 'X'.
*          MODIFY lt_check FROM ls_check
*          TRANSPORTING flag
*          WHERE segnum = ls_check-segnum.
*          ENDIF.
*        ENDLOOP.
*        CHECK lv_flag IS NOT INITIAL.
*        EXIT.
*      ENDLOOP.
*
*** Checking Sequence of Segments which smaller than Segment e1edl43
*      CLEAR lv_flag.
*      LOOP AT lt_idocsyn INTO ls_idocsyn.
*        LOOP AT lt_edidd INTO ls_edidd WHERE segnam = gc_e1edl24.
*          READ TABLE lt_edidd INTO ls_edidd2 WITH KEY segnam = gc_e1edl43
*          psgnum = ls_edidd-segnum.
*          CHECK sy-subrc <> 0.
*          READ TABLE lt_check INTO ls_check
*          WITH KEY segnum = ls_edidd-segnum flag = ''.
*          CHECK sy-subrc = 0.
*          LOOP AT lt_edidd INTO ls_edidd1
*          WHERE segnam = ls_idocsyn-segtyp
*            AND psgnum = ls_edidd-segnum.
*          ENDLOOP.
*          IF sy-subrc = 0.
*            IF lv_index IS INITIAL.
*              lv_index = ls_edidd1-segnum + 1.
*            ENDIF.
**Inser brand new E1EDL43 segment with a qualifier #V#
*            ls_edidd-psgnum  = ls_edidd-segnum.
*            ls_edidd-hlevel  = ls_edidd-hlevel + 1.
*            ls_edidd-segnam  = gc_e1edl43.
*            ls_edidd-segnum  = ls_edidd1-segnum + 1.
*            ls_e1edl43-qualf = gc_v.
*            ls_e1edl43-belnr = gv_new_ebeln.
*            ls_edidd-sdata   = ls_e1edl43.
*            APPEND ls_edidd TO lt_edidd.
*            lv_flag = 'X'.
*            ls_check-flag = 'X'.
*            MODIFY lt_check FROM ls_check
*            TRANSPORTING flag
*            WHERE segnum = ls_check-segnum.
*          ENDIF.
*        ENDLOOP.
*        CHECK lv_flag IS NOT INITIAL.
*        EXIT.
*      ENDLOOP.
*
*** Inserting the segment e1edl43 If Segment e1edl24
**   doesn't have child segment
*      LOOP AT lt_edidd INTO ls_edidd WHERE segnam = gc_e1edl24.
*        READ TABLE lt_edidd INTO ls_edidd2 WITH KEY segnam = gc_e1edl43
*        psgnum = ls_edidd-segnum.
*        CHECK sy-subrc <> 0.
*        lv_index = sy-tabix.
*        READ TABLE lt_check INTO ls_check
*        WITH KEY segnum = ls_edidd-segnum flag = ''.
*        CHECK sy-subrc = 0.
**Inser brand new E1EDL43 segment with a qualifier #V#
*        ls_edidd-psgnum  = ls_edidd-segnum.
*        ls_edidd-hlevel  = ls_edidd-hlevel + 1.
*        ls_edidd-segnam  = gc_e1edl43.
*        ls_edidd-segnum  = ls_edidd-segnum + 1.
*        ls_e1edl43-qualf = gc_v.
*        ls_e1edl43-belnr = gv_new_ebeln.
*        ls_edidd-sdata   = ls_e1edl43.
*        APPEND ls_edidd TO lt_edidd.
*        IF lv_index IS INITIAL.
*          lv_index = lv_index + 1.
*        ENDIF.
*        ls_check-flag = 'X'.
*        MODIFY lt_check FROM ls_check
*        TRANSPORTING flag
*        WHERE segnum = ls_edidd-segnum.
*      ENDLOOP.
*
*      CLEAR lv_flag.
*      SORT lt_edidd BY segnum.
*      CLEAR lv_count1.
*** Getting number of records from final IDoc
*      DESCRIBE TABLE lt_edidd LINES lv_count1.
*      lv_diff =  lv_count1 -  lv_count.
*
*      CLEAR : lv_count,lv_count1.

*** Formatting Segment Sequence number
*      LOOP AT lt_edidd INTO ls_edidd FROM lv_index.
*
*        IF ls_edidd-segnam EQ gc_e1edl43.
*          IF lv_count1 = 1.
*            lv_count = 1.
*          ELSE.
*            lv_count = lv_count + 1.
*          ENDIF.
*        ELSEIF lv_count IS INITIAL.
*          lv_count = lv_count + 1.
*        ENDIF.
*
*        lv_count1 = lv_count1 + 1.
*
*        IF ls_edidd-segnam EQ gc_e1edl43.
*          IF lv_count <> 1.
*            ls_edidd-segnum  = ls_edidd-segnum + 1.
*            MODIFY lt_edidd FROM ls_edidd INDEX
*            sy-tabix TRANSPORTING segnum.
*          ENDIF.
*        ELSE.
*          ls_edidd-segnum  = ls_edidd-segnum + lv_count.
*          MODIFY lt_edidd FROM ls_edidd INDEX
*          sy-tabix TRANSPORTING segnum.
*        ENDIF.
*      ENDLOOP.
*      SORT lt_edidd BY segnum.
***** Comment Start Mpathek ********

****** Mpathek Logic start  *******
      REFRESH gt_edidd_temp.
      gt_edidd_temp = lt_edidd.
      PERFORM inser_e1edl43.
      lt_edidd  = gt_edidd_temp.
      REFRESH gt_edidd_temp.
****** Mpathek Logic End   ********


** Getting Data records for Idoc
      LOOP AT lt_edidd INTO ls_edidd1.
        CLEAR: ls_edidd1-docnum.
        MOVE-CORRESPONDING ls_edidd1 TO ls_data_rec40.
        APPEND ls_data_rec40 TO lt_data_rec40.
      ENDLOOP.

** Getting Control record for Idoc
      CLEAR : ls_edidc-docnum,ls_edidc-status.
      MOVE-CORRESPONDING ls_edidc TO ls_control_rec40.
      ls_control_rec40-idoctyp = ls_edidc-idoctp.
*  Call IDOC_INBOUND_SINGLE to kick off a new idoc
*   with the new PO number
      CALL FUNCTION 'IDOC_INBOUND_SINGLE'
        EXPORTING
          pi_idoc_control_rec_40        = ls_control_rec40
          pi_do_commit                  = gc_x
        IMPORTING
          pe_idoc_number                = lv_idoc_number
          pe_error_prior_to_application = lv_error_appl
        TABLES
          pt_idoc_data_records_40       = lt_data_rec40
        EXCEPTIONS
          idoc_not_saved                = 1
          OTHERS                        = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        RETURN.
      ELSE.
        CLEAR :ls_idoc_status,lt_idoc_status.
*  Add a New status record as 70 to the Old idoc
        ls_idoc_status-status = '70'.
        ls_idoc_status-msgv1 = lv_idoc_number.
        APPEND ls_idoc_status TO lt_idoc_status.
        CALL FUNCTION 'IDOC_STATUS_WRITE_TO_DATABASE'
          EXPORTING
            idoc_number               = gv_docnum
          TABLES
            idoc_status               = lt_idoc_status
          EXCEPTIONS
            idoc_foreign_lock         = 1
            idoc_not_found            = 2
            idoc_status_records_empty = 3
            idoc_status_invalid       = 4
            db_error                  = 5
            OTHERS                    = 6.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                  WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
          RETURN.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " CHANGE_PO_NUMBER
*&---------------------------------------------------------------------*
*&      Form  INSER_E1EDL43
*&---------------------------------------------------------------------*
*      Insert E1EDL43 segment after E1EDL15 under segment E1EDL24
*----------------------------------------------------------------------*

FORM inser_e1edl43 .

  DATA : lv_tabix     TYPE sy-tabix,
         ls_edidd     TYPE edidd,
         ls_edidd2    TYPE edidd,
         ls_e1edl43   TYPE e1edl43,
         lv_flag      TYPE char1,
         lv_segnum(6) TYPE n.

  FIELD-SYMBOLS :
               <ls_edidd> TYPE edidd.

  CONSTANTS : lc_e1edl15  TYPE edilsegtyp VALUE 'E1EDL15'.

* Check E1EDL43 segment is available under E1EDL24,
* if not insert it after E1EDL15 under E1EDL24

  LOOP AT gt_edidd_temp INTO ls_edidd WHERE segnam = gc_e1edl24.
* Read tabix to insert E1EDL43 segment after last E1EDL15 segment
*     under E1EDL24 segment

    lv_tabix = sy-tabix.
    READ TABLE gt_edidd_temp INTO ls_edidd2 WITH KEY segnam = gc_e1edl43
    psgnum = ls_edidd-segnum.
    CHECK sy-subrc <> 0.
* To read index where we need to insert E1edl43 segment.
    lv_tabix  = lv_tabix  + 1.
    CLEAR ls_edidd2.
* Read exact Sy-tabix where we need to insert E1EDL43 segment

    LOOP AT gt_edidd_temp INTO ls_edidd2 FROM lv_tabix.
      IF ls_edidd2-segnam = lc_e1edl15.                     "'E1EDL15'.
        lv_tabix  = lv_tabix  + 1.
      ELSE.
        EXIT.
      ENDIF.
    ENDLOOP.

*Insert brand new E1EDL43 segment with a qualifier #V#
    ls_edidd-psgnum  = ls_edidd-segnum.
    ls_edidd-hlevel  = ls_edidd-hlevel + 1.
    ls_edidd-segnam  = gc_e1edl43.
    ls_edidd-segnum  = ls_edidd-segnum + 1.
    ls_e1edl43-qualf = gc_v.
    ls_e1edl43-belnr = gv_new_ebeln.
    ls_edidd-sdata   = ls_e1edl43.
    INSERT ls_edidd INTO gt_edidd_temp  INDEX lv_tabix.
    CLEAR lv_tabix.
    EXIT.
  ENDLOOP.
* Updating correct segment Num.
  LOOP AT gt_edidd_temp ASSIGNING <ls_edidd>.
    <ls_edidd>-segnum = sy-tabix.
  ENDLOOP.
  UNASSIGN <ls_edidd>.
ENDFORM.                    " INSER_E1EDL43

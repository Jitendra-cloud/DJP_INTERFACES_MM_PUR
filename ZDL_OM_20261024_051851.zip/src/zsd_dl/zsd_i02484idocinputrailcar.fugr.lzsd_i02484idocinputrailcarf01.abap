*----------------------------------------------------------------------*
***INCLUDE LZSD_I02484IDOCINPUTRAILCARF01 .
*----------------------------------------------------------------------*
* Change History:                                                      *
* Programmer    Date       Req. #                 Action               *
* ==========  ========   ==========   ===============================  *
* CCHERUP     10/30/2007 EDVK958228   TPR# 00245 Validating Equip Id   *
*                                     pushing Idoc status to 51 for    *
*                                     invalid equip id  and also check *
*                                     to see whether equipment exists  *
*                                     on any outbound shipment. If yes *
*                                     push idoc to 53                  *
* CCHERUP     04/25/2008 E0VK938889   CHG86925 - Resequence Validation *
*                                     changed idoc status from 53 to 68*
*                                     in "validate_idoc_data" form     *
*______________________________________________________________________*
************************************************************************

*&---------------------------------------------------------------------*
*&      Form  convert_scac
*&---------------------------------------------------------------------*
*  The SCAC code will be converted to a  vendor code.
*----------------------------------------------------------------------*

FORM convert_scac TABLES   idoc_data STRUCTURE edidd
                  CHANGING lv_flag
                           lv_msg.

  DATA: lv_e1edt20 TYPE e1edt20.


  READ TABLE idoc_data WITH KEY segnam = 'E1EDT20'.
  CHECK sy-subrc EQ 0.

  lv_e1edt20 = idoc_data-sdata.

*  SCAC not provided , set status to 51 and Exit.
  IF lv_e1edt20-exti2 IS INITIAL.
    CLEAR: lv_flag , lv_msg.

    lv_flag = 'X'.
    lv_msg = 'No SCAC provided'(005).
    EXIT.

  ELSE.

* Get Vendor number for the given SCAC code
    CLEAR : gv_carrier.
    SELECT SINGLE lifnr INTO gv_carrier FROM lfa1
                        WHERE scacd = lv_e1edt20-exti2. "Standard
    "carrier access code
    IF gv_carrier IS INITIAL.
      CLEAR: lv_flag , lv_msg.

      lv_flag = 'X'.
      lv_msg  = 'Invalid SCAC code has been presented'(006).
      EXIT.
    ENDIF.
  ENDIF.
ENDFORM.                    " convert_scac

*&---------------------------------------------------------------------*
*&      Form  convert_splc
*&---------------------------------------------------------------------*
* The SPLC will be converted to a transportation planning point
*----------------------------------------------------------------------*

FORM convert_splc TABLES idoc_data STRUCTURE edidd.

  DATA: lv_e1edt20 TYPE e1edt20.
  DATA: lx_zzxrefdetail TYPE zzxrefdetail.

  READ TABLE idoc_data
    WITH KEY segnam = 'E1EDT20'.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.

  lv_e1edt20 = idoc_data-sdata.

* Get data from zsp_value (SP Value Table - Development)
  CLEAR gv_tpp.
  SELECT SINGLE fieldvalue
    INTO gv_tpp FROM zsp_value
   WHERE pgrmid    = 'SPLC_LOOKUP'
     AND fieldname = lv_e1edt20-signi.
  IF gv_tpp IS INITIAL.                                     " <<RLW01+

    CLEAR lx_zzxrefdetail.                                  " <<RLW01+
    SELECT *
      FROM zzxrefdetail
      UP TO 1 ROWS
      INTO lx_zzxrefdetail
     WHERE zzgroup    = 'DELIVER'
       AND zzgroupset = 'SPLC_LOOKUP'
       AND zzkey1     = lv_e1edt20-signi.                   " <<RLW01+
    ENDSELECT.                                              " <<RLW01+
    IF sy-subrc = 0.                                        " <<RLW01+
      gv_tpp = lx_zzxrefdetail-zzvalue1.                    " <<RLW01+
    ELSE.
      CLEAR gv_splc.                                        " <<RLW01+
      gv_splc = lv_e1edt20-signi.                           " <<RLW01+
    ENDIF.                                                  " <<RLW01+

  ENDIF.                                                    " <<RLW01+

ENDFORM.                    " convert_splc

*&---------------------------------------------------------------------*
*&      Form  PROCESS_DIVERSION                             " <<RLW01+
*&---------------------------------------------------------------------*
*       Check if this is a diversion. If it is, delete the open
*   shipment.
*----------------------------------------------------------------------*
FORM process_diversion TABLES idoc_data STRUCTURE edidd.    " <<RLW01+

*  DATA: lx_vttk TYPE vttk.
*        lt_vttk TYPE vttk OCCURS 0.
  DATA: BEGIN OF lt_vttk OCCURS 0,
          tknum LIKE vttk-tknum,
        END OF lt_vttk.

  DATA:
*        l_tplst TYPE vttk-tplst,
        l_count TYPE i.

  IF NOT gv_equip_id IS INITIAL.

* Check if there are shipments that include this railcar, for inbound
*    shipment type 'ZRLI'
    REFRESH lt_vttk.
* Begin of changes for TPR-00154, for improving performance, select only
* the rquired entries from the table VTTK, instead of selecting all the
* Rail shipments, sort and delete the unwanted shipments.
* We should get only one shipment
* that meet the criteria as per Mark Tatham
*    SELECT *
*          FROM vttk
*          INTO TABLE lt_vttk
*         WHERE shtyp = c_shtyp_zrli.
    SELECT tknum
          FROM vttk
          INTO TABLE lt_vttk
         WHERE shtyp = gc_shtyp_zrli
         AND   sttrg = '6'
         AND   signi = gv_equip_id
         AND   stten = space.

    IF sy-subrc = 0.

** Finish filtering by criteria
*      SORT lt_vttk BY signi.
*      DELETE lt_vttk WHERE signi <> l_equip.
*      SORT lt_vttk BY dpten.
*      DELETE lt_vttk WHERE NOT dpten IS INITIAL.
*      SORT lt_vttk BY tknum.

* Count the total records returned
      CLEAR l_count.
      DESCRIBE TABLE lt_vttk LINES l_count.

* If there is at least 1 record returned, this is a Diversion.
      IF l_count > 0.

*   Delete and Recreate all relevant shipments returned
*        CLEAR lx_vttk.
        LOOP AT lt_vttk.    " INTO lx_vttk.
          PERFORM delete_shipment USING lt_vttk-tknum
                               CHANGING gv_flg_delete_fail.
        ENDLOOP.

      ENDIF. " l_count > 0.

    ENDIF. " sy-subrc = 0.

  ENDIF. " NOT l_equip IS INITIAL.

* If an attempt was made to delete a diversion shipment, and failed
* Write to the Application Log:
  IF NOT gv_flg_delete_fail IS INITIAL.
    PERFORM write_err_applog TABLES t_log
                           CHANGING gv_applog_ref.
  ENDIF.

ENDFORM. " PROCESS_DIVERSION.

*&---------------------------------------------------------------------*
*&      Form  delete_shipment                          " <<RLW01+
*&---------------------------------------------------------------------*
*        CALL FUNCTION 'RV_SHIPMENT_VIEW'
*        CALL FUNCTION 'SD_SHIPMENT_DELETE'
*        CALL FUNCTION 'SD_SHIPMENTS_SAVE'
*----------------------------------------------------------------------*
*      -->LX_VTTK-TKNUM  Shipment Number
*----------------------------------------------------------------------*
FORM delete_shipment USING lp_tknum
                  CHANGING l_flg_delete_fail.               " <<RLW01+

  DATA :  ls_vttkvb    LIKE vttkvb.

  DATA :  lt_vttp      LIKE  vttpvb   OCCURS 0  WITH HEADER LINE,
          lt_vtrlk     LIKE  vtrlk    OCCURS 0  WITH HEADER LINE,
          lt_vtrlp     LIKE  vtrlp    OCCURS 0  WITH HEADER LINE,
          lt_vtts      LIKE  vttsvb   OCCURS 0  WITH HEADER LINE.

  DATA :  lt_xvttk     LIKE  vttkvb   OCCURS 1  WITH HEADER LINE,
          lt_yvttk     LIKE  vttkvb   OCCURS 1  WITH HEADER LINE,
                                                      " Shipment Header
          lt_xvttp     LIKE  vttpvb   OCCURS 0  WITH HEADER LINE,
          lt_yvttp     LIKE  vttpvb   OCCURS 0  WITH HEADER LINE,
                                                      " Shipment Items
          lt_xvtts     LIKE  vttsvb   OCCURS 0  WITH HEADER LINE,
          lt_yvtts     LIKE  vttsvb   OCCURS 0  WITH HEADER LINE,
                                                      " Shipment Stages
          lt_xvtsp     LIKE  vtspvb   OCCURS 0  WITH HEADER LINE,
          lt_yvtsp     LIKE  vtspvb   OCCURS 0  WITH HEADER LINE,
                                                      " Stage/Item rel.
          lt_xvbpa     LIKE  vbpavb   OCCURS 0  WITH HEADER LINE,
          lt_yvbpa     LIKE  vbpavb   OCCURS 0  WITH HEADER LINE,
                                                      " Partners
          lt_xvtfa     LIKE  vtfavb   OCCURS 0  WITH HEADER LINE,
          lt_yvtfa     LIKE  vtfavb   OCCURS 0  WITH HEADER LINE,
                                                      " Flow
          lt_xvbadr    LIKE  sadrvb   OCCURS 0  WITH HEADER LINE,
          lt_yvbadr    LIKE  sadrvb   OCCURS 0  WITH HEADER LINE.
  " Addresses

* Function call to bring all the necessary data related to a shipment
  CALL FUNCTION 'RV_SHIPMENT_VIEW'
    EXPORTING
      shipment_number             = lp_tknum
      option_tvtk                 = 'X'
      option_ttds                 = 'X'
      language                    = sy-langu
      option_items                = 'X'
      option_minimized_item_data  = ' '     "temporary full read B
      option_sales_orders         = ' '
      option_export_data          = ' '
      option_stawn_read           = 'X'     "read comm.codes
      option_segments             = 'X'
      option_partners             = 'X'
      option_messages             = 'X'
      option_packages             = ' '
      option_package_dialog       = 'X'
      option_flow                 = 'X'
      option_delivery_lock        = 'X'
      option_authority_check      = 'X'
      activity                    = 'V'  "Transc. type - Change
      option_no_refresh           = ' '
      option_ignore_missing_deliv = 'X'
    IMPORTING
      f_vttkvb                    = ls_vttkvb
    TABLES
      f_vttp                      = lt_vttp
      f_trlk                      = lt_vtrlk
      f_trlp                      = lt_vtrlp
      f_vtts                      = lt_vtts
      f_vtsp                      = lt_xvtsp
      f_vbpa                      = lt_xvbpa
      f_vbadr                     = lt_xvbadr
      f_vtfa                      = lt_xvtfa
      f_yvtfa                     = lt_yvtfa
    EXCEPTIONS
      not_found                   = 1
      delivery_missing            = 3
      OTHERS                      = 99.
  IF sy-subrc EQ 0.
    CLEAR ls_vttkvb-pkstk.
    MOVE-CORRESPONDING ls_vttkvb TO lt_xvttk.
    APPEND lt_xvttk.
    lt_yvttk[] = lt_xvttk[].
    lt_xvttp[]  = lt_yvttp[]  = lt_vttp[].
    lt_xvtts[]  = lt_yvtts[]  = lt_vtts[].
    lt_yvtsp[]  = lt_xvtsp[].
    lt_yvtfa[]  = lt_xvtfa[].
    lt_yvbpa[]  = lt_xvbpa[].
    lt_yvbadr[] = lt_xvbadr[].

* Function call to delete the shipment
    CALL FUNCTION 'SD_SHIPMENT_DELETE'
      EXPORTING
        i_tknum                 = lp_tknum
      TABLES
        c_xvttk                 = lt_xvttk
        c_yvttk                 = lt_yvttk
        c_xvttp                 = lt_xvttp
        c_yvttp                 = lt_yvttp
        c_xvtts                 = lt_xvtts
        c_yvtts                 = lt_yvtts
        c_xvtsp                 = lt_xvtsp
        c_yvtsp                 = lt_yvtsp
        c_xvtfa                 = lt_xvtfa
        c_yvtfa                 = lt_yvtfa
        c_xvbpa                 = lt_xvbpa
        c_yvbpa                 = lt_yvbpa
        c_xvbadr                = lt_xvbadr
        c_yvbadr                = lt_yvbadr
      EXCEPTIONS
        no_shipment_number      = 1
        invalid_shipment_number = 2
        shipment_is_packed      = 3
        shipment_has_costs      = 4
        OTHERS                  = 5.
    IF sy-subrc EQ 0.
* >> Begin of Change TPR22744 CCHERUP 02/08/08 - BW Extractor fix
      DELETE lt_yvttp  WHERE updkz IS INITIAL.
      DELETE lt_yvtts  WHERE updkz IS INITIAL.
      DELETE lt_yvtsp  WHERE updkz IS INITIAL.
      DELETE lt_yvbpa  WHERE updkz IS INITIAL.
      DELETE lt_yvbadr WHERE updkz IS INITIAL.
      DELETE lt_yvtfa  WHERE updkz IS INITIAL.
* << End of Change TPR22744 CCHERUP 02/08/08 - BW Extractor fix
      CALL FUNCTION 'SD_SHIPMENTS_SAVE'
        EXPORTING
          i_transaktionstyp    = 'V'
          i_upd_deadlines      = 'X'
          i_upd_texts          = 'X'
          i_upd_shipping_units = 'X'
          i_upd_output         = 'X'
          i_opt_update_task    = 'X'
        TABLES
          i_xvttk              = lt_xvttk
          i_yvttk              = lt_yvttk
          i_xvttp              = lt_xvttp
          i_yvttp              = lt_yvttp
          i_vtrlk              = lt_vtrlk
          i_vtrlp              = lt_vtrlp
          i_xvtts              = lt_xvtts
          i_yvtts              = lt_yvtts
          i_xvtsp              = lt_xvtsp
          i_yvtsp              = lt_yvtsp
          i_xvbpa              = lt_xvbpa
          i_yvbpa              = lt_yvbpa
          i_xsadr              = lt_xvbadr
          i_ysadr              = lt_yvbadr
          i_xvtfa              = lt_xvtfa
          i_yvtfa              = lt_yvtfa
        EXCEPTIONS
          no_change            = 1
          delivery_split_error = 2
          OTHERS               = 3.
      IF sy-subrc EQ 0.
        COMMIT WORK AND WAIT.
        EXIT.
      ENDIF.
    ENDIF.
  ENDIF.

  CLEAR x_log.
  x_log-msgty = 'E'.
  x_log-msgid = 'ZSD_DL_I02484'.                            " <<RLW01+
  x_log-msgno = '000'.
  x_log-msgv1 = 'Diversion Shipment'(l01).
  x_log-msgv2 = lp_tknum.
  x_log-msgv3 = 'was not able to be deleted for the'(l02).
  x_log-msgv4 = 'following reason(s):'(l03).
  APPEND x_log TO t_log.

  CLEAR x_log.
  x_log-msgty = 'E'.
  x_log-msgid = sy-msgid.
  x_log-msgno = sy-msgno.
  x_log-msgv1 = sy-msgv1.
  x_log-msgv2 = sy-msgv2.
  x_log-msgv3 = sy-msgv3.
  x_log-msgv4 = sy-msgv4.
  APPEND x_log TO t_log.

  l_flg_delete_fail = 'X'.

ENDFORM. " delete_shipment

*&---------------------------------------------------------------------*
*&      Form  WRITE_APP_LOG                                 " <<RLW01+
*&---------------------------------------------------------------------*
*       Write T_LOG program logging to application log
*----------------------------------------------------------------------*
*      -->T_LOG      Program Log
*----------------------------------------------------------------------*
FORM write_err_applog TABLES t_log LIKE t_log
                    CHANGING gv_applog_ref.                 " <<RLW01+

  CONSTANTS: c_app_log_object TYPE balobj_d  VALUE 'ZDL_INTERFACE',
             c_app_log_subobj TYPE balsubobj VALUE 'ZDL_INBNDRAIL'.

* Multiple line Application Log Data
  DATA: lx_apploghead TYPE bal_s_log.

  DATA: l_extid TYPE balnrext.

  CLEAR: lx_apploghead.

* Build Application Logging header:
  lx_apploghead-alprog    = sy-repid.
  lx_apploghead-aluser    = sy-uname.
  lx_apploghead-object    = c_app_log_object.
  lx_apploghead-subobject = c_app_log_subobj.
  lx_apploghead-extnumber = 'I2484'.

* Generate the entire application log
  CALL FUNCTION 'Z_GEN_APP_LOG_MULT'
    EXPORTING
      is_log_header = lx_apploghead
    IMPORTING
      if_log_extid  = l_extid
    TABLES
      it_messages   = t_log.

  CONCATENATE 'See Application Log EXTID:' l_extid
         INTO gv_applog_ref.
  CONDENSE gv_applog_ref.

ENDFORM. " WRITE_APP_LOG

*&---------------------------------------------------------------------*
*&      Form  get_stage_points
*&---------------------------------------------------------------------*
* The transportation planning point will be used to look up the points *
* for the stage.
*  MGILL   08/27/13  - Change vstel (shipping Point) to werks (plant)
*----------------------------------------------------------------------*
FORM get_stage_points .

* Routes: Transportation Connection Points
  CLEAR : gv_point.
  SELECT SINGLE knote INTO gv_point FROM tvkn
                      WHERE werks = gv_tpp. "Plant          MG 08/27/13

ENDFORM.                    " get_stage_points


*&---------------------------------------------------------------------*
*&      Form  get_time_zone                                 " <<RLW01+
*&---------------------------------------------------------------------*
*       Get time zone
*----------------------------------------------------------------------*
*  -->  gv_tpp " Shipping Point
*  <--  gv_tz  " Time zone of the shipping point
*----------------------------------------------------------------------*
FORM get_time_zone USING lv_tpp TYPE tvkn-vstel
                CHANGING lv_tz  TYPE adrc-time_zone.        " <<RLW01+

  DATA: lx_t001w LIKE t001w,
        lx_adrc LIKE adrc,
        lt_adrc LIKE adrc OCCURS 0.

* Retrieve Plant address number
  CLEAR lx_t001w.
  SELECT SINGLE *
    FROM t001w
    INTO lx_t001w
    WHERE werks = lv_tpp.
  IF sy-subrc = 0.

* Retrieve address details
    REFRESH lt_adrc.
    SELECT *
      FROM adrc
      INTO TABLE lt_adrc
      WHERE addrnumber = lx_t001w-adrnr.
    IF sy-subrc = 0.

* Filter out invalid dates
      SORT lt_adrc BY date_to ASCENDING.
      DELETE lt_adrc WHERE date_to < sy-datum.
      SORT lt_adrc BY date_from ASCENDING.
      DELETE lt_adrc WHERE date_from > sy-datum.

      IF NOT lt_adrc[] IS INITIAL.
        SORT lt_adrc BY date_from addrnumber.
        CLEAR lx_adrc.
        READ TABLE lt_adrc INDEX 1 INTO lx_adrc.
        lv_tz = lx_adrc-time_zone.
      ENDIF.

    ENDIF.

  ENDIF.

ENDFORM.                    " get_time_zone

*&---------------------------------------------------------------------*
*&      Form  groom_idoc
*&---------------------------------------------------------------------*
*Substitute values in the IDoc with values determined in this function
*module
*----------------------------------------------------------------------*

FORM groom_idoc TABLES idoc_data STRUCTURE edidd.

  DATA: lv_e1adrm4 TYPE e1adrm4,
        lv_e1adre4 TYPE e1adre4,
        lv_e1edt44 TYPE e1edt44,
        lv_e1edt20 TYPE e1edt20,
        lv_e1adrm7 TYPE e1adrm7,                            " <<RLW01+
        lv_e1edt10 TYPE e1edt10.                            " <<RLW01+

  CLEAR: lv_e1adrm4,
         lv_e1adre4,
         lv_e1edt44,
         lv_e1edt20,                                        " <<RLW01+
         lv_e1adrm7,                                        " <<RLW01+
         lv_e1edt10.                                        " <<RLW01+

  LOOP AT idoc_data.
    CASE idoc_data-segnam.

      WHEN 'E1EDT20'. "IDoc: Shipment

* >> Begin of TPR# 00245 - CCHERUP - 10/30
        lv_e1edt20                   = idoc_data-sdata.
        lv_e1edt20-signi             = gv_equip_id.
        lv_e1edt20-exti1             = ' '.
        "PERFORM format_eq_id CHANGING lv_e1edt20-signi.     " <<RLW01+
* << End of TPR# 00245 - CCHERUP - 10/30
        CLEAR lv_e1edt20-route.                             " <<RLW01+
        CONCATENATE 'IN' gv_tpp INTO lv_e1edt20-route.      " <<RLW01+
        idoc_data-sdata              = lv_e1edt20.

        MODIFY idoc_data.

      WHEN 'E1ADRM4'. "Central Address Segment Group, Main Segment

        lv_e1adrm4                   = idoc_data-sdata.

        IF lv_e1adrm4-partner_q      = 'OTP'.
          lv_e1adrm4-partner_id      = gv_tpp.
        ELSEIF lv_e1adrm4-partner_q  = 'SP'.
          lv_e1adrm4-partner_id      = gv_carrier.
        ENDIF.

        idoc_data-sdata              = lv_e1adrm4.
        MODIFY idoc_data.

      WHEN 'E1ADRE4'. "Central Address Segment Group, Additional Data
        "Segment

        lv_e1adre4                   = idoc_data-sdata.

        IF lv_e1adre4-extend_q       = '305'.
          lv_e1adre4-extend_d        = gv_tpp.
        ELSEIF lv_e1adre4-extend_q   = '300'.
          lv_e1adre4-extend_d        = gv_carrier.
        ENDIF.

        idoc_data-sdata              = lv_e1adre4.
        MODIFY idoc_data.

      WHEN 'E1EDT44'. "Shipment stages point

        lv_e1edt44                   = idoc_data-sdata.

        lv_e1edt44-knote             = gv_point.
*        lv_e1edt44-vstel             = gv_tpp.             " <<RLW01-

        idoc_data-sdata              = lv_e1edt44.
        MODIFY idoc_data.

      WHEN 'E1ADRM7'.                                       " <<RLW01+

        lv_e1adrm7 = idoc_data-sdata.                       " <<RLW01+

        IF lv_e1adrm7-partner_q = 'SP'.                     " <<RLW01+
          lv_e1adrm7-partner_id = gv_carrier.               " <<RLW01+
        ENDIF.                                              " <<RLW01+

        idoc_data-sdata       = lv_e1adrm7.                 " <<RLW01+
        MODIFY idoc_data.                                   " <<RLW01+

      WHEN 'E1EDT10'.

        lv_e1edt10 = idoc_data-sdata.                       " <<RLW01+

*  the time zone should then be placed into the following segment if
*    they are not already populated.

        IF  lv_e1edt10-tzone_end IS INITIAL.                " <<RLW01+
          lv_e1edt10-tzone_end = gv_tz.                     " <<RLW01+
        ENDIF.                                              " <<RLW01+

        IF  lv_e1edt10-tzone_beg IS INITIAL.                " <<RLW01+
          lv_e1edt10-tzone_beg = gv_tz.                     " <<RLW01+
        ENDIF.                                              " <<RLW01+

        idoc_data-sdata       = lv_e1edt10.                 " <<RLW01+
        MODIFY idoc_data.                                   " <<RLW01+

    ENDCASE.
  ENDLOOP.

ENDFORM.                    " groom_idoc

*&---------------------------------------------------------------------*
*&      Form  format_eq_id " <<RLW01+
*&---------------------------------------------------------------------*
*       Format equipment id using function module
*             /SAPRCX/EQUIP_ID_VALIDATE
*----------------------------------------------------------------------*
*      <--P_LV_E1EDT20_SIGNI  text
*----------------------------------------------------------------------*
FORM format_eq_id  CHANGING lp_e1edt20_signi TYPE e1edt20-signi
* >> Begin of TPR# 00245 - CCHERUP - 10/30
                            cv_flag.
* << End of TPR# 00245 - CCHERUP - 10/30

  DATA: ws_signi TYPE  /saprcx/equip_id.

* The field size of the conversion FM is 2 characters smaller, but
*  we expect the incoming field to never be greater than 18
*  characters long, so we will shift the field to the right and only
*  take the last 18 characters
  CLEAR ws_signi.
  SHIFT lp_e1edt20_signi RIGHT DELETING TRAILING space.
  ws_signi = lp_e1edt20_signi+2(18).

  CALL FUNCTION '/SAPRCX/EQUIP_ID_VALIDATE'
    EXPORTING
      input              = ws_signi
    IMPORTING
      output             = ws_signi
    EXCEPTIONS
      invalid_initial    = 1
      invalid_number     = 2
      invalid_character  = 3
      no_equip_id        = 4
      max_chars_exceeded = 5
      OTHERS             = 6.
  IF sy-subrc <> 0.
* >> Begin of TPR# 00245 - CCHERUP - 10/30
    cv_flag = 'X'.
    EXIT.
* << End of TPR# 00245 - CCHERUP - 10/30
  ENDIF.

* If the conversion was successful, replace the value
  IF NOT ws_signi IS INITIAL.
    lp_e1edt20_signi = ws_signi.
  ENDIF.

ENDFORM.                    " format_eq_id

*&---------------------------------------------------------------------*
*&      Form  create_shipment
*&---------------------------------------------------------------------*
* Create the Shipment in SAP by calling the standard SAP function module
* BORES_IDOC_INPUT_SHPMNT .
*----------------------------------------------------------------------*

FORM create_shipment TABLES idoc_control       STRUCTURE edidc
                            idoc_data          STRUCTURE edidd
                            idoc_status        STRUCTURE bdidocstat
                            return_variables   STRUCTURE bdwfretvar
                            serialization_info STRUCTURE bdi_ser.

  DATA: lv_input_method    TYPE bdwfap_par-inputmethd,
        lv_mass_processing TYPE bdwfap_par-mass_proc.

  DATA: lv_status TYPE bdidocstat-status,
        lv_msgty  TYPE bdidocstat-msgty,
        lv_msgv1  TYPE bdidocstat-msgv1,
        lv_msgv2  TYPE bdidocstat-msgv2,                    " <<RLW01+
        lv_msgv3  TYPE bdidocstat-msgv3.

  CLEAR: lv_input_method,
         lv_mass_processing,
         lv_status,
         lv_msgty,
         lv_msgv1,
         lv_msgv2,                                          " <<RLW01+
         lv_msgv3.

  CALL FUNCTION 'BORES_IDOC_INPUT_SHPMNT'
    EXPORTING
      input_method                = lv_input_method
      mass_processing             = lv_mass_processing
* IMPORTING
*   WORKFLOW_RESULT               =
*   APPLICATION_VARIABLE          =
*   IN_UPDATE_TASK                =
*   CALL_TRANSACTION_DONE         =
    TABLES
      idoc_contrl                 = idoc_control
      idoc_data                   = idoc_data
      idoc_status                 = idoc_status
      return_variables            = return_variables
      serialization_info          = serialization_info

      EXCEPTIONS

      wrong_function_called       = 1
      OTHERS                      = 2
            .
  IF sy-subrc = 0.
* Begin of chnages for TPR-00154. If the Shipment creation is
* succesful, check if the last status is Partially posted as a
* result of Rail car creation. If that is the case, we need to
* set the IDOC status to 53 with the message  -
* Shipment created, Equipment not found, subsequently created
    DESCRIBE TABLE idoc_status LINES sy-tabix.
    READ TABLE  idoc_status INDEX sy-tabix.
    IF sy-subrc = 0 AND idoc_status-status = '52'.
      READ TABLE idoc_status WITH KEY status = '54'
                                      msgid = '/SAPRCX/RCTC'
                                      msgty = 'W'
                                      msgno = '116'.
      IF sy-subrc = 0.
        CLEAR idoc_status.                                  " <<RLW01+
        idoc_status-docnum = idoc_control-docnum.           " <<RLW01+
        idoc_status-status = '53'.                          " <<RLW01+
        idoc_status-msgty  = 'S'.                           " <<RLW01+
        idoc_status-msgid  = 'ZSD_DL_I02484'.               " <<RLW01+
        idoc_status-msgno  = '005'.                         " <<RLW01+
        idoc_status-uname  = sy-uname.                      " <<RLW01+
        idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).   " <<RLW01+
        idoc_status-routid = space.                         " <<RLW01+
        APPEND idoc_status.
      ENDIF.                                                " <<RLW01+
    ENDIF.
* End of changes for TPR-00154.
  ELSE.
*    lv_status = '51'.                                       " <<RLW01-
*    lv_msgty  = 'E'.                                        " <<RLW01-
*    lv_msgv1  = 'Shipment creation failed'(004).            " <<RLW01-
*    lv_msgv3  = idoc_control-docnum.                        " <<RLW01-
*    PERFORM set_idoc_status TABLES idoc_status              " <<RLW01-
*                            USING  idoc_control-docnum      " <<RLW01-
*                                   lv_status                " <<RLW01-
*                                   lv_msgty                 " <<RLW01-
*                                   lv_msgv1                 " <<RLW01-
*                                   lv_msgv3.                " <<RLW01-
* Set IDoc Status: "Shipment creation failed"               " <<RLW01+
    CLEAR idoc_status.                                      " <<RLW01+
    idoc_status-docnum = idoc_control-docnum.               " <<RLW01+
    idoc_status-status = '51'.                              " <<RLW01+
    idoc_status-msgty  = 'E'.                               " <<RLW01+
    idoc_status-msgid  = 'ZSD_DL_I02484'.                   " <<RLW01+
    idoc_status-msgno  = '004'.                             " <<RLW01+
    idoc_status-uname  = sy-uname.                          " <<RLW01+
    idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).       " <<RLW01+
    idoc_status-routid = space.                             " <<RLW01+
    APPEND idoc_status.                                     " <<RLW01+

    EXIT.
  ENDIF.

ENDFORM.                    " create_shipment
**&---------------------------------------------------------------------
**&      Form  set_idoc_status    " <<RLW01-
**&---------------------------------------------------------------------
**  Set appropriate status to IDOC .
**----------------------------------------------------------------------
*FORM set_idoc_status  TABLES idoc_status STRUCTURE bdidocstat
*                      USING  lv_docnum TYPE edidc-docnum
*                             lv_status TYPE bdidocstat-status
*                             lv_msgty  TYPE bdidocstat-msgty
*                             lv_msgv1  TYPE bdidocstat-msgv1
*                             lv_msgv3  TYPE bdidocstat-msgv3.
*
*  idoc_status-docnum = lv_docnum.
*  idoc_status-status = lv_status.
*  idoc_status-msgty  = lv_msgty.
*  idoc_status-msgid  = lv_msgid.
*  idoc_status-msgno  = lv_msgno.
*  idoc_status-msgv1  = lv_msgv1.
*  idoc_status-msgv3  = lv_docnum.
*  idoc_status-uname  = sy-uname.
*  idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).
*  idoc_status-routid = space.
*  APPEND idoc_status.
*
*ENDFORM.                    " set_idoc_status


* >> Begin of TPR# 00245 - CCHERUP - 10/30

*----------------------------------------------------------------------*
*       Form  validate_idoc_data
*----------------------------------------------------------------------*
* This form validates the incoming Idoc Data before further processing
*----------------------------------------------------------------------*
FORM validate_idoc_data  TABLES it_idoc_control STRUCTURE edidc
                                ct_idoc_data    STRUCTURE edidd
                                ct_idoc_status  STRUCTURE bdidocstat
                       CHANGING cv_flag.

  DATA : ls_e1edt20 TYPE e1edt20,
         BEGIN OF lt_shtyp OCCURS 0,
           shtyp    TYPE shtyp,
         END OF lt_shtyp,
         BEGIN OF lt_vttk OCCURS 0,
           tknum    TYPE tknum,
         END OF lt_vttk.

  CLEAR gv_equip_id.
  READ TABLE ct_idoc_data WITH KEY segnam = 'E1EDT20'.
  IF sy-subrc EQ 0.
    CLEAR ls_e1edt20.
    ls_e1edt20 = ct_idoc_data-sdata.
* Validating the incoming equipment id. If its not valid, then setting
* idoc status to 51
    PERFORM format_eq_id CHANGING ls_e1edt20-exti1
                                  cv_flag.
    IF cv_flag EQ 'X'.
      CLEAR ct_idoc_status.
      ct_idoc_status-docnum = it_idoc_control-docnum.
      ct_idoc_status-status = '51'.
      ct_idoc_status-msgty  = 'E'.
      ct_idoc_status-msgid  = 'ZSD_DL_I02484'.
      ct_idoc_status-msgno  = '006'.
      ct_idoc_status-msgv1  = ls_e1edt20-exti1.
      ct_idoc_status-uname  = sy-uname.
      ct_idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).
      ct_idoc_status-routid = space.
      APPEND ct_idoc_status.
      EXIT.
    ELSE.
      gv_equip_id = ls_e1edt20-exti1.
    ENDIF.

* If the equipment code is being used on an outbound shipment except
* on a ZRLI shipment type, then the idoc is set to status 53 and no
* shipment is created as the equipment is already on an open outbound
* shipment
    SELECT shtyp
           FROM /saprcx/shtypopt
           INTO TABLE lt_shtyp
           WHERE shtyp NE gc_shtyp_zrli.
    IF sy-subrc EQ 0.
      SORT lt_shtyp.
      SELECT tknum
             FROM vttk
             INTO TABLE lt_vttk
             FOR ALL ENTRIES IN lt_shtyp
             WHERE shtyp EQ lt_shtyp-shtyp AND
                   sttrg IN ('1', '2', '3', '4', '5', '6') AND
                   signi EQ gv_equip_id    AND
                   stten EQ space.
      IF sy-subrc EQ 0.
* There will always be only 1 shipment for the above scenario. Even if
* there are multiple, it shud b ok to read the 1st one to display in
* the error message
        READ TABLE lt_vttk INDEX 1.
        CLEAR ct_idoc_status.
        ct_idoc_status-docnum = it_idoc_control-docnum.
        ct_idoc_status-status = '68'.   "CHG86925 changed from 53 to 68
        ct_idoc_status-msgty  = 'E'.
        ct_idoc_status-msgid  = 'ZSD_DL_I02484'.
        ct_idoc_status-msgno  = '007'.
        ct_idoc_status-msgv1  = gv_equip_id.
        ct_idoc_status-msgv2  = lt_vttk-tknum.
        ct_idoc_status-uname  = sy-uname.
        ct_idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).
        ct_idoc_status-routid = space.
        APPEND ct_idoc_status.
        cv_flag = 'X'.
        EXIT.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " validate_idoc_data

* << End of TPR# 00245 - CCHERUP - 10/30

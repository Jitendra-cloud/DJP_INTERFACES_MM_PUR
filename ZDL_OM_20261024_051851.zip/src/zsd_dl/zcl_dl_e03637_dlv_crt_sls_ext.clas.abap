class ZCL_DL_E03637_DLV_CRT_SLS_EXT definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_DLV_CREATE_SLS_EXTIN .
protected section.
private section.
ENDCLASS.



CLASS ZCL_DL_E03637_DLV_CRT_SLS_EXT IMPLEMENTATION.


  method IF_DLV_CREATE_SLS_EXTIN~ADDITIONAL_INPUT.
* J.Grabowiecki E0V CMS 33303
* RFSCOP E03637 DLK delivery - handle delivery LIKP-Z*fields ( copy from inbound to outbound delivery)
* exported IT_EXTENSION_IN will be porceesed by BADI implementation ZDL_E03637_DELV_PROC of LE_SHP_DELIVERY_PROC,
* method FILL_DELIVERY_HEADER

    export it_extension_in from it_extension_in to memory id 'ZDLE03637_DLV_EXTEN'.

  endmethod.
ENDCLASS.

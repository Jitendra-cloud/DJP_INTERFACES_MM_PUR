************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         20xx                                       **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Fun. Name: ZDL_E3637_POST_INB_DLVRY_GR              Date: 10/09/2006 *
*                                                                      *
* Programmer  : Savithri Renganathan                                   *
*______________________________________________________________________*
* Description :                                                        *
*  Function to post goods receipt for inbound delivery.  This function *
* will be called from the program ZDL_E3637_3RD_PARTY_PUR specifically *
* for the inbound deliveries against the plant 9427.                   *
*                                                                      *
* Logic: Call the function module WS_DELIVERY_UPDATE to post goods     *
* receipt for the given inbound delivery.  Any error during the process*
* would be captured under the table PROT which is updated back to the  *
* export table parameter ET_MESSAGES.
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
* 03/06/07   TPR17697  CO73746    E0VK926702                           *
* If you run for multiple inbound in a LUW, WS_DELIVERY_UPDATE picks   *
*    HUs from global memory. Commit the previous one by uncommenting   *
*    'commit' parameter                                                *
*______________________________________________________________________*

************************************************************************
* External Calls                                                       *
*   Function Modules:                                                  *
*                    WS_DELIVERY_UPDATE                                *
*______________________________________________________________________*

FUNCTION zdl_e3637_post_inb_dlvry_gr.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IV_INB_DLVRY) LIKE  LIKP-VBELN
*"  TABLES
*"      ET_MESSAGES TYPE  ZCA_BAL_MSG_TAB
*"  EXCEPTIONS
*"      ERROR_POST_GR
*"----------------------------------------------------------------------

  DATA:
    ls_vbkok    TYPE vbkok,  "Confirming Picking Data from Delivery Header
    ls_prot     TYPE prott,  "Log for Picking Report
    ls_messages TYPE bal_s_msg,
    lt_prot     TYPE TABLE OF prott.

* Format Delivery Number
  ls_vbkok-vbeln_vl = iv_inb_dlvry.    "Delivery
  ls_vbkok-wabuc    = gc_true.
  ls_vbkok-wadat_ist = sy-datum. "JWILL68

* Post Goods Receipt using function module WS_DELIVERY_UPDATE
  CLEAR    ls_prot.
  REFRESH  lt_prot.

  CALL FUNCTION 'WS_DELIVERY_UPDATE'
    EXPORTING
      vbkok_wa                 = ls_vbkok
*     commit                   = gc_true    "TPR 17697-point (2)
      delivery                 = iv_inb_dlvry
      if_error_messages_send_0 = gc_true
    TABLES
      prot                     = lt_prot.

  IF NOT lt_prot[] IS INITIAL. "Any error?

    REFRESH et_messages.
    CLEAR   ls_messages.

* Insert a Label record which identifies which document
* is now at problem
    ls_messages-msgty  = gc_info.
    ls_messages-msgid  = gc_msgid.
* Problem at posting GR for the Inbound delivery &:
    ls_messages-msgno  = '212'.
    ls_messages-msgv1  = iv_inb_dlvry.
    ls_messages-msgv2  = space.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO et_messages.
    CLEAR  ls_messages.

* Write all error messages to generic application log
    LOOP AT lt_prot INTO ls_prot.

* Move into an internal table and post into application log later
* (through called program)
      ls_messages-msgty  = ls_prot-msgty.
      ls_messages-msgid  = ls_prot-msgid.
      ls_messages-msgno  = ls_prot-msgno.
      ls_messages-msgv1  = ls_prot-msgv1.
      ls_messages-msgv2  = ls_prot-msgv2.
      ls_messages-msgv3  = ls_prot-msgv3.
      ls_messages-msgv4  = ls_prot-msgv4.
      APPEND ls_messages TO et_messages.
      CLEAR  ls_messages.

    ENDLOOP.

    RAISE error_post_gr.

  ELSE.
*  Successfully posted GR for the inbound delivery &.
*    ls_messages-msgty  = gc_success.
*    ls_messages-msgid  = 'ZDL_RFSCOP'.
**    ls_messages-msgid  = gc_msgid.
*    ls_messages-msgno  = '087'.
**    ls_messages-msgno  = '208'.
*    ls_messages-msgv1  = iv_inb_dlvry.
*    ls_messages-msgv2  = space.
*    ls_messages-msgv3  = space.
*    ls_messages-msgv4  = space.
*    APPEND ls_messages TO et_messages.
*    CLEAR  ls_messages.

  ENDIF.

ENDFUNCTION.

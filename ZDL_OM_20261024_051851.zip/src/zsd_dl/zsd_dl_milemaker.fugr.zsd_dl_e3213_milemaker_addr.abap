FUNCTION zsd_dl_e3213_milemaker_addr .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(I_ADDRESS) TYPE  ADDR1_VAL
*"  EXPORTING
*"     REFERENCE(E_DDS_GEOGRAPHIC_POINT) TYPE
*"        /SAPDDS/DISTANCE_REQUEST_POINT
*"  TABLES
*"      MAP_RETURN STRUCTURE  BAPIRET2
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
**             COPYRIGHT (C) 2005 by INTERNATIONAL PAPER              **
**                     ALL RIGHTS RESERVED                            **
**     REVISIONS COPYRIGHT (C) 2005, 20nn by INTERNATIONAL PAPER      **
************************************************************************
* Function Name: ZSD_DL_E3213_MILEMAKER_ADDR          Date: 09/25/2005 *
* Programmer: Maureen Carter for Phil Mattox                           *
*______________________________________________________________________*
* Milemaker is called with shipment data in order to get the distance  *
* between the shipping points.  This function can be used (along with  *
* some configuration) to change the values passed to Milemaker.        *
*                                                                      *
* In particular; this was designed to replace Mansfield with Mansfield *
* Mill.  Freight rates are contracted to Mansfield Mill. Data standards*
* do not allow us to change the address' CITY to 'Mansfield Mill'.     *
*______________________________________________________________________*
* Change History:                                                      *
* Programmer    Date      Action                                       *
* ============  ========  =============================================*
*                                                                      *
*----------------------------------------------------------------------*

************************************************************************
*ANY TIME WE CHANGE THIS INCLUDE NEED TO INVOLVE DL TEAM TO TEST FROM
* THIER SIDE
************************************************************************

  e_dds_geographic_point-location_name = i_address-city1.
  e_dds_geographic_point-region        = i_address-region.
  e_dds_geographic_point-country       = i_address-country.

ENDFUNCTION.

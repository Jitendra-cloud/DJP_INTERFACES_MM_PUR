*&---------------------------------------------------------------------*
*&  Include           ZDL_C10156_INVENTORY_PBO
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.
  SET PF-STATUS 'STATUS_9000'.
  lcl_inventory_conv=>set_title_bar( ).
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  DISPLAY  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE display OUTPUT.
  lcl_inventory_conv=>create_container( ).
  lcl_inventory_conv=>create_header_area_layout( ).
  lcl_inventory_conv=>display_success_error_data( ).
  lcl_inventory_conv=>display_translation_data( ).
ENDMODULE.

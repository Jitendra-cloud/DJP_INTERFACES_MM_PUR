FUNCTION z_dl_e10168_open_shipment_due.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_VSTEL) TYPE  VSTELA
*"     VALUE(IT_TKNUM) TYPE  ZDL_SHIP_NO_TAB OPTIONAL
*"  TABLES
*"      ET_OPEN_SHIPMENTS STRUCTURE  ZDL_E10168_OPEN_SH
*"  EXCEPTIONS
*"      AUTHORIZATION_ERROR
*"----------------------------------------------------------------------

* CMS: 25256| Changed By: AMAOLE1| Changed On: 02/21/13| START
  TYPES: BEGIN OF ty_vtts_vttp,
          tknum TYPE tknum,           "Shipment No.
          vstel TYPE vstela,          "Ship pt at departure pt
          zz_p_ls_dt TYPE zdl_p_ls_dt,"Plan Load Start Date
          zz_a_ls_dt TYPE zdl_a_ls_dt,"Act. Load Start Date
          zz_a_le_dt TYPE zdl_a_le_dt,"Act. Load End Date
          zz_sttrg TYPE zdl_sttrg,    "Overall shipment status
          vbeln TYPE vbeln_vl,        "Delivery
         END OF ty_vtts_vttp.
  DATA lt_vtts_vttp TYPE STANDARD TABLE OF ty_vtts_vttp.
  DATA ls_vtts_vttp TYPE ty_vtts_vttp.

  TYPES: BEGIN OF ty_vbpa_kna1,
          vbeln TYPE vbeln,   "Delivery No.
          parvw TYPE parvw,   "Partner Functn
          kunnr TYPE kunnr,   "Sold-to/ Ship-to
          name1 TYPE name1_gp,"Name
          ort01 TYPE ort01_gp,"City
          regio TYPE regio,   "Region
          stras TYPE stras_gp,"Street
         END OF ty_vbpa_kna1.
  DATA lt_vbpa_kna1 TYPE STANDARD TABLE OF ty_vbpa_kna1.
  DATA ls_vbpa_kna1 TYPE ty_vbpa_kna1.
  DATA ls_open_shipments TYPE zdl_e10168_open_sh.
*"----------------------------------------------------------------------

* Authorization check
  AUTHORITY-CHECK OBJECT 'V_VTTK_TDS' " FOR USER iv_uname
           ID 'TPLST' FIELD iv_vstel
           ID 'ACTVT' FIELD '03'.
  IF sy-subrc <> 0.
    MESSAGE e208(00) WITH text-e01
            RAISING authorization_error.
  ENDIF.

* Get deliveries for shipments
  IF it_tknum[] IS NOT INITIAL.

    SELECT a~tknum a~vstel a~zz_p_ls_dt a~zz_a_ls_dt a~zz_a_le_dt a~zz_sttrg b~vbeln
           INTO TABLE lt_vtts_vttp
           FROM vtts AS a INNER JOIN vttp AS b
           ON a~tknum = b~tknum
           FOR ALL ENTRIES IN it_tknum
           WHERE a~tknum = it_tknum-tknum
           AND a~vstel = iv_vstel
           AND a~zz_sttrg IN ('1','2','3','4').
  ELSE.

    SELECT a~tknum a~vstel a~zz_p_ls_dt a~zz_a_ls_dt a~zz_a_le_dt a~zz_sttrg b~vbeln
         INTO TABLE lt_vtts_vttp
         FROM vtts AS a INNER JOIN vttp AS b
         ON a~tknum = b~tknum
         WHERE a~vstel = iv_vstel
         AND a~zz_sttrg IN ('1','2','3','4').
  ENDIF.

  DELETE lt_vtts_vttp WHERE zz_p_ls_dt IS INITIAL.
  DELETE lt_vtts_vttp WHERE zz_p_ls_dt GE sy-datum.
  DELETE lt_vtts_vttp WHERE zz_a_ls_dt GE sy-datum.
  DELETE lt_vtts_vttp WHERE zz_a_le_dt GE sy-datum.

  IF lt_vtts_vttp[] IS INITIAL.
    RETURN.
  ENDIF.

* Get sold-to & ship-to for the deliveries
  SELECT a~vbeln a~parvw b~kunnr b~name1 b~ort01 b~regio b~stras
         INTO TABLE lt_vbpa_kna1
         FROM vbpa AS a INNER JOIN kna1 AS b
         ON a~kunnr = b~kunnr
         FOR ALL ENTRIES IN lt_vtts_vttp
         WHERE a~vbeln = lt_vtts_vttp-vbeln
         AND a~posnr = '000000'. "Header level partners

  DELETE lt_vbpa_kna1 WHERE parvw NE 'AG' AND parvw NE 'WE'.
* PARVW AG: Sold-to Party
* PARVW WE: Ship-to Party

  SORT lt_vtts_vttp BY tknum vbeln.
  SORT lt_vbpa_kna1 BY vbeln parvw.

  LOOP AT lt_vtts_vttp INTO ls_vtts_vttp.

    READ TABLE lt_vbpa_kna1 INTO ls_vbpa_kna1 WITH KEY vbeln = ls_vtts_vttp-vbeln
                                                       parvw = 'WE'
                                                       BINARY SEARCH.
    IF sy-subrc NE 0.
      CONTINUE.
    ELSE.

      ls_open_shipments-tknum = ls_vtts_vttp-tknum.
      ls_open_shipments-vstel = ls_vtts_vttp-vstel.
      ls_open_shipments-zz_sttrg = ls_vtts_vttp-zz_sttrg.
      ls_open_shipments-zz_p_ls_dt = ls_vtts_vttp-zz_p_ls_dt.
      ls_open_shipments-zz_a_ls_dt = ls_vtts_vttp-zz_a_ls_dt.
      ls_open_shipments-zz_a_le_dt = ls_vtts_vttp-zz_a_le_dt.
      ls_open_shipments-kunnr_sh = ls_vbpa_kna1-kunnr.
      ls_open_shipments-name1_sh = ls_vbpa_kna1-name1.
      ls_open_shipments-stras_sh = ls_vbpa_kna1-stras.
      ls_open_shipments-ort01_sh = ls_vbpa_kna1-ort01.
      ls_open_shipments-regio_sh = ls_vbpa_kna1-regio.

      READ TABLE lt_vbpa_kna1 INTO ls_vbpa_kna1 WITH KEY vbeln = ls_vtts_vttp-vbeln
                                                         parvw = 'AG'
                                                         BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_open_shipments-kunnr_sp = ls_vbpa_kna1-kunnr.
        ls_open_shipments-name1_sp = ls_vbpa_kna1-name1.
      ENDIF.

      APPEND ls_open_shipments TO et_open_shipments.
    ENDIF.

    CLEAR ls_open_shipments.

  ENDLOOP.

  DELETE ADJACENT DUPLICATES FROM  et_open_shipments COMPARING tknum kunnr_sh  kunnr_sp.

  SORT et_open_shipments BY zz_p_ls_dt tknum.

**"----------------------------------------------------------------------
**"*"Local Interface:
**"  IMPORTING
**"     VALUE(VSTEL) TYPE  VSTEL
**"  TABLES
**"      OPEN_SHIPMENTS STRUCTURE  ZDL_E10168_OPEN_SH
**"  EXCEPTIONS
**"      AUTHORIZATION_ERROR
**"----------------------------------------------------------------------
*  TYPES: BEGIN OF ty_vtts,
*           tknum      TYPE tknum,
*           tsnum      TYPE tsnum,
*           vstel      TYPE vstel,
*           kunnz      TYPE kunnz,
*           zz_p_ls_dt TYPE zdl_p_ls_dt,
*           zz_a_ls_dt TYPE zdl_a_ls_dt,
*           zz_a_le_dt TYPE zdl_a_le_dt,
*           zz_sttrg   TYPE zdl_sttrg,
*         END OF ty_vtts.
*
*  TYPES: BEGIN OF ty_kna1,
*           kunnr TYPE kunnr,
*           name1 TYPE name1_gp,
*           ort01 TYPE ort01_gp,
*           regio TYPE regio,
*           stras TYPE stras_gp,
*         END OF ty_kna1.
*
*  DATA: lr_sttrg TYPE RANGE OF vtts-zz_sttrg,
*        ls_sttrg LIKE LINE OF lr_sttrg.
*
*  DATA: gt_vtts  TYPE STANDARD TABLE OF ty_vtts,
*        gt_vtts1 TYPE STANDARD TABLE OF ty_vtts,
*        gs_vtts  TYPE ty_vtts,
*        gt_kna1  TYPE STANDARD TABLE OF ty_kna1,
*        gs_kna1  TYPE ty_kna1,
*        gs_open_shipments TYPE zdl_e10168_open_sh.
*
*  DATA: lv_date TYPE zdl_p_ls_dt.
*  FIELD-SYMBOLS: <fs_open_shipments> TYPE zdl_e10168_open_sh.
*
** Perform the Authorization check
*  AUTHORITY-CHECK OBJECT 'V_VTTK_TDS' " FOR USER uname
*           ID 'TPLST' FIELD vstel
*           ID 'ACTVT' FIELD '03'.
*  IF sy-subrc <> 0.
*    MESSAGE e208(00) WITH text-e01
*            RAISING authorization_error.
*  ENDIF.
*
** Fill the ZZ_STTRG range with values '1' '2' '3' and '4'
*  ls_sttrg-sign = 'I'.
*  ls_sttrg-option = 'EQ'.
*  ls_sttrg-low = '1'.
*  APPEND ls_sttrg TO lr_sttrg.
*  ls_sttrg-low = '2'.
*  APPEND ls_sttrg TO lr_sttrg.
*  ls_sttrg-low = '3'.
*  APPEND ls_sttrg TO lr_sttrg.
*  ls_sttrg-low = '4'.
*  APPEND ls_sttrg TO lr_sttrg.
*
** Retreive the data from the DB table VTTS
*  SELECT  tknum
*          tsnum
*          vstel
*          kunnz
*          zz_p_ls_dt
*          zz_a_ls_dt
*          zz_a_le_dt
*          zz_sttrg
*    INTO TABLE gt_vtts
*    FROM vtts
*    WHERE vstel      =  vstel
*    AND   zz_sttrg   IN lr_sttrg
*    AND   zz_p_ls_dt LT sy-datum.
*  IF sy-subrc EQ 0.
*    SELECT  tknum
*        tsnum
*        vstel
*        kunnz
*        zz_p_ls_dt
*        zz_a_ls_dt
*        zz_a_le_dt
*        zz_sttrg
*  INTO TABLE gt_vtts1
*  FROM vtts
*      FOR ALL ENTRIES IN gt_vtts
*  WHERE tknum      =  gt_vtts-tknum.
*
*    APPEND LINES OF gt_vtts1 TO gt_vtts.
*
*    SELECT kunnr
*           name1
*           ort01
*           regio
*           stras
*        INTO TABLE gt_kna1
*      FROM kna1
*      FOR ALL ENTRIES IN gt_vtts
*      WHERE kunnr = gt_vtts-kunnz.
*  ENDIF.
*
*  SORT gt_kna1 BY kunnr.
*  DELETE ADJACENT DUPLICATES FROM gt_kna1 COMPARING kunnr.
*
*  SORT gt_vtts BY tknum tsnum.
*  DELETE ADJACENT DUPLICATES FROM gt_vtts COMPARING tknum tsnum.
*
*  SORT gt_vtts DESCENDING BY tknum zz_sttrg.
*  LOOP AT gt_vtts INTO gs_vtts.
*    IF gs_vtts-zz_sttrg GE '5'.
*      DELETE gt_vtts WHERE tknum = gs_vtts-tknum.
*      CONTINUE.
*    ENDIF.
*
** Remove the items where the shipping point is other than
** VSTEL entered in the FM.
*    IF gs_vtts-vstel IS INITIAL.
*
*    ELSEIF gs_vtts-vstel NE vstel.
*      CONTINUE.
*    ENDIF.
*
*    IF ( gs_vtts-zz_a_ls_dt IS INITIAL OR
*         gs_vtts-zz_a_ls_dt LT sy-datum ) AND
*       ( gs_vtts-zz_a_le_dt IS INITIAL OR
*         gs_vtts-zz_a_le_dt LT sy-datum ).
*
*      gs_open_shipments-vstel = gs_vtts-vstel.
*      gs_open_shipments-tknum = gs_vtts-tknum.
*      gs_open_shipments-zz_sttrg = gs_vtts-zz_sttrg.
*      gs_open_shipments-zz_p_ls_dt = gs_vtts-zz_p_ls_dt.
*      gs_open_shipments-zz_a_ls_dt = gs_vtts-zz_a_ls_dt.
*      gs_open_shipments-zz_a_le_dt = gs_vtts-zz_a_le_dt.
*      gs_open_shipments-kunnz = gs_vtts-kunnz.
*
*      READ TABLE gt_kna1 INTO gs_kna1 WITH KEY kunnr = gs_vtts-kunnz
*                                     BINARY SEARCH.
*      IF sy-subrc EQ 0.
*        gs_open_shipments-name1 = gs_kna1-name1.
*        gs_open_shipments-stras = gs_kna1-stras.
*        gs_open_shipments-ort01 = gs_kna1-ort01.
*        gs_open_shipments-regio = gs_kna1-regio.
*      ENDIF.
*      APPEND gs_open_shipments TO open_shipments.
*    ENDIF.
*  ENDLOOP.
*  SORT open_shipments BY  tknum. " zz_p_ls_dt
*
** Update the planned load start date(ZZ_P_LS_DT) for some of the
** blank records.
*  LOOP AT open_shipments ASSIGNING <fs_open_shipments>.
*    AT NEW tknum.
*      CLEAR lv_date.
*      IF <fs_open_shipments>-zz_p_ls_dt IS NOT INITIAL.
*        lv_date = <fs_open_shipments>-zz_p_ls_dt.
*      ENDIF.
*      CONTINUE.
*    ENDAT.
*    <fs_open_shipments>-zz_p_ls_dt = lv_date.
*  ENDLOOP.
*  SORT open_shipments BY zz_p_ls_dt tknum.
*
* CMS: 25256| Changed By: AMAOLE1| Changed On: 02/21/13| END

ENDFUNCTION.

FUNCTION zsd_idoc_input_picking.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  IMPORTING
*"     VALUE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     VALUE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     VALUE(WORKFLOW_RESULT) LIKE  BDWFAP_PAR-RESULT
*"     VALUE(APPLICATION_VARIABLE) LIKE  BDWFAP_PAR-APPL_VAR
*"     VALUE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     VALUE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"      OTHERS
*"----------------------------------------------------------------------
* Programmer  : Naveen Parchuri               Date : 09/12/2005        *
*                                                                      *
*______________________________________________________________________*
* Description : This function module is called from process code ZSDPI *
*               to add the delivery line item in the E1VPDLI segment   *
*               for vendor PAGE INTERNATIONAL. After the idoc has been *
*               modified with delivery line item the standard function *
*               module SD_IDOC_INPUT_PICKING is called to process the  *
*               idoc .                                                 *
* COR # I02296
*______________________________________________________________________*
* Change History:                                                      *
* 01/25/07  MACARTE per CO 71296    (MC001)                            *
*  Material/batch may have transferred from one sales order item to    *
*  another.  When reading MSKA, add a condition to check KALAB weight. *
*  KALAB will be = 0 for the 'FROM' line item and >= picked weight for *
*  the 'TO sales order line item.                                      *
*----------------------------------------------------------------------*


  READ TABLE idoc_contrl INDEX 1.

*........IDOC-Daten übernehmen..........................................
  LOOP AT idoc_data WHERE docnum = idoc_contrl-docnum.
    MOVE idoc_data TO isegm.
    PERFORM sdpiid01_segment_e1vpdli.
    MODIFY idoc_data FROM isegm TRANSPORTING sdata.
  ENDLOOP.


* Call the standard function module for normal processing of the IDOC
  CALL FUNCTION 'SD_IDOC_INPUT_PICKING'
    EXPORTING
      input_method                = input_method
      mass_processing             = mass_processing
* IMPORTING
*   WORKFLOW_RESULT             =
*   APPLICATION_VARIABLE        =
*   IN_UPDATE_TASK              =
*   CALL_TRANSACTION_DONE       =
    TABLES
      idoc_contrl                 = idoc_contrl
      idoc_data                   = idoc_data
      idoc_status                 = idoc_status
      return_variables            = return_variables
*   SERIALIZATION_INFO          =
* EXCEPTIONS
*   WRONG_FUNCTION_CALLED       = 1
*   OTHERS                      = 2
*   OTHERS                      = 3
            .
  IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.

ENDFUNCTION.


*----------------------------------------------------------------------*
*        FORM E1VPDLI_SEGMENT_E1VPDLI                                  *
*----------------------------------------------------------------------*
*        INPUT:     IDOC_KOPF           Header des IDOCs (Verwalt.Daten*
*                   IDOC_SEGMENT        Aktuelles IDOC-Segment         *
*----------------------------------------------------------------------*
FORM e1vpdli_segment_modify.

*Modify the line item segment with delivery line item
  MOVE isegm-sdata TO e1vpdli.
************************************************************************
* Get the sales order from the table vbfa for the for the delivery where
* VBTYP_N(Document category of subsequent document) is 'J'(delivery) and
* VBTYP_V(Document category of preceding SD document) is 'C'
* (Sales order)
************************************************************************

  IF e1vpdli-posnr_vl = 0 .
    SELECT SINGLE vbelv
       FROM vbfa
       INTO vbfa-vbelv
       WHERE vbeln = e1vpdli-vbeln_vl
       AND vbtyp_n = 'J'
       AND vbtyp_v = 'C' .
    IF sy-subrc = 0 .
************************************************************************
* From the table MSKA get the sales order line item MSKA-POSNR for the
* combination of material/batch/sales order
************************************************************************
      SELECT SINGLE posnr
         FROM mska
         INTO mska-posnr
         WHERE matnr = e1vpdli-matnr
         AND   charg = e1vpdli-charg
         AND   vbeln = vbfa-vbelv
         AND   kalab => e1vpdli-ntgew.                           "<MC001
      IF sy-subrc = 0 .
************************************************************************
* From the table LIPS get the delivery line item for the combination of
* delivery/sales order/ sales order line item .
************************************************************************
        SELECT SINGLE posnr
           FROM lips
           INTO lips-posnr
           WHERE vbeln = e1vpdli-vbeln_vl
           AND   vgbel = vbfa-vbelv
           AND   vgpos = mska-posnr .
        IF sy-subrc = 0 .
          e1vpdli-posnr_vl = lips-posnr.
          CLEAR isegm-sdata .
          MOVE e1vpdli TO isegm-sdata.
        ENDIF.
      ENDIF. " IF SY-SUBRC = 0
    ENDIF. " IF E1VPDLI-POSNR_VL IS INITIAL
  ENDIF.



ENDFORM.                    "E1VPDLI_SEGMENT_MODIFY

*----------------------------------------------------------------------*
*        FORM SDPIID01_SEGMENT_UEBERNEHMEN                             *
*----------------------------------------------------------------------*
*        INPUT:     IKOPF               Header des IDOCs (Verwalt.Daten*
*                   ISEGM               Aktuelles IDOC-Segment         *
*----------------------------------------------------------------------*
FORM sdpiid01_segment_e1vpdli.

* Modify the line item segment only
  CASE isegm-segnam.

    WHEN seg_pi_item.
      PERFORM e1vpdli_segment_modify.
  ENDCASE.

ENDFORM.                    "SDPIID01_SEGMENT_E1VPDLI

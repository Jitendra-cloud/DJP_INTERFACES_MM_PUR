*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSDR1460_SHPMNTS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSDR1460_SHPMNTS    .

  PERFORM TABLEPROC.

ENDFUNCTION.

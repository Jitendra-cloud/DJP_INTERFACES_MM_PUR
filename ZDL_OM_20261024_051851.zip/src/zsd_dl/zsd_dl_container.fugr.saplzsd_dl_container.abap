*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_CONTAINERTOP.              " Global Data
  INCLUDE LZSD_DL_CONTAINERUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_CONTAINERF...              " Subprograms
* INCLUDE LZSD_DL_CONTAINERO...              " PBO-Modules
* INCLUDE LZSD_DL_CONTAINERI...              " PAI-Modules

INCLUDE LZSD_DL_CONTAINERF01.

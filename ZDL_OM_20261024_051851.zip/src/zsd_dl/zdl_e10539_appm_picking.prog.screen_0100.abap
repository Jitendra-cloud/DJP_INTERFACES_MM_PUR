process before output.
  module status_0100.
*
process after input.
  module exit_command_0100 at exit-command.
  module set_ucomm.
  module user_command_0100.

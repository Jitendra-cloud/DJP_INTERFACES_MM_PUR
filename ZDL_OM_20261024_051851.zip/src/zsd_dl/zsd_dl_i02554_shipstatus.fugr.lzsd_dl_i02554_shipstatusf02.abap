*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_I02554_SHIPSTATUSF02 .
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
* Form routine for ZSD_DL_I02554_SHIPSTATUS_MESSG function module
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       Form  REFRESH_VARIABLES
*----------------------------------------------------------------------*
* This form clears the global variables
*----------------------------------------------------------------------*
FORM refresh_variables .

  CLEAR   : gs_em_data, gs_idoc_info, gs_vttk,
            gv_ship_from, gv_ship_from_adrnr,
            gv_ship_to,   gv_ship_to_adrnr.

  REFRESH : gt_stop_delvs, gt_vbpa, gt_nach, gt_vbfa, gt_vbak,
            gt_vtts,  gt_idoc_sent, gt_condition_record.

ENDFORM.                    " REFRESH_VARIABLES
*----------------------------------------------------------------------*
*       Form  VALIDATE_DATA
*----------------------------------------------------------------------*
* This form validates the Input data
*----------------------------------------------------------------------*
FORM validate_data CHANGING cs_error STRUCTURE bapiret2.

  DATA : lv_msg   TYPE string.

  PERFORM validate_shipment_number USING gs_em_data-tknum
                                CHANGING lv_msg.
  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message    USING lv_msg
                                CHANGING cs_error.
    RETURN.
  ENDIF.

  IF gs_em_data-itnum IS INITIAL.
* Itinerary Number is blank
    MESSAGE e003 INTO lv_msg.
  ELSE.
    PERFORM validate_itinerary_number USING gs_em_data-itnum
                                   CHANGING lv_msg.
  ENDIF.
  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message     USING lv_msg
                                 CHANGING cs_error.
    RETURN.
  ENDIF.

  PERFORM validate_event_code       USING gs_em_data-event_code
                                 CHANGING lv_msg.
  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message     USING lv_msg
                                 CHANGING cs_error.
    RETURN.
  ENDIF.


ENDFORM.                    " VALIDATE_DATA
*----------------------------------------------------------------------*
*       Form  VALIDATE_SHIPMENT_NUMBER
*----------------------------------------------------------------------*
* This form validates the Shipment Number
*----------------------------------------------------------------------*
FORM validate_shipment_number USING value(iv_tknum)
                           CHANGING cv_msg   TYPE string.

  IF iv_tknum IS INITIAL.
* Shipment Number is blank
    MESSAGE e001 INTO cv_msg.
  ELSE.
* Convert Shipment Number to numeric leading 0's
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = iv_tknum
      IMPORTING
        output = iv_tknum.
* Read the shipment header record from database
    CLEAR gs_vttk.
    SELECT SINGLE *
           FROM vttk
           INTO gs_vttk
           WHERE tknum = iv_tknum.
    IF sy-subrc NE 0.
* Shipment Number & does not exist
      MESSAGE e002 WITH iv_tknum INTO cv_msg.
    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_SHIPMENT_NUMBER
*----------------------------------------------------------------------*
*       Form  VALIDATE_ITINERARY_NUMBER
*----------------------------------------------------------------------*
* This form validates the Itinerary Number
*----------------------------------------------------------------------*
FORM validate_itinerary_number  USING iv_itnum TYPE zitnum
                             CHANGING cv_msg   TYPE string.

  DATA ls_vtts TYPE tt_vtts.

  SELECT tknum tsnum tsrfo vstel zz_itin_o zz_itin_d zz_stoptype_o
        FROM vtts
        INTO TABLE gt_vtts
        WHERE tknum EQ gs_vttk-tknum.
  IF sy-subrc EQ 0.
    CLEAR ls_vtts.
    READ TABLE gt_vtts INTO ls_vtts WITH KEY
                                         zz_itin_o = iv_itnum.
    IF sy-subrc NE 0.
      READ TABLE gt_vtts INTO ls_vtts WITH KEY
                                           zz_itin_d = iv_itnum.
    ENDIF.
    IF ls_vtts IS INITIAL.
* Itinerary Number & does not exist on the Shipment &
      MESSAGE e004 WITH iv_itnum gs_vttk-tknum INTO cv_msg.
    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_ITINERARY_NUMBER
*----------------------------------------------------------------------*
*       Form  VALIDATE_EVENT_CODE
*----------------------------------------------------------------------*
* This form checks for the validity of the Input Event Code
*----------------------------------------------------------------------*
FORM validate_event_code  USING iv_event_code TYPE zdl_zssoa
                       CHANGING cv_msg        TYPE string.

  DATA : lt_values TYPE STANDARD TABLE OF dd07v,
         ls_values TYPE dd07v.

  IF iv_event_code IS INITIAL.
* Event Code is blank
    MESSAGE e005 INTO cv_msg.
  ELSE.
    CALL FUNCTION 'GET_DOMAIN_VALUES'
      EXPORTING
        domname         = 'ZDL_ZSSOA'
        text            = 'X'
      TABLES
        values_tab      = lt_values
      EXCEPTIONS
        no_values_found = 1
        OTHERS          = 2.
    IF sy-subrc EQ 0.
      READ TABLE lt_values INTO ls_values WITH KEY
                                          domvalue_l = iv_event_code.
      IF sy-subrc NE 0.
* Event Code & does not exist in Domain ZDL_ZSSOA in R/3
        MESSAGE e006 WITH iv_event_code INTO cv_msg.
      ENDIF.
    ELSE.
* No values maintained in Domain ZDL_ZSSOA in R/3
      MESSAGE e007 INTO cv_msg.
    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_EVENT_CODE
*----------------------------------------------------------------------*
*       Form  READ_SHIPMENT_ITINERARY
*----------------------------------------------------------------------*
* This form reads the shipment itinerary for the input shipment
*----------------------------------------------------------------------*
FORM read_shipment_itinerary  USING iv_itnum TYPE      zitnum
                           CHANGING cs_error STRUCTURE bapiret2.

  DATA lv_msg TYPE string.

  CALL FUNCTION 'ZSD_DL_MOS_ITINERARY_VIEW'
    EXPORTING
      i_tknum                        = gs_vttk-tknum
    TABLES
      t_itinerary                    = gt_itinerary
    EXCEPTIONS
      invalid_input                  = 1
      shipment_not_found             = 2
      no_deliveries_found            = 3
      no_stages_on_shipment          = 4
      no_authority                   = 5
      deliveries_unassigned_to_stage = 6
      OTHERS                         = 7.
  CASE sy-subrc.
    WHEN 0.
      IF gt_itinerary[] IS NOT INITIAL.
        IF iv_itnum IS NOT INITIAL.
          DELETE gt_itinerary WHERE itnum NE iv_itnum.
        ENDIF.
      ELSE.
* Error while reading Itinerary Function Module
        MESSAGE e016 INTO lv_msg.
      ENDIF.
    WHEN 1.
* Invalid input to the Itinerary Function Module
      MESSAGE e010 INTO lv_msg.
    WHEN 2.
* Shipment & not found
      MESSAGE e011 WITH gs_vttk-tknum INTO lv_msg.
    WHEN 3.
* Deliveries not found on shipment &
      MESSAGE e012 WITH gs_vttk-tknum INTO lv_msg.
    WHEN 4.
* No Stages exist on shipment &
      MESSAGE e013 WITH gs_vttk-tknum INTO lv_msg.
    WHEN 5.
* No Authority for reading the Itinerary Function Module
      MESSAGE e014 INTO lv_msg.
    WHEN 6.
* Deliveries unassigned to stage for shipment &
      MESSAGE e015 WITH gs_vttk-tknum INTO lv_msg.
    WHEN OTHERS.
* Error while reading Itinerary Function Module
      MESSAGE e016 INTO lv_msg.
  ENDCASE.

  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message     USING lv_msg
                                 CHANGING cs_error.
  ENDIF.

ENDFORM.                    " READ_SHIPMENT_ITINERARY
*----------------------------------------------------------------------*
*       Form  GET_VBPA_DATA
*----------------------------------------------------------------------*
* This form gets the partner data from VBPA table
*----------------------------------------------------------------------*
FORM get_vbpa_data TABLES it_deliveries TYPE zmos_deliveries_s
                          ct_vbpa       STRUCTURE vbpa.

  REFRESH ct_vbpa.
  IF it_deliveries[] IS NOT INITIAL.
    SELECT *
          FROM vbpa
          INTO TABLE ct_vbpa
          FOR ALL ENTRIES IN it_deliveries
          WHERE vbeln EQ it_deliveries-vbeln.
    IF sy-subrc EQ 0.
      SORT ct_vbpa BY parvw.
* Delete partners that are not ship-to and sold-to
      DELETE ct_vbpa WHERE parvw NE gc_parvw_we AND
                           parvw NE gc_parvw_ag.
    ENDIF.
  ENDIF.

ENDFORM.                    " GET_VBPA_DATA
*----------------------------------------------------------------------*
*       Form  GET_VBFA_VBAK_DATA
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_vbfa_vbak_data .

  IF gt_stop_delvs[] IS NOT INITIAL.
* Get SO Numbers
    SELECT vbelv posnv vbeln posnn vbtyp_n vbtyp_v
           FROM vbfa
           INTO TABLE gt_vbfa
           FOR ALL ENTRIES IN gt_stop_delvs
           WHERE vbeln   EQ gt_stop_delvs-vbeln AND
                 vbtyp_n EQ 'J'                 AND
                 vbtyp_v EQ 'C'.
    IF sy-subrc EQ 0.
      SORT gt_vbfa BY vbelv.
      DELETE ADJACENT DUPLICATES FROM gt_vbfa COMPARING vbelv.
    ENDIF.
  ENDIF.

* Get PO Numbers
* - Change from TPR 27352 - requested pull PO from VBKD instead of VBAK
*  IF gt_vbfa[] IS NOT INITIAL.
*    SELECT vbeln bstnk
*           FROM vbak
*           INTO TABLE gt_vbak
*           FOR ALL ENTRIES IN gt_vbfa
*           WHERE vbeln EQ gt_vbfa-vbelv.
*    IF sy-subrc EQ 0.
*      SORT gt_vbak BY vbeln.
*    ENDIF.
*  ENDIF.
  IF gt_vbfa[] IS NOT INITIAL.
    SELECT vbeln bstkd
           FROM vbkd
           INTO TABLE gt_vbkd
           FOR ALL ENTRIES IN gt_vbfa
           WHERE vbeln EQ gt_vbfa-vbelv.
    IF sy-subrc EQ 0.
      SORT gt_vbkd BY vbeln.
    ENDIF.
  ENDIF.

ENDFORM.                    " GET_VBFA_VBAK_DATA
*----------------------------------------------------------------------*
*       Form  GET_CONDITION_RECORDS
*----------------------------------------------------------------------*
* This form gets the Condition Records data from condition tables      *
*----------------------------------------------------------------------*
FORM get_condition_records CHANGING cs_error STRUCTURE bapiret2.

  DATA : lv_msg   TYPE string.

* SSOA Code/Ship-To Pt/Sold-To
  SELECT *
        FROM b980
        INTO CORRESPONDING FIELDS OF TABLE gt_condition_record
        WHERE kappl    EQ gc_kappl_v7   AND
              kschl    EQ gc_kschl_zsso AND
              zz_zssoa EQ gs_em_data-event_code.

* SSOA Code/Sold-To
  SELECT *
        FROM b981
        APPENDING CORRESPONDING FIELDS OF TABLE gt_condition_record
        WHERE kappl    EQ gc_kappl_v7   AND
              kschl    EQ gc_kschl_zsso AND
              zz_zssoa EQ gs_em_data-event_code.

* SSOA Code/Ship-To Pt
  SELECT *
        FROM b982
        APPENDING CORRESPONDING FIELDS OF TABLE gt_condition_record
        WHERE kappl    EQ gc_kappl_v7   AND
              kschl    EQ gc_kschl_zsso AND
              zz_zssoa EQ gs_em_data-event_code.

  IF gt_condition_record[] IS NOT INITIAL.
    SORT gt_condition_record.
    DELETE ADJACENT DUPLICATES FROM gt_condition_record
                                    COMPARING ALL FIELDS.
  ELSE.
* No recipients exist for the event code &
    MESSAGE e008 WITH gs_em_data-event_code INTO lv_msg.
    PERFORM build_error_message    USING lv_msg
                                CHANGING cs_error.
  ENDIF.

ENDFORM.                    " GET_CONDITION_RECORDS
*---------------------------------------------------------------------*
*      Form  GET_RECIPIENTS_INFO
*---------------------------------------------------------------------*
* This form gets the recipients info from NACH table
*----------------------------------------------------------------------*
FORM get_recipients_info.

  IF gt_condition_record[] IS NOT INITIAL.
    SORT gt_condition_record BY knumh.
    SELECT *
          FROM nach
          INTO TABLE gt_nach
          FOR ALL ENTRIES IN gt_condition_record
          WHERE knumh EQ gt_condition_record-knumh.
    IF sy-subrc EQ 0.
      SORT gt_nach BY knumh.
    ENDIF.
  ENDIF.

ENDFORM.                    " GET_RECIPIENTS_INFO
*----------------------------------------------------------------------*
*       Form  PROCESS_SEND_IDOC
*----------------------------------------------------------------------*
* This form processes the gathered data and sends IDOC(s)
* While looping at all the deliveries, grab the recipient for the      *
* corresponding Ship-To & Sold-To (if any), extract the necessary data *
* to build the IDOC and then send the IDOC using the std. SAP process  *
*----------------------------------------------------------------------*
FORM process_send_idoc CHANGING cs_error STRUCTURE bapiret2.

  DATA : lv_ship_to         TYPE kunnr,
         lv_sold_to         TYPE kunnr,
         ls_vbpa            TYPE vbpa,
         ls_delv            TYPE zmos_deliveries.

  SORT gt_vbpa       BY vbeln parvw.
  SORT gt_stop_delvs BY vbeln.

  PERFORM get_ship_from_data.

  LOOP AT gt_stop_delvs INTO ls_delv.

* Ship-To
    READ TABLE gt_vbpa INTO ls_vbpa WITH KEY vbeln = ls_delv-vbeln
                                             parvw = gc_parvw_we
                                             BINARY SEARCH.
    IF sy-subrc EQ 0.
      lv_ship_to = ls_vbpa-kunnr.
      CLEAR : gv_ship_to, gv_ship_to_adrnr.
      gv_ship_to       = ls_vbpa-kunnr.
      gv_ship_to_adrnr = ls_vbpa-adrnr.
    ENDIF.

* Sold-To
    READ TABLE gt_vbpa INTO ls_vbpa WITH KEY vbeln = ls_delv-vbeln
                                             parvw = gc_parvw_ag
                                             BINARY SEARCH.
    IF sy-subrc EQ 0.
      lv_sold_to = ls_vbpa-kunnr.
    ENDIF.

* If Ship-To is available, check for condition record(s) and send idoc
    IF lv_ship_to IS NOT INITIAL.
      PERFORM send_recipient_idoc USING lv_ship_to
                                        ' '
                               CHANGING cs_error.
    ENDIF.

* If Sold-To is available, check for condition record(s) and send idoc
    IF lv_sold_to IS NOT INITIAL.
      PERFORM send_recipient_idoc USING ' '
                                        lv_sold_to
                               CHANGING cs_error.
    ENDIF.

* If Ship-To and Sold-To both are available,
* check for condition record(s) and send idoc
    IF lv_ship_to IS NOT INITIAL AND lv_sold_to IS NOT INITIAL.
      PERFORM send_recipient_idoc USING lv_ship_to
                                        lv_sold_to
                               CHANGING cs_error.
    ENDIF.

  ENDLOOP.

ENDFORM.                    " PROCESS_SEND_IDOC
*----------------------------------------------------------------------*
*       Form  GET_SHIP_FROM_DATA
*----------------------------------------------------------------------*
* This form gets the Ship-From Info (of the last origin)
*----------------------------------------------------------------------*
FORM get_ship_from_data.

  DATA : lt_vtts TYPE STANDARD TABLE OF tt_vtts,
         ls_vtts TYPE                   tt_vtts.

  lt_vtts[] = gt_vtts[].
  SORT lt_vtts BY zz_stoptype_o.
  DELETE lt_vtts WHERE zz_stoptype_o NE 'CL' AND
                       zz_stoptype_o NE 'PL'.
  SORT lt_vtts BY tsrfo DESCENDING.
  READ TABLE lt_vtts INTO ls_vtts INDEX 1.
  IF sy-subrc EQ 0.
    CLEAR : gv_ship_from, gv_ship_from_adrnr.
    gv_ship_from = ls_vtts-vstel.
    SELECT SINGLE adrnr
           INTO   gv_ship_from_adrnr
           FROM   tvst
           WHERE  vstel EQ ls_vtts-vstel.
  ENDIF.


ENDFORM.                    " GET_SHIP_FROM_DATA
*----------------------------------------------------------------------*
*       Form  SEND_RECIPIENT_IDOC
*----------------------------------------------------------------------*
* This form sends the IDOC to the recipients
*----------------------------------------------------------------------*
FORM send_recipient_idoc  USING  iv_ship_to TYPE kunnr
                                 iv_sold_to TYPE kunnr
                        CHANGING cs_error   STRUCTURE bapiret2.

  DATA : ls_cond_recrd TYPE tt_condition_record,
         ls_nach       TYPE nach.

  IF iv_ship_to IS NOT INITIAL AND iv_sold_to IS INITIAL.
* Check whether condition record exists or not
    READ TABLE gt_condition_record INTO ls_cond_recrd
                                   WITH KEY kunwe = iv_ship_to.
    IF sy-subrc EQ 0.
* Read the partner info from NACH
      READ TABLE gt_nach INTO ls_nach
                         WITH KEY knumh = ls_cond_recrd-knumh
                         BINARY SEARCH.
      IF sy-subrc EQ 0.
        PERFORM send_idoc    USING ls_nach
                          CHANGING cs_error.
      ENDIF.
    ENDIF.
    RETURN.
  ENDIF.

  IF iv_ship_to IS INITIAL AND iv_sold_to IS NOT INITIAL.
* Check whether condition record exists or not
    READ TABLE gt_condition_record INTO ls_cond_recrd
                                   WITH KEY zz_kunag = iv_sold_to.
    IF sy-subrc EQ 0.
* Read the partner info from NACH
      READ TABLE gt_nach INTO ls_nach
                         WITH KEY knumh = ls_cond_recrd-knumh
                         BINARY SEARCH.
      IF sy-subrc EQ 0.
        PERFORM send_idoc    USING ls_nach
                          CHANGING cs_error.
      ENDIF.
    ENDIF.
    RETURN.
  ENDIF.

  IF iv_ship_to IS NOT INITIAL AND iv_sold_to IS NOT INITIAL.
* Check whether condition record exists or not
    READ TABLE gt_condition_record INTO ls_cond_recrd
                                   WITH KEY kunwe    = iv_ship_to
                                            zz_kunag = iv_sold_to.
    IF sy-subrc EQ 0.
* Read the partner info from NACH
      READ TABLE gt_nach INTO ls_nach
                         WITH KEY knumh = ls_cond_recrd-knumh
                         BINARY SEARCH.
      IF sy-subrc EQ 0.
        PERFORM send_idoc    USING ls_nach
                          CHANGING cs_error.
      ENDIF.
    ENDIF.
    RETURN.
  ENDIF.

ENDFORM.                    " SEND_RECIPIENT_IDOC
*----------------------------------------------------------------------*
*       Form  FILL_IDOC_INFO
*----------------------------------------------------------------------*
* This form fills the global structure with the required info which will
* be used by the Outbound FM
*----------------------------------------------------------------------*
FORM fill_idoc_info.

  CLEAR gs_idoc_info.
  MOVE-CORRESPONDING gs_em_data TO gs_idoc_info.
  gs_idoc_info-ship_from       = gv_ship_from.
  gs_idoc_info-ship_from_adrnr = gv_ship_from_adrnr.
  gs_idoc_info-ship_to         = gv_ship_to.
  gs_idoc_info-ship_to_adrnr   = gv_ship_to_adrnr.

ENDFORM.                    " FILL_IDOC_INFO
*----------------------------------------------------------------------*
*       Form  SEND_IDOC
*----------------------------------------------------------------------*
* This form sends the IDOC
*----------------------------------------------------------------------*
FORM send_idoc     USING  is_nach  STRUCTURE nach
                CHANGING  cs_error STRUCTURE bapiret2.

  DATA : lv_rcode         LIKE sy-subrc,
         ls_parnr         TYPE tt_idoc_sent,
         lv_msg           TYPE string,
         lv_already_sent.

* Check whether the Idoc has already been sent to this partner
  PERFORM check_idoc_sent USING is_nach-parnr
                       CHANGING lv_already_sent.

* If Idoc has not been sent, then only send
  IF lv_already_sent IS INITIAL.
    PERFORM fill_idoc_info.
    PERFORM build_nast_record USING is_nach.

* This perform sends the Idoc
    PERFORM einzelnachricht_screen(rsnast00) USING lv_rcode.
    IF lv_rcode EQ 0.
      ls_parnr-parnr = is_nach-parnr.
      APPEND ls_parnr TO gt_idoc_sent.
* This perform gets the "Error Management Number" required for
* processing log
      PERFORM protocol_store(rsnast00) USING nast-kappl
                                             nast-kschl
                                    CHANGING nast-cmfpnr.
* This perform updates the NAST table
      PERFORM nast_update(rsnast00) USING lv_rcode.
      IF lv_rcode EQ 0.
        COMMIT WORK.
* Function module to get the "Processing Log"
        CALL FUNCTION 'WFMC_PROTOCOL_LOAD'
          EXPORTING
            cps_nast = nast.
      ENDIF.
    ELSE.
* Error while sending Idoc to &
      MESSAGE e017 WITH is_nach-parnr INTO lv_msg.
      PERFORM build_error_message    USING lv_msg
                                  CHANGING cs_error.
    ENDIF.
  ENDIF.

ENDFORM.                    " SEND_IDOC
*----------------------------------------------------------------------*
*       Form  BUILD_NAST_RECORD
*----------------------------------------------------------------------*
* This form populates the data in NAST
*----------------------------------------------------------------------*
FORM build_nast_record  USING is_nach  STRUCTURE nach.

  CLEAR nast.
  MOVE-CORRESPONDING is_nach TO nast.
  nast-mandt   = sy-mandt.
  nast-objky   = gs_vttk-tknum.
  nast-spras   = sy-langu.
  nast-erdat   = sy-datum.
  nast-eruhr   = sy-uzeit.
  nast-nacha   = '6'.                     " Trans. Medium '6' - EDI
  nast-vsztp   = '4'.                     " Timing 4 - Send Immediately
  nast-manue   = 'X'.                     " Manually proposed output
  nast-usnam   = sy-uname.
  nast-pfld1   = gs_idoc_info-itnum.      " Unused field for Itinerary
  nast-pfld2   = gs_idoc_info-event_code. " Unused filed for Event Code
  nast-objtype = 'VTTK'.

ENDFORM.                    " BUILD_NAST_RECORD
*----------------------------------------------------------------------*
*       Form  BUILD_ERROR_MESSAGE
*----------------------------------------------------------------------*
* This form builds the error message that needs to be returned to SCEM
*----------------------------------------------------------------------*
FORM build_error_message  USING iv_msg   TYPE string
                       CHANGING cs_error STRUCTURE bapiret2.

  cs_error-type        = sy-msgty.
  cs_error-id          = sy-msgid.
  cs_error-number      = sy-msgno.
  cs_error-message     = iv_msg.
  cs_error-message_v1  = sy-msgv1.
  cs_error-message_v2  = sy-msgv2.
  cs_error-message_v3  = sy-msgv3.
  cs_error-message_v4  = sy-msgv4.

ENDFORM.                    " BUILD_ERROR_MESSAGE
*----------------------------------------------------------------------*
*       Form  CHECK_IDOC_SENT
*----------------------------------------------------------------------*
* This form checks whether the IDOC has already been sent to a specific
* partner or not
*----------------------------------------------------------------------*
FORM check_idoc_sent  USING    iv_parnr
                      CHANGING cv_already_sent.

  DATA ls_parnr TYPE tt_idoc_sent.

  READ TABLE gt_idoc_sent INTO ls_parnr WITH KEY parnr = iv_parnr.
  IF sy-subrc EQ 0.
    cv_already_sent = 'X'.
  ELSE.
    CLEAR cv_already_sent.
  ENDIF.

ENDFORM.                    " CHECK_IDOC_SENT

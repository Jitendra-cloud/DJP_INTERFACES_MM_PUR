*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_I02484IDOCINPUTRAILCARTOP.    " Global Data
  INCLUDE LZSD_I02484IDOCINPUTRAILCARUXX.    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_I02484IDOCINPUTRAILCARF...    " Subprograms
* INCLUDE LZSD_I02484IDOCINPUTRAILCARO...    " PBO-Modules
* INCLUDE LZSD_I02484IDOCINPUTRAILCARI...    " PAI-Modules

INCLUDE LZSD_I02484IDOCINPUTRAILCARF01.

class ZCL_IM_DL_LE_WM_INV_WM_IM definition
  public
  final
  create public .

*"* public components of class ZCL_IM_DL_LE_WM_INV_WM_IM
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_LE_WM_INV_WM_IM .
protected section.
*"* protected components of class ZCL_IM_DL_LE_WM_INV_WM_IM
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_DL_LE_WM_INV_WM_IM
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_DL_LE_WM_INV_WM_IM IMPLEMENTATION.


METHOD if_ex_le_wm_inv_wm_im~add_data .
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**           COPYRIGHT (C) 2010 by INTERNATIONAL PAPER                **
**                     ALL RIGHTS RESERVED                            **
**             REVISIONS COPYRIGHT (C) 2010, 20nn                     **
**                    by INTERNATIONAL PAPER                          **
*______________________________________________________________________*
* Badi Impl  : ZDL_LE_WM_INV_WM_IM                   Date: 10/29/2010  *
* Badi Def   " LE_WM_INV_WM_IM                                         *
* Version    : R17I b/f CR10558 Product UOM validations                *
* Programmer : Bruce Ballehr                                           *
*______________________________________________________________________*
* Description :                                                        *
* This Badi Implementation is used for E04523 ZDL_CLEAR transaction    *
* If the Batch quantity has a Production Unit of Measure decimal error *
* then the IM Clear material document needs to have the Reason Code    *
* status set to '0050'.                                                *
* This Badi is called from this "tree of programs":                    *
*   Function Module ZDL_E04523_IM_CLEAR calls                          *
*     Function Module L_IM_DIFFERENCE_CLEAR which calls                *
*         Subroutine badicall_add_data which calls                     *
*           Badi Implementation ZDL_LE_WM_INV_WM_IM of                 *
*             Badi Definition LE_WM_INV_WM_IM                          *
*______________________________________________________________________*
* Change History:                                                      *
*   Programmer       Date     Req. #            Action                 *
* ===============  ========  ========== ===============================*
* Bruce Ballehr    10/29/10  E0VK977196  Fix PUoM Decimal issues.
*______________________________________________________________________*
************************************************************************

  DATA: ls_imseg TYPE imseg,
        ls_add_data TYPE wminv_im_new,

        lv_charg  TYPE charg_d,

        lt_charg_puom TYPE zdl_charg_t,
        ls_charg_puom TYPE zdl_charg_s.


  CALL FUNCTION 'ZDL_E04523_GET_DATA'
    IMPORTING
      et_charg_puom = lt_charg_puom.

  CHECK lt_charg_puom IS NOT INITIAL.

  LOOP AT it_imseg INTO ls_imseg.

    READ TABLE lt_charg_puom INTO ls_charg_puom
      WITH KEY charg = ls_imseg-charg.
    IF sy-subrc = 0.
      MOVE-CORRESPONDING ls_imseg TO ls_add_data.
      ls_add_data-grund = '0050'.
      APPEND ls_add_data TO et_add_data.
    ENDIF.
  ENDLOOP.

ENDMETHOD.
ENDCLASS.

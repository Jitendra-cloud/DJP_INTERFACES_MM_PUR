*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZD_ADVERSE_LOAD
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZD_ADVERSE_LOAD     .

  PERFORM TABLEPROC.

ENDFUNCTION.

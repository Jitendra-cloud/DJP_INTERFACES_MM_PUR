FUNCTION ZSDR6453_PRIME_SALES_CHARS .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IP_VGBEL) TYPE  VGBEL
*"     REFERENCE(IP_VGPOS) TYPE  VGPOS
*"     REFERENCE(IP_VGTYP) TYPE  VBTYP
*"  TABLES
*"      PT_CONFIG_SI STRUCTURE  CONF_OUT
*"----------------------------------------------------------------------

* Get Sales Characteristics for Sales Order or PO associated with
*  Delivery Item
*****************************************************************
  PERFORM get_sales_chars TABLES pt_config_si
                           USING ip_vgbel
                                 ip_vgpos
                                 ip_vgtyp.

ENDFUNCTION.

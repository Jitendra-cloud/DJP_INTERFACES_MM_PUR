*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_DELIVERYF01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_PLANTS_ZDL_FIELDS
*&---------------------------------------------------------------------*
FORM get_plants_zdl_fields .

  SELECT * FROM zdl_fields INTO TABLE gt_zdl_fields
    WHERE category = 'METRIC_CHAR' AND
          fieldname = 'FACILITYID'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_PLANT_SPECIFIC_CHAR
*&---------------------------------------------------------------------*
FORM get_plant_specific_char  USING pv_werks TYPE marc-werks. "CMS32311

  IF line_exists( gt_zdl_fields[ lowval = pv_werks ] ).

    gv_weight_of_roll = zsdc_weight_of_roll_in_kg.
    gv_lineal_char    = zsdc_lineal_meters_m.
  ELSE.
    gv_weight_of_roll = zsdc_weight_of_roll_in_lbs.
    gv_lineal_char    = zsdc_lineal_footage.
  ENDIF.

  CLEAR gt_zdl_fields.

ENDFORM.

FORM convert_to_raw CHANGING pv_atwrt TYPE atwrt.           "CMS32568

  DATA lv_part1 TYPE atwrt.
  DATA lv_part2 TYPE atwrt.

  SPLIT pv_atwrt AT ',' INTO lv_part1 lv_part2.
  REPLACE ALL OCCURRENCES OF '.' IN  lv_part1 WITH ','.
  pv_atwrt = |{ lv_part1 }.{ lv_part2 }|.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  CHECK_DECIMAL_NOMATION
*&---------------------------------------------------------------------*
FORM check_decimal_nomation  CHANGING pv_convert_to_raw.

  SELECT SINGLE 'X' AS european-format FROM usr01
    INTO @pv_convert_to_raw
    WHERE bname = @sy-uname AND
          dcpfm = @space.

ENDFORM.

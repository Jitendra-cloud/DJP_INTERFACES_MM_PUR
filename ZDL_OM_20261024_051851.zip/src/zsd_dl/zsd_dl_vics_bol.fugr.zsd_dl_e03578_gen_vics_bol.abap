FUNCTION zsd_dl_e03578_gen_vics_bol.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IF_TKNUM) LIKE  VTTS-TKNUM
*"  EXPORTING
*"     REFERENCE(OF_VICS_BOL_NUM) TYPE  CHAR19
*"  EXCEPTIONS
*"      MISSING_ZSP_UPC
*"      NON_NUMERIC_SHIPMENT_NUM
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2006                                    **
**                             by                                     **
**                    INTERNATIONAL PAPER                             **
************************************************************************
*______________________________________________________________________*
* Program Name: ZSD_DL_E03578_GEN_VICS_BOL      Create Date: 11/15/2006*
*                                                                      *
* SAP Name    : ZSD_DL_E03578_GEN_VICS_BOL      Version    : Final     *
*                                                                      *
* Programmer  : Randall Wainwright              Last Update: 11/15/2006*
*______________________________________________________________________*
*                                                                      *
*  Title      :  Generate VICS BOL #                                   *
*                                                                      *
* Description :  Generate the VICS BOL # using algorithm and the       *
*                  shipment number                                     *
*"----------------------------------------------------------------------

* Uses the UPC value mapped in the VICS BOL program
  CONSTANTS: c_vics_bol    TYPE programm
                          VALUE 'ZSD_DL_F01266_VICS_BOL',
             c_ip_upc_code TYPE zsp_fieldname VALUE 'IP_UPC_CODE',
             c_ship_dic(5)                    VALUE '(402)'.

  CLEAR of_vics_bol_num.

* Numeric Shipment numbers only
* (Sometimes during an exit, will be '$00001')
* First IF checks if there are any non-numerics and returns the position
*  of a non-numeric in sy-fdpos, starting with 1.
  IF if_tknum NA '1234567890 '. ENDIF.
  IF sy-fdpos = 0.

* EC will complain about the name beginging with a number
    SET EXTENDED CHECK OFF.
    DATA:
      BEGIN OF check,
        01, 02, 03, 04, 05, 06, 07, 08, 09,
        10, 11, 12, 13, 14, 15, 16,                         "17, 18,
                                                            " 19, 20,
      END OF check,
      l_counter(2)  TYPE n,
      l_pos         LIKE sy-fdpos,
      l_string      TYPE string,
      l_sum1        TYPE i,
      l_sum2        TYPE i,
      l_dic(3),
      l_upc(6),                             "6 Digits at beg of BOL #
      l_check_digit TYPE n. "Used in BOL Number
    SET EXTENDED CHECK ON.

    FIELD-SYMBOLS: <fs_cnt> TYPE ANY.

* Get UPC Code from table ZSP_VALUE for 1-6 in BOL Number
    SELECT SINGLE fieldvalue
      FROM zsp_value
      INTO l_upc
     WHERE pgrmid = c_vics_bol
       AND fieldname = c_ip_upc_code.

** Move Ship DIC number to check table.
    l_dic = c_ship_dic+1(3).

    CLEAR l_pos.

* Move UPC number to check table.
    DO 6 TIMES.
      ADD 1 TO l_counter.
      CONCATENATE 'CHECK-' l_counter INTO l_string.
      ASSIGN (l_string) TO <fs_cnt>.
      CLEAR l_string.
      <fs_cnt> = l_upc+l_pos.
      ADD 1 TO l_pos.
    ENDDO.

    CLEAR l_pos.

* Move SHIPMENT NO to check table.
    DO 10 TIMES.
      ADD 1 TO l_counter.
      CONCATENATE 'CHECK-' l_counter INTO l_string.
      ASSIGN (l_string) TO <fs_cnt>.
      CLEAR l_string.
      <fs_cnt> = if_tknum+l_pos.
      ADD 1 TO l_pos.
    ENDDO.

* Calculate check digit.
* Step 1 - Add the even numbered columns and multiply by 3
* Step 2 - Add the odd numbered columns
* Step 3 - Divide by 10
* Step 4 - Figure the value that will get you to the next whole number
    l_sum1 = ( check-02 +
               check-04 +
               check-06 +
               check-08 +
               check-10 +
               check-12 +
               check-14 +
               check-16 ) * 3.
*             check-18 ) * 3.
    l_sum2 = ( check-01 +
               check-03 +
               check-05 +
               check-07 +
               check-09 +
               check-11 +
               check-13 +
               check-15 )." +
*             check-17 +
*             check-19 ).

    l_check_digit = 10 - ( ( l_sum1 + l_sum2 ) MOD 10 ).

* Create BOL Number
    CONCATENATE l_upc if_tknum l_check_digit
           INTO of_vics_bol_num.

  ELSE.

    RAISE non_numeric_shipment_num.

  ENDIF.

  IF l_upc IS INITIAL.
    RAISE missing_zsp_upc.
  ENDIF.

ENDFUNCTION.

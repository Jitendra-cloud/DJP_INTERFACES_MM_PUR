*&---------------------------------------------------------------------*
*&  Include           ZDL_E11734_SYLVAMO_3PP_DEF
*&---------------------------------------------------------------------*
class lcl_3rd_party definition final.
  public section.
***  hmalkow - start
    types: begin of t_process,
             inbdel    type vbeln_vl,
             inbbolnr  type bolnr,
             outdel    type vbeln_vl,
             outbolnr  type bolnr,
             btgew     type gsgew,
             anzpk     type anzpk,
             processed type checkbox,
           end of t_process.

    types: tt_process type standard table of t_process with empty key.
    types: tt_messages type standard table of t_messages.
    types: tt_e11734_notif type standard table of zdl_e11734_notif.

    types: tt_irange type range of i.
    types: tt_err_bolnr type range of bolnr.
    types: tt_err_vbeln type range of vbeln.

    class-data:
      mv_error                type abap_bool,
      mt_process              type tt_process,
      ms_process              type t_process,
      mt_errors               type tt_messages,
      mv_action               type i,
      mr_proper_action        type tt_irange,
      mr_need_gr_check        type tt_irange,
      mr_need_outdel_check    type tt_irange,
      mr_need_pick_pack_check type tt_irange,
      mr_need_shipment_check  type tt_irange,
      mt_e11734_ntf           type tt_e11734_notif,
      mv_notif_email          type abap_bool,
      mv_notif_max            type i,
      mv_notif_threshold      type i,
      mv_notif_usd            type abap_bool,
      mv_notif_usd_priority   type char1,
      mv_notif_usd_retry      type i,
      mv_notif_usd_loop       type i,
      mv_notif_usd_group      type char20,
      mv_ticket_text          type zchar400,
      mv_mail_text            type string,
      ms_hlog                 type bal_s_log,
      mv_lognum               type balognr,
      mt_email                type string_table,
      mr_err_bolnr            type tt_err_bolnr,
      mr_err_vbeln            type tt_err_vbeln,
      mv_usd_created          type abap_bool,
      mv_mail_sent            type abap_bool.
***  hmalkow - end

***** 2000000261 - start
    types: begin of t_ibd_bolnr,
             bolnr type bolnr,
             vbeln type vbeln_vl,
             cnt   type i,
           end of t_ibd_bolnr.

    types: tt_ibd_bolnr type standard table of t_ibd_bolnr.
***** 2000000261 - end

    class-methods:
      get_inb_dlvry_data,
      process,
***** hmalkow - start
      check_action,
      process_shp,
      get_data_for_shp,
      initialization,
      suppress_messages,
      notif_send,
      screen_modify.

***** hmalkow - end

  private section.

    class-methods:
      get_inb_dlvry exporting et_inb_dlvry type ty_t_inb_dlvry
                              et_lips      type ty_t_lips,

      get_inb_with_no_outb exporting et_inb_dlvry type ty_t_inb_dlvry
                                     et_obd_dlvry type ty_t_lips
                                     et_lips      type ty_t_lips,

      get_dlvry_item_info importing it_inb_dlvry type ty_t_inb_dlvry
                          exporting et_lips      type ty_t_lips,

      filter_po_org importing it_lips  type ty_t_lips
                    exporting et_ebeln type ty_t_filter_po,

      filter_so_org importing it_lips   type ty_t_lips
                    exporting et_so_org type ty_t_so_org,

      get_so_item_info importing it_lips    type ty_t_lips
                       exporting et_so_item type ty_t_so_item,

      get_processing_inb_dlvry_data
        importing it_inb_dlvry type ty_t_inb_dlvry
                  it_lips      type ty_t_lips
                  it_filter_po type ty_t_filter_po
                  it_so_org    type ty_t_so_org
                  it_so_item   type ty_t_so_item,

      get_zdl_fields exporting et_fiels type zdl_fields_tab,

      po_lock importing iv_po      type vbeln_von
              exporting ev_lock    type boolean
                        ev_po_user type syst_msgv,

      so_lock importing iv_so      type vbeln_nach
              exporting ev_lock    type boolean
                        ev_so_user type syst_msgv,

      check_lock importing iv_po      type vbeln_von
                           iv_so      type vbeln_nach
                 exporting ev_lock    type boolean
                           ev_po_user type syst_msgv
                           ev_so_user type syst_msgv,

      calculate_quantity importing is_inb_del  type ty_s_inb_dlvry_process
                         exporting ev_quantity type lfimg,

      fill_pick_with_obd importing "iv_obd_dlvry TYPE vbeln_vl
                                   iv_vrkme     type vrkme
                                   it_vbpok     type vbpok_t
                                   ir_obd_dlvry type any table
                         exporting et_vbpok     type vbpok_t,

      compare_batches importing et_obd_dlvry type ty_t_lips
                      changing  ct_inb_dlvry type ty_t_lips,

      get_obd_line_itm importing it_lips type ty_t_lips
                       exporting et_lips type ty_t_lips,

      matnr_lock importing iv_matnr      type matnr
                           iv_werks      type werks_d
                 exporting ev_lock       type boolean
                           ev_matnr_user type syst_msgv,
***** hmalkow - start
      get_service_agent importing iv_vbeln        type vbeln_vl
                        returning value(rv_lifnr) type lifnr,

      get_time_stamp importing iv_date             type  syst_datlo
                               iv_time             type  syst_timlo
                               iv_zone             type  syst_zonlo optional
                     returning value(rv_timestamp) type tzntstmps,

      get_plant_time_zone importing iv_werks           type werks_d
                          returning value(rv_timezone) type tznzone,

      msg_add_bapiret importing iv_notifobj    type znotifobj
                                iv_notifobjtyp type znotifobjtyp
                                it_bapiret     type bapiret2_t,

      msg_add_bal importing iv_notifobj    type znotifobj optional
                            iv_notifobjtyp type znotifobjtyp optional
                            it_balmsg      type zca_bal_msg_tab,

      msg_err_bapiret importing it_bapiret      type bapiret2_t
                      returning value(rv_error) type abap_bool,

      msg_add_empty,

      shipment_create importing iv_inbdel       type vbeln_vl
                                it_ovbeln       type tt_process
                      returning value(rv_tknum) type tknum,

      shipment_setup importing iv_inbdel type vbeln_vl
                               it_ovbeln type tt_process,

      shipment_status_update  importing iv_tknum        type tknum
                                        iv_inbdel       type vbeln_vl
                              returning value(rv_error) type abap_bool,

      unlock,

      out_del_update_route importing iv_outdel type vbeln_vl
                                     is_inbdel type likp,

      update_process_tab importing iv_inbdel type vbeln_vl
                                   ir_outdel type fip_t_vbeln_range,

      check_batches importing iv_vbeln         type vbeln_vl
                    returning value(rv_return) type abap_bool,

      check_gr importing iv_vbeln         type vbeln_vl
               returning value(rv_return) type abap_bool,

      check_outbound_delivery importing iv_vbeln         type vbeln_vl
                              returning value(rv_return) type abap_bool,

      check_picked_packed importing iv_vbeln         type vbeln_vl
                          returning value(rv_return) type abap_bool,

      check_shp importing iv_vbeln         type vbeln_vl
                returning value(rv_return) type abap_bool,

      get_outbound_delivery importing iv_vbeln         type vbeln_vl
                            returning value(rt_outdel) type fip_t_vbeln_range,

      get_shipment importing iv_vbeln        type vbeln_vl
                   returning value(rv_tknum) type tknum,

      get_bolnr importing iv_vbeln        type vbeln_vl
                returning value(rv_bolnr) type bolnr,

      check_all_data importing iv_vbeln         type vbeln_vl
                     returning value(rv_return) type abap_bool,

      get_status_date_time importing is_likp type likp
                           changing  cv_date type sy-datum
                                     cv_time type sy-uzeit,

      check_inbound_delivery importing iv_err           type char1
                             changing  ct_ibd_bolnr     type tt_ibd_bolnr

                             returning value(rv_return) type abap_bool,

      get_delivery_list importing iv_inbout        type char1
                                  it_process       type tt_process
                        returning value(rv_return) type symsgv,
***** hmalkow - end
***  hmalkow1 - start
      notif_read_conf,
      notif_get_log_errors,
      notif_create_text,
      notif_not_sent,
      notif_get_usd_group returning value(rv_group) type char30,
      notif_usd importing iv_subject     type bcs_subject
                returning value(rv_sent) type abap_bool,

      notif_send_mail importing iv_subject     type bcs_subject
                      returning value(rv_sent) type abap_bool,

      notif_get_zdl_e11734 importing is_error         type t_messages optional
                                     is_e11734_notif  type zdl_e11734_notif optional
                           returning value(rs_return) type zdl_e11734_notif,

      notif_upd_zdl_e11734 returning value(rv_updated) type abap_bool.
***  hmalkow1 - end

endclass.

************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2007                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: VTTS Z TRANSCATION              Create Date: 05/14/07  *
*                                                                      *
* SAP Name    : Z03732_VTTS_Z_TRANSCATION_001        Version    :      *
*                                                                      *
* Programmer  : Naveen Parchuri                                        *
* Kishore Thakur      08/12/08  CR-8022  - Implemented gate Exit       *
*                               Reversal logic for external and Z03732 *
*                               Added a Reverse button in screen 303   *
*                               for gate-exit reversal.                *
*                               Transport# EDEK912945                  *
*                               Transport# EDEK913754                  *
* Kishore Thakur/Padma Sunkara  11/05/08  pricef  -E07126, E07127      *
*                               Added functionality for updating dock  *
*                               and trailer id(container id) in        *
*                               screen 303 and in screen 304 added     *
*                               the functionality to capture the intent*
*                               if the user is requested or confirmed  *
*                               and set the code for qualifier         *
*                               accordingly(i.e.IDOC for behalf of     *
*                               distribution center in pickup          *
*                               appointment date/time window.          *
*                               Transport# ESBK9A07VO
*                               TPR # 30092  Transport# EDVK969175
* Sukanya      04/2/2018       CMS#33493: Heuristic protection checkbox*
*                              Production fix-Icon change              *
* Helena Malkowska  02/2020    2000006956: Enhancement for Madrid      *
*                              Add the ability to print out the existing
*                              documents EMEA CMR and Delivery Note    *
************************************************************************
module status_0100 output.

  data:  lv_dummy type zztsnum.                             "BCB02

  select single lowval into gv_lowval
  from zdl_fields
  where category = gc_category
  and   fieldname = gc_fieldname.

  data: lt_excl_100 type table of sy-ucomm  .
* disable the prev,next ,first and last  buttons
  append 'PREV' to lt_excl_100.
  append 'NEXT' to lt_excl_100.
  append 'PREVF' to lt_excl_100.
  append 'NEXTE' to lt_excl_100.
*CMS#32822
  append 'SAVE' to lt_excl_100.
*CMS#32822
  set pf-status 'MAIN01' excluding lt_excl_100.
  set titlebar 'MAIN01'.

  clear: gv_tsnum.                                          "BCB01
  get parameter id 'ZTN' field gv_tsnum.                    "BCB01
  set parameter id 'ZTN' field lv_dummy. "BCB02 clear shipment stage PID

***** 2000006956 - start
  clear: lcl_non_us_enh=>gv_non_us.
***** 2000006956 - end
endmodule.                 " STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0200 output.
  data: lt_excl_200 type table of sy-ucomm  .

  append 'PREV' to lt_excl_200.
  append 'ENTER' to lt_excl_200.
  append 'NEXT' to lt_excl_200.
  append 'PREVF' to lt_excl_200.
  append 'NEXTE' to lt_excl_200.
  set pf-status 'MAIN01' excluding lt_excl_200 .

*CMS 33493-Production fix
  perform shipment_screen_protect.
*CMS 33493
* shipment details
  perform get_data .
* set the titlebar
  perform set_titlebar.
* get the status ICON
  perform get_status_icon.
* set the grid for display
  perform prepare_control.
* select all records
  perform get_all_records.
endmodule.                 " STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0300  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0300 output.
  data: lt_excl      type table of sy-ucomm,
        lv_stage(50).
  clear lt_excl.
  refresh lt_excl.


* get the titlebar for the
  clear gt_stages_valid.
  clear lv_stage.
  read table gt_stages_valid index gv_index.
  concatenate  'Shipment'
               vttk-tknum
               'Stage'
               gt_stages_valid-tsnum
               'information'
     into lv_stage
     separated by space.

* check for the save button
  perform save.

* exclude the overview & shipment log buttons
  append 'ENTER' to lt_excl.
  append 'CHNLOG' to lt_excl.

* for first record exclude prev & first buttons
  if gv_index = 1 .
    append 'PREV' to lt_excl.
    append 'PREVF' to lt_excl.
  endif.

  describe table gt_stages_valid lines gv_lines.

* for last record exclude last  buttons
  if gv_index = gv_lines.
    append 'NEXT' to lt_excl.
    append 'NEXTE' to lt_excl.
  endif.
* set the pf status
  set pf-status 'MAIN01' excluding lt_excl.
  set titlebar 'MAIN03' with lv_stage.


* set the header fields
  perform set_header_fields.

***** 2000006956 - start
  lcl_non_us_enh=>read_zdl_fields( vtts-tknum ).
***** 2000006956 - end

endmodule.                 " STATUS_0300  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  TC_CHG1_MASTER_ACTIVE_TAB_SET  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module tc_chg1_master_active_tab_set output.
*get the pressed tab
  tc_chg1_master-activetab = g_tc_chg1_master-pressed_tab.
  case g_tc_chg1_master-pressed_tab.
    when c_tc_chg1_master-tab1.
      g_tc_chg1_master-subscreen = '0301'.
    when c_tc_chg1_master-tab2.
      g_tc_chg1_master-subscreen = '0302'.
    when c_tc_chg1_master-tab3.
      g_tc_chg1_master-subscreen = '0303'.
    when c_tc_chg1_master-tab4.
      g_tc_chg1_master-subscreen = '0304'.

    when others.
  endcase.

endmodule.                 " TC_CHG1_MASTER_ACTIVE_TAB_SET  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0301  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0301 output.
  scr_dtz = vtts-zz_dep_tz.
*  SET PF-STATUS 'MAIN01' excluding lt_excl_301.
*  SET TITLEBAR 'xxx'.

* CMS31525|ChangedBy:AMAOLE1|ChangedOn:02212017|START1
  if ( vttk-vlstk = '2' or vttk-vlstk = '4' ).
    if vtts-zz_stopnum_o = '1' .
      perform grey_out_screen_element using 'DAH'.
    else.
      perform grey_out_screen_element using 'PAH'.
    endif.
  elseif vttk-vlstk = '3' and vtts-zz_stopnum_o = '0'.
    perform grey_out_screen_element using 'PAH'.
  endif.
* CMS31525|ChangedBy:AMAOLE1|ChangedOn:02212017|END1

endmodule.                 " STATUS_0301  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0302  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0302 output.

* set the conf. delv. appt. date and time
  clear scr_app.
  if vtts-zz_cda_made_dt is not initial.
    concatenate 'Confirmed Delivery Appt made at'(047)
                 vtts-zz_cda_made_dt
                '/'
                 vtts-zz_cda_made_ti
                into scr_app separated by space.
  else.
    scr_app = 'Confirmed Delivery Appt not yet made'(057).
  endif.

* if the stoptype destination is blank or if display
* mode set the screen to display mode
  if gv_display = 'X' or
     vtts-zz_stoptype_d = ' ' .
    loop at screen.
      if screen-group1 = 'AAA' or
         screen-group1 = 'BBB' or
         screen-group1 = 'CCC'.
        screen-input = 0 .
        modify screen.
      endif.
    endloop.
  endif.
endmodule.                 " STATUS_0302  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0303  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0303 output.
*  SET PF-STATUS 'xxxxxxxx'.
*  SET TITLEBAR 'xxx'.

***** 2000006956 - start
  data: bol(20) type c.

  if lcl_non_us_enh=>gv_non_us = 'Y'.
    bol = 'SHP DOC'.
  else.
    bol = 'BOL'.
  endif.
***** 2000006956 - end

  scr_timza  = vtts-zz_dep_tz.

  "   scr_dock_desc = scr_txt_door.

*    scr_dock_desc = scr_txt_door.
*  if sy-ucomm <> 'ENTR'.
*   vttk-signi =  gv_signi_old.
*  endif.

* if the stoptype origin is blank or if display
* mode set the screen to display mode
  if gv_display = 'X' or
     vtts-zz_stoptype_o = ' '.
    loop at screen.
      if screen-group1 = 'AAA' or
         screen-group1 = 'BBB' or
         screen-group1 = 'CCC' or
         screen-name   = 'REV' or
         screen-name   = 'REVE' or
         screen-name   = 'PICK_PACK' or "psunkar/03/27/08 EDEK911301
         screen-name   = 'GATE_EXIT' or
         screen-name   = 'BOL'  or " end of changes /psunkar/03/27/08
                                   " Transport# EDEK911301

         screen-name  = 'GATE_EXIT_REV' or "psunkar /08/12/08
         screen-name   = 'DISPS'.

        screen-input = 0.
        modify screen.
      endif.
    endloop.
  endif.
  perform set_header_fields.

* Begin BCB04 insert
* If the user hits the Enter key on Screen 0303 do not overlay the value
* of the Dock Door screen field t30b-lgtor with the value in the
* database (LIKP-LGTOR).
* If the user hits the Enter key on Screen 0303 do not overlay the value
* of the Staging Area screen field t30c-lgbzo with the value in the
* database (LIKP-LGBZO).
* We want to retained so that if the user
* finally hits the SAVE button we can compare values and tell if a
* change has occurred and update it properly.
  if sy-ucomm ne 'ENTR'.
* End BCB04 insert
    t30b-lgtor =  scr_dock_door.
*//Begin of R16I Big Button Update Staging Area changes 10/13/09
    t30c-lgbzo =  scr_staging_area.
*// End of R16I Big Button Update Staging Area changes 10/13/09
* Begin BCB04 insert
  else.
*   If we came into the Big Buttom from the DSD the weird thing is that
*   sy-ucomm is set to 'ENTR' even thought the 'Big Button' button on
*   the DSD has a Function Code of 'BB'. So, the following code
*   accounts for this scenario:

*   If came into Big Button from DSD and the Dock Door screen field is
*   blank and the Database Dock Door is not blank then format the
*   screen field with the database value
    if t30b-lgtor is initial and scr_dock_door is not initial
      and gv_enter_pressed = space. "BCB05 insert
      t30b-lgtor =  scr_dock_door.
    endif.

*   If came into Big Button from DSD and the Staging Area screen field
*   is blank and the Database Staging Area is not blank then format
*   the screen field with the database value
    if t30c-lgbzo is initial and scr_staging_area is not initial
      and gv_enter_pressed = space. "BCB05 insert
      t30c-lgbzo =  scr_staging_area.
    endif.

  endif.
* End BCB04 insert

* Store the before value of the Staging Area "BCB05 insert
  gv_lgbzo_prev = t30c-lgbzo. "BCB05 insert

* Store the before value of the Dock Door "BCB05 insert
  gv_lgtor_prev = t30b-lgtor. "BCB05 insert

endmodule.                 " STATUS_0303  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0304  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0304 output.
*  SET PF-STATUS 'xxxxxxxx'.
*  SET TITLEBAR 'xxx'.
* if the stoptype origin is blank or if display
* mode set the screen to display mode
  if gv_display = 'X' or
    vtts-zz_stoptype_o = ' ' .
    loop at screen.
      if screen-group1 = 'AAA' or
         screen-group1 = 'CCC'.
        screen-input = 0.
        modify screen.
      endif.
    endloop.
  endif.
endmodule.                 " STATUS_0304  OUTPUT

* CMS31525|ChangedBy:AMAOLE1|ChangedOn:02212017|START2
form grey_out_screen_element using name type screen-name.

  loop at screen.
    if screen-name eq name.
      screen-input = 0.
      modify screen.
    endif.
  endloop.

endform.
* CMS31525|ChangedBy:AMAOLE1|ChangedOn:02212017|END2

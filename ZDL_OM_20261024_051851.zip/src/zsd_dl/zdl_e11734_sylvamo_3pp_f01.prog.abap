*&---------------------------------------------------------------------*
*&  Include           ZDL_E11734_SYLVAMO_3PP_F01                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  sele_scr_val
*&---------------------------------------------------------------------*
* Selection-screen variable validations:
*         Validate Shipping point against table TVST;
*         Inbound deliveries against SHP_IDX_GDRC (only open inbound
*           deliveries) - if any specific inbound delivery(ies) is(are)
*           passed, retrieve all open inbound deliveries;
*         Outbound deliveries against LIKP table
*----------------------------------------------------------------------*
form sele_scr_val.

** If all checkbox are initial, ask them to select one
*  if sp_posgr is initial and
*     sp_vl01n is initial and
*     sp_charg is initial.
** Select any one of the checkbox.
*    message e211.
*  endif.

* Begin CR# 11871 10/01/12
  if so_vsbed[] is not initial.
    if sp_posgr is initial.
      message e000 with 'Shipping condition valid Post GR only'(e04) ' ' ' '.
    elseif sp_vl01n is not initial or sp_charg is not initial.
      message e000 with 'Shipping condition valid Post GR only'(e04) ' ' ' '.
    endif.
  endif.
* End CR# 11871 10/01/12

  perform ship_point_val.

***** hmalkow - start
  if sp_posgr is not initial or
     sp_vl01n is not initial or
     sp_charg is not initial .

***** hmalkow - end
*  PERFORM inb_dlvry_val. "JWILL68 CD#1626
    lcl_3rd_party=>get_inb_dlvry_data( )."JWILL68 CD#1626

    if ( not sp_vbeln is initial ) and
       ( not sp_charg is initial ).
      perform out_dlvry_val.
    elseif ( not sp_charg is initial ) and
           (     sp_vl01n is initial   and
                 sp_vbeln is initial ).
* Select either 'Run create outbound delivery or
* Pass outbound delivery
      message e205.
    endif.

***** hmalkow - start
  else.
    lcl_3rd_party=>get_data_for_shp( ).
    if lcl_3rd_party=>mt_process is initial.
      "No Inbound found for processing
      message w124(zdl_sylvamo_3pp).
      return.
    endif.
  endif.
***** hmalkow - end

endform.                    " sele_scr_val
*&---------------------------------------------------------------------*
*&      Form  ship_point_val
*&---------------------------------------------------------------------*
* Validate Shipping/Receiving point against table TVST
*----------------------------------------------------------------------*
form ship_point_val.

  data: lv_lifnr like lfa1-lifnr,                     " CR# 11871 09/10/12
        lv_werks type werks_d,                        " CR# 11871 09/10/12
        lv_vsbed type vsbed,                          " CR# 11871 10/01/12
        begin of lt_tmp occurs 0,                         " CR# 11871 09/10/12
          lifnr type lifnr,                            " CR# 11871 09/10/12
        end of lt_tmp,                                    " CR# 11871 09/10/12
        begin of lt_tmp2 occurs 0,                        " CR# 11871 09/10/12
          werks type werks_d,                          " CR# 11871 09/10/12
        end of lt_tmp2,                                   " CR# 11871 10/01/12
        begin of lt_tmp3 occurs 0,                        " CR# 11871 10/01/12
          vsbed type vsbed,                            " CR# 11871 10/01/12
        end of lt_tmp3.                                   " CR# 11871 10/01/12

* Begin CR# 11871 09/10/12
  if so_plant[] is not initial.
    loop at so_plant.
      if so_plant-sign eq 'I'.
        if so_plant-low is not initial.
          move so_plant-low+0(4) to lt_tmp2-werks.
          append lt_tmp2.
        endif.
        if so_plant-high is not initial.
          move so_plant-high+0(4) to lt_tmp2-werks.
          append lt_tmp2.
        endif.
      endif.
    endloop.
  endif.

  loop at lt_tmp2.
    select single werks into lv_werks from zplant
        where werks eq lt_tmp2-werks.
    if sy-subrc is not initial.
      message e000 with 'Invalid Plant'(e01) ' ' lt_tmp2-werks.
      exit.
    endif.
  endloop.
* End CR# 11871 09/10/12


  select werks
   into corresponding fields of table gt_inb_dlvry
   from t001w
*    WHERE werks = sp_plant.   " CR# 11871 09/10/12
   ##too_many_itab_fields
   where werks in so_plant.   " CR# 11871 09/10/12
  if sy-subrc <> 0.
* Invalid shippping/receiving point.
    message e200.
  endif.


* Begin CR# 11871 10/01/12
  if so_vsbed[] is not initial.
    loop at so_vsbed.
      if so_vsbed-sign eq 'I'.
        if so_vsbed-low is not initial.
          move so_vsbed-low+0(2) to lt_tmp3-vsbed.
          append lt_tmp3.
        endif.
        if so_vsbed-high is not initial.
          move so_vsbed-high+0(2) to lt_tmp3-vsbed.
          append lt_tmp3.
        endif.
      endif.
    endloop.
  endif.

  if lt_tmp3[] is not initial.
    loop at lt_tmp3.
      select single vsbed into lv_vsbed from tvsb
        where vsbed eq lt_tmp3-vsbed.
      if sy-subrc is not initial.
        message e000 with 'Invalid Shipping Condition'(e03) ' ' lt_tmp3-vsbed.
        exit.
      endif.
    endloop.
  endif.
* End CR# 11871 10/01/12

* Begin CR# 11871 09/10/12
  if so_lifnr[] is not initial.
    loop at so_lifnr.
      if so_lifnr-sign eq 'I'.
        if so_lifnr-low is not initial.
          move so_lifnr-low+0(10) to lt_tmp-lifnr.
          append lt_tmp.
        endif.
        if so_lifnr-high is not initial.
          move so_lifnr-high+0(10) to lt_tmp-lifnr.
          append lt_tmp.
        endif.
      endif.
    endloop.
  endif.

  if lt_tmp[] is not initial.
    loop at lt_tmp.
      select single lifnr into lv_lifnr from lfa1
        where lifnr eq lt_tmp-lifnr.
      if sy-subrc is not initial.
        message e000 with 'Invalid Vendor'(e02) ' ' lt_tmp-lifnr.
        exit.
      endif.
    endloop.
  endif.
* End CR# 11871 09/10/12

endform.                    " ship_point_val
*&---------------------------------------------------------------------*
*&      Form  inb_dlvry_val
*&---------------------------------------------------------------------*
* Validate Inbound deliveries (Open) against the table SHP_IDX_GDRC
* Whenever an inbound delivery has been created for the plant 9427
* the table SHP_IDX_GDRC is not populated with receiving plant.
* Hence pick all inbound deliveries from LIPS where Delivery # =
* SHP_IDX_GDRC-VBELN
*----------------------------------------------------------------------*
form inb_dlvry_val .

*** Start of modification by ALANKAP on 10/20/2015
*  IF NOT sp_posgr IS INITIAL.
*    SELECT lk~vbeln lp~werks lp~vgbel "Inb. dlvry, plant, pur.order
*      INTO TABLE gt_inb_dlvry
*      FROM shp_idx_gdrc AS lk
*           inner join likp as lik        " CR# 11871 10/08/2012
*                 on lk~vbeln = lik~vbeln " CR# 11871 10/08/2012
*           INNER JOIN lips AS lp
*                 ON   lk~vbeln = lp~vbeln
*     WHERE lk~vbeln      IN   so_vbeln
**       AND lp~werks    =    sp_plant.   " CR# 11871 09/10/2012
*       AND lk~lifnr      IN so_lifnr     " CR# 11871 09/10/2012
*       and lik~vsbed     in so_vsbed     " CR# 11871 10/08/2012
*       AND lp~werks      IN so_plant.    " CR# 11871 09/10/2012
*  ELSE.
** If already GR is posted for the inbound delivery, then we will not
** find it in table SHP_IDX_GDRC.  Hence pick from LIKP; make sure that
** we pick only inbound deliveries - this has been made sure by
** ZZXREFDETAIL
*    PERFORM deliv_types.
*
*    IF NOT so_vbeln[] IS INITIAL.
*      SELECT lk~vbeln lp~werks lp~vgbel "Inb. dlvry, plant, pur.order
*        INTO TABLE gt_inb_dlvry
*        FROM likp AS lk
*             INNER JOIN lips AS lp
*                   ON   lk~vbeln = lp~vbeln
*       WHERE lk~vbeln     IN so_vbeln
*         AND lk~lifnr     IN so_lifnr    " CR# 11871 09/10/2012
**         AND lp~werks     =  sp_plant   " CR# 11871 09/10/2012
*         AND lp~werks     IN so_plant    " CR# 11871 09/10/2012
*         AND lk~lfart     IN gr_xref.
*    ELSE.
** Pleae specify the inbound delivery
*      MESSAGE e210.
*    ENDIF.
*  ENDIF.
*IF sy-subrc <> 0.
** No open inbound deliveries found for the given criteria.
*    MESSAGE i201.
*    STOP.
*  ELSE.
*    SORT gt_inb_dlvry BY vbeln
*    DELETE ADJACENT DUPLICATES FROM gt_inb_dlvry
*                    COMPARING  vbeln.
*  ENDIF.
* 33303 - we can assume that every selected delivery item will have a
* valid PO number in LIPS-VGBEL so we can get EKKO to validate EKORG
* and an originating document in VBAK so we can validate VKORG
  if not sp_posgr is initial.
    select lk~vbeln lp~werks lp~vgbel lp~vbelv "Inb. dlvry, plant, pur.order
           vbak~vkorg ekko~ekorg                                "33303
           lik~zz_complete "JWILL68 CD#2000000395
      into table gt_inb_dlvry
      from shp_idx_gdrc as lk
           inner join likp as lik        " CR# 11871 10/08/2012
                 on lk~vbeln = lik~vbeln " CR# 11871 10/08/2012
           inner join lips as lp
                 on   lk~vbeln = lp~vbeln
           join ekko on ekko~ebeln = lp~vgbel                   "33303
           join vbak on vbak~vbeln = lp~vbelv                   "33303
     where lk~vbeln      in   so_vbeln
*       AND lp~werks    =    sp_plant.   " CR# 11871 09/10/2012
       and lk~lifnr      in so_lifnr     " CR# 11871 09/10/2012
       and lik~vsbed     in so_vsbed     " CR# 11871 10/08/2012
       and lp~werks      in so_plant     " CR# 11871 09/10/2012
       and vbak~vkorg    in so_vkorg                            "33303
       and ekko~ekorg    in so_ekorg.                           "33303
  else.
* If already GR is posted for the inbound delivery, then we will not
* find it in table SHP_IDX_GDRC.  Hence pick from LIKP; make sure that
* we pick only inbound deliveries - this has been made sure by
* ZZXREFDETAIL
    perform deliv_types.

    if not so_vbeln[] is initial.
      select lk~vbeln lp~werks lp~vgbel lp~vbelv "Inb. dlvry, plant, pur.order
             vbak~vkorg ekko~ekorg                              "33303
             lk~zz_complete "JWILL68 CD#2000000395
        into table gt_inb_dlvry
        from likp as lk
             inner join lips as lp
                   on   lk~vbeln = lp~vbeln
             join ekko on ekko~ebeln = lp~vgbel                 "33303
             join vbak on vbak~vbeln = lp~vbelv                 "33303
       where lk~vbeln     in so_vbeln
         and lk~lifnr     in so_lifnr    " CR# 11871 09/10/2012
*         AND lp~werks     =  sp_plant   " CR# 11871 09/10/2012
         and lp~werks     in so_plant    " CR# 11871 09/10/2012
         and lk~lfart     in gr_xref
         and vbak~vkorg   in so_vkorg                            "33303
         and ekko~ekorg   in so_ekorg.                           "33303
    else.
* Pleae specify the inbound delivery
      message e210.
    endif.
  endif.
  if sy-subrc <> 0.
* No open inbound deliveries found for the given criteria.
    message i201.
    stop.
  else.

    sort gt_inb_dlvry by vbeln vbelv.    "Inb.deliveries
    delete adjacent duplicates from gt_inb_dlvry
                    comparing  vbeln vbelv.
*** End modification by ALANKAP 10/20/2015 CMS 29123
  endif.

endform.                    " inb_dlvry_val
*&---------------------------------------------------------------------*
*&      Form  out_dlvry_val
*&---------------------------------------------------------------------*
* Validate Outbound deliveries against the table LIKP
*----------------------------------------------------------------------*
form out_dlvry_val.

  select single vbeln      "Outbound deliveries
    into sp_vbeln
    from likp
    where vbeln   =     sp_vbeln.

  if sy-subrc <> 0.
* Invalid outbound delivery
    message e206.
  endif.
endform.   "out_dlvry_val

*&---------------------------------------------------------------------*
*&      Form  output
*&---------------------------------------------------------------------*
* Display or update the application log with the messages
*----------------------------------------------------------------------*
form output.

  constants:
    lc_obj type balobj_d   value 'ZDL_INTERFACE',
    lc_sub type balsubobj  value 'ZDL_E11734'.

  data:
    ls_log    type bal_s_log,
    lv_handle type balloghndl,
    lv_hlog   type bal_s_log,
    lv_lognum type balognr,
    lt_handle type bal_t_logh.

***  hmalkow1 - start
  data: lt_messages type zca_bal_msg_tab.
***  hmalkow1 - end

  lcl_3rd_party=>suppress_messages( ).

  check not gt_messages[] is initial.

***  hmalkow1 - start
  lt_messages[] = corresponding #( gt_messages[] ).
***  hmalkow1 - end

* Save application log
  ls_log-object     = lc_obj.
  ls_log-subobject  = lc_sub.

  call function 'Z_GEN_APP_LOG_MULT'
    exporting
      is_log_header = ls_log
    importing
      if_log_handle = lv_handle
    tables
      it_messages   = lt_messages[].

***  hmalkow1 - start
  call function 'BAL_LOG_HDR_READ'
    exporting
      i_log_handle  = lv_handle
    importing
      e_s_log       = lv_hlog
      e_lognumber   = lv_lognum
    exceptions
      log_not_found = 1
      others        = 2.

  if sy-subrc = 0.
    lcl_3rd_party=>ms_hlog  = lv_hlog.
    lcl_3rd_party=>mv_lognum = lv_lognum.
    lcl_3rd_party=>notif_send( ).
  endif.
***  hmalkow1 - end

* E0VK926702 TPR17697 - point (1) - check sy-batch is initial
* instead of = 0 to avoid background job failing
  if sy-batch is initial. " = 0."Online - TPR 17697
* Display the application log
    refresh lt_handle.
    append lv_handle to lt_handle.
    call function 'BAL_DSP_LOG_DISPLAY'
      exporting
        i_t_log_handle       = lt_handle[]
      exceptions
        profile_inconsistent = 1
        internal_error       = 2
        no_data_available    = 3
        no_authority         = 4
        others               = 5.

* TPR 17697 - Point (4) - To see messages in the spool if the
* program runs in background - start
  else.
    perform generate_report.
* TPR 17697 - End
  endif.

endform.                    " output
*&---------------------------------------------------------------------*
*&      Form  enable_out_dlvry
*&---------------------------------------------------------------------*
* Loop through screen elements, if 'Run Pick, Pack' has been selected
* get outbound deliveries from users
*----------------------------------------------------------------------*
form enable_out_dlvry.

  loop at screen.
    if screen-group1 = 'ODY'.
      if not sp_charg is initial.
        screen-input = 1.
      else.
        screen-input = 0.
      endif.
    endif.
    modify screen.
  endloop.

endform.                    " enable_out_dlvry
*&---------------------------------------------------------------------*
*&      Form  deliv_types
*&---------------------------------------------------------------------*
* Get all inbound delivery types from ZZXREFDETAIL table
*----------------------------------------------------------------------*
form deliv_types .

  constants:
    lc_group    like zzxrefdetail-zzgroup    value 'DELIVER',
    lc_groupset like zzxrefdetail-zzgroupset value '3PDELIVTYPE'.

  data:
    lt_zzxrefdetail like table of zzxrefdetail,
    ls_zzxrefdetail like zzxrefdetail.

  select zzgroup zzgroupset zzkey1 zzvalue1
    into corresponding fields of table lt_zzxrefdetail
    from zzxrefdetail
    where zzgroup     = lc_group
      and zzgroupset  = lc_groupset
     ##too_many_itab_fields
      and zzvalue1    = 'I'.    "I for inbound

  if sy-subrc = 0.
* Move into range table
    refresh gr_xref.
    loop at lt_zzxrefdetail into ls_zzxrefdetail.
      gr_xref-sign   = 'I'.
      gr_xref-option = 'EQ'.
      gr_xref-low    = ls_zzxrefdetail-zzkey1.
      append gr_xref.
      clear  gr_xref.
    endloop.
  endif.

endform.                    " deliv_types
*&---------------------------------------------------------------------*
*&      Form  generate_report
*&---------------------------------------------------------------------*
* Prepare report to see the application log output in the spool list
* of the background job
*----------------------------------------------------------------------*
form generate_report.

  constants:
    lc_msgty like sy-msgty value 'E',
    lc_msgid like sy-msgid value 'ZSD_DL',
    lc_msgno like sy-msgno value '000'.

  data:
*   ls_message   type bal_s_msg,
    lv_mess(255).

* Display all message as we stored in application log
  loop at gt_messages into data(ls_message).

    if ls_message-msgid is initial.
      sy-msgid = lc_msgid.
    else.
      sy-msgid = ls_message-msgid.
    endif.

    if ls_message-msgty is initial.
      sy-msgty = lc_msgty.
    else.
      sy-msgty = ls_message-msgty.
    endif.

    if ls_message-msgno is initial.
      sy-msgno = lc_msgno.
    else.
      sy-msgno = ls_message-msgno.
    endif.

    sy-msgv1 =  ls_message-msgv1.
    sy-msgv2 =  ls_message-msgv2.
    sy-msgv3 =  ls_message-msgv3.
    sy-msgv4 =  ls_message-msgv4.

    message id sy-msgid type sy-msgty number sy-msgno
            with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
            into lv_mess.

    write / lv_mess.

  endloop.

endform.                    " generate_report
*&---------------------------------------------------------------------*
*&      Form  PRINT_HEADING
*&---------------------------------------------------------------------*
*  Prepare IP's standard report header
*----------------------------------------------------------------------*
form print_heading .

  constants:
    lc_heading(50) value 'Third Party Automated Process'.

  data:
    lt_head        type zrptheader occurs 0 with header line.

* Prepare Report Header
  call function 'Z_RPT_HEADER'
    exporting
      primary      = lc_heading
    tables
      header_lines = lt_head
    exceptions
      others       = 1.

  if sy-subrc <> 0.
    message id sy-msgid type sy-msgty number sy-msgno
            with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  else.
    write:
      / lt_head-line1,
      / lt_head-line2,
      / lt_head-line3.
  endif.

endform.                    " PRINT_HEADING

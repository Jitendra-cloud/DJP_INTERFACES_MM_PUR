class ZCL_IM_DL_E01462_CARR_COMM definition
  public
  final
  create public .

*"* public components of class ZCL_IM_DL_E01462_CARR_COMM
*"* do not include other source files here!!!
public section.

  interfaces /GCDS04/IF_EX_SND_DLV_FLDS .
protected section.
*"* protected components of class ZCL_IM_DL_E01462_CARR_COMM
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_DL_E01462_CARR_COMM
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_DL_E01462_CARR_COMM IMPLEMENTATION.


method /GCDS04/IF_EX_SND_DLV_FLDS~ADD_FIELDS .

  constants: lc_type_delv type vbtyp value 'J',          " Delivery
             lc_type_salesord type vgtyp value 'C',      " Sales order
             lc_category type zcatgory value 'E01462',
             " COR# Inventory number
             lc_kdmat type fieldname value 'KDMAT',      " CMIR#
             lc_incl type cacsasign value 'I',
             lc_eq type cacsoption value 'EQ'.

  data: l_atpfield type atpfield,
        ws_zdl_fields type zdl_fields.

break cmorr18.
*break adhumba.

*** Make sure to process only Deliveries with a Sales order
  if i_fxlips-vgtyp = lc_type_salesord and i_fxlikp-vbtyp = lc_type_delv
  .
    select single * from zdl_fields
                    into ws_zdl_fields
                    where category  = lc_category
                      and fieldname = lc_kdmat
                      and sign      = lc_incl
                      and optn      = lc_eq
                      and lowval    = i_fxlikp-lfart
                      and highval   = ' '.
*** Process further only if it has an entry in table ZDL_FIELDS
    if sy-subrc = 0.
      clear: l_atpfield-kfdna, l_atpfield-value.
*** Make sure the Delivery has a corresponding Sales Order
      if not i_fxlips-vgbel is initial.
        select single kdmat
               from vbap
               into l_atpfield-value
               where vbeln = i_fxlips-vgbel
                 and posnr = i_fxlips-vgpos.
*** Update ATP fields only if the CMIR# is available.
        if not l_atpfield-value is initial.
          l_atpfield-delnr = i_fxlips-vbeln.
          l_atpfield-delps = i_fxlips-posnr.
          l_atpfield-kfdna = 'ZKDMAT'.
          append l_atpfield to ct_atpfield.
        endif.
      endif.
    endif.
  endif.

endmethod.
ENDCLASS.

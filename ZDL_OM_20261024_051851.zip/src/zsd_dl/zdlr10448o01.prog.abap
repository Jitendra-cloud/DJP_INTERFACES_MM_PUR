*&---------------------------------------------------------------------*
*&  Include           ZDLR10448O01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  EXIT_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
module exit_command_0100 input.

  set screen 0.
  leave screen.

endmodule.

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
module user_command_0100 input.


  lcl_rpt=>gv_ucomm = lcl_rpt=>gv_okcode.
  clear lcl_rpt=>gv_okcode.

  case lcl_rpt=>gv_ucomm.

    when 'PRINT'.


    when 'ADD'.


  endcase.

endmodule.

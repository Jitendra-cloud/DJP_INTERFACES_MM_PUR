FUNCTION zdl_rail_rate_ecc.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IR_PLND_SHP_DATE) TYPE  PIQ_SELOPT_T
*"  EXPORTING
*"     REFERENCE(ET_ADVERSE_RAIL_RATE) TYPE  ZDLE11459_LT_RAIL_RATE_T
*"  TABLES
*"      I_T_SELECT TYPE  SRSC_S_IF_SIMPLE-T_SELECT OPTIONAL
*"      I_T_FIELDS TYPE  SRSC_S_IF_SIMPLE-T_FIELDS OPTIONAL
*"----------------------------------------------------------------------

  TYPES: BEGIN OF t_cond.
           INCLUDE TYPE komg.
           TYPES: knumh TYPE knumh,
           kappl TYPE kappl,
           kschl TYPE kschl,
           datbi TYPE kodatbi,
           datab TYPE kodatab,
         END OF t_cond.

  TYPES: BEGIN OF t_rail_rate.
           INCLUDE TYPE zdle11459_lt_rail_rate.
           TYPES: knumh TYPE knumh,
         END OF t_rail_rate.

  TYPES: t_kappl TYPE RANGE OF kappl.
  TYPES: t_kschl TYPE RANGE OF kschl.

  DATA: lr_kappl      TYPE t_kappl,
        lr_kschl      TYPE t_kschl,
        lr_valid_date TYPE RANGE OF sy-datum,
        lt_cond       TYPE SORTED TABLE OF t_cond
        WITH NON-UNIQUE KEY knumh,
        lt_rail_rate  TYPE STANDARD TABLE OF t_rail_rate.

  REFRESH lt_rail_rate[].

** Fill the ranges
  LOOP AT i_t_select INTO DATA(ls_select).

    CASE ls_select-fieldnm.
      WHEN 'KAPPL'.
        lr_kappl = VALUE #( ( sign = ls_select-sign
                              option = ls_select-option
                              low    = ls_select-low
                              high   = ls_select-high ) ).

      WHEN 'KSCHL'.
        lr_kschl = VALUE #( ( sign = ls_select-sign
                              option = ls_select-option
                              low    = ls_select-low
                              high   = ls_select-high ) ).
    ENDCASE.

  ENDLOOP.

  lr_valid_date = VALUE #( ( sign   = 'I'
                             option = 'BT'
                             low    = '00010101'
                             high   = '99991231' ) ).

  SELECT
    kvewe,
    kappl,
    kschl
  FROM t685
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
  INTO TABLE @DATA(lt_t685).

* Delete unwanted KSCHL from the internal table.
  DELETE lt_t685 WHERE kschl <> 'ZRBW' AND
                       kschl <> 'ZRRW' AND
                       kschl <> 'ZTFS' AND
                       kschl <> 'ZTFM'.

* Select Data
  LOOP AT lt_t685 INTO DATA(ls_t685).

    CASE ls_t685-kschl.

      WHEN 'ZRBW'.
        SELECT * FROM a958
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a946
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a936
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a929
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a933
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a967
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a944
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a959
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a922
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a965
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a947
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a966
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a942
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a934
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a919
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a906
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.

      WHEN 'ZRRW'.

        SELECT * FROM a983
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a712
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
        SELECT * FROM a969
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a920
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a981
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a990
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
*        SELECT * FROM a707
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
        SELECT * FROM a992
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a995
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a906
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.

      WHEN 'ZTFM' OR 'ZTFS'.
        SELECT * FROM a900
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a933
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a971
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a919
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a897
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
        SELECT * FROM a943
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a936
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
*        SELECT * FROM a929
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
        SELECT * FROM a937
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a923
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a940
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
*        SELECT * FROM a938
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
*        SELECT * FROM a917
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
*        SELECT * FROM a928
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
*        SELECT * FROM a927
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
        SELECT * FROM a925
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a926
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
        SELECT * FROM a941
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
        SELECT * FROM a906
          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
          WHERE kappl = ls_t685-kappl
            AND kschl = ls_t685-kschl
            AND datab IN lr_valid_date
            AND datbi IN lr_valid_date.
*        SELECT * FROM a930
*          APPENDING CORRESPONDING FIELDS OF TABLE lt_cond
*          WHERE kappl = ls_t685-kappl
*            AND kschl = ls_t685-kschl
*            AND datab IN lr_valid_date
*            AND datbi IN lr_valid_date.
    ENDCASE.
  ENDLOOP.

  "Get Condition Record Header/Items
  IF lt_cond[] IS NOT INITIAL.
    SELECT
      konh~knumh,
      konp~kopos,
      konh~kotabnr,
      konh~kappl,
      konh~kschl,
      konp~kbetr,
      konp~konwa,
      konp~kmein,
      konp~loevm_ko
    FROM konh
      JOIN konp ON konh~knumh = konp~knumh
    INTO CORRESPONDING FIELDS OF TABLE @lt_rail_rate
      FOR ALL ENTRIES IN @lt_cond
    WHERE konh~knumh = @lt_cond-knumh.

  ENDIF.

  LOOP AT lt_rail_rate ASSIGNING FIELD-SYMBOL(<ls_rail_rate>).

    DATA(ls_cond) =
     VALUE #( lt_cond[ knumh = <ls_rail_rate>-knumh ] OPTIONAL ).

    "Transportation planning point
    <ls_rail_rate>-tplst = ls_cond-tplst.
    "Departure Point
    <ls_rail_rate>-knota = ls_cond-knota.
    "Destination point
    <ls_rail_rate>-knotz = ls_cond-knotz.
    "Route
    <ls_rail_rate>-route = ls_cond-route.
    "Number of forwarding agent
    <ls_rail_rate>-tdlnr = ls_cond-tdlnr.
    "Insurance type
    <ls_rail_rate>-vsart = ls_cond-vsart.
    "Insurance type
    <ls_rail_rate>-shtyp = ls_cond-shtyp.
    "Shipping Conditions
    <ls_rail_rate>-vsbed = ls_cond-vsbed.
    "STCC CODE
    <ls_rail_rate>-zstcc = ls_cond-zstcc.
    "Rail carrier region name
    <ls_rail_rate>-zzrail_region = ls_cond-zzrail_region.
    "Customer Number
    <ls_rail_rate>-kunnr = ls_cond-kunnr.
    "Ship-to-party
    <ls_rail_rate>-kunwe = ls_cond-kunwe.
    "Customer/Vendor City
    TRANSLATE ls_cond-cstvnd_city TO UPPER CASE.
    <ls_rail_rate>-cstvnd_city = ls_cond-cstvnd_city.
    "Destination region (federal state, county, province duchy)
    <ls_rail_rate>-regioz = ls_cond-regioz.
    "Destination zone.
    <ls_rail_rate>-lzonez = ls_cond-lzonez.
    "Tariff zone of point of departure.
    <ls_rail_rate>-trfzna = ls_cond-trfzna.
    "Tariff zone of point of destination.
    <ls_rail_rate>-trfznz = ls_cond-trfznz.
    "Country key.
    <ls_rail_rate>-land1z = ls_cond-land1z.
    "Valid From
    <ls_rail_rate>-datab = ls_cond-datab.
    "Valid to
    <ls_rail_rate>-datbi = ls_cond-datbi.

    IF <ls_rail_rate>-konwa = '%'. "percent
      <ls_rail_rate>-kbetr = <ls_rail_rate>-kbetr / 10.
    ENDIF.

  ENDLOOP.

  SORT lt_rail_rate BY kotabnr datab knumh.

*      e_t_data[] = corresponding #( lt_rail_rate ).
  et_adverse_rail_rate = CORRESPONDING #( lt_rail_rate ).

*    else.
* Stop after processing data.
*      raise no_more_data.
*    endif.
*  ENDIF.

ENDFUNCTION.

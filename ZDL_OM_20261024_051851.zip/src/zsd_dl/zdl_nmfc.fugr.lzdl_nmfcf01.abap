*----------------------------------------------------------------------*
***INCLUDE LZDL_NMFCF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_LTL_SHIPMENT_DATA
*&---------------------------------------------------------------------*
* Get NMFC Freight code and class details based on Shipment Number.
*----------------------------------------------------------------------*
FORM GET_LTL_SHIPMENT_DATA USING iv_tknum.
  DATA: ls_shipment LIKE gt_shipment,
        lv_count TYPE i.
* Get data from database tables VTTS and VTTP
  IF NOT iv_tknum is INITIAL.
    SELECT vtts~tknum                 "Shipment Number
           vtts~vsart                 "Shipping type for shipment stage
           vtts~abland1               "Country of departure
           vttp~vbeln                 "Delivery
      INTO TABLE gt_shipment
      FROM vtts
      INNER JOIN vttp
      ON vttp~tknum = vtts~tknum
      WHERE vtts~tknum = iv_tknum.
* If Shipment Number is not available, get the data from the tables
* VTTK, VTTS and VTTP.
  ELSE.
    LOOP at gt_vtts.
      LOOP at gt_vttp WHERE tknum = gt_vtts-tknum.
        gt_shipment-tknum = gt_vtts-tknum.
        gt_shipment-vsart = gt_vtts-vsart.
        gt_shipment-abland1 = gt_vtts-abland1.
        gt_shipment-vbeln = gt_vttp-vbeln.
        APPEND gt_shipment. CLEAR gt_shipment.
      ENDLOOP.
    ENDLOOP.
  ENDIF.
* Sort and Delete duplicates from Shipment Internal Table
  SORT gt_shipment BY tknum vbeln.
  DELETE ADJACENT DUPLICATES FROM gt_shipment COMPARING tknum vbeln.
* Get Material Number and Material freight group.
  IF NOT gt_shipment[] is INITIAL.
    SELECT vbeln matnr mfrgr INTO TABLE gt_delivery
         FROM lips FOR ALL ENTRIES IN gt_shipment
         WHERE vbeln = gt_shipment-vbeln.
  ENDIF.
*** We are assuming the Number of records in Master data tables TGAVF,
*** TGAF and TGAR are small and doing a SELECT ALL.
* Get Freight code set.
  IF NOT gt_shipment[] is INITIAL.
    SELECT * FROM tgavf INTO TABLE gt_frcode
        FOR ALL ENTRIES IN gt_shipment
        WHERE landa = gt_shipment-abland1
          AND vsart = gt_shipment-vsart.
  ENDIF.
* Get Freight code.
  SELECT * FROM tgaf INTO TABLE gt_frgroup.
* Get Freight class.
  IF NOT gt_frgroup[] is INITIAL.
    SELECT * FROM tgar INTO TABLE gt_frclass
       FOR ALL ENTRIES IN gt_frgroup
        WHERE garvz = gt_frgroup-garvz
          AND gtart = gt_frgroup-gtart.
  ENDIF.
* Update the Shipment Table
  LOOP at gt_shipment.
    LOOP at gt_delivery WHERE vbeln = gt_shipment-vbeln.
      gt_final-tknum = gt_shipment-tknum.
      gt_final-vbeln = gt_shipment-vbeln.
      gt_final-matnr = gt_delivery-matnr.  "Material Number
      gt_final-mfrgr = gt_delivery-mfrgr.  "Material freight group
*** Freight Code
      READ TABLE gt_frcode WITH KEY landa = gt_shipment-abland1
                                    vsart = gt_shipment-vsart.
      IF sy-subrc is INITIAL.
        gt_final-garvz = gt_frcode-garvz.
      ENDIF.
*** Freight Group
      READ TABLE gt_frgroup WITH KEY mfrgr = gt_final-mfrgr
                                     garvz = gt_final-garvz.
      IF sy-subrc is INITIAL.
        gt_final-gtart = gt_frgroup-gtart.
      ENDIF.
*** Freight Class
      READ TABLE gt_frclass WITH KEY garvz = gt_final-garvz
                                     gtart = gt_final-gtart.
      IF sy-subrc is INITIAL.
        gt_final-gtkls = gt_frclass-gtkls.
      ENDIF.
      APPEND gt_final. CLEAR gt_final.
    ENDLOOP.
  ENDLOOP.

ENDFORM.                    " GET_LTL_SHIPMENT_DATA

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE lzdl_e3637top.                     " Global Data
  INCLUDE lzdl_e3637uxx.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E3637F...                     " Subprograms
* INCLUDE LZDL_E3637O...                     " PBO-Modules
* INCLUDE LZDL_E3637I...                     " PAI-Modules

  INCLUDE lzdl_e3637f01.

  INCLUDE LZDL_E3637PIK.    "pick & pack subroutines

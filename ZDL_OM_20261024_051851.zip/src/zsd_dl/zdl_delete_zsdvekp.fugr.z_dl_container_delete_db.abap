FUNCTION Z_DL_CONTAINER_DELETE_DB .
*"----------------------------------------------------------------------
*"*"Update function module:
*"
*"*"Local interface:
*"  TABLES
*"      IT_ZDLU01267_VEKP STRUCTURE  ZDLU01267_VEKP
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2007 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: U01267 Save Container Handling Unit table
*                                                                      *
* FM Name     : Z_SD_CONTAINER_SAVE_DB           Create Date: 05/02/07 *
*                                                                      *
* Programmer  : Lance Vialpando                                        *
*______________________________________________________________________*
* Description : This FM deletes the container handling unit records
*               from table ZSDU01267_VEKP.
*
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ================  ========  ==========  =============================*
* Lance Vialpando   05/02/07  EDEK907877  Initial
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :

*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*   none
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   : On demand                                        *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            PB = Push Button      *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            TS = Type Struct.     *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*

  CHECK it_zdlu01267_vekp[] IS NOT INITIAL.
  DELETE zdlu01267_vekp FROM TABLE it_zdlu01267_vekp.

ENDFUNCTION.

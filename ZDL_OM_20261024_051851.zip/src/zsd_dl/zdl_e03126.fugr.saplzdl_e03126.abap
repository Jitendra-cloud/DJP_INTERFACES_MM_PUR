*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E03126TOP.                    " Global Data
  INCLUDE LZDL_E03126UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E03126F...                    " Subprograms
* INCLUDE LZDL_E03126O...                    " PBO-Modules
* INCLUDE LZDL_E03126I...                    " PAI-Modules

INCLUDE LZDL_E03126F01.

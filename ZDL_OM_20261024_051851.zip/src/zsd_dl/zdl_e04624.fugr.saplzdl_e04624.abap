*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E04624TOP.                    " Global Data
  INCLUDE LZDL_E04624UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E04624F...                    " Subprograms
* INCLUDE LZDL_E04624O...                    " PBO-Modules
* INCLUDE LZDL_E04624I...                    " PAI-Modules

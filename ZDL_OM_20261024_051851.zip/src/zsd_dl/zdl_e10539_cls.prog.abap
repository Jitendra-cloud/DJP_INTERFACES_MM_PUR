*&---------------------------------------------------------------------*
*&  Include           ZSDE10539_CLS
*&---------------------------------------------------------------------*

* event receiver for grid events
class lcl_event_receiver definition.
  public section.
    methods:
     double_click  for event double_click         of cl_gui_alv_grid
                   importing e_row e_column sender,
     top_of_page   for event print_top_of_page    of cl_gui_alv_grid,
     toolbar       for event toolbar              of cl_gui_alv_grid
                   importing sender e_object,
     user_command  for event user_command         of cl_gui_alv_grid
                   importing sender e_ucomm,
     data_changed_finished for event data_changed_finished
                                                  of cl_gui_alv_grid
                   importing e_modified.
endclass.                    "lcl_event_receiver DEFINITION

** implementation of grid control methods
class lcl_event_receiver implementation.
* top_of_page
  method top_of_page.
    perform top_of_page.
  endmethod.                    "top_of_page

* double_click
  method double_click.
    case sender.
      when gr_li.
        perform user_command_li using e_row e_column.
    endcase.
  endmethod.                    "double_click

* toolbar
  method toolbar.
    case sender.
      when gr_ba.
        perform set_toolbar_ba using e_object.
      when gr_li.
        perform set_toolbar_li using e_object.
    endcase.
  endmethod.                    "toolbar


* user_command
  method user_command.
    case sender.
      when gr_ba.
        perform user_command_toolbar_ba using e_ucomm.
      when gr_li.
        perform user_command_toolbar_li using e_ucomm.
    endcase.
  endmethod.                    "user_command

  method data_changed_finished.
    perform data_changed_finished_ba using e_modified.
  endmethod.

endclass.                    "lcl_event_receiver IMPLEMENTATION

data: g_rec    type ref to lcl_event_receiver.

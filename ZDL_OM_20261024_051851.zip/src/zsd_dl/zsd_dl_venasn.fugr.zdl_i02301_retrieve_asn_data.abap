FUNCTION zdl_i02301_retrieve_asn_data.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  EXPORTING
*"     REFERENCE(EV_TRADES_ASN1) TYPE  BOOLEAN
*"     REFERENCE(EV_TRADES_ASN2) TYPE  BOOLEAN
*"     REFERENCE(ET_ZDL_TRADES) TYPE  ZDL_TRADES_TT
*"----------------------------------------------------------------------

* Set variables to tell whether it's a Trades ASN1 or Trades ASN2
  ev_trades_asn1 = gv_trades_asn1.
  ev_trades_asn2 = gv_trades_asn2.

* Set return ZDL_TRADES data to the global data in the Inbound ASN
* Idoc function module Z_SD_DL_I2301_INPUT_ZVASN
  et_zdl_trades = gt_trades.

ENDFUNCTION.

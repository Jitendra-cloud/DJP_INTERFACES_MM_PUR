************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**            COPYRIGHT (C) 2004 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**             REVISIONS COPYRIGHT (C) 2005, 20yy, 20zz               **
**                    by INTERNATIONAL PAPER                          **
*______________________________________________________________________*
* Program Name: I02143                           Create Date: 08/10/04 *
* SAP Name    : Z_CHECK_REQ_FIELDS               Version    : 1.0      *
* Programmer  : Randall Wainwright               Last Update: 09/15/04 *
*______________________________________________________________________*
* Description : This function module accepts the control record and    *
*   corresponding data records of any generic IDoc, then queries       *
*   custom table ZREQ_FIELDS for a list of required fields specific to *
*   the RICE ID of the calling program, generating application log     *
*   entries and an AHD ticket if such logging is necessary.            *
*______________________________________________________________________*
* Change History:                                                      *
*  DEVELOPER NOTE: This function module/Top Include is and should      *
*   always be exactly identical to the corresponding copy in R/3       *
*   Enterprise or APO, as the case may be.                             *
*______________________________________________________________________*
*     Programmer        Date               Action                      *
* ==================  ========  =======================================*
* Maureen Carter      10/03/05  fix error msg after function call      *
*                                                                      *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Includes          : ZCA_APLOG_LOG_STANDARD - App Log Standards       *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: Z_INTERFACE_GEN_AHD_TICKET                       *
************************************************************************

FUNCTION-POOL zsd_dl_req_fields MESSAGE-ID zsd_dl.

*&---------------------------------------------------------------------*
*&  GLOBAL VARIABLES
*&---------------------------------------------------------------------*
DATA: g_inventory_code TYPE zzinv,
      g_idoc_number    TYPE edi_docnum,
      g_message_type   LIKE edidc-mestyp,
      g_receiver_num   LIKE edidc-rcvprn,
      g_sender_num     LIKE edidc-sndprn.

DATA: g_line TYPE i,
      gt_return LIKE zret_text OCCURS 0 WITH HEADER LINE ,
      g_dummy         TYPE string,                          " <<< SC02
      l_log_open      TYPE c ,                              " <<< SC02
      g_app_log_ext_id TYPE balnrext,                       " <<< SC02
      g_app_log_nbr    TYPE balognr,                        " <<< SC02
      l_lognum        TYPE bal_t_lgnm,                      " <<< SC02
      wa_lognum       LIKE LINE OF l_lognum,                " <<< SC02
      l_log           TYPE bal_s_log.                       " <<< SC02

* <<<SR01 - Start
* Change mail_addr of ZZMAILTAB as first field so that
* we can apply control level operations
DATA:
  BEGIN OF i_mailtab OCCURS 0,
    mail_addr LIKE zzmailtab-mail_addr,
    mailkey   LIKE zzmailtab-mailkey,
    counter   LIKE zzmailtab-counter,
    mail_type LIKE zzmailtab-mail_type,
  END OF i_mailtab.
* <<<SR01 - End

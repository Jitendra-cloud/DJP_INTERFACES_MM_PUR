FUNCTION zsd_sales_cif_mts_zunit_wgt.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(I_VBAP) TYPE  VBAP
*"  TABLES
*"      C_ATPFIELD STRUCTURE  ATPFIELD
*"----------------------------------------------------------------------

************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**            COPYRIGHT (C) 2006 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2006                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Include Name: ZSD_MOD_SALES_CIF                     Date: 03/27/2006 *
* Programmer  : Showry Kocherla                                        *
*______________________________________________________________________*
* Description :                                                        *
*  Function to add a row with VBAP-ZZ_UNIT_WGT to the table C_ATPFIELD *
*  which will be passed to APO.  CR-04275                                      *
*______________________________________________________________________*
* Change History:                                                      *
*  XXXXXXX     XX/XX/XX                                                *
*______________________________________________________________________*
************************************************************************
* External Calls                                                       *
*   Include    ZSD_MOD_SALES_CIF
*______________________________________________________________________*

  CONSTANTS: lc_kfdna_zunitwgt LIKE c_atpfield-kfdna VALUE 'ZUNITWGT'.
  DATA: lv_matkl TYPE matkl,
        lv_werks TYPE werks_d.

  IF NOT i_vbap-zz_wgt_roll IS INITIAL.
    CLEAR: lv_matkl, lv_werks.
    SELECT SINGLE matkl INTO lv_matkl FROM mara
           WHERE matnr = i_vbap-matnr.
    IF sy-subrc = 0.
      SELECT SINGLE werks INTO lv_werks
             FROM zdl_mts_density
             WHERE werks = i_vbap-werks
             AND   matkl = lv_matkl.
      IF sy-subrc = 0.
        c_atpfield-delnr = i_vbap-vbeln.
        c_atpfield-delps = i_vbap-posnr.
        c_atpfield-kfdna = lc_kfdna_zunitwgt.
        c_atpfield-value = i_vbap-zz_wgt_roll.
        APPEND c_atpfield.
      ENDIF.
    ENDIF.
  ENDIF.
ENDFUNCTION.

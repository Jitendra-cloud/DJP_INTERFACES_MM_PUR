*"**********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005, 20nn                                 **
**                   by INTERNATIONAL PAPER                           **
*______________________________________________________________________*
* Include Name: ZDL_E3074_BATCH_STATUS_CONSIG        Date: 05/09/2005  *
* Programmer  : Sushila Chaudhary / Maureen Carter                     *
*______________________________________________________________________*
* Description : This include is called whenever a export consignment   *
* order related delivery is pgi'd. The movement type 631 will be used  *
* for export consignment orders only. This logic should be executed    *
* only at the time of pgi and not otherwise.                           *
* Note: the BADI is also called when the shipment cost document        *
* is created                                                           *
*______________________________________________________________________*
* Change History:                                                      *
*
* 06/28/05  This code was not used because changing the batch status
* creates a material movement document.  The material movement document
* caused a problem with the posting of the shipment status idoc.  It
* caused the BDC session to unexpectedly exit before processing was
* complete.  I did not delete everything because we may need to use this
* in the future.  (Maureen)                                            *
************************************************************************
*
*types:  begin of t_batch_data ,
*          matnr type  mchb-matnr,
*          werks type mchb-werks,
*          charg type  mchb-charg,
*        end of t_batch_data,
*        l_return type bapiret2.
*
*data  ws_return type bapiret2.
*
*constants : c_export_consignment_mvt type mseg-bwart value '631',
*            c_complete  type c value 'C',
*            c_shipment_complete type sttrg value 5,
*            c_shipment_start type sttrg value 6,
*            c_restricted_status type c value 'X',
*            c_update_field type c value 'X',
*            c_status type bapibatchstatus value 'X'.
*.
*
*data : lt_vtrlk type standard table of vtrlk initial size 0,
*       t_vtrlk type vtrlk,
*       lt_vtrlp type standard table of vtrlp initial size 0,
*       t_vtrlp type vtrlp,
*       lt_vttk type standard table of vttk initial size 0,
*       t_vttk type vttk,
*       l_batch_data type t_batch_data,
*       lt_batch_data type standard table of t_batch_data initial size 0,
*       lt_return type standard table of l_return initial size 0,
*       l_text2(50), l_text3(50), l_text4(50), l_text5(50).
*
*data:
*  batchattributes type bapibatchatt,
*  batchattributesx type bapibatchattx,
*  batchstatus type bapibatchstatus,
*  batchstatusx type bapibatchstatusx.
*
*data: w_mcha_i                   type mcha.
*data: w_mcha_e                   type mcha.
*data: w_updmcha                  type updmcha.
*data: f_subrc                    type subrc.
*
*break macarte.
*
*************************************************************************
** check that 'shipment complete' / 'shipment start' status is being set
*************************************************************************
*lt_vttk[] = im_shipments_before_update-new_vttk[].
*loop at lt_vttk into t_vttk
*          where sttrg =  c_shipment_complete
*          or sttrg = c_shipment_start.   "Overall transportation status
*  exit.
*endloop.
*
*if sy-subrc = 0.
*  lt_vtrlk[] = im_shipments_before_update-new_vtrlk[].
*  lt_vtrlp[] = im_shipments_before_update-new_vtrlp[].
*
*************************************************************************
** Check if the movement type is complete. If yes then do nothing .
*************************************************************************
*  loop at lt_vtrlk into t_vtrlk.
*    if t_vtrlk-wbstk_tr = c_complete. "Total goods movement status
*      exit .
*    endif.
*  endloop.
*
*************************************************************************
** Check if the movement type is for export consignment orders only, i.e
** movement type = 631. If yes then create a list of batches being moved
** to consignment stock and change the batch status to restricted.
*************************************************************************
** t_vtrlk-gbstk_tr = Overall processing status of document
** This eliminates processing when shipment cost document is created
**  if t_vtrlk-gbstk_tr <> c_complete.
*  if t_vtrlk-gbstk_tr = c_complete.  "process at shipment cost create
*    loop at lt_vtrlp into t_vtrlp
*      where bwart = c_export_consignment_mvt
*        and charg <> space .
*      l_batch_data-matnr = t_vtrlp-matnr.
*      l_batch_data-charg = t_vtrlp-charg.
*      l_batch_data-werks = t_vtrlp-werks.
*      append l_batch_data to lt_batch_data.
*    endloop.
*
*    if not lt_batch_data[] is initial.
*      call function 'Z_DL_BATCH_STATUS_CHANGE'
*        exporting
*          status = c_status
*        tables
*          batch  = lt_batch_data
*          return = lt_return.
*      endif.
*    endif.
*
*  endif.
*
*endif.

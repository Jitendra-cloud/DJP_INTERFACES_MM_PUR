*---------------------------------------------------------------------*
*    generated viewmaintenance function pool top
*---------------------------------------------------------------------*
FUNCTION-POOL Z_ZDL_UNI_EQI_TM           MESSAGE-ID SV.

  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZ_ZDL_UNI_EQI_TMT00                    . "view rel. data dcl.

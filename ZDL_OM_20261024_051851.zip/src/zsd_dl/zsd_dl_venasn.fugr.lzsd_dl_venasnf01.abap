*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_VENASNF01 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  process_idoc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
form process_idoc .
  data: lv_24count type i,
        lv_37count type i,
        lv_37tabix type i,                                  "CR-8050
        lv_43tabix type sytabix,                           "BCB10
        lv_docnum  type edi_docnum.


  constants:                                                "EDVK946089
*   Denotes a Trades ASN2 which is against PO2              "EDVK946089
    lc_tr2      type edi_mescod  value 'TR2'.               "EDVK946089

*  Clear all global variables.
  clear:  gt_mbhp_tab,   gt_mbhp_tab[],
          gt_mbh,        gt_mbh[],
          gt_temp_mat,   gt_temp_mat[],
          gt_bat_char,   gt_bat_char[],
          gt_mbpsv_chars, gt_mbpsv_chars[],
          gv_tabix,
          gt_ekko,                                          "BCB09
          gt_hu_xref.                                       "CR-8050

  data:lv_weight type lfimg,                                "CMS30040
       lv_dldate type lfdat,                                "CMS30040
       lv_truck  type days,                                 "CMS30040
       lv_rail   type days,                                 "CMS30040
       lv_lfimg  type char15,                               "CMS30040
       lv_lfimg1 type lfimg.                                "CMS30040

*----------------------------------------------------------------------*
*  Logic Changed - New Logic - 11/10/2005                              *
*                                                                      *
*  In the first loop, fetch                                            *
*    1.  E1EDL20 - to validate BOL is not empty and is not already     *
*                  in SAP - changed on 02/03/06                        *
*    2.  E1EDL24 - for AFPA (in the MATNR field) grid code - non-empty *
*                  check and to fetch corresponding SAP material #.    *
*    3.  E1EDL43 - for PO line item - non-empty check and check whether*
*                  this PO does exist in SAP - facilitate to locate    *
*                  exact SAP material number.                          *
*    4.  E1EDL15 - to keep track batch characteristics                 *
*----------------------------------------------------------------------*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ================== ========   ======  ===============================*
* Mallik Aiely       3/14/2016  CMS30040 Del.Date update based on Mode *
*                                        of transport:Trades ASN to R/3*
*
* apunjaa            02/10/2017 CMS31541 Multiple changes to accomodate*
*                               Pensacola processing                   *
* PWADEHR            08/29/2019 CD2000003751 Check for Third Party POs *
*                                           to update VRKME field value*
*----------------------------------------------------------------------*


  clear  lv_24count.

  clear:lv_lfimg,lv_lfimg1,lv_dldate.                       "CMS30040
  perform get_zdl_fields changing lv_weight                 "CMS30040
                                  lv_truck
                                  lv_rail.

* Begin BCB10 insert
* If a blank Material is passed in then substitute material
* DUMMYXXX as the default Material
  loop at gt_idoc_data
        into gs_idoc_data
        where   docnum  =  gs_idoc_ctrl-docnum
          and   segnam  =  gc_e1edl24.
    gv_tabix      =  sy-tabix.

    gs_e1edl24    = gs_idoc_data-sdata.
    if gs_e1edl24-matnr is initial.
      gs_e1edl24-matnr = 'DUMMYXXX'.
      gs_idoc_data-sdata = gs_e1edl24.
      modify gt_idoc_data from gs_idoc_data
                index gv_tabix
                transporting sdata.
    endif.

*->Begin of CMS30040
    if gs_e1edl24-lfimg is not initial.
      lv_lfimg = lv_lfimg + gs_e1edl24-lfimg.
    endif.
*-<End of CMS30040

  endloop.
* End BCB10 insert

*->Begin of CMS30040
  lv_lfimg1 = lv_lfimg.

  loop at gt_idoc_data into gs_idoc_data
          where docnum  =  gs_idoc_ctrl-docnum
            and segnam  =  gc_e1edt13.

    gv_tabix      =  sy-tabix.
    gs_e1edt13    = gs_idoc_data-sdata.

    if gs_e1edt13-ntanf is not initial and
       lv_weight is not initial.

      lv_dldate = gs_e1edt13-ntanf.

      if lv_lfimg1 lt lv_weight and lv_truck is not initial.
        lv_dldate = lv_dldate + lv_truck.
        gs_e1edt13-ntanf = lv_dldate.
        gs_idoc_data-sdata = gs_e1edt13.
        modify gt_idoc_data from gs_idoc_data index gv_tabix
                                          transporting sdata.
      elseif lv_lfimg1 ge lv_weight and lv_rail is not initial.
        lv_dldate = lv_dldate + lv_rail.
        gs_e1edt13-ntanf = lv_dldate.
        gs_idoc_data-sdata = gs_e1edt13.
        modify gt_idoc_data from gs_idoc_data index gv_tabix
                                          transporting sdata.
      endif.

    endif.

  endloop.
*-<End of CMS30040


***Begin of changes pragup1 06/15/2012 CHG136783
  clear gv_chk_multiple_usd.
  select single docnum
         from edids
         into lv_docnum
         where docnum = gs_idoc_ctrl-docnum
         and status = c_idoc_status_error.

  if lv_docnum is not initial.
    gv_chk_multiple_usd = 'X'.
  endif.
***End of changes pragup1 06/15/2012 CHG136783


*--> Begin insert EDVK946089
* Determine if this is a Trades ASN1 or Trades ASN2 idoc.
*
* If this is Trades ASN1 (ASN against PO2) then PO2 information is
* contained on the idoc.  We need to:
*   1. Convert specific idoc data from PO2 to PO1 data
*   2. Generate Trades Inbound Delivery 1 against PO1

* For Paperpro, we have the Material and PO information.
* So we can by-pass the following logic for message code PPR
  if gv_parnr_ppr ne gc_ppr.                                "CR-8050
    if gs_idoc_ctrl-mescod ne lc_tr2.
      perform convert_data_to_po1 changing gv_trades_asn1.

    else.
*   If the Message Code = 'TR2' then we know this is Trades ASN2 being
*   processed.  This ASN2 is triggered from the Trades Goods Receipt
*   process. The information on the idoc is relevant to PO1 so we must:
*     1. Convert specific idoc data from PO1 to PO2 data
*     2. Generate Trades Inbound Delivery 2 against PO2
      gv_trades_asn2 = gc_true.

*   Convert idoc data from PO1 to PO2 information
      perform convert_data_to_po2.

    endif.
  endif.                                                    "CR-8050

  check gv_idoc_error = gc_false.
*--> End  insert EDVK946089

*--> Begin insert EDVK946089
* For the Trades ASN2 (which is against PO2), there is no need to
* derive SAP material numbers, create new batches and HU's. Skip this
* logic because all of the information will be provided. Trades ASN2 is
* triggered from the Trades GR process. The GR DELVRY03 idoc will
* already have this information. We want the Trades inbound delivery 2
* to have the same batches and HU's as Trades inbound delivery 1.
  if gv_trades_asn2 = gc_false.
*--> End  insert EDVK946089

    loop at gt_idoc_data
          into gs_idoc_data
          where   docnum  =  gs_idoc_ctrl-docnum
            and ( segnam  =  gc_e1edl20 or
                  segnam  =  gc_e1edl24 or
                  segnam  =  gc_e1edl43 or
                  segnam  =  gc_e1edl15 ).
      gv_tabix      =  sy-tabix.
      lv_43tabix    =  sy-tabix.                            "BCB10

      case gs_idoc_data-segnam.

        when gc_e1edl20.
          clear:  gs_e1edl20.
          gs_e1edl20    = gs_idoc_data-sdata.

*Validate the Shipping Condition(vsbed)- to table TVSB.
*If Idoc-vsbed is valid then append or else clear the value
          if gs_e1edl20-vsbed is not initial.

            data : lv_vsbed type vsbed.

            select single vsbed into lv_vsbed from tvsb
               where vsbed = gs_e1edl20-vsbed. "Value From IDOC
            if sy-subrc eq 0.
           export gs_e1edl20 = gs_e1edl20 to memory id 'ZDL_VASN_VSBED'.
              clear lv_vsbed.
            endif.
          endif.

*         Check whether BOL is in IDoc.
          if not gs_e1edl20-bolnr is initial.
*           Map this BOLNR into External Identification of Delviery Note
*           LIFEX field
            gs_e1edl20-lifex   = gs_e1edl20-bolnr.
            gs_idoc_data-sdata = gs_e1edl20.
            modify gt_idoc_data from gs_idoc_data
                      index gv_tabix
                      transporting sdata.
          endif.
        when gc_e1edl24.
          clear:  gs_e1edl24.
          lv_24count = lv_24count + 1.

          if lv_24count > 1.
            append gt_mbhp_tab.
            clear  gt_mbhp_tab.

            gt_bat_char-chars[] = gt_mbpsv_chars[].
            append gt_bat_char.
            clear  gt_bat_char.

            refresh gt_mbpsv_chars.

            append gt_temp_mat.
            clear  gt_temp_mat.
          endif.
*         Fetch all material & batch numbers
*         For Vendor ASN, this e1edl24.matnr contains AFPA grid code
*         Fetch corresponding material.
          gs_e1edl24    = gs_idoc_data-sdata.

          if not gs_e1edl24-matnr is initial.
            "Onlyif AFPA code is passed

            gt_mbhp_tab-matnr     = gs_e1edl24-matnr.
            gt_mbhp_tab-ebelp     = gs_e1edl24-posnr.       "CR-8050
*           Update Batch characteristics table also
            gt_bat_char-matnr    = gs_e1edl24-matnr.
          else.    "If matnr is empty
            perform sub_idoc_status_fill using
            c_idoc_status_error                             "status 51
                gs_idoc_ctrl-docnum     "idoc number
                c_error                 "status msg type
                'ZSD_DL'                "message class
                '000'                   "err msg
                text-106                                    "msgv1
                lv_24count                                  "msgv2
                text-108                                    "msgv3
                ' '                                         "msgv4
                'PROCESS_IDOC'          "routid
                gc_e1edl24              "seg num
                ' '.                    "seg field
            continue.
          endif.

* CMS31175|ChangedBy:AMAOLE1|ChangedOn:11042016|START1
          data lv_flag1 type char1.
          perform update_weight_e1edl24 changing gs_e1edl24 lv_flag1.

          if lv_flag1 = 'Y'.
            gs_idoc_data-sdata   = gs_e1edl24.

            modify gt_idoc_data from gs_idoc_data index gv_tabix
                   transporting sdata.
          endif.
* CMS31175|ChangedBy:AMAOLE1|ChangedOn:11042016|END1

          gt_mbhp_tab-24tabix   = gv_tabix.

          clear gv_tabix.

        when gc_e1edl43.
          clear  gs_e1edl43.
*         Fetch all PO numbers. - this is required only for Vendor ASN
*         i.e., to fetch material number from AFPA grid code
          gs_e1edl43        = gs_idoc_data-sdata.

          if gs_e1edl43-qualf      = 'V'.    "SD document category
            clear: gv_ebeln.
            if not gs_e1edl43-belnr is initial. "PO det. empty in IDOC
              if gv_parnr_ppr = gc_ppr.
                condense gs_e1edl43-belnr no-gaps.          "CR-8050
              endif.
*             Convert idoc PO number to numeric format
              call function 'CONVERSION_EXIT_ALPHA_INPUT'
                exporting
                  input  = gs_e1edl43-belnr(10)
                importing
                  output = gv_ebeln.

              gt_mbhp_tab-ebeln    = gv_ebeln.
              gt_mbhp_tab-43tabix  = gv_tabix.

*             Used to check for existence of PO line item in SAP
              gt_temp_mat-ebeln    = gv_ebeln.
              gt_temp_mat-43tabix  = lv_43tabix.            "BCB10

*             Update gt_idoc_data with this PO number.
              gs_e1edl43-belnr     = gv_ebeln.
              gs_idoc_data-sdata   = gs_e1edl43.
              modify gt_idoc_data from gs_idoc_data
                        index gv_tabix
                        transporting sdata.
            else.
*             Update Error - PO details are empty in IDoc for AFPA Grid
*             Code:
              perform sub_idoc_status_fill using
              c_idoc_status_error                           "status 51
                  gs_idoc_ctrl-docnum     "idoc number
                  c_error                 "status msg type
                  'ZSD_DL'                "message class
                  '000'                   "err msg
                  text-108                                  "msgv1
                  gt_mbhp_tab-matnr                         "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  'PROCESS_IDOC'          "routid
                  gc_e1edl43              "seg num
                  ' '.                    "seg field
              continue.
            endif.
            clear gv_tabix.
          endif.

        when gc_e1edl15.
          clear  gs_e1edl15.
*         Fetch Batch characteristics value
          gs_e1edl15                = gs_idoc_data-sdata.
          gt_mbpsv_chars-atnam      = gs_e1edl15-atbez.
          gt_mbpsv_chars-atwrt      = gs_e1edl15-atwrt.
*          if gt_mbpsv_chars-atnam =  zsdc_PACKAGE_NUMBER.
*            READ TABLE gt_batches_per_package
*                 with key charg =
*          endif.
*         Delete leading speces
          condense gt_mbpsv_chars-atwrt no-gaps.
          append gt_mbpsv_chars.
          clear  gt_mbpsv_chars.
      endcase.

    endloop.

*   Begin BCB10 insert
*   If no E1EDL24 segments exist then generate an error and trigger
*   workflow
    if lv_24count < 1.
      gv_trigger_wf = gc_true.
*     TRD ASN: Vendor ASN missing lines
      perform sub_idoc_status_fill using
      c_idoc_status_error                                   "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '602'                   "err msg
          ' '                                               "msgv1
          ' '                                               "msgv2
          ' '                                               "msgv3
          ' '                                               "msgv4
          'PROCESS_IDOC'          "routid
          ' '                     "seg num
          ' '.                    "seg field
      return.
    endif.
*   End BCB10 insert

*   Append the last record in the internal table
    check gv_idoc_error = gc_false.    "BOL is not empty.

    append gt_mbhp_tab.
    clear  gt_mbhp_tab.

    gt_bat_char-chars[] = gt_mbpsv_chars[].
    append gt_bat_char.
    clear  gt_bat_char.

    refresh gt_mbpsv_chars.

    append gt_temp_mat.
    clear  gt_temp_mat.

    if not gt_mbhp_tab[] is initial.
*     Check AFPA is not initial in IDoc
      read table gt_mbhp_tab with key matnr = ' '.

      if sy-subrc = 0.    "Any one of the AFPA code is missing
        gv_idoc_error = gc_true.
      else.
        gv_idoc_error = gc_false.
      endif.

      check gv_idoc_error = gc_false.    "AFPA code is not empty.

*     Begin BCB10 delete
*     Check PO is not initial in IDOC
*      READ TABLE gt_mbhp_tab WITH KEY ebeln = ' '.
*      IF sy-subrc = 0.    "Any one of the AFPA code is missing
*        gv_idoc_error = gc_true.
*      ELSE.
*        gv_idoc_error = gc_false.
*      ENDIF.
*     End BCB10 delete

*     Begin BCB10 insert
*     Check PO is not initial in IDOC
      read table gt_mbhp_tab with key ebeln = ' '.
      if sy-subrc = 0.    "Any one of the AFPA code is missing
        gv_segnum = gt_mbhp_tab-24tabix.
        if gv_trades_asn1 = gc_false or  "not Trades ASN1
          ( gv_trades_asn1 = gc_true and " is Trades ASN1 but it's a
            gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN

*         PO segment E1EDL43 does not exist for delivery item segment
*         E1EDL24
          perform sub_idoc_status_fill using
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZSD_DL'                "message class
              '000'                   "err msg
              text-120                                      "msgv1
              ' '                                           "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              'PROCESS_IDOC'                                   "routid
              gv_segnum                                     "seg num
              ' '.                                       "seg field
        else.
          gv_trigger_wf = gc_true.
*         TRD ASN: PO missing on IDOC
          perform sub_idoc_status_fill using
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZSD_DL'                "message class
              '604'                   "err msg
              ' '                                           "msgv1
              ' '                                           "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              'PROCESS_IDOC'                                   "routid
              gv_segnum                                     "seg num
              ' '.                                       "seg field
        endif.
        return.  "leave subroutine
      endif. "Check PO is blank or not
*     End BCB10 insert
    endif. "If gt_mbhp_tab is not blank

    check gv_idoc_error = gc_false.    "Material & PO is not empty.

*   Check PO existence in SAP
    perform sub_po_existence.

    check gv_idoc_error = gc_false.    "PO exist.
    clear lv_24count.                                       "CR-8050
*   Second loop - update HU details
    loop at gt_idoc_data
        into gs_idoc_data
        where   docnum  =  gs_idoc_ctrl-docnum
          and ( segnam  =  gc_e1edl37 or
                segnam  =  gc_e1edl44 ).

      gv_tabix      =  sy-tabix.

      case gs_idoc_data-segnam.

        when gc_e1edl37.

*         Begin CR-8050
*         We are now dealing with the potential for Bundled Rolls.
*         Whether we have Break Bulk or Bundled Rolls, all of our
*         work tables must be at the Batch level or, for non-Batch
*         scenario, the HU level. E1EDL37 can no longer be used as a
*         "driver" since we can have multiple E1EDL44's for one E1EDL37.
*          CLEAR  gs_e1edl37.
*          lv_37count  = lv_37count + 1.
**         Fetch all handling unit numbers
*          READ TABLE gt_mbhp_tab INDEX lv_37count.
*          READ TABLE gt_bat_char INDEX lv_37count.
*
*          gs_e1edl37          = gs_idoc_data-sdata.
*          gt_mbhp_tab-charg   = gs_e1edl37-exidv.
*          gt_mbhp_tab-exidv   = gs_e1edl37-exidv.
*          gt_mbhp_tab-37tabix = gv_tabix.
*
*          gt_bat_char-vendrbatch = gs_e1edl37-exidv.
*          lv_37tabix =  gv_tabix.
*          CLEAR  gv_tabix.

          gs_e1edl37            = gs_idoc_data-sdata.
          gs_hu_xref-orig_exidv = gs_e1edl37-exidv. "Original HU
          lv_37tabix            =  gv_tabix.        "store E1EDL37 index
*         End CR-8050

        when gc_e1edl44.

*         Begin CR-8050
*          CLEAR  gs_e1edl44.
*          gs_e1edl44           = gs_idoc_data-sdata.
*          gt_mbhp_tab-44tabix  = gv_tabix.
*
*          MODIFY gt_mbhp_tab
*                    INDEX lv_37count
*                    TRANSPORTING charg
*                                 exidv  37tabix
*                                 44tabix.
*
*          MODIFY gt_bat_char
*                    INDEX lv_37count
*                    TRANSPORTING vendrbatch.
*
*          CLEAR  gv_tabix.


*         There is 1 L44 segment per L24 segment
          lv_24count  = lv_24count + 1.

*         Fetch all handling unit numbers
          read table gt_mbhp_tab index lv_24count.
          read table gt_bat_char index lv_24count.

          clear  gs_e1edl44.
          gs_e1edl44           = gs_idoc_data-sdata.
          gt_mbhp_tab-44tabix  = gv_tabix.

*         Current format of idoc as of R12:
*           Non Paper Pro Vendors will ONLY send idocs in Break Bulk
*                      The L37-EXIDV and L44-EXIDV fields will contain
*                      the Vendor Batch for Batch Managed materials or
*                      the HU for Non-Batch Managed materials as it is
*                      the only field large enough, between EXIDV and
*                      CHARG, to hold up to a 15-byte Vendor Batch
*                      Number (EXIDV = 20 bytes; CHARG = 10 bytes).
*                      Break Bulk may or may not be Batch Managed.
*                      Regardless, the HU will be the SAME as the
*                      Vendor Batch and reside in L37-EXIDV & L44-EXIDV
*           Paper Pro may send in Break Bulk OR Bundled Roll idocs:
*                      Vendor Batch will be in both E1EDL24-CHARG &
*                      E1EDL44-CHARG for whether they send Bundled Rolls
*                      or not. Paper Pro's Vendor Batches will never be
*                      greater than 10 bytes, allegedly, so they will
*                      "fit" in the 10-byte CHARG field.
*                      The HU will be sent in both E1EDL37-EXIDV &
*                      E1EDL44-EXIDV
*
*         For all 3 scenarios: 1) Bundled Roll, 2) Break Bulk 3) Non
*         Batch, we want to populate from the L44 segment as it is
*         consistent with all 3
          gt_mbhp_tab-exidv   = gs_e1edl44-exidv.  "HU
*         Begin CR-8050-FIX2
*         Vendor Batch will be in both E1EDL24-CHARG & E1EDL44-CHARG for
*         the EDI version for PaperPro whether they send Bundled Rolls
*         or not. Paper Pro's Vendor Batches will never be > 10 bytes,
*         allegedly, so they will "fit" in the 10-byte CHARG field.
*         Vendor Batches from all other Vendors will be sent in fields
*         E1EDL37-EXIDV * E1EDL44-EXIDV. (NOTE: non Paper Pro Vendors
*         for R12 will only be sending in Break Bulk so EXIDV is fine
*         for now but will have to change down the line!)
*          gt_mbhp_tab-charg   = gs_e1edl44-charg.  "VB  "delete this
          if gv_parnr_ppr = gc_ppr.
            gt_mbhp_tab-charg = gs_e1edl44-charg.
          else.
            gt_mbhp_tab-charg = gs_e1edl44-exidv.
          endif.
*         End CR-8050-FIX2
          gt_mbhp_tab-37tabix = lv_37tabix.  "store L37 tabix


*         Vendor Batch will be in both E1EDL24-CHARG & E1EDL44-CHARG for
*         the EDI version for PaperPro whether they send Bundled Rolls
*         or not. Paper Pro's Vendor Batches will never be > 10 bytes,
*         allegedly, so they will "fit" in the 10-byte CHARG field.
*         Vendor Batches from all other Vendors will be sent in fields
*         E1EDL37-EXIDV * E1EDL44-EXIDV. (NOTE: non Paper Pro Vendors
*         for R12 will only be sending in Break Bulk so EXIDV is fine
*         for now but will have to change down the line!)
          if gv_parnr_ppr = gc_ppr.
            gt_bat_char-vendrbatch = gs_e1edl44-charg.

          else.
            gt_bat_char-vendrbatch = gs_e1edl44-exidv.
          endif.

*         Store the Xref between HU and Vendor Batch. This will be used
*         later to help assign the PACKAGE_NUMBER characteristic when
*         generating new Batches in a Bundled Roll scenario. Example of
*         data would look something like this:
*         Original HU          Vendor Batch
*         -----------          ------------
*         BT1                  BT1
*         BT1                  BT2
*         BT3                  BT3
*         BT3                  BT4
*         BT3                  BT5
*
*         Batches BT1 & BT2 are bundled within HU BT1
*         Batches BT3, BT4, BT5 are bundled within HU BT3
          gs_hu_xref-kdmat      = gt_bat_char-vendrbatch.  "Vendor Batch
          append gs_hu_xref to gt_hu_xref.


*         Shouldn't have to worry if this is PaperPro or not since there
*         will ALWAYS BE at 1:1 relationship between L24 and L44 segs
*         whether its Bundled Roll or not.
          modify gt_mbhp_tab
                 index lv_24count
                 transporting charg
                              exidv
                              37tabix
                              44tabix.
          modify gt_bat_char
                 index lv_24count
                 transporting vendrbatch.
          clear: gt_bat_char.  "CR-8050-FIX2


          clear  gv_tabix.
*       End CR-8050

      endcase.
    endloop.

    check gv_idoc_error = gc_false.
*   Material Fetch & Validataion Logic.
    perform sub_mat.
    check gv_idoc_error = gc_false.

*   Check whether batch field is not empty in IDoc for all batch
*   managed material (provided SAP material is found)
    perform sub_mat_type.
    check gv_idoc_error = gc_false.

*   Batch Validation Logic
    perform sub_bat.
    check gv_idoc_error = gc_false.

*   Call function ZFM_CREATE_BATMAS03 to create batches and
*   to post batch characteristics
    perform sub_bat_create.

    check gv_idoc_error = gc_false.
*   Modify gt_idoc_data with new changes
    perform sub_mod_idoc.

*--> Begin insert EDVK946089
  endif.

  check gv_idoc_error = gc_false.
* Delete HU Segments E1EDL37 and E1EDL44 because we don't need this
* for Inbound delivery creation by the standard BORES_IDOC_INPUT_DESADV1
* function module. It might fail with these segments due to the core
* mod made on Domain EXIDV.
  delete gt_idoc_data where segnam =  gc_e1edl37 or
                            segnam =  gc_e1edl44.

* For the Trades ASN1 (which is against PO1), retrieve additional
* PO1 item-based information since the PO Line Item has been identified
* by this time in FORM sub_mat
  if gv_trades_asn1 = gc_true.
    perform retrieve_trades_asn1_info.
  endif.
*--> End insert EDVK946089

endform.    "process_idoc.

*&---------------------------------------------------------------------*
*&      Form  sub_po_existence
*&---------------------------------------------------------------------*
* Check the existence of PO in SAP and get corresponding material
*----------------------------------------------------------------------*
form sub_po_existence .

  data: begin of lt_po occurs 0,
          ebeln like  ekpo-ebeln,
          ebelp like  ekpo-ebelp,
        end of lt_po.

  data: lv_subrc like sy-subrc.

  clear:  lt_po, lt_po[].

*******begin of changes pragup1 05/10/2012 E0VK988987******
  constants: lc_i2301_category type zcatgory value 'I2301'.

  data: ls_zdl_fields type zdl_fields,
        lt_zdl_fields type standard table of zdl_fields.

  select *
    from zdl_fields
    into table lt_zdl_fields
    where category = lc_i2301_category.

  clear : gv_do_loop, gv_wait_sec.

  read table lt_zdl_fields
        into ls_zdl_fields
    with key fieldname = 'WAIT_SECONDS'.
  if sy-subrc = 0.
*   Set global variable
    gv_wait_sec = ls_zdl_fields-lowval.
  endif.

  read table lt_zdl_fields
        into ls_zdl_fields
    with key fieldname = 'WAIT_LOOPS'.
  if sy-subrc = 0.
*   Set global variable
    gv_do_loop = ls_zdl_fields-lowval.
  endif.
*******end of changes pragup1 05/10/2012 E0VK988987******


  if not gt_temp_mat[] is initial.
* Select all PO details from EKPO table for the given PO
* ensuring whether it does exist in SAP
    select ebeln
          into corresponding fields of table lt_po
          from ekko
          for all entries in gt_temp_mat
          where ebeln = gt_temp_mat-ebeln.
  endif.

  sort gt_temp_mat by ebeln. " ebelp.
  sort lt_po       by ebeln. " ebelp.

  gv_fail  = gc_false.    "Initialize to sucess status
  refresh: gt_locked_pos.
  clear: gt_locked_pos.
  loop at gt_temp_mat.
    read table lt_po with key
                      ebeln = gt_temp_mat-ebeln
                      binary search.
    if sy-subrc = 0.
      gv_idoc_error = gc_false.
* Lock PO
      read table gt_locked_pos with key
                 ebeln = gt_temp_mat-ebeln.
      if sy-subrc = 0.
* Error out - PO is locked by other processes/user
        perform sub_idoc_status_fill using
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          text-e06                                          "msgv1
          gt_temp_mat-ebeln                                 "msgv2
          gt_temp_mat-ebelp                                 "msgv3
          ' '                                               "msgv4
          'PROCESS_IDOC'          "routid
          gc_e1edl43              "seg num
          ' '.                    "seg field
        gv_fail  = gc_true.
        exit.
      else.
*******begin of changes pragup1 05/10/2012 E0VK988987******
        perform lock_po changing lv_subrc.
*******end of changes pragup1 05/10/2012 E0VK988987******

*        CALL FUNCTION 'ENQUEUE_EMEKKOE'
*         EXPORTING
*           mode_ekko            = 'E'
*           mode_ekpo            = 'E'
*           mandt                = sy-mandt
*           ebeln                = gt_temp_mat-ebeln
*           ebelp                = gt_temp_mat-ebelp
**           X_EBELN              = ' '
**           X_EBELP              = ' '
**           _SCOPE               = '2'
**           _WAIT                = ' '
**           _COLLECT             = ' '
*         EXCEPTIONS
*           foreign_lock         = 1
*           system_failure       = 2
*           OTHERS               = 3                  .

        if lv_subrc <> 0.
* Error out - PO is locked by other processes/user
          gt_locked_pos-ebeln = gt_temp_mat-ebeln.
          append gt_locked_pos.
          perform sub_idoc_status_fill using
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '000'                   "err msg
            text-e06                                        "msgv1
            gt_temp_mat-ebeln                               "msgv2
            gt_temp_mat-ebelp                               "msgv3
            ' '                                             "msgv4
            'PROCESS_IDOC'          "routid
            gc_e1edl43              "seg num
            ' '.                    "seg field
          gv_fail  = gc_true.
          exit.
        endif.

      endif.
    else.
      if gv_trades_asn1 = gc_false.  "BCB10 insert
*       Error out - PO does not exist in SAP for the given PO:
        perform sub_idoc_status_fill using
        c_idoc_status_error                                 "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '000'                   "err msg
            text-103                                        "msgv1
            gv_ebeln                                        "msgv2
            gs_e1edl43-posnr                                "msgv3
            ' '                                             "msgv4
            'PROCESS_IDOC'          "routid
            gc_e1edl43              "seg num
            ' '.                    "seg field
*     Begin BCB10 insert
      else.
        gv_trigger_wf = gc_true.
*       TRD ASN: PO & not in SAP
        perform sub_idoc_status_fill using
        c_idoc_status_error                                 "status 51
          gs_idoc_ctrl-docnum      "idoc number
          c_error                  "status msg type
          'ZSD_DL'                 " message class
          '603'                    " err msg
          gv_ebeln                                          "msgv1 PO
          ' '                                               "msgv2
          ' '                                               "msgv3
          gv_ebeln                                          "msgv4 PO
        'SUB_PO_EXISTENCE'                                " routid
        gt_temp_mat-43tabix                                  "seg num
        'BELNR'.                                      "seg field
      endif.
*     End BCB10 insert
    endif.
    if gv_idoc_error = gc_true.  "At any point of time failed?
      gv_fail  = gc_true.
    endif.
  endloop.
  if gv_fail = gc_true.
    gv_idoc_error = gc_true.
  else.
    gv_idoc_error = gc_false.
  endif.

endform.                    " sub_po_existence
*EJECT
*&---------------------------------------------------------------------*
*&      Form  sub_mat
*&---------------------------------------------------------------------*
form sub_mat.

*  The logic to fetch SAP material is as follows:                      *
*  As far as vendor ASN is concerned, vendors are going to send IDoc   *
*  only for the case of batch managed material.  For non-batch managed *
*  materials are handled by Portal ASN.
*                                                                      *
*    a.  select MATNR from EKPO where EBELN =  SAP PO number           *
*        (concatenation of 'I000' and CBOPS PO number)                 *
*    b.  For each MATNR, read MARA to get the material's CUOBF.        *
*    c.  For each MATNR call the following function Module             *
*        "VC_I_GET_CONFIGURATION_IBASE" and read the ROLL_WIDTH        *
*        from the return table.                                        *
*    d.  If E1EDL15.ATNAM = ROLL_WIDTH and E1EDL15.ATWRT = the above   *
*        fetched value, Get that MATNR.                                *


*Table to store Material Type from Zdl_fields table
  data: gt_zdl_fields_mtart like zdl_fields occurs 0 with header line.


  types: begin of gty_sapinfo,
           ebeln type ebeln,  "PO
           ebelp type ebelp,  "PO item
           matnr type matnr,  "PO material
           atwrt type atwrt,  "PO material roll width
         end of gty_sapinfo.

* Local variables
  data:
    lv_temp_tabix     like syst-tabix,
    lv_mbhp_tabix     like syst-tabix,
    lv_dont_delete(1),
    lv_cuobj          like inob-cuobj,
    lv_unit_code      like  cawn-atwrt.

  data: lv_ebeln  type ebeln.                               "BCB10

  constants:
    lc_matkl_dpr like ekpo-matkl value 'DPR',
    lc_matkl_xdp like ekpo-matkl value 'XDP'.

*Load the MTO Material Type from ZDL_fields
  clear gt_zdl_fields_mtart[].
  refresh gt_zdl_fields_mtart[].

  select * into table gt_zdl_fields_mtart from zdl_fields
          where category  = 'I2301'
          and   fieldname = 'MTART'.


* Check whether the material number exists in MARA table. Retrieve info
* for each PO line item material (multiple PO's may exist)
  if not gt_mbhp_tab[] is initial.
    clear:  gt_temp_mat, gt_temp_mat[].
    select ep~matnr
           m~cuobf
           m~xchpf
           m~mtart
           ep~ebeln
           ep~ebelp
           ep~werks
           ep~lgort
           ep~matkl
           ep~knttp   "Account Assignment Indicator BCB03
           ep~cuobj   "Config object for PO Item Char
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|START
           ep~meins
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|END
           zp~omd_ind "Plant OMD Indicator          BCB03
          into corresponding fields of table gt_temp_mat
          from mara         as m
          inner join ekpo   as ep on ep~matnr    =  m~matnr
          inner join zplant as zp on zp~werks    = ep~werks
          for all entries in gt_mbhp_tab
          where ep~ebeln = gt_mbhp_tab-ebeln
            and ep~loekz = space. "make sure not locked

*   Remove any entries if the Plant is OMD and the Account Assignment
*   Indicator is 'L' (Non-Valuated PO Item)
    if sy-subrc = 0.
      delete gt_temp_mat where omd_ind = 'Y'  "plant is OMD
                           and knttp   = 'L'. "non valuated PO item
    endif.

  endif.
* Determine each PO Item Material's Roll Width and store in a work table
  loop at gt_temp_mat.

    gv_tabix = sy-tabix.

    clear: gt_conf_out[], gs_conf_out.
*           gs_sapinfo.
* Reading the characteristics from Batch is only an interim
* process.
    clear gt_zdl_fields_matkl.
    read table gt_zdl_fields_matkl with key
         fieldname = 'MATKL'
         lowval = gt_temp_mat-matkl.
    if sy-subrc = 0.
*    if gt_temp_mat-matkl = lc_matkl_dpr
*      or gt_temp_mat-matkl = lc_matkl_xdp.
      lv_cuobj = gt_temp_mat-cuobj.
    else.
      lv_cuobj = gt_temp_mat-cuobf.
    endif.

*Check the Material Type if found use cuobj = ekpo-cuobj
    read table gt_zdl_fields_mtart with key
        fieldname = 'MTART'
        lowval = gt_temp_mat-mtart.

    if sy-subrc eq 0.
      lv_cuobj = gt_temp_mat-cuobj.
    endif.


*     Retrieve SAP Characteristic Values
    call function 'VC_I_GET_CONFIGURATION_IBASE'
      exporting
        instance           = lv_cuobj
        language           = sy-langu
      tables
        configuration      = gt_conf_out
      exceptions
        instance_not_found = 1
        others             = 2.

    if sy-subrc eq 0.
      sort gt_conf_out by atnam atwrt.
*       Reformat the decimal value to implied decimal, leading 0 format
*       in gt_conf_out
      perform reformat_char_value.

* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|START
*       Store PO, PO Item, Material and Roll Width in a table
*      gt_temp_mat-atwrt = gs_conf_out-atwrt. "Roll Width Value
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|END

* For DPR Material groups, populate Order Link
      if gt_temp_mat-matkl = gt_zdl_fields_matkl-lowval.
        clear gs_conf_out.
        read table gt_conf_out into gs_conf_out with key
                 atnam = zsdc_order_link
                 binary search.
        if sy-subrc = 0.
          gt_temp_mat-order_link = gs_conf_out-atwrt.
        else.
          clear gt_temp_mat-order_link.
        endif.
      endif.
      modify gt_temp_mat index gv_tabix
        transporting atwrt unit_code order_link.

    endif.

  endloop.

  sort gt_temp_mat by ebeln atwrt.
* Process each ASN item and convert the AFPA code to the SAP Material
  loop at gt_mbhp_tab.

    gv_tabix = sy-tabix.

*   Get the correct Batch deep structure record based on AFPA code and
*   Batch. We need to include Batch on this READ because the same AFPA
*   can be on multiple ASN line items and the Batch gets us the unique
*   match we need.  gt_bat_char was built from the E1EDL15 batch
*   characteristic segments for each ASN line item.
    read table gt_bat_char
      with key matnr      = gt_mbhp_tab-matnr  "AFPA code
               vendrbatch = gt_mbhp_tab-charg. "Batch
*   Begin CR-8050-FIX2
    if sy-subrc = 0.
*   End CR-8050-FIX2

*   Move the table portion of the deep structure (containing
*   characteristic name and characteristic value) to a work table.
      gt_mbpsv_chars[] = gt_bat_char-chars[].
      sort gt_mbpsv_chars by atnam.

*   Retrieve the ASN line item's Roll Width characterist value
      read table gt_mbpsv_chars
        with key atnam = zsdc_roll_width
        binary search.

      if sy-subrc = 0.

*     Reformat the ASN line's Roll Width value to decimal value to
*     implied decimal, leading 0 format.
*     in IDoc data
        perform format_num_value using    gt_mbpsv_chars-atnam
                                 changing gt_mbpsv_chars-atwrt.
        perform format_value     changing gt_mbpsv_chars-atwrt.

*     Find a match on ROLL_WIDTH between the SAP PO info stored in
*     gt_temp_mat and the ASN line item info stored in gt_mbhp_tab

*     Begin CR-8050-FIX2
*     PaperPro sends in the SAP Material Number as opposed to the AFPA
*     code. The issue is that we were directed, for PaperPro processing,
*     to ignore the Decimals of the Roll Width when comparing the SAP
*     Material Roll Width (from the PO's on the idoc) to the Roll Width
*     on the ASN idoc. So, if SAP Material X has 76.25 and Idoc has
*     76.25 then 76 will be compared to 76. This is done in subroutine
*     format_value. This issue is that if the PO has multiple Materials
*     that have the same value to the left of the decimal then we would
*     have a Duplicate Material scenario (ie 76.25 and 76.50 would
*     appear to be both Roll Widths of 76). Since Paper Pro sends in the
*     SAP Material Number then we can use it as another KEY field in the
*     READ statement below.
        if gv_parnr_ppr ne gc_ppr.
*     End CR-8050-FIX2

          clear gt_temp_mat.
          read table gt_temp_mat
            with key ebeln = gt_mbhp_tab-ebeln     "PO
                     atwrt = gt_mbpsv_chars-atwrt  "Roll Width
            binary search.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|START
          if sy-subrc ne 0.
            read table gt_temp_mat
             with key ebeln = gt_mbhp_tab-ebeln     "PO
                      atwrt1 = gt_mbpsv_chars-atwrt  "Roll Width
             binary search.
            if sy-subrc eq 0.
read table gt_mbpsv_chars into gt_mbpsv_chars with key atnam = zsdc_roll_width.
              gt_mbpsv_chars-atwrt = gt_temp_mat-rollwid.
modify gt_mbpsv_chars index sy-tabix from gt_mbpsv_chars transporting atwrt.
read table gt_mbpsv_chars into gt_mbpsv_chars with key atnam = zsdc_roll_diameter.
              gt_mbpsv_chars-atwrt = gt_temp_mat-rolldia.
modify gt_mbpsv_chars index sy-tabix from gt_mbpsv_chars transporting atwrt.

*                  MOVE-CORRESPONDING gt_mbpsv_chars TO gt_bat_char-chars.
              refresh gt_bat_char-chars.
             append lines of gt_mbpsv_chars from 1 to gt_bat_char-chars.
              modify gt_bat_char index gv_tabix transporting chars.
            endif.
          endif.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|END

*     Begin CR-8050-FIX2
        else.
*       PaperPro
          clear gt_temp_mat.
          read table gt_temp_mat
            with key ebeln = gt_mbhp_tab-ebeln     "PO
                     atwrt = gt_mbpsv_chars-atwrt  "Roll Width
                     matnr = gt_mbhp_tab-matnr.    "SAP Material
        endif.
*     End CR-8050-FIX2

        if sy-subrc = 0.

*       Update main work table with SAP Material, PO line item, PO Plant
*       and PO storage location
          gt_mbhp_tab-nmatnr       = gt_temp_mat-matnr.
          gt_mbhp_tab-ebelp        = gt_temp_mat-ebelp.
          gt_mbhp_tab-werks        = gt_temp_mat-werks.
          gt_mbhp_tab-lgort        = gt_temp_mat-lgort.
          modify gt_mbhp_tab
                index gv_tabix
                transporting nmatnr ebelp werks lgort.

        else. "no SAP match

*       Begin CR-8050
          clear gt_temp_mat.
          read table gt_temp_mat
               with key ebeln = gt_mbhp_tab-ebeln     "PO
                        matnr = gt_mbhp_tab-matnr.
          if sy-subrc = 0.
            lv_unit_code = gt_temp_mat-unit_code.
            if lv_unit_code = 'C' or
               lv_unit_code = 'D' or
               lv_unit_code = 'S'.                          "CR-8050
              perform check_update_nonroll.
            elseif lv_unit_code = 'R' or
                   lv_unit_code is initial.
*       End CR-8050

              if gv_trades_asn1 = gc_false.  "BCB10 insert
*               SAP Material not derived: PO & AFPA & Roll Width &
                perform sub_idoc_status_fill using
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '196'                    " err msg
                  gt_mbhp_tab-ebeln                         " msgv1
                  gt_mbhp_tab-matnr                         "msgv2
                  gt_mbpsv_chars-atwrt                      "msgv3
                  ' '                                       "msgv4
                  'SUB_MAT'                                 " routid
                  ' '                                       "seg num
                  ' '.                                      "seg field
*             Begin BCB10 insert
              else.
                gv_trigger_wf = gc_true.
                gv_segnum = gt_mbhp_tab-43tabix.

*               Retrieve the PO2 which is what was on the Idoc if this
*               was a Trades ASN1 from a Vendor. PO2 will have Doc Flow
*               ref back to the Sales Order which is what we want in
*               function ZDL_E04625_GET_ASN_DATA.
                read table gt_tr_po_i into gs_tr_po_i
                  with key zz_trnpricepo = gt_mbhp_tab-ebeln. "PO1
                if sy-subrc = 0.
                  lv_ebeln = gs_tr_po_i-ebeln. "PO2
                else.
                  lv_ebeln = gt_mbhp_tab-ebeln. "PO1
                endif.

*               If the Plant is blank then retrieve it for this PO
                if gt_mbhp_tab-werks is initial.
                  perform retrieve_plant using gt_mbhp_tab-ebeln
                                     changing  gt_mbhp_tab-werks.
*                 If the Plant is blank, this may have been a Trades
*                 ASN1 scenario and this could be the PO1 which has
*                 no Doc Flow. Attempt to see if we can retrieve PO2
*                 which has Doc Flow and then retrieve the Plant
                  if gt_mbhp_tab-werks is initial.
                    perform retrieve_plant using lv_ebeln
                                   changing  gt_mbhp_tab-werks.
                  endif.
                endif.

*               TRD PLT & ASN: material not on PO &
                perform sub_idoc_status_fill using
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '601'                    " err msg
                  gt_mbhp_tab-werks                     " msgv1  Plant
                  lv_ebeln                                  "msgv2 PO
                  ' '                                       "msgv3
                  lv_ebeln                                  "msgv4   PO
                  'SUB_MAT'                                 " routid
                  gv_segnum                                 "seg num
                  'BELNR'.                                  "seg field
              endif.
*             End BCB10 insert
              return.
            endif.
          else.

            if gv_trades_asn1 = gc_false.  "BCB10 insert
*       Begin CR-8050
*       SAP Material not derived:  Material No , PO
              perform sub_idoc_status_fill using
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '316'                    " err msg
                gt_mbhp_tab-matnr                           " msgv1
                gt_mbhp_tab-ebeln                           "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                'SUB_MAT'                " routid
                ' '                      "seg num
                ' '.                     "seg field
              gv_idoc_error = gc_true.
*             Begin BCB10 insert
            else.
              gv_trigger_wf = gc_true.
              gv_segnum = gt_mbhp_tab-43tabix.

*             Retrieve the PO2 which is what was on the Idoc if this
*             was a Trades ASN1 from a Vendor. PO2 will have Doc Flow
*             ref back to the Sales Order which is what we want in
*             function ZDL_E04625_GET_ASN_DATA.
              read table gt_tr_po_i into gs_tr_po_i
                with key zz_trnpricepo = gt_mbhp_tab-ebeln. "PO1
              if sy-subrc = 0.
                lv_ebeln = gs_tr_po_i-ebeln. "PO2
              else.
                lv_ebeln = gt_mbhp_tab-ebeln. "PO1
              endif.

*             If the Plant is blank then retrieve it for this PO
              if gt_mbhp_tab-werks is initial.
                perform retrieve_plant using gt_mbhp_tab-ebeln
                                   changing  gt_mbhp_tab-werks.
*               If the Plant is blank, this may have been a Trades ASN1
*               scenario and this could be the PO1 which has no Doc
*               Flow. Attempt to see if we can retrieve PO2 which has
*               Doc Flow and then retrieve the Plant
                if gt_mbhp_tab-werks is initial.
                  perform retrieve_plant using lv_ebeln
                                 changing  gt_mbhp_tab-werks.
                endif.
              endif.

*             TRD PLT & ASN: material not on PO &
              perform sub_idoc_status_fill using
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '601'                    " err msg
                gt_mbhp_tab-werks                      " msgv1  Plant
                lv_ebeln                                    "msgv2   PO
                ' '                                         "msgv3
                lv_ebeln                                    "msgv4   PO
                'SUB_MAT'                                 " routid
                gv_segnum                                 "seg num
                'BELNR'.                                  "seg field
            endif.
*             End BCB10 insert
            return.
          endif.
        endif.
*     End CR-8050


      else. "roll width does not exist for this asn line item afpa/batch
*     ROLL_WIDTH characteristic does not exist for AFPA & Batch &
        clear gt_temp_mat.
        read table gt_temp_mat
             with key ebeln = gt_mbhp_tab-ebeln     "PO
                      matnr = gt_mbhp_tab-matnr.
        if sy-subrc = 0.
          lv_unit_code = gt_temp_mat-unit_code.
          if lv_unit_code = 'C' or
            lv_unit_code = 'D' or
            lv_unit_code = 'S'.                             "CR-8050
            perform check_update_nonroll.
          elseif lv_unit_code = 'R' or
                 lv_unit_code is initial.
            if gv_trades_asn1 = gc_false.  "BCB10 insert
              perform sub_idoc_status_fill using
                c_idoc_status_error
                                                            "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '197'                    " err msg
                gt_mbhp_tab-matnr                           " msgv1
                gt_mbhp_tab-charg                           "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                'SUB_MAT'                                 " routid
                ' '                                       "seg num
                ' '.                                      "seg field
*           Begin BCB10 insert
            else.
              gv_trigger_wf = gc_true.
              gv_segnum = gt_mbhp_tab-43tabix.

*             Retrieve the PO2 which is what was on the Idoc if this
*             was a Trades ASN1 from a Vendor. PO2 will have Doc Flow
*             ref back to the Sales Order which is what we want in
*             function ZDL_E04625_GET_ASN_DATA.
              read table gt_tr_po_i into gs_tr_po_i
                with key zz_trnpricepo = gt_mbhp_tab-ebeln. "PO1
              if sy-subrc = 0.
                lv_ebeln = gs_tr_po_i-ebeln. "PO2
              else.
                lv_ebeln = gt_mbhp_tab-ebeln. "PO1
              endif.

*             If the Plant is blank then retrieve it for this PO
              if gt_mbhp_tab-werks is initial.
                perform retrieve_plant using gt_mbhp_tab-ebeln
                                   changing  gt_mbhp_tab-werks.
*               If the Plant is blank, this may have been a Trades ASN1
*               scenario and this could be the PO1 which has no Doc
*               Flow. Attempt to see if we can retrieve PO2 which has
*               Doc Flow and then retrieve the Plant
                if gt_mbhp_tab-werks is initial.
                  perform retrieve_plant using lv_ebeln
                                 changing  gt_mbhp_tab-werks.
                endif.
              endif.

*             TRD PLT & ASN: material not on PO &
              perform sub_idoc_status_fill using
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '601'                    " err msg
                gt_mbhp_tab-werks                       " msgv1  Plant
                lv_ebeln                                    "msgv2   PO
                ' '                                         "msgv3
                lv_ebeln                                    "msgv4   PO
                'SUB_MAT'                                   " routid
                gv_segnum                                   "seg num
                'BELNR'.                                    "seg field
            endif.
*           End BCB10 insert
            return.
          else.

*       Begin CR-8050
*       SAP Material not derived:  Material No , PO
            perform sub_idoc_status_fill using
              c_idoc_status_error
                                                            "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZSD_DL'                 " message class
              '316'                    " err msg
              gt_mbhp_tab-matnr                             " msgv1
              gt_mbhp_tab-ebeln                             "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              'SUB_MAT'                " routid
              ' '                      "seg num
              ' '.                     "seg field
            gv_idoc_error = gc_true.
            return.
          endif.
*       End CR-8050
        endif.
      endif.

*   Begin CR-8050-FIX2
    else.
*     No corresponding batch in gt_bat_char for Material Batch & &
      perform sub_idoc_status_fill using
        c_idoc_status_error
                                                            "status 51
        gs_idoc_ctrl-docnum      "idoc number
        c_error                  "status msg type
        'ZSD_DL'                 " message class
        '350'                    " err msg
        gt_mbhp_tab-matnr                                   " msgv1
        gt_mbhp_tab-charg                                   "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'SUB_MAT'                " routid
        ' '                      "seg num
        ' '.                     "seg field
      gv_idoc_error = gc_true.
      return.
    endif.
*   End CR-8050-FIX2

  endloop. "loop at ASN item

endform.                    " sub_mat
*&---------------------------------------------------------------------*
*&      Form  reformat_char_value
*&---------------------------------------------------------------------*
* Reformat batch characteistics values into char value
*----------------------------------------------------------------------*
form reformat_char_value .

  data:
    lv_index        type sytabix,
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|START
    lv_atwrt1       like conf_out-atwrt,

    lt_zdl_flds_3ps type table of zdl_fields,
    ls_zdl_flds_3ps type zdl_fields,
    lv_rolldia      type cawn-atwrt,
    lv_rollwid      type cawn-atwrt.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|END


* Question to Bruce, why are you not using a Read table with
* Binary search? Is it not better for Performance reasons to
* read instead of loop? "Showry
* Format Conf_out data
*  if gv_parnr_ppr ne gc_ppr.
*  LOOP AT gt_conf_out INTO gs_conf_out
*    WHERE atnam EQ zsdc_roll_width. "ROLL_WIDTH
*    lv_index = sy-tabix.
*    PERFORM format_value CHANGING gs_conf_out-atwrt.
*    MODIFY gt_conf_out FROM gs_conf_out INDEX lv_index.
*  ENDLOOP.
*  else.
* Begin of CR-8050
  clear: gs_conf_out,lv_rolldia,lv_rollwid.
  read table gt_conf_out into gs_conf_out with key
             atnam = zsdc_unit_code binary search.
  if sy-subrc = 0.
    gt_temp_mat-unit_code = gs_conf_out-atwrt.
    if gs_conf_out-atwrt = 'R'.   "Roll
      clear gs_conf_out.
      if gt_temp_mat-matkl = gt_zdl_fields_matkl-lowval.
        read table gt_conf_out into gs_conf_out with key
                   atnam = zsdc_roll_width_whole
                   binary search.
        if sy-subrc = 0.
          perform format_value changing gs_conf_out-atwrt.
          modify gt_conf_out from gs_conf_out
                 transporting atwrt
                 where atnam = zsdc_roll_width.
        endif.
      else.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02152017|START
        clear:lv_rolldia, lv_rollwid.
        read table gt_conf_out into gs_conf_out with key
                   atnam = zsdc_roll_diameter binary search.
        if sy-subrc = 0.
*          SPLIT gs_conf_out-atwrt AT ' ' INTO lv_rolldia.
          split gs_conf_out-atwrt at ' ' into lv_rolldia lv_rollwid.
          gt_temp_mat-rolldia = lv_rolldia.
        endif.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02152017|END

        read table gt_conf_out into gs_conf_out with key
                   atnam = zsdc_roll_width binary search.
        if sy-subrc = 0.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02152017|START
          clear:lv_rolldia, lv_rollwid.
          split gs_conf_out-atwrt at ' ' into lv_rollwid  lv_rolldia.
          gt_temp_mat-rollwid = lv_rollwid.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02152017|END
          perform format_value changing gs_conf_out-atwrt.
          modify gt_conf_out from gs_conf_out
                 transporting atwrt
                 where atnam = zsdc_roll_width.

* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|START
          gt_temp_mat-atwrt = gs_conf_out-atwrt.
          modify gt_temp_mat from gt_temp_mat
                transporting atwrt rolldia rollwid.
*                 WHERE atnam = zsdc_roll_width.

        endif.

        select * into table lt_zdl_flds_3ps
          from zdl_fields
            where category  = 'I2301'
              and fieldname = '3PS'.

        if sy-subrc eq 0.
          loop at lt_zdl_flds_3ps into ls_zdl_flds_3ps.
            if ls_zdl_flds_3ps-lowval eq gt_temp_mat-werks and
               ls_zdl_flds_3ps-highval eq gt_temp_mat-meins.

              read table gt_conf_out into gs_conf_out with key
               atnam = zsdc_roll_width_metric binary search.
              if sy-subrc = 0.
                gt_temp_mat-atwrt1 = gs_conf_out-atwrt.
                perform format_value changing gt_temp_mat-atwrt1.
                modify gt_temp_mat from gt_temp_mat
                transporting atwrt1.
                exit.
              endif.
            endif.
          endloop.
        endif.

* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|END

      endif.
    elseif gs_conf_out-atwrt = 'C' or
           gs_conf_out-atwrt = 'D' or
           gs_conf_out-atwrt = 'S'.
      "?????
    endif.
  else.
    "What should happen?
  endif.
*  endif.   "PPR
* End of CR-8050

endform.                    " reformat_char_value
*&---------------------------------------------------------------------*
*&      Form  sub_mat_type
*&---------------------------------------------------------------------*
* If any one of the material is not existing in SAP error out and
* if existing, update whether it is batch managed one or not.  This
* will help us to decide whether we need to create batch and batch
* characteristics
*----------------------------------------------------------------------*
form sub_mat_type .

*Local Internal Table
*Declaration----------------------------------------------*
* Internal table to store Portal ASN info
  data: int_asn type standard table of zdl_asninfo initial size 0
                                                 with header line.

  data  lv_flag type flag.                " Local flag

  data: lv_ebeln type ebeln,                             " BCB10
        lv_lgort type lgort_d.                           " BCB10

  gv_fail = gc_false.
  loop at gt_mbhp_tab.
    gv_tabix = sy-tabix.
    if gt_mbhp_tab-nmatnr is initial.
* If no corresponding SAP Material was derived then update error log
* sap_material_not_determined for the given PO line item
      perform sub_idoc_status_fill using
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          text-100                                          "msgv1
          gt_mbhp_tab-ebeln                                 "msgv2
          gt_mbhp_tab-ebelp                                 "msgv3
          ' '                                               "msgv4
          'SUB_MAT_TYPE'          "routid
          gc_e1edl24              "seg num
          ' '.                    "seg field
    else.
      gv_idoc_error = gc_false.

      sort gt_temp_mat by matnr.
      read table gt_temp_mat
           with key matnr = gt_mbhp_tab-nmatnr
           binary search.
      if sy-subrc = 0.
*        Check for Storage location in PO, if the PO does not have
*        Stor.Locaion don't create inbound idoc, since storage location
*        is mandatory for packaging.
        if gt_temp_mat-lgort is initial.

*         Begin BCB10 insert
          if gv_trades_asn1 = gc_false or  "not Trades ASN1
            ( gv_trades_asn1 = gc_true and " is Trades ASN1 but it's a
              gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN
*         End BCB10 insert

            perform sub_idoc_status_fill using
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZSD_DL'                 " message class
              '000'                    " err msg
             'Storage Location does not exist on Purchase Order'(e03)
                                                            " msgv1
              gv_ekpo_ebeln                                 "msgv2 PO1
              gv_ekpo_ebelp                                 "msgv3
              ' '                                           "msgv4
              'SUB_MAT_TYPE'                            " routid
              gc_e1edl43                               "seg num
              ' '.                                      "seg field
*         Begin BCB10 insert
          else.
            gv_trigger_wf = gc_true.
*           If the PO1 is missing a Storage Location then report it;
            lv_ebeln = gt_temp_mat-ebeln.

*           TRD PLT & ASN: SAP PO & missing STGLOC
            perform sub_idoc_status_fill using
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZSD_DL'                 " message class
              '605'                    " err msg
              gt_temp_mat-werks                           " msgv1 PLANT
              lv_ebeln                                      "msgv2  PO1
              ' '                                           "msgv3
              lv_ebeln                                      "msgv4  PO1
              'SUB_MAT_TYPE'                            " routid
              gt_mbhp_tab-43tabix                       "seg num
              'BELNR'.                                      "seg field
          endif.
          return.

*       IF the PO1's Storage Location has a value then check to make
*       sure the PO2's Storage Location has a value
        else.
*         Retrieve the PO2 which is what was on the Idoc if this was
*         a Trades ASN1 from a Vendor. PO2 will have Doc Flow ref back
*         to the Sales Order which is what we want in function
*         ZDL_E04625_GET_ASN_DATA.
          read table gt_tr_po_i into gs_tr_po_i
            with key zz_trnpricepo = gt_temp_mat-ebeln. "PO1
          if sy-subrc = 0.
            lv_ebeln = gs_tr_po_i-ebeln. "PO2
            select single lgort into lv_lgort from ekpo
              where ebeln = lv_ebeln          "PO
                and ebelp = gt_temp_mat-ebelp. "PO item
            if sy-subrc = 0 and lv_lgort is initial.
*             Report Missing Storage Location for PO2

              if gv_trades_asn1 = gc_false or  "not Trades ASN1
                ( gv_trades_asn1 = gc_true and " is Trades ASN1 but a
                  gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN

                perform sub_idoc_status_fill using
                c_idoc_status_error                         "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '000'                    " err msg
               'Storage Location does not exist on Purchase Order'(e03)
                                                            " msgv1
                  lv_ebeln                                  "msgv2 PO2
                  gt_temp_mat-ebelp                    "msgv3 PO item
                  ' '                                       "msgv4
                  'SUB_MAT_TYPE'                            " routid
                  gc_e1edl43                               "seg num
                  ' '.                                      "seg field
              else. "Trades ASN1
                gv_trigger_wf = gc_true.
*               If the PO2 is missing a Storage Location then report it

*               TRD PLT & ASN: SAP PO & missing STGLOC
                perform sub_idoc_status_fill using
                c_idoc_status_error                         "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '605'                    " err msg
                  gt_temp_mat-werks                       " msgv1 PLANT
                  lv_ebeln                                  "msgv2  PO2
                  ' '                                       "msgv3
                  lv_ebeln                                  "msgv4  PO2
                  'SUB_MAT_TYPE'                        " routid
                  gt_mbhp_tab-43tabix                       "seg num
                  'BELNR'.                                    "seg field
              endif. "If Trades ASN1 and not a Manual ASN
              return.
            endif. "Select on EKPO and check of Sloc is blank
          endif. "Read on PO xref table gt_tr_po_i
*         End BCB10 insert
        endif.

* Check whether it is batch manages one or not
        if not gt_temp_mat-xchpf is initial.  "Batch-managed material
          if gv_parnr_ppr = gc_ppr.                         "CR-8050
            gt_mbhp_tab-charg = gt_mbhp_tab-charg.
          else.
            gt_mbhp_tab-charg = gt_mbhp_tab-exidv.
          endif.
        else.  "Non-batch managed material
          clear: gt_mbhp_tab-charg.
        endif.
        modify gt_mbhp_tab index gv_tabix
              transporting charg.
        clear gv_tabix.
      endif.
    endif.
    if gv_idoc_error = gc_true.
      gv_fail  = gc_true.
    endif.
  endloop.
  if gv_fail = gc_true.
    gv_idoc_error = gc_true.
  else.
    gv_idoc_error = gc_false.
  endif.

  check gv_idoc_error = gc_false.

  clear int_asn.
  refresh int_asn.

*Validate duplicate bill of lading against delivery, PO, Material and
*Vendor id.
  loop at gt_mbhp_tab.
    int_asn-vgbel = gt_mbhp_tab-ebeln.
    int_asn-bolnr = gs_e1edl20-bolnr.
*    int_asn-matnr = gt_mbhp_tab-matnr.  "BCB06
    int_asn-matnr = gt_mbhp_tab-nmatnr.  "SAP Material BCB06
    int_asn-inhalt = gt_mbhp_tab-charg.
    append int_asn.
  endloop.

* Call Funtion Module 'Z_SD_DL_I2301_CHECK_DUPLI_ASN' to check duplicate
* delivery numbers against bill of lading, purchase order and unit id
  clear lv_flag.
  if not int_asn[] is initial.
    call function 'Z_SD_DL_I2301_CHECK_DUPLI_ASN'
      importing
        ex_flag               = lv_flag
      tables
        it_asninfo            = int_asn
      exceptions
        wrong_function_called = 1
        others                = 2.
    if sy-subrc = 0 and lv_flag = gc_true.
      loop at int_asn.
        if int_asn-flag = gc_true.
*       Begin BCB10 insert
*       For all ZDL_VASN idocs, if this is a duplicate ASN then archive
*       the idoc (status 68) instead of setting it to a 51.
*       End BCB10 insert

*       Update Error log, the idoc should not be processed if BOL
*       alreadyexist.
*         Begin BCB06
          shift int_asn-vgbel left deleting leading '0'.
          perform sub_idoc_status_fill using
*             c_idoc_status_error               "status 51 BCB10 delete
              c_idoc_status_delete              "status 68 BCB10 insert
              gs_idoc_ctrl-docnum                        "idoc number
*              c_error
              c_info
              "status msg type
              'ZSD_DL'                                   "message class
              '285'                                      "err msg
              int_asn-vbeln                                 "msgv1
              int_asn-bolnr                                 "msgv2
              int_asn-inhalt                                "msgv3
              int_asn-vgbel                                 "msgv4
              'SUB_MAT_TYPE'                                "routid
              ' '                                        "seg num
              ' '.                                       "seg field
*         End BCB06
*** CO 122352 - since the process team requested we no longer generate
*  a USD ticket - we turned the error into an INFO message (C_INFO).
* BUT doing this also resulted in not stopping the processing since
* GV_IDOC_ERROR must be set to stop processing - this is done in
* SUB_IDOC_STATUS - - so we must set it here manually
          gv_idoc_error = gc_true.
**** CO12352
          return.   "BCB10 insert
        endif.
      endloop.
    endif.
  endif.

endform.                    " sub_mat_type

*&---------------------------------------------------------------------*
*&      Form  sub_bat
*&---------------------------------------------------------------------*
* 1.  Create unique batch id.
* 2.  Generate internal tables needed for unique id creation and
*     batch creation
*----------------------------------------------------------------------*
form sub_bat .

  data:  lv_tabix  like  syst-tabix.

  clear: gt_mbh, gt_mbh[].

* Begin CR-8050: delete all code and modify below in a new block so as
*                to complicate the look of the code

*  IF NOT gt_mbhp_tab[] IS INITIAL.
*
**  Move all batch managed material, Batch and Handling Unit number
**  from central table to gt_mbh table which is going to be parameter
**  table for unique-id creation function module (E03126)
*
*    LOOP AT gt_mbhp_tab.
**  move-corresponding gt_mbhp_tab into gt_mbh for E03126
*      gt_mbh-matnr = gt_mbhp_tab-nmatnr.
*      IF gv_parnr_ppr = gc_ppr.                             "CR-8050
**        gt_mbh-exidv = gt_mbhp_tab-exidv.
*        gt_mbh-exidv = gt_mbhp_tab-charg.
*        gt_mbh-old_batch_no = gt_mbhp_tab-charg.
*      ELSE.
*        gt_mbh-exidv = gt_mbhp_tab-exidv.
*      ENDIF.
*      gt_mbh-bolnr = gs_e1edl20-bolnr.                      "BCB06
*      gt_mbh-vgbel = gt_mbhp_tab-ebeln.                     "PO  BCB07
*
**     Begin BCB09
**     Retrieve Vendor associated with PO
*      READ TABLE gt_ekko INTO gs_ekko WITH KEY ebeln = gt_mbh-vgbel
*        BINARY SEARCH.
*      lv_tabix = sy-tabix. "index of itab for use of binary
*      IF sy-subrc = 0.
*        gt_mbh-lifnr = gs_ekko-lifnr.
*      ELSE.
**       Retrieve the PO and Vendor and store in an itab sorted
**       by PO. This increases efficiency since we don't want to
**       keep hitting EKKO for every record if the referenced PO will
**       be the same on some or all Delivery items
*        SELECT SINGLE ebeln lifnr
*          INTO (gs_ekko-ebeln,
*                 gs_ekko-lifnr)
*          FROM ekko
*          WHERE ebeln = gt_mbh-vgbel.
*        INSERT gs_ekko INTO gt_ekko INDEX lv_tabix.
*        gt_mbh-lifnr = gs_ekko-lifnr.
*      ENDIF.
**     End BCB09
*
*      APPEND: gt_mbh.
*      CLEAR:  gt_mbh.
*    ENDLOOP.
*  ENDIF.
*
*  IF NOT gt_mbh[] IS INITIAL.
**  Create unique-id for Batch i.e., validate batch #
*    CALL FUNCTION 'Z_DL_E03126_UNIT_ID_CHECK'
*      TABLES
*        it_batch               = gt_mbh[]
*      EXCEPTIONS
*        number_range_not_found = 1
*        OTHERS                 = 2.
*    IF sy-subrc = 0.
*      gv_idoc_error = gc_false.  "Successfully created
**  Pass all batch managed material to gt_mbpsv to create
**  BATMAS03 IDoc
**  sort table gt_mbpsv by matnr.
**      SORT gt_mbh      BY matnr  exidv   "CR-8050
*      SORT gt_mbh      BY matnr  exidv old_batch_no.        "CR-8050
*      SORT gt_mbhp_tab BY nmatnr exidv.
*      SORT gt_bat_char BY matnr  vendrbatch.
*      CLEAR:  gt_mbpsv, gt_mbpsv[].
*      LOOP AT gt_mbhp_tab.
*        lv_tabix = sy-tabix.
*        READ TABLE gt_mbh WITH KEY
*                    matnr    = gt_mbhp_tab-nmatnr
**                    exidv    = gt_mbhp_tab-exidv
*                    exidv    = gt_mbhp_tab-charg
*                    old_batch_no = gt_mbhp_tab-charg        "CR-8050
*                    BINARY SEARCH.
*        IF sy-subrc = 0.
**"Successfully created NEW unique_id?
** If the batch is already created, the field in gt_mbh-oldbatch will be
** set by the above FM.  Remove those records.
*          IF NOT gt_mbhp_tab-charg IS INITIAL. "Batch managed material
*            IF gt_mbh-old_batch_flag IS INITIAL.  "New unique-id
*created
**  Fetch Plant and Storage Location from gt_temp_mat
*              SORT gt_temp_mat BY ebeln ebelp.
*              READ TABLE gt_temp_mat
*                        WITH KEY ebeln = gt_mbhp_tab-ebeln
*                                 ebelp = gt_mbhp_tab-ebelp.
*              IF sy-subrc = 0.
*                gt_mbpsv-matnr       = gt_mbh-matnr.
*                gt_mbpsv-charg       = gt_mbh-batch_num.
**  Plant and Str. Loc - take from PO line item
*                gt_mbpsv-werks       = gt_temp_mat-werks.
*                gt_mbpsv-lgort       = gt_temp_mat-lgort.
*                IF gv_parnr_ppr = gc_ppr.                   "CR-8050
**                  gt_mbpsv-vendrbatch  = gt_mbh-batch_num.
*                  gt_mbpsv-vendrbatch  = gt_mbh-old_batch_no.
*                ELSE.
*                  gt_mbpsv-vendrbatch  = gt_mbh-exidv.
*                ENDIF.
*              ENDIF.
*              APPEND  gt_mbpsv.
*              CLEAR   gt_mbpsv.
*
*            ENDIF.  "Only for new batches
**  Modify gt_mbhp_tab & gt_bat_char with newly generated
**  matnr and unique batch id.
*            gt_mbhp_tab-ncharg      = gt_mbh-batch_num.
*            gt_mbhp_tab-nexidv      = gt_mbh-batch_num.
*          ELSE.
**  Make sure charg field is empty
*            CLEAR:  gt_mbhp_tab-charg, gt_mbhp_tab-ncharg.
**  For non-batch managed material, update only handling units
*            gt_mbhp_tab-nexidv    = gt_mbh-batch_num.
*          ENDIF.
**  Modify gt_bat_char with new material and batch
*          READ TABLE gt_bat_char WITH KEY
*                              matnr      = gt_mbhp_tab-matnr
*                              vendrbatch = gt_mbhp_tab-charg.
*          IF sy-subrc = 0.
*            gv_tabix = sy-tabix.
*            gt_bat_char-matnr = gt_mbhp_tab-nmatnr.
*            gt_bat_char-charg = gt_mbhp_tab-ncharg.
*
*            MODIFY gt_bat_char
*                        INDEX gv_tabix
*                        TRANSPORTING matnr charg.
*          ENDIF.
*          MODIFY gt_mbhp_tab
*                        INDEX lv_tabix
*                        TRANSPORTING charg ncharg nexidv.
*        ENDIF.  "gt_mbh entry check
*      ENDLOOP.
*    ELSE.
**  Update error log
*
*      PERFORM sub_idoc_status_fill USING
*          c_idoc_status_error                               "status 51
*          gs_idoc_ctrl-docnum     "idoc number
*          c_error                 "status msg type
*          'ZSD_DL'                "message class
*          '000'                   "err msg
*          text-101                                          "msgv1
*          ' '                                               "msgv2
*          ' '                                               "msgv3
*          ' '                                               "msgv4
*          'PROCESS_IDOC'          "routid
*          gc_e1edl24              "seg num
*          ' '.                    "seg field
*    ENDIF.  "Unique_id function call success
*  ENDIF.  "for all materials
**  Get rest of the batch characteristics from MARA table
*  CHECK gv_idoc_error = gc_false.
*  PERFORM sub_get_bat_char.
*  PERFORM sub_pop_bat_char.
*
** start of change 06/30/2006
** Add aditional batch chars: roll width in meters,roll weight in KG's
** and Package Number
*  PERFORM add_batch_chars.
** end of change 06/30/2006

  if not gt_mbhp_tab[] is initial.

*  Move all batch managed material, Batch and Handling Unit number
*  from central table to gt_mbh table which is going to be parameter
*  table for unique-id creation function module (E03126)

    loop at gt_mbhp_tab.

*     Build table of Vendor Batch info (if BM) or HU info (if not BM)
*     for function module Z_DL_E03126_UNIT_ID_CHECK
      gt_mbh-matnr = gt_mbhp_tab-nmatnr. "SAP Material number

*     When we populated gt_mbhp_tab-charg in the beginning and updated
*     it in sub_mat_type, we know we'll have the following possibilities
*     1. If it's Paper Pro, it will be their 10-byte Vendor Batch
*     2. If it's not Paper Pro but still Batch Managed, it will be the
*        Vendor's vendor batch which may be > 10 bytes
*       (gt_mbhp_tab-charg is defined as 20 bytes)
*     3. If not Batch Managed it will be a SPACE
      if gt_mbhp_tab-charg is not initial.
        gt_mbh-exidv = gt_mbhp_tab-charg.  "Vend Batch
      else.
        gt_mbh-exidv = gt_mbhp_tab-exidv.  "HU (not Batch Managed)
      endif.

      gt_mbh-bolnr = gs_e1edl20-bolnr.                      "BCB06
      gt_mbh-vgbel = gt_mbhp_tab-ebeln.                     "PO  BCB07
*     Store the Old Vendor Batch if this is BM. I extended field
*     old_batch_no from 10 to 20 bytes since a Vendor Batch can be
*     > 10 bytes.
      gt_mbh-old_batch_no = gt_mbhp_tab-charg.              "CR-8050

*     Begin BCB09
*     Retrieve Vendor associated with PO
      read table gt_ekko into gs_ekko with key ebeln = gt_mbh-vgbel
        binary search.
      lv_tabix = sy-tabix. "index of itab for use of binary
      if sy-subrc = 0.
        gt_mbh-lifnr = gs_ekko-lifnr.
      else.
*       Retrieve the PO and Vendor and store in an itab sorted
*       by PO. This increases efficiency since we don't want to
*       keep hitting EKKO for every record if the referenced PO will
*       be the same on some or all Delivery items
        select single ebeln lifnr
          into (gs_ekko-ebeln,
                 gs_ekko-lifnr)
          from ekko
          where ebeln = gt_mbh-vgbel.
        insert gs_ekko into gt_ekko index lv_tabix.
        gt_mbh-lifnr = gs_ekko-lifnr.
      endif.
*     End BCB09

      append: gt_mbh.
      clear:  gt_mbh.
    endloop.
  endif.

  if not gt_mbh[] is initial.
*   Create unique-id for Batch i.e., validate batch #
    call function 'Z_DL_E03126_UNIT_ID_CHECK'
      tables
        it_batch               = gt_mbh[]
      exceptions
        number_range_not_found = 1
        others                 = 2.
    if sy-subrc = 0.
      gv_idoc_error = gc_false.  "Successfully created

*     Pass all batch managed material to gt_mbpsv to create BATMAS03
*     IDoc
      sort gt_mbh      by matnr  exidv.                     "CR-8050
*      SORT gt_mbh      BY matnr  exidv old_batch_no.        "CR-8050
      sort gt_mbhp_tab by nmatnr exidv.
      sort gt_bat_char by matnr  vendrbatch.
      clear:  gt_mbpsv, gt_mbpsv[].

*     Begin CR-8050
*     If we are in this section of the code then we're dealing with only
*     a group of Materials that are Batch Managed. We know that
*     gt_mbhp_tab-charg will contain the up-to-20byte Vendor Batch
*     number.  We know that gt_mbh-exidv contains the up-to-20byte
*     Vendor Batch number as well.
      loop at gt_mbhp_tab.
        lv_tabix = sy-tabix.
        read table gt_mbh with key
                    matnr    = gt_mbhp_tab-nmatnr  "SAP Material
                    exidv    = gt_mbhp_tab-charg   "Vendor Batch
                    binary search.
        if sy-subrc = 0.
*         "Successfully created NEW unique_id?
*         If the batch is already created, the field in
*         gt_mbh-old_batch_flag  will be set to 'X' by the above FM.
*         Remove those records.

*         Determine if Material is Batch Managed
          sort gt_temp_mat by matnr.
          read table gt_temp_mat
               with key matnr = gt_mbhp_tab-nmatnr
               binary search.
          if sy-subrc = 0.  "Batch managed material

            if gt_mbh-old_batch_flag is initial.  "New unique-id created
*             Fetch Plant and Storage Location from gt_temp_mat
              sort gt_temp_mat by ebeln ebelp.
              read table gt_temp_mat
                        with key ebeln = gt_mbhp_tab-ebeln
                                 ebelp = gt_mbhp_tab-ebelp.
              if sy-subrc = 0.

                gt_mbpsv-matnr       = gt_mbh-matnr.
                gt_mbpsv-charg       = gt_mbh-batch_num.
*               Plant and Str. Loc - take from PO line item
                gt_mbpsv-werks       = gt_temp_mat-werks.
                gt_mbpsv-lgort       = gt_temp_mat-lgort.

*               Set the Vendor Batch to GT_MBH-EXIDV as it will contain
*               the Vendor Batch in a BM scenario
                gt_mbpsv-vendrbatch  = gt_mbh-exidv.
              endif.
              append  gt_mbpsv.
              clear   gt_mbpsv.
            endif.  "Only for new batches

*           Modify gt_mbhp_tab & gt_bat_char with newly generated
*           matnr and unique batch id.
            gt_mbhp_tab-ncharg      = gt_mbh-batch_num.

*           Does it make sense to populate a New HU value from the new
*           Batch number in Batch Material mode? We may not be in a
*           Break Bulk scenario so this would be wrong in a Bundled
*           Roll scenario
*            gt_mbhp_tab-nexidv      = gt_mbh-batch_num.
            gt_mbhp_tab-nexidv      = space.
          else.
*           Make sure charg field is empty
            clear:  gt_mbhp_tab-charg, gt_mbhp_tab-ncharg.
*           For non-batch managed material, update only handling units
            gt_mbhp_tab-nexidv    = gt_mbh-batch_num.
          endif.  "Endif Batch Managed

*         Modify gt_bat_char with new material and batch
          read table gt_bat_char with key
                              matnr      = gt_mbhp_tab-matnr
                              vendrbatch = gt_mbhp_tab-charg.
          if sy-subrc = 0.
            gv_tabix = sy-tabix.
            gt_bat_char-matnr = gt_mbhp_tab-nmatnr.
            gt_bat_char-charg = gt_mbhp_tab-ncharg.

            modify gt_bat_char
                        index gv_tabix
                        transporting matnr charg.
            clear: gt_bat_char.  "CR-8050-FIX2
          endif.

          modify gt_mbhp_tab
                        index lv_tabix
                        transporting charg ncharg nexidv.
        endif.  "gt_mbh entry check
      endloop.
    else.

*     Update error log
      perform sub_idoc_status_fill using
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          text-101                                          "msgv1
          ' '                                               "msgv2
          ' '                                               "msgv3
          ' '                                               "msgv4
          'PROCESS_IDOC'          "routid
          gc_e1edl24              "seg num
          ' '.                    "seg field
    endif.  "Unique_id function call success
  endif.  "for all materials
*  Get rest of the batch characteristics from MARA table
  check gv_idoc_error = gc_false.
  perform sub_get_bat_char.
  perform sub_pop_bat_char.

* start of change 06/30/2006
* Add aditional batch chars: roll width in meters,roll weight in KG's
* and Package Number
  perform add_batch_chars.
* end of change 06/30/2006
  if gt_mbpsv[] is not initial.
    perform add_additional_batch_chars.
  endif.

* End CR-8050

endform.                    " sub_bat

*&---------------------------------------------------------------------*
*&      Form  sub_get_bat_char
*&---------------------------------------------------------------------*
* Get batch characteristics other than in segment E1EDL15 from MARA
*----------------------------------------------------------------------*
form sub_get_bat_char.

  data:
    begin of lt_bat_char occurs 0,
      matnr   like mara-matnr,
      cuobf   like mara-cuobf,
      zzslgrd like mara-zzslgrd,
      zzslbwt like mara-zzslbwt,
      zzslclr like mara-zzslclr,
      zzslsur like mara-zzslsur,
    end of lt_bat_char.

  if not gt_bat_char[]  is initial.
    select matnr
           cuobf
           zzslgrd
           zzslbwt
           zzslclr
           zzslsur
           into table lt_bat_char
           from mara
           for all entries in gt_bat_char
           where matnr = gt_bat_char-matnr.
  endif.

  sort lt_bat_char by matnr.

  if not lt_bat_char[] is initial.
    loop at gt_bat_char.
      gv_tabix = sy-tabix.
      read table lt_bat_char with key matnr = gt_bat_char-matnr.
      if sy-subrc = 0.
        clear:  gt_mbpsv_chars, gt_mbpsv_chars[].
        gt_mbpsv_chars-atnam   = zsdc_sales_grade.
        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslgrd.
        append gt_mbpsv_chars.
        clear  gt_mbpsv_chars.

        gt_mbpsv_chars-atnam   = zsdc_sales_basis_weight.
        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslbwt.
        append gt_mbpsv_chars.
        clear  gt_mbpsv_chars.

        gt_mbpsv_chars-atnam   = zsdc_sales_color.
        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslclr.
        append gt_mbpsv_chars.
        clear  gt_mbpsv_chars.

        gt_mbpsv_chars-atnam   = zsdc_sales_surface.
        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslsur.
        append gt_mbpsv_chars.
        clear  gt_mbpsv_chars.

        if gv_parnr_ppr = gc_ppr.
          clear gt_temp_mat.
          read table gt_temp_mat with key matnr = gt_bat_char-matnr.
          clear gt_zdl_fields_matkl.
          read table gt_zdl_fields_matkl with key
               fieldname = 'MATKL'
               lowval = gt_temp_mat-matkl.
          if sy-subrc = 0.
            gt_mbpsv_chars-atnam   = zsdc_order_link.
            gt_mbpsv_chars-atwrt   = gt_temp_mat-order_link.
            append gt_mbpsv_chars.
            clear  gt_mbpsv_chars.
          endif.
        endif.

* 06/08/2006: Get 'CORE_DIAMETER' from configuration table;
* Idoc will not contain this information
*     Retrieve SAP Characteristic Values
        refresh gt_conf_out.
        clear   gs_conf_out.
        call function 'VC_I_GET_CONFIGURATION_IBASE'
          exporting
            instance           = lt_bat_char-cuobf
            language           = sy-langu
          tables
            configuration      = gt_conf_out
          exceptions
            instance_not_found = 1
            others             = 2.

        check sy-subrc = 0.
        sort gt_conf_out by atnam.
        read table gt_conf_out into gs_conf_out
                    with key atnam = 'CORE_DIAMETER'
                    binary search.
        if sy-subrc = 0.
          gt_mbpsv_chars-atnam   = gs_conf_out-atnam.
* Format characteristics value to suit batch creation function module
          perform format_num_value using    gs_conf_out-atnam
                                   changing gs_conf_out-atwrt.

          gt_mbpsv_chars-atwrt   = gs_conf_out-atwrt.
          append gt_mbpsv_chars.
          clear  gt_mbpsv_chars.
        endif.
* End of finding 'CORE_DIAMETER' logic

* Add '# of Rolls in Pack' characteristics - 07/05/2007
        read table gt_conf_out into gs_conf_out
                    with key atnam = 'ROLLS_IN_PACKAGE'
                    binary search.
        if sy-subrc = 0.
          gt_mbpsv_chars-atnam   = gs_conf_out-atnam.
* Format characteristics value to suit batch creation function module
          perform format_num_value using    gs_conf_out-atnam
                                   changing gs_conf_out-atwrt.

          gt_mbpsv_chars-atwrt   = gs_conf_out-atwrt.
          append gt_mbpsv_chars.
          clear  gt_mbpsv_chars.
        else.
* Set to default '1.000'
          gt_mbpsv_chars-atnam   = 'ROLLS_IN_PACKAGE'.
          gt_mbpsv_chars-atwrt   = '1.000'.
          append gt_mbpsv_chars.
          clear  gt_mbpsv_chars.
        endif.
* End of fetching 'ROLLS_IN_PACKAGE'
      endif.
      append lines of gt_mbpsv_chars from 1 to gt_bat_char-chars.
      modify gt_bat_char index gv_tabix transporting chars.
      clear: gt_bat_char.  "CR-8050-FIX2
    endloop.
  endif.
endform.                    " sub_get_bat_char

*&---------------------------------------------------------------------*
*&      Form  sub_pop_bat_char
*&---------------------------------------------------------------------*
* Update bat_char internal table with all batch characteristics
* Few taken from IDoc E1EDL15 segments and rest from MARA table
*----------------------------------------------------------------------*
form sub_pop_bat_char .

  sort gt_bat_char by matnr charg.
  sort gt_mbpsv    by matnr charg.
  if not gt_bat_char[] is initial.
    loop at gt_bat_char.
      read table gt_mbpsv with key
                  matnr = gt_bat_char-matnr
                  charg = gt_bat_char-charg.
      if sy-subrc = 0.
        gv_tabix = sy-tabix.
        gt_mbpsv-chars[] = gt_bat_char-chars[].
        modify  gt_mbpsv
                index gv_tabix
                transporting chars.
      endif.
    endloop.
  endif.

endform.                    " sub_pop_bat_char
*&---------------------------------------------------------------------*
*&      Form  sub_bat_create
*&---------------------------------------------------------------------*
* This subroutine calls function module ZFM_CREATE_BATMAS03 in order to
* create batch and batch charateristics in SAP
*----------------------------------------------------------------------*
form sub_bat_create .
  data:
    ls_idoc_ctrl type  edi_dc40,
    lc_batmas    type  edilsegtyp value 'BATMAS',
    lc_batmas03  type  edilsegtyp value 'BATMAS03',
    lc_mescod    type  edi4mescod value 'VSN',
    lc_rcvprt    type  edi4rcvprt value 'US',
    lc_sndpor    type  edi4sndpor value 'TRFC'.

*  Convert gs_idoc_ctrl (type edidc) into ls_idoc_control
*  (type edi_dc40)
*  Set partner profile for the BATMAS03 for this message type
*  Change MESTYP = BATMAS and IDOCTYPE = BATMAS03.
*  Set MESCODE = this object's message type; ie., ZDL_VASN
  if not gs_idoc_ctrl is initial.
    move-corresponding gs_idoc_ctrl to ls_idoc_ctrl.
    clear: ls_idoc_ctrl-docnum.
    ls_idoc_ctrl-idoctyp  = lc_batmas03.
    ls_idoc_ctrl-mestyp   = lc_batmas.
    ls_idoc_ctrl-mescod   = lc_mescod.
    ls_idoc_ctrl-rcvprt   = lc_rcvprt.
    concatenate sy-sysid 'CLNT' sy-mandt into ls_idoc_ctrl-rcvprn.

    ls_idoc_ctrl-sndpor   = lc_sndpor.
    ls_idoc_ctrl-sndprt   = lc_rcvprt.
    ls_idoc_ctrl-sndprn   = ls_idoc_ctrl-rcvprn.
    clear ls_idoc_ctrl-mesfct.
  endif.

  refresh:  gt_bapi, gt_mbis.
  if not gt_mbpsv[] is initial.  "New Batches need to be created
    call function 'ZFM_CREATE_BATMAS03'
      exporting
        i_idoc_control  = ls_idoc_ctrl
        it_batch        = gt_mbpsv[]
      tables
        et_batch_status = gt_mbis[]
        et_return       = gt_bapi[].

*    Begin BCB11 delete
*    Clean up error processing when creating Batches fail
*    IF NOT gt_mbis[] IS INITIAL.
*
*      LOOP AT gt_mbis.
*        IF gt_mbis-status <> c_idoc_status_ok.  "failed
*          PERFORM sub_idoc_status_fill USING
*            gt_mbis-status          "status
*            gt_mbis-docnum          "idoc number
*            c_error                 "status msg type
*            'ZSD_DL'                "message class
*            '000'                   "err msg
*            text-102                                        "msgv1
*            gt_mbis-matnr                                   "msgv2
*            gt_mbis-charg                                   "msgv3
*            gt_mbis-statxt                                  "msgv4
*            'PROCESS_IDOC'          "routid
*            ' '                     "seg num
*            ' '.                    "seg field
*        ENDIF.
*      ENDLOOP.  "Status update
*
*      SORT gt_mbis BY status.
*      READ TABLE gt_mbis WITH KEY status = c_idoc_status_error
*                          BINARY SEARCH.
**     Don't create Inbound delivery IDoc if any one of the
**     batch creation failed
*      IF sy-subrc = 0.  "Any one batch creation failed
*        gv_idoc_error    = gc_true.
*      ENDIF.
*    ENDIF.

*    IF gt_bapi[] IS INITIAL.  "Error not occured
*      gv_idoc_error    = gc_false.
*    ELSE.
*      LOOP AT gt_bapi.
*        PERFORM sub_idoc_status_fill USING
*            c_idoc_status_error                             "status 51
*            gs_idoc_ctrl-docnum     "idoc number
*            gt_bapi-type            "status msg type
*            gt_bapi-id              "message class
*            gt_bapi-number          "err msg
*            gt_bapi-message_v1                              "msgv1
*            gt_bapi-message_v2                              "msgv2
*            gt_bapi-message_v3                              "msgv3
*            gt_bapi-message_v4                              "msgv4
*            'PROCESS_IDOC'          "routid
*            ' '                     "seg num
*            ' '.                    "seg field
*      ENDLOOP.
*    ENDIF.
*    End BCB11 delete

*   Begin BCB11 insert
*   Generate an Idoc Status error message if any occurred creating
*   a batch
    loop at gt_bapi.
      perform sub_idoc_status_fill using
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          gt_bapi-type            "status msg type
          gt_bapi-id              "message class
          gt_bapi-number          "err msg
          gt_bapi-message_v1                                "msgv1
          gt_bapi-message_v2                                "msgv2
          gt_bapi-message_v3                                "msgv3
          gt_bapi-message_v4                                "msgv4
          'PROCESS_IDOC'          "routid
          ' '                     "seg num
          ' '.                    "seg field
    endloop.
*   End BCB11 insert
  else.
* Update Batch details and Plant and Str.Loc details to gt_mbpsv table
  endif.
endform.                    " sub_bat_create
*&---------------------------------------------------------------------*
*&      Form  sub_mod_idoc
*&---------------------------------------------------------------------*
*  Modify the IDoc_data with changes
*----------------------------------------------------------------------*
form sub_mod_idoc.

  data:
    lv_matnr  like mara-matnr.  "For packing material

  data:
    lv_tabix   type sytabix,          " Internal table index BCB04
    lv_44count type i.                " Local counter BCB08

* For Packing material identification
  constants:
    lc_verp      like mara-mtart  value 'VERP',
    lc_pkg       like mara-vhart  value 'PKG',
    lc_hu_status like vekp-status value '0060'.

  data:
    lv_exidv   type exidv,  "HU
    lv_counter type i.

  gv_idoc_error = gc_false.

  refresh gt_hu.
  clear   gs_hu.

* Begin CR-8050 --> commenting out whole block of code and adding new
*                   logic later for readability

*  IF NOT gt_mbhp_tab[] IS INITIAL.
*    gt_mbhp_tab2[] = gt_mbhp_tab[].
*    SORT gt_mbhp_tab2 BY exidv.
*    LOOP AT gt_mbhp_tab.
**  Modify Material, Batch at E1EDL24 segment
*      IF NOT gt_mbhp_tab-24tabix IS INITIAL.
*        READ TABLE gt_idoc_data INTO gs_idoc_data
*              INDEX gt_mbhp_tab-24tabix.
*        CLEAR:  gs_e1edl24.
*        gs_e1edl24            = gs_idoc_data-sdata.
*        IF gt_mbhp_tab-matnr  = gs_e1edl24-matnr.
*          gs_e1edl24-matnr    = gt_mbhp_tab-nmatnr.
*          gs_e1edl24-charg    = gt_mbhp_tab-ncharg.
*          gs_e1edl24-posnr    = lv_counter + 1.
** Get ISO code of Sales Unit and populate it
*          SELECT SINGLE isocode INTO gs_e1edl24-vrkme FROM t006
*          WHERE msehi = gs_e1edl24-meins.
*        ENDIF.
*        gs_idoc_data-sdata    = gs_e1edl24.
*        MODIFY gt_idoc_data FROM gs_idoc_data
*                INDEX gt_mbhp_tab-24tabix
*                TRANSPORTING sdata.
*      ENDIF.
*
** Update PO line item in E1EDL43 segment
*      IF NOT gt_mbhp_tab-43tabix IS INITIAL.
*        READ TABLE gt_idoc_data INTO gs_idoc_data
*              INDEX gt_mbhp_tab-43tabix.
*        CLEAR:  gs_e1edl43.
*        gs_e1edl43            = gs_idoc_data-sdata.
*        gs_e1edl43-belnr    = gt_mbhp_tab-ebeln.
*        gs_e1edl43-posnr    = gt_mbhp_tab-ebelp.
*        gs_idoc_data-sdata    = gs_e1edl43.
*        MODIFY gt_idoc_data FROM gs_idoc_data
*                INDEX gt_mbhp_tab-43tabix
*                TRANSPORTING sdata.
*      ENDIF.
*
*
**  Modify HU at E1EDL37 segment
*      IF NOT gt_mbhp_tab-37tabix IS INITIAL.
*        READ TABLE gt_idoc_data INTO gs_idoc_data
*              INDEX gt_mbhp_tab-37tabix.
*        CLEAR:  gs_e1edl37.
*        gs_e1edl37            = gs_idoc_data-sdata.
*        IF gt_mbhp_tab-exidv  = gs_e1edl37-exidv.
*          gs_e1edl37-exidv    = gt_mbhp_tab-nexidv.
*
** Collect all HU details from E1EDL37 segment for updating
** inbound delivery with HU details
*          gs_hu-exidv = gs_e1edl37-exidv.
*          COLLECT gs_hu INTO gt_hu.
*          CLEAR   gs_hu.
*        ENDIF.
** Get Packing Materials details and populate that into VHILM and
** VHILM_KU field.
*        SELECT SINGLE matnr
*              INTO lv_matnr
*              FROM mara
*              WHERE  mtart = lc_verp
*                AND  vhart = lc_pkg.
*        IF sy-subrc = 0.
*          gv_idoc_error = gc_false.
*          gs_e1edl37-vhilm     = lv_matnr.
*          gs_e1edl37-vhilm_ku  = gt_mbhp_tab-exidv.  "Vendor Old HU #
*        ELSE.
*
*          PERFORM sub_idoc_status_fill USING
*            c_idoc_status_error                             "status 51
*              gs_idoc_ctrl-docnum     "idoc number
*              c_error                 "status msg type
*              'ZSD_DL'                "message class
*              '000'                   "err msg
*              text-e01                                      "msgv1
*              ' '                                           "msgv2
*              ' '                                           "msgv3
*              ' '                                           "msgv4
*              'PROCESS_IDOC'          "routid
*              gc_e1edl37              "seg num
*              ' '.                    "seg field
*
*        ENDIF.
*
*        CHECK gv_idoc_error = gc_false.
*        gs_idoc_data-sdata    = gs_e1edl37.
*        MODIFY gt_idoc_data FROM gs_idoc_data
*                INDEX gt_mbhp_tab-37tabix
*                TRANSPORTING sdata.
*      ENDIF.
*
**  Modify Material, Batch and HU at E1EDL44 segment
** CR-8050, loop for Bundles.
*      LOOP AT gt_mbhp_tab2 WHERE exidv = gt_mbhp_tab-exidv.
*        IF NOT gt_mbhp_tab2-24tabix IS INITIAL.
*          READ TABLE gt_idoc_data INTO gs_idoc_data
*                INDEX gt_mbhp_tab2-24tabix.
*          CLEAR:  gs_e1edl24.
*          gs_e1edl24            = gs_idoc_data-sdata.
*        ENDIF.
*        IF NOT gt_mbhp_tab2-44tabix IS INITIAL.             "CR-8050
*          READ TABLE gt_idoc_data INTO gs_idoc_data
*                INDEX gt_mbhp_tab2-44tabix.                 "CR-8050
*          CLEAR:  gs_e1edl44.
*          gs_e1edl44            = gs_idoc_data-sdata.
*          IF gt_mbhp_tab-exidv  = gs_e1edl44-exidv.
*
*            gs_e1edl44-matnr    = gt_mbhp_tab2-nmatnr.      "CR-8050
*            gs_e1edl44-charg    = gt_mbhp_tab2-ncharg.      "CR-8050
*            gs_e1edl44-exidv    = gt_mbhp_tab2-nexidv.      "CR-8050
** Update Plant, Str.Loc in the 44 segment for HU purpose
*            gs_e1edl44-werks    = gt_mbhp_tab2-werks.       "CR-8050
*            gs_e1edl44-lgort    = gt_mbhp_tab2-lgort.       "CR-8050
*
** If quantity and UOM in the E1EDL44 segment is empty,
** please get from corresponding E1EDL24 segment and populate
*            IF gs_e1edl44-vemng IS INITIAL.
*              gs_e1edl44-vemng = gs_e1edl24-lfimg.
*              gs_e1edl44-vemeh = gs_e1edl24-meins.
*            ENDIF.
*            gs_idoc_data-sdata    = gs_e1edl44.
*            MODIFY gt_idoc_data FROM gs_idoc_data
*                  INDEX gt_mbhp_tab2-44tabix                "CR-8050
*                  TRANSPORTING sdata.
*
*          ENDIF.
*        ENDIF.
*      ENDLOOP.                                              "CR-8050
**       Create New Handling Unit if doesn't exist <old HU>
*      SELECT SINGLE exidv INTO lv_exidv FROM vekp
*          WHERE exidv = gs_e1edl37-exidv AND
*                status <> lc_hu_status.       " Status '0060' deleted
*
*      IF sy-subrc NE 0.
**       Create New Handling Unit, if not exists
*        PERFORM sub_hu_create.
*      ENDIF.
*
*      CHECK gv_idoc_error = gc_false.
*      gs_idoc_data-sdata    = gs_e1edl44.
*      MODIFY gt_idoc_data FROM gs_idoc_data
*              INDEX gt_mbhp_tab-44tabix
*              TRANSPORTING sdata.
**      ENDIF.    "CR-8050
*    ENDLOOP.
*
**--> Begin delete EDVK946089
***  Delete Segment 37 and 44 because we don't need this
*** for Inbound delivery creation by 'BORES*' FM.  Infact, this FM
*** tries to post something with this segments.  All HU part is handled
*** separately.  So delete these segments.
**
**    DELETE gt_idoc_data WHERE segnam =  gc_e1edl37 OR
**                              segnam =  gc_e1edl44.
**--> End delete EDVK946089
*
*  ENDIF.


  check gt_mbhp_tab[] is not initial.

* Get Packing Materials details and populate that into VHILM and
* VHILM_KU field.
  select single matnr
        into lv_matnr
        from mara
        where  mtart = lc_verp
          and  vhart = lc_pkg.
  if sy-subrc ne 0.
    perform sub_idoc_status_fill using
      c_idoc_status_error                                   "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '000'                   "err msg
        text-e01                                            "msgv1
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'PROCESS_IDOC'          "routid
        gc_e1edl37              "seg num
        ' '.                    "seg field
  endif.

  check gv_idoc_error = gc_false.


  gt_mbhp_tab2[] = gt_mbhp_tab[].
  sort gt_mbhp_tab2 by exidv.
**<<<INSERT of changes PWADEHR CD2000003751
  select * from zdl_fields
    into table @data(lt_zdl_fields)
      where category = 'I2301'.
  if sy-subrc eq 0.
    sort lt_zdl_fields by fieldname lowval.
  endif.
  if gt_temp_mat[] is not initial.
    select * from mara
      into table @data(lt_mara)
        for all entries in @gt_temp_mat
          where matnr = @gt_temp_mat-matnr.
    if sy-subrc eq 0.
      sort lt_mara by matnr.
    endif.
  endif.
**END of changes PWADEHR CD2000003751>>>
  loop at gt_mbhp_tab.

*   Modify Material, Batch at E1EDL24 segment
    if not gt_mbhp_tab-24tabix is initial.
      read table gt_idoc_data into gs_idoc_data
            index gt_mbhp_tab-24tabix.
      clear:  gs_e1edl24.
      gs_e1edl24            = gs_idoc_data-sdata.
      if gt_mbhp_tab-matnr  = gs_e1edl24-matnr.
        gs_e1edl24-matnr    = gt_mbhp_tab-nmatnr.
        gs_e1edl24-charg    = gt_mbhp_tab-ncharg.
        gs_e1edl24-posnr    = lv_counter + 1.
*       Get ISO code of Sales Unit and populate it
        select single isocode into gs_e1edl24-vrkme from t006
        where msehi = gs_e1edl24-meins.
*<<<INSERT of changes CD2000003751 PWADEHR
        if sy-subrc ne 0 and gs_e1edl24-vrkme is initial.
          data(ls_zdl_fields_bsart) =
            value #( lt_zdl_fields[ fieldname = 'BSART'
                                    lowval = gs_tr_po_h-bsart ]
                                    optional ).
          if ls_zdl_fields_bsart-lowval is not initial.
            data(lv_bsart) = ls_zdl_fields_bsart-lowval.
          endif.
          data(ls_mara) = value #( lt_mara[ matnr = gs_e1edl24-matnr ]
                                   optional ).
          if ls_mara-matnr is not initial.
            data(ls_zdl_fields_matkl) =
              value #( lt_zdl_fields[ fieldname = 'MAT_GROUP'
                                      lowval = ls_mara-matkl ]
                                      optional ).
            if ls_zdl_fields_matkl-lowval is not initial.
              data(lv_matkl) = ls_zdl_fields_matkl-lowval.
            endif.
          endif.
          if lv_bsart is not initial and
             lv_matkl is not initial.
            gs_e1edl24-vrkme = gs_e1edl24-meins.
          endif.
          clear : lv_bsart, ls_zdl_fields_bsart, lv_matkl,
                  ls_zdl_fields_matkl, ls_mara.
        endif.
*END of changes CD2000003751 PWADEHR>>>
      endif.
      gs_idoc_data-sdata    = gs_e1edl24.
      modify gt_idoc_data from gs_idoc_data
              index gt_mbhp_tab-24tabix
              transporting sdata.
    endif.

*   Update PO line item in E1EDL43 segment
    if not gt_mbhp_tab-43tabix is initial.
      read table gt_idoc_data into gs_idoc_data
            index gt_mbhp_tab-43tabix.
      clear:  gs_e1edl43.
      gs_e1edl43            = gs_idoc_data-sdata.
      gs_e1edl43-belnr    = gt_mbhp_tab-ebeln.
      gs_e1edl43-posnr    = gt_mbhp_tab-ebelp.
      gs_idoc_data-sdata    = gs_e1edl43.
      modify gt_idoc_data from gs_idoc_data
              index gt_mbhp_tab-43tabix
              transporting sdata.
    endif.

  endloop.

* Update HU Header and HU Item data with the new SAP HU
* Number if applicable.
  clear: lv_44count,
         gs_l37,
         gt_l37,
         gs_l44,
         gt_l44.

  loop at gt_idoc_data
       into gs_idoc_data
       where   docnum  =  gs_idoc_ctrl-docnum
         and ( segnam  =  gc_e1edl37 or
               segnam  =  gc_e1edl44 ).

    lv_tabix      =  sy-tabix. "store index of doc record

    case gs_idoc_data-segnam.
      when gc_e1edl37.

        gs_e1edl37 = gs_idoc_data-sdata.

        gs_e1edl37-vhilm_ku = gs_e1edl37-exidv. "store original HU
        gs_e1edl37-vhilm    = lv_matnr.        "store packaging material

*       Find matching record on work table used to generate new unit id
*       number. If batch managed scenario, the gt_mbh-exidv is the
*       Vendor Batch Number. If not batch managed, it is the HU number
        read table gt_mbh with key exidv = gs_e1edl37-exidv.
        if sy-subrc = 0.
*         If a new unit id was generated for either the HU (non batch
*         managed) or the Batch (batch managed scenario) then overlay
*         the HU with the newly generated unit id.
          if gs_e1edl37-exidv ne gt_mbh-batch_num.
            gs_e1edl37-exidv = gt_mbh-batch_num.
          endif.
        endif.

*       Update segment data
        gs_idoc_data-sdata = gs_e1edl37.
        modify gt_idoc_data from gs_idoc_data index lv_tabix
          transporting sdata.

*       Build table of HU's relevant to this ASN whether the HU exists
*       or not.
        gs_hu-exidv = gs_e1edl37-exidv.
        append gs_hu to gt_hu.

*       Build HU Header data table for use when generating HU's
        move-corresponding gs_e1edl37 to gs_l37.
        append gs_l37 to gt_l37.


      when gc_e1edl44.

        lv_44count  = lv_44count + 1."ctr relates to oth work tables

        gs_e1edl44 = gs_idoc_data-sdata.

*       Find matching record on work table used to generate new unit id
*       number. If batch managed scenario, the gt_mbh-exidv is the
*       Vendor Batch Number. If not batch managed, it is the HU number.
*       The retrieved value will be the new HU Number
        read table gt_mbh with key exidv = gs_e1edl44-exidv.
        if sy-subrc = 0.
*         If a new unit id was generated for either the HU (non batch
*         managed) or the Batch (batch managed scenario) then overlay
*         the HU with the newly generated unit id.
          if gs_e1edl44-exidv ne gt_mbh-batch_num.
            gs_e1edl44-exidv = gt_mbh-batch_num.
          endif.
        endif.

*       Determine the new SAP Batch Number if applicable.
*       gt_mbhp_tab-charg is a 20-byte field containing the Vendor
*       Batch.  gt_mbhp_tab-ncharg is the new SAP Batch (or the same
*       one passed in on the idoc if it meets the necessary criteria).
*       Retrieve other SAP values and overlay existing junk
*       Begin CR-8050-FIX1
*        IF gs_e1edl44-charg IS NOT INITIAL.
*          READ TABLE gt_mbhp_tab WITH KEY 44tabix = lv_tabix.
*          IF sy-subrc = 0.
*            gs_e1edl44-matnr = gt_mbhp_tab-nmatnr. "SAP Material
*            gs_e1edl44-charg = gt_mbhp_tab-ncharg. "SAP Batch
*            gs_e1edl44-werks = gt_mbhp_tab-werks.  "SAP Plant
*          ENDIF.
*        ENDIF.
        read table gt_mbhp_tab with key 44tabix = lv_tabix.
        if sy-subrc = 0.
          gs_e1edl44-matnr = gt_mbhp_tab-nmatnr. "SAP Material
          gs_e1edl44-werks = gt_mbhp_tab-werks.  "SAP Plant
          gs_e1edl44-charg = gt_mbhp_tab-ncharg. "SAP Batch

*         If quantity and UOM in the E1EDL44 segment is empty,
*         please get from corresponding E1EDL24 segment and populate
          if gs_e1edl44-vemng is initial.

            read table gt_idoc_data into gs_idoc_data
                  index gt_mbhp_tab-24tabix.
            if sy-subrc = 0.
              clear:  gs_e1edl24.
              gs_e1edl24            = gs_idoc_data-sdata.
              gs_e1edl44-vemng = gs_e1edl24-lfimg.
              gs_e1edl44-vemeh = gs_e1edl24-meins.
            endif.
          endif.

        endif.
*       End CR-8050-FIX1

*       Update segment data
        gs_idoc_data-sdata = gs_e1edl44.
        modify gt_idoc_data from gs_idoc_data index lv_tabix
          transporting sdata.

*       Build HU Item data table for use when generating HU's
        move-corresponding gs_e1edl44 to gs_l44.
        append gs_l44 to gt_l44.

    endcase.
  endloop.

* Create New Handling Unit(s) if doesn't exist
  perform hu_create.

* End CR-8050

endform.                    " sub_mod_idoc
*&---------------------------------------------------------------------*
*&      Form  sub_idoc_status_fill
*&---------------------------------------------------------------------*
*  Update IDoc Status Record
*----------------------------------------------------------------------*
form sub_idoc_status_fill  using    p_status "idoc status
                                p_docnum "idoc nmber
                                p_msgty  "message type
                                p_msgid  "message class
                                p_msgno  "message number
                                p_msgv1  "message variable 1
                                p_msgv2  "message variable 2
                                p_msgv3  "message variable 3
                                p_msgv4  "message variable 4
                                p_routid "subroutine or func mod name
                                p_segnum "segment number
                                p_segfld."segment field name

  clear: gs_idoc_status.
  gs_idoc_status-status = p_status.
  gs_idoc_status-docnum = p_docnum.
  gs_idoc_status-msgty  = p_msgty.
  gs_idoc_status-msgid  = p_msgid.
  gs_idoc_status-msgno  = p_msgno.
  gs_idoc_status-msgv1  = p_msgv1.
  gs_idoc_status-msgv2  = p_msgv2.
  gs_idoc_status-msgv3  = p_msgv3.
  gs_idoc_status-msgv4  = p_msgv4.
  gs_idoc_status-routid = p_routid.
  gs_idoc_status-segnum = p_segnum.
  gs_idoc_status-segfld = p_segfld.
*
  gs_idoc_status-uname  = sy-uname.
  gs_idoc_status-repid  = sy-repid.
  append gs_idoc_status to gt_idoc_status.

* If any idoc errors occur then set flag
  if p_msgty = c_error.
    gv_idoc_error = gc_true.

    if gv_usd_created = gc_false.  "CR-8050-FIX3
      gv_usd_created = gc_true.    "CR-8050-FIX3
      perform generate_usd_ticket using gs_idoc_status.     " CR5297
    endif.                         "CR-8050-FIX3

  endif.

endform.                    " sub_idoc_status_fill

*&---------------------------------------------------------------------*
*&      Form  generate_usd_ticket " CR5297
*&---------------------------------------------------------------------*
*** NOTE: ANY time and idoc 51 error is generated, this subroutine
*     should only be executed once so we should not run the risk of
*     generating multiple USD tickets
*----------------------------------------------------------------------*
* 10/26/06  Randall Wainwright EDVK949782  CR#5297                     *
*                                                                      *
*                          Generate AHD tickets with a priority based  *
*                          on values populated in the ZSP_VALUE table  *
*                          where the PRGMID='ZDL_I02301_USD_PRIORITY'  *
*                          for specific plants. The AHD ticket must be *
*                          configured with inventory code 'I2301' in   *
*                          a system where USD tickets may be generated *
*                          (connected to WebMethods) for this code to  *
*                          work. This change is located:               *
*                          Under Include: LZSD_DL_VENASNF01            *
*                          Subroutine:    generate_usd_ticket          *
*----------------------------------------------------------------------*
form generate_usd_ticket using lpx_idoc_status like bdidocstat. " CR5297

  constants: c_i02301_pgrmid like zsp_value-pgrmid
                  value 'ZDL_I02301_USD_PRIORITY',
             c_ahd_invcode   type  zzinv value 'I2301'.

  data: lt_zsp          type standard table of zsp_value,
        ls_zsp          type zsp_value,
        lv_priority     type c,
        lv_omd_ind      type c,
        l_sys_mess(200),
        l_ahd_text      type zchar400, " AHD ticket body
        l_plant         type werks_d.

***Begin of changes pragup1 06/15/2012 CHG136783
  check gv_chk_multiple_usd is initial.
*  CHECK gv_trades_asn1 = gc_true.
***End of changes pragup1 06/15/2012 CHG136783



* Begin BCB10 insert
* Do not generate a USD ticket if this is Trades ASN1 and one of the
* specified error conditions occurred. If one of the specified error
* conditions did occur, then Workflow will be triggered INSTEAD of
* the generation of a USD ticket.
  check gv_trigger_wf = gc_false.
* End BCB10 insert

  clear lv_priority.

  clear l_plant.

* Use the plant from the WERKS field.
  sort gt_tr_po_i by werks descending.
  clear gs_tr_po_i.
  read table gt_tr_po_i
        into gs_tr_po_i index 1.
  if   not gs_tr_po_i-werks is initial.
    l_plant = gs_tr_po_i-werks.
  endif.

* If the plant is missing, use the Purch org for PO1 instead
  if l_plant is initial.
    sort gt_tr_po_i by ekorg descending.
    clear gs_tr_po_i.
    read table gt_tr_po_i
          into gs_tr_po_i index 1.
    if not gs_tr_po_i-ekorg is initial.
      l_plant = gs_tr_po_i-ekorg.
    endif.
  endif.

* If a plant was identified...
  if not l_plant is initial.

* retrieve all relevant, populated priority records
    select *
      from zsp_value
      into table lt_zsp
      where pgrmid = c_i02301_pgrmid.
    if sy-subrc = 0.
      sort lt_zsp by fieldvalue.
      delete lt_zsp where fieldvalue is initial.
    endif.

* Determine if there is a plant-specific record
    clear ls_zsp.
    sort lt_zsp by fieldname.
    read table lt_zsp
          into ls_zsp
      with key fieldname = l_plant.
    if sy-subrc = 0.
      lv_priority = ls_zsp-fieldvalue.
    else.
* Retrieve omd plant record to determine the priority indicator
      clear lv_omd_ind.
      select single omd_ind
        into lv_omd_ind
        from zplant
       where werks = l_plant.
      if sy-subrc = 0.
* Retrieve Priority from ZSP_VALUE
        clear ls_zsp.
        read table lt_zsp
              into ls_zsp
          with key fieldname = lv_omd_ind.
        if sy-subrc = 0.
          lv_priority = ls_zsp-fieldvalue.
        endif.
      endif.
    endif.
  endif.

* If the priority is still blank...
  if lv_priority is initial.
* Default to priority 2
    lv_priority = '2'.
  endif.

* Write the IDoc Message into a 400 char. AHD ticket format:
  clear l_sys_mess.
  message id lpx_idoc_status-msgid
        type lpx_idoc_status-msgty
      number lpx_idoc_status-msgno
        with lpx_idoc_status-msgv1
             lpx_idoc_status-msgv2
             lpx_idoc_status-msgv3
             lpx_idoc_status-msgv4
        into l_sys_mess.
  clear l_ahd_text.
  concatenate gs_idoc_ctrl-mestyp                      "<<mc001 03/2007
              ' IDoc #:'
              lpx_idoc_status-docnum
              ' returned the following error: '
              l_sys_mess
         into l_ahd_text.

* Generate the AHD Ticket
  call function 'Z_GEN_AHD_TICKET'
    exporting
      if_inventory_code      = c_ahd_invcode
      if_priority            = lv_priority
      if_severity            = '2'
      if_text                = l_ahd_text
    exceptions
      invalid_inv_code       = 1
      ahdgrp_not_found       = 2
      webmd_connection_error = 3
      others                 = 4.
  if sy-subrc <> 0.
* Do nothing
  endif.

endform. "GENERATE_USD_TICKET

*&---------------------------------------------------------------------*
*&      Form  check_delivery_lock
*&---------------------------------------------------------------------*
* Ensure that the inbound is locked by anybody, because we are going to
* change inbound delivery with HU details
*----------------------------------------------------------------------*
form check_delivery_lock .

  data: lv_subrc type sysubrc value 4.

* Attempt to lock the delivery to make sure it is not already locked
  do 30 times.
    call function 'ENQUEUE_EVVBLKE'
      exporting
        mode_likp      = 'E'
        mandt          = sy-mandt
        vbeln          = gv_inb_vbeln  "inb delivery nu
        _scope         = '2'
      exceptions
        foreign_lock   = 1
        system_failure = 2
        others         = 3.
    if sy-subrc = 0.
      lv_subrc = sy-subrc.
      exit.
    else.
      wait up to 3 seconds.
    endif.
  enddo.

  if lv_subrc = 0.
*   Unlock the delivery
    call function 'DEQUEUE_EVVBLKE'
      exporting
        mode_likp = 'E'
        mandt     = sy-mandt
        vbeln     = gv_inb_vbeln "inbound delivery num
        _scope    = '3'.
  else.
*   Generate an error
    perform sub_idoc_status_fill using
        c_idoc_status_error                                 "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '119'                   "err msg
        gv_inb_vbeln                                        "msgv1
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'CHECK_DELIVERY_LOCK'          "routid
        ' '                     "seg num
        ' '.                    "seg field
  endif.

endform.                    " check_delivery_lock
*&---------------------------------------------------------------------*
*&      Form  assign_hu_to_delivery
*&---------------------------------------------------------------------*
* Update Inbound delivery with HU details
*----------------------------------------------------------------------*
form assign_hu_to_delivery .

* >>Begin of change by rsured1 for CMS 28753
* add Error Importing and exporting parameters
* as the below FM do not have exeptions
* which might cause an when PO is locked during this update
*to delivery(assign HU)
  data: lv_error_any.
*>> End of change by rsured1 for CMS 28753

* Make sure HU's exist before attempting to assign to Delivery
  check not gt_hu[] is initial.

* For any HU's not already assigned to the inbound delivery,
* format HU external id's into table
  clear: gt_handling_units[].
  loop at gt_assign into gs_assign where vpobjkey ne gv_inb_vbeln.
    clear: gs_handling_units.
    gs_handling_units-top_hu_external = gs_assign-exidv.
    append gs_handling_units to gt_handling_units.
  endloop.

* If HU's need assigning to the inbound then do so
  if not gt_handling_units[] is initial.

*   Format header structure with Inbound Delivery Number
    clear: gs_vbkok.
    gs_vbkok-vbeln_vl = gv_inb_vbeln.

*>>Begin of change by rsured1 for CMS 28753
    clear: lv_error_any.
*>>End of change by rsured1 for CMS 28753

*   Assign HU to the Delivery since not currently assigned
    clear: gs_prot, gt_prot[].
    call function 'WS_DELIVERY_UPDATE'
      exporting
        vbkok_wa                 = gs_vbkok
        commit                   = 'X'
        delivery                 = gv_inb_vbeln
        if_database_update       = '1' "check & save
        if_error_messages_send_0 = space "'X' "by rsured1 for CMS 28753
      importing
     ef_error_any_0           = lv_error_any  " by rsured1 for CMS 28753
   tables
     prot                     = gt_prot
     it_handling_units        = gt_handling_units.
* Begin of change by rsured1 for CMS 28753
* Check if any of the Flags are set to "X" then Error out that HU is not assigned
* Inbound Delivery. So that when re-processing is done there will be no
* new Inbound Delivery will be created.
    if lv_error_any  is not initial .
* End of Change  by rsured1 for CMS 28753
      if not gt_prot[] is initial.
*     Write error messages from function
        loop at gt_prot into gs_prot where msgty = c_error.
          perform sub_idoc_status_fill using
                        c_idoc_status_error                   "status 51
                        gs_idoc_ctrl-docnum        "idoc number
                        gs_prot-msgty              "status msg type
                        gs_prot-msgid              "message id
                        gs_prot-msgno              "msgno
                        gs_prot-msgv1                         "msgv1
                        gs_prot-msgv2                         "msgv2
                        gs_prot-msgv3                         "msgv3
                        gs_prot-msgv4                         "msgv4
                        'ASSIGN_HU_TO_DELIVERY' "routid
                        ' '                   "seg num
                        ' '.                  "seg field
*>>Begin of change by rsured1 for CMS 28753
*add another "51" error message with delivery no
          perform sub_idoc_status_fill using
                       c_idoc_status_error      "status 51
                       gs_idoc_ctrl-docnum      "idoc number
                       c_error                  "status msg type
                       'ZSD_DL'                 " message class
                       '701'                    " err msg
                       gv_inb_vbeln             " msgv1
                       ' '                      "msgv2
                       ' '                      "msgv3
                       ' '                      "msgv4
                       ' '                      " routid
                       ' '                      "seg num
                       ' '.                     "seg field
*>>End of change by rsured1 for CMS 28753

        endloop.
*     If any errors occurred on the HU assignment then error
        if gv_idoc_error = gc_true.
          return.
        endif.
      endif.
    endif."by rsured1 for CMS 28753

*     If this is a reprocess of the idoc (already existed) then the
*     Assignment of the HU's probably failed on the previous run for
*     some reason. If that happened we had issued a '51' message but
*     NOW need to generate a successful '53' message, like the one
*     BORES_IDOC_INPUT_DESADV1 generates when the inbound delivery is
*     initially created, now that the rest of the HU's were successfully
*     assigned to the inbound delivery.
*     If this is NOT a reprocess of the idoc (gv_inb_vbeln = false) then
*     this is the first time the idoc is executed and there is no need
*     to generate the '53' message since we'll have done it when
*     BORES_IDOC_INPUT_DESADV1 runs prior to this subroutine.
    if gv_inb_vbeln_exists = gc_true.
      perform sub_idoc_status_fill using
                    c_idoc_status_ok                        "status 53
                    gs_idoc_ctrl-docnum "idoc number
                    c_smsg              "status msg type
                    'ME'                "message class
                    '780'               "HU's successfully processed
                    '0001'              "msgv1 - 0001 inb deliv creatd
                    gv_inb_vbeln        "msgv2 - beg range of ibd's
                    gv_inb_vbeln        "msgv3 - end range of ibd's
                    ' '                                     "msgv4
                    ' '                 "routid
                    ' '                 "seg num
                    ' '.                "seg field
    endif.

  else. "No HU's to assign

*   If Inbound Delivery had already existed and all HU's were already
*   assigned then generate an error that this is a duplicate ASN
    if gv_inb_vbeln_exists = gc_true.
*     Begin BCB10 insert
*     For all ZDL_VASN idocs, if this is a duplicate ASN then archive
*     the idoc (status 68) instead of setting it to a 51.
      if gs_idoc_ctrl-mestyp = 'ZDL_VASN'.
        perform sub_idoc_status_fill using
                      c_idoc_status_delete                  "status 68
                      gs_idoc_ctrl-docnum "idoc number
                      c_error              "status msg type
                      'ZSD_DL'             "message class
                      '194'               "msgno
                      ' '              "msgv1 - 0001 inb deliv creatd
                      ' '        "msgv2 - beg range of ibd's
                      ' '        "msgv3 - end range of ibd's
                      ' '                                   "msgv4
                      ' '                 "routid
                      ' '                 "seg num
                      ' '.                "seg field
      else.
*     End BCB10 insert
        perform sub_idoc_status_fill using
                      c_idoc_status_error                   "status 51
                      gs_idoc_ctrl-docnum "idoc number
                      c_error              "status msg type
                      'ZSD_DL'             "message class
                      '194'               "msgno
                      ' '              "msgv1 - 0001 inb deliv creatd
                      ' '        "msgv2 - beg range of ibd's
                      ' '        "msgv3 - end range of ibd's
                      ' '                                   "msgv4
                      ' '                 "routid
                      ' '                 "seg num
                      ' '.                "seg field
      endif.
    endif. "BCB10 insert

  endif.

endform.                    " assign_hu_to_delivery
*&---------------------------------------------------------------------*
*&      Form  sub_inb_del_exists
*&---------------------------------------------------------------------*
* Check Inbound delivery already exists
*----------------------------------------------------------------------*
form sub_inb_del_exists .

* Retrieve Outbound Delivery number
  loop at gt_idoc_data into gs_idoc_data
    where segnam  = gc_e1edl20.
    gs_e1edl20 = gs_idoc_data-sdata.
  endloop.

  if not gs_e1edl20-bolnr is initial.

*   Retrieve the associcated inbound delivery number using
*   outbound delivery number
    clear: gv_inb_vbeln.
    select single vbeln into gv_inb_vbeln
      from likp
      where bolnr = gs_e1edl20-bolnr. "Bill of Lading No.
  else.  "BOL is empty
    perform sub_idoc_status_fill using
    c_idoc_status_error                                     "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '000'                   "err msg
        text-105                                            "msgv1
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'PROCESS_IDOC'          "routid
        gc_e1edl20              "seg num
        ' '.                    "seg field
    exit.

  endif.
endform.                    " sub_inb_del_exists
*&---------------------------------------------------------------------*
*&      Form  sub_hu_create
*&---------------------------------------------------------------------*
* Collect all details required to create HU and create HU.
*----------------------------------------------------------------------*
form sub_hu_create .

  constants:

*   Type of Handling-unit Item Content
    lc_material_item    type  velin        value '1',

*   HU Status
    lc_in_warehouse     type  hu_st_init   value 'C',
    lc_not_in_warehouse type hu_st_init value 'B'.


* Populate Header structure
  clear: gs_headerproposal.
  gs_headerproposal-hu_status_init = lc_not_in_warehouse.  "B
  gs_headerproposal-pack_mat       = gs_e1edl37-vhilm. "HU packng matl
  gs_headerproposal-content        = gs_e1edl37-vhilm_ku. "Vendor ID

  gs_headerproposal-hu_exid        = gs_e1edl37-exidv. "HU
  gs_headerproposal-plant          = gs_e1edl44-werks. "HU plant
*  04/25/2006 - Start of change
*  gs_headerproposal-stge_loc       = gs_e1edl44-lgort. "HU sloc
*  04/25/2006 - End of change
* Populate item table
  clear: gs_itemsproposal, gt_itemsproposal[].
* CR-8050 With Bundled Packages, we will have multiple items per
* bundle. We need to loop at repeated items per HU and populate
* the internal table accoringly.
  loop at gt_mbhp_tab2 where exidv = gt_mbhp_tab-exidv.
    gs_itemsproposal-hu_item_type      = lc_material_item.
    if not gt_mbhp_tab2-44tabix is initial.
      read table gt_idoc_data into gs_idoc_data
           index gt_mbhp_tab2-44tabix.
      clear:  gs_e1edl44.
      gs_e1edl44            = gs_idoc_data-sdata.
    endif.
    gs_itemsproposal-pack_qty          = gs_e1edl44-vemng.

* Retrieve SAP uom using ISO Code uom stored in L44 from current HU
    clear: gs_itemsproposal-base_unit_qty.
    select single msehi into gs_itemsproposal-base_unit_qty from t006
      where isocode = gs_e1edl44-vemeh.

    if sy-subrc <> 0.
      gs_itemsproposal-base_unit_qty = gs_e1edl44-vemeh.
    endif.

    gs_itemsproposal-material          = gs_e1edl44-matnr.
*  gs_itemsproposal-batch             = gs_e1edl44-charg.
    gs_itemsproposal-batch             = gt_mbhp_tab2-ncharg.
    gs_itemsproposal-plant             = gs_e1edl44-werks.
*  04/25/2006 - Start of change
*  gs_itemsproposal-stge_loc          = gs_e1edl44-lgort.
*  04/25/2006 - End of change
    append gs_itemsproposal  to  gt_itemsproposal.
  endloop.
* Create the new Handling Unit
  clear gt_return[]. "refresh error table
  call function 'BAPI_HU_CREATE'
    exporting
      headerproposal = gs_headerproposal  "Hdr data
    tables
      itemsproposal  = gt_itemsproposal   "Itm data
      return         = gt_return.
  if not gt_return[] is initial.
*   Write all Bapi return messages to idoc status table
    loop at gt_return into gs_return.
*
      perform sub_idoc_status_fill using
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          gs_return-id           "message class
          gs_return-number            "err msg
          gs_return-message_v1                              "msgv1
          gs_return-message_v2                              "msgv2
          gs_return-message_v3                              "msgv3
          gs_return-message_v4                              "msgv4
          'BAPI_HU_CREATE'                                    "routid
          gs_idoc_data-segnum                                 "seg num
          ' '.                    "seg field
    endloop.
    return. "leave subroutine
  endif.

* Commit data to database
  clear: gs_return.
  call function 'BAPI_TRANSACTION_COMMIT'
    exporting
      wait   = 'X'      "wait for update
    importing
      return = gs_return.
  if not gs_return is initial.
*   Write all Bapi return messages to idoc status table
    perform sub_idoc_status_fill using
        c_idoc_status_error                                 "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        gs_return-id           "message class
        gs_return-number            "err msg
        gs_return-message_v1                                "msgv1
        gs_return-message_v2                                "msgv2
        gs_return-message_v3                                "msgv3
        gs_return-message_v4                                "msgv4
        'BAPI_HU_CREATE'                                    "routid
        gs_idoc_data-segnum                                 "seg num
        ' '.                    "seg field
    return. "leave subroutine
  endif.

endform.                    " sub_hu_create
*&---------------------------------------------------------------------*
*&      Form  format_value
*&---------------------------------------------------------------------*
*  Format Batch characteristics into char format
*----------------------------------------------------------------------*
*      <-> cv_ATWRT  characteristic value
*----------------------------------------------------------------------*
form format_value  changing cv_atwrt like conf_out-atwrt.

  data: lv_atwrt1 type atwrt,
        lv_atwrt2 type atwrt,
        lv_atwrt3 type atwrt.

  clear:  lv_atwrt1,  lv_atwrt2.

*     Remove unit of measure if exists ( ie 4.00 IN )
  split cv_atwrt at ' ' into lv_atwrt1 lv_atwrt2.

*     Remove commas if exist
  if lv_atwrt1 ca ','.
    clear: lv_atwrt2, lv_atwrt3.
    split lv_atwrt1 at ',' into lv_atwrt2 lv_atwrt3.
    clear lv_atwrt1.
    concatenate lv_atwrt2 lv_atwrt3 into lv_atwrt1.
  endif.

*     Remove decimal point
  if lv_atwrt1 ca '.'.
    clear: lv_atwrt2, lv_atwrt3.
    split lv_atwrt1 at '.' into lv_atwrt2 lv_atwrt3.
    if gv_parnr_ppr = gc_ppr.                               "CR-8050
* Ignore the decimal places for Paperpro.
      lv_atwrt1 = lv_atwrt2.
    else.
      clear lv_atwrt1.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|START
      while strlen( lv_atwrt3 ) lt 5.
        concatenate lv_atwrt3 '0' into lv_atwrt3.
      endwhile.
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102017|END

      concatenate lv_atwrt2 lv_atwrt3 into lv_atwrt1.
    endif.
  endif.

*     Right justify value and pad left with 0's
*      if gs_conf_out-atnam = 'ROLL_WIDTH'.
  while strlen( lv_atwrt1 ) lt 8.
    concatenate '0' lv_atwrt1 into lv_atwrt1.
  endwhile.

  cv_atwrt = lv_atwrt1.

endform.                    " format_value
*&---------------------------------------------------------------------*
*&      Form  format_num_value
*&---------------------------------------------------------------------*
* Convert the ROLL_WIDTH characteristics in the IDoc into SAP std.
* format i.e., 3.5 char format
*----------------------------------------------------------------------*
*      -->uv_atnam  characteristics name
*      <->cv_aTWRT  characteristics value
*----------------------------------------------------------------------*
form format_num_value     using    uv_atnam
                          changing cv_atwrt.

  data:
    lv_anzst  type i,
    lv_anzdz  type i,
    lv_atwrt1 type atwrt,
    lv_atwrt2 type atwrt.

  select anzst  anzdz
         into (lv_anzst,  lv_anzdz)
         from cabn
         up to 1 rows
         where atnam = uv_atnam.
  endselect.

*     Remove unit of measure if exists ( ie 4.00 IN )
  split cv_atwrt at ' ' into lv_atwrt1 lv_atwrt2.

  clear lv_atwrt2.

*         Remove all commas from numeric values being fed back in since
*         this will cause an error.
  replace all occurrences of ',' in
    lv_atwrt1 with space.
  condense lv_atwrt1 no-gaps.


* Split integer and decimal part
  split lv_atwrt1 at '.' into lv_atwrt1 lv_atwrt2.

* Fill up trailing zeros if it is less than ANZDZ (no. of decimal char)
* in the decimal part. 0's need to be added to the END of the decimal
* portion.
  while strlen( lv_atwrt2 ) lt lv_anzdz.
    concatenate lv_atwrt2 '0' into lv_atwrt2.
  endwhile.

* Find only integer part
  lv_anzst = lv_anzst - lv_anzdz.

* Fill up leading zeros in the integer part if it is less than ANZST
* (No. of characters)
  while strlen( lv_atwrt1 ) lt lv_anzst.
    concatenate '0' lv_atwrt1 into lv_atwrt1.
  endwhile.

  if not lv_anzst is initial.
* Fix the numeric format by concatenating integer and decimal part
    concatenate lv_atwrt1 lv_atwrt2 into cv_atwrt separated by '.'.
  else.
* Just fill the integer part
    cv_atwrt = lv_atwrt1.
  endif.

  condense cv_atwrt no-gaps.


endform.                    " format_num_value
*&---------------------------------------------------------------------*
*&      Form  sub_idoc_status
*&---------------------------------------------------------------------*
*  Update Idoc status with error message
*----------------------------------------------------------------------*
*  -->  tt_status  Idoc status record
*  <--  uv_docnum  Idoc Number
*----------------------------------------------------------------------*
form sub_upd_idoc_status tables tt_status structure bdidocstat
                         using  uv_docnum type      edi_docnum.

* IDOC control record
  data: ls_ctrl    like edidc.

* Open IDOC for process
  call function 'EDI_DOCUMENT_OPEN_FOR_PROCESS'
    exporting
      document_number          = uv_docnum
    importing
      idoc_control             = ls_ctrl
    exceptions
      document_foreign_lock    = 1
      document_not_exist       = 2
      document_number_invalid  = 3
      document_is_already_open = 4.

  if sy-subrc = 0 or sy-subrc = 4.

* Convert BDIDOCSTAT into EDI_DS structure
    perform sub_conv_form_bdiocstat_edids tables  tt_status.

* Update status record
    call function 'EDI_STATUS_ADD_BLOCK'
      exporting
        document_number           = uv_docnum
      importing
        idoc_control              = ls_ctrl
      tables
        idoc_status_records       = gt_edids[]
      exceptions
        document_number_invalid   = 1
        idoc_status_records_empty = 2
        other_fields_invalid      = 3
        status_invalid            = 4.

    check sy-subrc = 0.
* Close IDOC
    call function 'EDI_DOCUMENT_CLOSE_PROCESS'
      exporting
        document_number = uv_docnum
      importing
        idoc_control    = ls_ctrl.
  endif.

endform.                    " sub_idoc_status
*&---------------------------------------------------------------------*
*&      Form  sub_conv_form_bdiocstat_edids
*&---------------------------------------------------------------------*
*  Convert status record of structure BDIOCSTAT INTO EDI_DS
*----------------------------------------------------------------------*
*  TT_STATUS  in BDIDOCSTAT structure
*  TT_EDIDS   in EDI_DS structure
*----------------------------------------------------------------------*
form sub_conv_form_bdiocstat_edids
                       tables   tt_status structure bdidocstat.
  refresh gt_edids.

  loop at tt_status.
    gt_edids-docnum = tt_status-docnum.
    gt_edids-status = tt_status-status.
    gt_edids-statyp = tt_status-msgty.
    gt_edids-stamid = tt_status-msgid.
    gt_edids-stamno = tt_status-msgno.
    gt_edids-segnum = tt_status-segnum.
    gt_edids-segfld = tt_status-segfld.
    gt_edids-stapa1 = tt_status-msgv1.
    gt_edids-stapa2 = tt_status-msgv2.
    gt_edids-stapa3 = tt_status-msgv3.
    gt_edids-stapa4 = tt_status-msgv4.
    gt_edids-logdat = sy-datum.
    gt_edids-logtim = sy-uzeit.
    gt_edids-uname  = sy-uname.

    append gt_edids.
    clear  gt_edids.
  endloop.

endform.                    " sub_conv_form_bdiocstat_edids
*&---------------------------------------------------------------------*
*&      Form  CHECK_UPDATE_NONROLL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
form check_update_nonroll .

  data: ls_temp_mat like gt_temp_mat.
  clear ls_temp_mat.

*****>>> Commented out as per Showry 08222008 TPR 01908
*  IF gt_temp_mat-unit_code = 'C' or
*     gt_temp_mat-unit_code = 'D' or
*     gt_temp_mat-unit_code = 'S'.
** If the Incoming Batch has characteristic Equipment Numer,
** over write that with N.A. The value is taken from the 5th char of
** the characteristic value. This is true only for non roll products.
*    read table gt_mbpsv_chars with key
*               atnam = ZSDC_EQUIPMENT_NUMBER
*               BINARY SEARCH.
*    IF sy-subrc = 0.
*      if gt_mbpsv_chars-atwrt <> 'N.A.'.
*         gt_mbpsv_chars-atwrt = 'N.A.'.
*        modify gt_mbpsv_chars TRANSPORTING atwrt
*               where atnam = ZSDC_EQUIPMENT_NUMBER.
*        gt_bat_char-chars[] = gt_mbpsv_chars[].
*        MODIFY gt_bat_char
*              INDEX gv_tabix
*              TRANSPORTING chars.
*      endif.
*    endif.
*  endif.
*****>>> Commented out as per Showry 08222008 TPR 01908
  if gt_mbhp_tab-ebelp is initial.
    clear gt_temp_mat.
    read table gt_temp_mat
      with key ebeln = gt_mbhp_tab-ebeln     "PO
               matnr = gt_mbhp_tab-matnr.  "Material
    if sy-subrc = 0.
* Non Roll products can not have the same material on more than on
* one line item on the same PO. Above, we have read one line item for
* the PO and Material. If there is any line item other than the above
* read line item, IDOC should fail.
      loop at gt_temp_mat into ls_temp_mat
           where ebeln = gt_mbhp_tab-ebeln
           and   matnr = gt_mbhp_tab-matnr
           and   ebelp <> gt_temp_mat-ebelp.
*       SAP Material not derived: PO & AFPA & Roll Width &
        perform sub_idoc_status_fill using
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum      "idoc number
          c_error                  "status msg type
          'ZSD_DL'                 " message class
          '315'                    " err msg
          gt_mbhp_tab-matnr                                 " msgv1
          gt_mbhp_tab-ebeln                                 "msgv2
          gt_temp_mat-ebelp                                 "msgv3
          ls_temp_mat-ebelp                                 "msgv4
          'SUB_MAT'                " routid
          ' '                      "seg num
          ' '.                     "seg field
        gv_idoc_error = gc_true.
      endloop.
*       Update main work table with SAP Material, PO line item, PO Plant
*       and PO storage location
      gt_mbhp_tab-nmatnr       = gt_temp_mat-matnr.
      gt_mbhp_tab-ebelp        = gt_temp_mat-ebelp.
      gt_mbhp_tab-werks        = gt_temp_mat-werks.
      gt_mbhp_tab-lgort        = gt_temp_mat-lgort.
      modify gt_mbhp_tab
            index gv_tabix
            transporting nmatnr ebelp werks lgort.
    else.
*       SAP Material not derived:  Material No , PO
      perform sub_idoc_status_fill using
        c_idoc_status_error                                 "status 51
        gs_idoc_ctrl-docnum      "idoc number
        c_error                  "status msg type
        'ZSD_DL'                 " message class
        '316'                    " err msg
        gt_mbhp_tab-matnr                                   " msgv1
        gt_mbhp_tab-ebeln                                   "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'SUB_MAT'                " routid
        ' '                      "seg num
        ' '.                     "seg field
      gv_idoc_error = gc_true.

    endif.
  else.
    read table gt_temp_mat
      with key matnr = gt_mbhp_tab-matnr  "Material
               ebeln = gt_mbhp_tab-ebeln     "PO
               ebelp = gt_mbhp_tab-ebelp.     "PO
    if sy-subrc = 0.
      gt_mbhp_tab-nmatnr       = gt_temp_mat-matnr.
      gt_mbhp_tab-ebelp        = gt_temp_mat-ebelp.
      gt_mbhp_tab-werks        = gt_temp_mat-werks.
      gt_mbhp_tab-lgort        = gt_temp_mat-lgort.
      modify gt_mbhp_tab
            index gv_tabix
            transporting nmatnr ebelp werks lgort.
    endif.
  endif.
endform.                    " CHECK_UPDATE_NONROLL
*&---------------------------------------------------------------------*
*&      Form  check_hu_exist
*&---------------------------------------------------------------------*
*       Check if HU's exist for inbound delivery.
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
form check_hu_exist .

  constants:
    lc_inb_del    like vekp-vpobj   value '03'.
* Local variable
  data: lv_exidv  like vekp-exidv.

* If inbound delivery already exists, ie., we are doing reprocessing of
* IDocs
  if not gv_out_vbeln is initial.
*   Read Handling Unit number from VEKP
    select  exidv
       from vekp
       into lv_exidv up to 1 rows
        where vpobj    = lc_inb_del
          and vpobjkey = gv_inb_vbeln.
    endselect.
    if sy-subrc <> 0.
      perform sub_idoc_status_fill using
          c_idoc_status_ok_incomplete                       "status 52
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          text-i01                                          "msgv1
          gv_inb_vbeln                                      "msgv2
          ' '                                               "msgv3
          ' '                                               "msgv4
          'Z_SD_DL_I2301_INPUT_ZVASN'                       "routid
          ' '                     "seg num
          ' '.                    "seg field
      gv_idoc_error = gc_true.
    else.
      gv_idoc_error = gc_false.
    endif.
  endif.
endform.                    " check_hu_exist

*&---------------------------------------------------------------------*
*&      Form  CHECK_3PP_PO
*&---------------------------------------------------------------------*
*       Check for 3PP PO
*       Added by 2000012354
*----------------------------------------------------------------------*
form check_3pp_po tables it_asninfo structure zdl_asninfo
                  using ex_flag type abap_bool
                        cv_3pp  type abap_bool.

  data: lv_index type sy-tabix.

  clear: cv_3pp.

  loop at it_asninfo into data(ls_asninfo).
    lv_index =  sy-tabix.

    "check if it it 3PP PO
    select single
      ebeln,
      bsart,
      ekorg
    from ekko into @data(ls_ekko)
      where ebeln = @ls_asninfo-vgbel
        and bsart = 'TPS'
        and ekorg = '9427'.

    if sy-subrc = 0. "It is 3PP PO
      cv_3pp = 'X'.

      select venum, vpobjkey up to 1 rows from vekp into @data(ls_venum)
        where inhalt = @ls_asninfo-inhalt
          and ( vpobj = @gc_inbound_delivery or
                vpobj = @gc_non_assigned or
                vpobj = @gc_outbound_delivery ).
      endselect.

      if sy-subrc = 0. "Inhalt exists in VEKP
        "Mark entire ASN duplicate and EX_FLAG = 'X'
        ex_flag          = 'X'.
        ls_asninfo-flag  = 'X'.
     modify it_asninfo from ls_asninfo index lv_index transporting flag.
      endif.
    endif.
  endloop.

endform.
*&---------------------------------------------------------------------*
*&      Form  RETRIEVE_PLANT
*&---------------------------------------------------------------------*
*       Attempt to retrieve the Plant using the PO number
*----------------------------------------------------------------------*
*      -->P_GT_MBHP_TAB_EBELN  text
*      <--P_GT_MBHP_TAB_WERKS  text
*----------------------------------------------------------------------*
form retrieve_plant  using    pv_ebeln type ebeln  "PO
                     changing cv_werks type werks_d. "Plant


  data :
    lv_vbeln type vbeln,
    lv_kunnr type kunnr.


  clear: cv_werks.

* Retrieve corresponding Sales Order for the PO
  select single vbelv into lv_vbeln from vbfa "get sales order
    where vbeln = pv_ebeln.
  if sy-subrc = 0.
*   Get customer on the Sales Order header
    select single kunnr into lv_kunnr from vbak "get customer
      where vbeln = lv_vbeln. "sales order
    if sy-subrc = 0.
*     Using the Customer, retrieve the Plant number
      select single werks into cv_werks from zplant "get plant
        where kunnr = lv_kunnr. "customer "#EC CI_NOFIELD
    endif.
  endif.

endform.                    " RETRIEVE_PLANT

*&---------------------------------------------------------------------*
*&      Form  LOCK_PO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_LV_SUBRC  text
*----------------------------------------------------------------------*
form lock_po  changing p_subrc.

  p_subrc = 4.

  do gv_do_loop times.
    call function 'ENQUEUE_EMEKKOE'
      exporting
        mode_ekko      = 'E'
        mode_ekpo      = 'E'
        mandt          = sy-mandt
        ebeln          = gt_temp_mat-ebeln
        ebelp          = gt_temp_mat-ebelp
*       X_EBELN        = ' '
*       X_EBELP        = ' '
*       _SCOPE         = '2'
*       _WAIT          = ' '
*       _COLLECT       = ' '
      exceptions
        foreign_lock   = 1
        system_failure = 2
        others         = 3.

    if sy-subrc = 0.
      p_subrc = sy-subrc.
      call function 'DEQUEUE_EMEKKOE'
        exporting
          mode_ekko = 'E'
          mode_ekpo = 'E'
          mandt     = sy-mandt
          ebeln     = gt_temp_mat-ebeln
          ebelp     = gt_temp_mat-ebelp
          _scope    = '3'.
      exit.
    else.
      wait up to gv_wait_sec seconds.
    endif.
  enddo.


endform.                    " LOCK_PO

* CMS31175|ChangedBy:AMAOLE1|ChangedOn:11042016|START3
form update_weight_e1edl24 changing cs_e1edl24 type e1edl24
                                    cv_flag type char1.

  clear cv_flag.

  select single mtart into @data(lv_mtart) from mara
    where matnr = @cs_e1edl24-matnr.

  select single lowval into @data(lv_lowval) from zdl_fields
    where category  = 'I2301'
    and   fieldname = 'MTART'
    and   lowval    = @lv_mtart.
  if sy-subrc eq 0.
    if gs_e1edl24-ntgew is initial.
      gs_e1edl24-ntgew = gs_e1edl24-lfimg.
    endif.

    if gs_e1edl24-brgew is initial.
      gs_e1edl24-brgew = gs_e1edl24-lfimg.
    endif.

    if gs_e1edl24-lgmng is initial.
      gs_e1edl24-lgmng = gs_e1edl24-lfimg.
    endif.

    cv_flag = 'Y'.
  endif.

endform.
* CMS31175|ChangedBy:AMAOLE1|ChangedOn:11042016|END3

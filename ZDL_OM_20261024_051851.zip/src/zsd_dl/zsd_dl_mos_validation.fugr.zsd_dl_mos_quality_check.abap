FUNCTION zsd_dl_mos_quality_check.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  IMPORTING
*"     REFERENCE(IS_VTTS) TYPE  VTTS
*"  EXPORTING
*"     REFERENCE(ES_SHIP_HEADER_STATUS) TYPE  ZDL_SHIP_HEADER_STATUS
*"  TABLES
*"      IT_ITINERARY TYPE  ZMOS_ITINERARY_S OPTIONAL
*"      ET_SHIPMENT_HU_STATUS STRUCTURE  ZDL_SHIPMENT_HU_STATUS
*"      ET_DELIVERY_HEADER_STATUS STRUCTURE  ZDL_DELIVERY_HEADER_STATUS
*"      ET_DELIVERY_ITEM_STATUS STRUCTURE  ZDL_DELIVERY_ITEM_STATUS
*"  EXCEPTIONS
*"      FACILITY_NOT_FOUND
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2006                                    **
**                             by                                     **
**                    INTERNATIONAL PAPER                             **
************************************************************************
* Description:                                                         *
*---------------                                                       *
* This Function Module will be called to validate various information  *
* regarding a Shipment Stage: Delivery Headers, Delivery Items, etc... *
*----------------------------------------------------------------------*
* Programmer          User-Id      Date         Description            *
* ------------        ---------    --------     ---------------        *
* Kumar Kolluri       kkollur                  Initial Version -Created*
* Meenakshi Yadav     myadav       10/26/2009  ? No comments           *
* Naveen Parchuri     nparchu      11/09/2009  ? No comments           *
* Bruce Ballehr       bballeh      12/15/2009  Added Shipment HU       *
*                                              logic:                  *
*                                            - new return table        *
*                                              ET_SHIPMENT_HU_STATUS   *
*                                            - new Shipment HU         *
*                                              validation and populate *
*                                              ET_SHIPMENT_HU_STATUS   *
*                                            - add field TO_CONFIRMED  *
*                                              ET_DELIVERY_ITEM_STATUS *
*                                              and corresp logic       *
*                                            - Changing the way the    *
*                                              quantity differences are*
*                                              calculated for Batch    *
*                                                                      *
*                                              Split. Must sum up the  *
*                                              LFIMG value and compare *
*                                              to the Parent delivery  *
*                                              item's ZZLFIMG.         *
*                                            - Simplifying logic to    *
*                                              determine Picked and    *
*                                              Packed indicators       *
*                                                                      *
* Bruce Ballehr    04/28/2010  R16I July 2010 --> TPR37866 EDVK976707  *
*                                                                      *
*                              Do not allow the consolidation for HU's *
*                              assigned to STO Deliveries. STO Delivs  *
*                              have LIKP-LFART = 'NL'. We will put     *
*                              create a ZDL_FIELDS entry for this in   *
*                              case we need to expand to other values  *
*                              in the future. The entry will look      *
*                              like this in ZDL_FIELDS:                *
*                                CATEGORY  = WM_STO_DEL                *
*                                FIELDNAME = LFART                     *
*                                SIGN      = I                         *
*                                OPTION    = EQ                        *
*                                LOWVAL    = NL                        *
*                                                                      *
*                              Search BCB01 for these changes          *
*                                                                      *
* Bruce Ballehr    04/28/2010  R16I July 2010 --> TPR38243 EDVK977050  *
*                                                                      *
*                              In subroutine get_reason_code ignore    *
*                              blank Difference Indicators (LTAP-KDZIF)*
*                              when determining if multiple Difference *
*                              Indicators exist for a Delivery Item.   *
*                                                                      *
*                              Search BCB02 for these changes          *
*                                                                      *
* Bruce Ballehr BCB08 08/23/10 b/f USD5575589 --> CO11631  E0VK976159  *
*                                                                      *
*                              When retrieving LIPS records we need to *
*                              ignore all of the LIPS records having   *
*                              an Item Category (lips-pstyv) of TATX   *
*                              as this is causing validation issues.   *
************************************************************************


  DATA:

    lv_is_vtts  TYPE vtts,
    lt_item_obj TYPE zdl_delivery_item_obj_t. "delivery item obj

  lv_is_vtts = is_vtts.

  CLEAR : gv_facility,
          gv_total_weight.

  gv_sto_deliveries = c_n. "set no stage deliveries are STO flag BCB01

  REFRESH : gt_stage_deliveries,
            gt_total_deliveries,
            gt_lips,
            gt_likp,
            gt_ltap,
            gt_t336t.

* Begin BCB01 insert
  PERFORM get_zdl_fields.
* End BCB01 insert

* Populate itinerary
  IF it_itinerary IS INITIAL.
    PERFORM populate_t_itinerary TABLES gt_itinerary USING lv_is_vtts.
  ELSE.
    gt_itinerary = it_itinerary[].
  ENDIF.

* Retain only the loading pts
  DELETE gt_itinerary WHERE stpty = 'CU' OR stpty = 'PU'.

* Move the deliveries from itinerary to the stage  deliveries
* table and  total deliveries table
  PERFORM move_deliveries.

  IF gt_stage_deliveries[] IS NOT INITIAL.
*   Get data from LIPS and VBUP for all Stage Deliveries
    PERFORM get_lips.
*   Generate Delivery Item Objects up front
    PERFORM create_delivery_objects CHANGING lt_item_obj.
  ENDIF.

* Get data from LIKP for Total Deliveries.
  IF gt_total_deliveries[] IS NOT INITIAL.
    PERFORM get_likp.
  ENDIF.

* Get facility.
  PERFORM get_facility.

* Get the text for reason codes
  PERFORM get_t336t.

* Populate the delivery item level picking and packing
  PERFORM prepare_item_status USING lt_item_obj.

* Populate the delivery header
  PERFORM prepare_header_status.

* Validate Shipment Level HU's
  PERFORM prepare_ship_hu_status USING lt_item_obj.

* Populate the shipment weight status
  PERFORM ship_header_status.

* Remove all Delivery Items from the Delivery Item return table if the
* Delivery Item is fully picked and fully packed
  DELETE et_delivery_item_status
    WHERE kosta = c_y  "Pick status
      AND pksta = c_y  "Pack status
      AND difference IS INITIAL.

* Pass the variables to the table
  it_itinerary[] = gt_itinerary.

ENDFUNCTION.

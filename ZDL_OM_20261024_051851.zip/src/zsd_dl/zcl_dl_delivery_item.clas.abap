class ZCL_DL_DELIVERY_ITEM definition
  public
  final
  create public .

*"* public components of class ZCL_DL_DELIVERY_ITEM
*"* do not include other source files here!!!
public section.
  type-pools IBCO2 .
  type-pools ZSDC .

  methods CONSTRUCTOR
    importing
      !IV_VBELN type VBELN_VL optional
      !IV_POSNR type POSNR_VL optional
      !IV_PACK_VIEW type CHAR1 optional
      !IS_ITEM_DATA type ZDL_DELIVERY_ITEM_DATA_S optional
    exceptions
      INVALID_DATA .
  methods GET_ITEM_DATA
    returning
      value(RS_ITEM_DATA) type ZDL_DELIVERY_ITEM_DATA_S .
  methods GET_LIKP_DATA
    returning
      value(RS_LIKP) type LIKP .
  methods GET_LIPS_DATA
    returning
      value(RT_LIPS) type TAB_LIPS .
  methods GET_VBUK_DATA
    returning
      value(RS_VBUK) type VBUK .
  methods GET_VBUP_DATA
    returning
      value(RT_VBUP) type VBUP_T .
  methods GET_VBFA_DATA
    returning
      value(RT_VBFA) type VBFA_T .
  methods GET_VBLKK_DATA
    returning
      value(RS_VBLKK) type VBLKK .
  methods GET_VBLKP_DATA
    returning
      value(RT_VBLKP) type TT_LFPVB .
  methods GET_VBPLK_DATA
    returning
      value(RT_VBPLK) type ZDL_VBPLK_TT .
  methods GET_VBPLP_DATA
    returning
      value(RT_VBPLP) type ZDL_VBPLP_TT .
  methods GET_VBDKL_DATA
    returning
      value(RT_VBDKL) type ZDL_VBDKL_TAB .
  methods GET_VBDPL_DATA
    returning
      value(RT_VBDPL) type ZDL_VBDPL_TAB .
  methods GET_VBPLS_DATA
    returning
      value(RT_VBPLS) type ZDL_VBPLS_TT .
  methods GET_MLGN_DATA
    returning
      value(RS_MLGN) type MLGN .
  methods GET_OPEN_TANUM
    returning
      value(RT_OPEN_TANUM) type TT_TANUM .
  methods GET_CONF_TANUM
    returning
      value(RT_CONF_TANUM) type TT_TANUM .
  methods GET_CANC_TANUM
    returning
      value(RT_CANC_TANUM) type TT_TANUM .
  methods GET_ALL_TANUM
    returning
      value(RT_ALL_TANUM) type TT_TANUM .
  methods GET_POSNR
    returning
      value(RV_POSNR) type POSNR_VL .
  methods GET_MATNR
    returning
      value(RV_MATNR) type MATNR .
  methods GET_WERKS
    returning
      value(RV_WERKS) type WERKS_D .
  methods GET_VRKME
    returning
      value(RV_VRKME) type VRKME .
  methods GET_LGNUM
    returning
      value(RV_LGNUM) type LGNUM .
  methods GET_VSTEL
    returning
      value(RV_VSTEL) type VSTEL .
  class-methods GET_UNIT_CODE
    importing
      !IV_MATNR type MATNR
    returning
      value(RV_UNIT_CODE) type CHAR1 .
  class-methods GET_MTO_MTS
    importing
      !IV_MATNR type MATNR
    returning
      value(RV_STOCK_INDICATOR) type CHAR1 .
  methods GET_SPECIAL_STOCK_INFO
    exporting
      !EV_SOBKZ type SOBKZ
      !EV_SONUM type LVS_SONUM .
  class-methods GET_LETYP
    importing
      !IV_LGNUM type LGNUM
      !IV_MATNR type MATNR
    returning
      value(RV_LETYP) type LVS_LETYP1 .
  methods RELOAD_DATA
    importing
      !IV_PACK_VIEW type CHAR1 optional
    exceptions
      INVALID_DATA .
  methods GET_SO_ITEM
    exporting
      value(EV_VBELN) type VBELN
      value(EV_POSNR) type POSNR .
  class-methods GET_LE_QTY
    importing
      !IV_LGNUM type LGNUM
      !IV_MATNR type MATNR
    exporting
      value(EV_LHMG1) type LVS_LHMNG1
      value(EV_LHME1) type LHMEH1 .
  class-methods GET_CONTROL_QTY
    importing
      !IV_LGNUM type LGNUM
      !IV_MATNR type MATNR
      !IV_LGTYP type LGTYP optional
    exporting
      !EV_MAMNG type MLGT_MAMNG
      !EV_MEINS type MEINS .
  methods GET_OPEN_QTY
    returning
      value(RS_OPEN_QTY) type ZDL_DELIVERY_ITEM_OPEN_QTY_S .
  methods GET_PICKING_STATUS
    returning
      value(RV_KOSTA) type KOSTA .
  methods GET_WM_MOVMT_STATUS
    returning
      value(RV_LVSTA) type LVSTA .
  methods GET_UNDER_TOLERANCE
    exporting
      !EV_TOL_PERCENT type UNTTO
      value(ES_UNDER_TOL) type ZDL_DELIVERY_ITEM_OPEN_QTY_S .
  methods GET_OVER_TOLERANCE
    exporting
      !EV_TOL_PERCENT type UEBTO
      value(ES_OVER_TOL) type ZDL_DELIVERY_ITEM_OPEN_QTY_S .
  methods CHECK_FOR_UNLIMITED_TOL
    returning
      value(RV_UNLIMITED_TOL) type XFELD .
  methods GET_DEST_LGPLA
    returning
      value(RV_LGPLA) type LGPLA .
  methods GET_DEST_LGTYP
    returning
      value(RV_LGTYP) type LGTYP .
  class-methods GET_WM_UNIT
    importing
      !IV_MATNR type MATNR
      !IV_LGNUM type LGNUM
    returning
      value(RV_WM_UNIT) type LVS_LVSME .
  methods UPDATE_ITEM_QTY
    importing
      !IV_ITEM_QTY type LFIMG
      !IV_CHARG type CHARG_D optional
    returning
      value(RT_PROTT) type TAB_PROTT .
  methods COPY_PICKED_QTY_TO_DELV_QTY
    exporting
      !EV_COPY_NOT_REQUIRED type CHAR1
      !EV_COPIED_SUCCESSFULLY type CHAR1
      !ET_PROTT type TAB_PROTT .
  methods GET_TOT_NET_PICKED_WGHT
    exporting
      !EV_TOT_NET_WT type KCNTGEW
      !EV_MEINS type MEINS .
  methods GET_TOT_GROSS_PICKED_WGHT
    exporting
      !EV_TOT_GROSS_WT type KCBRGEW
      !EV_MEINS type MEINS .
  methods GET_TOT_PICKED_QTY
    returning
      value(RS_PICKED_QTY) type ZDL_DELIVERY_ITEM_OPEN_QTY_S .
  methods GET_CURR_DELV_QTY
    returning
      value(RS_DELV_QTY) type ZDL_DELIVERY_ITEM_OPEN_QTY_S .
  methods VALIDATE_DEST_BIN
    exceptions
      INVALID_BIN .
protected section.
*"* protected components of class ZCL_DL_DELIVERY_ITEM
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_DL_DELIVERY_ITEM
*"* do not include other source files here!!!

  data GS_DATA type ZDL_DELIVERY_ITEM_DATA_S .
  data GS_MATNR type GS_MATNR_DATA .
  class-data GS_MLGN type MLGN .
  data GV_PACK_VIEW type CHAR1 .

  methods READ_ITEM_DATA
    importing
      !IV_VBELN type VBELN_VL
      !IV_POSNR type POSNR_VL
      !IV_PACK_VIEW type CHAR1
    exceptions
      DELIVERY_NOT_FOUND
      ITEM_NOT_FOUND .
  methods READ_LIKP_LIPS_DATA
    importing
      !IV_VBELN type VBELN_VL
      !IV_POSNR type POSNR_VL
    exceptions
      DELIVERY_NOT_FOUND .
  methods READ_VBUK_DATA .
  methods READ_VBUP_DATA
    returning
      value(RT_VBUP) type VBUP_T .
  methods READ_VBFA_DATA .
  methods READ_TANUM_DATA .
  methods READ_PACKING_DATA
    exporting
      !ET_VBDKL type ZDL_VBDKL_TAB
      !ET_VBDPL type ZDL_VBDPL_TAB
      !ET_VBPLK type ZDL_VBPLK_TT
      !ET_VBPLP type ZDL_VBPLP_TT
      !ET_VBPLS type ZDL_VBPLS_TT .
ENDCLASS.



CLASS ZCL_DL_DELIVERY_ITEM IMPLEMENTATION.


METHOD check_for_unlimited_tol .

  DATA ls_lips TYPE lips.

  CLEAR : rv_unlimited_tol.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  rv_unlimited_tol = ls_lips-uebtk.

ENDMETHOD.


METHOD constructor .

  CLEAR : gs_data, gs_matnr, gs_mlgn.

  IF  is_item_data IS INITIAL AND
    ( iv_vbeln     IS INITIAL OR iv_posnr IS INITIAL ).
* Invalid input
    MESSAGE e203 RAISING invalid_data.
  ENDIF.

  IF is_item_data IS NOT INITIAL.
    gs_data = is_item_data.
    RETURN.
  ENDIF.

  CALL METHOD read_item_data
    EXPORTING
      iv_vbeln           = iv_vbeln
      iv_posnr           = iv_posnr
      iv_pack_view       = iv_pack_view
    EXCEPTIONS
      delivery_not_found = 1
      item_not_found     = 2
      OTHERS             = 3.
  IF sy-subrc NE 0.
* Invalid Delivery/Item
    MESSAGE e202 RAISING invalid_data.
  ENDIF.

ENDMETHOD.


METHOD copy_picked_qty_to_delv_qty .

  DATA : ls_lips  TYPE lips,
         lv_pikmg TYPE pikmg.

  CLEAR : ev_copy_not_required, ev_copied_successfully.
  REFRESH et_prott.

  CALL METHOD reload_data.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  IF ls_lips-charg IS INITIAL.
    ev_copy_not_required = 'X'.
    RETURN.
  ENDIF.

  CALL FUNCTION 'SD_SALES_DOCUMENT_REFRESH'
    EXPORTING
      i_vbeln = ls_lips-vbeln.

  CALL FUNCTION 'WB2_GET_PICK_QUANTITY'
    EXPORTING
      i_vbeln             = ls_lips-vbeln
      i_posnr             = ls_lips-posnr
    IMPORTING
      e_pikmg             = lv_pikmg
    EXCEPTIONS
      document_read_error = 1
      OTHERS              = 2.
  IF sy-subrc NE 0.
    " do nothing
  ENDIF.

  IF lv_pikmg LE ls_lips-lfimg.   " TPR 38262 ->changed lgmng to lfimg
    ev_copy_not_required = 'X'.
    RETURN.
  ENDIF.

  CALL METHOD update_item_qty
    EXPORTING
      iv_item_qty = lv_pikmg
      iv_charg    = ls_lips-charg
    RECEIVING
      rt_prott    = et_prott.

  IF et_prott[] IS INITIAL.
    ev_copied_successfully = 'X'.
  ENDIF.

ENDMETHOD.


METHOD GET_ALL_TANUM .

  REFRESH rt_all_tanum[].

  rt_all_tanum[] = gs_data-all_tanum[].

ENDMETHOD.


METHOD GET_CANC_TANUM .

  REFRESH rt_canc_tanum[].

  rt_canc_tanum[] = gs_data-canc_tanum[].

ENDMETHOD.


METHOD GET_CONF_TANUM .

  REFRESH rt_conf_tanum[].

  rt_conf_tanum[] = gs_data-conf_tanum[].

ENDMETHOD.


METHOD get_control_qty .

  DATA : ls_mlgt  TYPE mlgt,
         lv_lgtyp TYPE lgtyp.

  CLEAR : ev_mamng, ev_meins.

  IF iv_lgnum IS INITIAL OR iv_matnr IS INITIAL.
    RETURN.
  ENDIF.

  IF iv_lgtyp IS NOT INITIAL.
    lv_lgtyp = iv_lgtyp.
  ELSE.
* Get the Fixed bin for the material
    CALL METHOD zcl_wm_misc_func=>get_fixed_bin_for_matnr
      EXPORTING
        iv_matnr = iv_matnr
        iv_lgnum = iv_lgnum
      IMPORTING
        ev_lgtyp = lv_lgtyp.
  ENDIF.

  SELECT SINGLE *
         FROM   mlgt
         INTO   ls_mlgt
         WHERE  matnr EQ iv_matnr AND
                lgnum EQ iv_lgnum AND
                lgtyp EQ lv_lgtyp.
  IF ls_mlgt-mamng IS NOT INITIAL.
    ev_mamng = ls_mlgt-mamng.
    ev_meins = 'LB'.    " Control Qty is always in base unit
  ENDIF.

ENDMETHOD.


METHOD get_curr_delv_qty .

  DATA : ls_lips      TYPE lips,
         lv_wm_unit   TYPE lvs_lvsme,
         lv_input_qty TYPE komng.

  CLEAR rs_delv_qty.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rs_delv_qty-in_meins = ls_lips-ntgew.  " Cuml. batch qty
    rs_delv_qty-meins    = ls_lips-meins.   " Base Unit
    rs_delv_qty-in_vrkme = ls_lips-lfimg.  " Qty in sales unit
    rs_delv_qty-vrkme    = ls_lips-vrkme.      " Sales Unit

    CALL METHOD zcl_dl_delivery_item=>get_wm_unit
      EXPORTING
        iv_matnr   = ls_lips-matnr
        iv_lgnum   = ls_lips-lgnum
      RECEIVING
        rv_wm_unit = lv_wm_unit.

    IF lv_wm_unit EQ ls_lips-vrkme.
      rs_delv_qty-in_lvsme = ls_lips-lfimg.  " Qty in WM Unit
      rs_delv_qty-lvsme    = ls_lips-vrkme.      " WM Unit
    ELSE.
      lv_input_qty = ls_lips-ntgew.
      CALL METHOD zcl_wm_misc_func=>convert_matnr_qty_to_wm_unit
        EXPORTING
          iv_lgnum         = ls_lips-lgnum
          iv_matnr         = ls_lips-matnr
          iv_input_qty     = lv_input_qty
          iv_input_meins   = ls_lips-meins
          iv_wm_unit       = lv_wm_unit
        IMPORTING
          ev_output_qty    = rs_delv_qty-in_lvsme   " Qty in WM Unit
          ev_wm_unit       = rs_delv_qty-lvsme      " WM Unit
        EXCEPTIONS
          invalid_data     = 1
          no_wm_data       = 2
          conversion_error = 3
          OTHERS           = 4.
      IF sy-subrc NE 0.
*        RAISE wm_unit_conversion_error.
      ENDIF.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD GET_DEST_LGPLA .

  DATA ls_lips TYPE lips.

  CLEAR rv_lgpla.

  IF gs_matnr-destn_bin IS NOT INITIAL.
    rv_lgpla = gs_matnr-destn_bin.
    RETURN.
  ENDIF.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_lgpla = gs_matnr-destn_bin = ls_lips-lgpla.
  ENDIF.

ENDMETHOD.


METHOD get_dest_lgtyp .

  DATA ls_lips TYPE lips.

  CLEAR rv_lgtyp.

  IF gs_matnr-destn_typ IS NOT INITIAL.
    rv_lgtyp = gs_matnr-destn_typ.
    RETURN.
  ENDIF.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_lgtyp = gs_matnr-destn_typ = ls_lips-lgtyp.
  ENDIF.

ENDMETHOD.


METHOD GET_ITEM_DATA .

  CLEAR rs_item_data.

  rs_item_data = gs_data.

ENDMETHOD.


METHOD get_letyp .

  DATA ls_mlgn TYPE mlgn.

  CLEAR rv_letyp.

  IF iv_lgnum IS INITIAL OR iv_matnr IS INITIAL.
    RETURN.
  ENDIF.

  SELECT SINGLE *
         FROM   mlgn
         INTO   ls_mlgn
         WHERE  matnr EQ iv_matnr AND
                lgnum EQ iv_lgnum.
  IF ls_mlgn-lety1 IS NOT INITIAL.
    rv_letyp = ls_mlgn-lety1.
  ENDIF.

ENDMETHOD.


METHOD get_le_qty .

  DATA ls_mlgn TYPE mlgn.

  CLEAR : ev_lhmg1, ev_lhme1.

  IF iv_lgnum IS INITIAL OR iv_matnr IS INITIAL.
    RETURN.
  ENDIF.

  SELECT SINGLE *
         FROM   mlgn
         INTO   ls_mlgn
         WHERE  matnr EQ iv_matnr AND
                lgnum EQ iv_lgnum.
  IF ls_mlgn-lhmg1 IS NOT INITIAL.
    ev_lhmg1 = ls_mlgn-lhmg1.
    ev_lhme1 = ls_mlgn-lhme1.
  ENDIF.

ENDMETHOD.


METHOD GET_LGNUM .

  DATA ls_lips TYPE lips.

  CLEAR rv_lgnum.

  IF gs_matnr-lgnum IS NOT INITIAL.
    rv_lgnum = gs_matnr-lgnum.
    RETURN.
  ENDIF.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY vbeln = gs_data-vbeln
                                                  posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_lgnum = gs_matnr-lgnum = ls_lips-lgnum.
  ENDIF.

ENDMETHOD.


METHOD GET_LIKP_DATA .

  CLEAR rs_likp.
  rs_likp = gs_data-likp.

ENDMETHOD.


METHOD GET_LIPS_DATA .

  REFRESH rt_lips.
  rt_lips[] = gs_data-lips[].

ENDMETHOD.


METHOD GET_MATNR .

  DATA ls_lips TYPE lips.

  CLEAR rv_matnr.

  IF gs_matnr-matnr IS NOT INITIAL.
    rv_matnr = gs_matnr-matnr.
    RETURN.
  ENDIF.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_matnr = gs_matnr-matnr = ls_lips-matnr.
  ENDIF.

ENDMETHOD.


METHOD get_mlgn_data .

  DATA : lv_matnr TYPE matnr,
         lv_lgnum TYPE lgnum.

  CLEAR rs_mlgn.

  IF gs_mlgn IS NOT INITIAL.
    rs_mlgn = gs_mlgn.
    RETURN.
  ENDIF.

  lv_matnr = get_matnr( ).
  lv_lgnum = get_lgnum( ).

  SELECT SINGLE *
         FROM   mlgn
         INTO   gs_mlgn
         WHERE  matnr EQ lv_matnr AND
                lgnum EQ lv_lgnum.
  IF sy-subrc EQ 0.
    rs_mlgn = gs_mlgn.
  ENDIF.

ENDMETHOD.


METHOD get_mto_mts .

  DATA : lv_cuobf      TYPE cuobm,
         lt_char_name  TYPE TABLE OF zsd_characteristic_name,
         lt_char_value TYPE ibco2_value_tab,
         ls_char_name  TYPE zsd_characteristic_name,
         ls_char_value TYPE ibco2_value_rec.

  CLEAR rv_stock_indicator.

  IF iv_matnr IS INITIAL.
    RETURN.
  ENDIF.

  ls_char_name-atnam = zsdc_stock_indicator.
  APPEND ls_char_name TO lt_char_name.

  SELECT SINGLE cuobf
         INTO   lv_cuobf
         FROM   mara
         WHERE  matnr EQ iv_matnr.
  IF lv_cuobf IS NOT INITIAL.
    CALL FUNCTION 'ZSD_GET_SINGLE_VALUES_OF_INST'
      EXPORTING
        instance                       = lv_cuobf
      IMPORTING
        et_values                      = lt_char_value
      TABLES
        t_get_specific_characteristics = lt_char_name
      EXCEPTIONS
        instance_not_found             = 1
        no_configuration_data_found    = 2
        characteristic_not_found       = 3
        OTHERS                         = 4.
    IF lt_char_value[] IS NOT INITIAL.
      READ TABLE lt_char_value INTO ls_char_value INDEX 1.
      rv_stock_indicator = ls_char_value-atwrt.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD get_open_qty .

  DATA : ls_vblkp   TYPE vblkp,
         lv_wm_unit TYPE lvs_lvsme.

  CLEAR rs_open_qty.

  READ TABLE gs_data-vblkp[] INTO ls_vblkp
                             WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rs_open_qty-in_meins = ls_vblkp-komng.  " Qty in base unit
    rs_open_qty-meins    = ls_vblkp-meins.  " Base Unit
    rs_open_qty-in_vrkme = ls_vblkp-komng_vme.  " Qty in sales unit
    rs_open_qty-vrkme    = ls_vblkp-vrkme.      " Sales Unit

    CALL METHOD zcl_dl_delivery_item=>get_wm_unit
      EXPORTING
        iv_matnr   = ls_vblkp-matnr
        iv_lgnum   = ls_vblkp-lgnum
      RECEIVING
        rv_wm_unit = lv_wm_unit.

    IF lv_wm_unit EQ ls_vblkp-vrkme.
      rs_open_qty-in_lvsme = ls_vblkp-komng_vme.  " Qty in WM Unit
      rs_open_qty-lvsme    = ls_vblkp-vrkme.      " WM Unit
    ELSE.
      CALL METHOD zcl_wm_misc_func=>convert_matnr_qty_to_wm_unit
        EXPORTING
          iv_lgnum         = ls_vblkp-lgnum
          iv_matnr         = ls_vblkp-matnr
          iv_input_qty     = ls_vblkp-komng
          iv_input_meins   = ls_vblkp-meins
        IMPORTING
          ev_output_qty    = rs_open_qty-in_lvsme   " Qty in WM Unit
          ev_wm_unit       = rs_open_qty-lvsme     " WM Unit
        EXCEPTIONS
          invalid_data     = 1
          no_wm_data       = 2
          conversion_error = 3
          OTHERS           = 4.
      IF sy-subrc NE 0.
*        RAISE wm_unit_conversion_error.
      ENDIF.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD GET_OPEN_TANUM .

  REFRESH rt_open_tanum[].

  rt_open_tanum[] = gs_data-open_tanum[].

ENDMETHOD.


METHOD get_over_tolerance .

  DATA : ls_lips     TYPE lips,
         lv_wm_unit  TYPE lvs_lvsme,
         lv_net_wght TYPE ntgew_15,
         lv_del_qty  TYPE lfimg.

  CLEAR : ev_tol_percent, es_over_tol.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  ev_tol_percent = ls_lips-uebto.

  lv_net_wght = ls_lips-ntgew + ls_lips-kcntgew.
  IF ls_lips-vrkme EQ 'LB'.
    lv_del_qty  = lv_net_wght.
  ELSE.
    lv_del_qty  = ls_lips-lfimg + ls_lips-kcmengvme.
  ENDIF.

  es_over_tol-in_meins = lv_net_wght *
                          ( 100 + ls_lips-uebto ) / 100.
  es_over_tol-meins    = ls_lips-meins.

  IF ls_lips-vrkme EQ ls_lips-meins.
    es_over_tol-in_vrkme = es_over_tol-in_meins.
    es_over_tol-vrkme    = es_over_tol-meins.
  ELSE.
    es_over_tol-in_vrkme = lv_del_qty *
                            ( 100 + ls_lips-uebto ) / 100.
    es_over_tol-vrkme    = ls_lips-vrkme.
  ENDIF.

  CALL METHOD zcl_dl_delivery_item=>get_wm_unit
    EXPORTING
      iv_matnr   = ls_lips-matnr
      iv_lgnum   = ls_lips-lgnum
    RECEIVING
      rv_wm_unit = lv_wm_unit.
  IF lv_wm_unit IS NOT INITIAL.
    IF lv_wm_unit EQ ls_lips-vrkme.
      es_over_tol-in_lvsme = es_over_tol-in_vrkme.
      es_over_tol-lvsme    = es_over_tol-vrkme.
    ELSE.
      CALL METHOD zcl_wm_misc_func=>convert_matnr_qty_to_wm_unit
        EXPORTING
          iv_lgnum         = ls_lips-lgnum
          iv_matnr         = ls_lips-matnr
          iv_input_qty     = es_over_tol-in_meins
          iv_input_meins   = es_over_tol-meins
          iv_wm_unit       = lv_wm_unit
        IMPORTING
          ev_output_qty    = es_over_tol-in_lvsme   " Qty in WM Unit
          ev_wm_unit       = es_over_tol-lvsme      " WM Unit
        EXCEPTIONS
          invalid_data     = 1
          no_wm_data       = 2
          conversion_error = 3
          OTHERS           = 4.
      IF sy-subrc NE 0.
*        RAISE wm_unit_conversion_error.
      ENDIF.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD GET_PICKING_STATUS .

  DATA ls_vbup TYPE vbup.

  CLEAR rv_kosta.

  READ TABLE gs_data-vbup[] INTO ls_vbup WITH KEY vbeln = gs_data-vbeln
                                                  posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_kosta = ls_vbup-kosta.
  ENDIF.

ENDMETHOD.


METHOD GET_POSNR .

  CLEAR rv_posnr.
  rv_posnr = gs_data-posnr.

ENDMETHOD.


METHOD get_so_item .

  DATA ls_lips TYPE lips.

  CLEAR : ev_vbeln, ev_posnr.

  IF gs_matnr-so_vbeln IS NOT INITIAL.
    ev_vbeln = gs_matnr-so_vbeln.
    ev_posnr = gs_matnr-so_posnr.
    RETURN.
  ENDIF.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    ev_vbeln = gs_matnr-so_vbeln = ls_lips-vgbel.
    ev_posnr = gs_matnr-so_posnr = ls_lips-vgpos.
  ENDIF.

ENDMETHOD.


METHOD get_special_stock_info .

  DATA ls_lips TYPE lips.

  CLEAR : ev_sobkz, ev_sonum.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    ev_sobkz = ls_lips-sobkz.
    ev_sonum = ls_lips-sonum.
  ENDIF.

ENDMETHOD.


METHOD get_tot_gross_picked_wght .

  DATA ls_lips TYPE lips.

  CLEAR : ev_tot_gross_wt, ev_meins.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  IF ls_lips-charg IS NOT INITIAL.
    ev_tot_gross_wt = ls_lips-brgew.
    ev_meins        = ls_lips-meins.
  ELSE.
    ev_tot_gross_wt = ls_lips-kcbrgew.
    ev_meins        = ls_lips-meins.
  ENDIF.

ENDMETHOD.


METHOD get_tot_net_picked_wght .

  DATA ls_lips TYPE lips.

  CLEAR : ev_tot_net_wt, ev_meins.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  IF ls_lips-charg IS NOT INITIAL.
    ev_tot_net_wt = ls_lips-ntgew.
    ev_meins      = ls_lips-meins.
  ELSE.
    ev_tot_net_wt = ls_lips-kcntgew.
    ev_meins      = ls_lips-meins.
  ENDIF.

ENDMETHOD.


METHOD get_tot_picked_qty .

  DATA : ls_lips      TYPE lips,
         lv_wm_unit   TYPE lvs_lvsme,
         lv_input_qty TYPE komng.

  CLEAR rs_picked_qty.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  IF ls_lips-charg IS NOT INITIAL.
    rs_picked_qty-in_meins = ls_lips-ntgew  .  " Batch qty
    rs_picked_qty-meins    = ls_lips-meins.   " Base Unit
    rs_picked_qty-in_vrkme = ls_lips-lfimg.  " Qty in sales unit
    rs_picked_qty-vrkme    = ls_lips-vrkme.      " Sales Unit
  ELSE.
    rs_picked_qty-in_meins = ls_lips-kcmeng.  " Cuml. batch qty
    rs_picked_qty-meins    = ls_lips-meins.   " Base Unit
    rs_picked_qty-in_vrkme = ls_lips-kcmengvme.  " Qty in sales unit
    rs_picked_qty-vrkme    = ls_lips-vrkme.      " Sales Unit
  ENDIF.

  CALL METHOD zcl_dl_delivery_item=>get_wm_unit
    EXPORTING
      iv_matnr   = ls_lips-matnr
      iv_lgnum   = ls_lips-lgnum
    RECEIVING
      rv_wm_unit = lv_wm_unit.

  IF lv_wm_unit EQ ls_lips-vrkme.
    rs_picked_qty-in_lvsme = rs_picked_qty-in_vrkme.  " Qty in WM Unit
    rs_picked_qty-lvsme    = rs_picked_qty-vrkme.      " WM Unit
  ELSE.
    lv_input_qty = rs_picked_qty-in_meins.
    CALL METHOD zcl_wm_misc_func=>convert_matnr_qty_to_wm_unit
      EXPORTING
        iv_lgnum         = ls_lips-lgnum
        iv_matnr         = ls_lips-matnr
        iv_input_qty     = lv_input_qty
        iv_input_meins   = ls_lips-meins
        iv_wm_unit       = lv_wm_unit
      IMPORTING
        ev_output_qty    = rs_picked_qty-in_lvsme   " Qty in WM Unit
        ev_wm_unit       = rs_picked_qty-lvsme      " WM Unit
      EXCEPTIONS
        invalid_data     = 1
        no_wm_data       = 2
        conversion_error = 3
        OTHERS           = 4.
    IF sy-subrc NE 0.
*        RAISE wm_unit_conversion_error.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD get_under_tolerance .

  DATA : ls_lips     TYPE lips,
         lv_wm_unit  TYPE lvs_lvsme,
         lv_net_wght TYPE ntgew_15,
         lv_del_qty  TYPE lfimg.

  CLEAR : ev_tol_percent, es_under_tol.

  READ TABLE gs_data-lips INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  ev_tol_percent = ls_lips-untto.

  lv_net_wght = ls_lips-ntgew + ls_lips-kcntgew.
  IF ls_lips-vrkme EQ 'LB'.
    lv_del_qty  = lv_net_wght.
  ELSE.
    lv_del_qty  = ls_lips-lfimg + ls_lips-kcmengvme.
  ENDIF.

  es_under_tol-in_meins = lv_net_wght *
                          ( 100 - ls_lips-untto ) / 100.
  es_under_tol-meins    = ls_lips-meins.

  IF ls_lips-vrkme EQ ls_lips-meins.
    es_under_tol-in_vrkme = es_under_tol-in_meins.
    es_under_tol-vrkme    = es_under_tol-meins.
  ELSE.
    es_under_tol-in_vrkme = lv_del_qty *
                            ( 100 - ls_lips-untto ) / 100.
    es_under_tol-vrkme    = ls_lips-vrkme.
  ENDIF.

  CALL METHOD zcl_dl_delivery_item=>get_wm_unit
    EXPORTING
      iv_matnr   = ls_lips-matnr
      iv_lgnum   = ls_lips-lgnum
    RECEIVING
      rv_wm_unit = lv_wm_unit.
  IF lv_wm_unit IS NOT INITIAL.
    IF lv_wm_unit EQ ls_lips-vrkme.
      es_under_tol-in_lvsme = es_under_tol-in_vrkme.
      es_under_tol-lvsme    = es_under_tol-vrkme.
    ELSE.
      CALL METHOD zcl_wm_misc_func=>convert_matnr_qty_to_wm_unit
        EXPORTING
          iv_lgnum         = ls_lips-lgnum
          iv_matnr         = ls_lips-matnr
          iv_input_qty     = es_under_tol-in_meins
          iv_input_meins   = es_under_tol-meins
          iv_wm_unit       = lv_wm_unit
        IMPORTING
          ev_output_qty    = es_under_tol-in_lvsme   " Qty in WM Unit
          ev_wm_unit       = es_under_tol-lvsme      " WM Unit
        EXCEPTIONS
          invalid_data     = 1
          no_wm_data       = 2
          conversion_error = 3
          OTHERS           = 4.
      IF sy-subrc NE 0.
*        RAISE wm_unit_conversion_error.
      ENDIF.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD get_unit_code .

  DATA : lv_cuobf      TYPE cuobm,
         lt_char_name  TYPE TABLE OF zsd_characteristic_name,
         lt_char_value TYPE ibco2_value_tab,
         ls_char_name  TYPE zsd_characteristic_name,
         ls_char_value TYPE ibco2_value_rec.

  CLEAR rv_unit_code.

  IF iv_matnr IS INITIAL.
    RETURN.
  ENDIF.

  ls_char_name-atnam = zsdc_unit_code.
  APPEND ls_char_name TO lt_char_name.

  SELECT SINGLE cuobf
         INTO   lv_cuobf
         FROM   mara
         WHERE  matnr EQ iv_matnr.
  IF lv_cuobf IS NOT INITIAL.
    CALL FUNCTION 'ZSD_GET_SINGLE_VALUES_OF_INST'
      EXPORTING
        instance                       = lv_cuobf
      IMPORTING
        et_values                      = lt_char_value
      TABLES
        t_get_specific_characteristics = lt_char_name
      EXCEPTIONS
        instance_not_found             = 1
        no_configuration_data_found    = 2
        characteristic_not_found       = 3
        OTHERS                         = 4.
    IF lt_char_value[] IS NOT INITIAL.
      READ TABLE lt_char_value INTO ls_char_value INDEX 1.
      rv_unit_code = ls_char_value-atwrt.
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD get_vbdkl_data .

  REFRESH rt_vbdkl.
  rt_vbdkl[] = gs_data-vbdkl[].

ENDMETHOD.


METHOD get_vbdpl_data .

  REFRESH rt_vbdpl.
  rt_vbdpl[] = gs_data-vbdpl[].

ENDMETHOD.


METHOD GET_VBFA_DATA .

  REFRESH rt_vbfa.
  rt_vbfa[] = gs_data-vbfa[].

ENDMETHOD.


METHOD GET_VBLKK_DATA .

  CLEAR rs_vblkk.
  rs_vblkk = gs_data-vblkk.

ENDMETHOD.


METHOD GET_VBLKP_DATA .

  REFRESH rt_vblkp.
  rt_vblkp[] = gs_data-vblkp[].

ENDMETHOD.


METHOD get_vbplk_data .

  REFRESH rt_vbplk.
  rt_vbplk[] = gs_data-vbplk[].

ENDMETHOD.


METHOD get_vbplp_data .

  REFRESH rt_vbplp.
  rt_vbplp[] = gs_data-vbplp[].

ENDMETHOD.


METHOD get_vbpls_data .

  REFRESH rt_vbpls.
  rt_vbpls[] = gs_data-vbpls[].

ENDMETHOD.


METHOD GET_VBUK_DATA .

  CLEAR rs_vbuk.
  rs_vbuk = gs_data-vbuk.

ENDMETHOD.


METHOD GET_VBUP_DATA .

  REFRESH rt_vbup.
  rt_vbup[] = gs_data-vbup[].

ENDMETHOD.


METHOD get_vrkme .

  DATA ls_lips TYPE lips.

  CLEAR rv_vrkme.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_vrkme = ls_lips-vrkme.
  ENDIF.

ENDMETHOD.


METHOD GET_VSTEL .

  CLEAR rv_vstel.

  rv_vstel = gs_data-likp-vstel.

ENDMETHOD.


METHOD GET_WERKS .

  DATA ls_lips TYPE lips.

  CLEAR rv_werks.

  IF gs_matnr-werks IS NOT INITIAL.
    rv_werks = gs_matnr-werks.
    RETURN.
  ENDIF.

  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_werks = gs_matnr-werks = ls_lips-werks.
  ENDIF.

ENDMETHOD.


METHOD GET_WM_MOVMT_STATUS .

  DATA ls_vbup TYPE vbup.

  CLEAR rv_lvsta.

  READ TABLE gs_data-vbup[] INTO ls_vbup WITH KEY vbeln = gs_data-vbeln
                                                  posnr = gs_data-posnr.
  IF sy-subrc EQ 0.
    rv_lvsta = ls_vbup-lvsta.



  ENDIF.

ENDMETHOD.


METHOD get_wm_unit .

  CLEAR rv_wm_unit.

  IF gs_mlgn IS NOT INITIAL.
    IF gs_mlgn-matnr EQ iv_matnr AND gs_mlgn-lgnum EQ iv_lgnum.
      rv_wm_unit = gs_mlgn-lvsme.
    ENDIF.
  ENDIF.

  SELECT SINGLE *
         FROM   mlgn
         INTO   gs_mlgn
         WHERE  matnr EQ iv_matnr AND
                lgnum EQ iv_lgnum.
  IF sy-subrc EQ 0.
    rv_wm_unit = gs_mlgn-lvsme.
  ENDIF.

ENDMETHOD.


METHOD read_item_data .

  DATA : lt_vbup  TYPE vbup_t,
         lt_vbdkl TYPE zdl_vbdkl_tab,
         lt_vbdpl TYPE zdl_vbdpl_tab,
         lt_vbplk TYPE zdl_vbplk_tt,
         lt_vbplp TYPE zdl_vbplp_tt,
         lt_vbpls TYPE zdl_vbpls_tt,
         ls_lips  TYPE lips,
         ls_vbup  TYPE vbup,
         ls_vbdpl TYPE vbdpl,
         ls_vbplk TYPE vbplk,
         ls_vbplp TYPE vbplp.

  DATA : lv_vbeln TYPE vbeln_vl,
         lv_posnr TYPE posnr_vl,
         lv_pack_view.

  lv_vbeln     = iv_vbeln.
  lv_posnr     = iv_posnr.
  lv_pack_view = iv_pack_view.

  CLEAR : gs_data, gs_matnr, gs_mlgn.

  CALL METHOD read_likp_lips_data
    EXPORTING
      iv_vbeln           = lv_vbeln
      iv_posnr           = lv_posnr
    EXCEPTIONS
      delivery_not_found = 1
      OTHERS             = 2.
  IF sy-subrc NE 0.
* Delivery & not found
    MESSAGE e200 WITH lv_vbeln RAISING delivery_not_found.
  ENDIF.

  CLEAR ls_lips.
  READ TABLE gs_data-lips[] INTO ls_lips WITH KEY vbeln = lv_vbeln
                                                  posnr = lv_posnr.
  IF sy-subrc NE 0.
* Delivery & Item & not found
    MESSAGE e201 WITH lv_vbeln lv_posnr RAISING item_not_found.
  ENDIF.

  gs_data-vbeln = lv_vbeln.
  gs_data-posnr = lv_posnr.

* Get VBUK data
  CALL METHOD read_vbuk_data.

* Get VBUP data
  CALL METHOD read_vbup_data
    RECEIVING
      rt_vbup = lt_vbup.

* Get VBFA data
  CALL METHOD read_vbfa_data.

* For a WM managed delivery/item, look for the Transfer Orders
  IF gs_data-likp-lgnum IS NOT INITIAL.
    CALL METHOD read_tanum_data.
  ENDIF.

* If packing data is requested, go get it!!!
  IF lv_pack_view IS INITIAL.
    CALL METHOD read_packing_data
      IMPORTING
        et_vbdkl = lt_vbdkl
        et_vbdpl = lt_vbdpl
        et_vbplk = lt_vbplk
        et_vbplp = lt_vbplp
        et_vbpls = lt_vbpls.
  ENDIF.

* Prepare the global attribute GS_DATA with the data read so far from
* all other tables
  gs_data-vbdkl[] = lt_vbdkl[].
  gs_data-vbpls[] = lt_vbpls[].

  LOOP AT gs_data-lips INTO ls_lips.
    CLEAR ls_vbup.
    READ TABLE lt_vbup INTO ls_vbup WITH KEY vbeln = ls_lips-vbeln
                                             posnr = ls_lips-posnr
                                             BINARY SEARCH.
    IF sy-subrc EQ 0.
      APPEND ls_vbup TO gs_data-vbup[].
    ENDIF.

* Document Item View for Delivery Note
    CLEAR ls_vbdpl.
    READ TABLE lt_vbdpl INTO ls_vbdpl WITH KEY posnr = ls_lips-posnr.
    IF sy-subrc EQ 0.
      APPEND ls_vbdpl TO gs_data-vbdpl[].
    ENDIF.

*  Handling-Unit Content Data
    CLEAR ls_vbplp.
    READ TABLE lt_vbplp INTO ls_vbplp WITH KEY posnr = ls_lips-posnr.
    IF sy-subrc EQ 0.
      APPEND ls_vbplp TO gs_data-vbplp[].

* * Handling Unit Header-Data
      CLEAR ls_vbplk.
      READ TABLE lt_vbplk INTO ls_vbplk WITH KEY venum = ls_vbplp-venum.
      IF sy-subrc EQ 0.
        APPEND ls_vbplk TO gs_data-vbplk[].
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDMETHOD.


METHOD read_likp_lips_data .

  CALL FUNCTION 'RV_DELIVERY_PICK_VIEW'
    EXPORTING
      vbeln              = iv_vbeln
      if_posnr           = iv_posnr
      zweck              = 'L'
    IMPORTING
      es_likp            = gs_data-likp
      vblkk_wa           = gs_data-vblkk
    TABLES
      vblkp_tab          = gs_data-vblkp[]
      lips_tab           = gs_data-lips[]
    EXCEPTIONS
      no_likp            = 1
      no_picking_allowed = 2
      hu_error           = 3
      OTHERS             = 4.
  IF sy-subrc NE 0.
* Delivery & not found
    MESSAGE e200 WITH iv_vbeln RAISING delivery_not_found.
  ENDIF.

ENDMETHOD.


METHOD read_packing_data .

  DATA ls_vbco3 TYPE vbco3.

  REFRESH : et_vbdkl, et_vbdpl, et_vbplk, et_vbplp, et_vbpls.
* If the delivery is packed, and packing data is requested
  ls_vbco3-vbeln = gs_data-vbeln.
  ls_vbco3-packd = 'X'.
  CALL FUNCTION 'SD_DELIVERY_VIEW'
    EXPORTING
      comwa            = ls_vbco3
    TABLES
      vbdkl_tab        = et_vbdkl[]
      vbdpl_tab        = et_vbdpl[]
      vbplk_tab        = et_vbplk[]
      vbplp_tab        = et_vbplp[]
      vbpls_tab        = et_vbpls[]
    EXCEPTIONS
      object_not_found = 1
      OTHERS           = 2.
  IF sy-subrc NE 0.
    " do nothing
  ENDIF.

ENDMETHOD.


METHOD read_tanum_data .

  DATA : ls_vbfa  TYPE vbfa,
         ls_tanum TYPE tanum.

  LOOP AT gs_data-vbfa[] INTO ls_vbfa WHERE vbtyp_n EQ 'Q'.
    ls_tanum = ls_vbfa-vbeln.
    IF ls_vbfa-taqui EQ 'X'.
      IF ls_vbfa-rfmng IS INITIAL.
        COLLECT ls_tanum INTO gs_data-canc_tanum[].
      ELSE.
        COLLECT ls_tanum INTO gs_data-conf_tanum[].
      ENDIF.
    ELSE.
      COLLECT ls_tanum INTO gs_data-open_tanum[].
    ENDIF.
    COLLECT ls_tanum INTO gs_data-all_tanum[].
  ENDLOOP.

ENDMETHOD.


METHOD read_vbfa_data .

  DATA lt_vbfa TYPE vbfa_t.

  REFRESH lt_vbfa.
  CALL FUNCTION 'SD_VBFA_READ_WITH_VBELV'
    EXPORTING
      i_vbelv          = gs_data-vbeln
      i_refresh_buffer = 'X'
    TABLES
      et_vbfa          = lt_vbfa[]
    EXCEPTIONS
      record_not_found = 1
      OTHERS           = 2.
  IF sy-subrc EQ 0.
    SORT lt_vbfa BY vbelv posnv.
    DELETE lt_vbfa WHERE posnv NE gs_data-posnr.
    gs_data-vbfa[] = lt_vbfa[].
  ENDIF.

ENDMETHOD.


METHOD read_vbuk_data .

  CALL FUNCTION 'SD_VBUK_SINGLE_READ'
    EXPORTING
      i_vbeln          = gs_data-vbeln
      i_refresh_buffer = 'X'
    IMPORTING
      e_vbuk           = gs_data-vbuk
    EXCEPTIONS
      record_not_found = 1
      OTHERS           = 2.
  IF sy-subrc NE 0.
    " do nothing
  ENDIF.

ENDMETHOD.


METHOD read_vbup_data .

  REFRESH rt_vbup.

  CALL FUNCTION 'SD_VBUP_READ_WITH_VBELN'
    EXPORTING
      i_vbeln          = gs_data-vbeln
      i_refresh_buffer = 'X'
    TABLES
      et_vbup          = rt_vbup[]
    EXCEPTIONS
      record_not_found = 1
      OTHERS           = 2.
  IF sy-subrc EQ 0.
    SORT rt_vbup BY vbeln posnr.
  ENDIF.

ENDMETHOD.


METHOD reload_data .

  CALL METHOD read_item_data
    EXPORTING
      iv_vbeln           = gs_data-vbeln
      iv_posnr           = gs_data-posnr
      iv_pack_view       = iv_pack_view
    EXCEPTIONS
      delivery_not_found = 1
      item_not_found     = 2
      OTHERS             = 3.
  IF sy-subrc NE 0.
* Invalid Delivery/Item
    MESSAGE e202 RAISING invalid_data.
  ENDIF.

ENDMETHOD.


METHOD update_item_qty .

  DATA : ls_vbkok TYPE vbkok,
         ls_vbpok TYPE vbpok,
         ls_prott TYPE prott,
         lv_messg TYPE string,
         lt_vbpok TYPE TABLE OF vbpok,
         lv_subrc TYPE sy-subrc.

  REFRESH rt_prott.

  CLEAR ls_vbkok.
  ls_vbkok-vbeln_vl = gs_data-vbeln.

  CLEAR ls_vbpok.
  ls_vbpok-vbeln_vl = gs_data-vbeln.
  ls_vbpok-posnr_vl = gs_data-posnr.
  ls_vbpok-charg    = iv_charg.
  ls_vbpok-lianp = 'X'.
  ls_vbpok-lfimg = iv_item_qty.
* Begin of change / nparchu / CHG 118067 / 10/14/2010
* The flag kntz and kzbrg is used to blank out the gross weight and
* new weight values for a delivery . This is used for zero pick and
* also when the values need to be zeroed out for the non batch items .
* however this method is also used to update the value when there is a
* overpick and the delivery qty is to be updated to pick qty . the flag
* is made conditional , only to be populated when the batch is not
* populated.
if iv_charg IS INITIAL.                                     " CHG118067
  ls_vbpok-kzntg = 'X'.                                     " CHG115461
  ls_vbpok-kzbrg = 'X'.                                     " CHG115461
 ENDIF.                                                     " CHG118067
  ls_vbpok-gewei = 'LB'.                                    " CHG116665

  APPEND ls_vbpok TO lt_vbpok.

*  Call the WS_DELIVEY_UPDATE in Background to avoid the popup
*  information messages/displaying the messages on status bar
  sy-oncom = 'V'.

  CLEAR lv_subrc.
  CALL FUNCTION 'WS_DELIVERY_UPDATE'
    EXPORTING
      vbkok_wa      = ls_vbkok
      delivery      = ls_vbkok-vbeln_vl
    TABLES
      vbpok_tab     = lt_vbpok
      prot          = rt_prott
    EXCEPTIONS
      error_message = 1.
  lv_subrc = sy-subrc.

* After processing WS_DELIVERY_UPDATE setting sy-oncomm back to
* online transaction
  sy-oncom = 'T'.

  IF lv_subrc EQ 0.
    COMMIT WORK AND WAIT.
  ELSE.
    CLEAR ls_prott.
    ls_prott-msgno = sy-msgno.
    ls_prott-msgty = sy-msgty.
    ls_prott-msgid = sy-msgid.
    ls_prott-msgv1 = sy-msgv1.
    ls_prott-msgv2 = sy-msgv2.
    ls_prott-msgv3 = sy-msgv3.
    ls_prott-msgv4 = sy-msgv4.
    APPEND ls_prott TO rt_prott.
  ENDIF.

ENDMETHOD.


METHOD validate_dest_bin .

  DATA : lv_lgnum TYPE lgnum,
         lv_lgtyp TYPE lgtyp,
         lv_lgpla TYPE lgpla,
         ls_lagp  TYPE lagp.

  lv_lgnum = get_lgnum( ).
  lv_lgpla = get_dest_lgpla( ).
  lv_lgtyp = get_dest_lgtyp( ).

  SELECT SINGLE *
         FROM  lagp
         INTO  ls_lagp
         WHERE lgnum EQ lv_lgnum AND
               lgtyp EQ lv_lgtyp AND
               lgpla EQ lv_lgpla.
  IF sy-subrc NE 0.
    RAISE invalid_bin.
  ENDIF.

ENDMETHOD.
ENDCLASS.

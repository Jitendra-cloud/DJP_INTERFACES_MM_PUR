*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDL_U01440_STAT
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDL_U01440_STAT    .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

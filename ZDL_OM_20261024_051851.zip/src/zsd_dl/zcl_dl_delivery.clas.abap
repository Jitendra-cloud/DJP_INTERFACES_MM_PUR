CLASS zcl_dl_delivery DEFINITION
  PUBLIC
  CREATE PUBLIC .

*"* public components of class ZCL_DL_DELIVERY
*"* do not include other source files here!!!
  PUBLIC SECTION.
    TYPE-POOLS ibco2 .
    TYPE-POOLS zsdc .

    DATA gv_vbeln TYPE vbeln_vl .
    DATA gs_delv_data TYPE zdl_delivery_data_s READ-ONLY .
    DATA gs_item_data TYPE zdl_delivery_item_data_s READ-ONLY .


    METHODS constructor
      IMPORTING
        VALUE(iv_vbeln)     TYPE vbeln_vl
        VALUE(iv_pack_view) TYPE char1 OPTIONAL
      EXCEPTIONS
        invalid_data
        delivery_not_found
        hu_error .
    METHODS get_item_data
      IMPORTING
        !iv_posnr           TYPE posnr_vl OPTIONAL
      EXPORTING
        VALUE(es_item_data) TYPE zdl_delivery_item_data_s .
    METHODS read_delivery_data
      IMPORTING
        !iv_vbeln     TYPE vbeln_vl
        !iv_pack_view TYPE char1 OPTIONAL
      EXCEPTIONS
        delivery_not_found
        hu_error .
    METHODS get_picking_status
      RETURNING
        VALUE(rv_kostk) TYPE kostk .
    METHODS get_wm_movmt_status
      RETURNING
        VALUE(rv_lvstk) TYPE lvstk .
    METHODS get_lips_data
      RETURNING
        VALUE(rt_lips) TYPE tab_lips .
    METHODS get_likp_data
      RETURNING
        VALUE(rs_likp) TYPE likp .
    METHODS get_vbuk_data
      RETURNING
        VALUE(rs_vbuk) TYPE vbuk .
    METHODS get_vbup_data
      RETURNING
        VALUE(rt_vbup) TYPE vbup_t .
    METHODS get_vbfa_data
      RETURNING
        VALUE(rt_vbfa) TYPE vbfa_t .
    METHODS get_vblkk_data
      RETURNING
        VALUE(rs_vblkk) TYPE vblkk .
    METHODS get_vblkp_data
      RETURNING
        VALUE(rt_vblkp) TYPE tt_lfpvb .
    METHODS get_vbplk_data
      RETURNING
        VALUE(rt_vbplk) TYPE zdl_vbplk_tt .
    METHODS get_vbplp_data
      RETURNING
        VALUE(rt_vbplp) TYPE zdl_vbplp_tt .
    METHODS get_vbdkl_data
      RETURNING
        VALUE(rt_vbdkl) TYPE zdl_vbdkl_tab .
    METHODS get_vbdpl_data
      RETURNING
        VALUE(rt_vbdpl) TYPE zdl_vbdpl_tab .
    METHODS get_vbpls_data
      RETURNING
        VALUE(rt_vbpls) TYPE zdl_vbpls_tt .
    METHODS reload_data
      IMPORTING
        !iv_pack_view TYPE char1 DEFAULT ' ' .
    METHODS get_item_objects
      IMPORTING
        !iv_posnr          TYPE posnr_vl OPTIONAL
      RETURNING
        VALUE(et_item_obj) TYPE zdl_delivery_item_obj_t .
    METHODS get_lgnum
      RETURNING
        VALUE(rv_lgnum) TYPE lgnum .
    METHODS get_open_tanum
      RETURNING
        VALUE(rt_open_tanum) TYPE tt_tanum .
    METHODS get_conf_tanum
      RETURNING
        VALUE(rt_conf_tanum) TYPE tt_tanum .
    METHODS get_canc_tanum
      RETURNING
        VALUE(rt_canc_tanum) TYPE tt_tanum .
    CLASS-METHODS check_delivery_lock
      IMPORTING
        !iv_vbeln     TYPE vbeln_vl
        !iv_num_times TYPE numc2 OPTIONAL
        !iv_wait_time TYPE numc2 OPTIONAL
      EXPORTING
        !iv_uname     TYPE sy-msgv1
      EXCEPTIONS
        delivery_locked .
    CLASS-METHODS check_hu_lock
      IMPORTING
        !iv_exidv     TYPE exidv
        !iv_num_times TYPE numc2 OPTIONAL
        !iv_wait_time TYPE numc2 OPTIONAL
      EXPORTING
        !ev_uname     TYPE sy-msgv1
      EXCEPTIONS
        hu_locked
        hu_not_found .
    METHODS get_door
      RETURNING
        VALUE(rv_lgtor) TYPE lgtor .
    METHODS get_staging_area
      RETURNING
        VALUE(rv_lgbzo) TYPE lgbzo .
    METHODS get_vbtyp
      RETURNING
        VALUE(rv_vbtyp) TYPE vbtyp .
    CLASS-METHODS save_delivery
      IMPORTING
        !is_vbkok                     TYPE vbkok
        !iv_synchron                  TYPE rvsel-xfeld OPTIONAL
        !iv_no_messages_update        TYPE rvsel-xfeld OPTIONAL
        !iv_commit                    TYPE rvsel-xfeld OPTIONAL
        !iv_update_picking            TYPE rvsel-xfeld OPTIONAL
        !iv_nicht_sperren             TYPE rvsel-no_sp OPTIONAL
        !iv_if_confirm_central        TYPE rvsel-xfeld OPTIONAL
        !iv_if_wmpp                   TYPE rvsel-xfeld OPTIONAL
        !iv_if_get_delivery_buffered  TYPE rvsel-xfeld OPTIONAL
        !iv_no_generic_system_service TYPE rvsel-xfeld OPTIONAL
        !iv_if_database_update        TYPE leshp_database_update OPTIONAL
        !iv_if_no_init                TYPE xfeld OPTIONAL
        !iv_if_no_read                TYPE xfeld OPTIONAL
        !iv_if_error_messages_send_0  TYPE xfeld OPTIONAL
        !iv_if_no_buffer_refresh      TYPE v50agl_no_buffer_refresh OPTIONAL
        !iv_it_partner_update         TYPE shp_partner_update_t OPTIONAL
        !iv_it_sernr_update           TYPE shp_sernr_update_t OPTIONAL
        !iv_if_no_remote_chg          TYPE rvsel-xfeld OPTIONAL
        !iv_if_no_mes_upd_pack        TYPE v50agl_no_mes_upd_pack OPTIONAL
        !iv_if_late_delivery_upd      TYPE xfeld OPTIONAL
      EXPORTING
        !et_applog                    TYPE zca_bal_msg_tab
      CHANGING
        VALUE(et_vbpok_tab)           TYPE tt_vbpok OPTIONAL
        VALUE(et_prot)                TYPE tab_prott OPTIONAL
        VALUE(et_verko_tab)           TYPE tab_verko OPTIONAL
        VALUE(et_verpo_tab)           TYPE tab_verpo OPTIONAL
        VALUE(et_vbsupcon_tab)        TYPE tab_vbsupcon OPTIONAL
        VALUE(et_verpo_sernr)         TYPE tab_hum_verpo_sernr OPTIONAL
        VALUE(et_packing)             TYPE tab_repack_hu_wm OPTIONAL
        VALUE(et_packing_sernr)       TYPE tab_hum_rep_sernr OPTIONAL
        VALUE(et_repack)              TYPE tab_hum_repack OPTIONAL
        VALUE(et_handling_units)      TYPE tab_hum_rehang_hu OPTIONAL
        VALUE(et_objects)             TYPE lepgr_objects OPTIONAL
        VALUE(et_created_hus)         TYPE vekpvb_tab OPTIONAL
        VALUE(et_tvpod_tab)           TYPE vlc_tvpodvb_t OPTIONAL
        VALUE(et_sernr_tab)           TYPE vlc_vlser_t OPTIONAL
        VALUE(et_hures)               TYPE isauto_verpo_hures_t OPTIONAL
      EXCEPTIONS
        delivery_locked
        delivery_update_fail .
    CLASS-METHODS pack_su_from_hu
      IMPORTING
        !iv_lgnum        TYPE lgnum
        !iv_sto_del      TYPE char1 OPTIONAL
        !it_tanum_tapos  TYPE zdl_wm_pack_t
      EXPORTING
        VALUE(et_prot)   TYPE tab_prott
        VALUE(et_return) TYPE tt_bapiret2
        !et_applog       TYPE zca_bal_msg_tab
      EXCEPTIONS
        delivery_update_fail
        delivery_locked
        to_item_del_level_pack_fail .
    CLASS-METHODS get_lock_wait_times
      IMPORTING
        !iv_category  TYPE zcatgory
      EXPORTING
        !ev_num_times TYPE numc2
        !ev_wait_time TYPE numc2 .
    METHODS get_tot_net_picked_wght
      EXPORTING
        !ev_tot_net_wt TYPE kcntgew
        !ev_meins      TYPE meins .
    METHODS get_tot_gross_picked_wght
      EXPORTING
        !ev_tot_gross_wt TYPE kcbrgew
        !ev_meins        TYPE meins .
    CLASS-METHODS set_message_buffer
      RETURNING
        VALUE(es_applog) TYPE bal_s_msg .
    METHODS get_metric_ind
      RETURNING
        VALUE(rv_metric_ind) TYPE zsde3607_metric_indicator .
    CLASS-METHODS check_add_new_hu
      IMPORTING
        VALUE(iv_exidv) TYPE exidv OPTIONAL
      EXPORTING
        !ev_exidv       TYPE exidv .
    CLASS-METHODS determine_msh_weight
      IMPORTING
        VALUE(is_ltap) TYPE ltap OPTIONAL
      EXPORTING
        !es_vbpok      TYPE vbpok .
    CLASS-METHODS pack_su_from_hu_new
      IMPORTING
        !iv_lgnum       TYPE lgnum OPTIONAL
        !iv_sto_del     TYPE char1 OPTIONAL
        !it_tanum_tapos TYPE zdl_wm_pack_t OPTIONAL
      EXPORTING
        !et_prot        TYPE tab_prott
        !et_return      TYPE tt_bapiret2
        !et_applog      TYPE zca_bal_msg_tab .
    CLASS-METHODS delete_duplicate_batch
      CHANGING
        !ct_ltap TYPE tt_ltap .
    CLASS-METHODS save_delivery_new
      IMPORTING
        !is_vbkok                     TYPE vbkok OPTIONAL
        !iv_synchron                  TYPE rvsel-xfeld OPTIONAL
        !iv_no_messages_update        TYPE rvsel-xfeld OPTIONAL
        !iv_commit                    TYPE rvsel-xfeld OPTIONAL
        !iv_update_picking            TYPE rvsel-xfeld OPTIONAL
        !iv_nicht_sperren             TYPE rvsel-no_sp OPTIONAL
        !iv_if_confirm_central        TYPE rvsel-xfeld OPTIONAL
        !iv_if_wmpp                   TYPE rvsel-xfeld OPTIONAL
        !iv_if_get_delivery_buffered  TYPE rvsel-xfeld OPTIONAL
        !iv_no_generic_system_service TYPE rvsel-xfeld OPTIONAL
        !iv_if_database_update        TYPE leshp_database_update OPTIONAL
        !iv_if_no_init                TYPE xfeld OPTIONAL
        !iv_if_no_read                TYPE xfeld OPTIONAL
        !iv_if_error_messages_send_0  TYPE xfeld OPTIONAL
        !iv_if_no_buffer_refresh      TYPE v50agl_no_buffer_refresh OPTIONAL
        !iv_it_partner_update         TYPE shp_partner_update_t OPTIONAL
        !iv_it_sernr_update           TYPE shp_sernr_update_t OPTIONAL
        !iv_if_no_remote_chg          TYPE rvsel-xfeld OPTIONAL
        !iv_if_no_mes_upd_pack        TYPE v50agl_no_mes_upd_pack OPTIONAL
        !iv_if_late_delivery_upd      TYPE xfeld OPTIONAL
      EXPORTING
        !et_applog                    TYPE zca_bal_msg_tab
      CHANGING
        VALUE(et_vbpok_tab)           TYPE tt_vbpok OPTIONAL
        VALUE(et_prot)                TYPE tab_prott OPTIONAL
        VALUE(et_verko_tab)           TYPE tab_verko OPTIONAL
        VALUE(et_verpo_tab)           TYPE tab_verpo OPTIONAL
        VALUE(et_vbsupcon_tab)        TYPE tab_vbsupcon OPTIONAL
        VALUE(et_verpo_sernr)         TYPE tab_hum_verpo_sernr OPTIONAL
        VALUE(et_packing)             TYPE tab_repack_hu_wm OPTIONAL
        VALUE(et_packing_sernr)       TYPE tab_hum_rep_sernr OPTIONAL
        VALUE(et_repack)              TYPE tab_hum_repack OPTIONAL
        VALUE(et_handling_units)      TYPE tab_hum_rehang_hu OPTIONAL
        VALUE(et_objects)             TYPE lepgr_objects OPTIONAL
        VALUE(et_created_hus)         TYPE vekpvb_tab OPTIONAL
        VALUE(et_tvpod_tab)           TYPE vlc_tvpodvb_t OPTIONAL
        VALUE(et_sernr_tab)           TYPE vlc_vlser_t OPTIONAL
        VALUE(et_hures)               TYPE isauto_verpo_hures_t OPTIONAL
      EXCEPTIONS
        delivery_locked
        delivery_update_fail .
    CLASS-METHODS check_hu_status_lock
      IMPORTING
        VALUE(iv_current_su) TYPE lenum OPTIONAL
      EXCEPTIONS
        hu_locked .
    CLASS-METHODS pick_missing_batch
      IMPORTING
        VALUE(it_xlips)      TYPE shp_lips_t
        VALUE(update_flag)   TYPE flag OPTIONAL
        VALUE(iv_class_name) TYPE symsgv OPTIONAL
      EXPORTING
        VALUE(et_xlips)      TYPE shp_lips_t .
  PROTECTED SECTION.
*"* protected components of class ZCL_DL_DELIVERY
*"* do not include other source files here!!!
  PRIVATE SECTION.
*"* private components of class ZCL_DL_DELIVERY
*"* do not include other source files here!!!

    DATA gt_item_info TYPE gt_item_info .
    CLASS-DATA gv_del_times TYPE num2 .
    CLASS-DATA gv_del_wait TYPE num2 .
    CLASS-DATA gv_messg TYPE string .
    CLASS-DATA gt_applog TYPE REF TO zca_bal_msg_tab .
    CLASS-DATA gt_return TYPE REF TO bapiret2_t .

    METHODS read_vbup_data .
    METHODS read_vbuk_data .
    METHODS read_vbfa_data .
    METHODS read_tanum_data .
    METHODS read_packing_data .
    METHODS read_likp_lips_data
      IMPORTING
        !iv_vbeln TYPE vbeln_vl
      EXCEPTIONS
        delivery_not_found
        hu_error .
    CLASS-METHODS handle_applog_message .
    CLASS-METHODS handle_message .
ENDCLASS.



CLASS ZCL_DL_DELIVERY IMPLEMENTATION.


  METHOD check_add_new_hu.
***********************************************************************
***********************************************************************
**                                                                    *
**             C O M P A N Y   C O N F I D E N T I A L                *
**                                                                    *
**        This program is the property of International Paper.        *
**        Care should be taken to pervent its unauthorized use.       *
**                                                                    *
***********************************************************************
***********************************************************************
**                                                                    *
**                    COPYRIGHT (C) 2018 by                           *
**                     INTERNATIONAL PAPER                            *
**                                                                    *
**                     ALL RIGHTS RESERVED                            *
**                                                                    *
**                   REVISIONS COPYRIGHT (C)                          *
**                                20XX                                *
**                             by                                     *
**                     INTERNATIONAL PAPER                            *
***********************************************************************
*_____________________________________________________________________*
* Program Name:CHECK_ADD_NEW_HU                                       *
*                                                                     *
*                                              Creation   : 12/28/2018*
*                                                                     *
* SAP Name    :ZDL_E11424_EXP_SHP_ASN_DEF      Version    : Initial   *
*                                                                     *
* Programmer  :JWILL68                           Last Update:         *
*_____________________________________________________________________*
* Description: Include for implemeting the local class methods        *
*_____________________________________________________________________*
* Change History:                                                     *
*  Programmer     Date    CMS. #                  Action              *
* ============ ======== ========= ====================================*
* JWILL68       12/28/2018  32732   Initial Transport                 *
***********************************************************************
* Local data declaration.
    DATA: lv_hu_add TYPE char27 VALUE '0ABCDEFGHIJKLMNOPQRSTUVWXYZ'.

    CONSTANTS: lc_status TYPE hu_status VALUE '0060'.

* Initialize exporting parameter.
    CLEAR ev_exidv.

    DATA(lv_exidv_add) = iv_exidv.
    DATA(lv_index) = 0.
* Check for the External Handling Unit Identification in VEKP table.
    DO 15 TIMES.
* Check if the HU exist.
      SELECT  SINGLE exidv
        FROM vekp
        INTO @DATA(lv_exidv)
        WHERE exidv = @lv_exidv_add AND
              status <> @lc_status.
      IF sy-subrc = 0.
        lv_index = lv_index + 1.
        lv_exidv_add = |{ iv_exidv }{ lv_hu_add+lv_index(1) }|.
* Check if the HU exist.
        SELECT  SINGLE exidv
          FROM vekp
          INTO @lv_exidv
          WHERE exidv = @lv_exidv_add AND
                status <> @lc_status.
        IF sy-subrc = 0.
          lv_index = lv_index + 1.
          lv_exidv_add = |{ iv_exidv }{ lv_hu_add+lv_index(1) }|.
        ELSE.
          ev_exidv = lv_exidv_add.
          EXIT.
        ENDIF. " sy-subrc
      ELSE.
        ev_exidv = lv_exidv_add.
        EXIT.
      ENDIF. " sy-subrc
    ENDDO.

  ENDMETHOD.


  METHOD check_delivery_lock .

    DATA : lv_userid    TYPE sy-msgv1,
           lv_subrc     TYPE sysubrc VALUE 4,
           lv_num_times TYPE i,
           lv_wait_time TYPE i.

    IF iv_num_times IS INITIAL.
      lv_num_times = 1.
    ELSE.
      lv_num_times = iv_num_times.
    ENDIF.

    IF iv_wait_time IS INITIAL.
      lv_wait_time = 1.
    ELSE.
      lv_wait_time = iv_wait_time.
    ENDIF.

    DO lv_num_times TIMES.
      CALL FUNCTION 'ENQUEUE_EVVBLKE'
        EXPORTING
          mode_likp      = 'E'
          mandt          = sy-mandt
          vbeln          = iv_vbeln " Delivery num
          _scope         = '2'
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc = 0.
        lv_subrc = sy-subrc.
        EXIT.
      ELSE.
        lv_userid = sy-msgv1.
        WAIT UP TO lv_wait_time SECONDS.
      ENDIF.
    ENDDO.

    IF lv_subrc = 0.
*   Unlock the delivery
      CALL FUNCTION 'DEQUEUE_EVVBLKE'
        EXPORTING
          mode_likp = 'E'
          mandt     = sy-mandt
          vbeln     = iv_vbeln " Delivery num
          _scope    = '3'.
    ELSE.

*** Start changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779
      iv_uname  = lv_userid.
*** End changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779

* Delivery & is locked by the user &.
      MESSAGE e220 WITH iv_vbeln lv_userid RAISING delivery_locked.

    ENDIF.

  ENDMETHOD.


  METHOD check_hu_lock.

    DATA : lv_userid    TYPE sy-msgv1,
           lv_subrc     TYPE sysubrc VALUE 4,
           lv_num_times TYPE i,
           lv_wait_time TYPE i.

    IF iv_num_times IS INITIAL.
      lv_num_times = 1.
    ELSE.
      lv_num_times = iv_num_times.
    ENDIF.

    IF iv_wait_time IS INITIAL.
      lv_wait_time = 1.
    ELSE.
      lv_wait_time = iv_wait_time.
    ENDIF.

    SELECT SINGLE venum FROM vekp INTO @DATA(lv_venum)
      WHERE exidv = @iv_exidv.
    IF sy-subrc NE 0.
      RAISE hu_not_found.
    ENDIF.

*RAISE or not to RAISE
    DO lv_num_times TIMES.

      CALL FUNCTION 'ENQUEUE_EVVEKPE'
        EXPORTING
          mode_vekp      = 'E'
          mandt          = sy-mandt
          venum          = lv_venum
*         X_VENUM        = ' '
          _scope         = '2'
*         _WAIT          = ' '
*         _COLLECT       = ' '
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc = 0.
        lv_subrc = sy-subrc.
        EXIT.
      ELSE.
        lv_userid = sy-msgv1.
        WAIT UP TO lv_wait_time SECONDS.
      ENDIF.
    ENDDO.

    IF lv_subrc = 0.
*   Unlock the HU

      CALL FUNCTION 'DEQUEUE_EVVEKPE'
        EXPORTING
          mode_vekp = 'E'
          mandt     = sy-mandt
          venum     = lv_venum
*         X_VENUM   = ' '
          _scope    = '3'
*         _SYNCHRON = ' '
*         _COLLECT  = ' '
        .
    ELSE.

      ev_uname  = lv_userid.

* Delivery & is locked by the user &. ??????
      MESSAGE e237 WITH lv_venum lv_userid RAISING hu_locked.
*       Add new raise

    ENDIF.
  ENDMETHOD.


  METHOD check_hu_status_lock.
**********************************************************************
***********************************************************************
**                                                                    *
**             C O M P A N Y   C O N F I D E N T I A L                *
**                                                                    *
**        This program is the property of International Paper.        *
**        Care should be taken to pervent its unauthorized use.       *
**                                                                    *
***********************************************************************
***********************************************************************
**                                                                    *
**                    COPYRIGHT (C) 2019 by                           *
**                     INTERNATIONAL PAPER                            *
**                                                                    *
**                     ALL RIGHTS RESERVED                            *
**                                                                    *
**                   REVISIONS COPYRIGHT (C)                          *
**                                20XX                                *
**                             by                                     *
**                     INTERNATIONAL PAPER                            *
***********************************************************************
*_____________________________________________________________________*
* Program Name:CHECK_HU_STATUS_LOCK                                       *
*                                                                     *
*                                              Creation   : 04/22/2019*
*                                                                     *
* SAP Name    :                                Version    : Initial   *
*                                                                     *
* Programmer  :afulwar                         Last Update:           *
*_____________________________________________________________________*
* Description: Include for implemeting the local class methods        *
*_____________________________________________________________________*
************************************************************************
* Change History:                                                      *
*     Programmer        Date          Req. #          Action           *
* ==================  ========       ======    ======================  *
*  Aditya Fulwaria    04/22/2019     CD#1525         New method        *
*                                              Check HU status and lock*
*                                                                      *
************************************************************************


    IF iv_current_su IS NOT INITIAL.

*Selecting Handling Unit on the basis of SU which user entered on 9011 screen lm01 tcode.
      SELECT venum
        FROM vekp
     INTO TABLE @DATA(lt_vekp)
         WHERE exidv EQ @iv_current_su AND
        NOT ( status = '0060' OR status = '0050' OR status = '0040')
        ORDER BY venum DESCENDING.


* Checking if the entry is locked under any user.
      IF sy-subrc  = '0'.

        READ TABLE lt_vekp INTO DATA(ls_vekp) INDEX 1.

        CALL FUNCTION 'ENQUEUE_EVVEKPE'
          EXPORTING
            mode_vekp      = 'E'
*           mandt          =
            venum          = ls_vekp-venum
*           X_VENUM        = ' '
            _scope         = '2'
*           _WAIT          = ' '
*           _COLLECT       = ' '
          EXCEPTIONS
            foreign_lock   = 1
            system_failure = 2
            OTHERS         = 3.

* Raising exception HU locked
        IF sy-subrc NE '0'.
          RAISE hu_locked.
        ELSE.
*Unlocking the record
          CALL FUNCTION 'DEQUEUE_EVVEKPE'
            EXPORTING
              mode_vekp = 'E'
*             mandt     = sy-mandt
              venum     = ls_vekp-venum
*             X_VENUM   = ' '
              _scope    = '3'
*             _SYNCHRON = ' '
*             _COLLECT  = ' '
            .

        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD constructor .

    IF iv_vbeln IS INITIAL.
* Invalid input
      MESSAGE e203 RAISING invalid_data.
    ENDIF.

    CALL METHOD read_delivery_data
      EXPORTING
        iv_vbeln           = iv_vbeln
        iv_pack_view       = iv_pack_view
      EXCEPTIONS
        delivery_not_found = 1
        hu_error           = 2
        OTHERS             = 3.
    CASE sy-subrc.
      WHEN 0. " No action required.
      WHEN 2.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                RAISING hu_error.
      WHEN OTHERS.
* Delivery & not found
        MESSAGE e200 RAISING delivery_not_found.
    ENDCASE.

  ENDMETHOD.


  METHOD delete_duplicate_batch.
***********************************************************************
***********************************************************************
**                                                                    *
**             C O M P A N Y   C O N F I D E N T I A L                *
**                                                                    *
**        This program is the property of International Paper.        *
**        Care should be taken to pervent its unauthorized use.       *
**                                                                    *
***********************************************************************
***********************************************************************
**                                                                    *
**                    COPYRIGHT (C) 2018 by                           *
**                     INTERNATIONAL PAPER                            *
**                                                                    *
**                     ALL RIGHTS RESERVED                            *
**                                                                    *
**                   REVISIONS COPYRIGHT (C)                          *
**                                20XX                                *
**                             by                                     *
**                     INTERNATIONAL PAPER                            *
***********************************************************************
*_____________________________________________________________________*
* Program Name:CHECK_ADD_NEW_HU                                       *
*                                                                     *
*                                              Creation   : 12/28/2018*
*                                                                     *
* SAP Name    :DELETE_DUPLICATE_BATCH          Version    : Initial   *
*                                                                     *
* Programmer  :JWILL68                           Last Update:         *
*_____________________________________________________________________*
* Description: Include for implemeting the local class methods        *
*_____________________________________________________________________*
* Change History:                                                     *
*  Programmer     Date    CMS. #                  Action              *
* ============ ======== ========= ====================================*
* JWILL68       12/28/2018  32732   Initial Transport                 *
***********************************************************************
    TYPES ty_t_tanum_range TYPE RANGE OF tanum.
* Chek the LTAB is not initial
    CHECK ct_ltap IS NOT INITIAL.

*   get range table for all the key fields.
    DATA(lt_lgnum_range) = VALUE shp_lgnum_range_t( FOR ls_lgnum IN ct_ltap
                                                    ( sign   = 'I'
                                                      option = 'EQ'
                                                      low    = ls_lgnum-lgnum ) ).

    DATA(lt_tanum_range) = VALUE ty_t_tanum_range( FOR ls_lgnum IN ct_ltap
                                                    ( sign   = 'I'
                                                      option = 'EQ'
                                                      low    = ls_lgnum-tanum ) ).


* Get the values in the ra
* read the LTAB table with hight number of Item number.
    SELECT lgnum,
           tanum,
           charg,
           MAX( tapos ) AS highest_tapos
      FROM ltap
      INTO TABLE @DATA(lt_ltab)
      WHERE lgnum IN @lt_lgnum_range AND
            tanum IN @lt_tanum_range
         GROUP BY lgnum, tanum, charg.
    IF sy-subrc = 0.
      SORT lt_ltab BY lgnum ASCENDING
                      tanum ASCENDING
                      charg ASCENDING.

* Loop through the changing LTAB table and read the local LTAB table.
* Delete the record which is not found in reading the table.
      LOOP AT ct_ltap INTO DATA(ls_latp).
* Check if line exits in the local table. If not,then delete the record from the
* changing table.
        IF line_exists( lt_ltab[ lgnum         = ls_latp-lgnum
                                 tanum         = ls_latp-tanum
                                 highest_tapos = ls_latp-tapos
                                 charg         = ls_latp-charg ] ).
        ELSE.
          DELETE TABLE ct_ltap FROM ls_latp.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


  METHOD determine_msh_weight.
***********************************************************************
***********************************************************************
**                                                                    *
**             C O M P A N Y   C O N F I D E N T I A L                *
**                                                                    *
**        This program is the property of International Paper.        *
**        Care should be taken to pervent its unauthorized use.       *
**                                                                    *
***********************************************************************
***********************************************************************
**                                                                    *
**                    COPYRIGHT (C) 2018 by                           *
**                     INTERNATIONAL PAPER                            *
**                                                                    *
**                     ALL RIGHTS RESERVED                            *
**                                                                    *
**                   REVISIONS COPYRIGHT (C)                          *
**                                20XX                                *
**                             by                                     *
**                     INTERNATIONAL PAPER                            *
***********************************************************************
*_____________________________________________________________________*
* Program Name:CHECK_ADD_NEW_HU                                       *
*                                                                     *
*                                              Creation   : 12/28/2018*
*                                                                     *
* SAP Name    :DETERMINE_MSH_WEIGHT            Version    : Initial   *
*                                                                     *
* Programmer  :JWILL68                           Last Update:         *
*_____________________________________________________________________*
* Description: Include for implemeting the local class methods        *
*_____________________________________________________________________*
* Change History:                                                     *
*  Programmer     Date    CMS. #                  Action              *
* ============ ======== ========= ====================================*
* JWILL68       12/28/2018  32732   Initial Transport                 *
***********************************************************************

* Check Alternative Unit of Measure for Stockkeeping Unit is MSHEET (MSH)
* and Storage Unit Type should be SKID
    CHECK is_ltap-altme = 'MSH' AND
          is_ltap-letyp = 'SKD'.

* Initialize exporting parameter
    CLEAR: es_vbpok.

* Retrive data from LIPS
    SELECT SINGLE *
      FROM lips
      INTO @DATA(ls_lips)
      WHERE vbeln = @is_ltap-vbeln AND
            posnr = @is_ltap-posnr AND
            charg = @is_ltap-charg.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

*Compare Source target quantity in alternate unit and Actual quantity delivered
    IF is_ltap-vsola <> ls_lips-lfimg.
      es_vbpok = VALUE #( vbeln_vl = is_ltap-vbeln
                          posnr_vl = is_ltap-posnr
                          matnr = is_ltap-matnr
                          werks = is_ltap-werks
                          charg = is_ltap-charg
                          lianp = abap_true
                          lfimg = is_ltap-vsola
                          vrkme = is_ltap-altme
                          lgmng = is_ltap-nistm
                          ntgew = is_ltap-nistm
                          gewei = is_ltap-gewei ).
    ENDIF.
  ENDMETHOD.


  METHOD get_canc_tanum .

    REFRESH rt_canc_tanum.

    rt_canc_tanum[] = gs_delv_data-canc_tanum[].

  ENDMETHOD.


  METHOD get_conf_tanum .

    REFRESH rt_conf_tanum.

    rt_conf_tanum[] = gs_delv_data-conf_tanum[].

  ENDMETHOD.


  METHOD get_door .

    CLEAR rv_lgtor.

    rv_lgtor = gs_delv_data-likp-lgtor.

  ENDMETHOD.


  METHOD get_item_data .

    DATA : ls_lips  TYPE lips,
           ls_vblkp TYPE lfpvb,
           ls_vbup  TYPE vbup,
           ls_vbfa  TYPE vbfa,
           ls_vbdpl TYPE vbdpl,
           ls_vbplk TYPE vbplk,
           ls_vbplp TYPE vbplp,
           ls_ltak  TYPE ltak,
           ls_ltap  TYPE ltap,
           ls_tanum TYPE tanum.

    IF gs_item_data IS NOT INITIAL AND gs_item_data-posnr EQ iv_posnr.
      es_item_data = gs_item_data.
      RETURN.
    ENDIF.

    CLEAR gs_item_data.

    gs_item_data-vbeln = gs_delv_data-vbeln.
    gs_item_data-posnr = iv_posnr.

    gs_item_data-likp = gs_delv_data-likp.
    LOOP AT gs_delv_data-lips[]  INTO  ls_lips
                                 WHERE posnr EQ iv_posnr OR
                                       uecha EQ iv_posnr.
      APPEND ls_lips TO gs_item_data-lips[].

      CLEAR ls_vbup.
      READ TABLE gs_delv_data-vbup[] INTO ls_vbup
                                     WITH KEY posnr = ls_lips-posnr.
      IF sy-subrc EQ 0.
        APPEND ls_vbup TO gs_item_data-vbup[].
      ENDIF.

      LOOP AT gs_delv_data-vbfa[] INTO ls_vbfa
                                     WHERE posnv EQ ls_lips-posnr AND
                                           vbtyp_n EQ 'Q'.
        APPEND ls_vbfa TO gs_item_data-vbfa[].
        ls_tanum = ls_vbfa-vbeln.
        IF ls_vbfa-taqui EQ 'X'.
          IF ls_vbfa-rfmng IS INITIAL.
            COLLECT ls_tanum INTO gs_item_data-canc_tanum[].
          ELSE.
            COLLECT ls_tanum INTO gs_item_data-conf_tanum[].
          ENDIF.
        ELSE.
          COLLECT ls_tanum INTO gs_item_data-open_tanum[].
        ENDIF.
        COLLECT ls_tanum INTO gs_item_data-all_tanum[].
      ENDLOOP.

* Document Item View for Delivery Note
      CLEAR ls_vbdpl.
      READ TABLE gs_delv_data-vbdpl[] INTO ls_vbdpl
                                      WITH KEY posnr = ls_lips-posnr.
      IF sy-subrc EQ 0.
        APPEND ls_vbdpl TO gs_item_data-vbdpl[].
      ENDIF.

*  Handling-Unit Content Data
      CLEAR ls_vbplp.
      READ TABLE gs_delv_data-vbplp[] INTO ls_vbplp
                                      WITH KEY posnr = ls_lips-posnr.
      IF sy-subrc EQ 0.
        APPEND ls_vbplp TO gs_item_data-vbplp[].

* * Handling Unit Header-Data
        CLEAR ls_vbplk.
        READ TABLE gs_delv_data-vbplk[] INTO ls_vbplk
                                        WITH KEY venum = ls_vbplp-venum.
        IF sy-subrc EQ 0.
          APPEND ls_vbplk TO gs_item_data-vbplk[].
        ENDIF.
      ENDIF.
    ENDLOOP.

* Document Header View for Delivery Note
    gs_item_data-vbdkl[] = gs_delv_data-vbdkl[].

* Summary Data Packing
    gs_item_data-vbpls[] = gs_delv_data-vbpls[].

    gs_item_data-vblkk = gs_delv_data-vblkk.

    LOOP AT gs_delv_data-vblkp[] INTO  ls_vblkp
                                 WHERE posnr EQ iv_posnr OR
                                       uecha EQ iv_posnr.
      APPEND ls_vblkp TO gs_item_data-vblkp[].
    ENDLOOP.

    gs_item_data-vbuk = gs_delv_data-vbuk.

    es_item_data = gs_item_data.

  ENDMETHOD.


  METHOD get_item_objects .

    DATA : ls_item_obj      TYPE zdl_delivery_item_obj_s,
           lt_item_obj      TYPE zdl_delivery_item_obj_t,
           ls_item_data     TYPE zdl_delivery_item_data_s,
           lo_delivery_item TYPE REF TO zcl_dl_delivery_item,
           ls_lips          TYPE lips,
           lt_posnr         TYPE wb2_posnr_vl_stab,
           ls_posnr         TYPE posnr_vl.

* In case of POSNR requested,
    IF iv_posnr IS NOT INITIAL.
      ls_posnr = iv_posnr.
*->Begin Chg/MAIELY/CD2000010003 Resolving the LIPS Sorting issue
*      APPEND ls_posnr TO lt_posnr.
      INSERT ls_posnr INTO TABLE lt_posnr.
*-<End Chg/MAIELY/CD2000010003 Resolving the LIPS Sorting issue
    ELSE.
* Else, create objects for all the POSNRs
      LOOP AT gs_delv_data-lips[] INTO ls_lips WHERE uecha IS INITIAL.
        CLEAR ls_posnr.
        ls_posnr = ls_lips-posnr.
*->Begin Chg/MAIELY/CD2000010003 Resolving the LIPS Sorting issue
*        APPEND ls_posnr TO lt_posnr.
        INSERT ls_posnr INTO TABLE lt_posnr.
*-<End Chg/MAIELY/CD2000010003 Resolving the LIPS Sorting issue
      ENDLOOP.
    ENDIF.

    LOOP AT lt_posnr INTO ls_posnr.
      CALL METHOD get_item_data
        EXPORTING
          iv_posnr     = ls_posnr
        IMPORTING
          es_item_data = ls_item_data.

      CREATE OBJECT lo_delivery_item
        EXPORTING
          iv_vbeln     = gv_vbeln
          iv_posnr     = ls_posnr
          is_item_data = gs_item_data.

      ls_item_obj-vbeln = gv_vbeln.
      ls_item_obj-posnr = ls_posnr.
      ls_item_obj-item_object = lo_delivery_item.
      APPEND ls_item_obj TO et_item_obj.
    ENDLOOP.

  ENDMETHOD.


  METHOD get_lgnum .

    CLEAR rv_lgnum.
    rv_lgnum = gs_delv_data-likp-lgnum.

  ENDMETHOD.


  METHOD get_likp_data .

    CLEAR rs_likp.

    rs_likp = gs_delv_data-likp.

  ENDMETHOD.


  METHOD get_lips_data .

    REFRESH rt_lips.

    rt_lips[] = gs_delv_data-lips[].

  ENDMETHOD.


  METHOD get_lock_wait_times .
    DATA : lt_zdl_fields TYPE STANDARD TABLE OF zdl_fields,
           ls_zdl_fields TYPE zdl_fields.

    SELECT * FROM zdl_fields
     INTO TABLE lt_zdl_fields
     WHERE category  = iv_category.

    CLEAR ls_zdl_fields.
    READ TABLE lt_zdl_fields INTO ls_zdl_fields
                             WITH KEY fieldname = 'WM_DEL_WAIT_TIME'.
    IF sy-subrc EQ 0.
      ev_wait_time = ls_zdl_fields-lowval.
    ELSE.
      ev_wait_time = 0.
    ENDIF.

    CLEAR ls_zdl_fields.
* Logic added for calling above wait time in loops - CR#9253
    READ TABLE lt_zdl_fields INTO ls_zdl_fields
                             WITH KEY fieldname = 'WM_DEL_TIMES'.
    IF sy-subrc EQ 0.
      ev_num_times = ls_zdl_fields-lowval.
    ELSE.
      ev_num_times = 1.
    ENDIF.
  ENDMETHOD.


  METHOD get_metric_ind .

    TYPES : BEGIN OF tt_ekkn_lips,
              vgbel TYPE ebeln,
              vgpos TYPE ebelp,                              " NUMC 5
            END   OF tt_ekkn_lips,
            BEGIN OF tt_ekko,
              ebeln   TYPE ebeln,
              bsart   TYPE bsart,
              zzvbeln TYPE vbeln,
              zzposnr TYPE posnr,
            END   OF tt_ekko,
            BEGIN OF tt_ekpo,
              ebeln TYPE ebeln,
              ebelp TYPE ebelp,
            END   OF tt_ekpo,
            BEGIN OF tt_ekkn,
              ebeln TYPE ebeln,
              ebelp TYPE ebelp,
              vbeln TYPE vbeln,
              vbelp TYPE vbelp,
            END   OF tt_ekkn,
            BEGIN OF tt_vbak,
              vbeln TYPE vbeln,
            END   OF tt_vbak,
            BEGIN OF tt_vbap,
              vbeln      TYPE vbeln,
              posnr      TYPE posnr,
              metric_ind TYPE zsde3607_metric_indicator,
            END   OF tt_vbap.

    DATA  : lt_vbak      TYPE TABLE OF tt_vbak,
            lt_vbap      TYPE TABLE OF tt_vbap,
            ls_vbap      TYPE          tt_vbap,
            lt_ekko      TYPE TABLE OF tt_ekko,
            ls_ekko      TYPE          tt_ekko,
            lt_ekko_1    TYPE TABLE OF tt_ekko,
            lt_ekpo      TYPE TABLE OF tt_ekpo,
            lt_ekkn      TYPE TABLE OF tt_ekkn,
            ls_ekkn      TYPE          tt_ekkn,
            lt_ekkn_1    TYPE TABLE OF tt_ekkn,
            lt_ekkn_lips TYPE TABLE OF tt_ekkn_lips,
            ls_ekkn_lips TYPE          tt_ekkn_lips.

    DATA  : lt_lips     TYPE TABLE OF lips,
            lt_lips_1   TYPE TABLE OF lips,
            ls_lips     TYPE          lips,
            lv_so_vbeln TYPE          vbeln,
            lv_so_posnr TYPE          posnr.


    CALL METHOD get_lips_data
      RECEIVING
        rt_lips = lt_lips.

    lt_lips_1[] = lt_lips[].
    SORT lt_lips_1 BY vgbel.
    DELETE ADJACENT DUPLICATES FROM lt_lips_1 COMPARING vgbel vgpos.

    IF lt_lips_1[] IS NOT INITIAL.
* >> Getting required data from VBAK
      SELECT vbeln
             INTO TABLE lt_vbak
             FROM vbak
             FOR ALL ENTRIES IN lt_lips_1
             WHERE vbeln EQ lt_lips_1-vgbel AND
                   vbtyp EQ lt_lips_1-vgtyp.
      IF sy-subrc EQ 0.
        SORT lt_vbak.
      ENDIF.

* >> Getting required data from VBAP
      SELECT vbeln posnr zz_metric_ind
             INTO TABLE lt_vbap
             FROM vbap
             FOR ALL ENTRIES IN lt_lips_1
             WHERE vbeln EQ lt_lips_1-vgbel AND
                   posnr EQ lt_lips_1-vgpos.
      IF sy-subrc EQ 0.
        SORT lt_vbap.
      ENDIF.
    ENDIF.

* >> Getting required data from EKKO
    IF lt_lips_1[] IS NOT INITIAL.
      SELECT ebeln bsart zzvbeln zzposnr
             INTO TABLE lt_ekko
             FROM ekko
             FOR ALL ENTRIES IN lt_lips_1
             WHERE ebeln EQ lt_lips_1-vgbel.
      IF sy-subrc EQ 0.
        SORT lt_ekko.
      ENDIF.
    ENDIF.

* LT_VBAK internal table above will be blank in case of purchasing
* document b'coz LIPS-VGBEL will have the PO number and a hit to
* VBAK will return nothing. So, in this scenario, we are hitting
* VBAK with SO in EKKO-ZZVBELN
* we are doing the samething to get data from VBAP
    IF lt_ekko[] IS NOT INITIAL.
      REFRESH lt_ekko_1.
      lt_ekko_1[] = lt_ekko[].
      SORT lt_ekko_1 BY zzvbeln zzposnr.
      DELETE lt_ekko_1 WHERE zzvbeln IS INITIAL.
      IF lt_ekko_1[] IS NOT INITIAL.
        SELECT vbeln
               FROM vbak
               APPENDING TABLE lt_vbak
               FOR ALL ENTRIES IN lt_ekko_1
               WHERE vbeln EQ lt_ekko_1-zzvbeln.
        IF sy-subrc EQ 0.
          SORT lt_vbak.
          SELECT vbeln posnr zz_metric_ind
                 FROM vbap
                 APPENDING TABLE lt_vbap
                 FOR ALL ENTRIES IN lt_ekko_1
                 WHERE vbeln EQ lt_ekko_1-zzvbeln AND
                       posnr EQ lt_ekko_1-zzposnr.
          IF sy-subrc EQ 0.
            SORT lt_vbap.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

* >> Getting required data from EKKN
    REFRESH lt_lips_1.
    lt_lips_1[] = lt_lips[].
    SORT lt_lips_1 BY vgbel vgpos.
    DELETE ADJACENT DUPLICATES FROM lt_lips_1 COMPARING vgbel vgpos.
* >> since LIPS-VGPOS is NUMC 6 and EKKN-EBELP is NUMC 5, populating
*    LIPS-VGPOS into another internal table
    LOOP AT lt_lips_1 INTO ls_lips.
      CLEAR  ls_ekkn_lips.
      ls_ekkn_lips-vgbel = ls_lips-vgbel.
      ls_ekkn_lips-vgpos = ls_lips-vgpos.
      APPEND ls_ekkn_lips TO lt_ekkn_lips.
    ENDLOOP.
    IF lt_ekkn_lips[] IS NOT INITIAL.
      SORT lt_ekkn_lips.
      SELECT ebeln ebelp vbeln vbelp
             INTO TABLE lt_ekkn
             FROM ekkn
             FOR ALL ENTRIES IN lt_ekkn_lips
             WHERE ebeln EQ lt_ekkn_lips-vgbel AND
                   ebelp EQ lt_ekkn_lips-vgpos.
      IF sy-subrc EQ 0.
        SORT lt_ekkn.
      ENDIF.
      SELECT ebeln ebelp
             INTO TABLE lt_ekpo
             FROM ekpo
             FOR ALL ENTRIES IN lt_ekkn_lips
             WHERE ebeln EQ lt_ekkn_lips-vgbel AND
                   ebelp EQ lt_ekkn_lips-vgpos.
      IF sy-subrc EQ 0.
        SORT lt_ekpo.
      ENDIF.
    ENDIF.

* LT_VBAK internal table above may be blank in case of purchasing
* document where EKKN will not have the associated SO and a hit to
* VBAK will return nothing. So, in this scenario, we are hitting
* VBAK with SO in EKKN-VBELN
* we are doing the samething to get data from VBAP
    IF lt_ekkn[] IS NOT INITIAL.
      REFRESH lt_ekkn_1.
      lt_ekkn_1[] = lt_ekkn[].
      SORT lt_ekkn_1 BY vbeln.
      DELETE lt_ekkn_1 WHERE vbeln IS INITIAL.
      IF lt_ekkn_1[] IS NOT INITIAL.
        SELECT vbeln
               FROM vbak
               APPENDING TABLE lt_vbak
               FOR ALL ENTRIES IN lt_ekkn_1
               WHERE vbeln EQ lt_ekkn_1-vbeln.
        IF sy-subrc EQ 0.
          SORT lt_vbak.
          SELECT vbeln posnr zz_metric_ind
                 FROM vbap
                 APPENDING TABLE lt_vbap
                 FOR ALL ENTRIES IN lt_ekkn_1
                 WHERE vbeln EQ lt_ekkn_1-vbeln AND
                       posnr EQ lt_ekkn_1-vbelp.
          IF sy-subrc EQ 0.
            SORT lt_vbap.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    SORT lt_vbak BY vbeln.
    SORT lt_vbap BY vbeln posnr.
    SORT lt_ekko BY ebeln.
    SORT lt_ekpo BY ebeln ebelp.
    SORT lt_ekkn BY ebeln ebelp.

    CLEAR : rv_metric_ind, ls_lips, lv_so_vbeln, lv_so_posnr.

    rv_metric_ind = 'N'.
    LOOP AT lt_lips INTO ls_lips WHERE uecha IS INITIAL.
      CASE ls_lips-vgtyp.
        WHEN 'C'.    " Sales Order ('C')
          lv_so_vbeln = ls_lips-vgbel.
          lv_so_posnr = ls_lips-vgpos.
        WHEN 'V'.    " Purchasing Document ('V')
          CLEAR ls_ekko.
          READ TABLE lt_ekko INTO ls_ekko WITH KEY ebeln = ls_lips-vgbel
                                                   BINARY SEARCH.
          IF sy-subrc EQ 0.
            IF ls_ekko-zzvbeln IS NOT INITIAL OR
               ls_ekko-zzposnr IS NOT INITIAL.
              lv_so_vbeln = ls_ekko-zzvbeln.
              lv_so_posnr = ls_ekko-zzposnr.
            ELSE.
              CLEAR ls_ekkn.
              READ TABLE lt_ekkn INTO ls_ekkn
                                 WITH KEY ebeln = ls_lips-vgbel
                                          ebelp = ls_lips-vgpos
                                          BINARY SEARCH.
              IF sy-subrc EQ 0.
                lv_so_vbeln = ls_ekkn-vbeln.
                lv_so_posnr = ls_ekkn-vbelp.
              ENDIF.
            ENDIF.
          ENDIF.
      ENDCASE.

      CLEAR ls_vbap.
      READ TABLE lt_vbap INTO ls_vbap WITH KEY vbeln = lv_so_vbeln
                                               posnr = lv_so_posnr
                                               BINARY SEARCH.
      IF sy-subrc EQ 0 AND ls_vbap-metric_ind EQ 'Y'.
        rv_metric_ind = 'Y'.
        EXIT.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD get_open_tanum .

    REFRESH rt_open_tanum.

    rt_open_tanum[] = gs_delv_data-open_tanum[].

  ENDMETHOD.


  METHOD get_picking_status .

    CLEAR rv_kostk.

    rv_kostk = gs_delv_data-vbuk-kostk.

  ENDMETHOD.


  METHOD get_staging_area .

    CLEAR rv_lgbzo.

    rv_lgbzo = gs_delv_data-likp-lgbzo.

  ENDMETHOD.


  METHOD get_tot_gross_picked_wght .

    DATA ls_lips TYPE lips.

    CLEAR : ev_tot_gross_wt, ev_meins.

    LOOP AT gs_delv_data-lips INTO ls_lips WHERE uecha IS INITIAL.
      ev_tot_gross_wt = ev_tot_gross_wt + ls_lips-kcbrgew.
    ENDLOOP.

    ev_meins = ls_lips-meins.

  ENDMETHOD.


  METHOD get_tot_net_picked_wght .

* CHG115057 - Copy Pick Qty to Delivery Qty
* As per this change, we wanted to get the Total Net Picked Wght for
* entire delivery

    DATA : lt_lips TYPE TABLE OF lips,
           ls_lips TYPE lips.

    CLEAR : ev_tot_net_wt, ev_meins.

    lt_lips[] = gs_delv_data-lips[].

    SORT lt_lips BY uecha.
    DELETE lt_lips WHERE uecha IS NOT INITIAL.

    LOOP AT lt_lips INTO ls_lips.
      IF ls_lips-charg IS NOT INITIAL.
        ev_tot_net_wt = ev_tot_net_wt + ls_lips-ntgew.
      ELSE.
        ev_tot_net_wt = ev_tot_net_wt + ls_lips-kcntgew.
      ENDIF.
    ENDLOOP.

    ev_meins = ls_lips-meins.

  ENDMETHOD.


  METHOD get_vbdkl_data .

    REFRESH rt_vbdkl.
    rt_vbdkl[] = gs_delv_data-vbdkl[].

  ENDMETHOD.


  METHOD get_vbdpl_data .

    REFRESH rt_vbdpl.
    rt_vbdpl[] = gs_delv_data-vbdpl[].

  ENDMETHOD.


  METHOD get_vbfa_data .

    REFRESH rt_vbfa.
    rt_vbfa[] = gs_delv_data-vbfa[].

  ENDMETHOD.


  METHOD get_vblkk_data .

    CLEAR rs_vblkk.

    rs_vblkk = gs_delv_data-vblkk.

  ENDMETHOD.


  METHOD get_vblkp_data .

    REFRESH rt_vblkp.

    rt_vblkp[] = gs_delv_data-vblkp[].

  ENDMETHOD.


  METHOD get_vbplk_data .

    REFRESH rt_vbplk.
    rt_vbplk[] = gs_delv_data-vbplk[].

  ENDMETHOD.


  METHOD get_vbplp_data .

    REFRESH rt_vbplp.
    rt_vbplp[] = gs_delv_data-vbplp[].

  ENDMETHOD.


  METHOD get_vbpls_data .

    REFRESH rt_vbpls.
    rt_vbpls[] = gs_delv_data-vbpls[].

  ENDMETHOD.


  METHOD get_vbtyp .

    CLEAR rv_vbtyp.

    rv_vbtyp = gs_delv_data-likp-vbtyp.

  ENDMETHOD.


  METHOD get_vbuk_data .

    CLEAR rs_vbuk.
    rs_vbuk = gs_delv_data-vbuk.

  ENDMETHOD.


  METHOD get_vbup_data .

    REFRESH rt_vbup.
    rt_vbup[] = gs_delv_data-vbup[].

  ENDMETHOD.


  METHOD get_wm_movmt_status .

    CLEAR rv_lvstk.

    rv_lvstk = gs_delv_data-vbuk-lvstk.

  ENDMETHOD.


  METHOD handle_applog_message .

    DATA ls_message TYPE bal_s_msg.

    FIELD-SYMBOLS : <lt_applog> TYPE zca_bal_msg_tab.

    ls_message-msgty = sy-msgty.
    ls_message-msgid = sy-msgid.
    ls_message-msgno = sy-msgno.
    WRITE sy-msgv1 TO ls_message-msgv1 USING EDIT MASK '==ALPHA'.
    WRITE sy-msgv2 TO ls_message-msgv2 USING EDIT MASK '==ALPHA'.
    WRITE sy-msgv3 TO ls_message-msgv3 USING EDIT MASK '==ALPHA'.
    WRITE sy-msgv4 TO ls_message-msgv4 USING EDIT MASK '==ALPHA'.

    ASSIGN gt_applog->* TO <lt_applog>.
    APPEND ls_message   TO <lt_applog>.

  ENDMETHOD.


  METHOD handle_message .

    DATA ls_message  TYPE bapiret2.

    FIELD-SYMBOLS : <lt_return> TYPE bapiret2_t.

    ls_message-type   = sy-msgty.
    ls_message-id     = sy-msgid.
    ls_message-number = sy-msgno.
    WRITE sy-msgv1 TO ls_message-message_v1 USING EDIT MASK '==ALPHA'.
    WRITE sy-msgv2 TO ls_message-message_v2 USING EDIT MASK '==ALPHA'.
    WRITE sy-msgv3 TO ls_message-message_v3 USING EDIT MASK '==ALPHA'.
    WRITE sy-msgv4 TO ls_message-message_v4 USING EDIT MASK '==ALPHA'.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH ls_message-message_v1 ls_message-message_v2
                 ls_message-message_v3 ls_message-message_v4
            INTO ls_message-message.

    ASSIGN gt_return->* TO <lt_return>.
    APPEND ls_message TO <lt_return>.

  ENDMETHOD.


  METHOD pack_su_from_hu .
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======      ===========================*
* Bruce Ballehr 04/14/2010 R16 July 2010 -> TPR37583
*                          EDVK976410
*                          In the above TPR, some Batches of a Bundled
*                          Roll were not successfully packed onto the
*                          targeted HU. This fix will validate that all
*                          batches that were supposed to be assigned to
*                          a Handling Unit are actually assigned. If not
*                          the proper App Log message will be generated
*                          See program tag BCB01 for these changes.
* Chandra Cherupally 04/15/2010  TPR 37744
*                          Confirmation w/diff in case picking was
*                          failing b'coz of the wrong packing qty.
*                          changed the code to look at the correct value
* Kmaddel            09/15/2015 E0VK9A0EVA  CMS# 28779
*                          1)Error messages written to the Application
*                          log to include the SAP USERID if a delivery
*                          lock occurs.
*                          2)Validation to destination field
* SMITHAI                  06/17/2016 E0VK9A0KJ6 CMS30397
*                          WM Auto Pack Failure + 552 Inventory Write-off
*                          712 Fix
* Amit Maole 06/13/2017 CMS31485 Add error message code  after delivery
*                       save(RF Pick)
* Amit Maole 10/17/2017 CMS32732 Check HU locking before delivery save(RF Pick)
* John William 12/28/2018 CMS 32732 add app log for error analisis
************************************************************************

    TYPES: BEGIN OF ty_vekp,
             venum TYPE venum,
             exidv TYPE exidv,
             vpobj TYPE vpobj,
           END OF ty_vekp.

    DATA: lt_vekp       TYPE hum_hu_header_t,
          ls_vekp       TYPE LINE OF hum_hu_header_t,
          lt_vepo       TYPE hum_hu_item_t,
          ls_vepo       TYPE LINE OF hum_hu_item_t,
          lt_to_objects TYPE zdl_wm_to_obj_t,
          ls_to_objects TYPE zdl_wm_to_obj_s,
          ls_ltak       TYPE ltak,
          lt_ltap       TYPE tt_ltap,
          ls_ltap       TYPE ltap,
          ls_hukey      TYPE bapihukey-hu_exid,
          ls_huhdr      TYPE zdl_hu_hdr,
          lt_huitm      TYPE zdl_hu_itm,
          ls_huitm      TYPE bapihuitmproposal,
          lt_hu         TYPE hum_rehang_hu_t,
          ls_hu         TYPE hum_rehang_hu,
          lt_matnr      TYPE TABLE OF matnr,
          ls_matnr      TYPE matnr,
          lv_head       TYPE bapihuheader,
          lv_exidv      TYPE bapihukey-hu_exid,
          lv_vbeln      TYPE vbeln_vl,
          lt_exidv      TYPE tab_hum_rehang_hu,
          ls_exidv      TYPE exidv,
          lv_lvsme      TYPE lvs_lvsme,
          lv_umrez_rl   TYPE umrez,
          lv_umrez_pkg  TYPE umrez,
          lv_umrez_div  TYPE umrez,
          lo_hu         TYPE REF TO zcl_dl_hu,
          lv_num_times  TYPE numc2,
          lv_wait_time  TYPE numc2,
          ls_vbkok      TYPE vbkok,
          lv_db_upd     TYPE leshp_database_update,
          lv_send_msg   TYPE xfeld,
          lt_tonum      TYPE zdl_wm_pack_t,
          lt_tanum      TYPE tt_tanum,
          lv_tanum      TYPE tanum,
          ls_tanum      TYPE zdl_wm_pack_s,
          lt_tapos      TYPE tapos_tt,
          ls_tapos      TYPE tapos,
          lt_return     TYPE tt_bapiret2,
          ls_return     TYPE bapiret2,                        "BCB01
          lv_vlenr      TYPE ltap-vlenr,
          lv_count      TYPE sy-tabix,   " TPR 05987 - from n to tabix
          lv_message    TYPE string, "symsgv,
          ls_applog     TYPE bal_s_msg,
          lv_flag       TYPE c,
          lt_applog     TYPE zca_bal_msg_tab,
          ls_ltap_temp  TYPE ltap,
          lt_vbpok      TYPE tt_vbpok,
          lv_error      TYPE char1.                           "BCB01

*** Start changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779
    DATA : lv_userid TYPE sy-msgv1.
*** End changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779

    CONSTANTS: lc_1 TYPE c VALUE '1',  " Database update
               lc_x TYPE c VALUE 'X'.  " Send Messaages

    GET REFERENCE OF et_return INTO gt_return.
    GET REFERENCE OF et_applog INTO gt_applog.

    lt_tonum[] = it_tanum_tapos[].

    LOOP AT lt_tonum INTO ls_tanum.
      lv_tanum = ls_tanum-tanum.
      APPEND lv_tanum TO lt_tanum.
    ENDLOOP.

    MESSAGE s214 INTO lv_message.
    CALL METHOD set_message_buffer
      RECEIVING
        es_applog = ls_applog.
    APPEND ls_applog TO et_applog.

* Create TO objects
    CALL METHOD zcl_wm_to=>get_to_objects
      EXPORTING
        iv_lgnum      = iv_lgnum
        it_tanum      = lt_tanum[]
      RECEIVING
        rt_to_objects = lt_to_objects[].

    LOOP AT lt_to_objects INTO ls_to_objects.
*   Get T0 Header data
      CALL METHOD ls_to_objects-to_obj->get_ltak_data
        RECEIVING
          rs_ltak = ls_ltak.

*   Get TO Item data
      CALL METHOD ls_to_objects-to_obj->get_ltap_data
        RECEIVING
          rt_ltap = lt_ltap.

      READ TABLE lt_tonum INTO ls_tanum WITH  KEY tanum = ls_ltak-tanum.

*   If there are no TO items passed
      IF ls_tanum-toitm[] IS INITIAL.
*     Need to pack the TOs that are confirmed.
        CHECK ls_ltak-kquit = 'X'.
      ELSE.
*     Need to pack the TO line items that are confirmed.
        DELETE lt_ltap WHERE  pquit IS INITIAL.
      ENDIF.

*   If TO Items passed then pack only that TO lines, delete the
*   remaining TO Items
      READ TABLE lt_tonum INTO ls_tanum WITH KEY tanum = ls_ltak-tanum.
      IF sy-subrc = 0 AND ls_tanum-toitm[] IS NOT INITIAL.
        lt_tapos = ls_tanum-toitm[].
        LOOP AT lt_ltap INTO ls_ltap.
          READ TABLE lt_tapos INTO ls_tapos WITH KEY
                                            table_line =  ls_ltap-tapos.
          IF sy-subrc NE 0.
            DELETE lt_ltap.
          ENDIF.
        ENDLOOP.
      ENDIF.

      SORT lt_ltap BY vlenr.

* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analysis.
      LOOP AT lt_ltap INTO DATA(ls_ltap_analysis).
*     CONCATENATE the values required for analysis.
        DATA(lv_msg1) = |{ 'TO ' }{ ls_ltap_analysis-tanum } { 'Item ' }{ ls_ltap_analysis-tapos } { 'Item ' }{ ls_ltap_analysis-posnr } |.
        DATA(lv_msg2) = |{ 'SU ' }{ ls_ltap_analysis-vlenr } { 'Batch ' }{ ls_ltap_analysis-charg } { 'Ind ' }{ ls_ltap_analysis-pquit } |.
        DATA(lv_msg3) = |{ 'Mat ' }{ ls_ltap_analysis-matnr } { 'Qty ' }{ ls_ltap_analysis-nistm } |.
        MESSAGE s243 WITH lv_msg1
                          lv_msg2
                          lv_msg3 INTO DATA(lv_ltab_analysis).
        CALL METHOD set_message_buffer
          RECEIVING
            es_applog = ls_applog.
        APPEND ls_applog TO et_applog.
      ENDLOOP.

* End of change JWILL68 CMS 32732 12/06/2018

*   Process each TO item
*   In case of Bundle rolls create one HU for all the items, BundleRolls
*   have single storage unit for all the items. In case of single units
*   individual HUs for each item.
      LOOP AT lt_ltap INTO ls_ltap.
        IF sy-tabix = 1.
          lv_vlenr = ls_ltap-vlenr.
        ENDIF.

*     Begin BCB01 insert
        CLEAR: lv_error.
*     End BCB01 insert

        lv_count = sy-tabix + 1.
        READ TABLE lt_ltap INTO ls_ltap_temp INDEX lv_count.
        IF ls_ltap-vlenr <> ls_ltap_temp-vlenr.
          lv_vlenr = ls_ltap-vlenr.
          lv_flag = lc_x.
        ENDIF.
        ls_huitm-hu_item_type   = lc_1.
*      ls_huitm-pack_qty       = ls_ltap-vsolm.  " TPR 37744
*      ls_huitm-base_unit_qty  = ls_ltap-gewei.
        ls_huitm-pack_qty       = ls_ltap-nistm.              " TPR 37744
        ls_huitm-base_unit_qty  = ls_ltap-meins.
** Need to pass carton quantity if storage type is 'PAL'.
*      IF ls_ltap-letyp        = 'PAL'.
*        ls_huitm-pack_qty       = ls_ltap-nista.
*        ls_huitm-base_unit_qty  = ls_ltap-altme.
*      ENDIF.
        ls_huitm-material       = ls_ltap-matnr.
        ls_huitm-batch          = ls_ltap-charg.
        ls_huitm-plant          = ls_ltap-werks.
        ls_huitm-stge_loc       = ls_ltap-lgort.
        ls_huitm-gr_date        = sy-datum.
        APPEND ls_huitm TO lt_huitm.

        AT LAST.
          lv_flag = 'X'.
        ENDAT.

        IF lv_flag = 'X'.
*       Get Packing material for the plant
          CALL METHOD zcl_dl_hu=>get_pack_mat
            EXPORTING
              iv_werks = ls_huitm-plant
            IMPORTING
              ev_matnr = ls_huhdr-pack_mat.

          ls_huhdr-hu_status_init = 'C'.
          ls_huhdr-plant          = ls_huitm-plant.

*       External Handling Unit
*       In case of pickpallet concatenate Ref. Number and Batch for HU
          IF NOT ls_ltak-lznum IS INITIAL.
            IF iv_sto_del EQ 'X'.
              lv_exidv = ls_ltak-lznum.
            ELSE.
              CONCATENATE ls_ltak-lznum ls_huitm-batch INTO lv_exidv.
            ENDIF.
          ELSE.
            IF NOT ls_ltap-vlenr IS INITIAL.
              lv_exidv = ls_ltap-vlenr.
            ELSE.
              lv_exidv = ls_huitm-batch.
            ENDIF.
            MESSAGE s221 WITH lv_exidv INTO lv_message.
            CALL METHOD set_message_buffer
              RECEIVING
                es_applog = ls_applog.
            APPEND ls_applog TO et_applog.
          ENDIF.

          ls_huhdr-hu_exid = lv_exidv.

*       Create HU object
          CREATE OBJECT lo_hu
            EXPORTING
              iv_exidv     = lv_exidv
            EXCEPTIONS
              invalid_data = 1
              OTHERS       = 2.

          IF sy-subrc = 0.
*         Get HU details
            CALL METHOD lo_hu->get_hu_details
              IMPORTING
                et_hu_hdr = lt_vekp[]
                et_hu_itm = lt_vepo[].

*         Check that HU is non assigned then delete and recreate HU
            READ TABLE lt_vekp INTO ls_vekp INDEX 1.
            IF sy-subrc = 0.
              IF ls_vekp-vpobj = '00' OR
                 ls_vekp-vpobj = '05' OR
                 ls_vekp-vpobj = '06' OR
                 ls_vekp-vpobj = '12' .
                CLEAR: lt_return, lt_return.                  "BCB01
* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Create log before attempting to delete HU
* Log before deleting HU.
                MESSAGE s239 WITH lv_exidv
                                  ls_vekp-vpobj
                                  ls_vekp-vpobjkey
                                  ls_vekp-status INTO DATA(lv_app_log).

                CALL METHOD set_message_buffer
                  RECEIVING
                    es_applog = ls_applog.
                APPEND ls_applog TO et_applog.
* End of change JWILL68 CMS 32732 12/06/2018

                CALL METHOD zcl_dl_hu=>delete_hu
                  EXPORTING
                    iv_exidv     = lv_exidv
                  IMPORTING                                   "BCB01
                    et_return    = lt_return                  "BCB01
                  EXCEPTIONS
                    hu_not_found = 1
                    OTHERS       = 2.
                IF sy-subrc = 0.
*               Begin BCB01 insert
                  READ TABLE lt_return INTO ls_return
                    WITH KEY type = 'E'.
                  IF sy-subrc NE 0.
*               End BCB01 insert
                    MESSAGE s216 WITH lv_exidv INTO lv_message.
                    CALL METHOD set_message_buffer
                      RECEIVING
                        es_applog = ls_applog.
                    APPEND ls_applog TO et_applog.
*               Begin BCB01 insert
                  ELSE.
*                 Error occurred Deleting the HU
*                 Packing failed for Delivery & , HU &
*                  MESSAGE e230 WITH ls_ltak-vbeln lv_exidv
*                    INTO lv_message.
* These log will be removed after analyzis.
                    CLEAR lv_app_log.
                    MESSAGE e238 WITH lv_exidv                    "JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                                  INTO lv_app_log.

                    CALL METHOD set_message_buffer
                      RECEIVING
                        es_applog = ls_applog.
                    APPEND ls_applog TO et_applog.
                    lv_error = lc_x.  "set error flag
                  ENDIF.
                ELSE.
*               Error calling the Method
*               Packing failed for Delivery & , HU &
*                MESSAGE e230 WITH ls_ltak-vbeln lv_exidv
*                  INTO lv_message.
* These log will be removed after analyzis.
                  CLEAR lv_app_log.
                  MESSAGE e238 WITH lv_exidv                    "JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                                INTO lv_app_log.

                  CALL METHOD set_message_buffer
                    RECEIVING
                      es_applog = ls_applog.
                  APPEND ls_applog TO et_applog.
                  lv_error = lc_x.  "set error flag
*               End BCB01 insert
                ENDIF.

                IF lv_error = space. "BCB01 insert
                  CLEAR: lt_return, lt_return.                "BCB01

* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Create log before attempting to delete HU
* Log before deleting HU.
                  MESSAGE s240 WITH lv_exidv
                                    |{ sy-timlo TIME = (cl_abap_format=>t_user) } |
                                    INTO lv_app_log.

                  CALL METHOD set_message_buffer
                    RECEIVING
                      es_applog = ls_applog.
                  APPEND ls_applog TO et_applog.
* End of change JWILL68 CMS 32732 12/06/2018

                  CALL METHOD zcl_dl_hu=>create_hu
                    EXPORTING
                      is_hu_hdr    = ls_huhdr
                      it_item      = lt_huitm[]
                    IMPORTING
                      es_head      = lv_head
                      et_return    = lt_return[]
*                     et_return_error_analysis = DATA(lt_return_error_analysis)
                    EXCEPTIONS
                      invalid_data = 1
                      OTHERS       = 2.
                  IF sy-subrc = 0.
*                 Begin BCB01 insert
*                  IF  sy-tcode = 'ZDL_RF_CASE_PICK' OR                  "JWILL68 CMS 32732 12/07/2018
*                      sy-tcode = 'ZDL_WM_E04515'.
*                    READ TABLE lt_return_error_analysis INTO ls_return
*                      WITH KEY type = 'E'.
*                  ELSE.
                    READ TABLE lt_return INTO ls_return
                      WITH KEY type = 'E'.
*                  ENDIF.
*                  READ TABLE lt_return INTO ls_return
*                    WITH KEY type = 'E'.
                    IF sy-subrc NE 0.
*                 End BCB01 insert
*                    MESSAGE s217 WITH lv_exidv INTO lv_message.
                      MESSAGE s244 WITH lv_exidv
                                        lv_head-hu_id
                                     INTO lv_message.
                      CALL METHOD set_message_buffer
                        RECEIVING
                          es_applog = ls_applog.
                      APPEND ls_applog TO et_applog.
*                 Begin BCB01 insert
                    ELSE.
*                   Error occurred Deleting the HU
*                   Packing failed for Delivery & , HU &
*                    MESSAGE e230 WITH ls_ltak-vbeln lv_exidv
*                      INTO lv_message.
                      MESSAGE s241 WITH lv_exidv                    " JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                                     INTO lv_app_log.
                      CALL METHOD set_message_buffer
                        RECEIVING
                          es_applog = ls_applog.
                      APPEND ls_applog TO et_applog.
                      lv_error = lc_x.  "set error flag
                    ENDIF.
* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Read the VEKP table to make sure HU is created
                    IF lv_head-hu_id IS NOT INITIAL.
                      SELECT *
                        FROM vekp
                        INTO TABLE @DATA(lt_vekp_log)
                        WHERE venum = @lv_head-hu_id.
                      IF sy-subrc <> 0.
                        MESSAGE s242 WITH lv_head-hu_id
                                          |{ sy-timlo TIME = (cl_abap_format=>t_user) } | " JWILL68 CMS 32732 12/06/2018
                                       INTO lv_app_log.
                        CALL METHOD set_message_buffer
                          RECEIVING
                            es_applog = ls_applog.
                        APPEND ls_applog TO et_applog.
                      ELSEIF sy-subrc = 0.
                        MESSAGE s245 WITH lv_head-hu_id
                                          |{ sy-timlo TIME = (cl_abap_format=>t_user) } | " JWILL68 CMS 32732 12/06/2018
                                       INTO lv_app_log.
                        CALL METHOD set_message_buffer
                          RECEIVING
                            es_applog = ls_applog.
                        APPEND ls_applog TO et_applog.
                      ENDIF.
                    ENDIF.
* End of change JWILL68 CMS 32732 12/06/2018
                  ELSE.
*                 Packing failed for Delivery & , HU &
*                  MESSAGE e230 WITH ls_ltak-vbeln lv_exidv
*                    INTO lv_message.
                    MESSAGE e241 WITH lv_exidv                    " JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                                   INTO lv_app_log.

                    CALL METHOD set_message_buffer
                      RECEIVING
                        es_applog = ls_applog.
                    APPEND ls_applog TO et_applog.
                    lv_error = lc_x.  "set error flag
*               End BCB01 insert
                  ENDIF.

                ENDIF. "BCB01 insert
*-->CMS30397 E0VK9A0KJ6 SMITHAI 5/26/2016
              ELSEIF ls_vekp-vpobj = '01'.
                SELECT SINGLE charg FROM mseg INTO @DATA(lv_charg) WHERE charg = @ls_vekp-exidv AND
                      ( bwart = '552' OR bwart = '712' ).
                IF sy-subrc = 0.
                  CONCATENATE lv_exidv 'A' INTO lv_exidv. "ls_huhdr-hu_exid.

                  ls_huhdr-hu_exid = lv_exidv.

                  IF lv_error = space. "BCB01 insert
                    CLEAR: lt_return, lt_return.                "BCB01

* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Create log before attempting to delete HU
* Log before deleting HU.
                    MESSAGE s240 WITH lv_exidv
                                      |{ sy-timlo TIME = (cl_abap_format=>t_user) } |
                                      INTO lv_app_log.

                    CALL METHOD set_message_buffer
                      RECEIVING
                        es_applog = ls_applog.
                    APPEND ls_applog TO et_applog.
* End of change JWILL68 CMS 32732 12/06/2018

                    CALL METHOD zcl_dl_hu=>create_hu
                      EXPORTING
                        is_hu_hdr    = ls_huhdr
                        it_item      = lt_huitm[]
                      IMPORTING
                        es_head      = lv_head
                        et_return    = lt_return[]
*                       et_return_error_analysis = lt_return_error_analysis
                      EXCEPTIONS
                        invalid_data = 1
                        OTHERS       = 2.
                    IF sy-subrc = 0.
*                    IF  sy-tcode = 'ZDL_RF_CASE_PICK' OR                  "JWILL68 CMS 32732 12/07/2018
*                        sy-tcode = 'ZDL_WM_E04515'.
*                      READ TABLE lt_return_error_analysis INTO ls_return
*                        WITH KEY type = 'E'.
*                    ELSE.
                      READ TABLE lt_return INTO ls_return
                        WITH KEY type = 'E'.
*                    ENDIF.
*                    READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
                      IF sy-subrc NE 0.
*                   HU Created with an suffix 'A'
*                      MESSAGE s217 WITH lv_exidv INTO lv_message.
                        MESSAGE s244 WITH lv_exidv
                                          lv_head-hu_id
                                       INTO lv_message.
                        CALL METHOD set_message_buffer
                          RECEIVING
                            es_applog = ls_applog.
                        APPEND ls_applog TO et_applog.
                      ELSE.
*                   Packing failed for Delivery & , HU &
*                      MESSAGE e230 WITH ls_ltak-vbeln lv_exidv INTO lv_message.
                        MESSAGE s241 WITH lv_exidv                    " JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                                       INTO lv_app_log.

                        CALL METHOD set_message_buffer
                          RECEIVING
                            es_applog = ls_applog.
                        APPEND ls_applog TO et_applog.
                        lv_error = lc_x.  "set error flag
                      ENDIF.
* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Read the VEKP table to make sure HU is created
                      IF lv_head-hu_id IS NOT INITIAL.
                        SELECT *
                          FROM vekp
                          INTO TABLE @lt_vekp_log
                          WHERE venum = @lv_head-hu_id.
                        IF sy-subrc <> 0.
                          MESSAGE s242 WITH lv_head-hu_id
                                            |{ sy-timlo TIME = (cl_abap_format=>t_user) } | " JWILL68 CMS 32732 12/06/2018
                                         INTO lv_app_log.
                          CALL METHOD set_message_buffer
                            RECEIVING
                              es_applog = ls_applog.
                          APPEND ls_applog TO et_applog.
                        ELSEIF sy-subrc = 0.
                          MESSAGE s245 WITH lv_head-hu_id
                                            |{ sy-timlo TIME = (cl_abap_format=>t_user) } | " JWILL68 CMS 32732 12/06/2018
                                         INTO lv_app_log.
                          CALL METHOD set_message_buffer
                            RECEIVING
                              es_applog = ls_applog.
                          APPEND ls_applog TO et_applog.
                        ENDIF.
                      ENDIF.
* End of change JWILL68 CMS 32732 12/06/2018

                    ELSE.
*                 Packing failed for Delivery & , HU &
*                    MESSAGE e230 WITH ls_ltak-vbeln lv_exidv INTO lv_message.
                      MESSAGE e241 WITH lv_exidv                    " JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                                     INTO lv_app_log.

                      CALL METHOD set_message_buffer
                        RECEIVING
                          es_applog = ls_applog.
                      APPEND ls_applog TO et_applog.
                      lv_error = lc_x.  "set error flag
                    ENDIF.
                  ENDIF. "Check LV_Error = ' '.
                ELSE.
* Start of change JWILL68 CMS 32732 12/10/2018
                  DATA(lv_mseg1) = |{ 'Entry not found in MSEG for batch' } { ls_vekp-exidv } |.
                  DATA(lv_mseg2) = |{ ' for mvt types 552 & 712' } |.
                  DATA(lv_mseg3) = | |.
                  MESSAGE s243 WITH lv_mseg1
                                    lv_mseg2
                                    lv_mseg3 INTO DATA(lv_msg_error).
                  CALL METHOD set_message_buffer
                    RECEIVING
                      es_applog = ls_applog.
                  APPEND ls_applog TO et_applog.
* End of change JWILL68 CMS 32732 12/10/2018

                ENDIF. "Check for Mvt Type 552 and 712.
*<--CMS 30397 E0VK9A0KJ6 SMITHAI 5/26/2016
              ELSE.
                MESSAGE e228 WITH lv_exidv INTO lv_message.
                CALL METHOD set_message_buffer
                  RECEIVING
                    es_applog = ls_applog.
                APPEND ls_applog TO et_applog.
              ENDIF.
            ENDIF.
          ELSE.

*         If HU not exist then create new HU
            CLEAR: lt_return, lt_return.                      "BCB01

* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Create log before attempting to delete HU
* Log before deleting HU.
            MESSAGE s240 WITH lv_exidv
                              |{ sy-timlo TIME = (cl_abap_format=>t_user) } |
                              INTO lv_app_log.

            CALL METHOD set_message_buffer
              RECEIVING
                es_applog = ls_applog.
            APPEND ls_applog TO et_applog.
* End of change JWILL68 CMS 32732 12/06/2018

            CALL METHOD zcl_dl_hu=>create_hu
              EXPORTING
                is_hu_hdr    = ls_huhdr
                it_item      = lt_huitm[]
              IMPORTING
                es_head      = lv_head
                et_return    = lt_return[]
*               et_return_error_analysis = lt_return_error_analysis
              EXCEPTIONS
                invalid_data = 1
                OTHERS       = 2.
            IF sy-subrc = 0.
*            IF  sy-tcode = 'ZDL_RF_CASE_PICK' OR                  "JWILL68 CMS 32732 12/07/2018
*                sy-tcode = 'ZDL_WM_E04515'.
*              READ TABLE lt_return_error_analysis INTO ls_return
*                WITH KEY type = 'E'.
*            ELSE.
              READ TABLE lt_return INTO ls_return
                WITH KEY type = 'E'.
*            ENDIF.
*           Begin BCB01 insert
*            READ TABLE lt_return INTO ls_return
*              WITH KEY type = 'E'.
              IF sy-subrc NE 0.
*           End BCB01 insert
*              MESSAGE s217 WITH lv_exidv INTO lv_message.
                MESSAGE s244 WITH lv_exidv
                                  lv_head-hu_id
                               INTO lv_message.
                CALL METHOD set_message_buffer
                  RECEIVING
                    es_applog = ls_applog.
                APPEND ls_applog TO et_applog.
*           Begin BCB01 insert
              ELSE.
*             Error occurred Deleting the HU
*             Packing failed for Delivery & , HU &
*              MESSAGE e230 WITH ls_ltak-vbeln lv_exidv
*                INTO lv_message.
                MESSAGE s241 WITH lv_exidv                    " JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                               INTO lv_app_log.

                CALL METHOD set_message_buffer
                  RECEIVING
                    es_applog = ls_applog.
                APPEND ls_applog TO et_applog.
                lv_error = lc_x.  "set error flag
              ENDIF.
* Start of change JWILL68 CMS 32732 12/06/2018
* These log will be removed after analyzis.
* Read the VEKP table to make sure HU is created
              IF lv_head-hu_id IS NOT INITIAL.
                SELECT *
                  FROM vekp
                  INTO TABLE @lt_vekp_log
                  WHERE venum = @lv_head-hu_id.
                IF sy-subrc <> 0.
                  MESSAGE s242 WITH lv_head-hu_id
                                    |{ sy-timlo TIME = (cl_abap_format=>t_user) } | " JWILL68 CMS 32732 12/06/2018
                                 INTO lv_app_log.
                  CALL METHOD set_message_buffer
                    RECEIVING
                      es_applog = ls_applog.
                  APPEND ls_applog TO et_applog.
                ELSEIF sy-subrc = 0.
                  MESSAGE s245 WITH lv_head-hu_id
                                    |{ sy-timlo TIME = (cl_abap_format=>t_user) } | " JWILL68 CMS 32732 12/06/2018
                                 INTO lv_app_log.
                  CALL METHOD set_message_buffer
                    RECEIVING
                      es_applog = ls_applog.
                  APPEND ls_applog TO et_applog.
                ENDIF.
              ENDIF.
* End of change JWILL68 CMS 32732 12/06/2018

            ELSE.
*           Packing failed for Delivery & , HU &
*            MESSAGE e230 WITH ls_ltak-vbeln lv_exidv INTO lv_message.
              MESSAGE e241 WITH lv_exidv                    " JWILL68 CMS 32732 12/06/2018
                                      ls_return-id
                                      ls_return-number
                                      ls_return-message
                             INTO lv_app_log.

              CALL METHOD set_message_buffer
                RECEIVING
                  es_applog = ls_applog.
              APPEND ls_applog TO et_applog.
              lv_error = lc_x.  "set error flag
*         End BCB01 insert
            ENDIF.
          ENDIF.

*       Begin BCB01 insert comments
*       If lv_head-hu_exid has a value then the HU was created
*       successfully.
*       End BCB01 insert comments
          IF lv_head-hu_exid IS NOT INITIAL.
            ls_exidv = lv_head-hu_exid.
          ENDIF.

*       Begin BCB01 delete
*        APPEND ls_exidv TO lt_exidv.
*       End BCB01 delete

*       Begin BCB01 insert
*       If not errors occurred Deleting the existing HU, Creating the
*       HU after the attempted Deletion of the HU, or the Creating of
*       the HU when it never existed, then append the HU to the table
*       of HU's that will be assigned to the Delivery
          IF lv_error = space.
            APPEND ls_exidv TO lt_exidv.
          ENDIF.
*       End BCB01 insert

          CLEAR: lt_huitm, ls_huhdr,lv_head, lv_exidv,
                 lt_huitm[], lv_flag.
        ENDIF.

* Start of change JWILL68 CMS 12/19/2018
        CALL METHOD determine_msh_weight
          EXPORTING
            is_ltap  = ls_ltap     " Transfer order item
          IMPORTING
            es_vbpok = DATA(ls_vbpok).    " Confirming Picking Data from Delivery Item
        IF ls_vbpok IS NOT INITIAL.
* Write an app log
          MESSAGE s248 WITH ls_vbpok-vbeln_vl
                            ls_vbpok-posnr_vl
                            ls_vbpok-lfimg
                         INTO lv_app_log.
          ls_applog = set_message_buffer( ).
          APPEND ls_applog TO et_applog.
          APPEND ls_vbpok TO lt_vbpok.
          CLEAR ls_vbpok.
        ENDIF.
* End of change JWILL68 CMS 12/19/2018
      ENDLOOP.
    ENDLOOP.

* Start of change JWILL68 CMS 32732 12/06/2018
    IF lt_exidv IS INITIAL.
      MESSAGE s000 WITH |{ 'No HUs for delivery packing' }|
                     INTO DATA(lv_hu_error).
      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ELSE.
      DESCRIBE TABLE lt_exidv LINES DATA(lv_hu_lines).
      MESSAGE s243 WITH |{ 'Total no of HUs for delivery packing' }|
                        |{ lv_hu_lines }|
                        |{ '' }|
                     INTO lv_hu_error.
      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ENDIF.

    LOOP AT lt_exidv INTO DATA(ls_exidv_analysis).
      MESSAGE s243 WITH |{ 'HU' }|
                        |{ ls_exidv_analysis-top_hu_external }|
                        |{ '' }| INTO DATA(lv_exdiv_message).
      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ENDLOOP.
* End of change JWILL68 CMS 32732 12/06/2018.

* Get number of trials and wait time for each trial
    CALL METHOD zcl_dl_delivery=>get_lock_wait_times
      EXPORTING
        iv_category  = 'E04532'
      IMPORTING
        ev_num_times = lv_num_times
        ev_wait_time = lv_wait_time.

    MESSAGE s219 INTO lv_message.
    CALL METHOD set_message_buffer
      RECEIVING
        es_applog = ls_applog.
    APPEND ls_applog TO et_applog.

* Check delivery is locked or not

    CALL METHOD zcl_dl_delivery=>check_delivery_lock
      EXPORTING
        iv_vbeln        = ls_ltak-vbeln
        iv_num_times    = lv_num_times
        iv_wait_time    = lv_wait_time
*** Start changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779
      IMPORTING
        iv_uname        = lv_userid
*** End changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779
      EXCEPTIONS
        delivery_locked = 1
        OTHERS          = 2.
    IF sy-subrc <> 0.

*** Start commented by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779
*   Delivery & locked
*    MESSAGE e204 WITH ls_ltak-vbeln INTO lv_message.
*** Start commented by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779

*** Start changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779
*    MESSAGE e220 WITH ls_ltak-vbeln lv_userid INTO lv_message.
      MESSAGE e235 WITH ls_ltak-vbeln
                        lv_userid
                        lv_wait_time
                        lv_num_times
                   INTO lv_message.
*** End changes by kmaddel on 9/15/2015 E0VK9A0EVA  CMS# 28779

      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
      RETURN.
    ENDIF.

    et_return[] = lt_return[].

* Save delivery
    ls_vbkok-vbeln_vl = ls_ltak-vbeln.
    lv_db_upd   = lc_1.
    lv_send_msg = lc_x.
*-->CMS 30397 E0VK9A0KJ6 SMITHAI 7/6/2016
    DO lv_num_times TIMES.
      CALL METHOD zcl_dl_delivery=>save_delivery
        EXPORTING
          is_vbkok                    = ls_vbkok
          iv_if_database_update       = lv_db_upd
          iv_if_error_messages_send_0 = lv_send_msg
        IMPORTING
          et_applog                   = lt_applog[]
        CHANGING
          et_vbpok_tab                = lt_vbpok
          et_prot                     = et_prot[]
          et_handling_units           = lt_exidv[]
        EXCEPTIONS
          delivery_locked             = 1
          delivery_update_fail        = 2
          OTHERS                      = 3.
      IF sy-subrc = 0.
        DATA(lv_subrc) = sy-subrc.
        EXIT.
      ELSE.
        lv_subrc = sy-subrc.
        WAIT UP TO lv_wait_time SECONDS.
      ENDIF.
    ENDDO.

    IF lv_subrc <> 0.
      MESSAGE e236 WITH lv_subrc lv_num_times INTO lv_message. "CMS31485
      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
      CALL METHOD zcl_dl_delivery=>handle_message.
*<--CMS 30397 E0VK9A0KJ6 SMITHAI 7/6/2016
      MESSAGE e229 WITH ls_ltak-vbeln ls_ltap-charg INTO lv_message.
      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
      CALL METHOD zcl_dl_delivery=>handle_message.


* Start of change JWILL68 CMS 32732 12/06/2018
* Get the application log for error analysis.
      LOOP AT lt_applog INTO DATA(ls_app_log).
        DATA(lv_app1) = |{ 'ID:' }{ ls_app_log-msgid }{ '/' }{ ls_app_log-msgno } { 'Type: ' }{ ls_app_log-msgty }|.
        DATA(lv_app2) = |{ 'Text: ' }{ ls_app_log-msgv1 } { ls_app_log-msgv2 } { ls_app_log-msgv3 }|.
        DATA(lv_app3) = |{ 'sy-subrc' } { ls_app_log-alsort }|.
        MESSAGE s243 WITH lv_app1
                          lv_app2
                          lv_app3 INTO lv_msg_error.
        CALL METHOD set_message_buffer
          RECEIVING
            es_applog = ls_applog.
        APPEND ls_applog TO et_applog.
      ENDLOOP.
      LOOP AT et_prot INTO DATA(ls_prot).
        DATA(lv_prot1) = |{ 'Mat ' }{ ls_prot-matnr } { 'Batch ' }{ ls_prot-charg } { 'Qty ' }{ ls_prot-lfimg }|.
        DATA(lv_prot2) = |{ 'ID:' }{ ls_prot-msgid } { 'Number: ' }{ ls_prot-msgno } { 'Type: ' }{ ls_prot-msgty }|.
        DATA(lv_prot3) = |{ 'Text: ' }{ ls_prot-msgv1 } { ls_prot-msgv2 } { ls_prot-msgv3 }|.
        MESSAGE s243 WITH lv_prot1
                          lv_prot2
                          lv_prot3 INTO lv_msg_error.
        CALL METHOD set_message_buffer
          RECEIVING
            es_applog = ls_applog.
        APPEND ls_applog TO et_applog.
      ENDLOOP.
* End of change JWILL68 CMS 32732 12/06/2018

*   Delivery level packing failed then return to calling program
      RETURN.
    ELSE.
*   HUs are packed successfully.
      MESSAGE s213 INTO lv_message.
      CALL METHOD set_message_buffer
        RECEIVING
          es_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ENDIF.

    CLEAR: lt_exidv, ls_huhdr, lt_huitm, lv_head, lv_exidv, ls_ltap,
           ls_ltak.

  ENDMETHOD.


  METHOD pack_su_from_hu_new.
***********************************************************************
***********************************************************************
**                                                                    *
**             C O M P A N Y   C O N F I D E N T I A L                *
**                                                                    *
**        This program is the property of International Paper.        *
**        Care should be taken to pervent its unauthorized use.       *
**                                                                    *
***********************************************************************
***********************************************************************
**                                                                    *
**                    COPYRIGHT (C) 2018 by                           *
**                     INTERNATIONAL PAPER                            *
**                                                                    *
**                     ALL RIGHTS RESERVED                            *
**                                                                    *
**                   REVISIONS COPYRIGHT (C)                          *
**                                20XX                                *
**                             by                                     *
**                     INTERNATIONAL PAPER                            *
***********************************************************************
*_____________________________________________________________________*
* Program Name:CHECK_ADD_NEW_HU                                       *
*                                                                     *
*                                              Creation   : 12/28/2018*
*                                                                     *
* SAP Name    :DETERMINE_MSH_WEIGHT            Version    : Initial   *
*                                                                     *
* Programmer  :JWILL68                           Last Update:         *
*_____________________________________________________________________*
* Description: Include for implemeting the local class methods        *
*_____________________________________________________________________*
************************************************************************
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======      ===========================*
*  John William       12/21/2108  CMS 32732  Rewritten the method      *
*                                            PACK_SU_FROM_HU           *
*                                                                      *
************************************************************************
* Local data type declaration.
    TYPES: BEGIN OF ty_s_tanum,
             tanum TYPE tanum,
           END OF ty_s_tanum,
           ty_t_tanum TYPE STANDARD TABLE OF ty_s_tanum WITH EMPTY KEY.

* Local data declaration
    DATA: lt_exidv TYPE tab_hum_rehang_hu,
          lt_vbpok TYPE tt_vbpok,
          lt_huitm TYPE zdl_hu_itm.

* Local ref declaration
    DATA: lo_hu TYPE REF TO zcl_dl_hu.

*Initialize exporting parameter
    CLEAR: et_prot,
           et_return,
           et_applog.

* get the transfer order number into a separate table to
* pass into the method  zcl_wm_to=>get_to_objects
    DATA(lt_tanum) = VALUE ty_t_tanum(
                          FOR ls_tanum_tapos IN it_tanum_tapos
                                    ( tanum = ls_tanum_tapos-tanum ) ).

* write in the application log Instantiating delivery level packing.
    MESSAGE s214 INTO DATA(lv_message).
    DATA(ls_applog) = set_message_buffer( ).
    APPEND ls_applog TO et_applog.
    CLEAR ls_applog.

* Create TO objects
    CALL METHOD zcl_wm_to=>get_to_objects
      EXPORTING
        iv_lgnum      = iv_lgnum
        it_tanum      = CONV tt_tanum( lt_tanum )
      RECEIVING
        rt_to_objects = DATA(lt_to_objects).

* Loop all the TO objects.
    LOOP AT lt_to_objects INTO DATA(ls_to_objects).
      " Get TO header data
      DATA(ls_ltak) = ls_to_objects-to_obj->get_ltak_data( ).

      " Get TO Item data
      DATA(lt_ltap) = ls_to_objects-to_obj->get_ltap_data( ).

* Read the import table to check if the TO item is passed.
      TRY.
          DATA(ls_tanum) = it_tanum_tapos[ tanum = ls_ltak-tanum ].
* Check if there are TO item is passed.
          IF ls_tanum-toitm[] IS INITIAL.
*     Need to pack the TOs that are confirmed.
            CHECK ls_ltak-kquit = abap_true.
          ELSE.
*     Need to pack the TO line items that are confirmed.
            DELETE lt_ltap WHERE  pquit IS INITIAL.
          ENDIF.
        CATCH cx_sy_itab_line_not_found.
          CLEAR ls_tanum.
      ENDTRY.

*   If TO Items passed then pack only that TO lines, delete the
*   remaining TO Items
      TRY.
          ls_tanum = it_tanum_tapos[ tanum = ls_ltak-tanum ].
          IF ls_tanum-toitm[] IS NOT INITIAL.
            LOOP AT lt_ltap INTO DATA(ls_ltap).
              IF line_exists( ls_tanum-toitm[ table_line =  ls_ltap-tapos ] ).
                " Do nothing.
              ELSE.
                DELETE lt_ltap.
              ENDIF.
            ENDLOOP.
          ENDIF.
        CATCH cx_sy_itab_line_not_found.
          CLEAR ls_tanum.
      ENDTRY.

      SORT lt_ltap BY vlenr.

* check if batch repeats in TO. If the batch repeats in TO, then
* Select the last confirmation TO line item.
      CALL METHOD delete_duplicate_batch
        CHANGING
          ct_ltap = lt_ltap. " TO Items

      LOOP AT lt_ltap INTO DATA(ls_ltap_analysis).
*     CONCATENATE the values required for analysis.
        DATA(lv_msg1) = |{ 'TO ' } { ls_ltap_analysis-tanum } { 'Item ' } { ls_ltap_analysis-tapos } { 'Item ' } { ls_ltap_analysis-posnr } |.
        DATA(lv_msg2) = |{ 'SU ' } { ls_ltap_analysis-vlenr } { 'Batch ' } { ls_ltap_analysis-charg } { 'Ind ' } { ls_ltap_analysis-pquit } |.
        DATA(lv_msg3) = |{ 'Mat ' } { ls_ltap_analysis-matnr } { 'Qty ' } { ls_ltap_analysis-nistm } |.
        MESSAGE s243 WITH lv_msg1
                          lv_msg2
                          lv_msg3 INTO DATA(lv_ltap_analysis).
        ls_applog = set_message_buffer( ).
        APPEND ls_applog TO et_applog.
      ENDLOOP.

*   Process each TO item
*   In case of Bundle rolls create one HU for all the items, BundleRolls
*   have single storage unit for all the items.
*   In case of single units individual HUs for each item.
      LOOP AT lt_ltap INTO ls_ltap.
        IF sy-tabix = 1.
          DATA(lv_vlenr) = ls_ltap-vlenr.
        ENDIF.

        DATA(lv_count) = sy-tabix + 1.

        TRY.
            DATA(ls_ltap_temp) = lt_ltap[ lv_count ].
            IF ls_ltap-vlenr <> ls_ltap_temp-vlenr.
              lv_vlenr = ls_ltap-vlenr.
              DATA(lv_flag) = abap_true.
            ENDIF.
          CATCH cx_sy_itab_line_not_found.
            CLEAR ls_ltap_temp.
        ENDTRY.

        APPEND VALUE  bapihuitmproposal(
                                 hu_item_type   = 1
                                 pack_qty       = ls_ltap-nistm
                                 base_unit_qty  = ls_ltap-meins
                                 material       = ls_ltap-matnr
                                 batch          = ls_ltap-charg
                                 plant          = ls_ltap-werks
                                 stge_loc       = ls_ltap-lgort
                                 gr_date        = sy-datum  ) TO lt_huitm.

        AT LAST.
          lv_flag = 'X'.
        ENDAT.

        IF lv_flag = 'X'.
*       Get Packing material for the plant
          CALL METHOD zcl_dl_hu=>get_pack_mat
            EXPORTING
              iv_werks = ls_ltap-werks
            IMPORTING
              ev_matnr = DATA(lv_pack_matnr).

          DATA(ls_huhdr) = VALUE zdl_hu_hdr( pack_mat = lv_pack_matnr
                                             hu_status_init = 'C'
                                             plant = ls_ltap-werks ).

*       External Handling Unit
*       In case of pickpallet concatenate Ref. Number and Batch for HU
          IF NOT ls_ltak-lznum IS INITIAL.
            IF iv_sto_del EQ abap_true.
              DATA(lv_exidv) = ls_ltak-lznum.
            ELSE.
              lv_exidv = |{ ls_ltak-lznum }{ ls_ltap-charg }|.
            ENDIF.
          ELSE.
            IF NOT ls_ltap-vlenr IS INITIAL.
              lv_exidv = ls_ltap-vlenr.
            ELSE.
              lv_exidv = ls_ltap-charg.
            ENDIF.
            " app log
            MESSAGE s221 WITH lv_exidv INTO lv_message.
            ls_applog = set_message_buffer( ).
            APPEND ls_applog TO et_applog.
          ENDIF.

          ls_huhdr-hu_exid = lv_exidv.

* since exceptions should be cought for this method, inline declarations can not be used.
*       Create HU object
          CREATE OBJECT lo_hu
            EXPORTING
              iv_exidv     = lv_exidv    " Internal Handling Unit Number
            EXCEPTIONS
              invalid_data = 1
              hu_not_found = 2
              OTHERS       = 3.

* If HU exits, then get the details for the HU.
          CASE sy-subrc.
            WHEN 0.
*         Get HU details
              CALL METHOD lo_hu->get_hu_details
                IMPORTING
                  et_hu_hdr = DATA(lt_vekp)
                  et_hu_itm = DATA(lt_vepo).

*  Check that HU is non assigned then delete HU.
* To check if HU is unassigned, read the table vekp and check for the status.
* Status 0040 and 0050 is for unassigned HU
              TRY.
                  DATA(ls_vekp) = lt_vekp[ 1 ].
                  IF ls_vekp-status = '0040' OR
                     ls_vekp-status = '0050'.
* Call the method to add 11th digit to HU.
                    CALL METHOD check_add_new_hu
                      EXPORTING
                        iv_exidv = lv_exidv    " External Handling Unit Identification
                      IMPORTING
                        ev_exidv = lv_exidv.    " External Handling Unit Identification
                  ELSE.
* Call the method to delete the HU
                    CALL METHOD zcl_dl_hu=>delete_hu
                      EXPORTING
                        iv_exidv     = lv_exidv    " External Handling Unit Identification
                      IMPORTING
                        et_return    = DATA(lt_return)    " Table Type for BAPIRET2
                      EXCEPTIONS
                        hu_not_found = 1
                        OTHERS       = 2.
                    IF sy-subrc = 0.
* Read the return table to check if the delete is successful.
                      TRY.
                          DATA(ls_return) = lt_return[ type = 'E' ].
* In case if the HU delete fails, then add a 11th digit to HU.
* Adding 11th digit will make sure that HU create never fails.
                          CALL METHOD check_add_new_hu
                            EXPORTING
                              iv_exidv = lv_exidv    " External Handling Unit Identification
                            IMPORTING
                              ev_exidv = lv_exidv.     " External Handling Unit Identification
                        CATCH cx_sy_itab_line_not_found.
                          MESSAGE s216 WITH lv_exidv INTO lv_message.
                          ls_applog = set_message_buffer( ).
                          APPEND ls_applog TO et_applog.
                      ENDTRY.
                    ENDIF.
                  ENDIF. " status Check
* Create a HU.
* App log before creating a new HU.
                  MESSAGE s240 WITH lv_exidv
                                    |{ sy-timlo TIME = (cl_abap_format=>t_user) } |
                                    INTO lv_message.
                  ls_applog = set_message_buffer( ).
                  APPEND ls_applog TO et_applog.
                  ls_huhdr-hu_exid = lv_exidv.
                  CALL METHOD zcl_dl_hu=>create_hu
                    EXPORTING
                      is_hu_hdr    = ls_huhdr    " HU Header  $$$ should we pass new HU here
                      it_item      = lt_huitm    " Default for HU Item Creation
                    IMPORTING
                      es_head      = DATA(ls_head)    " Handling Unit - Header Table
                      et_return    = lt_return  " Table with BAPI Return Information
                    EXCEPTIONS
                      invalid_data = 1
                      OTHERS       = 2.
                  IF sy-subrc = 0.
* Read the return table to check if the create is successful.
                    TRY.
                        ls_return = lt_return[ type = 'E' ].
* In case if the HU creation fails, then get the reason for fail from
* BAPI return table and write it the app log and aslo set the error flag as X
                        MESSAGE e241 WITH lv_exidv
                                       INTO lv_message.
                        ls_applog = set_message_buffer( ).
                        APPEND ls_applog TO et_applog.
* Capture the standard one as separate line as full text is not printed in output.
* This message text will give the information about why HU creation is failed.
                        CLEAR: lv_msg1, lv_msg2.
                        lv_msg1 = ls_return-message+0(45).
                        lv_msg2 = ls_return-message+45(50).
                        MESSAGE e252 WITH ls_return-id
                                          ls_return-number
                                          lv_msg1
                                          lv_msg2
                                       INTO lv_message.
                        ls_applog = set_message_buffer( ).
                        APPEND ls_applog TO et_applog.
                        DATA(lv_error) = abap_true.  "set error flag
* If HU create fails, then no use of going for packing
                      CATCH cx_sy_itab_line_not_found.
* HU Created with an suffix 'A'
* App log write
                        MESSAGE s244 WITH lv_exidv
                                          ls_head-hu_id
                                       INTO lv_message.
                        ls_applog = set_message_buffer( ).
                        APPEND ls_applog TO et_applog.
                    ENDTRY.
                  ELSEIF sy-subrc = 1.
* App log write
                    MESSAGE e247 INTO lv_message.
                    ls_applog = set_message_buffer( ).
                    APPEND ls_applog TO et_applog.
                  ENDIF.
                CATCH cx_sy_itab_line_not_found.
                  CLEAR ls_vekp.
              ENDTRY.
            WHEN OTHERS.
* If no HU exits, then create a new HU.
              CALL METHOD zcl_dl_hu=>create_hu
                EXPORTING
                  is_hu_hdr    = ls_huhdr     " HU Header
                  it_item      = lt_huitm    " Default for HU Item Creation
                IMPORTING
                  es_head      = ls_head    " Handling Unit - Header Table
                  et_return    = lt_return   " Table with BAPI Return Information
                EXCEPTIONS
                  invalid_data = 1
                  OTHERS       = 2.
              IF sy-subrc = 0.
* Read the return table to check if the create is successful.
                TRY.
                    CLEAR ls_return.
                    ls_return = lt_return[ type = 'E' ].
* In case if the HU creation fails, then get the reason for fail from
* BAPI return table and write it the app log and aslo set the error flag as X
                    MESSAGE e241 WITH lv_exidv
                                   INTO lv_message.
                    ls_applog = set_message_buffer( ).
                    APPEND ls_applog TO et_applog.
* Capture the standard one as separate line as full text is not printed in output.
* This message text will give the information about why HU creation is failed.
                    CLEAR: lv_msg1, lv_msg2.
                    lv_msg1 = ls_return-message+0(45).
                    lv_msg2 = ls_return-message+45(50).
                    MESSAGE e252 WITH ls_return-id
                                      ls_return-number
                                      lv_msg1
                                      lv_msg2
                                   INTO lv_message.
                    ls_applog = set_message_buffer( ).
                    APPEND ls_applog TO et_applog.
                    lv_error = abap_true.  "set error flag
* If HU create fails, then no use of going for packing
                  CATCH cx_sy_itab_line_not_found.
* App log write
                    MESSAGE s244 WITH lv_exidv
                                      ls_head-hu_id
                                   INTO lv_message.
                    ls_applog = set_message_buffer( ).
                    APPEND ls_applog TO et_applog.
                ENDTRY.
              ELSEIF sy-subrc = 1.
                MESSAGE e247 INTO lv_message.
                ls_applog = set_message_buffer( ).
                APPEND ls_applog TO et_applog.
              ELSE.
* App log write
                MESSAGE s246 WITH lv_exidv
                               INTO lv_message.
                ls_applog = set_message_buffer( ).
                APPEND ls_applog TO et_applog.
              ENDIF.
          ENDCASE.

*       If lv_head-hu_exid has a value then the HU was created
*       successfully.
          IF ls_head-hu_exid IS NOT INITIAL.
            DATA(lv_hu_exid) = ls_head-hu_exid.
          ENDIF.

*       If no errors occurred while
*          1. Deleting the existing HU,
*          2. Creating the HU after the attempted Deletion & Adding 11th digit &
*             HU when it never existed,
*     then append the HU to the table of HU's that will be assigned to the Delivery

          IF lv_error = space.
            DATA(ls_exidv) = VALUE hum_rehang_hu( top_hu_external = lv_hu_exid ).
            APPEND ls_exidv TO lt_exidv.
          ENDIF.

* Determine the MSHEET logic. Sometimes the quantity may not be equal
          CALL METHOD determine_msh_weight
            EXPORTING
              is_ltap  = ls_ltap    " Transfer order item
            IMPORTING
              es_vbpok = DATA(ls_vbpok).    " Confirming Picking Data from Delivery Item
          IF ls_vbpok IS NOT INITIAL.
* Write an app log
            MESSAGE s248 WITH ls_vbpok-vbeln_vl
                              ls_vbpok-posnr_vl
                              ls_vbpok-lfimg
                           INTO lv_message.
            ls_applog = set_message_buffer( ).
            APPEND ls_applog TO et_applog.
            APPEND ls_vbpok TO lt_vbpok.
            CLEAR: ls_vbpok.
          ENDIF.

*CLEAR all the local table and variable after each record.
          CLEAR: " all the local variable
                 lv_vlenr, lv_message, lv_error,
                 lv_flag,  lv_pack_matnr, lv_exidv,   lv_hu_exid,

                 " Local strucuture
                 ls_ltap_temp, ls_huhdr, ls_vekp,ls_return,
                 ls_head,      ls_exidv,

                " Local internal table
                 lt_huitm, lt_vekp, lt_vepo, lt_return,

                " Local reference
                 lo_hu.
        ENDIF.
      ENDLOOP.

      CLEAR: ls_tanum, lt_ltap.
    ENDLOOP.

* Check for HU's table and MSH table. If both are empty, then give an error log and exit.
* if MSH is not empty, then packing update is required.
    IF lt_vbpok IS INITIAL AND
       lt_exidv IS INITIAL.
* Write an app log
      MESSAGE s249 INTO lv_message.
      ls_applog = set_message_buffer( ).
      APPEND ls_applog TO et_applog.
      RETURN.
    ELSEIF lt_vbpok IS NOT INITIAL AND
           lt_exidv IS INITIAL.
* Write an app log
      MESSAGE s250 INTO lv_message.
      ls_applog = set_message_buffer( ).
      APPEND ls_applog TO et_applog.
    ENDIF.

* Get number of trials and wait time for each trial
* When the program runs in backround and incase if someone locked the delivery
* then try X times and wait for Y times. the X and Y values would be maintained
* in the custom tbale ZDL_FIELDS.
    CALL METHOD zcl_dl_delivery=>get_lock_wait_times
      EXPORTING
        iv_category  = 'E04532'    " Report category
      IMPORTING
        ev_num_times = DATA(lv_num_times)    " Two digit number
        ev_wait_time = DATA(lv_wait_time).    " Two digit number

**********************************************************************
    MESSAGE s219 INTO lv_message.
    ls_applog = set_message_buffer( ).
    APPEND ls_applog TO et_applog.
**********************************************************************

* Check delivery is locked or not
    CALL METHOD zcl_dl_delivery=>check_delivery_lock
      EXPORTING
        iv_vbeln        = ls_ltak-vbeln    " Delivery
        iv_num_times    = lv_num_times    " Number of Times
        iv_wait_time    = lv_wait_time    " Wait Time
      IMPORTING
        iv_uname        = DATA(lv_userid)   " Name of User
      EXCEPTIONS
        delivery_locked = 1
        OTHERS          = 2.
    IF sy-subrc <> 0.
      MESSAGE e235 WITH ls_ltak-vbeln
                        lv_userid
                        lv_wait_time
                        lv_num_times
                   INTO lv_message.
      ls_applog = set_message_buffer( ).
      APPEND ls_applog TO et_applog.
      RETURN.
    ENDIF.

    et_return[] = lt_return[].

    DATA(ls_vbkok) = VALUE vbkok( vbeln_vl = ls_ltak-vbeln ).
* Save delivery
    CALL METHOD save_delivery_new
      EXPORTING
        is_vbkok                    = ls_vbkok    " Confirming Picking Data from Delivery Header
        iv_if_database_update       = '1'   " Saving a Delivery can be Deactivated: See Fixed Values
        iv_if_error_messages_send_0 = abap_true   " Checkbox
      IMPORTING
        et_applog                   = DATA(lt_applog)    " CA: Table Type for BAL_S_MSG
      CHANGING
        et_vbpok_tab                = lt_vbpok    " Delivery Items
        et_prot                     = et_prot    " TABLE PROTT
        et_handling_units           = lt_exidv    " TABLE HUM_REHANG_HU
      EXCEPTIONS
        delivery_locked             = 1
        delivery_update_fail        = 2
        OTHERS                      = 3.
    IF sy-subrc <> 0.
      MESSAGE e229 WITH ls_ltak-vbeln ls_ltap-charg INTO lv_message.
      ls_applog = set_message_buffer( ).
      APPEND ls_applog TO et_applog.

**********************************************************************
* Get the application log for error analysis.
      LOOP AT lt_applog INTO DATA(ls_app_log).
        DATA(lv_app1) = |{ 'ID:' }{ ls_app_log-msgid }{ '/' }{ ls_app_log-msgno } { 'Type: ' }{ ls_app_log-msgty }|.
        DATA(lv_app2) = |{ 'Text: ' }{ ls_app_log-msgv1 } { ls_app_log-msgv2 } { ls_app_log-msgv3 }|.
        DATA(lv_app3) = |{ 'sy-subrc' } { ls_app_log-alsort }|.
        MESSAGE s243 WITH lv_app1
                          lv_app2
                          lv_app3 INTO lv_message.
        ls_applog = set_message_buffer( ).
        APPEND ls_applog TO et_applog.
      ENDLOOP.
**********************************************************************
    ELSE.
      IF lt_exidv IS INITIAL AND
         lt_vbpok IS NOT INITIAL.
* Delivery update completed successfully.
        MESSAGE s251 INTO lv_message.
        ls_applog = set_message_buffer( ).
        APPEND ls_applog TO et_applog.
      ELSE.
*   HUs are packed successfully.
        MESSAGE s213 INTO lv_message.
        ls_applog = set_message_buffer( ).
        APPEND ls_applog TO et_applog.
      ENDIF.
    ENDIF.

    CLEAR: lt_to_objects, lt_vbpok, lt_exidv.
  ENDMETHOD.


  METHOD pick_missing_batch.

    TYPES: BEGIN OF ty_ship_deliv_item,
             ship_del_item(26) TYPE c,        " Shipment Delivery Line item
             shipment          TYPE tknum,    " Shipment Number
             delivery          TYPE vbeln_vl, " Delivery Number
             del_item          TYPE posnr_vl, " Delivery Item
             old_shipment      TYPE tknum,    " Previous Shipment
             kunnr             TYPE kunwe,    " Ship to Party
             dest_label        TYPE lznum,    " Additional Reference number
             stage             TYPE tsnum,    " Stage of transport number
             lfart             TYPE lfart,    "Delivery Type
           END   OF ty_ship_deliv_item,

           BEGIN OF ty_to_details,
             tanum     TYPE tanum,            " Transfer Order
             tapos     TYPE tapos,            " Transfer Order Item
             matnr     TYPE matnr,            " Material Number
             charg     TYPE charg_d,          " Batch number
             werks     TYPE werks_d,          " Plant
             vsola     TYPE ltap_vsola,
             " Source Target Qty in Alt Unit
             altme     TYPE lrmei,            " Alt. Unit of Measure
             vltyp     TYPE ltap_vltyp,       " Source storage type
             vlpla     TYPE ltap_vlpla,       " Source Storage Bin
             nlenr     TYPE ltap_nlenr,       " Source Storage Unit
             svlpla    TYPE ltap_vlpla,       " Source Storage Bin (Scan)
             nlpla     TYPE ltap_vlpla,       " Destination Storage Bin
             nltyp     TYPE ltap_vltyp,       " Destination storage type
             dnlpla    TYPE lagp_verif,
             " Destination Storage Bin( Scanned)
             scnts(10) TYPE n,                " Sr. Target Qty in Cartons
             reason(1) TYPE c,                " Reason Code
             vsolm     TYPE ltap_vsolm,
             ausfb     TYPE lvs_ausfb,
             ausfb_msg TYPE mobmess,
           END   OF ty_to_details.

    CONSTANTS : lc_app_log_object TYPE balobj_d  VALUE 'ZDL_WM_EO',
                lc_app_log_subobj TYPE balsubobj VALUE 'PICK_MISSING_BATCH'.

    DATA: gs_ship_deliv_item TYPE ty_ship_deliv_item,
          gs_to_details      TYPE ty_to_details,
          lt_app_log         TYPE zca_bal_msg_tab,
          lt_ltap_conf       TYPE pdt_t_ltap_conf,
          lv_external_id     TYPE symsgv.


    SELECT * FROM zdl_fields INTO TABLE @DATA(lt_fields)
      WHERE category = 'E04548'
      AND fieldname = 'PICK_MISSING_BATCH'
      AND lowval = @sy-tcode. "Succesful only when executed via lm01

    IF sy-subrc = '0'.
*"Imported from Report :ZDL_WM_E04548_CASE_RF_PICK  Include: ZDL_WM_E04548_CASE_PICK_F01
      IMPORT gs_ship_deliv_item = gs_ship_deliv_item
      FROM MEMORY ID 'GS_SHIP_DELIV'.

*"Imported from Report :ZDL_WM_E04548_CASE_RF_PICK  Include: ZDL_WM_E04548_CASE_PICK_F01
      IMPORT gs_to_details = gs_to_details
      FROM MEMORY ID 'GS_TO_DETAILS'.

*"checking first condition for 'I'
      READ TABLE it_xlips
        WITH KEY vbeln = gs_ship_deliv_item-delivery
                 uecha = gs_ship_deliv_item-del_item
                 updkz = 'I'
             ASSIGNING FIELD-SYMBOL(<ls_xlips>).
      IF sy-subrc = '0'.
        IF <ls_xlips> IS NOT INITIAL AND <ls_xlips>-charg IS INITIAL.
          IF update_flag = abap_true.   "checking update flag
            <ls_xlips>-charg = gs_to_details-charg.   "Moving imported batch value to the structure

            IF sy-subrc = '0'.
              APPEND VALUE #( msgty = 'S'
                                msgid = 'AD'
                                msgno = '010'
                                msgv1 = |{ 'Delivery:' } { <ls_xlips>-vbeln } |
                                msgv2 = | { 'Item:' } { <ls_xlips>-posnr } |
                                msgv3 = | { 'Batch:' } { <ls_xlips>-charg } |
                                msgv4 = |Updated| ) TO lt_app_log.
              lv_external_id = |{ <ls_xlips>-vbeln }{ gs_ship_deliv_item-del_item }|.
            ENDIF.
          ELSE.
            APPEND VALUE #( msgty = 'S'
                            msgid = 'AD'
                            msgno = '010'
                            msgv1 = | { 'Class:' } { iv_class_name } |
                            msgv2 = | { 'Delivery:' } { <ls_xlips>-vbeln } { 'Item:' } { <ls_xlips>-posnr } |
                            msgv3 = | { 'Batch:' } { <ls_xlips>-charg } |
                            msgv4 = |Batch number empty with update indicator 'I'| ) TO lt_app_log.
            lv_external_id = |{ <ls_xlips>-vbeln }{ <ls_xlips>-posnr }|.
          ENDIF.
        ENDIF.
      ENDIF.

      IF sy-subrc = '4'.

*    "checking second condition for 'U'
        READ TABLE it_xlips
               WITH KEY vbeln = gs_ship_deliv_item-delivery
                              posnr = gs_ship_deliv_item-del_item
                              updkz = 'U'
               ASSIGNING FIELD-SYMBOL(<ls_xlips_u>).

        IF sy-subrc = '0'.
          IF <ls_xlips_u> IS NOT INITIAL AND <ls_xlips_u>-charg IS INITIAL.
            IF update_flag = abap_true.
              <ls_xlips_u>-charg = gs_to_details-charg.


              IF sy-subrc = '0'.
                APPEND VALUE #( msgty = 'S'
                                msgid = 'AD'
                                msgno = '010'
                                msgv1 = |{ 'Delivery:' } { <ls_xlips_u>-vbeln } |
                                msgv2 = | { 'Item:' } { <ls_xlips_u>-posnr } |
                                msgv3 = | { 'Batch:' } { <ls_xlips_u>-charg } |
                                msgv4 = |Updated| ) TO lt_app_log.
                lv_external_id = |{ <ls_xlips_u>-vbeln }{ gs_ship_deliv_item-del_item }|.
              ENDIF.

            ELSE.
              APPEND VALUE #( msgty = 'S'
                            msgid = 'AD'
                            msgno = '010'
                            msgv1 = | { 'Class:' } { iv_class_name } |
                            msgv2 = | { 'Delivery:' } { <ls_xlips_u>-vbeln } { 'Item:' } { <ls_xlips_u>-posnr } |
                            msgv3 = | { 'Batch:' } { <ls_xlips_u>-charg } |
                            msgv4 = |Batch number Empty with update indicator 'U'| ) TO lt_app_log.
              lv_external_id = |{ <ls_xlips_u>-vbeln }{ <ls_xlips_u>-posnr }|.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.

      IF lt_app_log IS NOT INITIAL.
        IF update_flag = abap_true.
          et_xlips[] = it_xlips[].
        ENDIF.

        CALL METHOD zcl_wm_misc_func=>write_application_log
          EXPORTING
            iv_repid        = sy-repid
            iv_log_object   = lc_app_log_object
            iv_log_subobj   = lc_app_log_subobj
*           iv_applog_extid = |PICK MISSING BATCH|
            iv_applog_extid = |{ lv_external_id }|
            it_messages     = lt_app_log.

      ENDIF.

      CLEAR: lv_external_id,
              update_flag,
             lt_app_log.
      UNASSIGN: <ls_xlips_u>,
                <ls_xlips>.
    ENDIF.
  ENDMETHOD.


  METHOD read_delivery_data .

    DATA : lv_vbeln     TYPE vbeln_vl,
           lv_pack_view.

    CLEAR : lv_vbeln, lv_pack_view.
    lv_vbeln     = iv_vbeln.
    lv_pack_view = iv_pack_view.

    CLEAR gs_delv_data.

    CALL METHOD read_likp_lips_data
      EXPORTING
        iv_vbeln           = lv_vbeln
      EXCEPTIONS
        delivery_not_found = 1
        hu_error           = 2
        OTHERS             = 3.
    CASE sy-subrc.
      WHEN 0. " No action required.
      WHEN 2.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                RAISING hu_error.
      WHEN OTHERS.
* Delivery & not found
*    MESSAGE e200 WITH iv_vbeln RAISING delivery_not_found.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                RAISING delivery_not_found.
    ENDCASE.

    gs_delv_data-vbeln = lv_vbeln.
    gv_vbeln = lv_vbeln.

* Get VBUK data
    CALL METHOD read_vbuk_data.

* Get VBUP data
    CALL METHOD read_vbup_data.

* Get VBFA data
    CALL METHOD read_vbfa_data.

* For a WM managed delivery/item, look for the Transfer Orders
    IF gs_delv_data-likp-lgnum IS NOT INITIAL.
      CALL METHOD read_tanum_data.
    ENDIF.

* If packing data is requested, go get it!!!
    IF lv_pack_view IS NOT INITIAL.
      CALL METHOD read_packing_data.
    ENDIF.

  ENDMETHOD.


  METHOD read_likp_lips_data .

    DATA : lv_subrc TYPE sy-subrc,
           ls_tvlk  TYPE tvlk.

* Get the Picking View data of the delivery
    CALL FUNCTION 'RV_DELIVERY_PICK_VIEW'
      EXPORTING
        vbeln              = iv_vbeln
        zweck              = 'L'
      IMPORTING
        es_likp            = gs_delv_data-likp
        vblkk_wa           = gs_delv_data-vblkk
      TABLES
        vblkp_tab          = gs_delv_data-vblkp[]
        lips_tab           = gs_delv_data-lips[]
      EXCEPTIONS
        no_likp            = 1
        no_picking_allowed = 2
        hu_error           = 3
        OTHERS             = 4.

    lv_subrc = sy-subrc.
    IF gs_delv_data-likp IS INITIAL.
      SELECT SINGLE *
             FROM likp
             INTO gs_delv_data-likp
             WHERE vbeln EQ iv_vbeln.
      MOVE-CORRESPONDING gs_delv_data-likp TO gs_delv_data-vblkk.
      SELECT SINGLE *
             FROM tvlk
             INTO ls_tvlk
             WHERE lfart EQ gs_delv_data-likp-lfart.
      gs_delv_data-vblkk-aufer  = ls_tvlk-aufer.
      gs_delv_data-vblkk-tdname = iv_vbeln.
    ENDIF.

    CASE lv_subrc.
      WHEN 0. "OR 2 OR 3. " No action required.
      WHEN 3.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                RAISING hu_error.
      WHEN OTHERS.
* Delivery & not found
*    MESSAGE e200 WITH iv_vbeln RAISING delivery_not_found.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                RAISING delivery_not_found.
    ENDCASE.

*->Begin of Chg/MAIELY/CD2000010003 /
*-Sorting the internal table from FM: RV_DELIVERY_PICK_VIEW
*-to resolve the unsorted del.item sequence from it
    IF gs_delv_data-lips[] IS NOT INITIAL.
      SORT gs_delv_data-lips.
    ENDIF.
*-<End of Chg/MAIELY/CD2000010003

  ENDMETHOD.


  METHOD read_packing_data .

    DATA ls_vbco3 TYPE vbco3.

    ls_vbco3-vbeln = gv_vbeln.
    ls_vbco3-packd = 'X'.
    CALL FUNCTION 'SD_DELIVERY_VIEW'
      EXPORTING
        comwa            = ls_vbco3
      TABLES
        vbdkl_tab        = gs_delv_data-vbdkl[]
        vbdpl_tab        = gs_delv_data-vbdpl[]
        vbplk_tab        = gs_delv_data-vbplk[]
        vbplp_tab        = gs_delv_data-vbplp[]
        vbpls_tab        = gs_delv_data-vbpls[]
      EXCEPTIONS
        object_not_found = 1
        OTHERS           = 2.
    IF sy-subrc EQ 0.
* do nothing
    ENDIF.

  ENDMETHOD.


  METHOD read_tanum_data .

    DATA : ls_vbfa  TYPE vbfa,
           ls_tanum TYPE tanum.

    LOOP AT gs_delv_data-vbfa[] INTO ls_vbfa WHERE vbtyp_n EQ 'Q'.
      ls_tanum = ls_vbfa-vbeln.
      IF ls_vbfa-taqui EQ 'X'.
        IF ls_vbfa-rfmng IS INITIAL.
          COLLECT ls_tanum INTO gs_delv_data-canc_tanum[].
        ELSE.
          COLLECT ls_tanum INTO gs_delv_data-conf_tanum[].
        ENDIF.
      ELSE.
        COLLECT ls_tanum INTO gs_delv_data-open_tanum[].
      ENDIF.
      COLLECT ls_tanum INTO gs_delv_data-all_tanum[].
    ENDLOOP.

  ENDMETHOD.


  METHOD read_vbfa_data .

* Get VBFA data
    CALL FUNCTION 'SD_VBFA_READ_WITH_VBELV'
      EXPORTING
        i_vbelv          = gv_vbeln
        i_refresh_buffer = 'X'
      TABLES
        et_vbfa          = gs_delv_data-vbfa[]
      EXCEPTIONS
        record_not_found = 1
        OTHERS           = 2.
    IF sy-subrc EQ 0.
      SORT gs_delv_data-vbfa BY vbelv posnv.
    ENDIF.

  ENDMETHOD.


  METHOD read_vbuk_data .

    CALL FUNCTION 'SD_VBUK_SINGLE_READ'
      EXPORTING
        i_vbeln          = gv_vbeln
        i_refresh_buffer = 'X'
      IMPORTING
        e_vbuk           = gs_delv_data-vbuk
      EXCEPTIONS
        record_not_found = 1
        OTHERS           = 2.
    IF sy-subrc NE 0.
      " do nothing
    ENDIF.

  ENDMETHOD.


  METHOD read_vbup_data .

    CALL FUNCTION 'SD_VBUP_READ_WITH_VBELN'
      EXPORTING
        i_vbeln          = gv_vbeln
        i_refresh_buffer = 'X'
      TABLES
        et_vbup          = gs_delv_data-vbup[]
      EXCEPTIONS
        record_not_found = 1
        OTHERS           = 2.
    IF sy-subrc EQ 0.
      SORT gs_delv_data-vbup BY vbeln posnr.
    ENDIF.

  ENDMETHOD.


  METHOD reload_data .

    CALL METHOD read_delivery_data
      EXPORTING
        iv_vbeln     = gv_vbeln
        iv_pack_view = iv_pack_view.

  ENDMETHOD.


  METHOD save_delivery .
    DATA: ls_vbkok         TYPE vbkok,
          lt_hu            TYPE hum_rehang_hu_t,
          ls_hu            TYPE hum_rehang_hu,
          ls_exidv         TYPE hum_rehang_hu,
          lv_error         TYPE xfeld,
          lv_item_del      TYPE xfeld,
          lv_pod_update    TYPE xfeld,
          lv_err_int       TYPE xfeld,
          lv_err_in_gi     TYPE xfeld,
          lv_err_final_chk TYPE xfeld,
          lv_err_part_upd  TYPE xfeld,
          lv_err_sernr_upd TYPE xfeld,
          lv_subrc         TYPE sy-subrc,
          lv_inv_code      TYPE zzinv VALUE 'U1379',
          lv_priority      TYPE c VALUE '2',
          lv_severity      TYPE c VALUE '2',
          lv_message       TYPE string, "symsgv,
          lv_text          TYPE zchar400,
          ls_applog        TYPE bal_s_msg.

*  Call the WS_DELIVEY_UPDATE in Background to avoid the popup
*  information messages/displaying the messages on status bar
    CALL FUNCTION 'HU_PACKING_REFRESH'.
    sy-oncom = 'V'.
    ls_vbkok-vbeln_vl = is_vbkok-vbeln_vl.

    CALL FUNCTION 'WS_DELIVERY_UPDATE'
      EXPORTING
        vbkok_wa                     = ls_vbkok
        synchron                     = iv_synchron
        no_messages_update           = iv_no_messages_update
        commit                       = iv_commit
        delivery                     = is_vbkok-vbeln_vl
        update_picking               = iv_update_picking
        nicht_sperren                = iv_nicht_sperren
        if_confirm_central           = iv_if_confirm_central
        if_wmpp                      = iv_if_wmpp
        if_get_delivery_buffered     = iv_if_get_delivery_buffered
        if_no_generic_system_service = iv_no_generic_system_service
        if_database_update           = iv_if_database_update
        if_no_init                   = iv_if_no_init
        if_no_read                   = iv_if_no_read
        if_error_messages_send_0     = iv_if_error_messages_send_0
        if_no_buffer_refresh         = iv_if_no_buffer_refresh
        it_partner_update            = iv_it_partner_update
        it_sernr_update              = iv_it_sernr_update
        if_no_remote_chg             = iv_if_no_remote_chg
        if_no_mes_upd_pack           = iv_if_no_mes_upd_pack
        if_late_delivery_upd         = iv_if_late_delivery_upd
      IMPORTING
        ef_error_any_0               = lv_error
        ef_error_in_item_deletion_0  = lv_item_del
        ef_error_in_pod_update_0     = lv_pod_update
        ef_error_in_interface_0      = lv_err_int
        ef_error_in_goods_issue_0    = lv_err_in_gi
        ef_error_in_final_check_0    = lv_err_final_chk
        ef_error_partner_update      = lv_err_part_upd
        ef_error_sernr_update        = lv_err_sernr_upd
      TABLES
        vbpok_tab                    = et_vbpok_tab[]
        prot                         = et_prot[]
        verko_tab                    = et_verko_tab[]
        verpo_tab                    = et_verpo_tab[]
        vbsupcon_tab                 = et_vbsupcon_tab[]
        it_verpo_sernr               = et_verpo_sernr[]
        it_packing                   = et_packing[]
        it_packing_sernr             = et_packing_sernr[]
        it_repack                    = et_repack[]
        it_handling_units            = et_handling_units[]
        it_objects                   = et_objects[]
        et_created_hus               = et_created_hus[]
        tvpod_tab                    = et_tvpod_tab[]
        sernr_tab                    = et_sernr_tab[]
        it_hures                     = et_hures[]
      EXCEPTIONS
        error_message                = 1.

    lv_subrc = sy-subrc. "BCB01

* Start of change JWILL68 CMS 32732 12/07/2018
* Get the system messge in the application table.
    DATA(ls_msg) = VALUE bal_s_msg( msgid = sy-msgid
                                    msgno = sy-msgno
                                    msgty = sy-msgty
                                    msgv1 = sy-msgv1
                                    msgv2 = sy-msgv2
                                    msgv3 = sy-msgv3
                                    alsort = lv_subrc ).
    APPEND ls_msg TO et_applog.
* End of change JWILL68 CMS 32732 12/06/2018

* After processing WS_DELIVERY_UPDATE setting sy-oncomm back to
* online transaction
    sy-oncom = 'T'.

    IF lv_subrc <> 0. "BCB01
      MESSAGE e205 INTO lv_message.
      lv_error = 'X'.
      MESSAGE e205 RAISING delivery_update_fail..
    ENDIF.

    IF lv_error = 'X'.
      MESSAGE e205 INTO lv_message.
    ELSEIF  lv_item_del = 'X'.
      MESSAGE e206 INTO lv_message.
    ELSEIF  lv_pod_update = 'X'.
      MESSAGE e207 INTO lv_message.
    ELSEIF  lv_err_int = 'X'.
      MESSAGE e208 INTO lv_message.
    ELSEIF  lv_err_in_gi = 'X'.
      MESSAGE e209 INTO lv_message.
    ELSEIF  lv_err_final_chk = 'X'.
      MESSAGE e210 INTO lv_message.
    ELSEIF  lv_err_part_upd = 'X'.
      MESSAGE e211 INTO lv_message.
    ELSEIF  lv_err_sernr_upd = 'X'.
      MESSAGE e212 INTO lv_message.
    ELSE.
      COMMIT WORK AND WAIT.
      MESSAGE s213 INTO lv_message.
    ENDIF.
  ENDMETHOD.


  METHOD save_delivery_new.
***********************************************************************
***********************************************************************
**                                                                    *
**             C O M P A N Y   C O N F I D E N T I A L                *
**                                                                    *
**        This program is the property of International Paper.        *
**        Care should be taken to pervent its unauthorized use.       *
**                                                                    *
***********************************************************************
***********************************************************************
**                                                                    *
**                    COPYRIGHT (C) 2018 by                           *
**                     INTERNATIONAL PAPER                            *
**                                                                    *
**                     ALL RIGHTS RESERVED                            *
**                                                                    *
**                   REVISIONS COPYRIGHT (C)                          *
**                                20XX                                *
**                             by                                     *
**                     INTERNATIONAL PAPER                            *
***********************************************************************
*_____________________________________________________________________*
* Program Name:CHECK_ADD_NEW_HU                                       *
*                                                                     *
*                                              Creation   : 12/28/2018*
*                                                                     *
* SAP Name    :DETERMINE_MSH_WEIGHT            Version    : Initial   *
*                                                                     *
* Programmer  :JWILL68                           Last Update:         *
*_____________________________________________________________________*
* Description: Include for implemeting the local class methods        *
*_____________________________________________________________________*
* Change History:                                                     *
*  Programmer     Date    CMS. #                  Action              *
* ============ ======== ========= ====================================*
* JWILL68       12/28/2018  32732   Initial Transport                 *
***********************************************************************
    DATA: lv_error         TYPE xfeld,
          lv_item_del      TYPE xfeld,
          lv_pod_update    TYPE xfeld,
          lv_err_int       TYPE xfeld,
          lv_err_in_gi     TYPE xfeld,
          lv_err_final_chk TYPE xfeld,
          lv_err_part_upd  TYPE xfeld,
          lv_err_sernr_upd TYPE xfeld.

    CLEAR: et_applog.
*  information messages/displaying the messages on status bar
    CALL FUNCTION 'HU_PACKING_REFRESH'.
    DATA(ls_vbkok) = VALUE vbkok( vbeln_vl = is_vbkok-vbeln_vl ).

    CALL FUNCTION 'WS_DELIVERY_UPDATE'
      EXPORTING
        vbkok_wa                     = ls_vbkok
        synchron                     = iv_synchron
        no_messages_update           = iv_no_messages_update
        commit                       = iv_commit
        delivery                     = is_vbkok-vbeln_vl
        update_picking               = iv_update_picking
        nicht_sperren                = iv_nicht_sperren
        if_confirm_central           = iv_if_confirm_central
        if_wmpp                      = iv_if_wmpp
        if_get_delivery_buffered     = iv_if_get_delivery_buffered
        if_no_generic_system_service = iv_no_generic_system_service
        if_database_update           = iv_if_database_update
        if_no_init                   = iv_if_no_init
        if_no_read                   = iv_if_no_read
        if_error_messages_send_0     = iv_if_error_messages_send_0
        if_no_buffer_refresh         = iv_if_no_buffer_refresh
        it_partner_update            = iv_it_partner_update
        it_sernr_update              = iv_it_sernr_update
        if_no_remote_chg             = iv_if_no_remote_chg
        if_no_mes_upd_pack           = iv_if_no_mes_upd_pack
        if_late_delivery_upd         = iv_if_late_delivery_upd
      IMPORTING
        ef_error_any_0               = lv_error
        ef_error_in_item_deletion_0  = lv_item_del
        ef_error_in_pod_update_0     = lv_pod_update
        ef_error_in_interface_0      = lv_err_int
        ef_error_in_goods_issue_0    = lv_err_in_gi
        ef_error_in_final_check_0    = lv_err_final_chk
        ef_error_partner_update      = lv_err_part_upd
        ef_error_sernr_update        = lv_err_sernr_upd
      TABLES
        vbpok_tab                    = et_vbpok_tab[]
        prot                         = et_prot[]
        verko_tab                    = et_verko_tab[]
        verpo_tab                    = et_verpo_tab[]
        vbsupcon_tab                 = et_vbsupcon_tab[]
        it_verpo_sernr               = et_verpo_sernr[]
        it_packing                   = et_packing[]
        it_packing_sernr             = et_packing_sernr[]
        it_repack                    = et_repack[]
        it_handling_units            = et_handling_units[]
        it_objects                   = et_objects[]
        et_created_hus               = et_created_hus[]
        tvpod_tab                    = et_tvpod_tab[]
        sernr_tab                    = et_sernr_tab[]
        it_hures                     = et_hures[]
      EXCEPTIONS
        error_message                = 1.

    DATA(lv_subrc) = sy-subrc. "BCB01

* Get the system messge in the application table.
    et_applog = VALUE zca_bal_msg_tab( ( msgid = sy-msgid
                                         msgno = sy-msgno
                                         msgty = sy-msgty
                                         msgv1 = sy-msgv1
                                         msgv2 = sy-msgv2
                                         msgv3 = sy-msgv3
                                         alsort = lv_subrc ) ).

    IF lv_subrc <> 0.
      lv_error = 'X'.
      MESSAGE e205 RAISING delivery_update_fail.
    ENDIF.

    IF lv_error <> abap_true.
      COMMIT WORK AND WAIT.
      MESSAGE s213 INTO DATA(lv_message).
    ENDIF.
  ENDMETHOD.


  METHOD set_message_buffer .

    CLEAR es_applog.
    es_applog-msgty = sy-msgty.
    es_applog-msgid = sy-msgid.
    es_applog-msgno = sy-msgno.
    es_applog-msgv1 = sy-msgv1.
    es_applog-msgv2 = sy-msgv2.
    es_applog-msgv3 = sy-msgv3.
    es_applog-msgv4 = sy-msgv4.

  ENDMETHOD.
ENDCLASS.

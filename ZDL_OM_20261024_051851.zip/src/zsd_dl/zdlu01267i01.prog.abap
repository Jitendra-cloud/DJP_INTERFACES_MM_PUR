*----------------------------------------------------------------------*
***INCLUDE ZSDU01267I01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  LEAVE_TRANSACTION_0100  INPUT
*&---------------------------------------------------------------------*
*       The Cancel button is clicked (the red X) from screen 0100
*----------------------------------------------------------------------*
MODULE LEAVE_TRANSACTION_0100 INPUT.

  PERFORM exit_0100.

ENDMODULE.                 " LEAVE_TRANSACTION_0100  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       User performs an action on screen 0100
*----------------------------------------------------------------------*
MODULE USER_COMMAND_0100 INPUT.

  ok_code = sy-ucomm.

  CASE ok_code.

*   User clicks 'Create Container' from Main screen mode of 0100. Screen
*   0100 will be displayed again but in Selection Screen mode
    WHEN 'CREATE'.

      gv_0100_mode = gc_selection_screen.

*   Execute button is clicked AFTER user selected 'Create Container'
    WHEN 'ONLI'.

      PERFORM validate_0100.  "Validate data entered on selection screen
      PERFORM retrieve_data.  "Retrieve data based on selection screen

*     Set the mode of screen 0200 to the List Selection screen
      gv_0200_mode = gc_list_selection.

      CALL SCREEN '0200'.     "Call List Screen of possible batches

*   Update Book Confirmation Number button is clicked
    WHEN 'UPDATE'.

      CALL TRANSACTION 'ZDLU01267_BKCON'.

      gv_0100_mode = gc_main_processing. "Go back to main screen

*   Output Tally button is clicked
    WHEN 'TALLY'.

*     Call Container Tally output program. This program presents the
*     user with a selection screen to determine what Containers are to
*     be outputted
      SUBMIT ZDL_F01316_CONT_TALLY_ALV VIA SELECTION-SCREEN AND RETURN.

      gv_0100_mode = gc_main_processing. "Go back to main screen

*   User clicked Back button
    WHEN 'BACK'.

      PERFORM exit_0100.

  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*&      Module  LEAVE_TRANSACTION_0200  INPUT
*&---------------------------------------------------------------------*
*       The Cancel button is clicked (the red X) from screen 0200
*----------------------------------------------------------------------*
MODULE LEAVE_TRANSACTION_0200 INPUT.

  PERFORM exit_0200.

ENDMODULE.                 " LEAVE_TRANSACTION_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*       User performs an action on screen 0200
*----------------------------------------------------------------------*
MODULE USER_COMMAND_0200 INPUT.

  DATA: seltab     TYPE TABLE OF rsparams,
        seltab_wa  LIKE LINE OF seltab,
        lv_repid LIKE sy-repid.

  ok_code = sy-ucomm.

  CASE ok_code.

*   Set screen 0200 mode based on user's action

*   User clicks Back button
    WHEN 'BACK'.

      PERFORM exit_0200.

*   User clicked to Confirm his/her selection
    WHEN 'CONFIRM'.

      PERFORM confirm_0200.

*   User was on List Confirmation Screen then clicked 'Create Container'
    WHEN 'CREATE'.

      PERFORM create_container_hu.

*     Set Screen 0200 mode based on whether the Container HU was created
*     successfully or not
      IF gv_container_created = gc_true.
        gv_0200_mode = gc_status.
      ELSE.
        gv_0200_mode = gc_list_confirmation.
      ENDIF.


*   User was on Status Screen after successfully creating the HU then
*   clicked to Print the Container Tally.
    WHEN 'TALLY'.

*     Stay on Status screen
      gv_0200_mode = gc_status.


*     Retrieve the Selection Screen parameters from Container Tally
*     Print program
      MOVE 'ZDL_F01316_CONTAINER_TALLY' TO lv_repid.
      CALL FUNCTION 'RS_REFRESH_FROM_SELECTOPTIONS'
        EXPORTING
          curr_report     = lv_repid
        TABLES
          selection_table = seltab
        EXCEPTIONS
          not_found       = 1
          no_report       = 2
          OTHERS          = 3.

*     Pre-populate certain Selection Screen field values
      IF seltab[] IS NOT INITIAL.
        LOOP AT seltab INTO seltab_wa
          WHERE selname = 'P_VENUM' OR    "Internal HU num for Container
                selname = 'P_NACHA'.      "Transmission Medium

          CASE seltab_wa-selname.

*           Format the Internal HU number field with the Container HU's
*           internal HU number that was just created.
            WHEN 'P_VENUM'.
            seltab_wa-sign = ' '.
            seltab_wa-option = ' '.
            seltab_wa-low = gv_container_venum.

*           Format the Transmission Medium to '1' so the Printing will
*           default to output 'Immediately'
            WHEN 'P_NACHA'.
            seltab_wa-sign = ' '.
            seltab_wa-option = ' '.
            seltab_wa-low = '1'.

          ENDCASE.
          MODIFY seltab FROM seltab_wa.
        ENDLOOP.

*       Submit program .
        SUBMIT ZDL_F01316_CONTAINER_TALLY
               WITH  SELECTION-TABLE seltab
               AND RETURN.
      ENDIF.

  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0200  INPUT

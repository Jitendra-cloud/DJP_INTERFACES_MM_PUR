
PROCESS BEFORE OUTPUT.
  MODULE status_0303.

PROCESS AFTER INPUT.

* Begin of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
  FIELD t30b-lgtor MODULE check_dock_door ON INPUT.
* End of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.

*Begin of R16I Big Button Update Staging  Area changes 10/13/09   *
  FIELD t30c-lgbzo MODULE check_staging_area ON INPUT.
*End of R16I Big Button Update Staging  Area changes 10/13/09   *


  CHAIN.
    FIELD : vtts-zz_load_ind ,
            vtts-zz_seal_no  ,
            vtts-zz_load_q1  ,
            vtts-zz_load_u1  ,
            vtts-zz_load_q2  ,
            vtts-zz_a_ls_dt  ,
            vtts-zz_a_ls_ti  ,
            vtts-zz_a_le_dt  ,
            vtts-zz_a_le_ti  ,
            vtts-datbg       ,
            vtts-uatbg       ,
*** 34502 - lines below commented out
*           vttk-signi, " 11/06/08 Transport # ESBK9A07VO
*** 34502 – end lines commented out
*** 34502 - start
            vttk-signi module check_signi,
*** 34502 - end
* begin of change / nparchu / V4W3
            vtts-zz_p_ls_dt  ,
            vtts-zz_p_ls_ti  ,
            vtts-zz_p_le_dt  ,
            vtts-zz_p_le_ti  ,
            vtts-dptbg,
            vtts-uptbg,
* end of change / nparchu / V4W3
            vttk-exti2. "R16I Big Button Update Stg.Area chgs. 10/13/09
    MODULE user_command_0303.
  ENDCHAIN.
* Begin of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
PROCESS ON VALUE-REQUEST.
  FIELD t30b-lgtor MODULE create_dropdown_box.
  FIELD t30c-lgbzo MODULE create_f4_help.
* End of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.

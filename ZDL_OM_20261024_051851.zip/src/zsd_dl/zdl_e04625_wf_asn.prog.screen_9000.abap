
PROCESS BEFORE OUTPUT.
* Initialize variables
  MODULE status_9000.
*
PROCESS AFTER INPUT.
* The Cancel button (red X) will be defined with a
* function type of 'E' on our pf-status.
  MODULE cancel_9000 AT EXIT-COMMAND.

* Handle user interaction
  MODULE user_command_9000.

class ZCL_IM__BI_DL_E10544_1 definition
  public
  final
  create public .

public section.

  interfaces IF_EX_SMOD_V50B0001 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM__BI_DL_E10544_1 IMPLEMENTATION.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50I_001.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50I_002.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50I_003.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50I_004.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50I_009.
  endmethod.


  METHOD if_ex_smod_v50b0001~exit_saplv50i_010.

* CMS: 28322| Changed By: AMAOLE1| Changed On: 03/13/2015
* Table EXTENSION2 information is imported by - BAdI imp. Z_BI_DL_E10544_2 for BAdI LE_SHP_DELIVERY_PROC
* Method CHANGE_DELIVERY_HEADER

  IF extension2[] IS NOT INITIAL.
    EXPORT extension2 = extension2 TO MEMORY ID 'SMOD_V50B0001'.
  ENDIF.

  ENDMETHOD.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_005.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_006.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_007.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_008.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_011.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_012.
  endmethod.


  method IF_EX_SMOD_V50B0001~EXIT_SAPLV50K_013.
  endmethod.
ENDCLASS.

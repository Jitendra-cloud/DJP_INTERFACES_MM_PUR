class ZCL_DL_HU definition
  public
  create public .

*"* public components of class ZCL_DL_HU
*"* do not include other source files here!!!
public section.

  methods CONSTRUCTOR
    importing
      value(IV_EXIDV) type EXIDV optional
      !IV_VENUM type VENUM optional
      !IS_HU_DATA type ZDL_WM_HU_DATA_S optional
    exceptions
      INVALID_DATA
      HU_NOT_FOUND .
  class-methods CHECK_HU
    importing
      value(IV_EXIDV) type EXIDV
    exporting
      value(EV_VENUM) type VENUM
      value(EV_STATUS) type HU_STATUS
    exceptions
      HU_NOT_FOUND .
  class-methods CREATE_HU
    importing
      value(IS_HU_HDR) type ZDL_HU_HDR
      value(IT_ITEM) type ZDL_HU_ITM optional
    exporting
      !ES_HEAD type BAPIHUHEADER
      !ET_RETURN type TT_BAPIRET2
    exceptions
      INVALID_DATA .
  class-methods DELETE_HU
    importing
      value(IV_EXIDV) type BAPIHUKEY-HU_EXID
    exporting
      !ET_RETURN type TT_BAPIRET2
    exceptions
      HU_NOT_FOUND .
  methods GET_HU_DETAILS
    exporting
      !ET_HU_HDR type HUM_HU_HEADER_T
      !ET_HU_ITM type HUM_HU_ITEM_T .
  class-methods GET_PACK_MAT
    importing
      !IV_WERKS type WERKS_D
    exporting
      !EV_MATNR type MATNR
    exceptions
      NO_PACKMAT_FOUND .
  class-methods GET_HU_OBJECTS
    importing
      !IT_EXIDV type HUM_EXIDV_T optional
      !IT_VENUM type HUM_VENUM_T optional
    returning
      value(RT_HU_OBJECTS) type ZDL_WM_HU_OBJ_T
    exceptions
      INVALID_DATA .
  class-methods CHANGE_HU_STATUS_0020
    importing
      value(IV_EXIDV) type BAPIHUKEY-HU_EXID
    exporting
      !ET_RETURN type TT_BAPIRET2
    exceptions
      HU_NOT_FOUND .
protected section.
*"* protected components of class ZCL_DL_HU
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_DL_HU
*"* do not include other source files here!!!

  data GS_DATA type ZDL_WM_HU_DATA_S .
ENDCLASS.



CLASS ZCL_DL_HU IMPLEMENTATION.


METHOD change_hu_status_0020 .

  TYPE-POOLS: vsep.

  DATA: lt_return TYPE tt_bapiret2,
        ls_return TYPE bapiret2.

  DATA: lv_venum  TYPE venum,     "Internal HU
        lv_status TYPE hu_status. "HU status

  DATA:
    ls_header         TYPE vekpvb,    "structure of HU Headers
    ls_status         TYPE hum_jstat, "structure of HU statuses
    ls_handling_unit  TYPE huitem_from,
    lt_changed_fields TYPE vsep_t_changed,
    ls_changed_fields TYPE v51p_changed.

  CONSTANTS:
     lc_object_03     TYPE vpobj          VALUE '03',
     lc_activity_hu01 TYPE hu_st_activity VALUE 'HU01',
     lc_status_i0522  TYPE jstat          VALUE 'I0522',
     lc_inact         TYPE xfeld          VALUE 'X',
     lc_status_0020   TYPE hu_status      VALUE '0020'.


  CLEAR: et_return.

* Check HU
  CALL METHOD check_hu
    EXPORTING
      iv_exidv     = iv_exidv
    IMPORTING
      ev_venum     = lv_venum
      ev_status    = lv_status
    EXCEPTIONS
      hu_not_found = 1
      OTHERS       = 2.
  IF sy-subrc <> 0.
    MESSAGE e201 RAISING hu_not_found.
  ENDIF.

* Only continue if the HU is not in a status of '0020'. If the HU is
* already in a status of '0020' then it can be Deleted. If it is NOT in
* a status of '0020' then we need to change it to '0020' so it CAN be
* deleted.
  CHECK lv_status NE lc_status_0020.


* For this particular HU, turn off (make inactive) the I0522 status.
* This sets the status from "In Transit" to "In Warehouse and
* physically existing".
  CLEAR: ls_status,
         ls_handling_unit.

  ls_status-stat  = lc_status_i0522.
  ls_status-inact = lc_inact.
  ls_handling_unit-venum = lv_venum. "Internal HU
  ls_handling_unit-exidv = iv_exidv. "External HU

  CALL FUNCTION 'HU_STATUS_SET'
    EXPORTING
      if_object        = lc_object_03
      if_activity      = lc_activity_hu01
      if_compl_contens = 'X'
      is_status        = ls_status
      is_handling_unit = ls_handling_unit
    EXCEPTIONS
      not_possible     = 1
      error            = 2
      OTHERS           = 3.
  IF sy-subrc <> 0.
*   HU Status could not be changed
    ls_return-type = 'E'.
    ls_return-id = 'ZSD_DL_HU'.
    ls_return-number = 206.
    APPEND ls_return TO et_return.
    EXIT.
  ENDIF.


  CLEAR: lt_changed_fields[].
* Set the HU Header status to 'Stock at non-HU storage location
  CLEAR ls_changed_fields.
  ls_changed_fields-changed_f = 'STATUS'.
  ls_changed_fields-f_value = lc_status_0020.
  APPEND ls_changed_fields TO lt_changed_fields.
* Set the type of object, the HU is packed into, to
* 'Non-Assigned Handling Unit'
  CLEAR ls_changed_fields.
  ls_changed_fields-changed_f = 'VPOBJ'.
  ls_changed_fields-f_value = '12'.
  APPEND ls_changed_fields TO lt_changed_fields.
  CLEAR ls_changed_fields.
  break bballeh.
* Update the HU Header Status
  CALL FUNCTION 'V51F_HU_HEADER_UPDATE'
    EXPORTING
      if_with_update    = 'X'
      is_header         = ls_header
      it_changed_fields = lt_changed_fields.
  IF sy-subrc <> 0.
*   HU Status could not be changed
    ls_return-type = 'E'.
    ls_return-id = 'ZSD_DL_HU'.
    ls_return-number = 206.
    APPEND ls_return TO et_return.
    EXIT.
  ENDIF.

ENDMETHOD.


METHOD check_hu .

  DATA lv_exidv TYPE exidv.

* Validate Handling Unit
  SELECT SINGLE exidv  "external hu
                venum  "internal hu
                status "hu status
    INTO (lv_exidv, ev_venum, ev_status)
    FROM vekp
    WHERE exidv = iv_exidv.
  IF sy-subrc NE 0.
    MESSAGE e201 WITH iv_exidv RAISING hu_not_found.
  ENDIF.

ENDMETHOD.


METHOD constructor .

  DATA: lt_exidv TYPE hum_exidv_t,
        ls_exidv TYPE hum_exidv,
        lt_venum TYPE hum_venum_t,
        ls_venum TYPE hum_venum.

  IF is_hu_data IS NOT INITIAL.
    gs_data = is_hu_data.
    RETURN.
  ENDIF.

** Any one of EXIDV or VENUM should be passed
  IF iv_exidv IS INITIAL AND
     iv_venum IS INITIAL.
    MESSAGE e200 RAISING invalid_data.
  ENDIF.

** Pass Import parameter values into local Internal tables
  IF iv_venum IS NOT INITIAL AND
     iv_exidv IS NOT INITIAL.
    ls_venum = iv_venum.
    APPEND ls_venum TO lt_venum.
  ELSEIF iv_venum IS NOT INITIAL.
    ls_venum = iv_venum.
    APPEND ls_venum TO lt_venum.
  ELSEIF iv_exidv IS NOT INITIAL.
    ls_exidv = iv_exidv.
    APPEND ls_exidv TO lt_exidv.
  ENDIF.
* Need to refresh buffer tables
  CALL FUNCTION 'HU_PACKING_REFRESH'.

** Get HU details
  CALL FUNCTION 'HU_GET_HUS'
    EXPORTING
      it_hus      = lt_exidv[]
      it_venum    = lt_venum[]
    IMPORTING
      et_header   = gs_data-vekp[]
      et_items    = gs_data-vepo[]
    EXCEPTIONS
      hus_locked  = 1
      no_hu_found = 2
      fatal_error = 3
      OTHERS      = 4.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING invalid_data.
  ENDIF.

ENDMETHOD.


METHOD create_hu .
  DATA: lv_head   TYPE bapihuhdrproposal,
        lt_return TYPE tt_bapiret2,
        ls_return TYPE bapiret2.

  CONSTANTS: lc_a TYPE c VALUE 'A',
             lc_b TYPE c VALUE 'B',
             lc_c TYPE c VALUE 'C'.
* initialize Exporting parameter.
  CLEAR: et_return.

** A, B and C are valid statuses
  IF is_hu_hdr-hu_status_init <> lc_a AND
     is_hu_hdr-hu_status_init <> lc_b AND
     is_hu_hdr-hu_status_init <> lc_c .
    MESSAGE e205 RAISING invalid_data.
  ENDIF.

** HU header data
  lv_head-hu_status_init = is_hu_hdr-hu_status_init.
  lv_head-pack_mat       = is_hu_hdr-pack_mat.
  lv_head-hu_exid        = is_hu_hdr-hu_exid.
  lv_head-plant          = is_hu_hdr-plant.

  IF lv_head-pack_mat IS INITIAL AND
     lv_head-plant IS INITIAL.
    MESSAGE e204 RAISING invalid_data.

  ELSEIF lv_head-pack_mat IS INITIAL AND
         lv_head-plant IS NOT INITIAL.

    CALL METHOD zcl_dl_hu=>get_pack_mat
      EXPORTING
        iv_werks         = lv_head-plant
      IMPORTING
        ev_matnr         = lv_head-pack_mat
      EXCEPTIONS
        no_packmat_found = 1
        OTHERS           = 2.
    IF sy-subrc <> 0.
      MESSAGE e202 RAISING invalid_data.
    ENDIF.
  ENDIF.

  CALL FUNCTION 'HU_PACKING_REFRESH'.

** Create HU
  CALL FUNCTION 'BAPI_HU_CREATE'
    EXPORTING
      headerproposal = lv_head
    IMPORTING
      huheader       = es_head
    TABLES
      itemsproposal  = it_item[]
      return         = lt_return[].

  READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
  IF sy-subrc NE 0.
** Commit
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait = 'X'.
  ENDIF.

  APPEND LINES OF lt_return TO et_return.

* Start of changes JWILL68 CMS 32732 12/07/2018
* Fill the export table based on the T-Code for error analysis
* This will be removed after error analysis.
*  IF sy-tcode = 'ZDL_RF_CASE_PICK' OR
*     sy-tcode = 'ZDL_WM_E04515'.
*    APPEND LINES OF lt_return TO et_return_error_analysis.
*  ENDIF.
* End of changes JWILL68 CMS 32732 12/07/2018
ENDMETHOD.


METHOD delete_hu .
  DATA: lt_return TYPE tt_bapiret2,
        ls_return TYPE bapiret2.

** Check HU
  CALL METHOD check_hu
    EXPORTING
      iv_exidv     = iv_exidv
    EXCEPTIONS
      hu_not_found = 1
      OTHERS       = 2.

  IF sy-subrc <> 0.
    MESSAGE e201 RAISING hu_not_found.
  ELSE.

** Delete HU
    CALL FUNCTION 'BAPI_HU_DELETE'
      EXPORTING
        hukey  = iv_exidv
      TABLES
        return = lt_return[].
  ENDIF.

  READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
  IF sy-subrc NE 0.
** Commit
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        WAIT = 'X'.
  ENDIF.
  APPEND LINES OF lt_return TO et_return.
ENDMETHOD.


METHOD GET_HU_DETAILS .
  et_hu_hdr[] = gs_data-vekp[].
  et_hu_itm[] = gs_data-vepo[].
ENDMETHOD.


METHOD get_hu_objects .
  DATA: lt_hu_head    TYPE hum_hu_header_t,
        ls_hu_head    TYPE vekpvb,
        lt_hu_item    TYPE hum_hu_item_t,
        ls_hu_item    TYPE vepovb,
        ls_data       TYPE zdl_wm_hu_data_s,
        lo_hu_object  TYPE REF TO zcl_dl_hu,
        ls_hu_object  TYPE zdl_wm_hu_obj_s,
        lv_message    TYPE string.

  CONSTANTS: lc_3     TYPE vepo-velin VALUE '3'.  " Handling Unit

** If no Handling units is passed
  IF it_exidv[] IS NOT INITIAL AND
     it_venum[] IS NOT INITIAL.
    MESSAGE e203 RAISING invalid_data.
  ENDIF.

* Get details of the child HU
  CALL FUNCTION 'HU_GET_HUS'
    EXPORTING
      it_hus      = it_exidv[]
      it_venum    = it_venum[]
    IMPORTING
      et_header   = lt_hu_head[]
      et_items    = lt_hu_item[]
    EXCEPTIONS
      hus_locked  = 1
      no_hu_found = 2
      fatal_error = 3
      OTHERS      = 4.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
            RAISING invalid_data.
  ENDIF.

  SORT lt_hu_head BY exidv venum.
  SORT lt_hu_item BY venum.

  LOOP AT lt_hu_head INTO ls_hu_head.
    CLEAR ls_data.
    APPEND ls_hu_head TO ls_data-vekp.
    LOOP AT lt_hu_item INTO ls_hu_item WHERE venum = ls_hu_head-venum.
      APPEND ls_hu_item TO ls_data-vepo.
** In case of Pick pallets Item type is Handling Unit(3) then read the
** items using Lower level HU append them to HU item table
      IF ls_hu_item-velin EQ lc_3.
        READ TABLE lt_hu_item INTO ls_hu_item
          WITH KEY venum = ls_hu_item-unvel.
        IF sy-subrc = 0.
          APPEND ls_hu_item TO ls_data-vepo.
        ENDIF.
      ENDIF.
    ENDLOOP.

    CREATE OBJECT lo_hu_object
      EXPORTING
        is_hu_data   = ls_data
      EXCEPTIONS
        invalid_data = 1
        OTHERS       = 2.

** Append the objects to Return tables parameter
    ls_hu_object-exidv = ls_hu_head-exidv.
    ls_hu_object-venum = ls_hu_head-venum.
    ls_hu_object-hu_obj = lo_hu_object.
    APPEND ls_hu_object TO rt_hu_objects.
  ENDLOOP.
  FREE lo_hu_object.
ENDMETHOD.


METHOD get_pack_mat .
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date  Req. #              Action               *
* ================== ======== ======     ==============================*
* Bruce Ballehr      06/23/10 E0VK974575 USD5468793 R17 CO 114587 b/f  *
*                                                                      *
*                                        There should only ever be one *
*                                        Packaging Material for        *
*                                        NON-Container HU packing. The *
*                                        MARA-MTART = 'VERP' and the   *
*                                        MART-VHART = 'PKG'. The old   *
*                                        code was retrieving the wrong *
*                                        Material.                     *
*                                                                      *
*                                        (Just a note that if we       *
*                                         wanted to retrieve the lone  *
*                                         Container Packaging Material *
*                                         we would look for            *
*                                         MARA-MTART = 'VERP' and the  *
*                                         MART-VHART = 'CONT'.         *                                                                      *
*                                                                      *
*                                        * Search program code change  *
*                                          tag BCB01 for this change.  *
*----------------------------------------------------------------------*

* Begin BCB01 delete
*  DATA: lt_matnr TYPE TABLE OF matnr,
*        ls_matnr TYPE matnr.
*
*  CONSTANTS: lc_verp TYPE mtart VALUE 'VERP',
*             lc_292 TYPE matkl VALUE '292'.
*
*
*** Get the Packing Material for the Plant where Material type is VERP
*** and Material group is 292.
*  SELECT mara~matnr INTO TABLE lt_matnr FROM mara INNER JOIN marc
*                                ON mara~matnr = marc~matnr
*                                WHERE mara~mtart = lc_verp
*                                  AND mara~matkl = lc_292
*                                  AND marc~werks = iv_werks.
*
*** In case of multiple Packing materials
*  READ TABLE lt_matnr INTO ls_matnr INDEX 1.
*  IF sy-subrc = 0.
*    ev_matnr = ls_matnr.
*  ELSE.
*    MESSAGE e202 RAISING no_packmat_found.
*  ENDIF.
* Begin BCB01 delete

* Begin BCB01 insert
  CONSTANTS: lc_verp  TYPE mtart  VALUE 'VERP',
             lc_vhart TYPE vhiart VALUE 'PKG'.

* Retrieve the Packaging Material. There should only ever be one (1)
* of these. The VHART = 'PKG' and the MTART = 'VERP'.
  CLEAR: ev_matnr.
  SELECT SINGLE matnr INTO ev_matnr FROM mara
    WHERE mtart = lc_verp
      AND vhart = lc_vhart.
  IF sy-subrc NE 0.
    MESSAGE e202 RAISING no_packmat_found.
  ENDIF.
* End BCB01 insert

ENDMETHOD.
ENDCLASS.

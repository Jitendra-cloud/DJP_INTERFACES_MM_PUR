*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDLU01267TOP.                     " Global Data
  INCLUDE LZDLU01267UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDLU01267F...                     " Subroutines
* INCLUDE LZDLU01267O...                     " PBO-Modules
* INCLUDE LZDLU01267I...                     " PAI-Modules
* INCLUDE LZDLU01267E...                     " Events
* INCLUDE LZDLU01267P...                     " Local class implement.
* INCLUDE LZDLU01267T99.                     " ABAP Unit tests
  INCLUDE LZDLU01267F00                           . " subprograms
  INCLUDE LZDLU01267I00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules


FUNCTION zsd_dl_i02249_shpmnt_outbound.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  IMPORTING
*"     VALUE(CONTROL_RECORD_OUT) TYPE  EDIDC
*"     VALUE(MESSAGE_TYPE) TYPE  EDMSG-MSGTYP
*"     VALUE(SEGMENT_NAME) TYPE  EDIDD-SEGNAM
*"     REFERENCE(DATA) TYPE  TR_IDOC_SHPMNT_INDATA
*"  TABLES
*"      IDOC_DATA STRUCTURE  EDIDD
*"  EXCEPTIONS
*"      ERROR_MESSAGE_RECEIVED
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                REVISIONS COPYRIGHT (C) 2005                        **
**                   by INTERNATIONAL PAPER                           **
*______________________________________________________________________*
* Include Name: ZSD_DL_I02249_SHPMNT_OUTBOUND         Date: 07/28/2005 *
*                                                                      *
* Programmer  : Savithri Renganathan                                   *
*______________________________________________________________________*
* Description :                                                        *
*  Function to change the SAP standard SHPMNT05 IDoc with for use in   *
*  outbound shipments/deliveries to Apriso Flexnet for V2.             *
*                                                                      *
*  Logics are included:                                                *
*    1.  To check for 'planned' status.  If it is set, send IDoc;      *
*          else, don't send.                                           *
*    2.  To fetch Allowed Weight E1EDT20.E1EDL37.MAGEW from table VEKP.*
*    3.  To filter out batch split line item.                          *
*    4.  To count for number of delivery items E1EDT20.GESZTD - exclude*
*        batch split items.                                            *
*    5.  To fetch booking number E1EDT20.E1EDL20.LIFEX from LIKP.      *
*    6.  To fetch tolerance % UEBTO and UNTTO from (TBD - 07/28/05).   *
*        08/23/05 - Take tolerance from LIPS table for SO              *
*                   or take tolerance from ZSP_VALUE table for STO     *
*    7.  Convert Delivery Quantity into Base UOM.                      *
*    8.  To check whether all required fields are entered.             *
*    9.  To truncate deliveries that does not correspond to stages     *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
* Date       TPR #/Progr Ch#  Remarks                                  *
*                                                                      *
* 01/23/2006  TPR# 11627  Apriso can't understand decimal value in the *
*                         UOM field.  Raise an error if E1EDL24-LGMNG  *
*                         contains decimal value.                      *
* 04/04/2006              Convert ISO code into SAP in E1EDL24-VRKME,  *
*                         MEINS & GEWEI. Req. # EDVK944933             *
* 06/05/2006  CRAMEY      Added logic to convert TONS to LBS since     *
*                         Apriso can't handle TONS - CR4645            *
*                                                                      *
* 07/25/06  TPR# 12964/ 4 Missing segment E1EDT01 for split-delivery   *
*             Savithri    case.  Since shipments are hitting at same   *
*                         LUW, reset the counter.                      *
*                                                                      *
* 12/12/2006 CR05601        Populate Segment E1EDL43 for Delivery Type *
*            Anand Dhumbala 'ZLO'(Delivery w/o Ref.).                  *
*                                                                      *
* 03/8/2007  CO73971       Street Number does not gets printed on the  *
*            Sabitha       BOL document: Solution : Populate           *
*                          E1EDT20.E1EDT20.E1ADRM1WE-STREET1 with      *
*                          ADRC-HOUSE_NUM1 + ADRC-STREET .             *
*______________________________________________________________________*

************************************************************************
* External Calls                                                       *
*   Function Modules:                                                  *
*                    Z_CHECK_REQ_FIELDS                                *
*______________________________________________________________________*

*----------------------------------------------------------------------*
* CONSTANTS
*----------------------------------------------------------------------*
  CONSTANTS:
      lc_zsdshpmnt_mestyp    TYPE edi_mestyp   VALUE 'ZSDSHPMNT_APRISO',
      lc_final_run           TYPE  edilsegtyp  VALUE 'FINAL_RUN',

* Start of changes by Anand Dhumbala CR05601
      lc_lfart(4) VALUE 'ZLO',
      lc_e1edl20_seg TYPE  edilsegtyp  VALUE 'E1EDL20',
      lc_e1edl24_seg TYPE  edilsegtyp  VALUE 'E1EDL24',
      lc_e1edl43_seg TYPE  edilsegtyp  VALUE 'E1EDL43'.
* Delivery Header Data
  DATA: BEGIN OF st_e1edl20.
          INCLUDE STRUCTURE e1edl20.
  DATA: END OF st_e1edl20.
* Work area to hold Delivery Header information
  DATA: BEGIN OF wa_data_likp.
          INCLUDE STRUCTURE likp.
  DATA: END OF wa_data_likp.
* IDoc: Reference
  DATA: BEGIN OF st_e1edl43.
          INCLUDE STRUCTURE e1edl43.
  DATA: END OF st_e1edl43.
* End of changes by Anand Dhumbala CR05601

* start of  Change CO73971
  DATA: lv_adrnr      LIKE vbpa-adrnr,
        lv_house_rang LIKE adrc-house_num1,
        lv_street     LIKE adrc-street,
        lv_street1    LIKE e1adrm1-street1,
        lv_shipto     LIKE vbpa-parvw.


  CONSTANTS: lc_shipto   TYPE vbpa-parvw VALUE 'WE',
             lc_e1adrm1  TYPE edilsegtyp VALUE 'E1ADRM1'.

* End of Change CO73971

* Check for message type
  CHECK message_type = lc_zsdshpmnt_mestyp.

* begin of change CO73971

  DESCRIBE TABLE idoc_data LINES gv_segments.
  READ TABLE idoc_data INDEX gv_segments.
  IF gv_segments IS NOT INITIAL.
    gv_last_segment_added = idoc_data-segnam.
    gv_segment_data       = idoc_data-sdata.
    IF gv_last_segment_added = 'E1EDL20'.
      CLEAR gs_e1edl20.
      gs_e1edl20 = idoc_data-sdata.
      gv_vbeln = gs_e1edl20-vbeln.
    ENDIF.
  ENDIF.

* end of change CO73971


  CASE segment_name.
* Start of changes by Anand Dhumbala CR05601
    WHEN lc_e1edl20_seg.
* Retrieve Sales Order number
      CLEAR gv_bolnr.
      READ TABLE idoc_data INDEX sy-tabix.
      MOVE idoc_data-sdata  TO st_e1edl20.

      READ TABLE data-tab_likp INTO wa_data_likp
                               WITH KEY vbeln = st_e1edl20-vbeln
                                        lfart = lc_lfart.  "ZLO.
      IF sy-subrc = 0.
        gv_bolnr = wa_data_likp-bolnr.
*       gv_bolnr = st_e1edl20-bolnr.
      ENDIF.

* Start of Change CO73971
    WHEN lc_e1adrm1.
      PERFORM get_street_num CHANGING lv_street1.
* End of Change CO73971


    WHEN lc_e1edl24_seg.
* Populate Segment 'E1EDL43'
      IF NOT gv_bolnr IS INITIAL.   " Sales Order
        CLEAR st_e1edl43.
        st_e1edl43-qualf = c_qualf.
        st_e1edl43-belnr = gv_bolnr.
        SELECT SINGLE posnr FROM vbap
                            INTO st_e1edl43-posnr
                            WHERE vbeln = gv_bolnr.
        st_e1edl43-datum = sy-datum.
        MOVE st_e1edl43      TO idoc_data-sdata.
        MOVE lc_e1edl43_seg  TO idoc_data-segnam.
        APPEND idoc_data.
* To adjust the IDOC structure if atleast one 'E1EDL43' segment
* is added.
        gv_flag_idoc_syntax = 'X'.
      ENDIF.


* End of changes by Anand Dhumbala CR05601
    WHEN lc_final_run.
* Start of changes by Anand Dhumbala CR05601
* Adjust the IDOC_DATA structure to match the 'SHPMNT05' Idoc
      IF NOT gv_flag_idoc_syntax IS INITIAL.
        PERFORM test_idoc_syntax.
      ENDIF.
* End of changes by Anand Dhumbala CR05601
      PERFORM process_final_run.
  ENDCASE.


ENDFUNCTION.

*&---------------------------------------------------------------------*
*&      Form  test_idoc_syntax
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM test_idoc_syntax.

  DATA: lv_idoctyp TYPE edi_iapi00-idoctyp
                   VALUE 'SHPMNT05',
        lv_cimtyp TYPE edi_iapi00-cimtyp
                   VALUE ''.
  DATA: BEGIN OF st_syntax_table.
          INCLUDE STRUCTURE edi_iapi06.
  DATA:  END OF st_syntax_table.
  DATA : lv_flag TYPE c.
  DATA: it_syntax_table LIKE STANDARD TABLE OF edi_iapi06.
*  data : lt_idoc_data like STANDARD TABLE OF EDIDD with header line.
  DATA : st_idoc_e1edl43 LIKE edidd.
  DATA : st_idoc_data LIKE edidd.
  DATA : w_int_tabix LIKE sy-tabix,
         w_fin_tabix LIKE sy-tabix.
  REFRESH : it_syntax_table.


  CALL FUNCTION 'EDI_IDOC_SYNTAX_GET'
    EXPORTING
      pi_idoctyp       = lv_idoctyp
      pi_cimtyp        = lv_cimtyp
    TABLES
      pt_syntax_table  = it_syntax_table
    EXCEPTIONS
      syntax_not_found = 1
      OTHERS           = 2.

  CLEAR lv_flag.

  LOOP AT it_syntax_table INTO st_syntax_table.
    IF lv_flag IS INITIAL.
      DELETE it_syntax_table INDEX sy-tabix.
    ENDIF.
    IF st_syntax_table-segtyp = 'E1EDL24' .
      lv_flag = 'X'.
    ELSEIF st_syntax_table-segtyp = 'E1EDL43'.
      CLEAR : lv_flag  .
    ENDIF.
  ENDLOOP.


  CLEAR lv_flag.

  LOOP AT idoc_data.
    CASE idoc_data-segnam .
      WHEN 'E1EDL43' .
        IF lv_flag IS INITIAL.
          lv_flag = 'X'.
          CLEAR : w_int_tabix  , st_idoc_e1edl43.
          w_int_tabix = sy-tabix.
          st_idoc_e1edl43 = idoc_data.
        ENDIF.
    ENDCASE.

    CLEAR : w_fin_tabix .
    w_fin_tabix = sy-tabix - 1.

    IF NOT lv_flag IS INITIAL.
      CLEAR : st_syntax_table.
      READ TABLE it_syntax_table INTO st_syntax_table
                           WITH KEY segtyp = idoc_data-segnam.
      IF sy-subrc <> 0.
        CLEAR lv_flag .
        DELETE idoc_data INDEX w_int_tabix .
        INSERT st_idoc_e1edl43 INTO idoc_data INDEX w_fin_tabix.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF NOT lv_flag IS INITIAL.
    CLEAR lv_flag.
    w_fin_tabix = w_fin_tabix + 1 .
    DELETE idoc_data INDEX w_int_tabix .
    INSERT st_idoc_e1edl43 INTO idoc_data INDEX w_fin_tabix.
    CLEAR : w_fin_tabix , w_int_tabix .
  ENDIF.

ENDFORM.                    "test_idoc_syntax
*&---------------------------------------------------------------------*
*&      Form  process_final_run
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM process_final_run.
  CONSTANTS:
*    SHPMNT05 IDoc Segments referenced
       lc_e1edt20  TYPE edilsegtyp VALUE 'E1EDT20',  "Shipment
     lc_e1edl37  TYPE edilsegtyp VALUE 'E1EDL37',  "Shipment unit Header
       lc_e1edl20  TYPE edilsegtyp VALUE 'E1EDL20',  "Delivery Header
       lc_e1edl24  TYPE edilsegtyp VALUE 'E1EDL24',  "Delivery item
       lc_e1edl26  TYPE edilsegtyp VALUE 'E1EDL26',  "Del. Item.Add.Data
       lc_e1edl43  TYPE edilsegtyp VALUE 'E1EDL43',  "Del. Item.Add.Data
       lc_e1edk33  TYPE edilsegtyp VALUE 'E1EDK33',  "Shipment Stage
       lc_e1edt01  TYPE edilsegtyp VALUE 'E1EDT01',  "Shipment Item .

* Constants for application logging
  lc_log_object       TYPE balobj_d  VALUE 'ZDL_INTERFACE',
  lc_log_subobj       TYPE balsubobj VALUE 'ZDL_I2249_AHD_TICKET'.


* Local variable to hold TABIX for internal table gt_e1edl24_qty
  DATA: l_tabix     LIKE sy-tabix VALUE 0,
        lv_vbeln    LIKE lips-vbeln,
        lv_posnr    LIKE lips-posnr,
        lv_bat_flag(1),
        lv_sytabix LIKE sy-tabix,
        lv_message TYPE string,
        lv_tknum    TYPE char50,  "to store ship. # for message

* Application log
        lo_log    TYPE REF TO zcl_ca_applogging,
        ls_log    TYPE bal_s_log,
        l_weight       LIKE vekp-magew.

  CLEAR: gs_idoc_data,   gt_e1edl24_qty,  gt_tol,   gt_tol_c, gt_del,
         gt_del_val,     gv_subrc,        gv_tknum, gv_e1edt20_index,
         gv_countr,   gv_deliv_item_ctr, gv_sytabix, gv_vrkme, gv_cuobj.

  REFRESH: gt_e1edl24_qty, gt_tol,     gt_tol_c,    gt_vc,
           gt_del,         gt_del_val, gt_zsp_value, gt_conf_out.

** FIRST PASS of idoc data - Store relevant delivery line item info in
** order to perform only a single SELECT
  LOOP AT idoc_data INTO gs_idoc_data
     WHERE ( segnam = lc_e1edl20 OR segnam = lc_e1edl24
             OR segnam = lc_e1edl43 OR segnam = lc_e1edk33
             OR segnam = lc_e1edt01 ).
    CASE gs_idoc_data-segnam.
*   Store Delivery Number
      WHEN lc_e1edl20.
        gs_e1edl20     = gs_idoc_data-sdata.
        lv_vbeln       = gs_e1edl20-vbeln.
        gt_tol-countr  = gt_tol-countr + 100.
*   Collect Delivery Number / Delivery Item Numbers into internal table
      WHEN lc_e1edl24.
        gs_e1edl24    = gs_idoc_data-sdata.
        lv_posnr      = gs_e1edl24-posnr.
        gt_tol-countr = gt_tol-countr + 10.
*  Keep track of matnr and idoc_data index for batch managed one       *
*  materials                                                           *
        IF gs_e1edl24-charg <> ' '.
          lv_bat_flag = 'Y'.
          gt_e1edl24_qty-lgmng = gs_e1edl24-lgmng.
          gt_e1edl24_qty-vrkme = gs_e1edl24-vrkme.
          gt_e1edl24_qty-matnr = gs_e1edl24-matnr.
          gt_e1edl24_qty-index = sy-tabix.
        ELSE.
          lv_bat_flag = 'N'.
        ENDIF.
* For tolerance calculation.  E1EDL43 holds the type of sales document
*
      WHEN lc_e1edl43.
        gs_e1edl43    = gs_idoc_data-sdata.
        IF gs_e1edl43-qualf = 'C'.            "Sales Order
          gt_tol-vbeln  = lv_vbeln.
          gt_tol-posnr  = lv_posnr.
          gt_tol-countr = gt_tol-countr + 1.
          APPEND gt_tol.
          CLEAR: gt_tol-vbeln, gt_tol-posnr.
        ELSEIF gs_e1edl43-qualf = 'V'.        " STO
          gt_tol-countr = gt_tol-countr + 1.
        ENDIF.
        IF lv_bat_flag = 'Y'.
*        " For Base UOM conv - only for batch managed materials
          gt_e1edl24_qty-vbeln = gs_e1edl43-belnr.
          gt_e1edl24_qty-posnr = gs_e1edl43-posnr.
          APPEND gt_e1edl24_qty.
          CLEAR gt_e1edl24_qty.
          CLEAR lv_bat_flag.
        ENDIF.
* For 9th point
      WHEN lc_e1edk33.
        gt_del-cnt33 = gt_del-cnt33 + 1.

      WHEN lc_e1edt01.
        gs_e1edt01     = gs_idoc_data-sdata.

        gt_del-tabix01 = sy-tabix.
        gt_del-vbeln   = gs_e1edt01-vbeln.

        APPEND gt_del.
        CLEAR:  gt_del-tabix01, gt_del-vbeln.
    ENDCASE.
  ENDLOOP.
*

*   6.  Tolerance Calculation                                          *
*    The tolerance is based on the order type.  The order type could   *
*    either be a STO (doc. category V) or Sales Order (document        *
*    category C).                                                      *
*    The segment/field E1EDT20.E1EDL20.E1EDL24.E1EDL43 will give us the*
*    QUALF value. The QUALF is nothing but the doc. category.          *
*                                                                      *
*    If QUALF = C (i.e. Sales order), then pick the tolerance value    *
*    from the LIPS (delivery) table. Select from LIPS table based on   *
*    the delivery no. and line item no.                                *
*                                                                      *
*    If QUALF = V (i.e. STO), then pick the tolerance value from the   *
*    z-table, ZSP_VALUE.                                               *
*----------------------------------------------------------------------*
  IF NOT gt_tol[] IS INITIAL.
    gt_tol_c[] = gt_tol[].
    PERFORM sub_lips_tol.
  ENDIF.

* For Stage -> Deliveries.
**  Logic used:  E1EDK33 has component called E1EDT01.  E1EDT01 is
*shipment item assignment which contains delivery number associated with
*each shipment stage E1EDK33.  SAP keeps all shipments assigned at each
*stage.  Load all entries in an internal table.  All valid deliveries,
*keep it in another table.

  IF NOT gt_del[] IS INITIAL.
    SORT gt_del BY cnt33 DESCENDING.

    LOOP AT gt_del.
      IF gt_del_val[] IS INITIAL.
        gt_del_val-cnt33   = gt_del-cnt33.
        gt_del_val-tabix01 = gt_del-tabix01.
        gt_del_val-vbeln   = gt_del-vbeln.
        APPEND gt_del_val.
        CLEAR gt_del_val.
      ELSE.
        SORT gt_del_val BY cnt33 DESCENDING.
        READ TABLE gt_del_val
            WITH KEY vbeln = gt_del-vbeln.
        IF sy-subrc <> 0.          " Valid Deliveries corr to each stage
          gt_del_val-cnt33   = gt_del-cnt33.
          gt_del_val-tabix01 = gt_del-tabix01.
          gt_del_val-vbeln   = gt_del-vbeln.
          APPEND gt_del_val.
          CLEAR gt_del_val.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.

  CLEAR gv_e1edk33_cnt.                                     "change # 4

  LOOP AT idoc_data INTO gs_idoc_data.
    gv_sytabix = sy-tabix.
    CASE gs_idoc_data-segnam.
      WHEN lc_e1edt20.    PERFORM sub_e1edt20.
      WHEN lc_e1edl37.    PERFORM sub_e1edl37.
      WHEN lc_e1edl20.    PERFORM sub_e1edl20.
      WHEN lc_e1edl24.    PERFORM sub_e1edl24.
      WHEN lc_e1edl26.    PERFORM sub_e1edl26.
** 9.  Truncate Deliveries that does not correspond to stages.
**  Logic used:  E1EDK33 has component called E1EDT01.  E1EDT01 is
*shipment item assignment which contains delivery number associated with
*each shipment stage E1EDK33.  SAP keeps all shipments assigned at each
*stage.
      WHEN lc_e1edk33.
        gv_e1edk33_cnt = gv_e1edk33_cnt + 1.
        gv_subrc = 0.
      WHEN lc_e1edt01.    PERFORM sub_e1edt01.
    ENDCASE.
    IF gv_subrc = 3.        " 3 for modify
      MODIFY idoc_data
        FROM gs_idoc_data
        INDEX gv_sytabix
        TRANSPORTING sdata.
    ELSEIF gv_subrc = 2.    " 2 for delete
      DELETE idoc_data
         INDEX gv_sytabix.
    ELSEIF gv_subrc = 6.    "LGMNG contains decimal point
* Raise AHD ticket
      lv_tknum = gv_tknum.
      CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
        EXPORTING
          inventory_code         = 'I2249'(e01)
          text_1                 =
          'IDoc creation failed for shipment'(e02)
          text_2                 = lv_tknum
          text_3                 =
          'due to any/all of delivery line item field'(e03)
          text_4                 =
          'Base UOM E1EDL24-LGMNG contains decimal value;'(e04)
          text_5                 = 'Check delivery quantity'(e05)
        EXCEPTIONS
          invalid_inv_code       = 1
          ahdgrp_not_found       = 2
          invalid_idoc_number    = 3
          webmd_connection_error = 4
          OTHERS                 = 5.

      IF sy-subrc <> 0.
*/  catch the sy-subrc error. The case statement should
*/  help prevent the short dumps .
*        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ls_log-object    = lc_log_object.
        ls_log-subobject = lc_log_subobj.
        TRY.
            CREATE OBJECT lo_log
            EXPORTING
              is_log = ls_log.

            CASE sy-subrc .
              WHEN '1' .
               MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '86' INTO lv_message
               .
                lo_log->handle_message( ).
              WHEN '2' .
               MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '87' INTO lv_message
               .
                lo_log->handle_message( ).
              WHEN '3'.
               MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '88' INTO lv_message
               .
                lo_log->handle_message( ).
              WHEN '4'.
               MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '89' INTO lv_message
               .
                lo_log->handle_message( ).
              WHEN OTHERS.
               MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '90' INTO lv_message
               .
                lo_log->handle_message( ).
            ENDCASE .
            lo_log->log_save( ).
          CATCH zcx_ca_applog.
        ENDTRY.

      ENDIF. " sy-subrc <> 0.

      MESSAGE ID      'ZSD_DL'
              TYPE    'E'
              NUMBER  '000'
              WITH    'Base UOM contains decimal value;'(e06)
                      ' One of the E1EDL24-LGMNG contains'(e07)
                      ' decimal values.'(e08)
                      ' Check delivery quantity'(e05)
      RAISING error_message_received.
    ENDIF.

  ENDLOOP.
  IF gv_status = '1'.
*    4.  To count for number of delivery items E1EDT20.GESZTD-exclude *
*        batch split items.
    gs_e1edt20-gesztd   = gv_deliv_item_ctr.
    gs_idoc_data-sdata  = gs_e1edt20.

    MODIFY idoc_data
          FROM gs_idoc_data
          INDEX gv_e1edt20_index
          TRANSPORTING sdata.

*    7.  Convert Delivery Quantity into Base UOM.                      *
*  For Roll Stock material (Batch Managed One),  Convert into Base UOM *
*  For Containers/Finished Goods/Non-batch managed ones, Keep it 'EA'  *
*
*  For all batch managed materials (roll stock materials), convert     *
*  delivery quantity LFIMG from Sales UOM to Base UOM.                 *

    CLEAR: gs_idoc_data, gt_e1edl24_qty.

    IF NOT gt_e1edl24_qty[] IS INITIAL.
      LOOP AT gt_e1edl24_qty.
        l_tabix = sy-tabix.
        PERFORM sub_qty_conv.
        MODIFY gt_e1edl24_qty
            INDEX l_tabix
            TRANSPORTING lfimg vrkme.
        CLEAR: gs_idoc_data, gs_e1edl24.
        READ TABLE idoc_data
              INTO gs_idoc_data
              INDEX gt_e1edl24_qty-index.

        IF sy-subrc = 0.
          gs_e1edl24          = gs_idoc_data-sdata.
          gs_e1edl24-lfimg    = gt_e1edl24_qty-lfimg.

          gs_e1edl24-vrkme    = gt_e1edl24_qty-vrkme.

          gs_idoc_data-sdata  = gs_e1edl24.

          MODIFY idoc_data
                FROM gs_idoc_data
                INDEX gt_e1edl24_qty-index
                TRANSPORTING sdata.
        ENDIF.
      ENDLOOP.
    ENDIF.
*
*  04/04/06:  Convert ISO code of fields E1EDT20.E1EDL20.E1EDL24, -    *
*             VRKME, MEINS & GEWEI into SAP code                       *
* <Start>

    LOOP AT idoc_data INTO gs_idoc_data
       WHERE  segnam = lc_e1edl24.
      gv_sytabix = sy-tabix.

      gs_e1edl24          = gs_idoc_data-sdata.

      IF NOT gs_e1edl24-vrkme IS INITIAL.
        PERFORM unit_of_measure_iso_to_sap
                              USING    gs_e1edl24-vrkme
                              CHANGING gs_e1edl24-vrkme.    "04/04/06

      ENDIF.

      IF NOT gs_e1edl24-meins IS INITIAL.
        PERFORM unit_of_measure_iso_to_sap
                              USING    gs_e1edl24-meins
                              CHANGING gs_e1edl24-meins.    "04/04/06
      ENDIF.

      IF NOT gs_e1edl24-gewei IS INITIAL.
        PERFORM unit_of_measure_iso_to_sap
                              USING    gs_e1edl24-gewei
                              CHANGING gs_e1edl24-gewei.    "04/04/06

      ENDIF.

* CR4645 - convert TONS to lbs.
      IF gs_e1edl24-vrkme = 'TON'.
        l_weight = gs_e1edl24-lfimg.
        PERFORM convert_ton_to_lb CHANGING gs_e1edl24-vrkme l_weight.
        gs_e1edl24-lfimg = l_weight.
        CONDENSE gs_e1edl24-lfimg.
        gs_idoc_data-sdata = gs_e1edl24.
      ENDIF.

      IF gs_e1edl24-meins = 'TON'.
        l_weight = gs_e1edl24-lgmng.
        PERFORM convert_ton_to_lb CHANGING gs_e1edl24-meins l_weight.
        gs_e1edl24-lgmng = l_weight.
        CONDENSE gs_e1edl24-lgmng.
        gs_idoc_data-sdata = gs_e1edl24.
      ENDIF.

      IF gs_e1edl24-gewei = 'TON'.
        l_weight = gs_e1edl24-ntgew.
        PERFORM convert_ton_to_lb CHANGING gs_e1edl24-gewei l_weight.
        gs_e1edl24-ntgew = l_weight.

        gs_e1edl24-gewei = 'TON'.
        l_weight = gs_e1edl24-brgew.
        PERFORM convert_ton_to_lb CHANGING gs_e1edl24-gewei l_weight.
        gs_e1edl24-brgew = l_weight.
        CONDENSE gs_e1edl24-ntgew.
        CONDENSE gs_e1edl24-brgew.
        gs_idoc_data-sdata = gs_e1edl24.
      ENDIF.

      gs_idoc_data-sdata  = gs_e1edl24.

      MODIFY idoc_data
            FROM gs_idoc_data
            INDEX gv_sytabix
            TRANSPORTING sdata.

    ENDLOOP.
* 04/04/06: <End>

*    8.  To check whether all required fields are entered.             *

    PERFORM check_reqfields
        TABLES  idoc_data
        USING   control_record_out.
  ELSE.
    CLEAR control_record_out.
    FREE idoc_data.
  ENDIF.
ENDFORM.                    "process_final_run
*&--------------------------------------------------------------------*
*&      Form  check_reqfields
*&--------------------------------------------------------------------*
* Calls the function to check to make sure that all required fields
* are in the IDoc.
FORM check_reqfields
          TABLES  idoc_data          STRUCTURE edidd
          USING   control_record_out STRUCTURE edidc.

  CONSTANTS:
    c_inventory_code    TYPE zzinv  VALUE 'I2249',
    c_logflag(1)        TYPE c      VALUE ' ',
    c_logobject(20)     TYPE c      VALUE 'ZDL_INTERFACE',
    c_logsubobj(20)     TYPE c      VALUE 'ZDL_ZSHP_REQFIELDS'.

  DATA: l_text  TYPE char50,
        l_key   LIKE  zreq_fields-zaux_key1.

  CONCATENATE 'Shipment Number ='
              gv_tknum  INTO l_text SEPARATED BY space.

  l_key = control_record_out-rcvprn.

  CALL FUNCTION 'Z_CHECK_REQ_FIELDS'
    EXPORTING
     idoc_control                   = control_record_out
     aux_key1                       = l_key
     inventory_code                 = c_inventory_code
     ahd_tkt_skip_flag              = c_logflag
     ahd_text4                      = l_text
*   AHD_TEXT5                       =
*   AHD_TEXT6                       =
     app_log_skip_flag              = c_logflag
     app_log_object                 = c_logobject
     app_log_subobject              = c_logsubobj
    TABLES
      idoc_data                     = idoc_data[]
   EXCEPTIONS
      control_record_missing        = 1
      data_record_missing           = 2
      no_required_values            = 3
      unidentifiable_idoc_structure = 4
      empty_fields_identified       = 5
      OTHERS                        = 6.

  IF sy-subrc = 3.
    CLEAR sy-subrc.
  ENDIF.
  CHECK NOT sy-subrc IS INITIAL.

  CLEAR control_record_out.
  FREE idoc_data.
ENDFORM.                    "check_reqfields

*&--------------------------------------------------------------------*
*&      Form  sub_e1edl37
*&--------------------------------------------------------------------*
*  Changed for CR4645 to also pull GEWEI_MAX to see if UOM is tons -
* if so convert MAGEW to LBS.
*---------------------------------------------------------------------*
FORM sub_e1edl37.

  DATA: lv_magew LIKE vekp-magew,
        lv_gewei_max LIKE vekp-gewei_max.

  CHECK gv_status = '1'.      " Planned Status = 1
  gs_e1edl37 = gs_idoc_data-sdata.
*  2. To fetch Allowed Weight E1EDT20.E1EDL37.MAGEW from table VEKP.
  SELECT SINGLE magew gewei_max
         INTO (lv_magew, lv_gewei_max)
         FROM vekp
         WHERE vpobjkey = gv_tknum.
  IF sy-subrc = 0.
    gv_subrc = 3.
    IF lv_gewei_max = 'TON' OR
       lv_gewei_max = 'STN'.
      lv_gewei_max = 'TON'.
      PERFORM convert_ton_to_lb CHANGING lv_gewei_max lv_magew.
    ENDIF.
    gs_e1edl37-magew = lv_magew.
    gs_idoc_data-sdata = gs_e1edl37.
  ELSE.
    gv_subrc = 1.
  ENDIF.
ENDFORM.      "sub_e1edl37.
*&--------------------------------------------------------------------*
*&      Form  sub_e1edt20
*&--------------------------------------------------------------------*
FORM sub_e1edt20.

* VARIABLES
  DATA:
    lv_sttrg  LIKE vttk-sttrg.   "Overall transportation status

  gs_e1edt20       = gs_idoc_data-sdata.
  gv_tknum         = gs_e1edt20-tknum.
  gv_e1edt20_index = sy-tabix.
*   1.  To check for 'planned' status.  If it is set, send IDoc;
*       else, don't send.
  SELECT SINGLE sttrg
      INTO lv_sttrg
      FROM vttk
      WHERE tknum = gv_tknum.    "Status field STTRG
  IF lv_sttrg <> 1.
    gv_subrc = 1.
    gv_status = '0'.
*    RAISE planned_status_not_set.
    MESSAGE ID      'ZSD_DL'
             TYPE    'E'
             NUMBER  '000'
             WITH    'Planned Status not set.'
                     ' '
                     ' '
                     ' '
     RAISING error_message_received.

  ELSE.
    gv_subrc  = 0.
    gv_status = '1'.
  ENDIF.

ENDFORM.    "sub_e1edt20

*&--------------------------------------------------------------------*
*&      Form  sub_e1edl20
*&--------------------------------------------------------------------*

FORM sub_e1edl20.

  DATA: lv_lifex LIKE likp-zzbooknum.

  CHECK gv_status = '1'.
*    5.  To fetch booking number E1EDT20.E1EDL20.LIFEX from LIKP.    *
  gs_e1edl20 = gs_idoc_data-sdata.
  gv_countr  = gv_countr + 100.
  gv_sytabix = sy-tabix.
  SELECT SINGLE zzbooknum
        INTO lv_lifex
        FROM likp
        WHERE vbeln = gs_e1edl20-vbeln.
  IF sy-subrc = 0.
    gv_subrc = 3.
    gs_e1edl20-lifex = lv_lifex.
    gs_idoc_data-sdata = gs_e1edl20.
  ELSE.
    gv_subrc = 1.
  ENDIF.
ENDFORM.      "sub_e1edl20

*&--------------------------------------------------------------------*
*&      Form  sub_e1edl24
*&--------------------------------------------------------------------*
FORM sub_e1edl24.

  DATA:
    lv_lgmng_seg   LIKE lips-lgmng,
    lv_lgmng       TYPE i.

  CHECK gv_status = '1'.
*    3.  To filter out batch split line item.                          *
  gs_e1edl24 = gs_idoc_data-sdata.
  gv_countr  = gv_countr + 10.

* If delivery item does start with '9*', then it is batch split items
  IF gs_e1edl24-posnr CP '9*'.
    gv_subrc = 2.
    EXIT.
* 01/23/2006 - For TPR # 11627 - End
  ELSE.
    gv_subrc = 0.
    gv_deliv_item_ctr = gv_deliv_item_ctr + 1.
    IF gs_e1edl24-charg <> ' '.
      gt_e1edl24_qty-index = sy-tabix.
    ENDIF.
  ENDIF.

  CHECK gv_subrc = 0.
  IF gs_e1edl24-lgmng CA '.'.
    lv_lgmng_seg = gs_e1edl24-lgmng.
* 01/23/2006 - For TPR # 11627 - Start
    CALL FUNCTION 'ROUND'
      EXPORTING
*             DECIMALS            = 0
        input              = lv_lgmng_seg
     IMPORTING
       output              = lv_lgmng.
    IF sy-subrc = 0.
      IF lv_lgmng = lv_lgmng_seg.
        gv_subrc = 0.
      ELSE.
        gv_subrc = 6.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.     "sub_e1edl24
*&--------------------------------------------------------------------*
*&      Form  sub_e1edl26
*&--------------------------------------------------------------------*
FORM sub_e1edl26.

  CHECK gv_status = '1'.
*    6.  To Tolerance Calculation.                          *
  gs_e1edl26 = gs_idoc_data-sdata.
  gv_sytabix = sy-tabix.
  gv_countr  = gv_countr + 1.
  SORT gt_tol BY countr.
  READ TABLE gt_tol WITH KEY countr = gv_countr BINARY SEARCH.
  IF sy-subrc = 0.
    READ TABLE gt_tol_c WITH KEY vbeln = gt_tol-vbeln
                                 posnr = gt_tol-posnr.
    gs_e1edl26-uebto = gt_tol_c-uebto.
    gs_e1edl26-untto = gt_tol_c-untto.
  ELSE.
    PERFORM sub_z_tol.
  ENDIF.
  gs_idoc_data-sdata = gs_e1edl26.
  gv_subrc  = 3.
  gv_status = '1'.

ENDFORM.    " sub_e1edl26

*&--------------------------------------------------------------------*
*&      Form  sub_e1edt01
*&--------------------------------------------------------------------*
FORM sub_e1edt01.
  CHECK gv_status = '1'.
  gs_e1edt01     = gs_idoc_data-sdata.
* If delivery is not there in this internal table, those are not
*relevant deliveries - delete it.
  IF NOT gt_del_val[] IS INITIAL.
    SORT gt_del_val BY cnt33 vbeln.
    READ TABLE gt_del_val
          WITH KEY  cnt33    = gv_e1edk33_cnt
                    vbeln    = gs_e1edt01-vbeln.
    IF sy-subrc <> 0.
      gv_subrc = 2.
*          DELETE idoc_data INDEX l_tabix.
    ELSE.
      gv_subrc = 0.
    ENDIF.
  ENDIF.
ENDFORM.  " sub_e1edt01

*&--------------------------------------------------------------------*
*&      Form  sub_qty_conv
*&--------------------------------------------------------------------*

FORM sub_qty_conv.

  CLEAR : gv_cuobj,
          gv_vrkme,
          gt_conf_out[].

  SELECT SINGLE cuobj vrkme
                INTO (vbap-cuobj, vbap-vrkme)
                FROM vbap
                WHERE  vbeln = gt_e1edl24_qty-vbeln
                  AND  posnr = gt_e1edl24_qty-posnr.
  IF sy-subrc = 0 .
    gv_cuobj = vbap-cuobj.
    gv_vrkme = vbap-vrkme.
    gt_e1edl24_qty-vrkme    =  gv_vrkme.
    PERFORM shipment_no_of_units.
  ELSE .
* // this is a  MTS scenario .
    gv_vrkme = gt_e1edl24_qty-vrkme.
    PERFORM get_mts_relevant_fields.
  ENDIF.

ENDFORM.         " sub_qty_conv
**
**----------------------------------------------------------------------
*-
** perform shipment_no_of_units
**----------------------------------------------------------------------
*-
**// LGMNG is in base unit of measure. LFIMG is supposed to
**/  be in sales unit of measure. But for the export shipments that are
**/  based out of STO's, the deliveries are also created in the base
*unit
**/  of measure where as we need the sales unit of measure from the
**/  sales order associated with the STO. The ordered number of units
*com
**/  from the sales order and not the STO's.
*
FORM shipment_no_of_units.

  DATA: x_int   TYPE p DECIMALS 2,
        x_int4 TYPE int4,
        p1(15) TYPE c,
        p2(15) TYPE c.

  CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
    EXPORTING
      instance           = gv_cuobj
    TABLES
      configuration      = gt_conf_out
    EXCEPTIONS
      instance_not_found = 1
      OTHERS             = 2.
  IF sy-subrc = 0.
    READ TABLE gt_conf_out
          WITH KEY atnam = gc_zsdc_order_units .
    IF sy-subrc = 0 .
*calculate the corresponding delivered unit of rolls. This would change
*in the later versions as the ordered and delivered unit could be
*anything other than rolls.
      SPLIT gt_conf_out-atwrt AT ' ' INTO p1 p2.
      IF sy-subrc = 0.
        REPLACE ALL OCCURRENCES OF ',' IN p1 WITH space.
        x_int = p1.
        SELECT SINGLE klmeng INTO vbap-klmeng FROM vbap
                 WHERE  vbeln = gt_e1edl24_qty-vbeln
                 AND    posnr = gt_e1edl24_qty-posnr.

        IF sy-subrc = 0 .
          IF vbap-klmeng <> 0 .
            x_int4   = ( gs_e1edl24-lgmng / vbap-klmeng ) *
                               x_int.
            gt_e1edl24_qty-lfimg  = x_int4.
          ENDIF.
        ENDIF.
      ENDIF.
    ELSE.
      gv_vrkme = gt_e1edl24_qty-vrkme .
      PERFORM get_mts_relevant_fields.
    ENDIF.
  ENDIF.

ENDFORM .                    "shipment_no_of_units
*
**&--------------------------------------------------------------------*
**&      Form  get_mts_relevant_fields
**&--------------------------------------------------------------------*
**// if it was a MTS then cuobj would be blank, therefore characteristic
**/  cannot be read .
**---------------------------------------------------------------------*
FORM  get_mts_relevant_fields.
  IF gv_vrkme <> 'RL' .
    PERFORM unit_conversion .
  ENDIF.

ENDFORM.                    "get_mts_relevant_fields

*&---------------------------------------------------------------------*
*&      Form  convert_ton_to_lb
*&---------------------------------------------------------------------*
* uses UNIT_CONVERSION_SIMPLE to convert TONS to LB
*----------------------------------------------------------------------*
FORM convert_ton_to_lb CHANGING p_uom    LIKE vekp-gewei_max
                                p_weight LIKE vekp-magew.
  DATA l_output LIKE p_weight.

  CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
    EXPORTING
      input                = p_weight
      unit_in              = p_uom
      unit_out             = 'LB'
    IMPORTING
      output               = l_output
    EXCEPTIONS
      conversion_not_found = 1
      division_by_zero     = 2
      input_invalid        = 3
      output_invalid       = 4
      overflow             = 5
      type_invalid         = 6
      units_missing        = 7
      unit_in_not_found    = 8
      unit_out_not_found   = 9
      OTHERS               = 10.
  IF sy-subrc IS INITIAL.
    IF NOT l_output IS INITIAL.
      p_weight = l_output.
      p_uom    = 'LB'.
    ENDIF.
  ENDIF.
ENDFORM.                    "convert_ton_to_lb
**&--------------------------------------------------------------------*
**&      Form  unit_conversion
**&--------------------------------------------------------------------*
**       This UoM conversion needs to be done for both the MTS and the
**       VMI orders . If the ordered  qty is not in Rolls then convert
*it
**       into Rolls using the FM 'MATERIAL_UNIT_CONVERSION'
**---------------------------------------------------------------------*
FORM unit_conversion.
  DATA:  l_uom          TYPE meins,
         l_qty          TYPE meng15,
         l_weight       TYPE meng15.

  l_weight = gt_e1edl24_qty-lfimg.

  CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
    EXPORTING
      input                = l_weight
      matnr                = gt_e1edl24_qty-matnr
      meinh                = gt_e1edl24_qty-vrkme
      meins                = 'RL'
    IMPORTING
      meins                = l_uom
      output               = l_qty
    EXCEPTIONS
      conversion_not_found = 1
      input_invalid        = 2
      material_not_found   = 3
      meinh_not_found      = 4
      meins_missing        = 5
      no_meinh             = 6
      output_invalid       = 7
      overflow             = 8
      OTHERS               = 9.
  IF sy-subrc <> 0 .
    EXIT.
  ENDIF.
  gt_e1edl24_qty-lfimg  = l_qty.
  gt_e1edl24_qty-vrkme  = l_uom.

ENDFORM .                    "unit_conversion
**&--------------------------------------------------------------------*
**&      Form  SUB_LIPS_TOL
**&--------------------------------------------------------------------*
*  When order type is Sales Order, i.e, e1edl43-qualf = 'C', fetch     *
*  tolerance from LIPS table.                                          *

FORM sub_lips_tol.
  IF NOT gt_tol_c[] IS INITIAL.
    SELECT vbeln posnr uebto untto
      INTO CORRESPONDING FIELDS OF TABLE gt_tol_c
      FROM lips
      FOR ALL ENTRIES IN gt_tol_c
      WHERE vbeln = gt_tol_c-vbeln
        AND posnr = gt_tol_c-posnr.
*  IF sy-subrc = 0.
*    MODIFY gt_e1edl26 TRANSPORTING sdata
*      WHERE psgnum = gt_e1edl24-segnum.
*  ENDIF.
  ENDIF.
ENDFORM.                    "SUB_LIPS_TOL

**&--------------------------------------------------------------------*
**&      Form  SUB_z_TOL
**&--------------------------------------------------------------------*
*  When order type is STO, i.e, e1edl43-qualf = 'V', fetch             *
*  tolerance from ZSP_VALUE table                                      *

FORM sub_z_tol.
  IF gt_zsp_value[] IS INITIAL.

* Get details from ZSP_Value table for
* PGRMID = 'ZSD_DL_I02249_SHPMNT_OUTBOUND' for V2 Apriso system
* The table has to be populated with these details.
    SELECT *
      INTO TABLE gt_zsp_value
      FROM zsp_value
      WHERE pgrmid = gc_pgrmid.
  ENDIF.
  IF NOT gt_zsp_value[] IS INITIAL.
    READ TABLE gt_zsp_value
        WITH KEY fieldname = gc_over_tolerance.    "Over Tolerance
    IF sy-subrc = 0.
      gs_e1edl26-uebto = gt_zsp_value-fieldvalue.
    ENDIF.
    READ TABLE gt_zsp_value
        WITH KEY fieldname = gc_under_tolerance.   "Under Tolerance
    IF sy-subrc = 0.
      gs_e1edl26-untto = gt_zsp_value-fieldvalue.
    ENDIF.

  ENDIF.

ENDFORM.                    "SUB_z_TOL



* 04/4/06:  Convert ISO code into SAP code
*&---------------------------------------------------------------------*
*&      Form  UNIT_OF_MEASURE_SAP_TO_ISO
*&---------------------------------------------------------------------*
*  This subroutine converts given ISO code into SAP code               *
*----------------------------------------------------------------------*
*  ---> iso_code      ISO code to be converted
*  <--  sap_code      converted SAP code
*----------------------------------------------------------------------*
FORM unit_of_measure_iso_to_sap USING  value(iso_code) TYPE any
                                CHANGING    sap_code   TYPE any.

  DATA: h_sap_code LIKE t006-msehi.

  CALL FUNCTION 'UNIT_OF_MEASURE_ISO_TO_SAP'
    EXPORTING
      iso_code  = sap_code
    IMPORTING
      sap_code  = h_sap_code
    EXCEPTIONS
      not_found = 1
      OTHERS    = 2.

  IF ( sy-subrc IS INITIAL ).
    sap_code = h_sap_code.
  ELSE.
    CLEAR sap_code.
  ENDIF.

ENDFORM.                               " UNIT_OF_MEASURE_SAP_TO_ISO


*&---------------------------------------------------------------------*
*&      Form  get_street_num
*&---------------------------------------------------------------------*
* This subroutine retrieves the Ship-To address for segment E1ADRM1
*----------------------------------------------------------------------*

FORM get_street_num CHANGING lv_street1.

  DATA: lv_adrnr      LIKE vbpa-adrnr,
        lv_house_rang LIKE adrc-house_num1,
        lv_street     LIKE adrc-street,
        lv_vbeln      LIKE lips-vbeln,
        lv_index      LIKE sy-tabix,
        lc_e1edl20    TYPE edilsegtyp VALUE 'E1EDL20'.  "Delivery Header

  CONSTANTS: lc_shipto   TYPE vbpa-parvw VALUE 'WE',
             lc_e1adrm1  TYPE edilsegtyp VALUE 'E1ADRM1'.


  CLEAR: lv_adrnr,
         lv_street1.


  DESCRIBE TABLE idoc_data LINES lv_index.

* Get the data from segment E1ADRM1 into structure
  gs_e1adrm1 = idoc_data-sdata.

* Get the delivery partner info
  SELECT SINGLE adrnr FROM vbpa INTO lv_adrnr
                   WHERE vbeln = gv_vbeln
                   AND   parvw = gs_e1adrm1-partner_q.

  CHECK sy-subrc = 0.

* some partners are people and don't have an adrnr
  CHECK NOT lv_adrnr IS INITIAL.

  CLEAR: lv_house_rang,
         lv_street.

* Get all of the street address
  SELECT SINGLE house_num1 street FROM adrc
    INTO (lv_house_rang,lv_street)
       WHERE addrnumber = lv_adrnr.

* If address is found and house number has data - change the idoc
  IF sy-subrc = 0.
    IF NOT lv_house_rang IS INITIAL.
      CONCATENATE lv_house_rang lv_street
        INTO lv_street1 SEPARATED BY space.

      gs_e1adrm1-street1 = lv_street1.

      idoc_data-sdata    = gs_e1adrm1 .

      MODIFY idoc_data INDEX lv_index TRANSPORTING sdata.

    ENDIF.
  ENDIF.

ENDFORM.                    " get_street_num

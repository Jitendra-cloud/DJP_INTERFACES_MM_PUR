*&---------------------------------------------------------------------*
*&  Include           ZDL_E04625_I01                                   *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  CANCEL  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE cancel INPUT.

  CASE gv_ok_9100.
    WHEN 'CANCEL' OR 'F12'.
      LEAVE PROGRAM.
  ENDCASE.

ENDMODULE.                 " CANCEL  INPUT

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9100 INPUT.

  DATA : lt_idoc_status TYPE STANDARD TABLE OF bdidocstat,
         ls_idoc_status TYPE bdidocstat.

* Reset error flag
  gv_error = gc_false .

* Validate Idoc Number
  PERFORM validate_idoc_number.

* Do not continue if there#s an invalid Idoc Number
  CHECK gv_error = gc_false.

  CASE gv_ok_9100.
    WHEN 'CHANGEPO'.
* Call screen to change the PO number
      CALL SCREEN '9200' STARTING AT 24 24 ENDING AT 100 27.
    WHEN 'ARCHIVE'.
* Set the status of the idoc to '68' to Archeving the data
      CLEAR ls_idoc_status.
      ls_idoc_status-status = '68'.
      APPEND ls_idoc_status TO lt_idoc_status.
      CALL FUNCTION 'IDOC_STATUS_WRITE_TO_DATABASE'
        EXPORTING
          idoc_number               = gv_docnum
        TABLES
          idoc_status               = lt_idoc_status
        EXCEPTIONS
          idoc_foreign_lock         = 1
          idoc_not_found            = 2
          idoc_status_records_empty = 3
          idoc_status_invalid       = 4
          db_error                  = 5
          OTHERS                    = 6.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.
      LEAVE PROGRAM.
    WHEN 'REPROCESS'.
* The user may have changed some SAP data (e.g. added a Storage
* location on the PO Item) and they just want to reprocess the idoc
      SUBMIT rbdmani2 WITH so_docnu = gv_docnum AND RETURN.
      LEAVE PROGRAM.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_9100  INPUT
*&---------------------------------------------------------------------*
*&      Module  CANCEL_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE cancel_9000 INPUT.
  CASE gv_ok_9000.
    WHEN 'CANCEL' OR 'F12'.
      LEAVE PROGRAM.
  ENDCASE.
ENDMODULE.                 " CANCEL_9000  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9000 INPUT.
* Reset error flag
  gv_error = gc_false.

  IF gv_ok_9000 = 'ONLI' OR "Execute
     gv_ok_9000 = 'ENTER'.  "Enter
    CALL SCREEN '9100'.
  ENDIF.

ENDMODULE.                 " USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*&      Module  CANCEL_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE cancel_9200 INPUT.

  CASE gv_ok_9200.
    WHEN 'CANCEL' OR 'F12'.
* F12 Cancel key selected # send user back to Screen 9100
      SET SCREEN 0.
  ENDCASE.

ENDMODULE.                 " CANCEL_9200  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9200 INPUT.
* Reset error flag
  gv_error = gc_false.

* Validate Idoc Number
  IF gv_ok_9200 = 'ONLI' OR "Execute
     gv_ok_9200 = 'ENTER'.  "Enter
    PERFORM validate_po_number.
  ENDIF.

* Do not continue if there#s an invalid PO Number
  CHECK gv_error = gc_false.

* Handle user actions
  IF gv_ok_9200 = 'ONLI'.  "Execute the PO Change process
    PERFORM change_po_number.
    LEAVE PROGRAM.  "go back to workflow inbox
  ENDIF.

ENDMODULE.                 " USER_COMMAND_9200  INPUT

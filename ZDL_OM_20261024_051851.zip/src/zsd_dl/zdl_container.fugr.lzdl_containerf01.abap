*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_CONTAINERF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  validate_booking
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IV_BOOKDOC  text
*      -->P_IV_BOOKNUM  text
*      -->P_IV_WERKS  text
*      <--P_LV_BOOKDOC  text
*      <--P_LV_SUBRC  text
*----------------------------------------------------------------------*
FORM validate_booking  USING    p_bookdoc
                                p_booknum
                                p_werks
                       CHANGING c_bookdoc
                                c_subrc.

  DATA: lv_booknum TYPE zsd_book_booknum.

* Booking document may be blank OR have a value
  c_bookdoc = p_bookdoc.

* If a booking document passed in then use it for validation
  IF c_bookdoc IS NOT INITIAL.
    SELECT SINGLE booknum INTO lv_booknum FROM zsd_book_hdr
      WHERE bookdoc = c_bookdoc.
*   If the Booking Document passed in is invalid
    IF sy-subrc NE 0.
      c_subrc = 1.
*   Booking Document was valid but the Booking Confirmation retrieved
*   does not match what was passed in.
    ELSEIF p_booknum NE lv_booknum.
      c_subrc = 2.
    ENDIF.

* No Booking Document was passed in
  ELSE.

*   Retrieve Booking Document(s) based on Book Conf Num entered as
*   well as the Plant entered on the selection screen
    SELECT bookdoc INTO TABLE gt_book_hdr FROM zsd_book_hdr
      WHERE booknum    = p_booknum
        AND plant_code = p_werks.
    IF sy-subrc NE 0.
*     Booking Confirmation Number not found on table ZSD_BOOK_HDR
      c_subrc = 2.
    ELSEIF sy-dbcnt > 1.
*     If multiple Booking Documents exist for the same Booking Conf Num
*     in the same Plant then use the Booking Document with the greatest
*     Book Doc number
      SORT gt_book_hdr BY bookdoc DESCENDING."Latest book doc in 1st row
    ENDIF.
    READ TABLE gt_book_hdr INTO gs_book_hdr INDEX 1."Store data in struc
    IF sy-subrc = 0.
      c_bookdoc = gs_book_hdr-bookdoc.
      c_subrc   = 0.
    ENDIF.

  ENDIF.

ENDFORM.                    " validate_booking

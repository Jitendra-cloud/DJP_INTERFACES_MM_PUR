class ZCL_IM_DL_DELETE_CONTNR_HU definition
  public
  final
  create public .

*"* public components of class ZCL_IM_DL_DELETE_CONTNR_HU
*"* do not include other source files here!!!
public section.
  type-pools VSEP .

  interfaces IF_BADI_HU_SAVE .

  constants GC_CONTAINER type VHART value 'CONT'. "#EC NOTEXT
  constants GC_DELETE type UPDKZ value 'D'. "#EC NOTEXT
  constants GC_UPDATE type UPDKZ value 'U'. "#EC NOTEXT
  constants GC_DELETED type HU_STATUS value '0060'. "#EC NOTEXT
protected section.
*"* protected components of class ZCL_IM_SD_DELETE_CONTNR_HU
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_DL_DELETE_CONTNR_HU
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_DL_DELETE_CONTNR_HU IMPLEMENTATION.


METHOD if_badi_hu_save~save .
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2007 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* BADI Name   : U01267 Delete Container Handling Units from
*               zdlu01267_vekp                                         *
*                                                                      *
* Definition  : BADI_HU_SAVE                                           *
* Impl Name   : ZSD_DELETE_CONTNR_HU                                   *
* Method      : SAVE                             Create Date: 04/02/07 *
*                                                                      *
* Programmer  : Lance Vialpando                  Last Update: 04/02/07 *
*______________________________________________________________________*
* Description : This BADI deletes Container Handling Unit records
*               from custom table ZDL_U01267_VEKP when the
*               corresponding HU is deleted from VEKP.
*
*               The BADI is executed as part of transaction HUMO.
*
*               The import parameters don't contain a container HU
*               when the HU is deleted.  Thus, FM V51P_GET_TABLES
*               is called to retrieve the YVEKP internal table.
*               For deleted HU, the UPDKZ field will contain a "D".
*
*               SAP uses the same internal table to determine what
*               HU to delete.  This BADI is called from the
*               FM HU_PACKING_UPDATE.  After the call to the BADI, the
*               FM calls form determine_changed_header.  In this form,
*               SAP looks for records in the YVEKP table where
*               UPDKZ = 'D'.   The point is that this user exit uses
*               the same logic and internal tables that SAP uses to
*               determine what HUs should be deleted.
*
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ================  ========  ==========  =============================*
* Lance Vialpando   04/02/07  EDEK907877  Initial                      *
* Charles Ramey     08/19/11  E0VK984145  Change to not only use       *
*                                       UPDKZ = D, but also when       *
*                                       UPDKZ = U AND status = 60    *
*                                                                      *
*______________________________________________________________________*
************************************************************************
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            PB = Push Button      *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            TS = Type Struct.     *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************

  DATA: lt_yvekp          TYPE vsep_t_vekp,
        ls_yvekp          LIKE LINE OF lt_yvekp,
        lt_zdlu01267_vekp TYPE TABLE OF zdlu01267_vekp,
        ls_zdlu01267_vekp TYPE zdlu01267_vekp,
        lv_locker         TYPE sy-msgv1.

* Call a FM to return the YVEKP table, which represents the
* HU header as it currently exists in the DB.
  CALL FUNCTION 'V51P_GET_TABLES'
    IMPORTING
      et_yvekp    = lt_yvekp
    EXCEPTIONS
      hus_locked  = 1
      no_hu_found = 2
      fatal_error = 3
      OTHERS      = 4.

* Continue if no errors and YVEKP is populated.
* For purposes of this exit, and the way the above FM
* is called, there will not be an exception raised.
  CHECK sy-subrc = 0 AND lt_yvekp[] IS NOT INITIAL.

* Loop at the header table for container HU where container
* HUs have been deleted.
  LOOP AT lt_yvekp INTO ls_yvekp WHERE vhart    = gc_container.
*                                   AND updkz    = gc_delete.

*** logic changed to allow for either update status with deleted or
***  delete update indicator
    CHECK ( ls_yvekp-updkz = gc_delete ) OR
      ( ls_yvekp-updkz = gc_update AND ls_yvekp-status = gc_deleted ).

* See if HU exists in z table.  It is not an error if an entry
* does not exist.
    CLEAR ls_zdlu01267_vekp.
    SELECT SINGLE * INTO ls_zdlu01267_vekp
           FROM zdlu01267_vekp
           WHERE venum = ls_yvekp-venum.

* If record not found then continue with the next HU
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

* Attempt to lock the HU
    CALL FUNCTION 'ENQUEUE_EVVEKPE'
      EXPORTING
        mode_vekp      = 'E'
        mandt          = sy-mandt
        venum          = ls_zdlu01267_vekp-venum
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      lv_locker = sy-msgv1.
      "Booking confirmation is locked by user &.
      MESSAGE i031 WITH lv_locker.
    ELSE.
* if locked, then store the record for later processing.
      APPEND ls_zdlu01267_vekp TO lt_zdlu01267_vekp.
    ENDIF.
  ENDLOOP.

* If there are records to delete, then call a FM in
* a background task to delete the HU.
  IF lt_zdlu01267_vekp[] IS NOT INITIAL.
    CALL FUNCTION 'Z_DL_CONTAINER_DELETE_DB'
      IN UPDATE TASK
      TABLES
        it_zdlu01267_vekp = lt_zdlu01267_vekp.

  ENDIF.
ENDMETHOD.
ENDCLASS.

FUNCTION zdl_ssa_determination.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IV_VSTEL) TYPE  VSTELA OPTIONAL
*"  TABLES
*"      IT_TKNUM TYPE  ZDL_TKNUM_T OPTIONAL
*"      IT_VBELN TYPE  ZDL_VBELN_T OPTIONAL
*"      ET_SSA_HEADER TYPE  ZDL_SSA_HEADER_T OPTIONAL
*"      ET_SSA_DETAIL TYPE  ZDL_SSA_DETAIL_T OPTIONAL
*"  EXCEPTIONS
*"      INVALID_INPUT
*"      NO_DATA_PASSED
*"      INVALID_SHIPPING_POINT
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**           COPYRIGHT (C) 2008 by INTERNATIONAL PAPER                **
**                     ALL RIGHTS RESERVED                            **
**             REVISIONS COPYRIGHT (C) 2009, 20nn                     **
**                    by INTERNATIONAL PAPER                          **
*______________________________________________________________________*
* Function:    ZDL_SSA_DETERMINATION                 Date: 01/02/2009  *
* Programmer : Bruce Ballehr                                           *
*______________________________________________________________________*
* Description :                                                        *
*   This function module will return SSA (Special Service Agreement)   *
*   information.                                                       *
*                                                                      *
*   It will accept either a table of Shipments or a table of           *
*   Deliveries.                                                        *
*                                                                      *
*   It will return a table of Delivery Header information and a table  *
*   of Delivery Detail information.                                    *
*______________________________________________________________________*
* Change History:                                                      *
*   Programmer       Date     Req. #            Action                 *
* ===============  ========  ========== ===============================*
* Bruce Ballehr    01/02/09  ESBK967345 Initial creation               *
* Bruce Ballehr    06/01/09  E0VK950891 TPR 32237 Retrieve Plant       *
*                            specific SSA Description  (see tag BCB01) *
*                            If new OPTIONAL import parm Shipping Point*
*                            is passed in, then use it to retrieve the *
*                            corresponding Plant. Then, use that Plant *
*                            to retrieve the Plant-specific SSA        *
*                            Description from table ZSSA_ATTRIBUTE.    *
*                            NOTE: if the Shipping Point is NOT passed *
*                                  in then the SSA Description will be *
*                                  retrieved as originally designed    *
*                                  from the Shipping Condition table.  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: N/A                                              *
*______________________________________________________________________*
* Transactions    :   N/A                                              *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :   N/A                                            *
*______________________________________________________________________*
************************************************************************

* Begin BCB01
* Set global variables
  gv_vstel = iv_vstel.
* End BCB01

* Set global tables
  gt_tknum[] = it_tknum[].
  gt_vbeln[] = it_vbeln[].

* Validate input data
  PERFORM validate_input_data.

* Retrieve all SSA Shipping Conditions from ZDL_FIELDS
  PERFORM retrieve_ssa_conditions.

* Retrieve Delivery item and reference Sales Order / Shipping Condition
* information
  PERFORM retrieve_data.

* Determine if Shipping Conditions are SSA
  PERFORM determine_shipping_conditions.

* Build return tables
  PERFORM build_return_data.

* Format the Return parms
  et_ssa_header[] = gt_ssa_header[].
  et_ssa_detail[] = gt_ssa_detail[].

ENDFUNCTION.

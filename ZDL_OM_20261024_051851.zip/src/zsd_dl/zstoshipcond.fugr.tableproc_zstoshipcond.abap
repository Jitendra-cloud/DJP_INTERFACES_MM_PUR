*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSTOSHIPCOND
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSTOSHIPCOND        .

  PERFORM TABLEPROC.

ENDFUNCTION.

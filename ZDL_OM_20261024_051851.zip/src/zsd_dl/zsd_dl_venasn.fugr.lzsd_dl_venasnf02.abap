*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_VENASNF02 .
*----------------------------------------------------------------------*
*----------------------------------------------------------------------*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ================== ========   ======  ===============================*
* Mallik Aiely       3/14/2016  CMS30040 Del.Date update based on Mode *
*                                        of transport:Trades ASN to R/3*
*----------------------------------------------------------------------*
*Dinesh Gandla      03/25/2025  S0VK910287   To Update the COO
*Chanala           2000002371/ SCTASK0079209 from segment E1EDL37 to
*                                            Batch Master
*----------------------------------------------------------------------*
*Venkata Suresh    05/14/2025  S0VK911786 To Update the Pallet weight  *
*Kaki(VKAKI3)   2000002606/SCTASK0088091  from Material Master for IDOC*
*                                          ZDL_PASN
*----------------------------------------------------------------------*
*Venkata Suresh    06/02/2025  S0VK912053 Updating HU material weight  *
*Kaki(VKAKI3)   2000002667/SCTASK0090424  from Material Master for IDOC*
*                                          ZDL_PASN
*----------------------------------------------------------------------*
*Venkata Suresh    01/07/2026  S0VK915188 Updating the COO in batch if *
*Kaki(VKAKI3)   2000003223/SCTASK0113101  vendor maintained in table   *
*                                          ZDL_FIELDS table            *
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  process_idoc_pasn
*&---------------------------------------------------------------------*
*       This form is used to process message type ZDL_PASN for portal
*       ASN. The funtionality is similar to Vendor ASN.
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*-----------------------------------------------------------------------
*-*
FORM process_idoc_pasn.

*Local Constant Declaration------------------------------------------*
  CONSTANTS:
    lc_verp   LIKE mara-mtart VALUE 'VERP',    " Material Type
    lc_pkg    LIKE mara-vhart VALUE 'PKG',     " Pack Mat. Type
    lc_qualf  TYPE char1      VALUE 'V',       " Purchase Order
    lc_form   TYPE char17     VALUE 'PROCESS_IDOC_PASN', " Form
*---Start of insertion for Charm#2000002606, ID#VKAKI3 TR#S0VK911786
    lc_pasn   TYPE edidc-mestyp        VALUE 'ZDL_PASN', " IDOC Type
    lc_pal    TYPE marm-meinh          VALUE 'PAL',      "Alternative UOM
    lc_cat    TYPE zdl_fields-category VALUE 'I2301',
    lc_matkl  TYPE zdl_fields-fieldname VALUE 'MATKL_I',
    lc_landl  TYPE zdl_fields-fieldname VALUE 'LAND1',
    lc_vend   TYPE zdl_fields-fieldname VALUE 'VEND', "Added for S 2000003223/S0VK915188
*---End of insertion for Charm#2000002606, ID#VKAKI3 TR#S0VK911786
* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface
    lc_qualf7 TYPE char3      VALUE '007',    "Qualifier
    lc_ten    TYPE i         VALUE '10' .    "Batch length
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN
*Local variable declaration-------------------------------------------*
  DATA: lv_24count  TYPE i,                "Local counter variable
        lv_37count  TYPE i,                "Local counter variable
        lv_44count  TYPE i,                "Local counter BCB08
        lv_flag     TYPE flag,             "Local flag
        lv_matnr    TYPE matnr,            "For packing material
        lv_exidv    TYPE exidv,            "HU #
        lv_tabix    TYPE sytabix,          "Internal table index BCB04
        lv_lfimg2   TYPE lfimg,            "Added for Charm#2000002606, ID#VKAKI3 TR#S0VK911786
        lv_wt_upd   TYPE c,                "Added for Charm#2000002667, ID#VKAKI3 TR#S0VK912053
* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface

        lv_lgort    TYPE lgort_d,          "PO storage location
        lv_matnr_po TYPE matnr,            "PO material
        lv_werks    TYPE werks_d,          "PO plant
        lv_knttp    TYPE knttp,            "Goods receipt flag
        lv_date     LIKE sy-datum.
  DATA: ws_strlen TYPE i,                  "Length of batch
        ws_uniqid TYPE zdl_fields-fieldname. "Uniq batch ID
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN



*Types declaration----------------------------------------------------*
* Types to store material info
  TYPES: BEGIN OF ty_mara,
           matnr TYPE matnr,              " Material Number
           xchpf TYPE xchpf,              " Batch Indicator
         END OF ty_mara.

* Types to store material #,Plant,Storage location and HU#
  TYPES: BEGIN OF ty_char,
           matnr TYPE matnr,             " Materil Number
           werks TYPE werks_d,           " Plant
           lgort TYPE lgort_d,           " Storage Location
           exidv TYPE exidv,             " External Handling Unit num
         END OF ty_char.

*Internal Table Declaration-------------------------------------------*
* Internal table to store Portal ASN info
  DATA: int_asn TYPE STANDARD TABLE OF zdl_asninfo INITIAL SIZE 0
                                                 WITH HEADER LINE,
* Internal table to store material info
        lt_mara TYPE STANDARD TABLE OF ty_mara INITIAL SIZE 0
                                                 WITH HEADER LINE.

  DATA:lv_weight TYPE lfimg,                                "CMS30040
       lv_dldate TYPE lfdat,                                "CMS30040
       lv_truck  TYPE days,                                 "CMS30040
       lv_rail   TYPE days,                                 "CMS30040
       lv_lfimg  TYPE char15,                               "CMS30040
       lv_lfimg1 TYPE lfimg.                                "CMS30040

* Clear and Refresh all variables and tables
  CLEAR: int_asn,
         lt_mara,
         lv_24count,
         lv_37count,
         lv_flag,
         lv_matnr,
         lv_exidv,
         gt_mbpsv,
         gt_mbh,
         gt_mbpsv_chars,
         gt_bat_char,
         gt_ekko,                                           "BCB09
         gt_hu_xref.                                        "BCB08

  REFRESH: int_asn,
           lt_mara,
           gt_mbpsv,
           gt_mbh,
           gt_mbpsv_chars,
           gt_bat_char.

*--> Begin INSERT EDVK946089
* Determine if this is Trades
  PERFORM check_if_trades.

*  - will set gv_trades_asn1 to gc_true if it is
*
*  - if PO2

  CHECK gv_idoc_error = gc_false.

*--> End INSERT EDVK946089

  CLEAR:lv_lfimg,lv_lfimg1,lv_dldate.                       "CMS30040
  PERFORM get_zdl_fields CHANGING lv_weight                 "CMS30040
                                  lv_truck
                                  lv_rail.

* Begin BCB08
* Read segments to gather various data
  CLEAR gs_idoc_data.
  LOOP AT gt_idoc_data INTO gs_idoc_data
                    WHERE segnam     = gc_e1edt13 OR "Deliv header
                          segnam     = gc_e1edl20 OR "Deliv header
                          segnam     = gc_e1edl24 OR "Deliv item
                          segnam     = gc_e1edl15 OR "Batch Char
                          segnam     = gc_e1edl43 OR "PO info
                          segnam     = gc_e1edl37 OR "HU Header
                          segnam     = gc_e1edl44.   "HU Item

*    gv_tabix = sy-tabix.                                    "CMS31175
    gv_tabix = sy-tabix.                                    "CMS32255

    CASE gs_idoc_data-segnam.
*   Shipment date   " Only for Brazil ASN.
      WHEN gc_e1edt13.
* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface

        IF gv_parnr_bzl = gc_bzl.
          MOVE gs_idoc_data-sdata TO gs_e1edt13.
          IF gs_e1edt13-qualf = lc_qualf7.
            IF NOT  gs_e1edt13-ntanf IS INITIAL.
              WRITE gs_e1edt13-ntanf TO lv_date MM/DD/YYYY.
              CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
                EXPORTING
                  date                      = lv_date
                EXCEPTIONS
                  plausibility_check_failed = 1
                  OTHERS                    = 2.
              IF sy-subrc <> 0.
*  MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*  WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
                PERFORM sub_idoc_status_fill USING
                     c_idoc_status_error                    "status 51
                     gs_idoc_ctrl-docnum      "idoc number
                     c_error                  "status msg type
                     'ZSD_DL'                 " message class
                  '291'                    " Shipment dt in wrong format
                     lv_date                                "msgv1
                    ' '                                     "msgv2
                    ' '                                     "msgv3
                    ' '                                     "msgv4
                     ' '                                      "routid
                     gs_idoc_data-segnum                       "seg num
                    ' '.                                      "seg field
                RETURN.

              ENDIF.
            ELSE.     " Shipment date is initial.
              PERFORM sub_idoc_status_fill USING
                    c_idoc_status_error                     "status 51
                    gs_idoc_ctrl-docnum      "idoc number
                    c_error                  "status msg type
                    'ZSD_DL'                 " message class
                    '289'                    "Shipment date is initial
                    ' '                                     " msgv1
                    ' '                                     "msgv2
                    ' '                                     "msgv3
                    ' '                                     "msgv4
                    ' '                                        " routid
                    gs_idoc_data-segnum                       "seg num
                    ' '.                                      "seg field
              RETURN.

            ENDIF.
          ENDIF.
        ENDIF.
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN
*     Deliver header
      WHEN gc_e1edl20.
        MOVE gs_idoc_data-sdata TO gs_e1edl20.
        EXPORT gs_e1edl20 = gs_e1edl20 TO MEMORY ID 'ZDL_PASN_VSBED'.

*     Delivery item
      WHEN gc_e1edl24.
        MOVE gs_idoc_data-sdata TO gs_e1edl24.
*---Start of changes for Pallet weight update for BR, NY for Charm#2000002606, ID#VKAKI3 TR#S0VK911786
*---Updating the Full and Partial pallet weight material master weight for Brazil and Nymolla ASN
*---Check IDOC message type and this logic is applicable only ZDL_PASN
        IF gs_idoc_ctrl-mestyp = lc_pasn. "'ZDL_PASN'
*---GET the material weight from marm table for pallet
          SELECT SINGLE FROM marm
          FIELDS matnr, meinh, umrez, umren
          WHERE matnr = @gs_e1edl24-matnr
          AND   meinh = @lc_pal "'PAL'                "Alternative UOM
          INTO @DATA(ls_marm).
          IF sy-subrc = 0.
            CLEAR: lv_lfimg1, lv_lfimg2.
            IF  ( ls_marm-umrez <> 0 OR  ls_marm-umren <> 0 ).
*---Get the material weight and upate on IDOC segment and Modify
              lv_lfimg1 = ls_marm-umrez / ls_marm-umren.
              lv_lfimg2 = gs_e1edl24-lfimg. " = lv_lfimg1.
            ENDIF.
            IF lv_lfimg1 <> lv_lfimg2.
*---Get the material group, this logic only for sheets
              SELECT SINGLE FROM mara
                FIELDS matnr, matkl
                WHERE matnr = @gs_e1edl24-matnr
                INTO @DATA(ls_mara).
              IF sy-subrc = 0.
*---Check if material group is maintained in ZDL_FIELDS table if yes, update weight
                SELECT COUNT( * ) FROM zdl_fields
                  WHERE category = @lc_cat                  "'I2301'
                  AND fieldname = @lc_matkl  "'MATKL_I'
                  AND lowval = @ls_mara-matkl.
                IF sy-subrc = 0.
*---Get the vendor number from purchase order
                  SELECT SINGLE FROM ekko
                    FIELDS ebeln, lifnr
                    WHERE ebeln = @gv_ebeln
                    INTO @DATA(ls_ekko).
                  IF sy-subrc = 0.
*---Get the vendor country
                    SELECT SINGLE FROM lfa1
                      FIELDS lifnr, land1
                      WHERE lifnr = @ls_ekko-lifnr
                      INTO @DATA(ls_lfa1).
                    IF sy-subrc = 0.
*---Check vendor country is maintained in ZDL_FIELDS table
                      SELECT COUNT( * ) FROM zdl_fields
                        WHERE category = @lc_cat            "'I2301'
                        AND fieldname = @lc_landl "'LAND1'
                        AND lowval = @gs_e1edl24-werks
                        AND highval = @ls_lfa1-land1.
*---if vendor country is maintained in ZDL_FIELDS table, then update pallet weight
                      IF sy-subrc = 0.
                        lv_wt_upd = abap_true.      "Added for Charm#2000002667, ID#VKAKI3 TR#S0VK912053
*---Update material weight on IDOC segment and Modify
                        gs_e1edl24-lfimg = lv_lfimg1.
                        gs_idoc_data-sdata   = gs_e1edl24.
                        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix TRANSPORTING sdata.
                      ENDIF. "zdl_field Country
                    ENDIF."lfa1 zdl_field Country
                  ENDIF. "ekko
                ENDIF. "zdl_fields Material group
              ENDIF. "mara
            ENDIF. " Materi weight and IDOC weight
          ENDIF. "marm
        ENDIF. "ZDL_PASN
*---End of changes for Pallet weight update for BR, NY for Charm#2000002606, ID#VKAKI3 TR#S0VK911786

        lv_24count = lv_24count + 1.
** Begin insert  TPR # 33946   kthakur
** Input IDOC may or may not have leading zeros.
*     if not gs_e1edl24-posnr is INITIAL.
*        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*          EXPORTING
*            INPUT         = gs_e1edl24-posnr
*         IMPORTING
*           OUTPUT        = gs_e1edl24-posnr
*                  .
*     endif .
** End insert TPR # 33946   kthakur

*->Begin of CMS30040
        IF gs_e1edl24-lfimg IS NOT INITIAL.
          lv_lfimg = lv_lfimg + gs_e1edl24-lfimg.
        ENDIF.
*-<End of CMS30040

*  if more than one line item then append to the internal table.
        IF lv_24count > 1.
          gt_bat_char-chars[] = gt_mbpsv_chars[].
          APPEND gt_bat_char.
          CLEAR  gt_bat_char.
          REFRESH gt_mbpsv_chars.
          CLEAR  gt_mbpsv_chars.
        ENDIF.

*       Build work table to be used later when generating batches via
*       function module ZFM_CREATE_BATMAS03
        gt_bat_char-matnr      = gs_e1edl24-matnr. "Material
        gt_bat_char-vendrbatch = gs_e1edl24-kdmat. "Vendor batch

        gt_bat_char-werks      = gs_e1edl24-werks. "Plant
        gt_bat_char-lgort      = gs_e1edl24-lgort. "Sloc

* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface

* IF Brazil ASN  Check Batch format.
        IF gv_parnr_bzl = gc_bzl.

* gs_e1edl24-charg
          ws_strlen = ws_strlen = strlen( gs_e1edl24-charg ).
          IF ws_strlen = lc_ten.
            ws_uniqid = gs_e1edl24-charg+0(2).
            READ TABLE  gt_zdl_fields
            WITH KEY fieldname = ws_uniqid.
            IF sy-subrc = 0.
            ELSE.
* Error incorrect batch format.
              PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '295'                    " err msg
                gs_e1edl24-charg                            " msgv1
                ' '                                         "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                ' '                                          "routid
                gs_idoc_data-segnum                          "seg num
                ' '.                                         "seg field
              RETURN.
            ENDIF.
          ELSE.
* Error incorrect batch format.
            PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZSD_DL'                 " message class
              '295'                    " err msg
              gs_e1edl24-charg                              " msgv1
              ' '                                           "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              ' '                                     " routid
              gs_idoc_data-segnum                       "seg num
              ' '.                                      "seg field
            RETURN.
          ENDIF.

        ENDIF.
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN

* CMS31175|ChangedBy:AMAOLE1|ChangedOn:11042016|START2
        DATA lv_flag2 TYPE char1.
        PERFORM update_weight_e1edl24 CHANGING gs_e1edl24 lv_flag2.

        IF lv_flag2 = 'Y'.
          gs_idoc_data-sdata   = gs_e1edl24.

          MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                 TRANSPORTING sdata.
        ENDIF.
* CMS31175|ChangedBy:AMAOLE1|ChangedOn:11042016|END2

*     Batch Characteristic values
      WHEN gc_e1edl15.
        CLEAR  gs_e1edl15.
*       Fetch Batch characteristics value
        MOVE gs_idoc_data-sdata TO gs_e1edl15.
        gt_mbpsv_chars-atnam      = gs_e1edl15-atbez.
        gt_mbpsv_chars-atwrt      = gs_e1edl15-atwrt.
        CONDENSE gt_mbpsv_chars-atwrt NO-GAPS.
        APPEND gt_mbpsv_chars.
        CLEAR  gt_mbpsv_chars.

*     PO info
      WHEN gc_e1edl43.
        MOVE gs_idoc_data-sdata TO gs_e1edl43.

*       check for Qualifier is 'V' - Purchase order
        IF gs_e1edl43-qualf = lc_qualf.

*         Build table to check for Duplicate vendor batch for function
*         module Z_SD_DL_I2301_CHECK_DUPLI_ASN
          int_asn-vgbel = gs_e1edl43-belnr. "PO number
          int_asn-bolnr = gs_e1edl20-bolnr. "BOL from L20 seg
          int_asn-matnr = gs_e1edl24-matnr. "Material from L24
          int_asn-inhalt = gs_e1edl24-kdmat. "Vendor Batch Number
          APPEND int_asn.
          CLEAR: int_asn.

*         Build table to check for to see if new Batch or HU numbers
*         need to be created for function module
*         Z_DL_E03126_UNIT_ID_CHECK
          CLEAR: gt_mbh.
          gt_mbh-matnr = gs_e1edl24-matnr. "Material from L24
          gt_mbh-exidv = gs_e1edl24-kdmat. "Vendor Batch Number
          gt_mbh-bolnr = gs_e1edl20-bolnr. "BOL from L20 seg
          gt_mbh-vgbel = gs_e1edl43-belnr. "PO number


*         Begin BCB09
*         Retrieve Vendor associated with PO
          READ TABLE gt_ekko INTO gs_ekko WITH KEY ebeln = gt_mbh-vgbel
            BINARY SEARCH.
          lv_tabix = sy-tabix. "index of itab for use of binary
          IF sy-subrc = 0.
            gt_mbh-lifnr = gs_ekko-lifnr.

* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface
            IF gv_parnr_bzl = gc_bzl.

              CLEAR: lv_lgort,lv_matnr_po,lv_werks,lv_knttp.
              SELECT SINGLE matnr werks lgort knttp
              INTO (lv_matnr_po,
                    lv_werks,
                    lv_lgort,
                    lv_knttp)
              FROM  ekpo
              WHERE ebeln = gs_ekko-ebeln
              AND   ebelp = gs_e1edl43-posnr.
              IF sy-subrc = 0.
                IF lv_lgort = ''.
*         Check for Storage location in PO, if the PO does not have
*        Stor.Locaion don't create inbound idoc, since storage location
*        is mandatory for packging.

                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '288'                    " err msg

                  gv_ekpo_ebeln                             " msgv1

                  gv_ekpo_ebelp                             "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  lc_form                                     " routid
                  gs_idoc_data-segnum                       "seg num
                  ' '.                                      "seg field
                  RETURN.
                ENDIF.
                IF ( lv_matnr_po = '' )
                   OR
                   ( lv_matnr_po <>  gs_e1edl24-matnr ).
*        Check for material number is PO and IDOC
                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 "message class
                  '069'                    "err msg
                 gv_ekpo_ebeln                              " msgv1
                 gs_e1edl24-matnr                           "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  'PROCESS_IDOC_PASN'                     " routid
                  gs_idoc_data-segnum                       "seg num
                  ' '.                                      "seg field
                  RETURN.
                ENDIF.
*        Check for Plant in PO and IDOC
                IF  lv_werks <> gs_e1edl24-werks.
                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 "message class
                  '062'                    "err msg
                  gs_e1edl24-werks                          " msgv1
                  ' '                                       "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  ' '                                     "routid
                  gs_idoc_data-segnum                     "seg num
                  ' '.                                    "seg field
                  RETURN.
                ENDIF.
                IF lv_knttp = 'Y'.
*        Check for Purchase Order is Goods receipt relevant.

                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_delete                      "status 68
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '290'                    " err msg
                  gv_ekpo_ebeln                             " msgv1
                  gv_ekpo_ebelp                             "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  ' '                                          " routid
                  gs_idoc_data-segnum                       "seg num
                  ' '.                                      "seg field
                  RETURN.
                ENDIF.
              ENDIF.
            ENDIF.
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN

          ELSE.
*           Retrieve the PO and Vendor and store in an itab sorted
*           by PO. This increases efficiency since we don't want to
*           keep hitting EKKO for every record if the referenced PO will
*           be the same on some or all Delivery items
** TPR # 33946   insert  kthakur
*            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*              EXPORTING
*                INPUT         = gt_mbh-vgbel
*             IMPORTING
*                OUTPUT        = gt_mbh-vgbel
*                      .
** TPR # 33946  end insert kthakur

            SELECT SINGLE ebeln lifnr
              INTO (gs_ekko-ebeln,
                    gs_ekko-lifnr)
              FROM ekko
              WHERE ebeln = gt_mbh-vgbel.

            INSERT gs_ekko INTO gt_ekko INDEX lv_tabix.
            gt_mbh-lifnr = gs_ekko-lifnr.
* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface

* For Brazil ASN   Check All PO details.
            IF gv_parnr_bzl = gc_bzl.
              IF gs_ekko IS INITIAL.
*         Unable to find PO in SAP

                PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '287'                    " Vendor mismatch
                gt_mbh-vgbel                                " msgv1
                ' '                                         "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                lc_form                                     " routid
                gs_idoc_data-segnum                       "seg num
                ' '.                                      "seg field
                RETURN.
              ENDIF.
              IF gs_ekko-lifnr <> gs_idoc_ctrl-sndprn.
*         Compare  Partner number in PO and IDOC

                PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '292'                    " Vendor mismatch

                gs_idoc_ctrl-sndprn                         " msgv1
                gs_ekko-lifnr                               "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                lc_form                                     " routid
                gs_idoc_data-segnum                       "seg num
                ' '.                                      "seg field
                RETURN.
              ENDIF.
              CLEAR: lv_lgort,lv_matnr_po,lv_werks,lv_knttp.
** TPR # 33946   insert  kthakur
*            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*              EXPORTING
*                INPUT         = gs_e1edl43-posnr
*             IMPORTING
*                OUTPUT        = gs_e1edl43-posnr
*                      .
** TPR # 33946  insert kthakur
              SELECT SINGLE matnr werks lgort knttp
              INTO (lv_matnr_po,
                    lv_werks,
                    lv_lgort,
                    lv_knttp)
              FROM  ekpo
              WHERE ebeln = gs_ekko-ebeln
              AND   ebelp = gs_e1edl43-posnr.
              IF sy-subrc = 0.
                IF lv_lgort = ''.
*        Check for Storage location in PO, if the PO does not have
*        Stor.Locaion don't create inbound idoc, since storage location
*        is mandatory for packging.

                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '288'                    " err msg
                  gv_ekpo_ebeln                             " msgv1
                  gv_ekpo_ebelp                             "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  lc_form                                     " routid
                  gs_idoc_data-segnum                       "seg num
                  ' '.                                      "seg field
                  RETURN.
                ENDIF.
                IF ( lv_matnr_po = '' )
                    OR
                   ( lv_matnr_po <>  gs_e1edl24-matnr ).
*        Check for material number in PO and IDOC
                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 "message class
                  '069'                    "err msg
                  gv_ekpo_ebeln                             " msgv1
                  gs_e1edl24-matnr                          "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  lc_form                                     " routid
                  gs_idoc_data-segnum                       "seg num
                  ' '.                                      "seg field
                  RETURN.

                ENDIF.
*        Check for Plant in PO and IDOC
                IF  lv_werks <> gs_e1edl24-werks.
                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error                       "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 "message class
                  '062'                    "err msg

                  gs_e1edl24-werks                          " msgv1
                  ' '                                       "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  ' '                                     "routid
                  gs_idoc_data-segnum                     "seg num
                  ' '.                                    "seg field
                  RETURN.

                ENDIF.
                IF lv_knttp = 'Y'.
*        Check for Purchase Order is Goods receipt relevant.

                  PERFORM sub_idoc_status_fill USING
                  c_idoc_status_delete                      "status 68
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZSD_DL'                 " message class
                  '290'                    " err msg
                  gv_ekpo_ebeln                             " msgv1
                  gv_ekpo_ebelp                             "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  ' '                                          " routid
                  gs_idoc_data-segnum                       "seg num
                  ' '.                                      "seg field
                  RETURN.
                ENDIF.

              ELSE.
*        Check for PO number & line item

                PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZSD_DL'                 " message class
                '287'                    " err msg

                gv_ekpo_ebeln                               " msgv1

                gv_ekpo_ebelp                               "msgv2

                ' '                                         "msgv3
                ' '                                         "msgv4
                lc_form                                     " routid
                gs_idoc_data-segnum                       "seg num
                ' '.                                      "seg field
                RETURN.


              ENDIF.

            ENDIF.
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN

          ENDIF.
*         End BCB09

          APPEND gt_mbh.
          CLEAR: gt_mbh.
        ENDIF.

*     HU header
      WHEN gc_e1edl37.
        MOVE gs_idoc_data-sdata TO gs_e1edl37.
        gs_hu_xref-orig_exidv = gs_e1edl37-exidv.  "Original HU
**     Begin of changes DGANDLA 2000002371 /SCTASK0079209
        IF gs_e1edl37-landt IS NOT INITIAL.
          gs_batch_coo-charg = gs_e1edl37-exidv.
          gs_batch_coo-cntry = gs_e1edl37-landt.
          APPEND gs_batch_coo TO gt_batch_coo.
          CLEAR gs_batch_coo.
        ENDIF.
*     End of changes DGANDLA 2000002371 /SCTASK0079209

*     HU item
      WHEN gc_e1edl44.
        MOVE gs_idoc_data-sdata TO gs_e1edl44.

        gs_hu_xref-kdmat      = gs_e1edl44-kdmat.  "Vendor Batch
        APPEND gs_hu_xref TO gt_hu_xref.

*       Store the Xref between HU and Vendor Batch. This will be used
*       later to help assign the PACKAGE_NUMBER characteristic when
*       generating new Batches in a Bundled Roll scenario. Example of
*       data would look something like this:
*       Original HU          Vendor Batch
*       -----------          ------------
*       BT1                  BT1
*       BT1                  BT2
*       BT3                  BT3
*       BT3                  BT4
*       BT3                  BT5
*
*       Batches BT1 & BT2 are bundled within HU BT1
*       Batches BT3, BT4, BT5 are bundled within HU BT3
*---Start of changes for Pallet weight update for BR, NY for Charm#2000002667, ID#VKAKI3 TR#S0VK912053
*---Updating the Full and Partial pallet weight material master weight for Brazil and Nymolla ASN
*---Check IDOC message type and this logic is applicable only ZDL_PASN
        IF gs_idoc_ctrl-mestyp = lc_pasn. "'ZDL_PASN'
          IF  lv_wt_upd IS NOT INITIAL.
            SELECT SINGLE FROM marm
            FIELDS matnr, meinh, umrez, umren
            WHERE matnr = @gs_e1edl44-matnr
            AND   meinh = @lc_pal "'PAL'                "Alternative UOM
            INTO @ls_marm.
            IF sy-subrc = 0.
              CLEAR: lv_lfimg1, lv_lfimg2.
              IF  ( ls_marm-umrez <> 0 OR  ls_marm-umren <> 0 ).
*---Get the material weight and upate on IDOC segment and Modify
                lv_lfimg1 = ls_marm-umrez / ls_marm-umren.
                lv_lfimg2 = gs_e1edl44-vemng. " = lv_lfimg1.
              ENDIF.
              IF lv_lfimg1 <> lv_lfimg2.
                gs_e1edl44-vemng = lv_lfimg1.
                gs_idoc_data-sdata   = gs_e1edl44.
                MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix TRANSPORTING sdata.
              ENDIF. "Weight
            ENDIF."marm
          ENDIF. "lv_wt_upd
        ENDIF. "ZDL_PASN
*---End of changes for Pallet weight update for BR, NY for Charm#2000002667, ID#VKAKI3 TR#S0VK912053
    ENDCASE.
  ENDLOOP.
  CLEAR:  lv_wt_upd, lv_lfimg1, lv_lfimg2.     "Added for Charm#2000002667, ID#VKAKI3 TR#S0VK912053
*->Begin of CMS30040
  lv_lfimg1 = lv_lfimg.

  LOOP AT gt_idoc_data INTO gs_idoc_data
          WHERE docnum  =  gs_idoc_ctrl-docnum
            AND segnam  =  gc_e1edt13.

    gv_tabix      =  sy-tabix.

    gs_e1edt13    = gs_idoc_data-sdata.

    IF gs_e1edt13-ntanf IS NOT INITIAL AND
       lv_weight IS NOT INITIAL.

      lv_dldate = gs_e1edt13-ntanf.

      IF lv_lfimg1 LT lv_weight AND lv_truck IS NOT INITIAL.
        lv_dldate = lv_dldate + lv_truck.
        gs_e1edt13-ntanf = lv_dldate.
        gs_idoc_data-sdata = gs_e1edt13.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                                          TRANSPORTING sdata.
      ELSEIF lv_lfimg1 GE lv_weight AND lv_rail IS NOT INITIAL.
        lv_dldate = lv_dldate + lv_rail.
        gs_e1edt13-ntanf = lv_dldate.
        gs_idoc_data-sdata = gs_e1edt13.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                                          TRANSPORTING sdata.
      ENDIF.

    ENDIF.

  ENDLOOP.
*-<End of CMS30040

* Add last/first record
  gt_bat_char-chars[] = gt_mbpsv_chars[].
  APPEND gt_bat_char.
  CLEAR  gt_bat_char.
* End BCB08

* Call Funtion Module 'Z_SD_DL_I2301_CHECK_DUPLI_ASN' to check dup
* delivery numbers against bill of lading, purchase order and unit id
  CLEAR lv_flag.
  IF NOT int_asn[] IS INITIAL.
    CALL FUNCTION 'Z_SD_DL_I2301_CHECK_DUPLI_ASN'
      IMPORTING
        ex_flag               = lv_flag
      TABLES
        it_asninfo            = int_asn
      EXCEPTIONS
        wrong_function_called = 1
        OTHERS                = 2.
    IF sy-subrc = 0 AND lv_flag = gc_true.
      LOOP AT int_asn.
        IF int_asn-flag = gc_true.
*       Update Error log, the idoc should not be processed if BOL
*       alreadyexist.
          PERFORM sub_idoc_status_fill USING
          c_idoc_status_error                               "status 51
              gs_idoc_ctrl-docnum                        "idoc number
              c_error                                  "status msg type
              'ZSD_DL'                                   "message class
              '285'                                      "err msg
              int_asn-vbeln                                 "msgv1
              int_asn-bolnr                                 "msgv2
              int_asn-inhalt                                "msgv3
              int_asn-vgbel                                 "msgv4
              lc_form                                       "routid
              ' '                                        "seg num
              ' '.                                       "seg field
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.

* Check for error status
  CHECK gv_idoc_error = gc_false.

* Read all materials to identify batch managed material.
  IF NOT gt_bat_char[] IS INITIAL.
    SELECT matnr
           xchpf
     FROM mara
     INTO TABLE lt_mara
     FOR ALL ENTRIES IN gt_bat_char
     WHERE matnr = gt_bat_char-matnr.
    IF sy-subrc NE 0.
      PERFORM sub_idoc_status_fill USING
       c_idoc_status_error                                  "status 51
         gs_idoc_ctrl-docnum     "idoc number
         c_error                 "status msg type
         'ZSD_DL'                "message class
         '000'                   "err msg
         TEXT-e04                                           "msgv1
         ' '                                                "msgv2
         ' '                                                "msgv3
         ' '                                                "msgv4
         lc_form                 "routid
         ' '                     "seg num
         ' '.                    "seg field
    ENDIF.
  ENDIF.

  IF NOT gt_mbh[] IS INITIAL.

*  Create unique-id for Batch i.e., validate batch #
    CALL FUNCTION 'Z_DL_E03126_UNIT_ID_CHECK'
      TABLES
        it_batch               = gt_mbh[]
      EXCEPTIONS
        number_range_not_found = 1
        OTHERS                 = 2.
    IF sy-subrc = 0.
      CLEAR:  gt_mbpsv, gt_mbpsv[].

*     Begin BCB08
*     Replace existing Batchnumbers with new unit-id's if applicable
      LOOP AT gt_mbh.

        lv_tabix = sy-tabix.

*       If the 'old_batch_flag' is blank then a new unique id created
        IF gt_mbh-old_batch_flag IS INITIAL.  "New unique-id created

          READ TABLE gt_bat_char INDEX lv_tabix.

          IF sy-subrc = 0.
*           Determine if material is Batch Managed
            READ TABLE lt_mara WITH KEY matnr = gt_mbh-matnr.

*           If Batch Managed then build a table of new Batches to be
*           created via function module ZFM_CREATE_BATMAS03
            IF lt_mara-xchpf IS NOT INITIAL.
*---Start of changes for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
              SELECT COUNT( * ) FROM zdl_fields
                WHERE category = lc_cat
                AND lowval = gt_mbh-lifnr.
              IF sy-subrc = 0.
                SELECT SINGLE land1 FROM lfa1
                  INTO @DATA(lv_land)
                  WHERE lifnr = @gt_mbh-lifnr.
                IF sy-subrc = 0.
                  gt_mbh-batch_num = |{ lv_land }{ gt_mbh-batch_num+2(8) }|.
                  MODIFY gt_mbh INDEX lv_tabix TRANSPORTING batch_num.
                ENDIF.
              ENDIF.
*---End of changes for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
              gt_mbpsv-matnr       = gt_mbh-matnr.
              gt_mbpsv-charg       = gt_mbh-batch_num.  "vendor batch
              gt_mbpsv-werks       = gt_bat_char-werks.
              gt_mbpsv-lgort       = gt_bat_char-lgort.
              gt_mbpsv-vendrbatch  = gt_mbh-exidv.
              gt_mbpsv-chars       = gt_bat_char-chars.
              APPEND  gt_mbpsv.
              CLEAR   gt_mbpsv.

*             Update the work table with new SAP Batch Number when
*             Batch Managed
              gt_bat_char-charg = gt_mbh-batch_num.
              MODIFY gt_bat_char INDEX lv_tabix TRANSPORTING charg.

            ELSE.
*             Update the work table with blank SAP Batch Number when
*             Not Batch Managed
              CLEAR: gt_bat_char-charg.
              MODIFY gt_bat_char INDEX lv_tabix TRANSPORTING charg.

            ENDIF.
          ENDIF.
        ENDIF.                   " Only for new batches

      ENDLOOP.
*     End BCB08

    ELSE.
*     Update error log
      PERFORM sub_idoc_status_fill USING
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          TEXT-101                                          "msgv1
          ' '                                               "msgv2
          ' '                                               "msgv3
          ' '                                               "msgv4
          lc_form                 "routid
          ' '                     "seg num
          ' '.                    "seg field
      RETURN.
    ENDIF.
  ENDIF.
*  ENDIF.

* Begin BCB08
* Add Batch Characteristics will differ for Manual ASN versus EDI ASN
* so adding a new subroutine for Manual ASN instead of using shared
* subroutine add_batch_chars
* BCB08 Delete Begin
* start of change 04/19/2006
* Add aditional batch chars: roll width in meters,roll weight in KG's
* and Package Number
*  PERFORM add_batch_chars.
* end of change 04/19/2006
* BCB08 Delete End

* BCB08 Insert Begin
  IF gt_mbpsv[] IS NOT INITIAL.

    PERFORM add_additional_batch_chars.

  ENDIF.
* BCB08 Insert End
* End BCB08

* Create Batch chars for all batch managed materils with new batch/unit
* id
  IF NOT gt_mbpsv[] IS INITIAL.
    PERFORM sub_batch_create.
  ENDIF.
* Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface
  IF gv_parnr_bzl = gc_bzl.
    CHECK gv_idoc_error = gc_false.
  ENDIF.
* End insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN
* Begin BCB08
* Update Delivery Item data segment "E1EDL24" with the new SAP Batch
* Number if applicable
  CLEAR: lv_24count.
  LOOP AT gt_idoc_data INTO gs_idoc_data
                       WHERE   docnum  =  gs_idoc_ctrl-docnum
                         AND   segnam  =  gc_e1edl24.

    lv_tabix = sy-tabix. "store index of idoc table
    lv_24count = lv_24count + 1. "this counter relates to oth work tabls

    gs_e1edl24 = gs_idoc_data-sdata.

*   Retrieve corresponding work table record by matching Vendor Batch.
*   There is a 1 to 1 relationship between the number of E1EDL24 segs
*   and gt_bat_char since gt_bat_char was built from E1EDL24 segments.
    READ TABLE gt_bat_char INDEX lv_24count.
    IF sy-subrc = 0.

*     If a new SAP Batch Number was created then update L24 segment
*     with the new SAP Batch Number. If this is not Batch Managed then
*     they should both be SPACE and nothing will be updated.
      IF gs_e1edl24-charg NE gt_bat_char-charg.
        gs_e1edl24-charg = gt_bat_char-charg.
        MOVE gs_e1edl24 TO gs_idoc_data-sdata.
*       Modify IDOC data internal table
        MODIFY  gt_idoc_data INDEX lv_tabix FROM gs_idoc_data
          TRANSPORTING sdata.
      ENDIF.

    ENDIF.
  ENDLOOP.
* End BCB08

* Get Packing Materials details and populate that into VHILM and
* VHILM_KU field.
  SELECT SINGLE matnr
        INTO lv_matnr
        FROM mara
        WHERE  mtart = lc_verp
          AND  vhart = lc_pkg.
  IF sy-subrc NE 0.
    PERFORM sub_idoc_status_fill USING
      c_idoc_status_error                                   "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '000'                   "err msg
        TEXT-e01                                            "msgv1
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        lc_form                 "routid
        ' '                     "seg num
        ' '.                    "seg field
  ENDIF.


* Begin BCB08
* Update HU Header and HU Item data with the new SAP HU
* Number if applicable.
  CLEAR: lv_44count,
         gs_l37,
         gt_l37,
         gs_l44,
         gt_l44.

  LOOP AT gt_idoc_data
       INTO gs_idoc_data
       WHERE   docnum  =  gs_idoc_ctrl-docnum
         AND ( segnam  =  gc_e1edl37 OR
               segnam  =  gc_e1edl44 ).

    lv_tabix      =  sy-tabix. "store index of doc record

    CASE gs_idoc_data-segnam.
      WHEN gc_e1edl37.

        gs_e1edl37 = gs_idoc_data-sdata.

        gs_e1edl37-vhilm_ku = gs_e1edl37-exidv. "store original HU
        gs_e1edl37-vhilm     = lv_matnr.     "store packaging material

*       Find matching record on work table used to generate new unit id
*       number. If batch managed scenario, the gt_mbh-exidv is the
*       Vendor Batch Number. If not batch managed, it is the HU number
        READ TABLE gt_mbh WITH KEY exidv = gs_e1edl37-exidv.
        IF sy-subrc = 0.
*         If a new unit id was generated for either the HU (non batch
*         managed) or the Batch (batch managed scenario) then overlay
*         the HU with the newly generated unit id.
          IF gs_e1edl37-exidv NE gt_mbh-batch_num.
            gs_e1edl37-exidv = gt_mbh-batch_num.
          ENDIF.
        ENDIF.

*       Update segment data
        gs_idoc_data-sdata = gs_e1edl37.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX lv_tabix
          TRANSPORTING sdata.

*       Build table of HU's relevant to this ASN whether the HU exists
*       or not.
        gs_hu-exidv = gs_e1edl37-exidv.
        APPEND gs_hu TO gt_hu.

*       Build HU Header data table for use when generating HU's
        MOVE-CORRESPONDING gs_e1edl37 TO gs_l37.
        APPEND gs_l37 TO gt_l37.


      WHEN gc_e1edl44.

        lv_44count  = lv_44count + 1."ctr relates to oth work tables

        gs_e1edl44 = gs_idoc_data-sdata.

*       Find matching record on work table used to generate new unit id
*       number. If batch managed scenario, the gt_mbh-exidv is the
*       Vendor Batch Number. If not batch managed, it is the HU number.
*       The retrieved value will be the new HU Number
        READ TABLE gt_mbh WITH KEY exidv = gs_e1edl44-exidv.
        IF sy-subrc = 0.
*         If a new unit id was generated for either the HU (non batch
*         managed) or the Batch (batch managed scenario) then overlay
*         the HU with the newly generated unit id.
          IF gs_e1edl44-exidv NE gt_mbh-batch_num.
            gs_e1edl44-exidv = gt_mbh-batch_num.
          ENDIF.
        ENDIF.

*       Determine the new SAP Batch Number if applicable. There is a
*       one to one relationship between the number of E1EDL44 segments
*       and table gt_bat_char (since gt_bat_char was generating from a
*       one to one relationship with E1EDL24).
        READ TABLE gt_bat_char INDEX lv_44count.
        IF sy-subrc = 0.
          gs_e1edl44-charg = gt_bat_char-charg.
        ENDIF.

*       Update segment data
        gs_idoc_data-sdata = gs_e1edl44.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX lv_tabix
          TRANSPORTING sdata.

*       Build HU Item data table for use when generating HU's
        MOVE-CORRESPONDING gs_e1edl44 TO gs_l44.
        APPEND gs_l44 TO gt_l44.

    ENDCASE.
  ENDLOOP.

* Create New Handling Unit(s) if doesn't exist
  PERFORM hu_create.
* End BCB08

* Delete all Handling unit header and Item segments from IDOC data
  DELETE gt_idoc_data WHERE segnam =  gc_e1edl37 OR
                            segnam =  gc_e1edl44.

ENDFORM.                    " process_idoc_pasn
*&---------------------------------------------------------------------*
*&      Form  sub_batch_create
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM sub_batch_create .

  DATA:
    ls_idoc_ctrl TYPE  edi_dc40,
    lc_batmas    TYPE  edilsegtyp VALUE 'BATMAS',
    lc_batmas03  TYPE  edilsegtyp VALUE 'BATMAS03',
    lc_mescod    TYPE  edi4mescod VALUE 'PSN',
    lc_rcvprt    TYPE  edi4rcvprt VALUE 'US',
    lc_sndpor    TYPE  edi4sndpor VALUE 'TRFC'.

*  Convert gs_idoc_ctrl (type edidc) into ls_idoc_control
*  (type edi_dc40)
*  Set partner profile for the BATMAS03 for this message type
*  Change MESTYP = BATMAS and IDOCTYPE = BATMAS03.
*  Set MESCODE = this object's message type; ie., ZDL_VASN
  IF NOT gs_idoc_ctrl IS INITIAL.
    MOVE-CORRESPONDING gs_idoc_ctrl TO ls_idoc_ctrl.
    CLEAR: ls_idoc_ctrl-docnum.
    ls_idoc_ctrl-idoctyp  = lc_batmas03.
    ls_idoc_ctrl-mestyp   = lc_batmas.
    ls_idoc_ctrl-mescod   = lc_mescod.
    ls_idoc_ctrl-rcvprt   = lc_rcvprt.
    CONCATENATE sy-sysid 'CLNT' sy-mandt INTO ls_idoc_ctrl-rcvprn.

    ls_idoc_ctrl-sndpor   = lc_sndpor.
    ls_idoc_ctrl-sndprt   = lc_rcvprt.
    ls_idoc_ctrl-sndprn   = ls_idoc_ctrl-rcvprn.
  ENDIF.

  IF NOT gt_mbpsv[] IS INITIAL.
*Begin of changes DGANDlA 2000002371 /SCTASK0079209 .
*Comment-> Export to the FM ZFM_CREATE_BATMAS03
    IF gt_batch_coo IS NOT INITIAL.
      FREE MEMORY ID 'BATCH_COO'.
      EXPORT gt_batch_coo TO MEMORY ID 'BATCH_COO'.
      CLEAR gt_batch_coo.
    ENDIF.

*End of changes DGANDLA 2000002371 /SCTASK0079209
    CALL FUNCTION 'ZFM_CREATE_BATMAS03'
      EXPORTING
        i_idoc_control  = ls_idoc_ctrl
        it_batch        = gt_mbpsv[]
      TABLES
        et_batch_status = gt_mbis[]
        et_return       = gt_bapi[].

    IF NOT gt_mbis[] IS INITIAL.

      IF gv_parnr_bzl = gc_bzl.
        LOOP AT gt_mbis.
          IF gt_mbis-status <> c_idoc_status_ok.  "failed
            PERFORM sub_idoc_status_fill USING
              c_idoc_status_error
*            gt_mbis-status          "status
              gt_mbis-docnum          "idoc number
              c_error                 "status msg type
              'ZSD_DL'                "message class
              '000'                   "err msg
              TEXT-102                                      "msgv1
              gt_mbis-matnr                                 "msgv2
              gt_mbis-charg                                 "msgv3
              gt_mbis-statxt                                "msgv4
              'PROCESS_IDOC_PASN'     "routid
              ' '                     "seg num
              ' '.                    "seg field
          ENDIF.
        ENDLOOP.  "Status update
        RETURN.

      ELSE.

        LOOP AT gt_mbis.
          IF gt_mbis-status <> c_idoc_status_ok.  "failed
            PERFORM sub_idoc_status_fill USING
              gt_mbis-status          "status
              gt_mbis-docnum          "idoc number
              c_error                 "status msg type
              'ZSD_DL'                "message class
              '000'                   "err msg
              TEXT-102                                      "msgv1
              gt_mbis-matnr                                 "msgv2
              gt_mbis-charg                                 "msgv3
              gt_mbis-statxt                                "msgv4
              'PROCESS_IDOC_PASN'     "routid
              ' '                     "seg num
              ' '.                    "seg field
          ENDIF.
        ENDLOOP.  "Status update
      ENDIF.
      IF gv_parnr_bzl = gc_bzl.
        CHECK gv_idoc_error <> gc_true.

      ENDIF.
      SORT gt_mbis BY status.
      READ TABLE gt_mbis WITH KEY status = c_idoc_status_error
                          BINARY SEARCH.
*     Don't create Inbound delivery IDoc if any one of the
*     batch creation failed
      IF sy-subrc = 0.  "Any one batch creation failed
        gv_idoc_error    = gc_true.
      ENDIF.
    ENDIF.

    IF gt_bapi[] IS INITIAL.  "Error not occured
      gv_idoc_error    = gc_false.
    ELSE.
      LOOP AT gt_bapi.
        IF NOT gt_bapi-number IS INITIAL.
          gv_idoc_error    = gc_true.
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum     "idoc number
              gt_bapi-type            "status msg type
              gt_bapi-log_no          "message class
              gt_bapi-log_msg_no      "err msg
              gt_bapi-message_v1                            "msgv1
              gt_bapi-message_v2                            "msgv2
              gt_bapi-message_v3                            "msgv3
              gt_bapi-message_v4                            "msgv4
              'PROCESS_IDOC_PASN'     "routid
              ' '                     "seg num
              ' '.                    "seg field
        ENDIF.
      ENDLOOP.
      RETURN.
    ENDIF.
  ENDIF.

ENDFORM.                    " sub_batch_create
*&---------------------------------------------------------------------*
*&      Form  add_batch_chars
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_MBPSV  text
*----------------------------------------------------------------------*
FORM add_batch_chars.

  DATA: wa_head       TYPE zfm_chars,
        lv_roll_metr  TYPE zzroll_weight_metric,
        lv_rollwidth  TYPE zzlinear_footage_metric,
        lv_roll_feet  TYPE zzweight_of_roll_in_lbs,
        lv_roll_width TYPE zzweight_of_roll_in_lbs.

  CLEAR: gt_mbpsv,
         gt_mbpsv-chars,
         wa_head.

  LOOP AT gt_mbpsv.
    CLEAR wa_head.
    LOOP AT gt_mbpsv-chars INTO wa_head.

      CASE wa_head-atnam.

        WHEN 'WEIGHT_OF_ROLL_IN_LBS'.
          IF NOT wa_head-atwrt IS INITIAL.
            CLEAR: lv_roll_width,
                   lv_roll_metr.
            lv_roll_width = wa_head-atwrt.
            CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
              EXPORTING
                input                = lv_roll_width
                kzmeinh              = ' '
                matnr                = gt_mbpsv-matnr
                meinh                = 'KG'
                meins                = 'LB'
              IMPORTING
                output               = lv_roll_metr
              EXCEPTIONS
                conversion_not_found = 1
                input_invalid        = 2
                material_not_found   = 3
                meinh_not_found      = 4
                meins_missing        = 5
                no_meinh             = 6
                output_invalid       = 7
                overflow             = 8
                OTHERS               = 9.
            IF sy-subrc = 0.
              wa_head-atnam = 'ROLL_WEIGHT_METRIC'.
              wa_head-atwrt = lv_roll_metr.
              CONDENSE  wa_head-atwrt NO-GAPS.
              APPEND wa_head TO gt_mbpsv-chars.
              CLEAR wa_head.
              wa_head-atnam = 'PACKAGE_NUMBER'.
              wa_head-atwrt = gt_mbpsv-charg.
** Begin Bruce --> check this logic when done
** Before creation of the Batches, add the Batch Char.
** Package Number with Handling Unit number. CR-8050
*              IF gv_parnr_ppr = gc_ppr.
*                CLEAR gt_batches_per_package.
*                READ TABLE gt_batches_per_package
*                     WITH KEY charg = gt_mbpsv-vendrbatch.
*                IF sy-subrc = 0.
*                  CLEAR gt_mbhp_tab.
*                  READ TABLE gt_mbhp_tab
*                       WITH KEY charg = gt_batches_per_package-exidv.
*                  IF sy-subrc = 0.
*                    wa_head-atnam = 'PACKAGE_NUMBER'.
*                    wa_head-atwrt = gt_mbhp_tab-nexidv.
*                  ENDIF.
*                ENDIF.
*              ENDIF.
** End of chnages for CR-8050.
              CONDENSE wa_head-atwrt NO-GAPS.
              APPEND wa_head TO gt_mbpsv-chars.
            ENDIF.
          ENDIF.
        WHEN 'LINEAL_FOOTAGE'.
          IF NOT wa_head-atwrt IS INITIAL.
            CLEAR: lv_roll_feet,
                   lv_rollwidth.
            lv_roll_feet  = wa_head-atwrt.
            CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
              EXPORTING
                input                = lv_roll_feet
                unit_in              = 'LF'
                unit_out             = 'M'
              IMPORTING
                output               = lv_rollwidth
              EXCEPTIONS
                conversion_not_found = 1
                division_by_zero     = 2
                input_invalid        = 3
                output_invalid       = 4
                overflow             = 5
                type_invalid         = 6
                units_missing        = 7
                unit_in_not_found    = 8
                unit_out_not_found   = 9
                OTHERS               = 10.
            IF sy-subrc = 0.
              wa_head-atnam = 'LINEAR_FOOTAGE_METRIC'.
              wa_head-atwrt = lv_rollwidth.
              CONDENSE  wa_head-atwrt NO-GAPS.
              APPEND wa_head TO gt_mbpsv-chars.
              CLEAR wa_head.
            ENDIF.
          ENDIF.
      ENDCASE.
    ENDLOOP.
    MODIFY gt_mbpsv TRANSPORTING chars.
    CLEAR gt_mbpsv.
  ENDLOOP.

ENDFORM.                    " add_batch_chars
*&---------------------------------------------------------------------*
*&      Form  check_if_trades
*&---------------------------------------------------------------------*
*       Determine if this is Trades. If so, determine if this is PO1
*       or PO2
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_if_trades .

  DATA: lv_bsart TYPE esart,  "po type
        lv_lifnr TYPE elifn.  "vendor


  CONSTANTS:

    lc_thd       TYPE esart VALUE 'THD',       "Trades PO type
    lc_nb        TYPE esart VALUE 'NB',        "Standard PO type
    lc_ip0508530 TYPE elifn VALUE 'IP0508530'. "Trades Vendor


  LOOP AT gt_idoc_data INTO gs_idoc_data
    WHERE   docnum  =  gs_idoc_ctrl-docnum
      AND ( segnam  =  gc_e1edl43 ).

    gv_tabix      =  sy-tabix.

    gs_e1edl43    = gs_idoc_data-sdata.

    IF gs_e1edl43-qualf      = 'V'.    "SD document category
      CLEAR: gv_ebeln.
      IF NOT gs_e1edl43-belnr IS INITIAL. "PO det. empty in IDOC

*       Convert idoc PO number to numeric format
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = gs_e1edl43-belnr
          IMPORTING
            output = gv_ebeln.

*       Determine if this is a PO1 or PO2
        SELECT SINGLE bsart  "po type
                      lifnr  "vendor
          INTO (lv_bsart, lv_lifnr) FROM ekko
          WHERE ebeln = gv_ebeln.
*       check subrc for error ???
** CR# 8805/8806 Brazil ASN
*        if  gv_parnr_bzl = gc_bzl.
*           select SINGLE ebeln
*                         posnr
*                         matnr
*             INTO (lv_ebeln, lv_posnr,lv_matnr )
*             from ekpo
*             WHERE ebeln = gv_ebeln
*             and   posnr = gs_e1edl43-posnr.
*          if sy-subrc <> 0.
**   Error .005
*          endif.
*        endif.
*       PO2 logic
        IF lv_bsart = lc_thd.
*         Convert idoc data to PO1
          PERFORM convert_data_to_po1 CHANGING gv_trades_asn1.
*         Retrieve cross-ref info to update zdl_trades
          PERFORM retrieve_trades_asn1_info.
*       PO1 logic
        ELSEIF lv_bsart = lc_nb AND lv_lifnr = lc_ip0508530.

*         Convert the PO1's on the idoc to the corresponding PO2's so
*         we can reuse subroutines coded for Vendor ASN (I02301). The
*         sub convert_data_to_po1 will convert it back to PO1 but also
*         start gathering cross-reference information needed to update
*         table ZDL_TRADES.
          PERFORM convert_po1_to_po2.        "convert PO1's to PO2's

*         Convert idoc data to PO1
          PERFORM convert_data_to_po1 CHANGING gv_trades_asn1.
*         Retrieve cross-ref info to update zdl_trades
          PERFORM retrieve_trades_asn1_info.

        ENDIF.

*       Only perform the Trades check once
        EXIT.

      ENDIF. "if belnr is initial

    ENDIF. "if qualifier is a 'V'

  ENDLOOP.

ENDFORM.                    " check_if_trades
*&---------------------------------------------------------------------*
*&      Form  convert_po1_to_po2
*&---------------------------------------------------------------------*
*       Replace all PO1's on the idoc with their corresponding PO2's
*       in order to "trick" the code into allowing us to use existing
*       subroutine convert_data_to_po1.
*----------------------------------------------------------------------*

FORM convert_po1_to_po2 .

  TYPES: BEGIN OF lty_belnr,
           po1 TYPE ebeln, "PO1
           po2 TYPE ebeln,                                 "PO2,
         END OF lty_belnr.

  DATA: lt_belnr TYPE STANDARD TABLE OF lty_belnr,
        ls_belnr TYPE lty_belnr.

  DATA: lv_so  TYPE vbeln_va,   "SO

        lv_po1 TYPE bstnk,      "PO1
        lv_po2 TYPE ebeln.      "PO2

  LOOP AT gt_idoc_data INTO gs_idoc_data
    WHERE   docnum  =  gs_idoc_ctrl-docnum
      AND ( segnam  =  gc_e1edl43 ).

    gv_tabix      =  sy-tabix.

    gs_e1edl43    = gs_idoc_data-sdata.

    IF gs_e1edl43-qualf      = 'V'.    "SD document category
      CLEAR: gv_ebeln.

      IF NOT gs_e1edl43-belnr IS INITIAL. "PO det. empty in IDOC

*       Convert idoc PO1 number to numeric format
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = gs_e1edl43-belnr
          IMPORTING
            output = gv_ebeln.

*       Read internal table to see if the corresponding PO2 was already
*       retrieved for this PO1. If so, replace the PO1 with PO2. NOTE,
*       this table is built for efficiency so that we do not have to
*       perform unnecessary SELECTs
        READ TABLE lt_belnr INTO ls_belnr WITH KEY po1 = gv_ebeln.

        IF sy-subrc = 0.
          gs_e1edl43-belnr = ls_belnr-po2.
          gs_idoc_data-sdata = gs_e1edl43.
          MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
            TRANSPORTING sdata.

        ELSE.

*         Retrieve Sales Order using PO1. In some cases VBAK-BSTNK has
*         the PO1 in leading 0 format and sometimes no leading 0's. We
*         need to check for both if the first SELECT fails.
          lv_po1 = gv_ebeln. "Format PO as leading 0 format
          SELECT SINGLE vbeln INTO lv_so FROM vbak
            WHERE bstnk = lv_po1.
          IF sy-subrc NE 0.
            SHIFT lv_po1 LEFT DELETING LEADING '0'. "remove leading 0's
            SELECT SINGLE vbeln INTO lv_so FROM vbak
              WHERE bstnk = lv_po1.
            IF sy-subrc NE 0.
*           Error retrieving Sales Order from VBAK using PO1 &
              PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
                  gs_idoc_ctrl-docnum               "idoc number
                  c_error                           "status msg type
                  'ZSD_DL'                          "message class
                  '192'                             "err msg
                  gv_ebeln                                  "msgv1
                  ' '                                       "msgv2
                  ' '                                       "msgv3
                  ' '                                       "msgv4
                  'convert_po1_to_po2'              "routid
                  ' '                               "seg num
                  ' '.                              "seg field
              RETURN.
            ENDIF.
          ENDIF.

*         Retrieve PO2 using Sales Order
          SELECT SINGLE vbeln  INTO lv_po2 FROM vbfa
            WHERE vbelv = lv_so   "sales order
              AND vbtyp_n = 'V'.  "PO
          IF sy-subrc = 0.

*           Add record to work table
            ls_belnr-po1 = gv_ebeln.
            ls_belnr-po2 = lv_po2.
            APPEND ls_belnr TO lt_belnr.

*           Replace PO1 with PO2 on the idoc
            gs_e1edl43-belnr = ls_belnr-po2.
            gs_idoc_data-sdata = gs_e1edl43.
            MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
              TRANSPORTING sdata.

          ELSE.
*           PO2 not found on VBFA for Sales Order &
            PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum               "idoc number
                c_error                           "status msg type
                'ZSD_DL'                          "message class
                '193'                             "err msg
                lv_so                                       "msgv1
                ' '                                         "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                'convert_po1_to_po2'              "routid
                ' '                               "seg num
                ' '.                              "seg field
            RETURN.
          ENDIF.

        ENDIF.

      ENDIF. "if belnr is initial

    ENDIF. "if qualifier is a 'V'

  ENDLOOP.

ENDFORM.                    " convert_po1_to_po2
*&---------------------------------------------------------------------*
*&      Form  HU_CREATE
*&---------------------------------------------------------------------*
*       Generate HU's if they don't exist. This logic works for both
*       Bundled and Non-Bundled Rolls
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM hu_create .

  DATA:  lv_exidv    TYPE exidv.

  CONSTANTS:

*   Type of Handling-unit Item Content
    lc_material_item    TYPE  velin        VALUE '1',

*   HU Status
    lc_in_warehouse     TYPE  hu_st_init   VALUE 'C',
    lc_unassign         TYPE  hu_st_init   VALUE 'A', "Brazil ASN
    lc_not_in_warehouse TYPE hu_st_init VALUE 'B'.

* Process HU Header data
  LOOP AT gt_l37 INTO gs_l37.

*   Determine if HU exists. If not then create it
    SELECT SINGLE exidv INTO lv_exidv FROM vekp
        WHERE exidv = gs_l37-exidv
          AND status <> gc_hu_status.   " HU status '0060'
    IF sy-subrc = 0.
      CONTINUE.
    ENDIF.

*   Retrieve Plant from 1st E1EDL44 record
    READ TABLE gt_l44 INTO gs_l44
      WITH KEY exidv = gs_l37-exidv.

*   Populate Header structure
    CLEAR: gs_headerproposal.
    IF gv_parnr_bzl = gc_bzl.
      gs_headerproposal-hu_status_init = lc_unassign.  "A Brazil
    ELSE.
      gs_headerproposal-hu_status_init = lc_not_in_warehouse.  "B
    ENDIF.
    gs_headerproposal-pack_mat       = gs_l37-vhilm. "HU packng matl
    gs_headerproposal-content        = gs_l37-vhilm_ku. "Vendor ID
    gs_headerproposal-hu_exid        = gs_l37-exidv. "HU
    gs_headerproposal-plant          = gs_l44-werks. "HU plant

*   Process HU Item data
    CLEAR: gs_itemsproposal, gt_itemsproposal[].
    LOOP AT gt_l44 INTO gs_l44
      WHERE exidv = gs_l37-exidv.

*     Populate item table
      gs_itemsproposal-hu_item_type      = lc_material_item.
      gs_itemsproposal-pack_qty          = gs_l44-vemng.

*     Retrieve SAP uom using ISO Code uom stored in L44 from current HU
      CLEAR: gs_itemsproposal-base_unit_qty.
      SELECT SINGLE msehi INTO gs_itemsproposal-base_unit_qty FROM t006
        WHERE isocode = gs_l44-vemeh.
      IF sy-subrc <> 0.
        gs_itemsproposal-base_unit_qty = gs_l44-vemeh.
      ENDIF.

      gs_itemsproposal-material          = gs_l44-matnr.
      gs_itemsproposal-batch             = gs_l44-charg.
      gs_itemsproposal-plant             = gs_l44-werks.
      APPEND gs_itemsproposal  TO  gt_itemsproposal.
    ENDLOOP.                                                "gt_l44

*   endif.

*   Create the new Handling Unit
    CLEAR gt_return[]. "refresh error table
    CALL FUNCTION 'BAPI_HU_CREATE'
      EXPORTING
        headerproposal = gs_headerproposal  "Hdr data
      TABLES
        itemsproposal  = gt_itemsproposal   "Itm data
        return         = gt_return.
    IF NOT gt_return[] IS INITIAL.
*     Write all Bapi return messages to idoc status table
      LOOP AT gt_return INTO gs_return.
*
        PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            gs_return-id           "message class
            gs_return-number            "err msg
            gs_return-message_v1                            "msgv1
            gs_return-message_v2                            "msgv2
            gs_return-message_v3                            "msgv3
            gs_return-message_v4                            "msgv4
            'BAPI_HU_CREATE'                                    "routid
            gs_idoc_data-segnum                                 "seg num
            ' '.                    "seg field
      ENDLOOP.
      RETURN. "leave subroutine
    ENDIF.

*   Commit data to database
    CLEAR: gs_return.
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait   = 'X'      "wait for update
      IMPORTING
        return = gs_return.
    IF NOT gs_return IS INITIAL.
*     Write all Bapi return messages to idoc status table
      PERFORM sub_idoc_status_fill USING
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          gs_return-id           "message class
          gs_return-number            "err msg
          gs_return-message_v1                              "msgv1
          gs_return-message_v2                              "msgv2
          gs_return-message_v3                              "msgv3
          gs_return-message_v4                              "msgv4
          'BAPI_HU_CREATE'                                    "routid
          gs_idoc_data-segnum                                 "seg num
          ' '.                    "seg field
      RETURN. "leave subroutine
    ENDIF.

  ENDLOOP.                                                  "gt_l37

ENDFORM.                    " HU_CREATE
*&---------------------------------------------------------------------*
*&      Form  ADD_ADDITIONAL_BATCH_CHARS
*&---------------------------------------------------------------------*
*       New Logic to Assign PACKAGE_NUMBER will now work for a
*       Bundled Roll Scenario, as well as Break Bulk, for the Manual
*       ASN. EDI Logic has been changed in subroutine add_batch_chars so
*       I didn't want to chance breaking that code. This logic will only
*       be executed for Batch Managed materials.
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM add_additional_batch_chars .

  DATA: wa_head       TYPE zfm_chars,
        lv_roll_metr  TYPE zzroll_weight_metric,
        lv_rollwidth  TYPE zzlinear_footage_metric,
        lv_roll_feet  TYPE zzweight_of_roll_in_lbs,
        lv_roll_width TYPE zzweight_of_roll_in_lbs.

  CLEAR: gt_mbpsv,
         gt_mbpsv-chars,
         wa_head.

  LOOP AT gt_mbpsv.
    CLEAR wa_head.
    LOOP AT gt_mbpsv-chars INTO wa_head.

      CASE wa_head-atnam.

        WHEN 'WEIGHT_OF_ROLL_IN_LBS'.
          IF NOT wa_head-atwrt IS INITIAL.
            CLEAR: lv_roll_width,
                   lv_roll_metr.
            lv_roll_width = wa_head-atwrt.
            CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
              EXPORTING
                input                = lv_roll_width
                kzmeinh              = ' '
                matnr                = gt_mbpsv-matnr
                meinh                = 'KG'
                meins                = 'LB'
              IMPORTING
                output               = lv_roll_metr
              EXCEPTIONS
                conversion_not_found = 1
                input_invalid        = 2
                material_not_found   = 3
                meinh_not_found      = 4
                meins_missing        = 5
                no_meinh             = 6
                output_invalid       = 7
                overflow             = 8
                OTHERS               = 9.
            IF sy-subrc = 0.
              wa_head-atnam = 'ROLL_WEIGHT_METRIC'.
              wa_head-atwrt = lv_roll_metr.
              CONDENSE  wa_head-atwrt NO-GAPS.
              APPEND wa_head TO gt_mbpsv-chars.

              CLEAR wa_head.
              wa_head-atnam = 'PACKAGE_NUMBER'.

*             Begin BCB08
*              wa_head-atwrt = gt_mbpsv-charg.

*             Retrieve Original HU by matching up the Vendor Batch
              READ TABLE gt_hu_xref INTO gs_hu_xref
                WITH KEY kdmat = gt_mbpsv-vendrbatch.
              IF sy-subrc = 0.
*               Retrieve the newly-created SAP Batch Number (or the
*               value could be the original Vendor Batch if it had
*               passed all of the batch validations (ie 10 bytes, etc))
*               by matching the Original HU to the Vendor Batch in itab
*               gt_mbh (vendor batch is formatted into field
*               gt_mbh-exidv). Keep in mind that the Original HU MUST BE
*               identical to the lowest sorted Vendor Batch in a bundled
*               roll scenario.
                READ TABLE gt_mbh
                  WITH KEY exidv = gs_hu_xref-orig_exidv.
                IF sy-subrc = 0.
                  wa_head-atwrt = gt_mbh-batch_num.
                  CONDENSE wa_head-atwrt NO-GAPS.
                  APPEND wa_head TO gt_mbpsv-chars.
                ENDIF.
              ENDIF.

*              CONDENSE wa_head-atwrt NO-GAPS.
*              APPEND wa_head TO gt_mbpsv-chars.

*             End BCB08

            ENDIF.
          ENDIF.
        WHEN 'LINEAL_FOOTAGE'.
          IF NOT wa_head-atwrt IS INITIAL.
            CLEAR: lv_roll_feet,
                   lv_rollwidth.
            lv_roll_feet  = wa_head-atwrt.
            CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
              EXPORTING
                input                = lv_roll_feet
                unit_in              = 'LF'
                unit_out             = 'M'
              IMPORTING
                output               = lv_rollwidth
              EXCEPTIONS
                conversion_not_found = 1
                division_by_zero     = 2
                input_invalid        = 3
                output_invalid       = 4
                overflow             = 5
                type_invalid         = 6
                units_missing        = 7
                unit_in_not_found    = 8
                unit_out_not_found   = 9
                OTHERS               = 10.
            IF sy-subrc = 0.
              wa_head-atnam = 'LINEAR_FOOTAGE_METRIC'.
              wa_head-atwrt = lv_rollwidth.
              CONDENSE  wa_head-atwrt NO-GAPS.
              APPEND wa_head TO gt_mbpsv-chars.
              CLEAR wa_head.
            ENDIF.
          ENDIF.
      ENDCASE.
    ENDLOOP.
    MODIFY gt_mbpsv TRANSPORTING chars.
    CLEAR gt_mbpsv.
  ENDLOOP.

ENDFORM.                    " ADD_ADDITIONAL_BATCH_CHARS

*&---------------------------------------------------------------------*
*&      Form  GET_WEIGHT_OF_PALLET
*&---------------------------------------------------------------------*
*       get weight of pallet in lbs from MARM table
*----------------------------------------------------------------------*

FORM get_weight_of_pallet.
  DATA : lv_index LIKE sy-index,
* Internal table to check for duplicate batch or incorrect batch
* format.
         BEGIN OF lt_charg OCCURS 0,
           charg TYPE charg_d,
         END OF lt_charg.
  LOOP AT gt_idoc_data INTO gs_idoc_data
    WHERE   docnum  =  gs_idoc_ctrl-docnum
      AND   segnam  =  gc_e1edl24.


    gs_e1edl24    = gs_idoc_data-sdata.
    IF NOT gs_e1edl24-matnr IS INITIAL.
      READ TABLE gt_marm WITH KEY matnr =  gs_e1edl24-matnr.
      IF sy-subrc = 0.
      ELSE.
        SELECT SINGLE matnr meinh umrez umren
          INTO gt_marm
          FROM marm
          WHERE matnr = gs_e1edl24-matnr
          AND   meinh = 'PAL'.
        IF sy-subrc = 0.

          IF  ( gt_marm-umrez <> 0 OR  gt_marm-umren <> 0 ).
            gt_marm-umrez = gt_marm-umrez / gt_marm-umren.
          ENDIF.
          APPEND gt_marm.
          CLEAR gt_marm.
        ENDIF.
      ENDIF.
    ENDIF.
    IF gs_e1edl24-charg = ''.
* Error  Pallet ID is missing in the IDOC.
      PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZSD_DL'                 " message class
              '293'                    " err msg
              ' '                                           "msgv1
              ' '                                           "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              ' '                                          "routid
              gs_idoc_data-segnum                       "seg num
              ' '.                                      "seg field
      RETURN.

    ELSE.
      READ TABLE lt_charg WITH KEY charg = gs_e1edl24-charg.
      IF sy-subrc = 0.
* Error Pallet ID is duplicated within the IDOC.
        PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZSD_DL'                 " message class
              '294'                    " err msg
              ' '                                           "msgv1
              ' '                                           "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              ' '                                          "routid
              gs_idoc_data-segnum                          "seg num
              ' '.                                         "seg field
        RETURN.
      ELSE.
* Check Pallet ID format

        lt_charg-charg = gs_e1edl24-charg.
        APPEND  lt_charg.
        CLEAR lt_charg.
      ENDIF.

    ENDIF.
  ENDLOOP.

ENDFORM.                    " GET_WEIGHT_OF_PALLET


*&---------------------------------------------------------------------*
*&      Form  MOVE_WOP_TO_ALL_SEGMENTS
*&---------------------------------------------------------------------*
*       Move weight of pallets in lbs to relevant segments.
*----------------------------------------------------------------------*
FORM move_wop_to_all_segments .
  DATA : lv_index LIKE sy-index.

  CLEAR gs_idoc_data.
  LOOP AT gt_idoc_data INTO gs_idoc_data
                    WHERE segnam     = gc_e1edl24 OR "Deliv item
                          segnam     = gc_e1edl44.   "HU Item
    lv_index = sy-tabix.

    CASE gs_idoc_data-segnam.
*     Delivery item
      WHEN gc_e1edl24.
        MOVE gs_idoc_data-sdata TO gs_e1edl24.
        READ TABLE gt_marm WITH KEY matnr = gs_e1edl24-matnr.
        IF sy-subrc = 0.
          gs_e1edl24-lfimg = gt_marm-umrez.
          gs_e1edl24-ntgew = gt_marm-umrez.
          gs_e1edl24-brgew = gt_marm-umrez.
          MOVE gs_e1edl24 TO gs_idoc_data-sdata.
        ENDIF.
      WHEN gc_e1edl44.
        MOVE gs_idoc_data-sdata TO gs_e1edl44.
        READ TABLE gt_marm WITH KEY matnr = gs_e1edl44-matnr.
        IF sy-subrc = 0.
          gs_e1edl44-vemng = gt_marm-umrez.
          MOVE gs_e1edl44 TO gs_idoc_data-sdata.
        ENDIF.
    ENDCASE.
    MODIFY gt_idoc_data FROM gs_idoc_data INDEX lv_index.
  ENDLOOP.
ENDFORM.                    " MOVE_WOP_TO_ALL_SEGMENTS
*&---------------------------------------------------------------------*
*&      Form  GET_BATCH_FORMAT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM get_batch_format .
  SELECT * INTO TABLE gt_zdl_fields
            FROM zdl_fields
            WHERE category = 'E03261_BATCH'
            AND lowval = gs_idoc_ctrl-sndprn.
  IF gt_zdl_fields[] IS INITIAL.
  ENDIF.
ENDFORM.                    " GET_BATCH_FORMAT

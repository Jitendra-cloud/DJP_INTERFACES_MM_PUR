************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2006                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: Determine Means of Transport-   Create Date: 07/13/2006*
*               for MoT Shift changes                                  *
*                                                                      *
* Inventory code: U01249                                               *
*                                                                      *
* SAP Name    : ZDL_U01249_SC                   Version    : V2        *
*                                                                      *
* Programmer  : Sreekanth Devis                 Last Update:           *
*                                                                      *
*______________________________________________________________________*
* Description : This function module is used to get Shipping Condition *
*               for corresponding MTO Export or MTS(MoT).              *
*               Check to see tx_output-spec_stock field has an entry,  *
*               if it has an entry then the order relates to MTO export*
*               otherwise it would be an MTS order.                    *
*______________________________________________________________________*
* Includes          : LZDL_U01249TOP                                   *
*                     LZDL_U01249F01                                   *
*                                                                      *
*______________________________________________________________________*
* Logical Databases : none                                             *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: no                                               *
*   Transactions    : no                                               *
*   Forms           : no                                               *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs : Not Specified                                    *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   : On demand                                        *
*______________________________________________________________________*
* Application log object:    ZDL_INTERFACE                             *
* Application log subobject: ZMOT_SHIPCOND                             *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* ADHUMBA             07/24/2007        change to pull the Shipping    *
*                                       condition on an STO from the   *
*                                       Sales Order Line Item instead  *
*                                       of Sales Order header Item.    *
*______________________________________________________________________*
************************************************************************
FUNCTION zdl_u01249_sc.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  EXPORTING
*"     REFERENCE(EX_ZSHIP_COND) LIKE  VBAK-VSBED
*"  TABLES
*"      TX_INPUT STRUCTURE  CIFPUOROUT
*"      TX_OUTPUT STRUCTURE  CIFPUOROUT
*"      TX_EXTENSIONIN STRUCTURE  CIFBPAREX
*"      TX_MTO_SHIPCOND STRUCTURE  ZDL_MTO_SHIPCOND
*"  EXCEPTIONS
*"      NO_RECORDS_FOUND
*"----------------------------------------------------------------------
  CLEAR gv_message.

  READ TABLE tx_output INDEX 1.
  CHECK sy-subrc EQ 0.
*-- Open the Application Log
  PERFORM applog_open.
*-- Check to see if an entry in Special stock key field exists, if yes
*--the order relates to MTO Export otherwise it would be a MTS order.
  IF tx_output-spec_stock IS NOT INITIAL.
*-- Get the Shipping Condition for MTO
    PERFORM get_mto_shipping_condition TABLES tx_output
                                              tx_input
                                              tx_mto_shipcond.
  ELSE.
    READ TABLE tx_extensionin INTO gs_extensionin INDEX 1.
    IF sy-subrc EQ 0.
*-- Get the Shipping Condition for MTS
      PERFORM get_mts_shipping_condition USING gs_extensionin
                                         CHANGING ex_zship_cond.
    ENDIF.
  ENDIF.

  IF ex_zship_cond IS INITIAL AND tx_mto_shipcond[] IS INITIAL.
*-- Saves the contents of the application log to database
    PERFORM applog_close.
    RAISE no_records_found.
  ELSE.
*-- Saves the contents of the application log to database
    PERFORM applog_close.
  ENDIF.
ENDFUNCTION.

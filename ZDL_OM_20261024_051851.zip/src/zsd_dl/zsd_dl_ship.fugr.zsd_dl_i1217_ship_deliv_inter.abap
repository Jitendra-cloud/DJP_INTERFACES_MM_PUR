FUNCTION zsd_dl_i1217_ship_deliv_inter.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  IMPORTING
*"     REFERENCE(IDOC_CREATE) TYPE  C DEFAULT 'N'
*"  EXPORTING
*"     REFERENCE(T_COMM_CONTROL) LIKE  EDIDC STRUCTURE  EDIDC
*"  TABLES
*"      I_XVTTK STRUCTURE  VTTKVB
*"      I_YVTTK STRUCTURE  VTTKVB
*"      I_XVTTP STRUCTURE  VTTPVB
*"      I_YVTTP STRUCTURE  VTTPVB
*"      I_VTRLK STRUCTURE  VTRLK
*"      I_VTRLP STRUCTURE  VTRLP
*"      I_XVTTS STRUCTURE  VTTSVB
*"      I_YVTTS STRUCTURE  VTTSVB
*"      I_XVBPA STRUCTURE  VBPAVB
*"      I_XVTSP STRUCTURE  VTSPVB
*"      I_YVTSP STRUCTURE  VTSPVB
*"  EXCEPTIONS
*"      CONTROL_RECORD_MISSING
*"      DATA_RECORD_MISSING
*"      NO_REQUIRED_VALUES
*"      UNIDENTIFIABLE_IDOC_STRU
*"      EMPTY_FIELDS_IDENTIFIED
*"      OTHERS
*"----------------------------------------------------------------------
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**         COPYRIGHT (C) 2003 by INTERNATIONAL PAPER                  **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                      2003, 2005, 20nn                              **
**                   by INTERNATIONAL PAPER                           **
*______________________________________________________________________*
* Include Name: ZSD_DL_I1217_SHIP_DELIV_INTER         Date: 10/15/2003 *
* Programmer  : Sushila Chaudhary                                      *
*______________________________________________________________________*
* Description : This include is called when ever a shipment is created *
* or changed . Based on certain validation done, the shipment needs to *
* be sent down to MES via the idoc type ZSDSHP01.                      *
* table xttt shows all the changes  while the table yttt remains the   *
* same before the changes were done.                                   *
* cross ref : ship conditions,                                         *
*             delivery type                                            *
*             inco terms                                               *
* Change History :                                                     *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* 1.  04/07/2004  :  Carrier  changes should not be sent down to MES   *
* 2.  04/08/2004  :  send the so's instead of sto's CR: 1519           *
* 3.  04/08/2004  :  No shipments info should be sent to MES for the   *
*                     shipments that are created for the port.         *
* 4.  05/11/2004  : CR : 01955 Change the shipment/delivery interface  *
*                    to send number of units to OMEGA. TPR 02748.      *
* 5.  05/30/2004  : Booking number and Vessel name to be read from the *
*                    delivery first. If not present on the delivery,   *
*                    then read it from the orders.                     *
* 6.  09/02/2004  : ZDL_SHPMNT_REQFIELD application log sub object     *
* 7.  09/1/2004   : Idoc is getting created for ports as well . The    *
*                   entries are not present in the x ref table.  There-*
*                  for SAP looks at distribution model and picks up the*
*                    entries from the model                            *
* 8.  10/20/2004  : Changes done to incorporate multiple order types.  *
*                  Not to be dependent upon the constants being used   *
*                  in the program if the order type is anything but 'C'*
*                  'I', 'H' and 'E'. Then ZSP_value needs to be checked.
* 9a  03/02/2005  : Changes made to write to the application log. This *
*                 is done to look at the delete issue where the idocs  *
*                 are not getting created .                            *
* 9b  05/20/2005  : get delivery tolerance from material characteristic*
* 10. 06/24/2005  : put in code to stop IDoc when STO is for reject    *
*                  sales or for MRO product   - cramey                 *
*                 :change calculation of ship_num_of_units - macarte   *
* 10a 07/08/05    :re-apply break/fix in E0V since R03I transport      *
*                  overwrote the changes                               *
* R4  06/15/2005  : fix MATERIAL_UNIT_CONVERSION call for MTS rolls    *
* R4  07/21/2005  : CR : 3608 Adding over/under STO tolerances         *
* R4  09/21/2005  : CR 3694 Making changes as per the export density av*
*                   unit weight received from the trim order details   *
* R4  10/14/2005  : Changes when the mto sto had neither the trim nor
*                   NCP applied to it . Consider the SO vc in that case.
* Tony Harcrow        02/07/06          Read new ztables for export
*                                       info instead of VBAK.
* NPARCHU 04/28/2006 : Changes made to populate ship_num_of_units in   *
*                      segment Z1SDSHPDLI01 from APO in case of supply *
*                      driven material in IPG mills
* NPARCHU 06/14/2006 : Changes made to take care of VMI orders also
* SNAKKAL  07/11/2006: Changes made to get the Export MTS orders from  *
* MACARTE 11/21/2006   R7 CO69261 always set fractional unit of <1 to 1*
*                      <<MC001  must be manually repacked to EDV       *
* CRAMEY  04/20/2007   TPR 18224 - must call MATERIAL_UNIT_CONVERSION
*                      with BASE unit of Measure
* CRAMEY  08/12/2011 - due to move to SHPMNT05, this FM is no longer
*                      used - therefore the code is being commented out
*                      so it won't show up on where used lists.
*______________________________________________________________________*
*----------------------------------------------------------------------*
*  CLEAR g_subrc.
*
*  PERFORM initialize_parameters .
*  PERFORM get_logical_system.
*
** Begin of change / NPARCHU / 04/28/2006
** get all the data from table ZDL_SUPPLY_DRIVN against one select
*  PERFORM get_data_ipgmills .
** End of Change / NPARCHU / 04/28/2006
*
************************************************************************
**
**// documentation :   Do not use "exit" in this user exit as this gets
**/  called at the time of  shipment create and an exit statemnt here
*wil
**/  give an error during shipment create.
** if g_subrc <> 0 .
**   exit.
** endif.
************************************************************************
**
*
****cramey**************************************************************
** added 06/24/2005 - check to bypass STOs for MRO materials
** MRO material type for IDocs to Apriso is in table ZMAPRMATYP
** if all the materials on this STO are of an MRO material type - do not
** create an IDoc for Omega
** if any material on the STO is for a non-MRO material - create IDOC
************************************************************************
*  DATA: w_tabix LIKE sy-tabix.
*  DATA: lt_zmaprmatyp LIKE zmaprmatyp OCCURS 5 WITH HEADER LINE,
*         non_mro_mtrl_found(1).
*  CLEAR non_mro_mtrl_found.
************************************************************************
** added 04/22/2005 - Check to bypass STOs for selected materials
** based on materials listed in table ZSD_DL_NO_STO
** If any of the materials on this STO are in the table - do not
** create an IDoc for MES
************************************************************************
*  DATA: lt_zsd_dl_no_sto LIKE zsd_dl_no_sto OCCURS 0 WITH HEADER LINE,
*        no_sto_flag(1).
*  CLEAR no_sto_flag.
*
*  REFRESH lt_zmaprmatyp.
*  REFRESH lt_zsd_dl_no_sto.
*
** get list of MRO matrls and list of materials to exclude
*  SELECT * FROM zmaprmatyp INTO TABLE lt_zmaprmatyp.
*  SORT lt_zmaprmatyp BY mtart.
*  SELECT * FROM zsd_dl_no_sto INTO TABLE lt_zsd_dl_no_sto.
*
** read line items for exclusions -
** if any non-MRO material is found - send IDOC
** if any exclusion material is found - do not send IDOC
*
*
*  LOOP AT i_vtrlp.
** Begin of change / nparchu/ 04/28/2006
************************************************************************
**
** Check whether there are entries in the table ZDL_SUPPLY_DRIVN
** gv_get_apo = 'X' . check if single entry in internal table i_vtrlp
** is available in the table gt_supply_drivn . If available check the
** flag gv_read_apo = 'x' so other entries are not checked .
************************************************************************
**
*
*    IF  gv_read_apo IS  INITIAL .
*      READ TABLE gt_supply_drivn
*           WITH KEY locno = i_vtrlp-werks
*                    matkl = i_vtrlp-matkl
*                    BINARY SEARCH .
*      IF sy-subrc = 0 .
*        gv_read_apo = 'X'.
*      ENDIF.
*    ENDIF.
** end of  change / nparchu /04/28/2006
*    READ TABLE lt_zmaprmatyp
*            WITH KEY mtart = i_vtrlp-mtart BINARY SEARCH.
*    IF sy-subrc > 0.
*      non_mro_mtrl_found = 'X'.
*    ENDIF.
*    READ TABLE lt_zsd_dl_no_sto INTO lt_zsd_dl_no_sto
*      WITH KEY matnr = i_vtrlp-matnr
*        werks = i_vtrlp-werks
*        BINARY SEARCH.
*    IF sy-subrc = 0.
*      no_sto_flag = 'X'.
*    ELSE.
*      READ TABLE lt_zsd_dl_no_sto
*        WITH KEY matnr = i_vtrlp-matnr
*          BINARY SEARCH.
*      IF sy-subrc = 0.
*        no_sto_flag = 'X'.
*      ENDIF.
*    ENDIF.
*  ENDLOOP.
*  CHECK non_mro_mtrl_found = 'X'.
*  CHECK no_sto_flag IS INITIAL.
** end add 06/24/2005
****cramey**************************************************************
*
**** Create IDoc
*  PERFORM read_shipment_no.
*
*  PERFORM  count_delivery_line_items.
*
*  PERFORM check_update_indicator .
*
**// do not create the idoc if there is no  update indicator sent to MES
*.
*  IF ( idoc_z1sdshpmnt02-ship_update_ind <> space )  OR
*     ( idoc_create = c_yes ) .
*    idoc_z1sdshpmnt02-ship_shipment_id       = tknum.
*    idoc_z1sdshpmnt02-ship_type              = i_xvttk-shtyp.
*    idoc_z1sdshpmnt02-ship_changed_by        = i_xvttk-aenam.
*    idoc_z1sdshpmnt02-ship_changed_on        = i_xvttk-aedat.
*    idoc_z1sdshpmnt02-ship_changed_time      = i_xvttk-aezet.
*    idoc_z1sdshpmnt02-ship_route             = i_xvttk-route.
*
*
**//  RFC call only  if  the idoc is to be created
*
** Begin of change / nparchu / 05/01/2006
************************************************************************
**
** check for the flag gv_read_apo = 'X'
************************************************************************
*    CLEAR gv_fail_idoc.
*    IF gv_read_apo = 'X' .
************************************************************************
**
**get the rfc destination for the APO side . In case of error raise the
** flag gv_fail_idoc = 'X'
************************************************************************
*      CALL FUNCTION 'Z_MM_GET_APO_RFCDES'
*        IMPORTING
*          rfcdes_name         = lrfcdes_name
*        EXCEPTIONS
*          process_error       = 1
*          invalid_destination = 2
*          not_found           = 3
*          OTHERS              = 4.
*      IF sy-subrc <> 0 .
*        gv_fail_idoc = 'X' .
*        MESSAGE e000(zsp_gen) WITH
*                'No  RFC destination exists'(m09)
*                INTO g_dummy.
*        PERFORM handle_message.
*      ELSE .
*        dest = lrfcdes_name-rfcdest .
*        gs_shipment-shipment = tknum .
*        APPEND gs_shipment TO gt_shipment_no.
*
************************************************************************
**
**Read the function module ZDL_I01217_GUIDANCE_READ to get the no of
** rolls from the guidance data . In case of error catch the error in
*the
** application log and raise the flag gv_fail_idoc
************************************************************************
**
*
*        CALL FUNCTION 'ZDL_I01217_GUIDANCE_READ'
*          DESTINATION dest
*          EXPORTING
*            it_shipment_no        = gt_shipment_no[]
*          TABLES
*            it_delivery_roll      = gt_delivery_roll
*          EXCEPTIONS
*            no_records_found      = 1
*            communication_failure = 2  MESSAGE gmsg_text
*            system_failure        = 3  MESSAGE gmsg_text.
*        IF sy-subrc <> 0 .
*          gv_fail_idoc = 'X' .
*          IF sy-subrc = 1 .
*            MESSAGE e002(zsp_gen) WITH
*                    'Shipment Number'(m02)
*                     tknum
*        'Guidance Record not found for Shipment'(m10)
*         INTO g_dummy.
*            PERFORM handle_message.
*          ELSE.
*            MESSAGE e003(zsp_gen) WITH
*                    'Shipment Number'(m02)
*                     tknum
*                    gmsg_text
*                    INTO g_dummy.
*            PERFORM handle_message.
*          ENDIF.
*        ELSE .
*          SORT gt_delivery_roll BY delivery  delivery_item .
*        ENDIF.
*      ENDIF.
*    ENDIF.
*
** End of change / nparchu / 05/01/2006
*
**// route description
*    PERFORM get_route_description.
*
**// shipment weight .
*    PERFORM ship_allowed_wt.
*
**// ship conditions and the description
*    PERFORM ship_conditions.
*
**// scacd values
*    PERFORM get_ship_scacd_code.
*
*    t_idoc_data-segnam = c_shp_hdr .                    "'Z1SDSHPMNT02'
*    t_idoc_data-hlevel = c_hlevel_1 .
*    t_idoc_data-sdata   = idoc_z1sdshpmnt02.
*    APPEND t_idoc_data.
*
**// second shipment idoc record
*    PERFORM move_itab_data .
*
*    SORT temp_vtsp BY tsnum DESCENDING .
*    READ TABLE temp_vtsp INDEX 1.
*
*    DATA : g_tsnum LIKE vtts-tsnum.
** Data declaration for Export MTS orders
*    DATA: zsto_flag(1) TYPE c,
*          w_zzvbeln LIKE ekko-zzvbeln,
*          w_zzposnr LIKE ekko-zzposnr.
**// new logic for the deliveries on a stage .
**/ vtts table shows the shipping points In near future we might have to
**/ create multiple idoc's for multiple ship points.
*
*    LOOP AT i_xvtts .
*
*      IF NOT i_xvtts-kunnz IS INITIAL.
*        g_tsnum = i_xvtts-tsnum + 1 .
*
*        LOOP AT i_xvtsp WHERE tknum = i_xvtts-tknum
*                        AND   tsnum = i_xvtts-tsnum.
*
*          READ TABLE t_vtsp WITH KEY tknum = i_xvtts-tknum
*                                     tsnum = g_tsnum
*                                     tpnum = i_xvtsp-tpnum.
*          CHECK NOT sy-subrc IS INITIAL.
*
*          READ TABLE i_xvttp WITH KEY tknum = i_xvtts-tknum
*                                      tpnum = i_xvtsp-tpnum.
*          IF sy-subrc IS INITIAL.
*            idoc_z1sdshpdlh01-ship_stop_off_seq = i_xvtsp-tsnum.
**********************************************************************
**// always subtract 1 from the stop off's as this was the request by
**/  MES team : Lynn so that they can print there BOL properly.
**/  Looks like the other systems also work the same way .
***********************************************************************
*            IF temp_vtsp-tsnum <= 1 .
*              idoc_z1sdshpdlh01-ship_stop_off_seq =
*                       idoc_z1sdshpdlh01-ship_stop_off_seq - 1.
*            ENDIF.
*
*            idoc_z1sdshpdlh01-ship_delivery_no  = i_xvttp-vbeln.
*            idoc_z1sdshpdlh01-ship_to_location  = i_xvtts-kunnz.
*
*            PERFORM get_address_details.
*
**//  we check on the shipment stage ship point and not the TPS point.
**/  This method was adopted to enable multi stage shipments where the
**/ ship points could be different.
*            IF NOT i_xvtts-vstel IS INITIAL.
*              idoc_z1sdshpdlh01-ship_point = i_xvtts-vstel.
*              IF go_log IS NOT INITIAL.
*                MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)
*                tknum 'Ship Point' idoc_z1sdshpdlh01-ship_point INTO
*                g_dummy.
*                PERFORM handle_message.
*              ENDIF.
*            ELSEIF i_xvtts-vstel IS INITIAL AND NOT
*                    idoc_z1sdshpdlh01-ship_point IS INITIAL.
*            ELSE .
*              MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)
*              tknum
*              'No ship point found for idoc routing'(m03) INTO g_dummy.
*              PERFORM handle_message.
*            ENDIF.
*
*            datavalue = idoc_z1sdshpdlh01-ship_point  .
*
**// if the ship point is found and also the partner profile. build the
**/  partner table for the same.
*            PERFORM get_ale_partner_details.
*            IF t_master_idoc_control-rcvprn IS INITIAL .
*              CLEAR idoc_z1sdshpdlh01.
*              CONTINUE.
*            ELSE.
*              CLEAR  t_ship_points.
*              t_ship_points-vstel = idoc_z1sdshpdlh01-ship_point .
*              t_ship_points-rcvprn = t_master_idoc_control-rcvprn.
*              APPEND  t_ship_points .
*            ENDIF.
*
**// find out the system that is used in the present plant/mill.
**// to check for the cross ref.
*            SELECT SINGLE  zzvalue1 INTO v_millsystem
*                        FROM zzxrefdetail
*                        WHERE zzgroup = c_deliver
*                        AND   zzgroupset = c_millmes
*                        AND   zzkey1     = idoc_z1sdshpdlh01-ship_point
*.
*            IF sy-subrc <> 0 .
*              CLEAR v_millsystem.
** create an ahd ticket to inform that the mill system is not found
*              MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)
*              tknum
*            'Mill system not found in the xref table'(m05) INTO g_dummy
*.
*              PERFORM handle_message.
*            ENDIF.
*
*            READ TABLE i_vtrlk WITH KEY vbeln = i_xvttp-vbeln .
*            IF sy-subrc = 0 .
*
**// added the load date and time per change request  1207.   11/17/2003
**/  removed the  goods movement date
*              idoc_z1sdshpdlh01-ship_load_date = i_vtrlk-lddat.
*              idoc_z1sdshpdlh01-ship_load_time = i_vtrlk-lduhr.
*              idoc_z1sdshpdlh01-ship_del_date = i_vtrlk-lfdat.
*              idoc_z1sdshpdlh01-ship_del_priority = i_vtrlk-lprio.
*              idoc_z1sdshpdlh01-ship_inco1        = i_vtrlk-inco1.
*              idoc_z1sdshpdlh01-ship_inco2        = i_vtrlk-inco2.
*            ENDIF.
** incoterms need to be cross referenced per change request
*            IF NOT idoc_z1sdshpdlh01-ship_inco1 IS INITIAL OR
*                   v_millsystem IS INITIAL.
*              tem_key1 = idoc_z1sdshpdlh01-ship_inco1  .
*
*              PERFORM get_cross_ref_values TABLES t_result2
*                                                  t_result1
*                                                  itab_return
*                                           USING  c_deliver
*                                                 'INCOTERMS'
*                                                 tem_key1
*                                                 v_millsystem.
*              IF itab_return-type <> 'E' .
*                idoc_z1sdshpdlh01-ship_inco1 = t_result1-zzvalue1.
*              ENDIF.
*
*            ENDIF.
*
**// added the booking number and the vessel name per change request
**/ 01456  on 12/30/2003
*            CLEAR w_tabix.
*            READ TABLE i_vtrlp WITH KEY vbeln = i_vtrlk-vbeln.
*            w_tabix = sy-tabix.
*
** Change History # 5 .
*            IF sy-subrc = 0 .
*              SELECT SINGLE  zzbooknum zzveslname
*                    INTO (likp-zzbooknum, likp-zzveslname)
*                           FROM likp  WHERE  vbeln = i_vtrlk-vbeln.
*              IF sy-subrc = 0 .
*                idoc_z1sdshpdlh01-booking_number   = likp-zzbooknum.
*                idoc_z1sdshpdlh01-vessel_name      = likp-zzveslname.
*              ENDIF.
*
************************************************************************
**
**/ VGTYP Identifies the category for reference document
**/ when LIPS-VBELV is blank, it means that   LIPS-VBGEL contains the
**/ STO #  and it is a MTS order.
**/ when LIPS-VBELV is not blank, then check for LIPS-VGTYP and identify
**/ if it is a  MTO sto or a  MTS or a MTO .
**/
**/  EKKN table demonstrates the following values
**/  EBELN    EBELP                        VBELN  VBELP
**/  00008    00001                       000040  0001
**/  ( STO )                              ( Sales Order )
**/  LIPS Table demonstrates the following values for MTO STO .
**/  VBELN    POSNR                VBELV  POSNV     VGBEL  VGPOS   VGTYP
**/ 8000032   00010                00040  0001     0008   0001      V
**/ (Del for STO)       ( This is SO sent to OMEGA )  ( This is MTO STO
*)
**/
**/   LIPS Table demonstrates the following values for MTO (Normal SO )
**/  VBELN    POSNR                VBELV  POSNV     VGBEL  VGPOS  VGTYP
**/ 80001026  00010                                 311    1      C
**/   LIPS Table demonstrates the following values for SO which an STO
**/  VBELN    POSNR                VBELV  POSNV     VGBEL  VGPOS  VGTYP
**/ 800008286  00010               830     0001     839    0001   C
**/ Delivery for SO                Sales order       Sales Order
**/   LIPS Table demonstrates the following values for a MTS
**/  VBELN    POSNR                VBELV  POSNV     VGBEL  VGPOS  VGTYP
**/ 80001811  00010                       000000    2000932  00001  V
************************************************************************
**
*
**// check the sales document category.
*              CASE  i_vtrlp-vgtyp .
*                WHEN c_sto_order.                                "V"
*                  IF i_vtrlp-vbelv  EQ space.
*                    CLEAR: zsto_flag,
*                           w_zzvbeln,
*                           w_zzposnr.
** Get the sales document and item aginst the export MTS order when
** vtrlp-vbelv is initial.
*                    SELECT SINGLE zzvbeln zzposnr FROM ekko
*                           INTO (w_zzvbeln,w_zzposnr)
*                           WHERE ebeln = i_vtrlp-vgbel .
*
*                    IF ( ( w_zzvbeln IS NOT INITIAL ) AND
*                         ( w_zzposnr IS NOT INITIAL ) ).
*
*                      zsto_flag = 'X'.
*                      i_vtrlp-vbelv = w_zzvbeln.
*                      i_vtrlp-posnv = w_zzposnr.
*                      MODIFY i_vtrlp INDEX w_tabix.
*                    ENDIF.
*                  ENDIF.
*                  IF NOT ( i_vtrlp-vbelv EQ space ) .
** this is for a MTO sto situation.
*                    SELECT SINGLE auart vtweg
*                            INTO (vbak-auart, vbak-vtweg)
*                            FROM vbak  WHERE  vbeln = i_vtrlp-vbelv.
*                    IF sy-subrc = 0 .
** set the flag f_mto_sto as it will be used later to find out trim av
** weight and calculate the ship # of rolls.
*                      f_mto_sto = 'X' .
*
*                      idoc_z1sdshpdlh01-ship_delivery_type = vbak-auart
*.
*
*                    ENDIF.
*                    IF zsto_flag = 'X'.
*                      CLEAR f_mto_sto.
*                    ENDIF.
*                    SELECT SINGLE bookdoc INTO (zsd_book_itm-bookdoc)
*                      FROM zsd_book_itm WHERE vbeln = i_vtrlp-vbelv
*                                          AND posnr = i_vtrlp-posnv.
*                    IF sy-subrc = 0.
*                      SELECT SINGLE booknum veslname INTO
*                        (zsd_book_hdr-booknum, zsd_book_hdr-veslname)
*                        FROM zsd_book_hdr
*                        WHERE bookdoc = zsd_book_itm-bookdoc.
*                      IF sy-subrc = 0.
*                        IF  idoc_z1sdshpdlh01-booking_number IS INITIAL
*.
*                          idoc_z1sdshpdlh01-booking_number =
*                          zsd_book_hdr-booknum.
*                        ENDIF.
*                        IF  idoc_z1sdshpdlh01-vessel_name IS INITIAL.
*                          idoc_z1sdshpdlh01-vessel_name   =
*                          zsd_book_hdr-veslname.
*                        ENDIF.
*                      ENDIF.
*                    ENDIF.
*                  ELSE .
**// changes for the MTS STO . Changed by SCHAUDH on 02/11/2005 .
*                    SELECT SINGLE bsart INTO ekko-bsart FROM ekko
*                                     WHERE ebeln = i_vtrlp-vgbel.
*                    IF sy-subrc = 0 .
*                      idoc_z1sdshpdlh01-ship_delivery_type = ekko-bsart
*.
*                      f_mts_sto = 'X' .
*                    ENDIF.
*                  ENDIF.
*
*                WHEN OTHERS.
*                  SELECT SINGLE auart vtweg
*                     INTO (vbak-auart, vbak-vtweg)
*                           FROM vbak  WHERE  vbeln = i_vtrlp-vgbel.
*                  IF sy-subrc = 0 .
*
*                    idoc_z1sdshpdlh01-ship_delivery_type  = vbak-auart.
*                  ENDIF.
*                  SELECT SINGLE bookdoc INTO (zsd_book_itm-bookdoc)
*                      FROM zsd_book_itm WHERE vbeln = i_vtrlp-vbelv
*                                          AND posnr = i_vtrlp-posnr.
*                  IF sy-subrc = 0.
*                    SELECT SINGLE booknum veslname INTO
*                      (zsd_book_hdr-booknum, zsd_book_hdr-veslname)
*                      FROM zsd_book_hdr
*                      WHERE bookdoc = zsd_book_itm-bookdoc.
*                    IF sy-subrc = 0.
*                      IF  idoc_z1sdshpdlh01-booking_number IS INITIAL.
*                        idoc_z1sdshpdlh01-booking_number =
*                        zsd_book_hdr-booknum.
*                      ENDIF.
*                      IF  idoc_z1sdshpdlh01-vessel_name IS INITIAL.
*                        idoc_z1sdshpdlh01-vessel_name   =
*                        zsd_book_hdr-veslname.
*                      ENDIF.
*                    ENDIF.
*                  ENDIF.
*              ENDCASE.
*            ENDIF.
************************************************************************
**
**// These changes are for the consignment orders.  ZKB order type can
*be
**/  used for both domestic and export orders. Therefore to identify if
**/  it is a export consignment or domestic consignment, we also check
**/  the distribution channel else cross referencing the order type.
************************************************************************
**
*            IF vbak-auart = 'ZKB' AND vbak-vtweg = '10'.
*              idoc_z1sdshpdlh01-ship_type_shipment = 'D' .
*            ELSEIF vbak-auart = 'ZKB' AND vbak-vtweg = '20'.
*              idoc_z1sdshpdlh01-ship_type_shipment = 'E'.
*            ELSE.
*              tem_key1 = idoc_z1sdshpdlh01-ship_delivery_type .
*              PERFORM get_cross_ref_values TABLES t_result2
*                                                  t_result1
*                                                  itab_return
*                                           USING c_group
*                                                 'MESDELTYPE'
*                                                 tem_key1
*                                                 v_millsystem.
*              IF itab_return-type IS INITIAL .
*                idoc_z1sdshpdlh01-ship_type_shipment =
*                t_result1-zzvalue1.
*              ENDIF.
*            ENDIF.
*            t_idoc_data-segnam = 'Z1SDSHPDLH01' .
*            t_idoc_data-hlevel = c_hlevel_2.
*            t_idoc_data-sdata   = idoc_z1sdshpdlh01.
*            APPEND t_idoc_data.
*
** 3rd shipment idoc record
** read i_vtrlp for the item level details
*            LOOP AT i_vtrlp WHERE vbeln = i_xvttp-vbeln .
*
*              IF i_vtrlp-posnr(1) = c_posnr_9.
*                CONTINUE.
*              ENDIF.
*
*              IF NOT ( i_vtrlp-vbelv EQ space ) .
**//  This could be the SO for an MTO STO or a  MTO Sales Order.
*                idoc_z1sdshpdli01-ship_so_number      = i_vtrlp-vbelv.
*                idoc_z1sdshpdli01-ship_so_line_number = i_vtrlp-posnv.
*
*              ELSE.
*                idoc_z1sdshpdli01-ship_so_number      = i_vtrlp-vgbel.
*                idoc_z1sdshpdli01-ship_so_line_number = i_vtrlp-vgpos.
*
*              ENDIF.
*
*              idoc_z1sdshpdli01-ship_del_item       = i_vtrlp-posnr.
*              idoc_z1sdshpdli01-ship_del_qty        = i_vtrlp-lfimg.
*              idoc_z1sdshpdli01-ship_del_qty_uom    = i_vtrlp-vrkme.
*              idoc_z1sdshpdli01-ship_gross_wt       = i_vtrlp-brgew.
*              idoc_z1sdshpdli01-ship_net_wt         = i_vtrlp-ntgew.
*              idoc_z1sdshpdli01-ship_unit_wt        = i_vtrlp-gewei.
*
************************************************************************
**
**// changes done on 02/04/2004, MES always wants to see the delivery
*qty
**/  in either pounds(lb) or linear feet ( lf) and there fore this conv.
**/  needs to be done.
**/ this would work only for pounds c'oz SAP always stores the materials
**/ in the base unit of measure as pounds.
**// changes for the calculation of the sales number of units.
**/  This logic might not work for replineshment  deliveries
************************************************************************
**
*              CLEAR : cuobj ,
*                      vrkme ,
*                      conf_out[] .
*
*              SELECT SINGLE cuobj vrkme INTO (vbap-cuobj,vbap-vrkme)
*                   FROM vbap
*                   WHERE  vbeln = idoc_z1sdshpdli01-ship_so_number
*                   AND    posnr = idoc_z1sdshpdli01-ship_so_line_number
*.
*              IF sy-subrc = 0 .
*                cuobj = vbap-cuobj.
*                vrkme = vbap-vrkme.
*                idoc_z1sdshpdli01-ship_del_qty_uom    =  vrkme.
*                IF f_mto_sto = 'X' .
**// get the average trim unit weight to find out # of rolls .
*                  PERFORM extract_trim_details USING
*                                  idoc_z1sdshpdli01-ship_so_number
*                                  idoc_z1sdshpdli01-ship_so_line_number
*.
*                ELSE .
** Begin of change / NPARCHU / 06/14/2006
*                  IF gv_read_apo  IS NOT INITIAL .
*                    PERFORM read_apo .
*                  ELSE.
** End of change / NPARCHU / 06/14/2006
*                    PERFORM shipment_no_of_units.
** Begin of change / NPARCHU / 06/14/2006
*                  ENDIF.
** End of change / NPARCHU / 06/14/2006
*                ENDIF.
*              ELSE .
** // this is a  MTS scenario .
*                vrkme = i_vtrlp-vrkme .
** begin of change / nparchu / 05/02/2006
************************************************************************
**
** Check that data is to be read from apo . read the werks and matkl
*from
** table gt_supply_drivin . if available check whether the there is
*entry
** available for the delivery and posnr against the table
* gt_delivery_rol
** if available populate the idoc segment else raise flag gv_fail_idoc
** with application error
************************************************************************
**
*                IF gv_read_apo  IS NOT INITIAL .
** Begin of changes / nparchu / 06/14/2006
***********************************************************************
** The existing code has been moved into the form and removed from here
***********************************************************************
*                  PERFORM read_apo .
** End of changes / nparchu / 06/14/2006
*                ELSE.                  " if gv_get_apo  is not initial
*                  " no need for above logic
** end of change / nparchu / 05/02/2006
*                  PERFORM get_mts_relevant_fields.
*                ENDIF.
*              ENDIF.
*
*              CONDENSE : idoc_z1sdshpdli01-ship_del_qty ,
*                         idoc_z1sdshpdli01-ship_num_of_units,
*                         idoc_z1sdshpdli01-ship_gross_wt,
*                         idoc_z1sdshpdli01-ship_net_wt,
*                         idoc_z1sdshpdli01-ship_unit_wt .
*
*              PERFORM get_del_min_and_max.
*              PERFORM format_sales_order.
*
** 11/2006 CO69261 break/fix to always set fractional unit
**                of <1 to 1.
**      This is done after any min/max calculations
*              IF idoc_z1sdshpdli01-ship_num_of_units < 1    "MC001
*                     AND  idoc_z1sdshpdli01-ship_net_wt > 0."MC001
*                idoc_z1sdshpdli01-ship_num_of_units = 1.    "MC001
*                CONDENSE idoc_z1sdshpdli01-ship_num_of_units"MC001
*                         NO-GAPS.                           "MC001
*              ENDIF.                                        "MC001
*
*              t_idoc_data-segnam = 'Z1SDSHPDLI01' .
*              t_idoc_data-psgnum = c_hlevel_2.
*              t_idoc_data-hlevel = c_hlevel_3.
*              t_idoc_data-sdata   = idoc_z1sdshpdli01.
*              APPEND t_idoc_data.
*              CLEAR idoc_z1sdshpdli01.
*            ENDLOOP.
*          ENDIF.                              " READ I_XVTTP
*        ENDLOOP.                              "  LOOP AT I_XVTSP
*      ELSE .
*        MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)  tknum
*       'Error : VTTS-KUNNZ field is blank no record found for stage'
*        i_xvtts-tsnum INTO g_dummy.
*        PERFORM handle_message.
*      ENDIF.
*    ENDLOOP.                                    " LOOP AT I_XVTTS .
*
** change the ship conditions for the xref value here .
*    LOOP AT t_idoc_data.
*      w_data = t_idoc_data.
*      CASE t_idoc_data-segnam.
*        WHEN 'Z1SDSHPMNT02'.
*          idoc_z1sdshpmnt02 = w_data-sdata.
*
*          IF NOT idoc_z1sdshpmnt02-ship_conditions IS INITIAL.
*            CLEAR : t_result1[] ,
*                    itab_return[],
*                    t_result2[] .
*
*            tem_key1 = idoc_z1sdshpmnt02-ship_conditions .
*
********************************************************************
**// cross referencing for shipment type to ship mode.
**/ if there is more than one field on which the cross ref req is built,
**/ leave the key1 and most current field as blank and use the t_result2
**/ table to read the values.
*********************************************************************
*            CALL FUNCTION 'ZZ_EXTRACT_XREF_DATA'
*              EXPORTING
*                group    = c_group                   "'DELIVER'
*                groupset = 'MESSHIPTYPE'
*                key1     = tem_key1               " SHIP CONDITIONS.
*                key2     = v_millsystem
*              IMPORTING
*                result1  = t_result1
*                return   = itab_return
*              TABLES
*                result2  = t_result2.
*            IF itab_return-type IS INITIAL .
*              idoc_z1sdshpmnt02-ship_mode = t_result1-zzvalue1.
*              w_data-sdata = idoc_z1sdshpmnt02 .
*              MODIFY t_idoc_data FROM w_data.
*            ENDIF.
*          ENDIF.
*      ENDCASE.
*    ENDLOOP.
*
*    SORT t_ship_points BY vstel rcvprn .
*    DELETE ADJACENT DUPLICATES FROM t_ship_points COMPARING
*                                                      vstel rcvprn .
*    IF t_ship_points[] IS INITIAL .
*      MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)  tknum
*      'Shipping point not found for idoc routing'(m06) INTO g_dummy.
*      PERFORM handle_message.
*    ELSE.
*      LOOP AT  t_ship_points.
*        PERFORM create_ship_idoc.
*      ENDLOOP.
*    ENDIF.
*
**// delete the entires in these tables for delete, else there will
**/ be a short dump.
*    IF i_yvttk-updkz = c_delete.
*      CLEAR :  i_xvtts[] ,
*               i_xvtsp[] ,
*               i_xvttp[] .
*
** begin of change / nparchu / 05/02/2006
********************************************************************
**  The closing of the application log has been moved outside the
**  if i_yvttk-updkz = c_delete condition , so that it handles all
**  other messages
********************************************************************
** end of change / nparchu / 05/02/2006
*    ENDIF.
*
*  ENDIF.
** begin of change / nparchu / 05/02/2006
**//   Close the application log if it exists
*  IF go_log IS NOT INITIAL.
*    TRY.
*        go_log->log_save( ).
*      CATCH zcx_ca_applog_log_not_found .
*      CATCH zcx_ca_applog .
*    ENDTRY.
*  ENDIF.
** end of change / nparchu / 05/02/2006
** end of schaudh 10/14/2003
ENDFUNCTION.
*
**----------------------------------------------------------------------
*&
**   perform get_logical_system.
** Doc : details about the own logical system for IDOC control record.
**----------------------------------------------------------------------
*&
*FORM get_logical_system.
*
** Changes 08/03/2004
*  CONCATENATE sy-sysid
*              c_client
*              sy-mandt INTO h_logsys.
*
*  t_master_idoc_control-sndprt = c_logical_system .
*  t_master_idoc_control-sndprn = h_logsys.
*  t_master_idoc_control-direct = c_out_direct.
*  t_master_idoc_control-mestyp = c_message_type.
*  t_master_idoc_control-idoctp = c_idoc_type.
*
*ENDFORM.                    "get_logical_system
*
**----------------------------------------------------------------------
*&
**   perform  get_cross_ref_values.
**----------------------------------------------------------------------
**
*FORM get_cross_ref_values
*  TABLES result2 STRUCTURE zzxrefdetail
*         result1 STRUCTURE zzxrefdetail
*         return  STRUCTURE bapiret2
*  USING group
*        groupset
*        tem_key1
*        v_millsystem.
*
*  CLEAR : t_result1[] ,
*          return[],
*          t_result2[] .
*
*
*  CALL FUNCTION 'ZZ_EXTRACT_XREF_DATA'
*    EXPORTING
*      group    = group
*      groupset = groupset
*      key1     = tem_key1
*      key2     = v_millsystem
*    IMPORTING
*      result1  = result1
*      return   = return
*    TABLES
*      result2  = result2.
*
*ENDFORM.                    "get_cross_ref_values
*
**----------------------------------------------------------------------
**
**    perform count_delivery_line_items.
**----------------------------------------------------------------------
**
*FORM count_delivery_line_items.
*
**// count the number of deliveries line item excluding batch line item.
**/  Do not count the batch records on the deliveries.
*  CLEAR idoc_z1sdshpmnt02.
*  t_vtrlp[] = i_vtrlp[].
*  DELETE t_vtrlp WHERE posnr(1) = c_posnr_9.
*  DESCRIBE TABLE t_vtrlp LINES sy-tfill.
*  IF sy-tfill <> 0 .
*    v_numc3 = sy-tfill .
*    idoc_z1sdshpmnt02-ship_count_delv_item = v_numc3.
*  ENDIF.
*
*ENDFORM .                    "count_delivery_line_items
*
**----------------------------------------------------------------------
**
**   perform check_update_indicator.
**// check for the insert / update / delete
**/ insert and upd flag is updated for the i_xvttk
**/ delete flag is updated for the i_yvttk only
**----------------------------------------------------------------------
**
*FORM check_update_indicator.
*
*  DATA : lv_tabkey LIKE cdpos-tabkey .
*
*  CLEAR idoc_z1sdshpmnt02-ship_update_ind .
*  IF i_xvttk-updkz = c_insert.
*    IF i_xvttk-stdis =  c_checked.                   " planned status
*      idoc_z1sdshpmnt02-ship_update_ind = c_insert.
*    ENDIF.
*
*  ELSEIF i_xvttk-updkz = c_update.
**changed from unplanned to planned status
*    IF i_xvttk-stdis =  c_checked AND i_yvttk-stdis = c_unchecked
*     AND  NOT (  i_xvttk-stlbg = c_checked OR i_xvttk-stlad = c_checked
*           OR  i_xvttk-sttbg = c_checked OR i_xvttk-stabf = c_checked )
*.
** begin of change / nparchu / 05/03/2006
************************************************************************
**
** Check whether the shipment has been planned and unplanned before
************************************************************************
**
*      CLEAR lv_tabkey .
*      CONCATENATE sy-mandt tknum INTO lv_tabkey .
*      SELECT SINGLE * FROM cdpos INTO  cdpos
*                                 WHERE objectclas = c_objectclas AND
*                                       objectid   = tknum        AND
*                                       tabname    = c_tabname    AND
*                                       tabkey     = lv_tabkey    AND
*                                       fname      = c_fname      AND
*                                ( value_new <> ' ' OR value_old <> ' ')
*.
*      .
*      IF sy-subrc = 0 .
*        idoc_z1sdshpmnt02-ship_update_ind = c_update.
*      ELSE .
** end of change / nparchu /  05/03/2006
*        idoc_z1sdshpmnt02-ship_update_ind = c_insert.
** begin of change / nparchu / 05/03/2006
*      ENDIF.
** end of change / nparchu /  05/03/2006
*    ENDIF.
*
** changes as per change request 1798 . Do not send a delete on unplan
** changed from planned to unplanned
**    if i_xvttk-stdis =  c_unchecked and i_yvttk-stdis = c_checked.
**      idoc_z1sdshpmnt02-ship_update_ind = c_delete.
**    endif.
*
*  ENDIF.
*
*  IF i_yvttk-updkz = c_delete.
*    idoc_z1sdshpmnt02-ship_update_ind = c_delete.
*
*    MESSAGE s000(zsd_dl) WITH 'Shipment Number to be deleted:'(m01)
*                               tknum  INTO g_dummy.
*    PERFORM handle_message.
*  ENDIF.
*
*ENDFORM .                    "check_update_indicator
*
**----------------------------------------------------------------------
**
** peform get_route_description.
**----------------------------------------------------------------------
**
*FORM get_route_description.
*
*  SELECT SINGLE bezei INTO tvrot-bezei FROM tvrot
*                       WHERE   spras = sy-langu
*                       AND     route = i_xvttk-route.
*  IF sy-subrc <> 0 .
*    SELECT SINGLE bezei INTO tvrot-bezei FROM tvrot
*                       WHERE   spras = c_default_spras
*                       AND     route = i_xvttk-route.
*    IF sy-subrc = 0 .
*      idoc_z1sdshpmnt02-ship_route_description = tvrot-bezei .
*    ENDIF.
*  ELSE.
*    idoc_z1sdshpmnt02-ship_route_description = tvrot-bezei .
*  ENDIF.
*
*ENDFORM.                    "get_route_description
*
**----------------------------------------------------------------------
*-
**   perform ship_allowed_wt.
**   Doc : The weight and vehicle description are exported to memory
**         in the  include ZXV51SU01 at the time of Handling units
*create
**----------------------------------------------------------------------
*-
*FORM ship_allowed_wt.
*
*  SELECT SINGLE magew vhilm INTO (vekp-magew, vekp-vhilm) FROM vekp
*               WHERE vpobjkey = i_xvttk-tknum
*               AND   vpobj    =  c_04 .
*  IF sy-subrc = 0 .
*    idoc_z1sdshpmnt02-ship_allowed_wt = vekp-magew.
*  ELSE.
**// import the weight .
*    IMPORT magew FROM  MEMORY ID 'ZWT'.
*    IF sy-subrc <> 0 .
*    ELSE .
*      idoc_z1sdshpmnt02-ship_allowed_wt = magew .
*    ENDIF.
**// import the vehicle description
*    IMPORT vhilm FROM MEMORY ID 'ZCON' .
*    IF sy-subrc <> 0 .
** create an ahd if the weight is not  found ??
*    ELSE .
*      vekp-vhilm = vhilm.
*    ENDIF.
*    CONDENSE  idoc_z1sdshpmnt02-ship_allowed_wt NO-GAPS.
*  ENDIF.
*
*ENDFORM.                    "ship_allowed_wt
*
**----------------------------------------------------------------------
**
**   perform ship_conditions.
**----------------------------------------------------------------------
**
*FORM ship_conditions.
*
*  IF vekp-vhilm <> space.
*    SELECT SINGLE maktx INTO makt-maktx
*                             FROM makt
*                             WHERE matnr = vekp-vhilm.
*
*    IF sy-subrc = 0 .
*      idoc_z1sdshpmnt02-ship_conditions = makt-maktx(2) .
*      idoc_z1sdshpmnt02-ship_car_description = makt-maktx+3 .
*      CONDENSE idoc_z1sdshpmnt02-ship_car_description.
*    ENDIF.
*  ENDIF.
*
*ENDFORM.                    "ship_conditions
*
**----------------------------------------------------------------------
**
**   perform get_ship_scacd_code.
**----------------------------------------------------------------------
**
*FORM  get_ship_scacd_code.
*
*  SELECT SINGLE scacd FROM lfa1 INTO lfa1-scacd
*                             WHERE lifnr = i_xvttk-tdlnr.
*  IF sy-subrc = 0 .
*    idoc_z1sdshpmnt02-ship_scacd = lfa1-scacd.
*  ENDIF.
*
*ENDFORM .                    "get_ship_scacd_code
*
**----------------------------------------------------------------------
*-
** perform shipment_no_of_units
**----------------------------------------------------------------------
*-
**// vtrlp-lgmng is in base unit of measure . vtrlp-lfimg is supposed to
**/  be in sales unit of measure . but for the export shipments that are
**/  based out of sto's, the deliveries are also created in the base
*unit
**/  of measure where as we need the sales unit of measure from the
**/  sales order associated with the sto. the ordered number of units
*com
**/  from the sales order and not the STO's.
*
*FORM shipment_no_of_units.
*
*  CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
*    EXPORTING
*      instance           = cuobj
*    TABLES
*      configuration      = conf_out
*    EXCEPTIONS
*      instance_not_found = 1
*      OTHERS             = 2.
*  IF sy-subrc = 0.
*    SORT conf_out BY atnam.
*    READ TABLE conf_out
*         WITH KEY atnam = zsdc_order_units
*         BINARY SEARCH.
*    IF sy-subrc = 0 .
**calculate the corresponding delivered unit of rolls. this would change
**in the later versions as the ordered and delivered unit could be
*anythi
** other than rolls.
*      SPLIT conf_out-atwrt AT ' ' INTO p1 p2 .
*      IF sy-subrc = 0 .
*        REPLACE ALL OCCURRENCES OF ',' IN p1 WITH space.
*        x_int = p1 .
*        SELECT SINGLE kwmeng klmeng umvkz umvkn
*                 INTO CORRESPONDING FIELDS OF vbap
*                 FROM vbap
*                 WHERE  vbeln = idoc_z1sdshpdli01-ship_so_number
*                 AND    posnr = idoc_z1sdshpdli01-ship_so_line_number.
*
*        IF sy-subrc = 0 .
*          IF vbap-kwmeng <> 0 .
**            perform base_uom_del_wt .
**            x_int4   = ( i_vtrlp-lgmng / vbap-klmeng ) *
**                               x_int.
** CO52799
** VBAP-KLMENG is confirmed quantity; need to use order qty instead
** 06/24/2005 change calculation to convert sales order qyt to base uom
**   in order to calculate ship nbr of units
**  ( dlvry qty(base uom ) divided by
**[(sales order qty (ord uom)/ conversion denom) * conversion numerator]
**      times number of units from sales order line item characteristic
*            x_int4 = ( i_vtrlp-lgmng /             "dlvry qty base uom
*  ( ( vbap-kwmeng / vbap-umvkn ) * vbap-umvkz ) )  "sales ord qty
*                *  x_int.               "charact.for sales order rolls
*            idoc_z1sdshpdli01-ship_num_of_units  = x_int4.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*    ELSE.
*      vrkme = i_vtrlp-vrkme .
*      PERFORM get_mts_relevant_fields.
*
*    ENDIF.
*  ENDIF.
*
*ENDFORM .                    "shipment_no_of_units
*
**----------------------------------------------------------------------
**
**      perform get_address_details
**----------------------------------------------------------------------
*-
*FORM get_address_details.
*
*  CLEAR kna1.
*  SELECT SINGLE adrnr FROM kna1 INTO kna1-adrnr
*                              WHERE kunnr = i_xvtts-kunnz .
*  SELECT SINGLE adrnr FROM vbpa INTO vbpa-adrnr WHERE
*                           vbeln = i_xvttp-vbeln
*                          AND posnr = c_zeros
*                          AND parvw = c_shipto.
*
*  IF sy-subrc =  0 .
*    SELECT SINGLE * FROM adrc INTO adrc
*                            WHERE addrnumber = vbpa-adrnr.
*    IF sy-subrc = 0 .
*      idoc_z1sdshpdlh01-ship_to_name        = adrc-name1 .
*      idoc_z1sdshpdlh01-ship_to_name2       = adrc-name2 .
*      idoc_z1sdshpdlh01-ship_to_house       = adrc-house_num1.
*      idoc_z1sdshpdlh01-ship_to_street      = adrc-street.
*      idoc_z1sdshpdlh01-ship_to_ad_strspp1  = adrc-str_suppl1.
*      idoc_z1sdshpdlh01-ship_to_ad_strspp2  = adrc-str_suppl2.
*      idoc_z1sdshpdlh01-ship_to_city        = adrc-city1.
*      idoc_z1sdshpdlh01-ship_to_state       = adrc-region.
*      idoc_z1sdshpdlh01-ship_to_zip         = adrc-post_code1.
*      SELECT SINGLE landx INTO t005t-landx FROM t005t
*                                    WHERE spras = sy-langu
*                                    AND   land1  = adrc-country.
*      IF sy-subrc = 0 .
*        idoc_z1sdshpdlh01-ship_to_country_name = t005t-landx.
*      ELSE.
*        SELECT SINGLE landx INTO t005t-landx FROM t005t
*                                  WHERE spras = c_default_spras
*                                    AND   land1  = adrc-country.
*        IF sy-subrc = 0 .
*          idoc_z1sdshpdlh01-ship_to_country_name = t005t-landx.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*ENDFORM.                    "get_address_details
*
**----------------------------------------------------------------------
**
**     perform  get_del_min_and_max.
**----------------------------------------------------------------------
**
*FORM  get_del_min_and_max.
**// The deliveries for STO's is always going to be created in the base
**/ unit of measure as the STO is always in base unit of measure.
**/ therefore  find out the sales unit of measure for the sales order.
*
**/ 05/20/05 get tolerances from material characteristic values on order
**/   if not found there, use devlivery tolerances
*  DATA: over_tolerance TYPE uebto,
*        under_tolerance TYPE untto.
*
** get delivery tolerances as the default
*  SELECT SINGLE uebto untto FROM lips
*                INTO (over_tolerance, under_tolerance)
*                WHERE  vbeln = i_vtrlp-vbeln
*                AND    posnr = i_vtrlp-posnr.
*
*  SELECT * INTO TABLE t_zsp_value
*    FROM zsp_value
*    WHERE pgrmid = c_prgmid.
*
** check for material characteristic tolerances - use them if found
** CR3698 : For MTS STO's there are no delivery tolerances. Therefore
** read the tolerance values from the ZSP_VALUE table. f_mts_sto flag is
** set for MTS STO only. Note that we cannot check for the lips-uebto
*
*  READ TABLE conf_out
*        WITH KEY atnam = zsdc_tol_over_percent
*        BINARY SEARCH.
*  IF sy-subrc = 0.
*    over_tolerance = conf_out-atwrt.
*  ELSEIF f_mts_sto = 'X' OR gv_read_apo = 'X'.
*    READ TABLE t_zsp_value WITH KEY fieldname = c_over_tolerance.
*    IF sy-subrc = 0 .
*      over_tolerance = t_zsp_value-fieldvalue.
*    ENDIF.
*  ENDIF.
*
*  READ TABLE conf_out
*       WITH KEY atnam = zsdc_tol_under_percent
*       BINARY SEARCH.
*  IF sy-subrc = 0.
*    under_tolerance = conf_out-atwrt.
*  ELSEIF f_mts_sto = 'X' OR gv_read_apo = 'X' .
*    READ TABLE t_zsp_value WITH KEY fieldname = c_under_tolerance.
*    IF sy-subrc = 0 .
*      under_tolerance = t_zsp_value-fieldvalue.
*    ENDIF.
*  ENDIF.
*
** replaced document tolerance with tolerance from order characteristic
*  del_max = 100 + over_tolerance .
*  del_min = 100 - under_tolerance .
*
*  IF vrkme = 'RL' .
**// this might be the case for the deliveries created for export sto's.
**/ convert the delivery qty in ROLLS and  find out the tolerance on it
*    x_int4 =  idoc_z1sdshpdli01-ship_num_of_units  * del_max  / 100.
*    idoc_z1sdshpdli01-ship_max_del_qty =  x_int4.
*
*    x_int4 =  idoc_z1sdshpdli01-ship_num_of_units * del_min / 100.
*    idoc_z1sdshpdli01-ship_min_del_qty =  x_int4.
*
*  ELSE .
*
*    idoc_z1sdshpdli01-ship_max_del_qty =
*                       i_vtrlp-lgmng * del_max  / 100.
*    idoc_z1sdshpdli01-ship_min_del_qty =
*                         i_vtrlp-lgmng * del_min / 100.
*  ENDIF.
*
*  CONDENSE : idoc_z1sdshpdli01-ship_max_del_qty NO-GAPS,
*             idoc_z1sdshpdli01-ship_min_del_qty NO-GAPS.
*
*ENDFORM .                    "get_del_min_and_max
*
**----------------------------------------------------------------------
**
**   perform create_ship_idoc.
**----------------------------------------------------------------------
**
*FORM create_ship_idoc.
*
*  t_master_idoc_control-rcvprn = t_ship_points-rcvprn.
*  PERFORM check_req_fields TABLES t_idoc_data
*                          USING  t_master_idoc_control.
** Begin of change / nparchu / 05/02/2006
************************************************************************
**
** The data from the APO could not be read , hence we dont need to
*create
** the idoc . Also need to raise an AHD ticket
************************************************************************
**
*  IF gv_fail_idoc = 'X' .
*    PERFORM app_log_ahd_ticket.
*  ELSE.
** End of change / nparchu / 05/02/2006
*    CALL FUNCTION 'MASTER_IDOC_DISTRIBUTE'
*      EXPORTING
*        master_idoc_control            = t_master_idoc_control
*      TABLES
*        communication_idoc_control     = t_idoc_comm_control
*        master_idoc_data               = t_idoc_data
*      EXCEPTIONS
*        error_in_idoc_control          = 1
*        error_writing_idoc_status      = 2
*        error_in_idoc_data             = 3
*        sending_logical_system_unknown = 4
*        OTHERS                         = 5.
*    IF sy-subrc <> 0.
*      MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)
*      tknum 'Idoc create failed for return code'(m07)
*      sy-subrc INTO g_dummy.
*      PERFORM handle_message.
*      EXIT.
*    ELSE.
*      LOOP AT t_idoc_comm_control.
*        CALL FUNCTION 'EDI_DOCUMENT_DEQUEUE_LATER'
*          EXPORTING
*            docnum                 = t_idoc_comm_control-docnum
*          EXCEPTIONS
*            idoc_is_not_to_dequeue = 1
*            OTHERS                 = 2.
*        IF sy-subrc <> 0.
*          EXIT.
*        ELSE.
*          MESSAGE s000(zsd_dl) WITH t_idoc_comm_control-docnum
*                        ' IDoc sent successfully for shipment'(s01)
*                        space
*                   INTO g_dummy.
*          go_log->handle_message( ).
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
** Begin of change / nparchu / 05/02/2006
*  ENDIF.
** end of change / nparchu / 05/02/2006
*ENDFORM .                    "create_ship_idoc
*
**----------------------------------------------------------------------
**
**          perform get_ale_partner_details.
**    Doc :find out if the idoc needs to be created for this ship point
*.
**   This should improve the performance little bit.
**----------------------------------------------------------------------
**
*FORM get_ale_partner_details.
** fill idoc header data
*  CLEAR t_master_idoc_control-rcvprn.
*  CALL METHOD zcl_idoc_control_data=>read_partner_data
*    EXPORTING
*      element_name       = c_dataelement
*      element_value      = datavalue
*      message_type_name  = c_message_type
*    IMPORTING
*      receipient_partner = t_master_idoc_control-rcvprn
*      receipient_type    = t_master_idoc_control-rcvprt
*    EXCEPTIONS
*      partner_not_found  = 1
*      OTHERS             = 2.
*
*  g_subrc = sy-subrc.
*  IF sy-subrc <> 0.
*    MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)
*     tknum  'No ALE Partner found for idoc routing'(m04) g_dummy.
*    PERFORM handle_message.
*    EXIT.
*  ENDIF.
*
*ENDFORM.                    "get_ale_partner_details
*
**----------------------------------------------------------------------
**
**        perform read_shipment_no.
** Doc:  Read the shipment number in the global variable for  further
*use
**----------------------------------------------------------------------
**
*FORM read_shipment_no .
*
**// if it is shipment delete, then there is only header entry in xvttk
**/  therefore read would fail.
*  READ TABLE i_xvttk WITH KEY mandt = sy-mandt.
*  IF sy-subrc = 0 .
*    tknum = i_xvttk-tknum.
*  ELSE .
*    tknum = i_xvttk-tknum.
*  ENDIF.
*
*ENDFORM.                    "read_shipment_no
*
**----------------------------------------------------------------------
**
**        perform move_itab_data  .
**----------------------------------------------------------------------
**
*FORM move_itab_data .
*
*  t_vtts[] = i_xvtts[].                     " stages table
*  t_vtsp[] = temp_vtsp[] = i_xvtsp[].
*  t_vttp[] = i_xvttp[].                     " shipment items
*
**// changes to allow the manual deletion of the shipments
**/  the "x" tables are all empty for the deletes so manually
**/  change them for the idocs to be created. These tables needs to be
**/  cleared out later on.
*  IF i_yvttk-updkz = c_delete.
*    t_vtts[] = i_xvtts[] = i_yvtts[].
*    t_vtsp[] = i_xvtsp[] = i_yvtsp[].
*    t_vttp[] = i_xvttp[] = i_yvttp[].
*    temp_vtsp[] = i_yvtsp[].
*  ENDIF.
*
*ENDFORM.                    "move_itab_data
*
**----------------------------------------------------------------------
**
**        perform  base_uom_del_wt .
**----------------------------------------------------------------------
**
*FORM base_uom_del_wt.
*
*  IF sto_acct_assign_active <> 'Y' .
*    SELECT SINGLE rfmng INTO vbfa-rfmng FROM vbfa
*            WHERE vbelv = i_vtrlp-vgbel
*            AND   posnv = i_vtrlp-vgpos
*            AND   vbeln = i_xvttp-vbeln
*           AND   vbtyp_n = 'J' .        " Delivery
*    IF sy-subrc = 0 .
*      x_int4   = ( vbfa-rfmng / vbap-klmeng ) *
*                         x_int.
*      idoc_z1sdshpdli01-ship_num_of_units  = x_int4.
*    ENDIF.
*  ELSE.
**// if the sto account assignment is active, the  po history is
*obtained
**/ from the EKBE table. This table should always be having the deliver
**/ qty in the base unit of measure .
*    SELECT SINGLE menge INTO ekbe-menge FROM ekbe
*            WHERE ebeln = i_vtrlp-vgbel
*            AND   ebelp = i_vtrlp-vgpos
*            AND   belnr = i_vtrlp-vbeln.
*    IF sy-subrc = 0 .
*      x_int4   = ( ekbe-menge / vbap-klmeng ) *
*                         x_int.
*      idoc_z1sdshpdli01-ship_num_of_units  = x_int4.
*    ENDIF.
*  ENDIF.                              " sto_acct_assign_active
*
*
*ENDFORM.                    "base_uom_del_wt
*
**----------------------------------------------------------------------
**
**        perform format_sales_order.
**----------------------------------------------------------------------
**
*FORM format_sales_order.
*
** format the sales order #
*  SHIFT idoc_z1sdshpdli01-ship_so_number RIGHT
*                  DELETING TRAILING space.
*  TRANSLATE idoc_z1sdshpdli01-ship_so_number
*                                    USING ' 0'.
*
*ENDFORM.                    "format_sales_order
*
**&--------------------------------------------------------------------*
**&      Form  initialize_parameters
**&--------------------------------------------------------------------*
*FORM initialize_parameters .
*
*  CLEAR :  t_idoc_comm_control[],
*           t_idoc_data[],
*           t_vtrlp[],
*           t_vtts[],
*           t_vtsp[],
*           temp_vtsp[],
*           t_vttp[],
*           t_ship_points[],
*           it_trim_detail[],
*           tknum,
*           f_mts_sto,
*           f_mto_sto.
*
*  DATA :
*    ws_log  TYPE bal_s_log,                     "app log
*    lv_external_id TYPE balnrext.
*
*  ws_log-alprog    = sy-repid.
*  ws_log-aluser    = sy-uname.
*  ws_log-object    = c_object.
*  ws_log-subobject = c_subobject.
*
**  External ID should be Date_Time_Shipment#.
*
*  READ TABLE i_xvttk WITH KEY mandt = sy-mandt.
*
*  CONCATENATE sy-datum '_'
*              sy-uzeit '_'
*              i_xvttk-tknum
*              INTO lv_external_id.
*
*  ws_log-extnumber = lv_external_id.
*
**// Create the application logging object
*  TRY.
*      CREATE OBJECT go_log
*        EXPORTING
*          is_log  = ws_log.
*
*    CATCH zcx_ca_applog_init_failure .
*
*  ENDTRY.
*
*ENDFORM.                    "initialize_parameters
*
**&--------------------------------------------------------------------*
**&      Form  check_req_fields
**&--------------------------------------------------------------------*
** Call function module to generate application logs and/or a AHD ticket
** make sure that the ZZPD documentation exist for the creation of an
** ahd ticket. the zzpd documentation number for this inven. code I1217
**---------------------------------------------------------------------*
*FORM check_req_fields  TABLES  p_t_idoc_data STRUCTURE edidd
*                        USING   p_t_idoc_comm_control STRUCTURE edidc.
*
*  CONSTANTS: c_inventory_code TYPE zzinv VALUE 'I1217'.
*  DATA: l_text  TYPE char50,
*        l_key(50) .
*
*  CONCATENATE 'Shipment Number ='
*               tknum INTO l_text SEPARATED BY space.
*
*  CONCATENATE 'Receiver id = ' p_t_idoc_comm_control-rcvprn
*                               INTO l_key.
*
*  CALL FUNCTION 'Z_CHECK_REQ_FIELDS'
*    EXPORTING
*      idoc_control                        =  p_t_idoc_comm_control
***   AUX_KEY1                            =
*      inventory_code                      =  c_inventory_code
*     ahd_tkt_skip_flag                   =  ' '
*      ahd_text4                           =  l_text
*      ahd_text5                           =  l_key
***   AHD_TEXT6                           =
***   APP_LOG_SKIP_FLAG                   = ' '
*      app_log_object                      = c_object
*      app_log_subobject                   = c_subobject
*    TABLES
*      idoc_data                           = p_t_idoc_data
*    EXCEPTIONS
*      control_record_missing              = 1
*      data_record_missing                 = 2
*      no_required_values                  = 3
*      unidentifiable_idoc_structure       = 4
*      empty_fields_identified             = 5
*      OTHERS                              = 6.
*
*  IF sy-subrc = 3.
*    CLEAR sy-subrc.
*  ELSEIF sy-subrc = 0 .
*  ELSEIF NOT sy-subrc EQ 5.
*    MESSAGE s000(zsd_dl) WITH 'Shipment Number'(m02)
*       tknum 'AHD create functionality failed'(m08) sy-subrc
*       INTO g_dummy.
*    PERFORM handle_message.
*  ENDIF.
*
*
*ENDFORM.                    "check_req_fields
*
**&--------------------------------------------------------------------*
**&      Form  get_mts_relevant_fields
**&--------------------------------------------------------------------*
**// if it was a MTS then cuobj would be blank, therefore characteristic
**/  cannot be read .
**---------------------------------------------------------------------*
*FORM  get_mts_relevant_fields.
*  IF vrkme = c_alternate_uom .
*    idoc_z1sdshpdli01-ship_num_of_units  = i_vtrlp-lfimg .
*  ELSE .
*    PERFORM unit_conversion .
*  ENDIF.
*
*ENDFORM.                    "get_mts_relevant_fields
*
**&--------------------------------------------------------------------*
**&      Form  unit_conversion
**&--------------------------------------------------------------------*
**       This UoM conversion needs to be done for both the MTS and the
**       VMI orders . If the ordered  qty is not in Rolls then convert
*it
**       into Rolls using the FM 'MATERIAL_UNIT_CONVERSION'
**---------------------------------------------------------------------*
*FORM unit_conversion.
*  DATA:  l_uom          TYPE meins,
*         l_qty          TYPE meng15,
*         l_weight       TYPE meng15,
*         l_base_uom     type meins.
*
** l_weight = i_vtrlp-lfimg.
*  l_weight = i_vtrlp-ntgew.
*  l_base_uom = i_vtrlp-gewei.
*
*  CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
*    EXPORTING
*      input                = l_weight
*      matnr                = i_vtrlp-matnr
*      meinh                = c_alternate_uom                 " RL
**     meins                = i_vtrlp-vrkme
*      meins                = l_base_uom
**     extended_conv        = 'X'
*    IMPORTING
*      meins                = l_uom
*      output               = l_qty
*    EXCEPTIONS
*      conversion_not_found = 1
*      input_invalid        = 2
*      material_not_found   = 3
*      meinh_not_found      = 4
*      meins_missing        = 5
*      no_meinh             = 6
*      output_invalid       = 7
*      overflow             = 8
*      OTHERS               = 9.
*  IF sy-subrc <> 0 .
*    EXIT.
*  ENDIF.
*  x_int4 = l_qty .
*  idoc_z1sdshpdli01-ship_num_of_units  = x_int4 .
*ENDFORM .                    "unit_conversion
*
**&--------------------------------------------------------------------*
**&      Form  handle_message
**&--------------------------------------------------------------------*
*FORM handle_message.
*
*  CHECK go_log IS NOT INITIAL.
*  go_log->handle_message( ).
*
*ENDFORM.                    "HANDLE_MESSAGE
*
**&--------------------------------------------------------------------*
**&      Form  extract_trim_details
**&--------------------------------------------------------------------*
*FORM extract_trim_details USING v_sales_order v_so_line_item.
*
*  it_trim_detail-kdauf = v_sales_order.
*  it_trim_detail-kdpos = v_so_line_item.
*  APPEND it_trim_detail.
*
*  CALL FUNCTION 'ZSD_DL_U1165_TRIM_ORDER_DETAIL'
*    TABLES
*      zt_trim_details      = it_trim_detail
*    EXCEPTIONS
*      missing_input        = 1
*      no_valid_items_found = 2
*      OTHERS               = 3.
*  IF sy-subrc <> 0.
**// if for some reasons the function module to return the trim details
**/  errored out , then we will read the sales order characteristic.
*    PERFORM shipment_no_of_units.
*  ELSE .
**// calculate the ship # of rolls .
*    READ TABLE it_trim_detail WITH KEY kdauf = v_sales_order
*                                       kdpos = v_so_line_item.
*    IF sy-subrc = 0 .
*      IF it_trim_detail-ztrimunit_wt <> 0 .
*        x_int4 =  i_vtrlp-lgmng / it_trim_detail-ztrimunit_wt.
*        idoc_z1sdshpdli01-ship_num_of_units  = x_int4.
*      ELSE .
*        PERFORM shipment_no_of_units.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
*ENDFORM.                    "extract_trim_details
*
**&--------------------------------------------------------------------*
**&      Form  get_data_ipgmills
**&--------------------------------------------------------------------*
*FORM get_data_ipgmills.
*  CLEAR gv_read_apo.
*  SELECT * FROM zdl_supply_drivn INTO TABLE gt_supply_drivn
*           WHERE z_supply_driven = 'Y'.
*
*  IF sy-subrc <> 0 .
*    gv_read_apo = 'N' .
*  ELSE.
*    SORT gt_supply_drivn BY locno matkl .
*  ENDIF.
*ENDFORM.                    "get_data_ipgmills
*
**&--------------------------------------------------------------------*
**&      Form  app_log_ahd_ticket
**&--------------------------------------------------------------------*
*FORM app_log_ahd_ticket.
*
*  DATA : l_text TYPE char50 ,
*         l_err1 TYPE char50 ,
*         l_err2 TYPE char50 ,
*         lv_tknum TYPE char50.
*
*
** Raise the customized texts for the AHD ticket
* l_text = 'Error in getting value for field ship_num_of_units from APO'
* .
*  CONCATENATE 'check object ZDL_INTERFACE'(m12)
*              'subobject ZDL_SHPMNT_REQFIELD'(m13)
*              'for exact error details'(m14)
*              INTO l_err1 .
*  CONCATENATE 'correct the error and retrigger the shipment'(m15)
*              'from area menu ZZDL_RETRIGGER'(m16)
*              INTO l_err2 .
*  lv_tknum = tknum .
*  CONDENSE tknum .
*
** Raise AHD ticket
*  CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
*    EXPORTING
*      inventory_code         = 'I1217'
*      text_1                 = 'IDoc creation failed for shipment'(m17)
*      text_2                 = lv_tknum
*      text_3                 = l_text
*      text_4                 = l_err1
*      text_5                 = l_err2
*    EXCEPTIONS
*      invalid_inv_code       = 1
*      ahdgrp_not_found       = 2
*      invalid_idoc_number    = 3
*      webmd_connection_error = 4
*      OTHERS                 = 5.
*
*  IF sy-subrc <> 0.
**/  catch the sy-subrc error. The case statement should
**/  help prevent the short dumps .
**        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*
*    CASE sy-subrc .
*      WHEN '1' .
*        MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '86' INTO g_dummy.
*        go_log->handle_message( ).
*      WHEN '2' .
*        MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '87' INTO g_dummy.
*        go_log->handle_message( ).
*      WHEN '3'.
*        MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '88' INTO g_dummy.
*        go_log->handle_message( ).
*      WHEN '4'.
*        MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '89' INTO g_dummy.
*        go_log->handle_message( ).
*      WHEN OTHERS.
*        MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '90' INTO g_dummy.
*        go_log->handle_message( ).
*    ENDCASE .
*
*  ENDIF. " sy-subrc <> 0.
*
*ENDFORM.                    "app_log_ahd_ticket
*
**&--------------------------------------------------------------------*
**&      Form  read_apo
**&--------------------------------------------------------------------*
*FORM  read_apo .
*  READ TABLE gt_supply_drivn WITH KEY locno = i_vtrlp-werks
*                                      matkl = i_vtrlp-matkl
*                                      BINARY SEARCH.
*  IF sy-subrc = 0 .
*    READ TABLE gt_delivery_roll
*                WITH KEY  delivery = i_vtrlp-vbeln
*                          delivery_item = i_vtrlp-posnr
*                          ASSIGNING <ls_delivery>
*                          BINARY SEARCH.
*
*    IF sy-subrc = 0 .
*      idoc_z1sdshpdli01-ship_num_of_units  = <ls_delivery>-num_rolls
*.
*    ELSE .
*      gv_fail_idoc = 'X' . "read table gt_delivery_roll
*      CLEAR gmsg_text.
*      CONCATENATE 'delivery'(m11)
*                  i_vtrlp-vbeln
*                  'Delivery item'(m11)
*                  i_vtrlp-posnr
*                  INTO gmsg_text SEPARATED BY space.
*      MESSAGE s000(zsd_dl) WITH 'Guidance record not found for'
*                                  'Shipment Number'(m02)  tknum
*                                   gmsg_text
*                                  INTO g_dummy.
*      PERFORM handle_message.
*    ENDIF.
*  ELSE.                " read table gt_supply_drivn
*    " no need for above logic
*    IF cuobj IS INITIAL.
*      PERFORM get_mts_relevant_fields.
*    ELSE.
*      PERFORM shipment_no_of_units.
*    ENDIF.
*  ENDIF.
*ENDFORM .                    "read_apo

************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2015 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
************************************************************************
* Program Name: India Reel OBD Picking Front-end Create Date: 04/15/15 *
*                                                                      *
* SAP Name    : ZDL_E10539_APPM_PICKING          Version    : final    *
*                                                                      *
* Programmer  : Jacek Grabowiecki                Last Update: mm/dd/yy *
*______________________________________________________________________*
* Description :                                                        *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ================ ========== ========= ===============================*
* J.Grabowiecki    mm/2015    E0V cmsjg Initial transport              *
*                                                                      *
************************************************************************
* Includes          :                                                  *
*______________________________________________________________________*
* Logical Databases :                                                  *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: REUSE_ALV_GRID_DISPLAY                           *
*                     REUSE_ALV_FIELDCATALOG_MERGE                     *
*                     REUSE_ALV_COMMENTARY_WRITE                       *
*                     Z_RPT_HEADER                                     *
*                     REUSE_ALV_VARIANT_EXISTENCE                      *
*                     REUSE_ALV_VARIANT_F4                             *
*                     DYNP_VALUES_UPDATE                               *
*   Transactions    :                                                  *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   : On request                                       *
*______________________________________________________________________*
************************************************************************
report  zdl_e10539_appm_picking.

include zzez410a.       " Data Declarations for Variant Trapping

include zdl_e10539_top.
include zdl_e10539_cls.
include zdl_e10539_o01.
include zdl_e10539_i01.
include zdl_e10539_f01.

*-----------------------------------------------------------------------
* Process on value request
at selection-screen on value-request  for p_var_ba.
  perform get_variant using gs_variant_ba p_var_ba 'G_VTX_BA'.

at selection-screen on value-request  for p_var_li.
  perform get_variant using gs_variant_li p_var_li 'G_VTX_LI'.

*-----------------------------------------------------------------------
at selection-screen output.
  perform check_var using gs_variant_ba  p_var_ba g_vtx_ba space.
  perform check_var using gs_variant_li  p_var_li g_vtx_li space.

*-----------------------------------------------------------------------
at selection-screen.
  perform validate_input.
  perform check_var using gs_variant_ba  p_var_ba g_vtx_ba 'X'.
  perform check_var using gs_variant_li  p_var_li g_vtx_li 'X'.

*-----------------------------------------------------------------------
initialization.
  perform initialization.

*-----------------------------------------------------------------------
start-of-selection.
  include zzez410b.         " Begin gathering info for variant trapping
  perform get_char.
  perform select_data.

*--------------------------------------------------------------------
end-of-selection.
  include zzez410c.           " End data gathering for variant trapping

  if gt_li[] is initial.
    perform unlock_delivery.
    message 'No data selected' type 'S'.
  else.
    call screen 100.
  endif.

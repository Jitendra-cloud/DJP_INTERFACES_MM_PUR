*----------------------------------------------------------------------*
***INCLUDE ZSDU01267O01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

* Screen 0100 is used for two purposes:
*   1) Main Processing to let user decide what they want to do: ie
*      Create a Container, Update a Book Confirmation Number, Reissue a
*      Tally
*   2) Selection Screen - shows the Selection Screen if the 'Create
*      Container' button is clicked

  CLEAR gt_exclude.  REFRESH gt_exclude.

* Set the mode for screen 0100 the first time through.
  IF gv_0100_mode IS INITIAL.
    gv_0100_mode = gc_main_processing.
  ENDIF.

  CASE gv_0100_mode.

*   MAIN SCREEN Mode:
*     Initially, no fields will display; only application toolbar
*     buttons
    WHEN gc_main_processing.

      SET PF-STATUS '0100' EXCLUDING 'ONLI'.
      SET TITLEBAR '0100'. "Container Processing

      LOOP AT SCREEN.
        IF screen-group1 = 'SEL'.
          screen-input     = '0'.   "Disable input
          screen-output    = '0'.   "Disable Text
          screen-invisible = '1'.   "Remove from screen
          MODIFY SCREEN.
        ENDIF.
      ENDLOOP.

*   CREATE CONTAINER SELECTION SCREEN Mode:
*     User clicks 'Create Container' so remove navigation buttons so
*     hide all Application Tool buttons except for the Execute button
    WHEN gc_selection_screen.

      APPEND: 'CREATE' TO gt_exclude,
              'TALLY'  TO gt_exclude,
              'UPDATE' TO gt_exclude.

      SET PF-STATUS '0100' EXCLUDING gt_exclude.
      SET TITLEBAR '0110'. "Create Container

  ENDCASE.

ENDMODULE.                 " STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0200 OUTPUT.

  CLEAR gt_exclude.  REFRESH gt_exclude.
  CLEAR : zdlu01267_0200-lgobe.

* Initially, when coming from screen 0100, format Non-ALV Grid fields
  IF ok_code = 'ONLI'. "user selected Execute from 0100

*   Format Screen 0200 Display fields
    MOVE-CORRESPONDING zdlu01267_0100 TO zdlu01267_0200.

*   Retrieve Plant Description
    SELECT SINGLE name1 INTO zdlu01267_0200-name1
      FROM t001w
      WHERE werks = zdlu01267_0200-werks.

*   Retrieve Storage Location Description
    IF zdlu01267_0200-lgort IS NOT INITIAL.
      SELECT SINGLE lgobe INTO zdlu01267_0200-lgobe
        FROM t001l
        WHERE werks = zdlu01267_0200-werks
          AND lgort = zdlu01267_0200-lgort.
    ENDIF.

  ENDIF.

* Format screen 0200 in 3 possible modes
  CASE gv_0200_mode.

    WHEN gc_list_selection.

*     In List Selection mode user is presented a list of Batch info
*     where the user can select to include on the Container HU. The only
*     button available to the user will be 'Confirm Selection'
      APPEND: 'CREATE' TO gt_exclude,
              'TALLY'  TO gt_exclude.
      SET PF-STATUS '0200' EXCLUDING gt_exclude.
      SET TITLEBAR '0200'. "List Screen

    WHEN gc_list_confirmation.

*     In List Confirmation mode user is presented the list of Batch info
*     he/she selected on the List Selection screen. The only button
*     available to the user will be 'Create Container'. If the Container
*     is created successfully, the user will go on to the next mode
*     which is the Status mode. If an error occurred, the user will stay
*     on this screen.
      APPEND: 'CONFIRM' TO gt_exclude,
              'TALLY'   TO gt_exclude.
      SET PF-STATUS '0200' EXCLUDING gt_exclude.
      SET TITLEBAR '0210'. "List Confirmation Screen

    WHEN gc_status.

*     In Create Container HU Status mode the user had just selected
*     'Create Container' on the previous screen and the Container was
*     created successfully. The only button available to the user will
*     be 'Print Container Tally'.
      APPEND: 'CREATE'   TO gt_exclude,
              'CONFIRM'  TO gt_exclude.
      SET PF-STATUS '0200' EXCLUDING gt_exclude.
      SET TITLEBAR '0220'. "Container HU Status

  ENDCASE.

ENDMODULE.                 " STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  DISPLAY_ALV  OUTPUT
*&---------------------------------------------------------------------*
*       Display the ALV Grid
*----------------------------------------------------------------------*
MODULE display_alv OUTPUT.

* Display the ALV Grid
  PERFORM display_alv.

ENDMODULE.                 " DISPLAY_ALV  OUTPUT

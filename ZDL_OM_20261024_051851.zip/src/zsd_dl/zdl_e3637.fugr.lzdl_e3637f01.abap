*______________________________________________________________________*
* Change History:                                                      *
*    Programmer         Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Shabbir Mithaiwala 05/26/2016 E0VK9A0KHD CMS:30425 Add Wait Statement*
* Shabbir Mithaiwala 06/23/2016 E0VK9A0KS2 CMS:30577 Replace Call TXn  *
*                                          VL01N VL02N with BAPI Update*
* Jacek Grabowiecki 07/2018 E0V 33303 Copy LIKP-Z* fields from inbound
*                                     delivery when creating outbound
*                                     delivery.
*
*----------------------------------------------------------------------*
***INCLUDE LZDL_E3637F01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  sub_vl01
*&---------------------------------------------------------------------*
* Call transaction VL01N through BDC
*----------------------------------------------------------------------*
*      <--ET_MESSAGES      Error Messages
*      <--EV_OUT_DLVRY     Outbound Delivery
*      -->UV_SHIP_POINT    Shipping Point
*      -->UV_SALE_ORD      Sales Order
*      -->UV_SEL_DATE      Max date
*      -->UV_INB_DLVRY     Inbound delivery
*----------------------------------------------------------------------*
FORM sub_vl01  USING    uv_ship_point  LIKE likp-vstel
                        uv_sale_ord    LIKE lips-vgbel
                        uv_sel_date    TYPE dats "char10 "CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
                        uv_inb_dlvry   LIKE likp-vbeln
                        iv_dlk         TYPE char1               "33303
                        lt_outbound_data TYPE zdl_bapidlvreftosalesorder_t  "JWILL68 CD#1626
               CHANGING et_messages    TYPE zca_bal_msg_tab
                        ev_out_dlvry   LIKE likp-vbeln.
  DATA:
    ls_messages  TYPE bal_s_msg,
    lv_mode      VALUE 'N',
    lv_update    VALUE 'S',
    lt_out_dlvry LIKE TABLE OF lips,    "Outbound delivery line item
    ls_out       LIKE lips,
    lt_lips      LIKE TABLE OF lips,    "Inbound delivery item
    ls_lips      LIKE lips,
    lv_so_line   TYPE i,    "No. of outbound delivery line item
    lv_id_line   TYPE i,    "No. of inbound delivery line item
    lv_string    TYPE string,
    lv_pos       TYPE char2. "Position of line item to be deleted
*-->CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
** Screen 1:  VL01N
*
*  PERFORM bdc_dynpro    USING 'SAPMV50A'  '4001'.
*
*  PERFORM bdc_field     USING:
*               'BDC_OKCODE'    '/00',            "Enter
*               'BDC_CURSOR'    'LV50C-VBELN',
*               'LIKP-VSTEL'    uv_ship_point,    "Shiping point
*               'LV50C-DATBI'   uv_sel_date,      "SelectionDate
*               'LV50C-VBELN'   uv_sale_ord.      "Sales Order
*
** Screen 2:  Save when brought into Outbound Delivery Create screen
*  PERFORM bdc_dynpro    USING  'SAPMV50A'   '1000'.
*
*  PERFORM bdc_field     USING  'BDC_OKCODE' '=SICH_T'.  "Save
*
*  CLEAR   gs_messtab.
*  REFRESH gt_messtab.
*
  WAIT UP TO 5 SECONDS.                         "CMS:30425 E0VK9A0KHD SMITHAI 5/26/2016
** Create outbound delivery using VL01N
*  CALL TRANSACTION 'VL01N' USING   gt_bdcdata
*                           MODE    lv_mode      "No display screens
*                           UPDATE  lv_update    "Synchronous
*                           MESSAGES INTO gt_messtab.

  PERFORM create_outb_delivery USING uv_sale_ord
                                     uv_ship_point
                                     uv_sel_date
                                     uv_inb_dlvry   "33303
                                     iv_dlk         "33303
                                     lt_outbound_data.  "JWILL68 CD#1626

  IF gv_out_dlvry IS NOT INITIAL. "sy-subrc = 0.

*   SORT gt_messtab BY msgid msgnr.

* Retrieve newly generated outbound delivery number
*   READ TABLE gt_messtab INTO gs_messtab
*       WITH KEY msgid = 'VL'
*                msgnr = '311'
*       BINARY SEARCH.

*   IF sy-subrc = 0.
* Get the delivery number
*     gv_out_dlvry = gs_messtab-msgv2.
*<--CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
* Apply conversion routine and update back the
* export parameter EV_OUT_DLVRY
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = gv_out_dlvry
      IMPORTING
        output = ev_out_dlvry.

* Delete non-goods received line items by calling VL02n
*--------------------------------------------------------------*
*  Sometimes, there will be partial delivery.  When you just pass
* sales order number in VL01n, it will create with all line items
* hence, get sales order line item and inbound delivery line items.
* Only when there is GR for the line item in the sales order,
* create an outbound delivery for those line item; others, delete it.
*---------------------------------------------------------------*
*      Step1.  Get outbound delivery info from table LIPS for the
* delivery which has been created right now
    SELECT vbeln posnr matnr
      INTO CORRESPONDING FIELDS OF TABLE lt_out_dlvry
      FROM lips
      WHERE vbeln = ev_out_dlvry
        AND posnr NOT LIKE '9%'.  "Ignore batch split

*      Step2.  Get Inbound delivery details from LIPS table
    SELECT  vbeln posnr matnr
      INTO CORRESPONDING FIELDS OF TABLE lt_lips
      FROM lips
      WHERE vbeln = uv_inb_dlvry.

    DESCRIBE TABLE lt_out_dlvry LINES lv_so_line.
    DESCRIBE TABLE lt_lips LINES lv_id_line.

* If count of inbound line item is not matching with that of
* outbound delivery, then it is partial delivery
    IF lv_so_line <> lv_id_line.
*-->CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
      PERFORM change_outb_delivery TABLES lt_out_dlvry
                                          lt_lips.
*       REFRESH gt_bdcdata.
*       CLEAR   gs_bdcdata.
*       PERFORM bdc_dynpro USING  'SAPMV50A'   '4004'.
*       PERFORM bdc_field     USING:
*                  'BDC_OKCODE'    '/00',            "Enter
*                  'LIKP-VBELN'   ev_out_dlvry. "Out. dlvry

*       PERFORM bdc_dynpro USING  'SAPMV50A'   '1000'.

*       PERFORM bdc_field  USING:
*             'BDC_OKCODE' '=POLO_T', "Delete item
*             'BDC_SUBSCR' 'SAPMV50A 1102SUBSCREEN_BODY'.

*        LOOP AT lt_out_dlvry INTO ls_out.
*          lv_pos = sy-tabix.
*          READ TABLE lt_lips TRANSPORTING NO FIELDS
*                  WITH KEY matnr = ls_out-matnr.
*
*          IF sy-subrc <> 0.
*            CLEAR lv_string.
*            CONCATENATE 'LIPS-POSNR('
*                        lv_pos
*                        ')'
*                        INTO lv_string.
*            PERFORM bdc_field     USING 'BDC_CURSOR' lv_string.
*
*            CLEAR lv_string.
*            CONCATENATE 'RV50A-LIPS_SELKZ('
*                        lv_pos
*                        ')'
*                        INTO lv_string.
*            PERFORM bdc_field USING lv_string 'X'.
*          ENDIF.
*        ENDLOOP.
*       PERFORM bdc_field USING:
*             'BDC_SUBSCR' 'SAPMV50A 0611SUBSCREEN_BOTTOM',
*             'BDC_SUBSCR' 'SAPMV50A 1708SUBSCREEN_ICONBAR'.

*       PERFORM bdc_dynpro    USING  'SAPMV50A'   '1000'.

*       PERFORM bdc_field     USING  'BDC_OKCODE' '=SICH_T'.  "Save

*       CLEAR   gs_messtab.
*       REFRESH gt_messtab.

* Create outbound delivery using VL02N
*       CALL TRANSACTION 'VL02N' USING   gt_bdcdata
*               MODE    lv_mode      "No display screens
*               UPDATE  lv_update    "Synchronous
*         MESSAGES INTO gt_messtab.

      IF gv_err_vl02n = 'X'.
*<--CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
* Call transaction VL02n failed for outbound delivery &.
        PERFORM sub_update_errors USING    uv_sale_ord
                                           'VL02N'
                                  CHANGING et_messages[].
      ENDIF.
    ENDIF.
*-->CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
**----------------Un-wanted line item deletion process - End----------*
*
*     ELSE.
* Call tranaction failed for tcode VL01N for SO &
*       PERFORM sub_update_errors USING    uv_sale_ord
*                                         'VL01N'
*                                 CHANGING et_messages[].
*     ENDIF.
*<--CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
  ELSE.
    PERFORM sub_update_errors USING    uv_sale_ord
                                       'VL01N'
                              CHANGING et_messages[].
  ENDIF.

ENDFORM.                                                  " sub_vl01

*&---------------------------------------------------------------------*
*&      Form  sub_update_errors
*&---------------------------------------------------------------------*
* Update error messages into output parameter
*----------------------------------------------------------------------*
*      <--ET_MESSAGES  Error log
*      -->uv_sale_Ord  Sales orde
*      -->uv_tx        Transaction Name
*----------------------------------------------------------------------*
FORM sub_update_errors  USING       uv_sale_ord LIKE lips-vgbel
                                    uv_tx       LIKE tstc-tcode
                        CHANGING    et_messages TYPE zca_bal_msg_tab.

  DATA:
    ls_messages TYPE bal_s_msg.

* call tranaction failed for tcode vl01n for so &
  ls_messages-msgty  = gc_error.
  ls_messages-msgid  = gc_msgid.
  IF uv_tx = 'VL01N'.
    ls_messages-msgno  = '104'.
  ELSE.
    ls_messages-msgno  = '216'.
  ENDIF.
  ls_messages-msgv1  = uv_sale_ord.
  ls_messages-msgv2  = space.
  ls_messages-msgv3  = space.
  ls_messages-msgv4  = space.
  APPEND ls_messages TO et_messages.
  CLEAR  ls_messages.

* Update all errors in the output table parameter ET_MESSAGES
  LOOP AT gt_messtab INTO gs_messtab.
    ls_messages-msgty  = gs_messtab-msgtyp.
    ls_messages-msgid  = gs_messtab-msgid.
    ls_messages-msgno  = gs_messtab-msgnr.
    ls_messages-msgv1  = gs_messtab-msgv1.
    ls_messages-msgv2  = gs_messtab-msgv2.
    ls_messages-msgv3  = gs_messtab-msgv3.
    ls_messages-msgv4  = gs_messtab-msgv4.
    APPEND ls_messages TO et_messages.
    CLEAR  ls_messages.
  ENDLOOP.

ENDFORM.                    " sub_update_errors
*-->CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
**&---------------------------------------------------------------------*
**&      Form  bdc_dynpro
**&---------------------------------------------------------------------*
** BDC Screen
**----------------------------------------------------------------------*
**      -->uv_prog     Screen Name
**      -->uv_dynpro   Screen Number
**----------------------------------------------------------------------*
*FORM bdc_dynpro  USING    uv_prog
*                          uv_dynpro.
*
*  CLEAR gs_bdcdata.
*  gs_bdcdata-program  = uv_prog.
*  gs_bdcdata-dynpro   = uv_dynpro.
*  gs_bdcdata-dynbegin = gc_true.
*  APPEND gs_bdcdata TO gt_bdcdata.
*
*ENDFORM.                    " bdc_dynpro
**&---------------------------------------------------------------------*
**&      Form  bdc_field
**&---------------------------------------------------------------------*
** Insert Field
**----------------------------------------------------------------------*
**      -->uv_fnam  Field Name
**      -->uv_fval  Field Value
**----------------------------------------------------------------------*
*FORM bdc_field  USING    uv_fnam
*                         uv_fval.
*
*  CLEAR gs_bdcdata.
*  gs_bdcdata-fnam = uv_fnam.
*  gs_bdcdata-fval = uv_fval.
*  APPEND gs_bdcdata TO gt_bdcdata.
*
*ENDFORM.                    " bdc_field
*&---------------------------------------------------------------------*
*&      Form  CREATE_OUTB_DELIVERY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM create_outb_delivery USING p_sales_ord
                                p_ship_point
                                p_sel_date
                                iv_inb_dlvry   TYPE likp-vbeln "33303
                                iv_dlk         TYPE char1      "33303
                                lt_outbound_data  TYPE zdl_bapidlvreftosalesorder_t.  "JWILL68 CD#1626

  DATA: lv_num_deliveries TYPE bapidlvcreateheader-num_deliveries,
*        lt_sales_ord_items TYPE TABLE OF bapidlvreftosalesorder, "JWILL68 CD#1626
        lt_extension_in   TYPE TABLE OF bapiparex,
        lt_deliveries     TYPE TABLE OF bapishpdelivnumb,
        lt_created_items  TYPE TABLE OF bapidlvitemcreated,
        lt_extension_out  TYPE TABLE OF bapiparex,
        lt_return         TYPE TABLE OF bapiret2,
        ls_return         TYPE bapiret2.
*        ls_sales_ord_items TYPE bapidlvreftosalesorder."JWILL68 CD#1626


* 33303-start
  DATA: ls_lips TYPE lips.
  DATA: ls_ekkn TYPE ekkn.

* DLK delivery
  IF iv_dlk = 'X'.
    PERFORM copy_inb_outb_z_fields USING    iv_inb_dlvry
                                   CHANGING lt_extension_in.
* Start of change  JWILL68 CD#1626 5/21/2019
*    SELECT SINGLE *
*      FROM lips
*      INTO ls_lips
*     WHERE vbeln = iv_inb_dlvry
*       AND posnr = '000010'.
*
*      IF sy-subrc = 0.
*
*        SELECT SINGLE *
*          FROM ekkn
*          INTO ls_ekkn
*         WHERE ebeln = ls_lips-vgbel
*           AND ebelp = ls_lips-vgpos
*           AND zekkn = '01'.

*          ls_sales_ord_items-ref_doc    = ls_ekkn-vbeln.
*          ls_sales_ord_items-ref_item    = ls_ekkn-vbelp.
*          ls_sales_ord_items-dlv_qty    = ls_lips-lfimg.
*          ls_sales_ord_items-sales_unit  = ls_lips-vrkme.
*        ENDIF.
    DATA(lt_sales_ord_items) = VALUE zdl_bapidlvreftosalesorder_t(
                                         FOR ls_so_item IN lt_outbound_data
                                      ( ref_doc    = ls_so_item-ref_doc
                                        ref_item   = ls_so_item-ref_item
                                        dlv_qty    = ls_so_item-dlv_qty
                                        sales_unit = ls_so_item-sales_unit ) ).

  ELSE.
** 33303-end
    lt_sales_ord_items = VALUE zdl_bapidlvreftosalesorder_t(
                                         FOR ls_so_item IN lt_outbound_data
                                      ( ref_doc    = p_sales_ord
                                        ref_item   = ls_so_item-ref_item
                                        dlv_qty    = ls_so_item-dlv_qty
                                        sales_unit = ls_so_item-sales_unit ) ).
*    ls_sales_ord_items-ref_doc = p_sales_ord.
* End of change  JWILL68 CD#1626 5/21/2019
  ENDIF.                                                        "33303
*  APPEND ls_sales_ord_items TO lt_sales_ord_items.
*  CLEAR ls_sales_ord_items.


  CLEAR gv_out_dlvry.
  CALL FUNCTION 'BAPI_OUTB_DELIVERY_CREATE_SLS'
    EXPORTING
      ship_point        = p_ship_point
      due_date          = p_sel_date
*     DEBUG_FLG         =
*     NO_DEQUEUE        = ' '
    IMPORTING
      delivery          = gv_out_dlvry
      num_deliveries    = lv_num_deliveries
    TABLES
      sales_order_items = lt_sales_ord_items
*     SERIAL_NUMBERS    =
      extension_in      = lt_extension_in
      deliveries        = lt_deliveries
      created_items     = lt_created_items
      extension_out     = lt_extension_out
      return            = lt_return.

  IF gv_out_dlvry IS NOT INITIAL.
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait   = 'X'
      IMPORTING
        return = ls_return.
  ENDIF.
  REFRESH: lt_sales_ord_items[], lt_extension_in[], lt_deliveries[],
           lt_created_items[], lt_extension_out[], lt_return[].
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHANGE_OUTB_DELIVERY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_OUT_DLVRY  text
*      -->P_LT_LIPS  text
*----------------------------------------------------------------------*
FORM change_outb_delivery  TABLES   lt_out_dlvry STRUCTURE lips
                                         lt_lips STRUCTURE lips.
  DATA:
    header_data    LIKE bapiobdlvhdrchg,
    header_control LIKE bapiobdlvhdrctrlchg,
    delivery       LIKE bapiobdlvhdrchg-deliv_numb,
    item_data      LIKE bapiobdlvitemchg      OCCURS 0 WITH HEADER LINE,
    item_control   LIKE bapiobdlvitemctrlchg  OCCURS 0 WITH HEADER LINE,
    return1        LIKE bapiret2              OCCURS 0 WITH HEADER LINE,
    wa_lips        TYPE lips.

  header_data-deliv_numb    = gv_out_dlvry.
  header_control-deliv_numb = gv_out_dlvry.

  LOOP AT lt_out_dlvry INTO DATA(ls_out).
    READ TABLE lt_lips TRANSPORTING NO FIELDS WITH KEY matnr = ls_out-matnr.
    IF sy-subrc <> 0.
      IF ls_out-posnr IS NOT INITIAL.  "Delete particular Delivery item
*-------Get Item Details.
        SELECT SINGLE vbeln posnr charg matnr lfimg umvkz umvkn
        INTO CORRESPONDING FIELDS OF wa_lips
        FROM lips
        WHERE vbeln = gv_out_dlvry
        AND posnr = ls_out-posnr.

        IF sy-subrc = 0.
          item_data-deliv_numb      = wa_lips-vbeln.
          item_data-deliv_item      = wa_lips-posnr.
          item_data-material        = wa_lips-matnr.
          item_data-dlv_qty         = wa_lips-lfimg.
*         item_data-dlv_qty_imunit  = wa_lips-lfimg.
          item_data-fact_unit_nom   = wa_lips-umvkz.
          item_data-fact_unit_denom = wa_lips-umvkn.
          item_data-batch           = wa_lips-charg.
          APPEND item_data.

          item_control-deliv_numb   = gv_out_dlvry.
          item_control-deliv_item   = ls_out-posnr.
          item_control-del_item     = 'X'.
          APPEND item_control.
          CLEAR wa_lips.
        ENDIF.
      ENDIF.
    ENDIF.
    CLEAR ls_out.
  ENDLOOP.

  CLEAR gv_err_vl02n.
  IF item_data[] IS NOT INITIAL AND
     item_control[] IS NOT INITIAL.

    CALL FUNCTION 'BAPI_OUTB_DELIVERY_CHANGE'
      EXPORTING
        header_data    = header_data
        header_control = header_control
        delivery       = gv_out_dlvry
      TABLES
        item_data      = item_data
        item_control   = item_control
        return         = return1.

    READ TABLE return1 WITH KEY type = 'E'.
    IF sy-subrc NE 0.
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
        EXPORTING
          wait = 'X'.
    ELSE.
      gv_err_vl02n = 'X'.
    ENDIF.
  ENDIF.

  CLEAR: header_data, header_control.
  REFRESH: item_data[], item_control[], return1.
ENDFORM.
*<--CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI

*&---------------------------------------------------------------------*
*&      Form  COPY_INB_OUTB_Z_FIELDS - added 33303
*&---------------------------------------------------------------------*
* Copy LIKP-ZZ_* fields from inbound to outbound delivery
* Extension fields will be processed via BADI's:
*	- ZDL_E03637_DLV_CREATE_SLS_EXT of BADI_DLV_CREATE_SLS_EXTIN,
*   method ADDITIONAL_INPUT
*	- ZDL_E03637_DELV_PROC of LE_SHP_DELIVERY_PROC,
*   method FILL_DELIVERY_HEADER.
*----------------------------------------------------------------------*
FORM copy_inb_outb_z_fields  USING    iv_vbeln TYPE likp-vbeln
                             CHANGING ct_ext   TYPE bapiparex_t.

  DATA: ls_likp  TYPE likp.
  DATA: ls_ext   TYPE bapiparex.

  SELECT SINGLE *
    FROM likp
    INTO ls_likp
   WHERE vbeln = iv_vbeln.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  ls_ext-structure = 'LIKP'.

  ls_ext-valuepart1 = 'ZZ_EXIT_PASS_NO'.
  ls_ext-valuepart2 = ls_likp-zz_exit_pass_no.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_SCAC'.
  ls_ext-valuepart2 = ls_likp-zz_scac.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_SIGNI'.
  ls_ext-valuepart2 = ls_likp-zz_signi.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_BALE_CNT'.
  ls_ext-valuepart2 = ls_likp-zz_bale_cnt.

  APPEND ls_ext TO ct_ext.
  ls_ext-valuepart1 = 'ZZ_BOL'.
  ls_ext-valuepart2 = ls_likp-zz_bol.

  APPEND ls_ext TO ct_ext.
  ls_ext-valuepart1 = 'ZZ_SCALE'.
  ls_ext-valuepart2 = ls_likp-zz_scale.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_COMPLETE'.
  ls_ext-valuepart2 = ls_likp-zz_complete.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_SHIP_DATE'.
  ls_ext-valuepart2 = ls_likp-zz_ship_date.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_GROSS_WT'.
  ls_ext-valuepart2 = ls_likp-zz_gross_wt.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_NET_WT'.
  ls_ext-valuepart2 = ls_likp-zz_net_wt.
  APPEND ls_ext TO ct_ext.

  ls_ext-valuepart1 = 'ZZ_TARE_WT'.
  ls_ext-valuepart2 = ls_likp-zz_tare_wt.
  APPEND ls_ext TO ct_ext.

ENDFORM.

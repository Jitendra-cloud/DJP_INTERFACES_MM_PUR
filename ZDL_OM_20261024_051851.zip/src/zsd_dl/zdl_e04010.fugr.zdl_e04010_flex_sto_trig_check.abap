FUNCTION zdl_e04010_flex_sto_trig_check.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(STO_HEADER) TYPE  EBELN
*"     VALUE(STO_ITEM) TYPE  EBELP
*"     VALUE(DELV_DOCU) TYPE  VBELN_VL OPTIONAL
*"     VALUE(REF_TYPE) TYPE  ZDL_REF_TYPE OPTIONAL
*"     VALUE(REF_DOCU) TYPE  TKNUM OPTIONAL
*"     VALUE(FLAG_STATUS) TYPE  ZDL_FPED_FLAG_STAT OPTIONAL
*"  EXPORTING
*"     VALUE(STATUS) TYPE  FLAG
*"     VALUE(EXCEPTION) TYPE  CHAR30
*"  TABLES
*"      STO_RESULTS STRUCTURE  ZDL_FPEDSTAT OPTIONAL
*"----------------------------------------------------------------------
************************************************************************
* Function Module:ZDL_E04010_FLEX_STO_TRIG_CHECK                       *
* Create Date: 12/19/2007                                              *
* Inventory   : E04010(FM)             Version:  V4R14 March 2009      *
*                                                                      *
* Programmer  : Padma Nimmala                                          *
*______________________________________________________________________*
* Description : V2-Flexible Shipmnt FPED Status/Date-Time based Trigger*
*               The Object has been implemented in two parts-          *
*            1. Validate Flexible Shipment STO Trigger                 *
*            2. based on FPED date&time/status change                  *
*     This Validation Check will happen from these places              *
*            FFD-Flexible Shipment FPED date & Time change             *
*            FFS-Flexible shipment FPED status change                  *
*            FDL-Flexible Shipment when Delivery gets created          *
*            FSH-Pre-planned Shipment deleted or delivery added/remove *
*            FFR-Flexible shipment FPED re-pegging                     *
*            FPR-Flexible shipment Production Order re-pegging         *
*______________________________________________________________________*
* Includes  :                                                          *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run    :                                                           *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer      Date     Req. #            Action                *
* ================  ========  =========    ============================*
* PNIMMAL           12/19/07  ESBK9A0660     Initial Version           *
* PNIMMAL           06/27/08  EDEK912214  V2  Rollback-EDEK912214      *
************************************************************************

************************************************************************
*--- Data Declarations
************************************************************************
  DATA: lv_belnr             TYPE ekbe-belnr,
        lv_status_flag       TYPE c.

************************************************************************
*--- Validations
************************************************************************

*---refreshing and clearing the variables
  REFRESH: gt_zppkiwi, gt_zppfped_status,
*           gt_zdl_fped_from_to,                "V2 Rollback By PNIMMALA
                                                "EDEK912214
           sto_results.
  CLEAR:   status,lv_belnr,lv_status_flag,gs_zdl_fpedstat.

*---Validate the STO and Delivery Numbers
  IF delv_docu IS INITIAL.      "Delivery number is blank
    SELECT SINGLE belnr FROM ekbe
               INTO lv_belnr
               WHERE ebeln = sto_header
                 AND ebelp = sto_item
                 AND vgabe = gc_vgabe.        "'8'
    IF sy-subrc NE 0 AND lv_belnr IS INITIAL.
      CLEAR status.
      MOVE text-002 TO exception.
      EXIT.
    ENDIF.
  ENDIF.

* Begin of V2 Rollback By PNIMMALA  06/27/2008 EDEK912214
**---Extract all the status from the zdl_fped_from_to Table
*  SELECT * FROM zdl_fped_from_to
*           INTO TABLE gt_zdl_fped_from_to.
*  IF sy-subrc NE 0.
*    MOVE text-001 TO exception.
*    EXIT.
*  ENDIF.
* End of V2 Rollback By PNIMMALA  06/27/2008 EDEK912214

*---If Flag,Curr & Prev are provided through import parameter
  if flag_status is not initial.

*---add the record with the status from import parameter and set the flag
    perform flag_status_change TABLES sto_results
                                 USING flag_status
                                       ref_type
                                       ref_docu
                                       sto_header
                                       sto_item
                              CHANGING status.   "Status import update

  else.
*---Get the FPED Status from ZPPKIWIFPED Table and ZPPFPED_STATUS Tables
*---Select the delivery numbers for the STO header and item
    SELECT werks
           aufnr
           vbeln
           posnr
           fped_date
           fped_time
* Begin of V2 Rollback By PNIMMALA   06/27/2008 EDEK912214
*           zprv_prod_status
*           zcur_prod_status
* End of V2 Rollback By PNIMMALA   06/27/2008 EDEK912214
           FROM zppkiwifped
           INTO TABLE gt_zppkiwi
           WHERE vbeln = sto_header
             AND posnr = sto_item.

*---If records exists extract one record from ZPPKIWIFPED
*--- and rest of the deliveries from ZPPFPED_STATUS Table
*---else only extract deliveries from ZPPFPED_STATUS
*---Update the Status check accordingly

    IF sy-subrc EQ 0.

*---changing the status and a updating a record of ZPPKIWIFPED Table
      PERFORM zppkiwifped_collect TABLES sto_results
                                   USING ref_type
                                         ref_docu
                                CHANGING status.   "Status import update


*---Select the delivery numbers from ZPPFPED_STATUS Table for STO
      IF status EQ gc_x.
        PERFORM zppfped_status TABLES sto_results
                               USING sto_header
                                     sto_item
                                     ref_type
                                     ref_docu.

      ENDIF.

    ELSE.   "If no records exists in ZPPKIWIFPED Table
**---Extract the deliveries from ZPPFPED_STATUS Table for STO
      PERFORM zppfped_status_collect TABLES sto_results
                                      USING sto_header
                                            sto_item
                                            ref_type
                                            ref_docu
                                   CHANGING status. "Status import update
    ENDIF.    "Extraction ZPPKIWIFPED endif
*---Sort and delete the adjacent duplicates
    SORT sto_results.
    DELETE ADJACENT DUPLICATES FROM sto_results.
  endif.

*--- After all the process if status is initial
  IF status IS INITIAL.
    MOVE text-001 TO exception.
  ENDIF.

ENDFUNCTION.

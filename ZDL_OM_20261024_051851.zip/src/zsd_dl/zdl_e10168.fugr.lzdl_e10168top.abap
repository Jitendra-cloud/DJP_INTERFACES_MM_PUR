FUNCTION-POOL ZDL_E10168.                   "MESSAGE-ID ..

* INCLUDE LZDL_E10168D...                    " Local class definition

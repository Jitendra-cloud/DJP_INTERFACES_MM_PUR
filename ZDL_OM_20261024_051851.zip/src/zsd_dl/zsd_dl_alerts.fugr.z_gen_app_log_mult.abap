FUNCTION z_gen_app_log_mult .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IS_LOG_HEADER) TYPE  BAL_S_LOG
*"  EXPORTING
*"     REFERENCE(IF_LOG_EXTID) TYPE  BALNREXT
*"     REFERENCE(IF_LOG_NUMBER) TYPE  BALOGNR
*"     REFERENCE(IF_LOG_HANDLE) TYPE  BALLOGHNDL
*"  TABLES
*"      IT_MESSAGES TYPE  ZCA_BAL_MSG_TAB
*"----------------------------------------------------------------------

*&---------------------------------------------------------------------*
*&  DATA DECLARATIONS
*&---------------------------------------------------------------------*
  DATA:
    go_applog TYPE REF TO zcl_ca_applogging.

* Application log close return
  DATA: x_lognum TYPE bal_s_lgnm,
        t_lognum TYPE bal_t_lgnm.

* Application Log identification numbers
  DATA: g_app_log_ext_id TYPE balnrext,
        g_app_log_nbr    TYPE balognr.

  DATA: g_flg_openlog. " Application log is open

*&---------------------------------------------------------------------*
*&  PROCESSING
*&---------------------------------------------------------------------*

**// open the application log
*// Create the logging object
  TRY.
      CREATE OBJECT go_applog
        EXPORTING
          is_log = is_log_header.
    CATCH zcx_ca_applog_init_failure .
  ENDTRY.

**// add all messages to the open log
  CALL METHOD go_applog->log_message_add_mult
    EXPORTING
      it_messages = it_messages[].

*// Save the logging
  TRY.
      CALL METHOD go_applog->log_save
        IMPORTING
          et_new_lognum = t_lognum[].
*// Modified by Savithri on 10/19/2006
       if_log_handle = go_applog->get_handle( ).

    CATCH zcx_ca_applog_log_not_found .
      RETURN.
    CATCH zcx_ca_applog .
      RETURN.
  ENDTRY.

  CLEAR x_lognum.
  READ TABLE t_lognum INDEX 1 INTO x_lognum.
  IF sy-subrc IS INITIAL.
    g_app_log_nbr  = x_lognum-lognumber.
  ENDIF.

ENDFUNCTION.

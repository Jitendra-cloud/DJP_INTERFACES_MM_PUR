*----------------------------------------------------------------------*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ================== ========   ======  ===============================*
* apunjaa            02/10/2017 CMS31541 Multiple changes to accomodate*
*                               Pensacola processing
*Dinesh Gandla      03/25/2025  S0VK910287   To update the COO in the  *
*Chanala           2000002371/ SCTASK0079209 Batch master              *
*----------------------------------------------------------------------*

FUNCTION-POOL zsd_dl_venasn.                "MESSAGE-ID ..
INCLUDE mbdconwf.                           "ALE constants
TYPE-POOLS zsdc.                            "Characteristics constants


*----------------------------------------------------------------------*
*  TYPES                                                              *
*----------------------------------------------------------------------*
*        PO information
TYPES: BEGIN OF gty_ekpo,
         segnum TYPE idocdsgnum,
         posnr  TYPE posnr,
         matnr  TYPE matnr,
         werks  TYPE ewerk,   "plant
         lgort  TYPE lgort_d, "storage loc
         charg  TYPE charg_d,
         ebeln  TYPE ebeln,   "corresponding PO number
         ebelp  TYPE ebelp,   "PO item number
       END OF gty_ekpo.

*--> Begin insert EDVK946089
TYPES: BEGIN OF gty_tr_po,
         ebeln         TYPE ebeln,        "PO2 - Market Price PO
         werks         TYPE werks_d,      "Plant on segment E1EDL24
         bsart         TYPE esart,        "Po type
         zz_trnpricepo TYPE z_trnpricepo, "PO1 - Transfer Price PO
         ebelp         TYPE ebelp,        "PO1 item number
         zz_ipco       TYPE z_ipco,       "IPCO number
         lifnr         TYPE elifn,        "Vendor
         ekorg         TYPE ekorg,        "Purch org for PO1
         vbeln         TYPE vbeln_co,     "corresp Sales Ord for PO1
         vbelp         TYPE posnr_co,     "corresp Sales Ord item PO1
         ib_delivery_1 TYPE vbeln_vl,     "Inbound Delivery number 1
         ib_delivery_2 TYPE vbeln_vl,     "Inbound Delivery number 2
         bolnr         TYPE bolnr,        "Bill of Lading Number
         l24_segnum    TYPE idocdsgnum,   "E1EDL24 idoc segment number
         l24_tabix     TYPE sytabix,      "tabix of E1EDL24 segments
         l43_segnum    TYPE idocdsgnum,   "E1EDL43 idoc segment number
         l43_psgnum    TYPE edi_psgnum,   "idoc parent segment number
         l43_tabix     TYPE sytabix,      "tabix of E1EDL43 segments
         ebelp2        TYPE ebelp,        "PO2 item number  "BCB02
         matnr         TYPE matnr,        "Material on PO item "BCB02
       END OF gty_tr_po,

       BEGIN OF gty_so,
         vbeln  TYPE vbeln_co,     "corresp Sales Ord for PO2
         vbelp  TYPE posnr_co,     "corresp Sales Ord item PO2
         kwmeng TYPE kwmeng,       "SO quantity
*
         ebeln  TYPE ebeln,                         "ASN2 PO
         ebelp  TYPE ebelp,        "ASN2 corresponding PO item
         matnr  TYPE matnr,        "ASN2 Material
         charg  TYPE charg_d,                       "ASN2 Batch
         lfimg  TYPE lfimg,        "ASN2 quantity
       END OF gty_so.
*--> End insert EDVK946089

TYPES: BEGIN OF gty_assign,
         exidv    TYPE  exidv,   "external HU
         vpobj    TYPE  vpobj,   "Object type the HU is assigned to
         vpobjkey TYPE vpobjkey, "Object HU is assgined to
       END OF gty_assign.

* Begin BCB08
TYPES:

*   Holds HU header data for HU creation
  BEGIN OF gts_l37,
    exidv    TYPE exidv, "HU
    vhilm    TYPE vhilm, "Packaging Material
    vhilm_ku TYPE vhilm_ku, "Vendor HU
  END OF gts_l37,

*   Holds HU item data for HU creation
  BEGIN OF gts_l44,
    exidv TYPE exidv, "HU
    werks TYPE werks_d, "Plant
    vemng TYPE vemng,    "HU qty
    vemeh TYPE vemeh,    "HU uom
    matnr TYPE matnr,    "material
    charg TYPE charg_d,  "batch
  END OF gts_l44,

*   HU Xref table
  BEGIN OF gts_hu_xref,
    orig_exidv TYPE exidv,  "Original HU
    kdmat      TYPE kdmat,  "Vendor Batch
  END OF gts_hu_xref.
* End BCB08

* Begin BCB09
* Types to store PO and Vendor
TYPES: BEGIN OF gts_ekko,
         ebeln TYPE ebeln,             " PO
         lifnr TYPE elifn,             " Vendor
       END OF gts_ekko.
* End BCB09
TYPES: BEGIN OF gts_ekpo_b,              "Brazil ASN
         ebeln TYPE ebeln,             " PO
         ebelp TYPE ebelp,             "Item
         matnr TYPE matnr,             "Material
         werks TYPE werks_d,           "Plant
         lgort TYPE lgort_d,           "Storage location
       END OF gts_ekpo_b.

* Begin of changes DGANDLA 2000002371 /SCTASK0079209

TYPES: BEGIN OF ty_batch_coo,
         charg TYPE charg_d,
         cntry TYPE landt,
       END OF ty_batch_coo.
* End of changes DGANDLA 2000002371 /SCTASK0079209


*----------------------------------------------------------------------*
*  TABLES                                                              *
*----------------------------------------------------------------------*
TABLES:
  likp,          "Delivery Header
  mara,          "General Material Data
  ekpo,          "Purchasing Document Item
  zdl_uniqueid,  "Parameter table for unique-id create E03126
  zfm_batch_status. "O/p parameter table for BATCH03 IDoc create FM


*----------------------------------------------------------------------*
*  STRUCTURES / TABLES                                                 *
*----------------------------------------------------------------------*
*  IDoc data
DATA:
  gs_idoc_ctrl   LIKE  edidc,        "IDoc Control record
  gs_idoc_data   LIKE  edidd,        "IDoc data
  gs_idoc_status LIKE  bdidocstat.   "IDoc status

DATA:
* Filtered Idocs
  gs_idoc_ctrl_filter    LIKE  edidc,
  gs_idoc_data_filter    LIKE  edidd,
  gs_idoc_status_filter  LIKE  bdidocstat,
* Process continued
  gs_idoc_ctrl_process   LIKE  edidc,
  gs_idoc_data_process   LIKE  edidd,
  gs_idoc_status_process LIKE  bdidocstat.


DATA:

*   Segments referenced in DELVRY03
  gs_e1edl20        TYPE  e1edl20,    "Delivery Header
  gs_e1edl24        TYPE  e1edl24,    "Delivery Item
  gs_e1edl43        TYPE  e1edl43,    "PO details
  gs_e1edl15        TYPE  e1edl15,    "IDOC: Batch Characteristic
  gs_e1edl37        TYPE  e1edl37,    "Handling unit header
  gs_e1edl44        TYPE  e1edl44,    "Handling unit item
  gs_e1edl41        TYPE  e1edl41,    " Idoc Segment
  gs_e1edl26        TYPE  e1edl26,    " Idoc Segment
  gs_e1edl12        TYPE  e1edl12,    " idoc segment
  gs_e1adrm1        TYPE  e1adrm1,    " idoc segment
  gs_e1edt13        TYPE  e1edt13,    " Shipment date

*   Workareas/table - I/p para table for BATCH03 IDoc create FM
  gs_mbpsv          TYPE zfm_batch_tab,
  gt_mbpsv_chars    TYPE zfm_chars_tab WITH HEADER LINE,

*   Workarea for gt_conf_out,
  gs_conf_out       TYPE conf_out,

  gs_vbkok          TYPE vbkok,   "confirm picking structure

*   Handling units structure
  gs_handling_units TYPE hum_rehang_hu,

*   Default Data for Creating a Handling Unit
  gs_headerproposal TYPE bapihuhdrproposal,

*   Default for HU Item Creation
  gt_itemsproposal  TYPE STANDARD TABLE OF bapihuitmproposal,
  gs_itemsproposal  TYPE bapihuitmproposal,

*   PO item data
  gt_ekpo           TYPE STANDARD TABLE OF gty_ekpo,
  gs_ekpo           TYPE gty_ekpo,

*   BAPI Return Table
  gt_return         TYPE STANDARD TABLE OF bapiret2,
  gs_return         TYPE bapiret2.

* Begin BCB08
DATA:

*   Holds HU header data for HU creation
  gt_l37     TYPE STANDARD TABLE OF gts_l37,
  gs_l37     TYPE gts_l37,

*   Holds HU item data for HU creation
  gt_l44     TYPE STANDARD TABLE OF gts_l44,
  gs_l44     TYPE gts_l44,

*   Hold Original HU (which will always equal the lowest Vendor Batch
*   Number) and the associated Vendor Batch.
  gt_hu_xref TYPE STANDARD TABLE OF gts_hu_xref,
  gs_hu_xref TYPE gts_hu_xref.
* End BCB08

* Begin BCB09
* Types to store PO and Vendor
DATA: gt_ekko TYPE STANDARD TABLE OF gts_ekko,
      gs_ekko TYPE gts_ekko.
* End BCB09
* Types to store PO line item details  (Brazil ASN)
DATA: gt_ekpo_b TYPE STANDARD TABLE OF gts_ekpo_b,
      gs_ekpo_b TYPE gts_ekpo_b.


*--> Begin insert EDVK946089
DATA:

*   Segments referenced in SDPIID01 for picking
  gs_e1vpdlh TYPE  e1vpdlh,    "Picking Header
  gs_e1vpdli TYPE  e1vpdli,    "Picking Item

  gt_tr_po_h TYPE STANDARD TABLE OF gty_tr_po,   "PO work header table
  gs_tr_po_h TYPE gty_tr_po,

  gt_tr_po_i TYPE STANDARD TABLE OF gty_tr_po,   "PO work item table
  gs_tr_po_i TYPE gty_tr_po,

  gt_so      TYPE STANDARD TABLE OF gty_so,           "SO info for PO2
  gs_so      TYPE gty_so,

*   Log for Picking Report
  gt_prot    TYPE STANDARD TABLE OF prott,
  gs_prot    TYPE prott,

  gs_vbpok   TYPE vbpok,   "confirm picking structure
  gt_vbpok   TYPE STANDARD TABLE OF vbpok, "table of vbpok

*   BDC data table
  gt_bdcdata TYPE STANDARD TABLE OF bdcdata,
  gs_bdcdata TYPE bdcdata,

*   BDC messages
  gt_messtab TYPE STANDARD TABLE OF bdcmsgcoll,
  gs_messtab TYPE bdcmsgcoll.


DATA:

*   Table for HU assignment info
  gt_assign TYPE STANDARD TABLE OF gty_assign,
  gs_assign TYPE gty_assign.

* Begin BCB11 insert
* Add global ZDL_TRADES structure and internal table
DATA:

  gs_trades TYPE zdl_trades,
  gt_trades TYPE STANDARD TABLE OF zdl_trades.
* End BCB11 insert

*Begin of changes DGANDLA 2000002371/ SCTASK0079209
DATA: gt_batch_coo TYPE TABLE OF ty_batch_coo,
      gs_batch_coo TYPE ty_batch_coo.
*End of chnages DGANDLA 2000002371/ SCTASK0079209

DATA:

*   Idoc control record structure for IDOC_INBOUND_SINGLE
  gs_idoc_contrl40 TYPE edi_dc40, "edidc,

*   Idoc data structure for IDOC_INBOUND_SINGLE
  gt_idoc_data40   TYPE STANDARD TABLE OF edi_dd40, "edidd,
  gs_idoc_data40   TYPE edi_dd40, "edidd,

*   Variables for IDOC_INBOUND_SINGLE
  gv_segnum        TYPE idocdsgnum, "idoc segment number
  gv_idoc_num      TYPE edi_docnum,
  gv_error_app     TYPE edi_errflg.

CONSTANTS:

  gc_8530    TYPE  werks_d     VALUE '8530', "plant 8530 is Trades

  gc_e1vpdlh TYPE  edilsegtyp  VALUE  'E1VPDLH',   " Picking hdr
  gc_e1vpdli TYPE  edilsegtyp  VALUE  'E1VPDLI'.   " Picking item

*--> End insert EDVK946089

*----------------------------------------------------------------------*
*  CONSTANTS                                                           *
*----------------------------------------------------------------------*
*  Messages and Segments
CONSTANTS:

*   Valid Message Types
  gc_zdl_vasn       TYPE  edilsegtyp  VALUE  'ZDL_VASN', "Vendor ASN
  gc_zdl_pasn       TYPE  edilsegtyp  VALUE  'ZDL_PASN', "Portal ASN
  gc_zdl_mts_mtoasn TYPE  edilsegtyp  VALUE 'ZDL_MTS_MTOASN', "MTO/MTS

  gc_delvry03       TYPE edilsegtyp  VALUE  'DELVRY03', "DELVRY03 MESTYP
  gc_e1edl20        TYPE  edilsegtyp  VALUE  'E1EDL20',  "Del.Header
  gc_e1edl24        TYPE  edilsegtyp  VALUE  'E1EDL24',  "Del. Item
  gc_e1edl43        TYPE  edilsegtyp  VALUE  'E1EDL43',  "PO Details
  gc_e1edl15        TYPE  edilsegtyp  VALUE  'E1EDL15',  "Batch chara
  gc_e1edl37        TYPE  edilsegtyp  VALUE  'E1EDL37',  "HUheader
  gc_e1edl44        TYPE  edilsegtyp  VALUE  'E1EDL44',  "HUItem

  gc_e1adrm1        TYPE  edilsegtyp  VALUE  'E1ADRM1',   " segment type
  gc_e1edl12        TYPE  edilsegtyp  VALUE  'E1EDL12',   " segment type
  gc_e1edl41        TYPE  edilsegtyp  VALUE  'E1EDL41',   " segment type
  gc_e1edl26        TYPE  edilsegtyp  VALUE  'E1EDL26',   " segment type
  gc_fin_run        TYPE  edilsegtyp  VALUE  'FINAL_RUN_DELVRY', "FinalRunDel
* Brazil ASN.
  gc_e1edt13        TYPE  edilsegtyp  VALUE  'E1EDT13'.  "Shipment date


*  Operational constants
CONSTANTS:
  gc_true              TYPE  boolean VALUE 'X',   "True
  gc_false             TYPE  boolean VALUE '-',   "False
  gc_lfart             TYPE  lfart   VALUE 'ZEL', "Delivery type
  gc_prefix_ebeln      TYPE  string  VALUE 'I', "Changed on 02/03/06
  gc_hu_status         TYPE  hu_status VALUE '0060', " HU status

* HU assignment objects
  gc_outbound_delivery TYPE  vpobj  VALUE '01',   "Assigned to outb delv
  gc_inbound_delivery  TYPE  vpobj  VALUE '03',   "Assigned to inb delv
***** hmalkow - start
  gc_non_assigned      TYPE vpobj VALUE '12'.  "Non-Assigned HU
***** hmalkow - end

*----------------------------------------------------------------------*
*  VARIABLES                                                           *
*----------------------------------------------------------------------*

DATA:
  gv_subrc            LIKE  sy-subrc,  "Work variable for subrc
  gv_idoc_error       TYPE  boolean,   "Idoc has error flag
  gv_trigger_wf       TYPE  boolean,   "Trigger Workflow   BCB10
  gv_usd_created      TYPE  boolean,   "CR-8050-FIX3
  gv_fail             TYPE  boolean,
  gv_inb_vbeln_exists TYPE boolean, "inb deliv exists flag
  gv_ib2_exists       TYPE boolean, "inb 2 deliv exist flag EDVK949484
  gv_tabix            LIKE  sy-tabix,  "Current row index work var
  gv_ebeln            LIKE  ekpo-ebeln, "PO number
  gv_out_vbeln        TYPE  vbeln,      "outbound delivery
  gv_inb_vbeln        TYPE  vbeln.      "inbound delivery number


DATA: gv_werks           TYPE werks_d,  "plant
      gv_lgort           TYPE lgort_d,  "sloc
      gv_e1edl24_segnum  TYPE idocdsgnum, "idoc segment number
      gv_ekpo_ebelp      TYPE ebelp,    "po line item
      gv_ekpo_ebeln      TYPE ebeln,    "po number

*     Outbound Delivery number created from Trades ASN1
      gv_asn1_outb_vbeln TYPE vbeln,                        "EDVK946089

*     Trades ASN against PO2
      gv_trades_asn1     TYPE  boolean,                     "EDVK946089
*     Trades ASN against PO1
      gv_trades_asn2     TYPE  boolean.                     "EDVK946089

*----------------------------------------------------------------------*
*  INTERNAL TABLES                                                     *
*----------------------------------------------------------------------*
DATA:
  gt_idoc_data   LIKE  TABLE OF edidd,          "IDoc data
  gt_idoc_status LIKE  TABLE OF bdidocstat,     "IDoc status
  gt_edids       LIKE  TABLE OF edi_ds
                    WITH HEADER LINE.  "IDoc status in EDIDS form

DATA: gt_mbh      LIKE   TABLE OF zdl_uniqueid
                         WITH HEADER LINE,   "E03126 - uniqueid crea
      gt_mbpsv    LIKE   gs_mbpsv WITH HEADER LINE,
      gt_bat_char LIKE   gs_mbpsv WITH HEADER LINE,
      gt_mbis     LIKE   TABLE OF zfm_batch_status
                         WITH HEADER LINE,   "BATCH03 IDoc - o/p para
      gt_bapi     LIKE   TABLE OF bapiret2
                         WITH HEADER LINE,   "BATCH03 IDoc- error o/p
      gt_conf_out TYPE STANDARD TABLE OF conf_out,


*  To hold tabix of material, batch, batch indicator, HU and PO
      BEGIN OF gt_mbhp_tab  OCCURS 0,
        matnr   LIKE  mara-matnr,
        24tabix LIKE  sy-tabix,
        44tabix LIKE  sy-tabix,
        nmatnr  LIKE  mara-matnr,
*       Begin CR-8050 - need charg to be 20 in case Vendor Batch is
*                       is greater than 10 bytes
        charg   LIKE  vekp-exidv,  "stores Vendor Batch
*       End CR-8050
        ncharg  LIKE  mch1-charg,  "stores SAP Batch
        exidv   LIKE  vekp-exidv,
        37tabix LIKE  sy-tabix,
        nexidv  LIKE  vekp-exidv,
        ebeln   LIKE  ekpo-ebeln,
        ebelp   LIKE  ekpo-ebelp,
        43tabix LIKE  sy-tabix,
        werks   LIKE  ekpo-werks,
        lgort   LIKE  ekpo-lgort,
      END OF gt_mbhp_tab,

*  Work table for fetching material number
      BEGIN OF  gt_temp_mat OCCURS 0,
        matnr      LIKE  mara-matnr,
        cuobf      LIKE  mara-cuobf,
        xchpf      LIKE  mara-xchpf,
        mtart      LIKE  mara-mtart,
        ebeln      LIKE  ekpo-ebeln,
        ebelp      LIKE  ekpo-ebelp,
        werks      LIKE  ekpo-werks,
        lgort      LIKE  ekpo-lgort,
        matkl      LIKE  ekpo-matkl, "Material Group
        atwrt      LIKE  cawn-atwrt, "roll width value
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102016|START
        rolldia    TYPE  cawn-atwrt, "Unformatted roll diameter
        rollwid    TYPE  cawn-atwrt, "Unformatted roll width
        atwrt1     TYPE  cawn-atwrt, "Metric roll width value
        meins      TYPE  ekpo-meins,
* CMS31541|ChangedBy:APUNJAA|ChangedOn:02102016|END
        knttp      LIKE  ekpo-knttp, "acct assignment category BCB03
        cuobj      LIKE  ekpo-cuobj, "Configuration object for Char
        omd_ind    LIKE  zplant-omd_ind, "plant omd indicator  BCB03
        unit_code  LIKE  cawn-atwrt,     "Unit code  "CR-8050
        order_link LIKE cawn-atwrt,     "Order Link for DPR
        43tabix    TYPE  sytabix,    "idoc segment of corres E1EDL43 seg
      END OF gt_temp_mat,

* Work table for Loacked POs
      BEGIN OF gt_locked_pos OCCURS 0,
        ebeln LIKE ekko-ebeln,
      END OF gt_locked_pos,

* HU tables
      gt_handling_units TYPE STANDARD TABLE OF hum_rehang_hu.
DATA: gt_mbhp_tab2 LIKE gt_mbhp_tab OCCURS 0 WITH HEADER LINE.
*      Type structure of Handling Unit Header data
TYPES: BEGIN OF gty_hu,
         exidv TYPE exidv,     "HU external number
       END OF gty_hu.

DATA: gt_hu TYPE STANDARD TABLE OF gty_hu,
      gs_hu TYPE gty_hu.
DATA: gv_parnr_ppr(5).
* Begin CR-8050
* Additional Data Declaration
CONSTANTS: gc_ppr(3) VALUE 'PPR',
* End CR-8050
* Begin CR-8805/8806
* Additional data declaration
           gc_bzl(3) VALUE 'BZL'.
DATA : gv_parnr_bzl(3).
*  Work table for Weight of Pallets
DATA: BEGIN OF gt_marm OCCURS 0,
        matnr LIKE  marm-matnr,
        meinh LIKE  marm-meinh,
        umrez LIKE  marm-umrez,
        umren LIKE  marm-umren,
      END OF gt_marm,
      gt_zdl_fields LIKE STANDARD TABLE OF zdl_fields WITH HEADER LINE.

DATA: gt_zdl_fields_matkl LIKE zdl_fields OCCURS 0 WITH HEADER LINE,
      gv_wait_sec         TYPE i,
      gv_do_loop          TYPE i,
*Begin of changes pragup1 06/15/2012 CHG136783
      gv_chk_multiple_usd. "usd created already for this idoc
*End of changes pragup1 06/15/2012 CHG136783

*Begin of changes rsured1 08/19/2015 CMS 28753
TYPES: BEGIN OF gty_hu_tmp,
         batch_num TYPE exidv,
         exidv     TYPE inhalt,
       END OF   gty_hu_tmp.
TYPES: BEGIN OF gty_deliv,
         vbeln    TYPE vbeln,
         batch_no TYPE  charg_d,
         lichn    TYPE lichn,
       END OF   gty_deliv,
       BEGIN OF gty_mbh_tmp,
         bolnr TYPE bolnr,
         exidv TYPE lichn,
       END OF gty_mbh_tmp.

DATA: gt_hu_tmp  TYPE STANDARD TABLE OF gty_hu_tmp,
      gs_hu_tmp  TYPE gty_hu_tmp,
      gt_deliv   TYPE STANDARD TABLE OF gty_deliv,
      gs_deliv   TYPE gty_deliv,
      gt_mbh_tmp TYPE STANDARD TABLE OF gty_mbh_tmp,
      gs_mbh_tmp TYPE gty_mbh_tmp.

*End of changes rsured1 08/19/2015 CMS 28753

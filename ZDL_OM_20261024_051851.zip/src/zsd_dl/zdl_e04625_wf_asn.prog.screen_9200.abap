
PROCESS BEFORE OUTPUT.
* Initialize variables
  MODULE init_9200.
* Set gui status & titlebar
  MODULE status_9200.

PROCESS AFTER INPUT.
* The Cancel button (red X) will be defined with a
*  function type of 'E' on our pf-status.
  MODULE cancel_9200 AT EXIT-COMMAND.
* Handle user interaction
  MODULE user_command_9200.

************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2007                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: VTTS Z TRANSCATION              Create Date: 05/14/07  *
*                                                                      *
* SAP Name    : Z03732_VTTS_Z_TRANSCATION_TOP        Version    :      *
*                                                                      *
* Programmer  : Naveen Parchuri                                        *
* Kishore Thakur      08/12/08  CR-8022  - Implemented gate Exit       *
*                               Reversal logic for external and Z03732 *
*                               Added a Reverse button in screen 303   *
*                               for gate-exit reversal.                *
*                               Transport# EDEK912945                  *
*                               Transport# EDEK913754                  *
* Kishore Thakur/Padma Sunkara  11/05/08  pricef  -E07126, E07127      *
*                               Added functionality for updating dock  *
*                               and trailer id(container id) in        *
*                               screen 303 and in screen 304 added     *
*                               the functionality to capture the intent*
*                               if the user is requested or confirmed  *
*                               and set the code for qualifier         *
*                               accordingly(i.e.IDOC for behalf of     *
*                               distribution center in pickup          *
*                               appointment date/time window.          *
*                               Transport# ESBK9A07VO                  *
*                                                                      *
* Bruce Ballehr BCB01 12/17/08  R02740 Daily Shipping Report Changes   *
*                                                                      *
*                               Transport EDVK967185                   *
*                               The Daily Shipment Report, Transaction *
*                               ZDLR02740, will call this program if a *
*                               user double-clicks on an ALV Grid      *
*                               record for a Shipment / Shipment Stage.*
*                               The business wants the user to come    *
*                               into this Extended Shipment Stage      *
*                               Maintenance program in the following   *
*                               way:                                   *
*                               - Skip screens 0100 and 0200           *
*                               - Be brought directly into screen 0300 *
*                                 - and subscreen 0303 (Dispatch tab)  *
*                                 - in Change mode                     *
*                               A Non-Display field, Shipment Stage'   *
*                               will be added to to screen 0100. If a  *
*                               value is passed in, which there will   *
*                               be coming from the Daily Shipment     .*
*                               Report program, then this new logic    *
*                               will know to skip down to screen 0300  *
*                               subscreen 0303.                        *
*                               Program tag BCB01 will denote these    *
*                               program changes.                       *
*                               TPR # 30092  Transport# EDVK969175     *
*                                                                      *
* Bruce Ballehr BCB02 05/27/09  R02740 Daily Shipping Report Changes   *
*                                                                      *
*                               TPR 03990 EDVK971550                   *
*                               I set a Parameter Id 'ZTN' for the     *
*                               Stage Number within the DSR just before*
*                               getting into the Big Button. When I    *
*                               arrive in the BB, I Get the Parameter  *
*                               'ZTN' and if it has a value I set it to*
*                               the Stage and go right to the Dispatch *
*                               tab in change mode. When the user exits*
*                               the BB, the first thing the DSR does is*
*                               Clear the Parameter Id 'ZTN'.          *
*                               Unbeknownst to me, the process used by *
*                               some of the folks is as follows:       *
*                               Process the DSR and "stay in" the      *
*                               report. Then they may go into the Big  *
*                               Button in another session. If they do  *
*                               this, the Parameter Id 'ZTN' is STILL  *
*                               SET to the Stage number and, thus, will*
*                               "think" it's being called by the DSR   *
*                               and go right into the Dispatch tab. SO,*
*                               the program change is to clear the     *
*                              'ZTN' Paramber Id in the BB just after  *
*                              it is retrieved and the Stage is stored *
*                              in the global field gv_tsnum. Should    *
*                              work fine in all scenarios now          *
* Kishor Thakur                CHG102464 TR#E0VK952755                 *
*                              added LFIMG to VBUP internal table
* Kishor Thakur/Padma Sunkara  Begin of R16I Big Button Update Staging *
*                              Area changes 10/13/09                   *
*                                                                      *
* Bruce Ballehr BCB03 12/17/09 V6W3 July 2010 --> CR9652 EDEK916174    *
*                                                                      *
*                              DSD / Big Button Enhancements           *
*                              - Validate Pick & Delivery Quantities   *
*                                are the same when the BOL button is   *
*                                clicked.                              *
*                              - 24:00:00 is an invalid time           *
*                              - If the PRO# has a value of 'APO' then *
*                                it means the Shipment was created in  *
*                                APO. Make the following changes:      *
*                                1. Display mode - if the value is     *
*                                   'APO' blank it out for display and *
*                                   do not trigger a db update.        *
*                                2. For comparison purposes, make the  *
*                                   value blank if it's 'APO'.         *
*                              - In subroutine check_dock_door, added  *
*                                logic so that if the user changes the *
*                                dock door, we validate that open TO's *
*                                do not exist for the Deliveries on    *
*                                the Stage in question. If so, we      *
*                                display an error to the user.         *
*                                                                      *
* Bruce Ballehr BCB04 03/01/10 V6W3 July 2010 --> TPR37150 EDVK975423  *
*                                                          EDVK975526  *
*                                                                      *
*                              Error: If user changes the Dock Door OR *
*                              Staging Area (on screen 0303 [Dispatch  *
*                              tab]) then hits the Enter button the    *
*                              Dock Door value and Staging Area value  *
*                              reverts back to their previous value.   *
*                                                                      *
*                              Error: If come into Big Button from the *
*                              DSD they sy-ucomm defaults to 'ENTR' so *
*                              have to take that into account with the *
*                              fix above.                              *
*                                                                      *
*                              If its a Staging Area Shipment (where a *
*                              Staging Area exists) then we are        *
*                              allowed to have an optional Dock Door.  *
*                              The "new" rule is that if this is a     *
*                              Staging Area load and Open TO's exist   *
*                              the user can still change the optional  *
*                              Dock Door (but still cannot change the  *
*                              Staging Area if Open TO's exist).       *
*                              So, this change is: If a Staging Area   *
*                              exists and a Dock Door exists and Open  *
*                              TO's exist then ALLOW user to change    *
*                              the Dock Door.                          *
*                                                                      *
*                              * Search program tag BCB04 for this fix *
*                                                                      *
* Bruce Ballehr BCB05 03/08/10 V6W3 July 2010 --> TPR37232 EDVK975614  *
*                                                                      *
*                              Error: If user spaces out the Dock Door *
*                              or Staging Area (on screen 0303         *
*                              [Dispatch tab]) then hits the Enter     *
*                              button the Dock Door value and Staging  *
*                              Area value reverts back to their        *
*                              previous value.                         *
* Bruce Ballehr BCB06 05/11/10 V6W3 July 2010 --> TPR38151 EDVK976992  *
*                                                                      *
*                              If unpicking, the quantity for Case     *
*                              picking must be subtracted. This change *
*                              removes unpicked doc flow.              *
* Bruce Ballehr BCB07 05/12/10 V6W3 July 2010 --> TPR38151 EDVK977022  *
*                                                                      *
*                              SELECT / INTO FOR ALL ENTRIES removes   *
*                              dups from the internal table you are    *
*                              selecting into. Need to add VBFA keys   *
*                              so that those entries are not deleted.  *
*                                                                      *
* Bruce Ballehr BCB08 08/23/10 b/f USD5575589 --> CO11631  E0VK976159  *
*                                                                      *
*                              When retrieving LIPS records we need to *
*                              ignore all of the LIPS records having   *
*                              an Item Category (lips-pstyv) of TATX   *
*                              as this is causing validation issues.   *
* Sukanya    11/02/2017        CMS#32822:Big button heuristic check    *
*                               box adddition to screen                *
* Sukanya      04/2/2018       CMS#33493: Heuristic protection checkbox*
*                              Production fix-Icon change              *
*____________________________________________________________________  *

program  z0372_vtts_z_transcation                                    .
type-pools : slis, zmos,vrm. "  Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.

*----------------------------------------------------------------------*
*                        T A B L E S
*----------------------------------------------------------------------*

tables : vttk,
         tvtkt,
         ttdst,
         lfa1,
         tvsbt,
         rv56a,
         vtts,
         t30b,    " Transport # ESBK9A07VO  R13W  E07126,
         tvswz,   "Shipping Points per Plant TR#E0VK952755 kthakur+
         zplant,  "Custom Plant Master Table TR#E0VK952755 kthakur+
* E07127 (WM) Z03732  transaction.
         t30c. " //psunkar 10/13/2009

types ltr_expvz type range of eikp-expvz.                   "CMS29557

*---------------------------------------------------------------------*
* Screen fields
*---------------------------------------------------------------------*
data:
  scr_sttrg(60)      ,
  gv_tknum               type tknum,
  gv_heur_protect        type zdl_heur_protect,             "CMS 32822
  scr_dep_pt(30)     ,
  scr_des_pt(30)     ,
  gv_change(1)       ,
  gv_display(1)      ,
  scr_dep_pt_des(30) ,
  scr_des_pt_des(30) ,
  gv_user                type symsgv,
  gv_index               type sy-index,
  gv_lines               type i,
  gv_answer              type c,
  gv_commit              type c,
  scr_txt_org(30)        type c,
  scr_txt_dest(30)       type c,
  gv_code                like tstc-tcode,
  scr_dtz                like vtts-zz_dep_tz,
  scr_app(70)            type c,
  scr_timza              like vtts-zz_dest_tz,
  gv_save                type  c,
  des_mos                type char50,
  gv_vstel               type vstel,       "Kthakur
  gv_stage_authority     type c, "psunkar Transport# EDEK911301
  gv_gate_exit_rev_auth  type c, " 03/23/09 Transport# EDVK969540
  gv_mescod              type  edi_mescod, "psunkar 08/12/08 Transport# EDEK912945
* Begin of changes 11/05/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
  scr_dock_door(30),
  scr_txt_door(25),
  gv_signi_old           type vttk-signi,
  gv_vbeln               type vbeln_vl,
  scr_dock_desc(25),
* End of changes 11/05/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
  "gv_lowval type ZSP_LOWVAL.
*//Begin of R16I Big Button Update Staging Area changes 10/13/09
  scr_staging_area(30),
  scr_stagearea_desc(30),
  gv_exti2_old           type vttk-exti2.
*//End of R16I Big Button Update Staging Area changes 10/13/09
data:
  gv_tsnum  type tsnum. "Stage Number  BCB01

*---------------------------------------------------------------------*
* Constants
*---------------------------------------------------------------------*
constants:
  gc_x         type char1         value 'X',          "BCB03
  gc_a         type char1         value 'A',                "CMS#32822
  c_back       type sy-ucomm      value 'BACK',
  c_cancel     type sy-ucomm      value 'CANCEL',
  c_exit       type sy-ucomm      value 'EXIT',
  gc_rev(3)    type c             value 'REV', "psunkar08/12/08
  gc_tatx      type pstyv_vl      value 'TATX',       "BCB08
  " Transport# EDEK912945
* Begin of changes 12/11/08 Transport# EDVK967185
  gc_category  like zdl_fields-category  value 'I02415',
  gc_fieldname like zdl_fields-fieldname value 'SHPSTAT_RETRY_TIME'.
* End of changes 12/11/08 Transport# EDVK967185


************************************************************************
*                    EVENT DECLARATION                                 *
************************************************************************
class lcl_event_receiver definition deferred.

*----------------------------------------------------------------------*
* ALV data declaration
*----------------------------------------------------------------------*
data:     event_receiver type ref to lcl_event_receiver.

****************************************************************
* LOCAL CLASSES: Definition
****************************************************************
*===============================================================
* class lcl_event_receiver: local class to handle event DOUBLE_CLICK
*
* Definition:
* ~~~~~~~~~~~
class lcl_event_receiver definition.

  public section.
    methods:

      handle_double_click
                    for event double_click of cl_gui_alv_grid
        importing e_row e_column.

  private section.

endclass.                    "lcl_event_receiver DEFINITION
************************************************************************
*                    OBJECT DECLARATION                                *
************************************************************************
data: go_custom_container type ref to cl_gui_custom_container,
      gv_container        type scrfname value 'GV_CUSTOM',
      go_grid             type ref to cl_gui_alv_grid.

data:gt_reuse_fcat type slis_t_fieldcat_alv.

data: gt_fieldcat type lvc_t_fcat,
      gw_fieldcat like lvc_s_fcat,
      gs_layout   type lvc_s_layo.

types : begin of gs_stages             ,
          tsnum         like vtts-tsnum,
          tsrfo         like vtts-tsrfo,
          vstel         like vtts-vstel,
          lifna         like vtts-lifna,
          kunna         like vtts-kunna,
          vstez         like vtts-vstez,
          lifnz         like vtts-lifna,
          kunnz         like vtts-kunnz,
          sttrg         like vtts-zz_sttrg,
          zz_stoptype_o type zdl_stpty_o,
          zz_stoptype_d type zdl_stpty_d,
        end of gs_stages.

*internal table to hold stage details
data : gt_stages type standard table of gs_stages.

* table to hold changed values
data : begin of gt_vtts_old.
        include structure vtts.
data : end of gt_vtts_old.

* internal table for stage/stop
data : begin of gt_z1eds01 .
        include structure z1eds01.
data : end of gt_z1eds01.

* internl table for Stop Date/Times
data : begin of gt_z1edstz  occurs 0 .
        include structure z1edstz.
data : end of gt_z1edstz.

* internal table
data : begin of gt_z1edstc  occurs 0 .
        include structure z1edstc.
data : end of gt_z1edstc.

* internal table to hold errors
data : begin of gt_errors  occurs 0 .
        include structure bapiret2.
data : end of gt_errors.

*--internal table for alv merge catalog
data:begin of gt_stages_final occurs 0,
       tsnum(4)                  , " LIKE vtts-tsrfo
       dep_point(10)             ,
       dep_point_desc(30)        ,
       dep_stop           type zdl_stpty_o,
       des_point(10)             ,
       des_point_desc(30)        ,
       des_stop           type zdl_stpty_d,
       sttrg              like vtts-zz_sttrg,
       stage_desc(60)            ,
       celltab            type lvc_t_styl,
     end of gt_stages_final.

* internal table to hold deliveries
data: begin of gt_vttp occurs 0,
        vbeln type vbeln_vl,
      end of gt_vttp.

data : gt_stages_valid like gt_stages_final occurs 0 with header line.

* data for tab
constants: begin of c_tc_chg1_master,
             tab1 like sy-ucomm value 'TC_CHG1_MASTER_FC1',
             tab2 like sy-ucomm value 'TC_CHG1_MASTER_FC2',
             tab3 like sy-ucomm value 'TC_CHG1_MASTER_FC3',
             tab4 like sy-ucomm value 'TC_CHG1_MASTER_FC4',
           end of c_tc_chg1_master.

* control defination
controls:  tc_chg1_master type tabstrip.

* tab details
data:      begin of g_tc_chg1_master,
             subscreen   like sy-dynnr,
             prog        like sy-repid value 'Z03732_VTTS_Z_TRANSCATION',
             pressed_tab like sy-ucomm value c_tc_chg1_master-tab1,
           end of g_tc_chg1_master.

* Begin of changes psunkar Transport# EDEK911301
*  ZZBOOKNUM
types : begin of gs_likp_zzbooknum,
          vbeln     like likp-vbeln,
          zzbooknum like likp-zzbooknum,
        end of gs_likp_zzbooknum.
* internal table to hold booking confirmation numbers
data: gt_likp_zzbooknum type standard table of gs_likp_zzbooknum.

tables :nast.
data: gs_nast       like nast,
      gc_kappl      like nast-kappl value 'V7',
      gc_kschl_zbol like nast-kschl value 'ZBOL',
      gc_kschl_zbl2 like nast-kschl value 'ZBL2',          " CC01
      gc_kschl_zpkl like nast-kschl value 'ZPKL',
      gc_kschl_zpl2 like nast-kschl value 'ZPL2',
* << Begin of changes 08/21/09 R15  EDVK973207 Printing ZCCI output
* through  Big Button (Z03732).
      gc_v2         like nast-kappl value 'V2',
      gc_kschl_zcci like nast-kschl value 'ZCCI',
*>> End of changes 08/21/09 R15  EDVK973207 Printing ZCCI output
* through  Big Button (Z03732).
      gv_rcode      like sy-subrc.


* end of changes by psunkar Transport# EDEK911301

* Begin of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
types : begin of gs_likp_lgtor,
          vbeln like likp-vbeln,
          lgtor like likp-lgtor,
        end of gs_likp_lgtor.
types:  begin of ts_lgtor_ltort,
          lgtor like t30b-lgtor,
          ltort like t30bt-ltort,
        end of ts_lgtor_ltort.
data: gv_lgtor like likp-lgtor,
      gv_ltort like t30bt-ltort,
      gv_lgnum like lips-lgnum,
      gv_lgbzo like t30c-lgbzo,
      gv_lbzot like t30ct-lbzot.
* internal table
data: gt_likp_lgtor  type standard table of gs_likp_lgtor,
      gt_itinerary   type standard table of zmos_itinerary,
      gs_itinerary   type line of zmos_itinerary_s,
      gt_deliveries  type standard table of zmos_deliveries,
      gs_deliveries  like line of  gt_deliveries,
      gt_lgtor_ltort type standard table of ts_lgtor_ltort,
      gs_lgtor_ltort like line of gt_lgtor_ltort,
      gs_value       type vrm_value,
      gt_values      type vrm_values.

data: gt_return_values like ddshretval occurs 0 with header line.
data: rdb_requested type boolean,
      rdb_confirmed type boolean.
*End of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
* Begin of changes 12/11/08 Transport# EDVK967185
data: gv_lowval like zdl_fields-lowval,
      gv_signi  like vttk-signi.
* End of changes 12/11/08 Transport# EDVK967185

* Start of WM changes 03/23/09 Transport# EDVK969540
data: begin of gt_lips occurs 0,
        vbeln           like lips-vbeln,
        posnr           like lips-posnr,
        lfimg           like lips-lfimg,  "TR#E0VK952755 kthakur+
        lgnum           like lips-lgnum,
        uecha           like lips-uecha,
        zz_pickconf_ind like lips-zz_pickconf_ind,
        pstyv           like lips-pstyv,
      end   of gt_lips,
      begin of gt_hudat occurs 0,
        pexidv like zdl_wm_hudat-pexidv,
        cexidv like zdl_wm_hudat-cexidv,
        tknum  like zdl_wm_hudat-tknum,
        vbeln  like zdl_wm_hudat-vbeln,
        posnr  like zdl_wm_hudat-posnr,
      end   of gt_hudat,
      begin of gt_vekp occurs 0,
        venum    like vekp-venum,
        exidv    like vekp-exidv,
        status   like vekp-status, "TPR# 03495 TR#EDVK969962 kthakur+
        vpobjkey like vekp-vpobjkey,
      end   of gt_vekp,
      begin of gt_vepo occurs 0,
        venum like vepo-venum,
        vbeln like vepo-vbeln,
        posnr like vepo-posnr,
        unvel like vepo-unvel,
      end of gt_vepo,


      begin of gt_vbup occurs 0,
        vbeln like vbup-vbeln,
        posnr like vbup-posnr,
        kosta like vbup-kosta,
        pksta like vbup-pksta,
      end  of gt_vbup,
* Begin insert TPR# 31358  TR# EDVK970882  kthakur
      begin of gt_vbuk occurs 0,
        vbeln like vbuk-vbeln,
        kostk like vbuk-kostk,
      end of gt_vbuk,
* End insert TPR# 31358  TR# EDVK970882  kthakur
      gt_vekp_s     like standard table of gt_vekp with header line,
      gt_hudat_temp like table of gt_hudat with header line,
      gs_vekp       like line of gt_vekp.
*End of WM changes 03/23/09 Transport# EDVK969540

data: gv_enter_pressed type char1, "BCB05 insert
      gv_lgbzo_prev    type lgbzo, "BCB05 insert
      gv_lgtor_prev    type lgtor. "BCB05 insert

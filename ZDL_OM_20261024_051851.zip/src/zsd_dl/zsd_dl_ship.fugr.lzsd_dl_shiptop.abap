FUNCTION-POOL ZSD_DL_SHIP                MESSAGE-ID SV.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
* Programmer  : Sushila Chaudhary                                      *
*______________________________________________________________________*
* Description : This include is called when ever a shipment is created *
* or changed . Based on certain validation done, the shipment needs to *
* be sent down to MES via the idoc type ZSDSHP01.                      *
* table xttt shows all the changes  while the table yttt remains the   *
* same before the changes were done.                                   *
*-------------------------------------------------------------------
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Tony Harcrow        02/07/06          Read new ztables for export
*                                       info instead of VBAK.
*______________________________________________________________________*
************************************************************************
type-pools zsdc.

tables: adrc,
        lfa1,
        vbfa,
        kna1,
        t005t,
        tvrot,
        vekp,
        makt,
        zzxrefdetail,
        lips,
        likp,
        ekkn,
        vbak,
        vbap,
        ekbe,
        vbpa,
        ekko,
        zsp_value,
        zsd_book_hdr,
        zsd_book_itm ,
* begin of change / nparchu / 05/03/2006
        cdpos .
* end of change / nparchu / 05/03/2006
constants : c_logical_system like edidc-sndprt value 'LS',
            c_out_direct like edidc-direct value '1'     ,
            c_message_type like edidc-mestyp value 'ZSDSHPMNT' ,
            c_idoc_type like edidc-idoctp value 'ZSDSHP01'     ,
            c_deliver like zzxrefdetail-zzgroup  value 'DELIVER' ,
            c_millmes like zzxrefdetail-zzgroupset  value 'MILLMES',
            c_posnr_9   like vtrlp-posnr value '9' ,
            c_04  like vekp-vpobj value '04' ,
            c_dataelement like zzale_partner-fieldname
                                         value 'VSTEL',
            c_hlevel_1  like edidd-hlevel value '1',
            c_hlevel_2  like edidd-hlevel value '2',
            c_hlevel_3  like edidd-hlevel value '3',
            c_shp_hdr   like edidd-segnam value 'Z1SDSHPMNT02' ,
            c_default_spras like sy-langu value 'E' ,
            c_checked  type c value 'X' ,
            c_unchecked type c value ' ' ,
            c_insert   type c value 'I' ,
            c_update   type c value 'U' ,
            c_delete   type c value 'D' ,
            c_group like zzxrefhead-zzgroup value 'DELIVER',
            c_rollno   like conf_out-atnam value 'ORDER_UNITS',
            c_yes      type c value 'Y' ,
            c_sales_order type c  value 'C' ,
            c_sto_order   type c  value 'V' ,
            c_foc_order   type c  value 'I',
            c_returns     type c  value 'H',
            c_sch_ag      type c  value 'E',
            c_shipto      type vbpa-parvw value 'WE' ,
            c_zeros       type vbpa-posnr value '000000',
            c_client(4)   type c value 'CLNT',
            c_prgmid type programm
                          value 'ZSD_DL_I1217_SHIP_DELIV_INTER' ,
            c_fieldname type zsp_fieldname  value 'VGTYP',
            c_over_tolerance type zsp_fieldname  value 'OVER_TOLERANCE',
            c_under_tolerance type zsp_fieldname  value
                                                      'UNDER_TOLERANCE',
            c_alternate_uom   type marm-meinh value 'RL',
* Begin of change / nparchu / 05/03/2006
            c_objectclas(9) type c value 'TRANSPORT' ,
            c_tabname(4) type c value 'VTTK'  ,
            c_fname(5) type c value 'STDIS'  .
* end of change  / nparchu / 05/03/2006 .

* master_idoc_distribute parameters
data: t_idoc_comm_control like edidc occurs 0 with header line,
      t_master_idoc_control like edidc,
      t_idoc_data like edidd occurs 0 with header line,
      h_logsys like t000-logsys ,
      datavalue like zzale_partner-fieldvalue.

* Segment Tables
data : idoc_z1sdshpmnt02 like z1sdshpmnt02,
       idoc_z1sdshpdlh01 like z1sdshpdlh01,
       idoc_z1sdshpdli01 like z1sdshpdli01.

* Stage of Shipment
data: begin of t_vtts occurs 0.
        include structure vtts.
data: end of t_vtts.

* shipment line items
data: begin of t_vttp occurs 0.
        include structure vttp.
data: end of t_vttp.

* Stage of Transport / Item Allocation
data: begin of t_vtsp occurs 0.
        include structure vtsp.
data: end of t_vtsp.

data : temp_vtsp like t_vtsp occurs 0 with header line.

* Delivery in Shipment: Item
data: begin of t_vtrlp occurs 0.
        include structure vtrlp.
data: end of t_vtrlp.

data: begin of t_sorted occurs 0,
       tknum like vttk-tknum,
       tsnum like vtsp-tsnum,                       " stage number
       tpnum like vtsp-tpnum,                       " item number
       tsrfo like vtts-tsrfo,
       vstel like vtts-vstel,
       kunnz like vtts-kunnz,
       kunna like vtts-kunna,
       adrnz like vtts-adrnz,
      end of t_sorted.

* Shipment Number
data: tknum like vttk-tknum,
      v_numc3 type num03,
      tem_key1 like zzxrefdetail-zzkey1.

* cross ref requirement
data : t_result1 type zz_tt_zzxrefdetail with header line,
       itab_return like bapiret2 occurs 0 with header line ,
       t_result2 type zz_tt_zzxrefdetail with header line.

* variant config table
data: conf_out  like conf_out occurs 0 with header line,
      x_rollno(5) type c,
      x_int   type p decimals 2,
      x_int4 type int4.

data : magew like vekp-magew ,
       vhilm like vekp-vhilm,
       v_char type c,
       v_millsystem like zzxrefdetail-zzkey1,
       w_data       like edidd,
       p1(15) type c,
       p2(15) type c,
       del_max(4) type n,
       del_min(4) type n,
       g_subrc,
       sto_acct_assign_active.

data : del_min_toler(15) type p  decimals 3,
       del_max_toler(16) type p decimals 3,
       vrkme  like vbap-vrkme,
       cuobj like vbap-cuobj.

data : begin of t_ship_points occurs 10,
         vstel like vtts-vstel,
         rcvprn like edidc-rcvprn,
       end of t_ship_points.

data : begin of itab_value occurs 1,
         fieldname like zsp_value-fieldname,
     end of itab_value.

*// parameters to write the application log .
data:
      c_object    type balobj_d  value 'ZDL_INTERFACE',       "app log
      c_subobject type balsubobj value 'ZDL_SHPMNT_REQFIELD',
      g_dummy         type string,
      g_line type i,
      gt_return like zret_text occurs 0 with header line,
      l_lognum        type bal_t_lgnm,
      go_log      type ref to zcl_ca_applogging,

*// parameters to track the MTO or MTS STO's .
      f_mts_sto   type c,
      f_mto_sto   type c.

*// table declaration to read the zsp_value table for the sto character.
data: begin of t_zsp_value occurs 0.
        include structure zsp_value.
data: end of t_zsp_value.

*// table to store the trim unit weight
data it_trim_detail like ZST_TRIM_DETAILS occurs 1 with header line.

*// table to store the supply driven materials
 data : gt_supply_drivn like ZDL_SUPPLY_DRIVN occurs 0 with header line.
 .

*// variable to check for data in APO
Data : gv_read_apo(1) .
Data : lrfcdes_name type RFCDES .
Data : DEST LIKE RFCDES-RFCDEST .

Types : begin of tt_delivery_roll ,
         shipment type tknum      ,
         delivery like vbak-vbeln   ,
         delivery_item type posnr_vl ,
         num_rolls type int4 ,
        end of tt_delivery_roll .

Types : Begin of tt_shipment_no ,
         shipment type tknum ,
        end of tt_shipment_no .


Data :  gt_delivery_roll type tt_delivery_roll occurs 0 .
*Data :  gt_delivery_roll type YDL_DELIVERY_ROLLS occurs 0 .
*Data : gs_delivery type YDL_DELIVERY_ROLLS.

FIELD-SYMBOLS:  <ls_delivery>  TYPE  tt_delivery_roll.

Data : gs_shipment type tt_shipment_no  .
Data : gt_shipment_no type table of tknum .
Data : gmsg_text(80) type C .
Data : gv_fail_idoc(1) type C.
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZSD_DL_SHIPT00                         . "view rel. data dcl.

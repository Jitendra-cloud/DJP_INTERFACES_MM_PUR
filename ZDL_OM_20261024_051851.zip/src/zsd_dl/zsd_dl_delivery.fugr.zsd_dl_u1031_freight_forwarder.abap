FUNCTION zsd_dl_u1031_freight_forwarder.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  TABLES
*"      I_XVTSP STRUCTURE  VTSPVB
*"      I_XVTTP STRUCTURE  VTTPVB
*"      I_XVBPA STRUCTURE  VBPAVB
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2004, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Include Name: ZSD_DL_U1031_FREIGHT_FORWARDER        Date: 05/20/2004 *
*                                                                      *
* SAP Name    :                                                        *
*                                                                      *
* Programmer  : Charles M. Ramey                                       *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*  Function to retrieve the Freight Forwarder from an STO to place in  *
* the shipment as a partner.                                           *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* External Calls                                                       *
*   Function Modules:                                                  *
*______________________________________________________________________*

  CONSTANTS: c_forwarder   LIKE i_xvbpa-parvw   VALUE 'ZF',
             c_blank_ebelp LIKE ekpa-ebeln      VALUE '000000',
             c_insert      LIKE i_xvbpa-updkz   VALUE 'I'.
  DATA:      l_vgbel       LIKE lips-vgbel,
             l_posnr       LIKE vbpa-posnr,
             l_posnr2      LIKE vbpa-posnr,
             l_lifn2       LIKE ekpa-lifn2,
             l_adrnr       LIKE lfa1-adrnr.

  LOOP AT i_xvtsp.
*  if freight forwarder already exists for this stage - do not look for
*  a new one.
    l_posnr2 = i_xvtsp-tsnum.
    READ TABLE i_xvbpa
      WITH KEY vbeln = i_xvtsp-tknum
               posnr = l_posnr2
               parvw = c_forwarder.
    CHECK NOT sy-subrc IS INITIAL.

* check the table itself (due to problems with freight costing & BW OSS
* message (notice must check SHIPPING PARTNER TABLE (VTPA) )
    SELECT SINGLE lifnr
      INTO l_lifn2
      FROM vtpa
     WHERE vbeln = i_xvtsp-tknum
       AND posnr = l_posnr2
       AND parvw = c_forwarder.
    CHECK NOT sy-subrc IS INITIAL.

    CLEAR l_vgbel.
    CLEAR l_lifn2.
    CLEAR l_adrnr.

* get the delivery from the Shipments Item Table.
    LOOP AT i_xvttp
      WHERE tknum = i_xvtsp-tknum
        AND tpnum = i_xvtsp-tpnum.

* we only need 1 STO per delivery to find the freight forwarder.
      SELECT SINGLE vgbel
        INTO l_vgbel
        FROM lips
       WHERE vbeln = i_xvttp-vbeln.
      CHECK sy-subrc IS INITIAL.

* get the freight forwarder from the STO
*  if not one attached look for the next STO
      SELECT SINGLE lifn2
        INTO l_lifn2
        FROM ekpa
        WHERE ebeln = l_vgbel
          AND ebelp = c_blank_ebelp
          AND parvw = c_forwarder.
      CHECK sy-subrc IS INITIAL.

* get the address record number.
      SELECT SINGLE adrnr
        INTO l_adrnr
        FROM lfa1
       WHERE lifnr = l_lifn2.
      CHECK sy-subrc IS INITIAL.

      IF NOT l_lifn2 IS INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.                " i_xvttp

* write the forwarder to the shipment partner table.
    IF NOT l_lifn2 IS INITIAL.
      i_xvbpa-vbeln = i_xvtsp-tknum.
      i_xvbpa-posnr = i_xvtsp-tsnum.
      i_xvbpa-parvw = c_forwarder.
      i_xvbpa-lifnr = l_lifn2.
      i_xvbpa-adrnr = l_adrnr.
      i_xvbpa-updkz = c_insert.
      APPEND i_xvbpa.
    ENDIF.
  ENDLOOP.                    " i_xvtsp
ENDFUNCTION.
*

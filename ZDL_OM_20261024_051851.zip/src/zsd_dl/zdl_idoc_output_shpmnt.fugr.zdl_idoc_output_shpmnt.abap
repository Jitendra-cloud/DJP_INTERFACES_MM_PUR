FUNCTION zdl_idoc_output_shpmnt.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(OBJECT) LIKE  NAST STRUCTURE  NAST
*"     VALUE(CONTROL_RECORD_IN) LIKE  EDIDC STRUCTURE  EDIDC
*"  EXPORTING
*"     VALUE(OBJECT_TYPE) LIKE  WFAS1-ASGTP
*"     VALUE(CONTROL_RECORD_OUT) LIKE  EDIDC STRUCTURE  EDIDC
*"  TABLES
*"      INT_EDIDD STRUCTURE  EDIDD
*"  EXCEPTIONS
*"      ERROR_MESSAGE_RECEIVED
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2005 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2009                                       **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Programmer  : Bruce Ballehr                   Date : 04/17/2009      *
*                                                                      *
*______________________________________________________________________*
* Description : This Outbound Idoc function module is called to        *
* potentially split an Outbound SHPMNT05 ASN idoc into multiple        *
* Outbound SHPMNT05 ASN idocs. At this time this function module is    *
* linked to new Outbound Process Code ZSD1. This process is part of    *
* Interface I02419.                                                    *
*                                                                      *
* In multi-stop shipments, each individual stop may require an ASN     *
* that is sent to the designated trading partner. If those multiple    *
* trading partners utilize the same system (i.e. two stops at two      *
* different Staples stores) then the use of a single Shipment # to     *
* uniquely identify both ASNs may introduce a #duplicate shipment #'   *
* problem.                                                             *
*                                                                      *
* Basic on logic addressed in the code, we may have to send out        *
* idocs. Each idoc would have only one segment Z1EDSTP haveing load    *
* indicator field LDIND = 'A' (for ASN relevant) and an additional     *
* Z1EDSTC segment containing a QUALF = 'ESN' and a PARAM = the         *
* concatenation of the Shipment Number + the current 4 byte            *
* Z1EDSTP-SEQNM (Sequence number of the STOP).                         *
*                                                                      *
*                                                                      *
* If the Receipient Partner Type is a 'KU' (Customer)                  *
*   For Partial Unload or Complete Unload Stops ONLY:                  *
*     If any of the Deliveries for the Stop has the SAME               *
*     Recipient Partner as the Idoc Control Recipient Partner,         *
*     then is Stop is considered ASN Relevant and an outbound idoc     *
*     must be generated.                                               *
*                                                                      *
*______________________________________________________________________*
* Change History :                                                     *
* Bruce Ballehr   04/17/2009  Initial Creation (Transport EDVK969855)  *
*                                                                      *
* Bruce Ballehr   05/13/2009  TPR 31839 (Transport EDVK971128)         *
*                             Because of clearing Control Record fields*
*                             when calling IDOC_OUTPUT_SHPMNT, certain *
*                             filtering logic is not taking place.     *
*                             This change will let the inbound control *
*                             record be used when calling standard fm  *
*                             IDOC_OUTPUT_SHPMNT.                      *
*                                                                      *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
  DATA:

    lv_serial  TYPE edi_serial.


* Call the standard IDOC_OUTPUT_SHPMNT to retrieve Shipment idoc info
  CALL FUNCTION 'IDOC_OUTPUT_SHPMNT'
    EXPORTING
      object                 = object
      control_record_in      = control_record_in
    IMPORTING
      object_type            = gv_object_type
      control_record_out     = control_record_out
    TABLES
      int_edidd              = int_edidd
    EXCEPTIONS
      error_message_received = 1
      OTHERS                 = 2.

  CHECK sy-subrc = 0.

* Set Control Record global structure
  gs_edidc  = control_record_in.

* Capture Serial Number generated by IDOC_OUTPUT_SHPMNT
  lv_serial = control_record_out-serial.

* Set Control Record Out. This is needed for when program control is
* returned to program RSNASTED (subroutine NEW_DYN_PERFORM). Certain
* fields on control_record_out are wiped clean like Idoc Direction,
* Receiver Port, Receiver Partner Type, Receiver Partner, etc.. so we
* need to refresh control record out.
  control_record_out = control_record_in.

* Restore the Serial Number to the control_record_out
  control_record_out-serial = lv_serial.

* If the Control Record partner type is not 'KU' (Customer) then send
* the current idoc to the ALE layer
  IF gs_edidc-rcvprt NE 'KU'.
    RETURN. "Leave function module
  ENDIF.

* Create a working copy of the idoc data
  gt_idoc_data[] = int_edidd[].
* Initialize "ASN Relevant" flag to false
  gv_asn_relevant = gc_false.

* Initialize work tables
  CLEAR: gt_z1edstp, "Stop segment data table
         gt_z1edstd. "Delivery segment data table


* Gather Idoc data. Set Load Indicator(s) of idoc work table to space
* if any are 'A' (ASN Relevant)
  PERFORM init_idoc_work_table CHANGING gt_idoc_data.

* Retrieve Partner information for all Deliveries on the Shipment
  PERFORM get_partner_data.

* Determine if any Stop's Delivery partners match up to the Control
* Record's partner where the Stop is either a Partial Unload or a
* Complete Unload. If so, update the work table's corresponding record
* to have a Load Indicator of 'A' (ASN Relevant).
  PERFORM determine_asn_relevance.

* FOR EVERY Stop segment that had their Load Indicator updated with an
* 'A' (ASN Relevant), send the idoc data to the ALE Layer with ONLY
* THAT Stop's Load Indicator set to 'A'
* If no Stop segments had their Load Indicator updated with an 'A'
* then just send the original idoc data to the ALE Layer
  IF gv_asn_relevant = gc_true.
    PERFORM process_asn_relevant_idocs CHANGING int_edidd[].
  ENDIF.

ENDFUNCTION.

class ZCL_IM__BI_DL_E10544_2 definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_LE_SHP_DELIVERY_PROC .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM__BI_DL_E10544_2 IMPLEMENTATION.


  METHOD if_ex_le_shp_delivery_proc~change_delivery_header.

* CMS: 28322| Changed By: AMAOLE1| Changed On: 03/13/2015
* Table EXTENSION2 information is exported by - BAdI imp. Z_BI_DL_E10544_1 for BAdI SMOD_V50B0001
* Method EXIT_SAPLV50I_010

  DATA extension2 TYPE bapiextt.
  DATA ls_extension2 TYPE bapiext.

  IMPORT extension2 = extension2 FROM MEMORY ID 'SMOD_V50B0001'.

  IF extension2[] IS INITIAL.
    RETURN.
  ENDIF.

  LOOP AT extension2 INTO ls_extension2 WHERE param EQ 'LIKP' AND value NE space.

    CASE ls_extension2-field.
      WHEN 'LFUHR'.
        cs_likp-lfuhr = ls_extension2-value.
      WHEN 'ZZFRTFWD'.
        cs_likp-zzfrtfwd = ls_extension2-value.
      WHEN 'ZZBOOKNUM'.
        cs_likp-zzbooknum = ls_extension2-value.
      WHEN 'ZZVESLNAME'.
        cs_likp-zzveslname = ls_extension2-value.
      WHEN 'ZZVOYGNUM'.
        cs_likp-zzvoygnum = ls_extension2-value.
      WHEN 'ZZBOOKDOC'.
        cs_likp-zzbookdoc = ls_extension2-value.
      WHEN OTHERS.
    ENDCASE.
  ENDLOOP.
  ENDMETHOD.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FCODE_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FIELD_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHECK_ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_FINAL_CHECK.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DOCUMENT_NUMBER_PUBLISH.
  endmethod.


  METHOD if_ex_le_shp_delivery_proc~fill_delivery_header.
  ENDMETHOD.


  method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~INITIALIZE_DELIVERY.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~PUBLISH_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~READ_DELIVERY.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_BEFORE_OUTPUT.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_DOCUMENT.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_DOCUMENT_PREPARE.
  endmethod.
ENDCLASS.

FUNCTION Z_SD_DL_GET_SHIPMENT_COST_DATA .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  EXPORTING
*"     REFERENCE(I_INCO1) TYPE  INCO1
*"  TABLES
*"      G_KOMV_TAB TYPE  /SAPFCX/KOMV_TAB OPTIONAL
*"  CHANGING
*"     REFERENCE(I_VBAK) TYPE  VBAK
*"----------------------------------------------------------------------
*&---------------------------------------------------------------------*
*& Get delivery and sales order data for export pricing conditions
*&---------------------------------------------------------------------*
*&  © International Paper - May 2004
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Change History:
*&     Programmer        Date    Req. #            Action
*& ==================  ========  ======  ==============================
*& Maureen Carter      05/04/04          Initial creation from R/3
*&
*& Sabitha            03/13/06 E0VK917194 CHG59760 -Problem with Batch
*&                                        job
*& Sabitha            03/29/06 E0VK917128 U01027 - CHG60436 - In order
*&                                        to check for the INCO1 = FCA
*&                                        add the INCO1 as export
*&                                        parameter.
* DBANSOD            04/07/10  EDEK917406 UNICODE compatible changes   *
*&---------------------------------------------------------------------*
  FIELD-SYMBOLS: <l_vtrlp> TYPE vtrlp.
  FIELD-SYMBOLS: <l_vtrlk> TYPE vtrlk.
  FIELD-SYMBOLS: <l_komv> TYPE komv.

  CONSTANTS:
     vbtyp_verk(13) VALUE 'ABCDEFGHIKLW0'.

  TYPES: komv_tab TYPE komv OCCURS 0.

  DATA: l_item     TYPE v54a0_scd_item.
  DATA: l_refobj   TYPE v54a0_refobj.
  DATA: l_komv_wa  TYPE komv.
  DATA: l_caller   TYPE c.
  DATA: l_filter_c VALUE 'C'.
  DATA: l_konv     TYPE konv.
  DATA: l_vtrlk_c  TYPE v54a0_vtrlk_tab.
  DATA: l_vtrlp_c  TYPE v54a0_vtrlp_tab.

  DATA l_komv  TYPE komv.

****Start of E0VK917194 - CHG59760

  CLEAR g_refobj-vttkf-tknum.

*  IF g_refobj-vttkf-tknum IS INITIAL.

****End of E0VK917194 - CHG59760

* get item data from memory for the shipping cost docuument
  CALL FUNCTION 'SD_SCD_ITEM_PRICING_DATA_GET'
    IMPORTING
      e_scd_item = l_item
      e_refobj   = g_refobj.

* initialize fields for this condition
  CLEAR g_item_ref_conds.
  g_item_ref_conds-vfkp = l_item-vfkp.  "shipment cost item structure
  g_anzpk = 0.                          "# packages in delivery

* get deliveries relevant for calculation
  CALL FUNCTION 'SD_SCD_GET_RELEVANT_DELIVERIES'
    EXPORTING
      i_rebel       = l_item-vfkp-rebel  "shipment
      i_repos       = l_item-vfkp-repos  "shipment item
      i_filter_type = l_filter_c
      i_refobj      = g_refobj
    TABLES
      e_vtrlk       = l_vtrlk_c  "delivery headers
      e_vtrlp       = l_vtrlp_c. "line items

* calculate number of packages in the deliveries (for EA conditions)
  LOOP AT l_vtrlk_c ASSIGNING <l_vtrlk>.
    g_anzpk = g_anzpk + <l_vtrlk>-anzpk.

****Start of E0VK917128 U01027 - CHG60436
    i_inco1 =  <l_vtrlk>-inco1.
****End of E0VK917128 U01027 - CHG60436
  ENDLOOP.

* build conditions table for each delivery line item
*  this returns the sales order for the last item on the last delivery
*  If there are more than one sales order across the shipment -
*    the rate will only be the one for the last sales order
  LOOP AT l_vtrlp_c ASSIGNING <l_vtrlp>.
    CHECK <l_vtrlp>-vgtyp CA vbtyp_verk.
    "Check if sales order
*   get condition number from sales order header
    SELECT SINGLE * FROM vbak INTO g_vbak
                               WHERE vbeln = <l_vtrlp>-vbeln_vauf.
    CHECK sy-subrc IS INITIAL.
*   get header & items conditions
    SELECT * FROM konv INTO l_konv WHERE knumv = g_vbak-knumv.
      IF l_konv-kposn = 0 OR l_konv-kposn = <l_vtrlp>-posnr_vauf.
        MOVE-CORRESPONDING l_konv TO l_komv.              "EDEK917406
        APPEND l_komv TO g_komv_tab.                      "EDEK917406
*        APPEND l_konv TO g_komv_tab.
      ENDIF.
    ENDSELECT.
  ENDLOOP.

  SORT g_komv_tab BY kschl.
  APPEND LINES OF g_komv_tab TO g_item_ref_conds-komv.
*note g_komv_tab and g_items_ref_conds-komv are not used at this time
*5/04

****Start of E0VK917194 - CHG59760
*  ENDIF.

****End of E0VK917194 - CHG59760
  i_vbak = g_vbak.

ENDFUNCTION.

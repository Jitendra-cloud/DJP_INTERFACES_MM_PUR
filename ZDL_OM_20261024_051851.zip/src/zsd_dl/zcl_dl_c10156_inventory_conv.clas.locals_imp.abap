*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

CLASS lcl_inventory_conversion DEFINITION ABSTRACT.

  PUBLIC SECTION.
* Local type declaration
* For Partner storage location
    TYPES: BEGIN OF ty_s_slocation,
             werks TYPE werks_d,
             lgort TYPE lgort_d,
             xhupf TYPE xhupf,
             parlg TYPE parlg,
           END OF ty_s_slocation,

* For selction screen fields
           BEGIN OF ty_s_screen_fields,
             batch           TYPE boolean,
             goods           TYPE boolean,
             goods_rev       TYPE boolean,
             hu              TYPE boolean,
             product_type    TYPE zzgroupset,
             posting_date    TYPE budat,
             check_inventory TYPE boolean,
             local_drive     TYPE boolean,
             app_server      TYPE boolean,
             local_file_path TYPE string,
             app_file_path   TYPE string,
             test_mode       TYPE boolean,
             update_mode     TYPE boolean,
             except_proc     TYPE boolean,   "CD2000007614
             forground       TYPE boolean,
             background      TYPE boolean,
             gr_562          TYPE boolean,
             gr_bapi         TYPE boolean,
             gr_rev_check    TYPE boolean,
             trans_file      TYPE string,
             error_file      TYPE string,
             success_file    TYPE string,
           END OF ty_s_screen_fields,

* Application file data
           BEGIN OF ty_s_app_file_data,
             app_data TYPE char3000,
           END OF ty_s_app_file_data,

           BEGIN OF ty_s_batch_create,
             matnr      TYPE matnr,
             class_num  TYPE klasse_d, "Class
             object_key TYPE objnum,
             char_name  TYPE atnam,
           END OF ty_s_batch_create,

           BEGIN OF ty_s_profit_center,
             matnr TYPE matnr,
             werks TYPE werks_d,
             prctr TYPE prctr,
           END OF ty_s_profit_center,

           BEGIN OF ty_cabn,             ">CD2000007614
             atinn TYPE cabn-atinn,
             atnam TYPE cabn-atnam,
             atfor TYPE cabn-atfor,
           END OF ty_cabn,              "<CD2000007614

*  Table type declaration.
           ty_t_slocation TYPE STANDARD TABLE OF ty_s_slocation.

* Static data reference declaration
    CLASS-DATA: go_translation_data TYPE REF TO data,
                go_alv_output_ref   TYPE REF TO data.

* Static internal table declaration
    CLASS-DATA: gt_upload_data_ref      TYPE REF TO data,
                gt_translation_data_ref TYPE REF TO data,
                gt_alv_output_ref       TYPE REF TO data,
                gt_alv_hu_ref           TYPE REF TO data,
                gt_primary_table_2      TYPE zz_tt_zzxrefdetail,
                gt_primary_table_1      TYPE zz_tt_zzxrefdetail,
                gt_slocation            TYPE ty_t_slocation,
                gt_raw_app_file_data    TYPE rsanm_file_table,
                gt_app_file_data        TYPE STANDARD TABLE OF ty_s_app_file_data,
                gt_batch_char           TYPE STANDARD TABLE OF ty_s_batch_create,
                gt_batch_num            TYPE STANDARD TABLE OF ty_s_batch_create,
                gt_profit_center        TYPE STANDARD TABLE OF ty_s_profit_center.


* Static structure declaration
    CLASS-DATA: gs_upload_data_ref      TYPE REF TO data,
                gs_translation_data_ref TYPE REF TO data,
                gs_alv_output_ref       TYPE REF TO data,
                gs_primary_1            TYPE zzxrefdetail,
                gs_screen_input         TYPE ty_s_screen_fields,      "CD2000007614
                gv_cuobj                TYPE marc-cuobj,              "CD2000007614
                gr_atnam_rg             TYPE zsd_oip_cons_atnam_rtab. "CD2000007614

* Static Varaibale declaration.
    CLASS-DATA: gv_werks           TYPE werks_d,
                gv_lgort           TYPE lgort_d,
                gv_matnr           TYPE matnr,
                gv_charg           TYPE charg_d,
                gv_kunnr           TYPE kunnr,
                gv_menge           TYPE menge_d,
                gv_meins           TYPE meins,
                gv_profit_center   TYPE prctr,
                gv_vbeln           TYPE vbeln,
                gv_posnr           TYPE posnr,
                gv_subrc           TYPE sy-subrc,
                gv_sobkz           TYPE sobkz,
                gv_budat_mkpf      TYPE budat,
                gv_mblnr           TYPE mblnr,
                gv_mjahr           TYPE mjahr,
                gv_message         TYPE string,
                gv_pack_num        TYPE string,
                gv_special_stk_ind TYPE string,
                gv_no_xhupf        TYPE boolean,
                gv_no_parlg        TYPE boolean.   "CD2000007614

    METHODS: check_input_file_exists,
      upload_excel_data,
      get_file_name IMPORTING iv_filepath        TYPE string  "CD2000007614
                    RETURNING VALUE(rv_filename) TYPE string,
      validate_no_of_xcel_records,
      build_dynamic_internal_table,
      build_primary_internal_table,
      build_translation_data,
      program_conversion
        IMPORTING
                  is_field_details    TYPE zzxrefdetail
        CHANGING
                  cs_translation_data TYPE data
        RETURNING VALUE(rv_new_value) TYPE char15,
      system_conversion
        IMPORTING
                  is_field_details    TYPE zzxrefdetail
        CHANGING
                  cs_translation_data TYPE data
        RETURNING VALUE(rv_new_value) TYPE char15,
      check_config_uom
        IMPORTING
                  is_primary_table_1   TYPE zzxrefdetail
        RETURNING VALUE(rv_config_uom) TYPE boolean,
      get_packaging_material
        EXPORTING
          ev_pack_matnr TYPE matnr,
      sort_upload_table
        IMPORTING
          iv_field_name  TYPE string
          iv_descending  TYPE char1
        CHANGING
          ct_upload_data TYPE ANY TABLE,
      validate_fields_lenth
        IMPORTING
          iv_field_value TYPE any,
      read_application_file_data,
      validate_app_file_path,
      validate_no_of_app_fields,
      check_hu_exists
        CHANGING cs_alv_output_data TYPE data,
      check_translation_exists
        CHANGING cs_alv_output_data TYPE data,
      validate_werks
        CHANGING cs_alv_output_data TYPE data,
      validate_lgort
        CHANGING cs_alv_output_data TYPE data,
      validate_lgort_hu
        CHANGING cs_alv_output_data TYPE data,
      validate_matnr
        CHANGING cs_alv_output_data TYPE data,
      validate_goods_matnr
        CHANGING cs_alv_output_data TYPE data,
      validate_charg
        CHANGING cs_alv_output_data TYPE data,
      validate_create_charg
        CHANGING cs_alv_output_data TYPE data,
      validate_charg_for_gr_hu
        CHANGING cs_alv_output_data TYPE data,
      validate_menge
        CHANGING cs_alv_output_data TYPE data,
      validate_meins
        CHANGING cs_alv_output_data TYPE data,
      validate_sobkz
        CHANGING cs_alv_output_data TYPE data,
      validate_vbeln_posnr
        CHANGING cs_alv_output_data TYPE data,
      validate_kunnr
        CHANGING cs_alv_output_data TYPE data,
      validate_hsdat
        CHANGING cs_alv_output_data TYPE data,
      validate_characteristics
        CHANGING cs_alv_output_data TYPE data,
      validate_matnr_characteristics
        CHANGING cs_alv_output_data TYPE data,
      get_cuobj IMPORTING is_alv_output_data TYPE data,
      fill_required_global_field
        CHANGING cs_alv_output_data TYPE data,
      create_batch,
      create_goods_receipt,
      post_goods_receipt
        IMPORTING
          is_gm_header        TYPE bapi2017_gm_head_01
          is_gm_code          TYPE bapi2017_gm_code
          it_goodsmvt_item    TYPE bapi2017_gm_item_create_t
        EXPORTING
          ev_materialdocument TYPE bapi2017_gm_head_ret-mat_doc
          ev_matdocumentyear  TYPE bapi2017_gm_head_ret-doc_year
          et_return           TYPE bapiret2_t,
      check_inventory_posting,
      fill_gr_item_table
        IMPORTING
          iv_move_type TYPE bwart OPTIONAL
        EXPORTING
          et_gm_item   TYPE bapi2017_gm_item_create_t,
      goods_receipt_reversal,
      create_hu_pack,
      create_hu_pack_nomovement,                            "2000007614
      save_file_app_server,
      save_transalation_file,
      save_success_error_file,
      save_error_file,
      upload_build_dyn_table_data ABSTRACT,
      validate_input_file_data ABSTRACT,
      translation_file_data ABSTRACT,
      create_revers_process ABSTRACT,
      write_files_in_app_server ABSTRACT.
ENDCLASS.

CLASS lcl_inventory_conversion IMPLEMENTATION.
  METHOD: check_input_file_exists.
    DATA : lv_dir  TYPE string,
           lv_file TYPE string.

    CHECK gs_screen_input-local_drive = abap_true AND
          sy-batch = abap_false.
    IF gs_screen_input-local_file_path IS INITIAL.
      "Invalid Directory &1
      MESSAGE e009(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.

* Split the file path into directory and file name.
    CALL FUNCTION 'SO_SPLIT_FILE_AND_PATH'
      EXPORTING
        full_name     = gs_screen_input-local_file_path
      IMPORTING
        stripped_name = lv_file
        file_path     = lv_dir
      EXCEPTIONS
        x_error       = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      "Failed to split file path &1
      MESSAGE e005(zdl_c10156)
                     WITH gs_screen_input-local_file_path
                     INTO gv_message.
      RETURN.
    ENDIF.

    " check existence of directory
    cl_gui_frontend_services=>directory_exist(
      EXPORTING
        directory            = lv_dir          " Directory name
      RECEIVING
        result               = DATA(lv_result) " Result
      EXCEPTIONS
        cntl_error           = 1   " Control error
        error_no_gui         = 2   " No GUI available
        wrong_parameter      = 3   " Incorrect parameter
        not_supported_by_gui = 4   " GUI does not support this
        OTHERS               = 5 ).

    IF sy-subrc <> 0 OR lv_result IS INITIAL.
      "Invalid Directory &1
      MESSAGE e006(zdl_c10156)
                     WITH lv_dir
                     INTO gv_message.
      RETURN.
    ENDIF.
    CLEAR lv_result.
    " check file existence
    cl_gui_frontend_services=>file_exist(
      EXPORTING
        file                 = lv_file   " File to Check
      RECEIVING
        result               = lv_result " Result
      EXCEPTIONS
        cntl_error           = 1         " Control error
        error_no_gui         = 2         " Error: No GUI
        wrong_parameter      = 3         " Incorrect parameter
        not_supported_by_gui = 4         " GUI does not support this
        OTHERS               = 5 ).

    IF sy-subrc <> 0.
      "File &1 does not exist
      MESSAGE e007(zdl_c10156)
                       WITH lv_file
                       INTO gv_message.
      RETURN.
    ENDIF.

    SEARCH lv_file FOR '.XLSX'.
    IF sy-subrc <> 0.
      SEARCH lv_file FOR '.XLS'.
      IF sy-subrc <> 0.
        SEARCH lv_file FOR '.CSV'.
        IF sy-subrc <> 0.
*          Only excel file is supported
          MESSAGE e008(zdl_c10156) INTO gv_message.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD upload_excel_data.
    DATA: lt_type       TYPE truxs_t_text_data.
    FIELD-SYMBOLS <lt_table> TYPE STANDARD TABLE.

    ASSIGN gt_upload_data_ref->* TO <lt_table>.

    DATA(lv_file_path) = CONV localfile( gs_screen_input-local_file_path ).

    CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
      EXPORTING
        i_line_header        = abap_true
        i_tab_raw_data       = lt_type
        i_filename           = lv_file_path
      TABLES
        i_tab_converted_data = <lt_table>
      EXCEPTIONS
        conversion_failed    = 1
        OTHERS               = 2.
    IF sy-subrc <> 0.
      CLEAR <lt_table>.
    ENDIF.
  ENDMETHOD.

  METHOD get_file_name.

    CALL FUNCTION 'TRINT_SPLIT_FILE_AND_PATH'
      EXPORTING
        full_name     = iv_filepath     " File name with path
      IMPORTING
        stripped_name = rv_filename " File name w/o path
*       file_path     =
      EXCEPTIONS
        x_error       = 1
        OTHERS        = 2.

    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
        WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

  ENDMETHOD.
  METHOD validate_no_of_xcel_records.
    FIELD-SYMBOLS <lt_table> TYPE STANDARD TABLE.

    ASSIGN gt_upload_data_ref->* TO <lt_table>.

    DATA(lt_tabledescr_ref) = CAST cl_abap_tabledescr( cl_abap_typedescr=>describe_by_data( <lt_table> ) ).
    DATA(ls_descr_ref) = CAST cl_abap_structdescr( lt_tabledescr_ref->get_table_line_type( ) ).

    DATA(lv_excel_count) = lines( ls_descr_ref->components ).

    SELECT zzkey2,
           zzvalue1
      FROM zzxrefdetail
      INTO TABLE @DATA(lt_fields_dateail)
      WHERE zzgroup    = 'DELIVER' AND
            zzgroupset = @gs_screen_input-product_type.
    IF sy-subrc <> 0.
      CLEAR lt_fields_dateail.
    ENDIF.

    DATA(lv_db_count) = lines( lt_fields_dateail ).

    IF lv_db_count <> lv_excel_count.
*All fields in ZZXREFDETAIL are not maintained in excel
      MESSAGE e025(zdl_c10156) INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD build_dynamic_internal_table.
* Local table/strucuture/Variable declaration.
    DATA: lt_components             TYPE  cl_abap_structdescr=>component_table,
          lt_alv_components         TYPE  cl_abap_structdescr=>component_table,
          lt_translation_components TYPE  cl_abap_structdescr=>component_table,
          lt_hu_components          TYPE  cl_abap_structdescr=>component_table,
          ls_component              TYPE  cl_abap_structdescr=>component.

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order =  DATA(lt_fields_in_order) ).

    LOOP AT lt_fields_in_order INTO DATA(ls_fields_dateail).

* Message column only for the ALV output as the first column.
      AT FIRST.
        ls_component-name  = 'SUCCESS'.
        ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( 'BOOLEAN' ) ).
        APPEND ls_component TO lt_alv_components.
        CLEAR ls_component.

        ls_component-name  = TEXT-001."'Message'.
        ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( 'CCSECP_MESSAGE' ) ).
        APPEND ls_component TO lt_alv_components.
        CLEAR ls_component.

* Add Material Document & Material Document Year for GR and reversal
        IF gs_screen_input-goods = abap_true OR
           gs_screen_input-goods_rev = abap_true.
          ls_component-name  = 'MBLNR'.
          ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( 'MBLNR' ) ).
          APPEND ls_component TO lt_alv_components.
          CLEAR ls_component.

          ls_component-name  = 'MJAHR'.
          ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( 'MJAHR' ) ).
          APPEND ls_component TO lt_alv_components.
          CLEAR ls_component.
        ENDIF.
      ENDAT.

* This Part would be applied for the 3 tables reference.
      ls_component-name  = ls_fields_dateail-zzkey2.
      ls_component-type = CAST #( cl_abap_datadescr=>describe_by_data( ls_fields_dateail-zzkey2 ) ).

      APPEND ls_component TO lt_components.
      APPEND ls_component TO lt_alv_components.
      APPEND ls_component TO lt_translation_components.
      CLEAR ls_component.

* Add the new field for UOM conversion
      IF ls_fields_dateail-zzvalue2 IS NOT INITIAL AND
         ls_fields_dateail-zzvalue3 IS NOT INITIAL.
        ls_component-name  = |{ ls_fields_dateail-zzkey2 }{ '_NEW' }|.
        ls_component-type = CAST #( cl_abap_datadescr=>describe_by_data( ls_fields_dateail-zzkey2 ) ).
        APPEND ls_component TO lt_translation_components.
        CLEAR ls_component.
      ENDIF.
* If the filed require conversion, then the program needs to add a one more field in the
* output translation table.
      IF ls_fields_dateail-zzkey3 IS NOT INITIAL.
        ls_component-name  = |{ ls_fields_dateail-zzkey2 }{ '_NEW' }|.
        ls_component-type = CAST #( cl_abap_datadescr=>describe_by_data( ls_fields_dateail-zzkey2 ) ).
        APPEND ls_component TO lt_translation_components.
        CLEAR ls_component.
      ENDIF.

      AT LAST.
        ls_component-name  = 'COLOR'.
        ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( 'LVC_T_SCOL' ) ).
        APPEND ls_component TO lt_alv_components.
        CLEAR ls_component.
      ENDAT.
    ENDLOOP.

    IF gs_screen_input-hu = abap_true.
      LOOP AT lt_fields_in_order INTO ls_fields_dateail.
        AT FIRST.
          ls_component-name  = 'PACKAGE_NUMBER'.
          ls_component-type = CAST #( cl_abap_datadescr=>describe_by_data( ls_fields_dateail-zzkey2 ) ).
          APPEND ls_component TO lt_hu_components.
          CLEAR ls_component.

          ls_component-name  = TEXT-001."'Message'.
          ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( 'CCSECP_MESSAGE' ) ).
          APPEND ls_component TO lt_hu_components.
          CLEAR ls_component.
        ENDAT.
        IF ls_fields_dateail-zzkey2 <> 'PACKAGE_NUMBER'.
          ls_component-name  = ls_fields_dateail-zzkey2.
          ls_component-type = CAST #( cl_abap_datadescr=>describe_by_data( ls_fields_dateail-zzkey2 ) ).
          APPEND ls_component TO lt_hu_components.
          CLEAR ls_component.
        ENDIF.
      ENDLOOP.
    ENDIF.


    " Create result/output structure
    TRY.
        DATA(lo_structdescr) = cl_abap_structdescr=>create( lt_components ).
        DATA(lo_tabledescr)  = cl_abap_tabledescr=>create( lo_structdescr ).
      CATCH cx_sy_table_creation INTO DATA(lo_msg).
        DATA(lv_text) = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.

* Internal table instance
    CREATE DATA gt_upload_data_ref TYPE HANDLE lo_tabledescr.
* Structure instance
    CREATE DATA gs_upload_data_ref TYPE HANDLE lo_structdescr.

    " Create result/output structure
    TRY.
        lo_structdescr = cl_abap_structdescr=>create( lt_translation_components ).
        lo_tabledescr  = cl_abap_tabledescr=>create( lo_structdescr ).
      CATCH cx_sy_table_creation INTO lo_msg.
        lv_text = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.

* Internal table instance
    CREATE DATA gt_translation_data_ref TYPE HANDLE lo_tabledescr.
* Structure instance
    CREATE DATA gs_translation_data_ref TYPE HANDLE lo_structdescr.

* ALV Output table.
    TRY.
        lo_structdescr = cl_abap_structdescr=>create( lt_alv_components ).
        lo_tabledescr  = cl_abap_tabledescr=>create( lo_structdescr ).
      CATCH cx_sy_table_creation INTO lo_msg.
        lv_text = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.

* Internal table instance
    CREATE DATA gt_alv_output_ref TYPE HANDLE lo_tabledescr.
* Structure instance
    CREATE DATA gs_alv_output_ref TYPE HANDLE lo_structdescr.

* HU table.
    IF lt_hu_components IS NOT INITIAL.
      TRY.
          lo_structdescr = cl_abap_structdescr=>create( lt_hu_components ).
          lo_tabledescr  = cl_abap_tabledescr=>create( lo_structdescr ).
        CATCH cx_sy_table_creation INTO lo_msg.
          lv_text = lo_msg->get_text( ).
          MESSAGE e000(zdl_c10156) WITH lv_text.
      ENDTRY.

* Internal table instance
      CREATE DATA gt_alv_hu_ref TYPE HANDLE lo_tabledescr.
    ENDIF.
  ENDMETHOD.
  METHOD build_primary_internal_table.
    TYPES: BEGIN OF ty_s_low,
             zzgroupset TYPE zzgroupset,
           END OF ty_s_low,

           BEGIN OF ty_s_fields_in_order.
             INCLUDE TYPE zzxrefdetail.
             TYPES : numc TYPE /bcv/sin_numc3,
           END OF ty_s_fields_in_order.

    TYPES: ty_t_fields_in_order TYPE STANDARD TABLE OF ty_s_fields_in_order WITH EMPTY KEY,
           ty_t_low             TYPE STANDARD TABLE OF ty_s_low WITH EMPTY KEY.

* Get dynamic internal table and structure
    FIELD-SYMBOLS: <lt_excel_data>       TYPE STANDARD TABLE,
                   <lt_translation_data> TYPE STANDARD TABLE.
    ASSIGN gt_upload_data_ref->* TO <lt_excel_data>.
    ASSIGN gs_upload_data_ref->* TO FIELD-SYMBOL(<ls_excel_data>).
    ASSIGN gs_upload_data_ref->* TO FIELD-SYMBOL(<ls_app_data>).

    ASSIGN gt_translation_data_ref->* TO <lt_translation_data>.
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>).

    IF gs_screen_input-app_server = abap_true.

      LOOP AT gt_raw_app_file_data INTO DATA(ls_raw_app_file_data).
        SPLIT ls_raw_app_file_data AT ',' INTO TABLE gt_app_file_data.

        LOOP AT gt_app_file_data INTO DATA(ls_app_file_data).
          ASSIGN COMPONENT sy-tabix
              OF STRUCTURE <ls_app_data>
                TO FIELD-SYMBOL(<fs_app_data>).
          IF sy-subrc <> 0.
            CONTINUE.
          ENDIF.
          <fs_app_data> = ls_app_file_data-app_data.

          AT LAST.
            APPEND <ls_app_data> TO <lt_excel_data>.
            CLEAR <ls_app_data>.
          ENDAT.
        ENDLOOP.
        CLEAR gt_app_file_data.
      ENDLOOP.

    ENDIF.

* Primary internal table 1.
    SELECT *
      FROM zdl_fields
      INTO TABLE @DATA(lt_fields)
      WHERE category = 'C10156' AND
            lowval   = @gs_screen_input-product_type AND
            highval  = 'LOAD'.
    IF sy-subrc = 0.
* Since ZDL_FIELDS-LOW value and ZZXREFDETAIL-ZZGROUPSET do not have the
* same data type, ZDL_FIELDS-LOW should be captured in a different internal
* table
      DATA(lt_groupset) = VALUE ty_t_low( FOR ls_groupset IN lt_fields
                                       ( zzgroupset = ls_groupset-lowval ) ).
      SELECT *
        FROM zzxrefdetail
        INTO TABLE @gt_primary_table_1
        FOR ALL ENTRIES IN @lt_groupset
        WHERE zzgroup = 'DELIVER' AND
              zzgroupset = @lt_groupset-zzgroupset.
      IF sy-subrc <> 0.
        CLEAR gt_primary_table_1.
      ENDIF.
      DATA(lt_fields_in_order) = CORRESPONDING ty_t_fields_in_order( gt_primary_table_1
                                       MAPPING numc = zzkey1 ).

      SORT lt_fields_in_order BY numc ASCENDING.
      CLEAR gt_primary_table_1.
      gt_primary_table_1 = CORRESPONDING #( lt_fields_in_order ).
    ENDIF.

    SELECT *
      FROM zdl_fields
      INTO TABLE @lt_fields
      WHERE category = 'C10156' AND
            highval  = 'XREF'.
    IF sy-subrc = 0.
* Since ZDL_FIELDS-LOW value and ZZXREFDETAIL-ZZGROUPSET do not have the
* same data type, ZDL_FIELDS-LOW should be captured in a different internal
* table
      lt_groupset = VALUE ty_t_low( FOR ls_groupset IN lt_fields
                                        ( zzgroupset = ls_groupset-lowval ) ).
      SELECT *
        FROM zzxrefdetail
        INTO TABLE @gt_primary_table_2
        FOR ALL ENTRIES IN @lt_groupset
        WHERE zzgroup = 'DELIVER' AND
              zzgroupset = @lt_groupset-zzgroupset.
      IF sy-subrc <> 0.
        CLEAR gt_primary_table_2.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD build_translation_data.
    DATA: lv_trigger TYPE boolean.
    FIELD-SYMBOLS: <lt_upload_data>      TYPE STANDARD TABLE,
                   <lt_translation_file> TYPE STANDARD TABLE.
* Get the excel data.
    ASSIGN gt_upload_data_ref->* TO <lt_upload_data>.

* Build translation table type from the reference.
    ASSIGN gt_translation_data_ref->* TO <lt_translation_file>.

* Build translation structure type from the reference.
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>).

* Inorder to build transaltion internal table and it is dynamic,
* the program should have the translatioin internal TABLE TYPE ready
    <lt_translation_file> = CORRESPONDING #( <lt_upload_data> ).

    LOOP AT <lt_translation_file> ASSIGNING <ls_translation_data>.
      ASSIGN <lt_upload_data>[ sy-tabix ] TO FIELD-SYMBOL(<ls_upload_data>).

      LOOP AT gt_primary_table_1 INTO DATA(ls_primary_table_1) WHERE zzgroup = 'DELIVER' AND
                                                                     zzgroupset = gs_screen_input-product_type.
* Check if the fields is ignorable. If it is ignorable, then do not consider this field
*   for anything.
        IF ls_primary_table_1-zzvalue4 = 'I'.
          CONTINUE.
        ENDIF.
        ASSIGN COMPONENT ls_primary_table_1-zzkey2
                    OF STRUCTURE <ls_upload_data> TO FIELD-SYMBOL(<ls_org_field>).

        IF ls_primary_table_1-zzkey3 = abap_true.
          DATA(ls_primary_2) = VALUE #( gt_primary_table_2[ zzgroup = 'DELIVER'
                                                            zzgroupset = 'GCF_XREF'
                                                            zzkey1     = ls_primary_table_1-zzkey2
                                                            zzkey3     = <ls_org_field> ] OPTIONAL ).
          IF ls_primary_2-zzvalue1 IS NOT INITIAL.
            DATA(lv_new_field) = |{ ls_primary_table_1-zzkey2 }{ '_NEW' }|.
            ASSIGN COMPONENT lv_new_field OF STRUCTURE <ls_translation_data> TO FIELD-SYMBOL(<ls_new_field>).
            <ls_new_field> = ls_primary_2-zzvalue1.
            <ls_org_field> = ls_primary_2-zzvalue1.
            CLEAR lv_new_field.
          ENDIF.
          CLEAR ls_primary_2.
        ENDIF.

        IF ls_primary_table_1-zzvalue2 IS NOT INITIAL AND
           ls_primary_table_1-zzvalue3 IS NOT INITIAL.
          UNASSIGN:<ls_new_field>.
          CLEAR:lv_new_field.
          lv_new_field = |{ ls_primary_table_1-zzkey2 }{ '_NEW' }|.
          ASSIGN COMPONENT lv_new_field
                  OF STRUCTURE <ls_translation_data>
                  TO <ls_new_field>.
* For a record, should trigger only once.
          IF lv_trigger IS INITIAL.
            ASSIGN COMPONENT 'MEINS'
                    OF STRUCTURE <ls_upload_data>
                    TO FIELD-SYMBOL(<lv_new_uom>).
            <ls_new_field> = ls_primary_2-zzvalue1.
            <ls_org_field> = ls_primary_2-zzvalue1.
            <lv_new_uom>   = ls_primary_table_1-zzvalue3.
            lv_trigger = abap_true.
            CLEAR lv_new_field.
          ENDIF.
* Check if UOM is maintained in the system.
          DATA(lv_config_uom) = check_config_uom( is_primary_table_1 = ls_primary_table_1 ).

          CASE lv_config_uom.
            WHEN abap_false.
              system_conversion(
                EXPORTING
                  is_field_details    = ls_primary_table_1
                CHANGING
                  cs_translation_data = <ls_translation_data>
                RECEIVING
                  rv_new_value        = <ls_new_field> ).
              lv_new_field = |{ ls_primary_table_1-zzkey2 }{ '_NEW' }|.
              ASSIGN COMPONENT lv_new_field
                          OF STRUCTURE <ls_translation_data>
                          TO FIELD-SYMBOL(<ls_upload_uom>).
              <ls_upload_uom> = <ls_new_field>.
              <ls_org_field> = <ls_new_field>.
            WHEN abap_true.
              program_conversion(
                EXPORTING
                  is_field_details    = ls_primary_table_1
                CHANGING
                  cs_translation_data = <ls_translation_data>
                RECEIVING
                  rv_new_value        = <ls_new_field> ).
              lv_new_field = |{ ls_primary_table_1-zzkey2 }{ '_NEW' }|.
              ASSIGN COMPONENT lv_new_field
                          OF STRUCTURE <ls_translation_data>
                          TO <ls_upload_uom>.
              <ls_upload_uom> = <ls_new_field>.
              <ls_org_field> = <ls_new_field>.
            WHEN OTHERS.
          ENDCASE.
        ENDIF.
      ENDLOOP.
      CLEAR lv_trigger.
    ENDLOOP.
    IF <ls_new_field> IS ASSIGNED.
      UNASSIGN <ls_new_field>.
    ENDIF.
    IF <ls_org_field> IS ASSIGNED.
      UNASSIGN <ls_org_field>.
    ENDIF.

    go_translation_data = gt_translation_data_ref.
  ENDMETHOD.
  METHOD validate_werks.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_werks>).

* Capture the plant value in a global field so that it could be used in further
* validation.
    gv_werks = <lv_werks>.

    IF <lv_werks> IS INITIAL.
*Plant is missing
      MESSAGE e011(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.

    validate_fields_lenth(
      EXPORTING
        iv_field_value = <lv_werks> ).
    IF gv_message IS NOT INITIAL.
      RETURN.
    ENDIF.

    gv_werks = |{ gv_werks ALPHA = IN }|.
    <lv_werks> = gv_werks.

* Validate if the plant is valid.
    SELECT SINGLE werks
             FROM t001w
             INTO @DATA(lv_werks)
             WHERE werks = @<lv_werks>.
    IF sy-subrc <> 0.
*      Plant &1 is invalid
      MESSAGE e012(zdl_c10156) WITH <lv_werks> INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_lgort.
* Storage location should not be empty.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_lgort>).

    gv_lgort = <lv_lgort>.

* Check if the LGORT is empty.
    IF <lv_lgort> IS INITIAL.
*      Storage location is missing
      MESSAGE e013(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.

    validate_fields_lenth(
      EXPORTING
        iv_field_value = <lv_lgort> ).
    IF gv_message IS NOT INITIAL.
      RETURN.
    ENDIF.

    gv_lgort = |{ gv_lgort ALPHA = IN }|.
    <lv_lgort> = gv_lgort.

* Check if plant and storage location is valid.
    SELECT SINGLE werks,
                  lgort,
                  xhupf,
                  parlg
         FROM t001l
         INTO @DATA(ls_slocation)
         WHERE werks = @gv_werks AND
               lgort = @<lv_lgort>.
    IF sy-subrc <> 0.
*      Invalid Plant &1 / Storage location &2.
      MESSAGE e014(zdl_c10156) WITH gv_werks
                                    <lv_lgort>
                                 INTO gv_message.
    ELSE.
      IF ls_slocation-xhupf = abap_true.
        APPEND ls_slocation TO gt_slocation.
      ELSE.
        gv_no_xhupf = abap_true.
*->Begin of non-HU check/CD2000007614
        IF ls_slocation-parlg IS INITIAL.
          gv_no_parlg = abap_true.
        ENDIF.
*-<End of non-HU check/CD2000007614
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD validate_lgort_hu.
    validate_lgort(
      CHANGING
        cs_alv_output_data = cs_alv_output_data ).
    IF gv_no_xhupf = abap_true.
*      Plant &1 / Storage location &2 is not HU managed
      MESSAGE e064(zdl_c10156) WITH gv_werks
                                    gv_lgort
                                INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_matnr.
* Material should not be empty.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_matnr>).

    gv_matnr = <lv_matnr>.

    IF <lv_matnr> IS INITIAL.
*      Material is missing
      MESSAGE e015(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.

    validate_fields_lenth(
      EXPORTING
        iv_field_value = <lv_matnr> ).
    IF gv_message IS NOT INITIAL.
      RETURN.
    ENDIF.

    gv_matnr = |{ gv_matnr ALPHA = IN }|.
    <lv_matnr> = gv_matnr.

* Validate if the material is valid.
    SELECT SINGLE matnr
             FROM mara
             INTO @DATA(lv_matnr)
             WHERE matnr = @<lv_matnr>.
    IF sy-subrc <> 0.
*      Material &1 is Invalid
      MESSAGE e016(zdl_c10156) WITH <lv_matnr> INTO gv_message.
      RETURN.
    ENDIF.

* Validate if the material is extended to plant
    SELECT SINGLE matnr,
                  werks,
                  prctr
      FROM marc
      INTO @DATA(ls_matnr_ext)
      WHERE matnr = @<lv_matnr> AND
            werks = @gv_werks.
    IF sy-subrc <> 0.
*      Material &1 is not extended to Plant &2
      MESSAGE e017(zdl_c10156) WITH <lv_matnr>
                                    gv_werks
                                INTO gv_message.
      RETURN.
    ELSE.
      gv_profit_center = ls_matnr_ext-prctr.
      APPEND ls_matnr_ext TO gt_profit_center.
      CLEAR ls_matnr_ext.
    ENDIF.

* Validate material and plant is extended to storage location.
    SELECT SINGLE matnr,
                  werks,
                  lgort
      FROM mard
      INTO @DATA(ls_matnr_sloc_ext)
      WHERE matnr = @<lv_matnr> AND
            werks = @gv_werks   AND
            lgort = @gv_lgort.
    IF sy-subrc <> 0.
*      Material &1 is not extended to Plant &2 Storage location &3
      MESSAGE e018(zdl_c10156) WITH <lv_matnr>
                                    gv_werks
                                    gv_lgort
                                INTO gv_message.
      RETURN.
    ENDIF.

* If storage location is HU managed storage location then make sure
* the material is extended to the Partner Storage location.
    DATA(ls_slocation_ext) = VALUE #( gt_slocation[ werks = gv_werks
                                                    lgort = gv_lgort ] OPTIONAL ).
    IF ls_slocation_ext IS NOT INITIAL AND
       ls_slocation_ext-xhupf IS NOT INITIAL.
      SELECT SINGLE matnr,
                    werks,
                    lgort
        FROM mard
        INTO @ls_matnr_sloc_ext
        WHERE matnr = @<lv_matnr> AND
              werks = @gv_werks   AND
              lgort = @ls_slocation_ext-parlg.
      IF sy-subrc <> 0.
*        Material &1 is not extended to Plant &2 Storage location &3
        MESSAGE e018(zdl_c10156) WITH <lv_matnr>
                                      gv_werks
                                      ls_slocation_ext-parlg
                                  INTO gv_message.
      ENDIF.
    ENDIF.
    CLEAR ls_slocation_ext.
  ENDMETHOD.
  METHOD validate_charg.
* Batch should not be empty.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_charg>).
    gv_charg = <lv_charg>.

    IF <lv_charg> IS INITIAL.
*      Batch is missing
      MESSAGE e020(zdl_c10156) INTO gv_message.
      gv_subrc = 4.
      RETURN.
    ENDIF.

    validate_fields_lenth(
      EXPORTING
        iv_field_value = <lv_charg> ).
    IF gv_message IS NOT INITIAL.
      gv_subrc = 4.
      RETURN.
    ENDIF.

*Check if batch exists in MCH1 by passing Material, batch
    SELECT SINGLE matnr,
                  charg
            FROM mch1
            INTO @DATA(ls_batch)
             WHERE matnr = @gv_matnr AND
                   charg = @<lv_charg>.
    gv_subrc = sy-subrc.
  ENDMETHOD.
  METHOD validate_goods_matnr.
    validate_matnr(
      CHANGING
        cs_alv_output_data = cs_alv_output_data ).

    IF gv_profit_center IS INITIAL.
*      Profit Center is missing for Material &1 / Plant &2
      MESSAGE e022(zdl_c10156) WITH gv_matnr
                                    gv_werks
                                  INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_create_charg.
    validate_charg(
      CHANGING
        cs_alv_output_data = cs_alv_output_data ).
    IF gv_subrc = 0.
*      Batch &1 already exists
      MESSAGE e038(zdl_c10156) WITH gv_charg
                               INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_charg_for_gr_hu.
    validate_charg(
      CHANGING
        cs_alv_output_data = cs_alv_output_data ).
    IF gv_subrc <> 0.
*      Batch &1 does not exists
      MESSAGE e021(zdl_c10156) WITH gv_charg
                               INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_menge.
    DATA: lv_numc  TYPE string VALUE '0123456789',
          lv_menge TYPE menge_d.

* Quantity should not be empty.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_menge>).

* Quantity should not be empty.
    IF <lv_menge> IS INITIAL.
*      Weight is missing
      MESSAGE e026(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.
    lv_menge = <lv_menge>.
    <lv_menge> = |{ lv_menge }|.
* Check if the quantity field contains any non numc value
    IF NOT <lv_menge> CA lv_numc.
*      In valid value &1 in weight field
      MESSAGE e067(zdl_c10156) WITH <lv_menge>
                               INTO gv_message.
      RETURN.
    ENDIF.

    validate_fields_lenth( iv_field_value = <lv_menge> ).
    IF gv_message IS NOT INITIAL.
      RETURN.
    ENDIF.

* Decimal validate.
*    DATA: lv_round TYPE string.
*    lv_round = round( val = <lv_menge> dec = 3 ).
    <lv_menge> = round( val = <lv_menge> dec = 3 ).
    SPLIT <lv_menge> AT '.' INTO DATA(lv_whole_num)
                                 DATA(lv_decimal_num).
    DATA(lv_field_lenth) = strlen( lv_decimal_num ).
    IF lv_field_lenth > 3.
*      Invalid value &1 for the field &2
      MESSAGE e039(zdl_c10156) WITH <lv_menge>
                                    gs_primary_1-zzkey2
                               INTO gv_message.
      CLEAR lv_whole_num.
      RETURN.
    ENDIF.
* Only for ATC checks
    IF lv_whole_num IS NOT INITIAL.
      CLEAR: lv_whole_num,
             lv_decimal_num.
    ENDIF.

* Conversion factor validation.
    IF gs_primary_1-zzvalue3 IS NOT INITIAL.
* In this case conversion is required from Legacy to SAP
      SELECT SINGLE msehi
               FROM t006a
               INTO @DATA(lv_msehi)
               WHERE spras = @sy-langu AND
                     msehi = @gs_primary_1-zzvalue3.
      IF sy-subrc <> 0.
*        Invalid SAP UOM &1
        MESSAGE e040(zdl_c10156) WITH gs_primary_1-zzvalue3
                                 INTO gv_message.
        RETURN.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD validate_meins.
* Quantity should not be empty.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_meins>).

    IF <lv_meins> IS INITIAL.
*      UOM is missing
      MESSAGE e027(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.

    <lv_meins> = to_upper( <lv_meins> ).

    SELECT SINGLE msehi
             FROM t006a
             INTO @DATA(lv_msehi)
             WHERE spras = @sy-langu AND
                   msehi = @<lv_meins>.
    IF sy-subrc <> 0.
*      Invalid SAP UOM &1
      MESSAGE e040(zdl_c10156) WITH <lv_meins>
                               INTO gv_message.
      RETURN.
    ENDIF.
  ENDMETHOD.
  METHOD validate_sobkz.
* Quantity should not be empty.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_sobkz>).

    gv_sobkz = |{ <lv_sobkz> }|.

    IF gv_sobkz <> 'E' AND
       gv_sobkz <> 'W' AND
       gv_sobkz <> space.
*      Invalid Special Stock – &1
      MESSAGE e028(zdl_c10156) WITH gv_sobkz
                              INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_vbeln_posnr.
* Get the value of the fields.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_vbeln>).

    IF <lv_vbeln> IS ASSIGNED.
      gv_vbeln = <lv_vbeln>.
      gv_vbeln = |{ gv_vbeln ALPHA = IN }|.
      <lv_vbeln> = gv_vbeln.
      CLEAR gv_vbeln.
    ENDIF.

    ASSIGN COMPONENT 'POSNR'
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_posnr>).

    IF <lv_posnr> IS ASSIGNED.
      gv_posnr = <lv_posnr>.
      gv_posnr = |{ gv_posnr ALPHA = IN }|.
      <lv_posnr> = gv_posnr.
      CLEAR gv_posnr.
    ENDIF.

    CASE gv_sobkz.
      WHEN 'E'.
        IF <lv_vbeln> IS INITIAL.
*          Sales order is missing
          MESSAGE e029(zdl_c10156) INTO gv_message.
          RETURN.
        ENDIF.
        IF <lv_posnr> IS INITIAL.
*          Sales order item is missing
          MESSAGE e030(zdl_c10156) INTO gv_message.
          RETURN.
        ENDIF.
* Validate sales order and item.
        SELECT SINGLE vbeln,
                      posnr
          FROM vbap
          INTO (@DATA(lv_vbeln),
                @DATA(lv_posnr))
          WHERE vbeln = @<lv_vbeln> AND
                posnr = @<lv_posnr>.
        IF sy-subrc <> 0.
*         Sales Order &1, line item &2 does not exists
          MESSAGE e042(zdl_c10156) WITH <lv_vbeln>
                                        <lv_posnr>
                                   INTO gv_message.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD validate_kunnr.
* Get the value of the fields.
    CHECK gv_sobkz = 'W'.
    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_kunnr>).

    IF <lv_kunnr> IS INITIAL.
*      Customer number is missing
      MESSAGE e031(zdl_c10156) INTO gv_message.
      RETURN.
    ENDIF.
    gv_kunnr = |{ <lv_kunnr> ALPHA = IN }|.
    <lv_kunnr> = gv_kunnr.

    SELECT SINGLE kunnr
      FROM kna1
      INTO @DATA(lv_kunnr)
      WHERE kunnr = @<lv_kunnr>.
    IF sy-subrc <> 0.
*      Customer Number &1 not found
      MESSAGE e043(zdl_c10156) WITH <lv_kunnr>
                               INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_hsdat.

    DATA lv_hsdat TYPE mcha-hsdat.

    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_hsdat>).

    IF <lv_hsdat> IS NOT INITIAL.

      lv_hsdat = <lv_hsdat>.

      CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
        EXPORTING
          date                      = lv_hsdat
        EXCEPTIONS
          plausibility_check_failed = 1
          OTHERS                    = 2.

      IF sy-subrc <> 0.
        MESSAGE e079(zdl_c10156) WITH <lv_hsdat> INTO gv_message.
        RETURN.
      ENDIF.

    ENDIF.

  ENDMETHOD.
  METHOD validate_characteristics.
    TYPES: BEGIN OF ty_s_objek,
             objek TYPE objnum,
           END OF ty_s_objek,
           ty_t_objek TYPE STANDARD TABLE OF ty_s_objek WITH EMPTY KEY.

    DATA: lv_value TYPE string VALUE
  'abcdefghijklmnopqrstuvwxyz<,>?/:;"{[}]|\+=_-)(*&^%$#@!'.

    DATA: lv_numc TYPE string VALUE '0123456789'.

    ASSIGN COMPONENT gs_primary_1-zzkey2
                OF STRUCTURE cs_alv_output_data
                TO FIELD-SYMBOL(<lv_char>).

*->Begin Of Ins CD2000007614
    CLEAR gr_atnam_rg.
    gr_atnam_rg = VALUE zsd_oip_cons_atnam_rtab( LET s = 'I' o = 'EQ'
                                                  IN sign = s option = o
                                               ( low = 'PULP_BASIS_WEIGHT' )
                                               ( low = 'METRIC_PULP_BASIS_WEIGHT' )
                                               ( low = 'ROLL_WIDTH' )
                                               ( low = 'ROLL_WIDTH_MIL' )
                                               ( low = 'ROLL_DIAMETER' ) ).


    IF gs_primary_1-zzkey2 IN gr_atnam_rg[].
      CALL METHOD validate_matnr_characteristics(
        CHANGING
          cs_alv_output_data = cs_alv_output_data ).
    ENDIF.
*-<End Of Ins CD2000007614

* Validate if the entered value is valid.
    SELECT atinn,
           adzhl,
           atnam,
           atfor,
           anzst,
           anzdz
      FROM cabn
      INTO TABLE @DATA(lt_cabn)
      WHERE atnam = @gs_primary_1-zzkey2.
    IF sy-subrc <> 0.
*     Invalid batch character &1 in ZZXREFDETAIL
      MESSAGE e023(zdl_c10156) WITH gs_primary_1-zzkey2
                                  INTO gv_message.
      RETURN.
    ENDIF.

* Find Char for matnr.
*Link between Internal Number and Object
    SELECT cuobj,
           obtab,
           objek
      FROM inob
      INTO TABLE @DATA(lt_inob)
      WHERE obtab = 'MARA' AND
            objek = @gv_matnr.
    IF sy-subrc <> 0.
*      CUOBJ is missing for the material &1
      MESSAGE e033(zdl_c10156) WITH gv_matnr
                                INTO gv_message.
      RETURN.
    ENDIF.

    DATA(lt_objek) = VALUE ty_t_objek( FOR ls_inob_cuobj IN lt_inob
                                     ( objek = |{ ls_inob_cuobj-cuobj } | ) ).
    IF lt_objek IS NOT INITIAL.
      SELECT objek,
             klart,
             clint
        FROM kssk
        INTO TABLE @DATA(lt_kssk)
        FOR ALL ENTRIES IN @lt_objek
        WHERE objek = @lt_objek-objek AND
              klart = '023'.
      IF sy-subrc <> 0.
*        No entry found in KSSK for the material &1
        MESSAGE e034(zdl_c10156) WITH gv_matnr
                                  INTO gv_message.
        RETURN.
      ENDIF.
    ENDIF.

    DATA(ls_cabn) = VALUE #( lt_cabn[ 1 ] OPTIONAL ).

    IF lt_kssk IS NOT INITIAL.
      SELECT clint,
             klart,
             class
         FROM klah
         INTO TABLE @DATA(lt_klah)
         FOR ALL ENTRIES IN @lt_kssk
         WHERE clint = @lt_kssk-clint.
      IF sy-subrc <> 0.
        CLEAR lt_klah.
      ENDIF.

      SELECT clint,
             imerk
        FROM ksml
        INTO TABLE @DATA(lt_ksml)
        FOR ALL ENTRIES IN @lt_kssk
        WHERE clint = @lt_kssk-clint AND
              imerk = @ls_cabn-atinn.
      IF sy-subrc = 0 AND
        <lv_char> IS INITIAL AND
        gs_primary_1-zzvalue4 = 'M'.
*        gs_primary_1-zzvalue4 IS NOT INITIAL.
*        &1 is missing
        MESSAGE e024(zdl_c10156) WITH gs_primary_1-zzkey2
                                    INTO gv_message.
        RETURN.
      ENDIF.
    ENDIF.

    IF ls_cabn-anzdz IS NOT INITIAL.
      IF <lv_char> CA lv_value.
*        Invalid format for the field &1
        MESSAGE e044(zdl_c10156) WITH gs_primary_1-zzkey2
                                    INTO gv_message.
        RETURN.
      ENDIF.

      IF ls_cabn-atfor = 'NUM'.
        IF to_lower( <lv_char> ) CA lv_value.
          MESSAGE e044(zdl_c10156) WITH gs_primary_1-zzkey2
                                      INTO gv_message.
          RETURN.
        ENDIF.
      ENDIF.
*      <lv_char> = round( val = <lv_char> dec = 3 ). "CD2000007614
      SPLIT <lv_char> AT '.' INTO DATA(lv_whole_num)
                                  DATA(lv_decimal).
      DATA(lv_dec_lenth) = strlen( lv_decimal ).
      IF lv_dec_lenth > ls_cabn-anzdz.
*        Invalid format for the field &1
        MESSAGE e044(zdl_c10156) WITH gs_primary_1-zzkey2
                                    INTO gv_message.
        RETURN.
      ENDIF.
    ENDIF.

* This is where the program decides if the Characteristics belong to the
* material entered in the output file.

* Read INOB table to get the Link between Internal Number and Object
    DATA(ls_inob) = VALUE #( lt_inob[ obtab = 'MARA'
                                      objek = gv_matnr ] OPTIONAL ).

* Read KSSK table  to get class from the object
    DATA(ls_batch_kssk) = VALUE #( lt_kssk[ objek = CONV objnum( ls_inob-cuobj )
                                            klart = '023' ] OPTIONAL ).

    DATA(ls_batch_klah) = VALUE #( lt_klah[ clint = ls_batch_kssk-clint ] OPTIONAL ).

* Once you get the class, then read table KSML to check if the characteristics
* belong to the class and the material entered in the upload file.
    DATA(ls_ksml) = VALUE #( lt_ksml[ clint = ls_batch_kssk-clint
                                      imerk = ls_cabn-atinn ] OPTIONAL ).

* The output of KSML table is the list of characteristics
* for the material/batch that we need to load
    IF ls_ksml IS NOT INITIAL.

*->Begin Of Ins CD2000007614
      IF gs_primary_1-zzkey2 IN gr_atnam_rg AND gr_atnam_rg IS NOT INITIAL.
        ls_batch_kssk-objek =  gv_cuobj.
      ENDIF.
*-<End Of Ins CD2000007614

* Append value to bathc char/NUMC table.
      CASE ls_cabn-atfor.
        WHEN 'CHAR' OR 'DATE' OR 'TIME' OR 'UDEF'.
          APPEND VALUE #( matnr      = gv_matnr
                          class_num  = ls_batch_klah-class
                          object_key = ls_batch_kssk-objek
                          char_name  = ls_cabn-atnam ) TO gt_batch_char.
        WHEN 'NUM'.
          IF NOT <lv_char> CA lv_numc AND
             NOT <lv_char> EQ space.
            MESSAGE e071(zdl_c10156) WITH  <lv_char>
                                           ls_cabn-atnam
                                      INTO gv_message.
            CLEAR:ls_batch_kssk,
                  ls_batch_klah,
                  ls_inob,
                  ls_ksml,
                  ls_cabn.
            RETURN.
          ELSE.
            APPEND VALUE #( matnr      = gv_matnr
                            class_num  = ls_batch_klah-class
                            object_key = ls_batch_kssk-objek
                            char_name  = ls_cabn-atnam ) TO gt_batch_num.
          ENDIF.
        WHEN OTHERS.
          MESSAGE e000(zdl_c10156) WITH ls_cabn-atnam
                                    INTO gv_message.
      ENDCASE.
    ENDIF.

    CLEAR:ls_batch_kssk,
          ls_batch_klah,
          ls_inob,
          ls_ksml,
          ls_cabn.

* Only For ATC chekcs
    IF lv_whole_num IS NOT INITIAL.
      CLEAR: lv_whole_num,
             lv_decimal.
    ENDIF.
  ENDMETHOD.
  METHOD validate_matnr_characteristics.

    DATA lt_config TYPE STANDARD TABLE OF conf_out.

    CLEAR: lt_config,gv_cuobj.

    IF gv_matnr IS NOT INITIAL.

*-get relevant CUOBJ value
      get_cuobj( cs_alv_output_data ).     "CD2000007614

      IF gv_cuobj IS NOT INITIAL.

        CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
          EXPORTING
            instance           = gv_cuobj
*           BUSINESS_OBJECT    =
*           language           = sy-langu
*           IV_INVALID_POSSIBLE       = ' '
*           iv_neutral         = 'X'
          TABLES
            configuration      = lt_config
*           ET_CONF_WITH_AUTHOR       =
          EXCEPTIONS
            instance_not_found = 1
            OTHERS             = 2.

        IF sy-subrc <> 0.
          MESSAGE e078(zdl_c10156) WITH gv_matnr gv_werks gv_cuobj
                                   INTO gv_message.
        ELSE.

          ASSIGN COMPONENT gs_primary_1-zzkey2
                      OF STRUCTURE cs_alv_output_data
                      TO FIELD-SYMBOL(<lv_char_val>).

          IF <lv_char_val> IS INITIAL OR gs_screen_input-except_proc IS INITIAL.  "CD2000007614

            DATA(lv_config_val) = VALUE #( lt_config[ atnam = gs_primary_1-zzkey2 ]-atwrt OPTIONAL ).

            SPLIT lv_config_val AT space INTO lv_config_val DATA(lv_uom).    "CD2000007614
            REPLACE ALL OCCURRENCES OF ',' IN lv_config_val WITH space.
            CONDENSE lv_config_val.

            IF lv_config_val IS NOT INITIAL.
              <lv_char_val> = lv_config_val.
            ENDIF.

          ENDIF.

        ENDIF.

      ENDIF.

    ENDIF.

  ENDMETHOD.
  METHOD get_cuobj.

    IF gs_primary_1-zzkey2 EQ 'PULP_BASIS_WEIGHT' OR
       gs_primary_1-zzkey2 EQ 'METRIC_PULP_BASIS_WEIGHT'.

      SELECT SINGLE cuobj INTO gv_cuobj FROM marc
                          WHERE matnr EQ gv_matnr
                            AND werks EQ gv_werks.

    ELSE.

      IF  gs_screen_input-except_proc IS INITIAL.

        SELECT SINGLE mtart INTO @DATA(lv_mtart) FROM mara
                                  WHERE matnr EQ @gv_matnr.
        CASE lv_mtart.

          WHEN 'PRD3'.

            ASSIGN COMPONENT 'VBELN'
                         OF STRUCTURE is_alv_output_data
                         TO FIELD-SYMBOL(<fs_vbeln>).

            ASSIGN COMPONENT 'POSNR'
                         OF STRUCTURE is_alv_output_data
                         TO FIELD-SYMBOL(<fs_posnr>).

            IF <fs_vbeln> IS ASSIGNED AND <fs_posnr> IS ASSIGNED.

              SELECT SINGLE cuobj INTO gv_cuobj FROM vbap
                                  WHERE vbeln EQ <fs_vbeln>
                                    AND posnr EQ <fs_posnr>.
            ENDIF.

          WHEN 'PRD4'.

            SELECT SINGLE cuobj INTO gv_cuobj FROM marc
                                WHERE matnr EQ gv_matnr
                                  AND werks EQ gv_werks.

          WHEN OTHERS.

        ENDCASE.

      ENDIF.

    ENDIF.

  ENDMETHOD.
  METHOD validate_fields_lenth.
    DATA: lv_value TYPE string VALUE
  'abcdefghijklmnopqrstuvwxyz<,>?/:;"{[}]|\+=_-)(*&^%$#@!'.
** Check the lent of the field matching with Data element.
    IF gs_primary_1-zzvalue1 IS INITIAL.
      SELECT SINGLE datatype,
                    leng,
                    decimals
        FROM dd01l
        INTO (@DATA(lv_datatype),
              @DATA(lv_lenth),
              @DATA(lv_dec))
        WHERE domname = @gs_primary_1-zzkey2 AND
              as4local = 'A' AND
              as4vers  = '0000'.
      IF sy-subrc <> 0.
*        Invalid Data Element &1 in table ZZXREFDETAIL
        MESSAGE e035(zdl_c10156) WITH gs_primary_1-zzvalue5
                                 INTO gv_message.
        RETURN.
      ENDIF.

      CASE lv_datatype.
        WHEN 'CHAR'.
          DATA(lv_field_lenth) = strlen( iv_field_value ).
          IF  lv_lenth < lv_field_lenth.
            WRITE lv_lenth TO lv_lenth USING EDIT MASK '==ALPHA'.
*            Allowed lenth for the field &1 is &2. Actual lenth is &3
            MESSAGE e036(zdl_c10156) WITH gs_primary_1-zzkey2
                                          lv_lenth
                                          lv_field_lenth
                           INTO gv_message.
            RETURN.
          ENDIF.
        WHEN 'NUMC' OR 'QUAN' OR 'UNIT'.
          lv_field_lenth = strlen( iv_field_value ).
          DATA(lv_field_value) = to_lower( iv_field_value ).
          IF lv_field_value CA lv_value.
*            Invalid value &1 for the field &2
            MESSAGE e039(zdl_c10156) WITH iv_field_value
                                          gs_primary_1-zzkey2
                                     INTO gv_message.
            RETURN.
          ENDIF.
          IF  lv_lenth < lv_field_lenth.
*            Allowed lenth for the field &1 is &2. Actual lenth is &3
            MESSAGE e036(zdl_c10156) WITH gs_primary_1-zzkey2
                                          lv_lenth
                                          lv_field_lenth
                           INTO gv_message.
            RETURN.
          ENDIF.
        WHEN OTHERS.
      ENDCASE.
    ENDIF.
  ENDMETHOD.
  METHOD create_batch.
    DATA: lt_batch_cahr       TYPE bapi3060_valuations_char,
          lt_batch_num        TYPE bapi3060_valuations_num,
          ls_batchattributes  TYPE bapibatchatt,              "CD2000007614
          ls_batchattributesx TYPE bapibatchattx,              "CD2000007614
          lt_classification   TYPE bapi3060_allocations,
          lt_return           TYPE bapiret2_t.

    DATA: lv_class TYPE klasse_d.

    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE,
                   <lt_tansactional_data> TYPE STANDARD TABLE.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .
    ASSIGN gt_translation_data_ref->* TO <lt_tansactional_data> .
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>) .

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_fields_in_order) ).

    LOOP AT <lt_upload_data> ASSIGNING FIELD-SYMBOL(<ls_upload_data>).
* Create batch only for the error free record,
      ASSIGN COMPONENT 'MESSAGE'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_message>).
      IF <lv_message> IS NOT INITIAL.
        CONTINUE.
      ENDIF.

      fill_required_global_field(
        CHANGING
          cs_alv_output_data = <ls_upload_data> ).

      SELECT SINGLE charg
              FROM mch1
              INTO @DATA(lv_charg)
            WHERE matnr = @gv_matnr AND
                  charg = @gv_charg.
      IF sy-subrc = 0.
*        Batch &1 already exists
        MESSAGE e038(zdl_c10156) WITH lv_charg
                                 INTO gv_message.
        <lv_message> = gv_message.
        CONTINUE.
      ENDIF.
      <ls_translation_data> = <lt_tansactional_data>[ sy-tabix ].

* Determine the char field for the material.Those fields are
* 1. SALES_GRADE
* 2. SALES_BASIS_WEIGHT
* 3. SALES_COLOR
* 4. SALES_SURFACE
      SELECT SINGLE *
             FROM mara
             INTO @DATA(ls_matnr_char)
             WHERE matnr = @gv_matnr.
      IF sy-subrc <> 0.
        CLEAR ls_matnr_char.
      ENDIF.

      LOOP AT lt_fields_in_order INTO DATA(ls_fields_in_order).
* Check if the fields is ignorable. If it is ignorable,
*  then do not consider for creation process
        IF ls_fields_in_order-zzvalue4 = 'I'.
          CONTINUE.
        ENDIF.

        IF ls_fields_in_order-zzkey3 IS INITIAL.
          ASSIGN COMPONENT ls_fields_in_order-zzkey2
         OF STRUCTURE <ls_upload_data>
         TO FIELD-SYMBOL(<lv_zzkey2>).
        ELSE.
          DATA(lv_name) = |{ ls_fields_in_order-zzkey2 }{ '_NEW' }|.
          ASSIGN COMPONENT lv_name
         OF STRUCTURE <ls_translation_data>
         TO <lv_zzkey2>.
        ENDIF.

        DATA: lv_obj_key TYPE objnum.
        lv_obj_key+0(18)  = gv_matnr.
        lv_obj_key+18(10) = gv_charg.

* Read both CHAR table and NUM table.
        DATA(ls_batch_cahr) = VALUE #( gt_batch_char[ matnr = gv_matnr
                                                      char_name = ls_fields_in_order-zzkey2
                                                       ] OPTIONAL ).
        IF ls_batch_cahr IS NOT INITIAL.
          CASE ls_fields_in_order-zzkey2.
            WHEN 'SALES_GRADE'.
              APPEND VALUE #( class_type  = '023'
                              objectkey   = lv_obj_key
                              objecttable = 'MCH1'
                              charact     = ls_batch_cahr-char_name
                              value_char  = ls_matnr_char-zzslgrd ) TO lt_batch_cahr.
              ASSIGN COMPONENT 'SALES_GRADE'
                     OF STRUCTURE <ls_upload_data>
                     TO FIELD-SYMBOL(<lv_sales_grade>).
              IF <lv_sales_grade> IS ASSIGNED.
                <lv_sales_grade> = ls_matnr_char-zzslgrd.
              ENDIF.
            WHEN 'SALES_COLOR'.
              APPEND VALUE #( class_type  = '023'
                              objectkey   = lv_obj_key
                              objecttable = 'MCH1'
                              charact     = ls_batch_cahr-char_name
                              value_char  = ls_matnr_char-zzslclr ) TO lt_batch_cahr.
              ASSIGN COMPONENT 'SALES_COLOR'
                     OF STRUCTURE <ls_upload_data>
                     TO FIELD-SYMBOL(<lv_sales_color>).
              IF <lv_sales_color> IS ASSIGNED.
                <lv_sales_color> = ls_matnr_char-zzslclr.
              ENDIF.
            WHEN 'SALES_SURFACE'.
              APPEND VALUE #( class_type  = '023'
                              objectkey   = lv_obj_key
                              objecttable = 'MCH1'
                              charact     = ls_batch_cahr-char_name
                              value_char  = ls_matnr_char-zzslsur ) TO lt_batch_cahr.
              ASSIGN COMPONENT 'SALES_SURFACE'
                     OF STRUCTURE <ls_upload_data>
                     TO FIELD-SYMBOL(<lv_sales_surface>).
              IF <lv_sales_surface> IS ASSIGNED.
                <lv_sales_surface> = ls_matnr_char-zzslsur.
              ENDIF.
            WHEN OTHERS.
*->Begin Of Ins CD2000007614
              IF ls_fields_in_order-zzkey2 IN gr_atnam_rg.

                ASSIGN COMPONENT ls_fields_in_order-zzkey2 OF STRUCTURE <ls_upload_data>
                TO FIELD-SYMBOL(<fs_batch_char>).

                IF <fs_batch_char> IS ASSIGNED AND <fs_batch_char> IS NOT INITIAL.
                  APPEND VALUE #( class_type  = '023'
                                  objectkey   = lv_obj_key
                                  objecttable = 'MCH1'
                                  charact     = ls_fields_in_order-zzkey2
                                  value_char  = <fs_batch_char> ) TO lt_batch_cahr.
                ENDIF.

              ELSE.
*-<End Of Ins CD2000007614
                APPEND VALUE #( class_type  = '023'
                                objectkey   = lv_obj_key
                                objecttable = 'MCH1'
                                charact     = ls_batch_cahr-char_name
                                value_char  = <lv_zzkey2> ) TO lt_batch_cahr.
              ENDIF.                                                        "CD2000007614
          ENDCASE.
*          APPEND VALUE #( class_type  = '023'
*                          objectkey   = lv_obj_key
*                          objecttable = 'MCH1'
*                          charact     = ls_batch_cahr-char_name
*                          value_char  = <lv_zzkey2> ) TO lt_batch_cahr.
        ENDIF.

* Read both CHAR table and NUM table.
        DATA(ls_batch_num) = VALUE #( gt_batch_num[ matnr = gv_matnr
                                                    char_name = ls_fields_in_order-zzkey2
                                                  ] OPTIONAL ).
        IF ls_batch_num IS NOT INITIAL.

          CASE ls_fields_in_order-zzkey2.
            WHEN 'SALES_BASIS_WEIGHT'.
              APPEND VALUE #( class_type  = '023'
                              objectkey   = lv_obj_key
                              objecttable = 'MCH1'
                              charact     = ls_batch_num-char_name
                              value_from  = ls_matnr_char-zzslbwt ) TO lt_batch_num.
              ASSIGN COMPONENT 'SALES_BASIS_WEIGHT'
                     OF STRUCTURE <ls_upload_data>
                     TO FIELD-SYMBOL(<lv_sales_basis_weight>).
              IF <lv_sales_basis_weight> IS ASSIGNED.
                <lv_sales_basis_weight> = ls_matnr_char-zzslbwt.
              ENDIF.
            WHEN OTHERS.
*->Begin Of Ins CD2000007614
              IF ls_fields_in_order-zzkey2 IN gr_atnam_rg.

                ASSIGN COMPONENT ls_fields_in_order-zzkey2 OF STRUCTURE <ls_upload_data>
                TO FIELD-SYMBOL(<fs_batch_num>).

                IF <fs_batch_num> IS ASSIGNED AND <fs_batch_num> IS NOT INITIAL.
                  APPEND VALUE #( class_type  = '023'
                                  objectkey   = lv_obj_key
                                  objecttable = 'MCH1'
                                  charact     = ls_fields_in_order-zzkey2
                                  value_from  = <fs_batch_num> ) TO lt_batch_num.
                ENDIF.


              ELSE.
*-<End Of Ins CD2000007614

                APPEND VALUE #( class_type  = '023'
                                objectkey   = lv_obj_key
                                objecttable = 'MCH1'
                                charact     = ls_batch_num-char_name
                                value_from  = <lv_zzkey2> ) TO lt_batch_num.
              ENDIF.                                                         "CD2000007614
          ENDCASE.

*          APPEND VALUE #( class_type  = '023'
*                          objectkey   = lv_obj_key
*                          objecttable = 'MCH1'
*                          charact     = ls_batch_num-char_name
*                          value_from  = <lv_zzkey2> ) TO lt_batch_num.
          IF lv_class IS INITIAL.
            IF ls_batch_num-char_name IS NOT INITIAL.
              lv_class = ls_batch_num-class_num.
            ELSEIF ls_batch_cahr-char_name IS NOT INITIAL.
              lv_class = ls_batch_cahr-class_num.
            ENDIF.
          ENDIF.
        ENDIF.

*->Begin Of Ins CD2000007614
        IF ls_fields_in_order-zzkey2 EQ 'HSDAT'.

          ASSIGN COMPONENT ls_fields_in_order-zzkey2
          OF STRUCTURE <ls_upload_data>
          TO FIELD-SYMBOL(<lv_hsdat>).

          IF <lv_hsdat> IS NOT INITIAL.
            ls_batchattributes-prod_date = <lv_hsdat>.
            ls_batchattributesx-prod_date = 'X'.
          ENDIF.

        ENDIF.
*-<End Of Ins CD2000007614

        AT LAST.
          DATA(ls_batchcontrolfields) = VALUE bapibatchctrl( class_num = lv_class
                                                             doclassify = abap_true ).

          APPEND VALUE #( class_type = '023'
                          objectkey = lv_obj_key
                          objecttable = 'MCH1'
                          object = lv_obj_key
                          classnum = lv_class
                          classtype = '023' ) TO lt_classification.
          CLEAR lv_class.
        ENDAT.
        CLEAR: lv_obj_key,
               ls_batch_cahr,
               ls_batch_num.
      ENDLOOP.

      ASSIGN COMPONENT 'SUCCESS'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_success>).

* Call FM to create a batch.
      IF gs_screen_input-test_mode IS INITIAL.
        CALL FUNCTION 'BAPI_BATCH_SAVE_REPLICA'
          EXPORTING
            material             = gv_matnr
            batch                = gv_charg
            plant                = gv_werks
            batchattributes      = ls_batchattributes
            batchattributesx     = ls_batchattributesx
            batchcontrolfields   = ls_batchcontrolfields
            batchstoragelocation = gv_lgort
          TABLES
            return               = lt_return
            classallocations     = lt_classification
            classvaluationschar  = lt_batch_cahr
            classvaluationsnum   = lt_batch_num.

        IF lt_return IS NOT INITIAL.
          LOOP AT lt_return INTO DATA(ls_return) WHERE type = 'E' OR
                                                       type = 'A'.
            MESSAGE e000(zdl_c10156) WITH ls_return-message
                                       INTO gv_message.
            <lv_message> = gv_message.
            RETURN.
          ENDLOOP.
          CLEAR ls_return.
        ENDIF.
        IF lt_return IS NOT INITIAL.
          ls_return =  VALUE #( lt_return[ type = 'S' ] OPTIONAL ).
          IF ls_return IS NOT INITIAL.
*            Batch &1 is successfully created
*            MESSAGE s049(zdl_c10156) WITH gv_charg
*                                      INTO gv_message.
            MESSAGE s072(zdl_c10156) INTO gv_message.
            <lv_message> = gv_message.
            <lv_success> = abap_true.
          ENDIF.
        ENDIF.
      ELSE.
        MESSAGE e069(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        <lv_success> = abap_true.
      ENDIF.
* Clear
      CLEAR: lt_batch_cahr,
             lt_batch_num,
             lt_classification,
             lt_return.
    ENDLOOP.
    UNASSIGN: <ls_translation_data>.
  ENDMETHOD.
  METHOD read_application_file_data.
    cl_rsan_ut_appserv_file_reader=>appserver_file_read(
      EXPORTING
        i_filename   = gs_screen_input-app_file_path
        i_lines      = 0
      CHANGING
        c_data_tab   = gt_raw_app_file_data
      EXCEPTIONS
        open_failed  = 1
        read_failed  = 2
        close_failed = 3
        OTHERS       = 4 ).

    IF sy-subrc <> 0.
*->Begin Of Change CD2000007614
*      MESSAGE e000(zdl_c10156) WITH sy-msgv1
*                                    sy-msgv2
*                                    sy-msgv3
*                                    sy-msgv4
*                               INTO gv_message.

      DATA(lv_subrc) = sy-subrc.
      DATA(lv_path) = get_file_name( gs_screen_input-app_file_path ).

      CASE lv_subrc.
        WHEN 1.
          gv_message = |{ TEXT-f01 }:{ lv_path }|.
        WHEN 2.
          gv_message = |{ TEXT-f02 }:{ lv_path }|.
        WHEN 3.
          gv_message = |{ TEXT-f03 }:{ lv_path }|.
      ENDCASE.
*-<End Of Change CD2000007614
    ENDIF.
  ENDMETHOD.
  METHOD validate_no_of_app_fields.
    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order =  DATA(lt_fields_in_order) ).

    DATA(lv_db_count) = lines( lt_fields_in_order ).

    DATA(ls_app_file_data) = VALUE rsanm_file_line( gt_raw_app_file_data[ 1 ] OPTIONAL ).
    IF ls_app_file_data IS NOT INITIAL.
      SPLIT ls_app_file_data AT ',' INTO TABLE gt_app_file_data.
      DATA(lv_app_data_count) = lines( gt_app_file_data ).
    ENDIF.

    IF lv_db_count <> lv_app_data_count.
*      All fields in ZZXREFDETAIL are not maintained in application file
      MESSAGE e047(zdl_c10156) INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_app_file_path.
    SEARCH gs_screen_input-app_file_path FOR '.XLX'.
    IF sy-subrc <> 0.
      SEARCH gs_screen_input-app_file_path FOR '.XLSX'.
      IF sy-subrc = 0.
*        Invalid file &1 for application server. Use CSV or Text file
        MESSAGE e046(zdl_c10156) WITH gs_screen_input-app_file_path
                                 INTO gv_message.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD create_goods_receipt.
    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE,
                   <lt_tansactional_data> TYPE STANDARD TABLE.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .
    ASSIGN gt_translation_data_ref->* TO <lt_tansactional_data> .
    CLEAR gv_message.
    LOOP AT <lt_upload_data> ASSIGNING FIELD-SYMBOL(<ls_upload_data>).
      CLEAR gv_message.
* Create Goods Receipt only for the error free record,
      ASSIGN COMPONENT 'MESSAGE'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_message>).
      IF <lv_message> IS NOT INITIAL.
        CONTINUE.
      ENDIF.

      ASSIGN COMPONENT 'SUCCESS'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_success>).

      ASSIGN COMPONENT 'MBLNR'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_mblnr>).

      ASSIGN COMPONENT 'MJAHR'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_mjahr>).

* Get the required field value to read the MSEG table.
      fill_required_global_field(
        CHANGING
          cs_alv_output_data = <ls_upload_data> ).

* Check Inventory Posting logic
      IF gs_screen_input-check_inventory = abap_true.
        check_inventory_posting( ).
      ENDIF.

      IF gv_message IS NOT INITIAL.
        <lv_message> = gv_message.
        CLEAR gv_message.
        CONTINUE.
      ENDIF.

* Get the profit center.
      gv_profit_center = VALUE #( gt_profit_center[ matnr = gv_matnr
                                                    werks = gv_werks ]-prctr OPTIONAL ).

* Decide storage
      DATA(lv_slocation) = VALUE #( gt_slocation[ werks = gv_werks
                                                  lgort = gv_lgort ]-parlg OPTIONAL ).
      IF lv_slocation IS NOT INITIAL.
        gv_lgort = lv_slocation.
      ENDIF.

* Fill header
      DATA(ls_gm_header) = VALUE bapi2017_gm_head_01( pstng_date = gs_screen_input-posting_date
                                                      doc_date   = sy-datum
                                                      pr_uname   = sy-uname ).

* Fill Goods movement code
      DATA(ls_gm_code) = VALUE bapi2017_gm_code( gm_code = '05' ).

* Fill goods movement Item.
      fill_gr_item_table(
        EXPORTING
          iv_move_type = '561'
        IMPORTING
          et_gm_item = DATA(lt_gm_item) ).

      IF gs_screen_input-test_mode IS INITIAL.
        post_goods_receipt(
          EXPORTING
            is_gm_header        = ls_gm_header
            is_gm_code          = ls_gm_code
            it_goodsmvt_item    = lt_gm_item
          IMPORTING
            ev_materialdocument = DATA(lv_materialdocument)
            ev_matdocumentyear  = DATA(lv_matdocumentyear)
            et_return           = DATA(lt_return) ).

        LOOP AT lt_return INTO DATA(ls_return) WHERE type = 'E' OR
                                                     type = 'A'.
          MESSAGE e000(zdl_c10156) WITH ls_return-message_v1
                                        ls_return-message_v2
                                        ls_return-message_v3
                                        ls_return-message_v4
                                   INTO gv_message.
          EXIT.
        ENDLOOP.
        IF lv_materialdocument IS NOT INITIAL AND
           lv_matdocumentyear  IS NOT INITIAL.
          <lv_mblnr> = lv_materialdocument.
          <lv_mjahr> = lv_matdocumentyear.
*          GR Created successfully.
          MESSAGE s072(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.
          CLEAR gv_message.
        ELSE.
*          Error occured in posting GR
          MESSAGE e057(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR gv_message.
        ENDIF.
      ELSE.
*        No issues found in creating GR.
        MESSAGE e069(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        <lv_success> = abap_true.
        CLEAR gv_message.
      ENDIF.

      CLEAR:lv_slocation,
            ls_gm_header,
            ls_gm_code,
            lt_gm_item,
            gv_werks,
            gv_lgort,
            gv_matnr,
            gv_charg,
            gv_kunnr,
            gv_menge,
            gv_meins,
            gv_profit_center,
            gv_vbeln,
            gv_posnr,
            gv_subrc,
            gv_sobkz,
            gv_message.
    ENDLOOP.
  ENDMETHOD.
  METHOD check_inventory_posting.
* Decide storage
    DATA(lv_slocation) = VALUE #( gt_slocation[ werks = gv_werks
                                                lgort = gv_lgort ]-parlg OPTIONAL ).
    IF lv_slocation IS INITIAL.
      DATA(lv_lgort) = gv_lgort.
    ELSE.
      lv_lgort = lv_slocation.
    ENDIF.

* Do not consider Storage location for SOBKZ = W
    IF gv_sobkz = 'W'.
      CLEAR lv_lgort.
    ENDIF.

* select the record from the MSEG table for the validation.
    SELECT mblnr,
           mjahr,
           bwart,
           sobkz,
           sjahr,
           smbln,
           smblp,
           budat_mkpf,
           cpudt_mkpf,
           cputm_mkpf,
           usnam_mkpf,
           xblnr_mkpf,
           tcode2_mkpf
      FROM mseg
      INTO TABLE @DATA(lt_mseg)
      WHERE bwart IN ('561', '562') AND
            matnr = @gv_matnr AND
            werks = @gv_werks AND
            lgort = @lv_lgort AND
            charg = @gv_charg AND
            sobkz = @gv_sobkz.
    IF sy-subrc <> 0.
      CLEAR lt_mseg.
    ENDIF.

* Sort the table lt_mseg in decending order.
    SORT lt_mseg BY cpudt_mkpf DESCENDING
                    cputm_mkpf DESCENDING.

* Pick the first record.
    DATA(ls_check_inventory) = VALUE #( lt_mseg[ 1 ] OPTIONAL ).
    gv_budat_mkpf = ls_check_inventory-budat_mkpf.
    gv_mblnr = ls_check_inventory-mblnr.
    gv_mjahr = ls_check_inventory-mjahr.

    CASE abap_true.
      WHEN gs_screen_input-goods.
        IF ls_check_inventory-bwart = '561'.
*          GR Posted on material document &1 by &2 on &3
          MESSAGE e051(zdl_c10156)
          WITH |{ ls_check_inventory-mblnr }/{ ls_check_inventory-mjahr }|
               ls_check_inventory-usnam_mkpf
               |{ ls_check_inventory-cpudt_mkpf }/{ ls_check_inventory-cputm_mkpf }|
               INTO gv_message.
        ENDIF.
      WHEN gs_screen_input-goods_rev.
        IF ls_check_inventory-bwart = '562'.
*          GR Reversal Posted on material document &1 by &2 on &3
          MESSAGE e052(zdl_c10156)
          WITH |{ ls_check_inventory-mblnr }/{ ls_check_inventory-mjahr }|
               ls_check_inventory-usnam_mkpf
               |{ ls_check_inventory-cpudt_mkpf }/{ ls_check_inventory-cputm_mkpf }|
               INTO gv_message.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD fill_gr_item_table.
    CLEAR et_gm_item.
    CASE gv_sobkz.
      WHEN space.
        et_gm_item =  VALUE #( ( material   = gv_matnr
                                 plant      = gv_werks
                                 stge_loc   = gv_lgort
                                 batch      = gv_charg
                                 move_type  = iv_move_type
                                 spec_stock = space
                                 entry_qnt  = gv_menge
                                 entry_uom  = gv_meins
                                 profit_ctr = gv_profit_center ) ).
      WHEN 'E'.
        et_gm_item =  VALUE #( ( material   = gv_matnr
                                 plant      = gv_werks
                                 stge_loc   = gv_lgort
                                 batch      = gv_charg
                                 move_type  = iv_move_type
                                 spec_stock = gv_sobkz
                                 sales_ord  = gv_vbeln
                                 s_ord_item = gv_posnr
                                 entry_qnt  = gv_menge
                                 entry_uom  = gv_meins
                                 profit_ctr = gv_profit_center
                                 val_sales_ord = gv_vbeln
                                 val_s_ord_item = gv_posnr ) ).
      WHEN 'W'.
        et_gm_item =  VALUE #( ( material   = gv_matnr
                                 plant      = gv_werks
*                                 stge_loc   = gv_lgort
                                 batch      = gv_charg
                                 move_type  = iv_move_type
                                 spec_stock = gv_sobkz
                                 entry_qnt  = gv_menge
                                 entry_uom  = gv_meins
                                 profit_ctr = gv_profit_center
                                 customer   = gv_kunnr ) ).
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD goods_receipt_reversal.
    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE,
                   <lt_tansactional_data> TYPE STANDARD TABLE.

    DATA: lt_goodsmovement_items TYPE goodsmovement_items_t.

* For ATC issue, did not use inline declaration.
    DATA: ls_goodsmvt_headret TYPE  bapi2017_gm_head_ret.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .
    ASSIGN gt_translation_data_ref->* TO <lt_tansactional_data> .
    CLEAR gv_message.
    LOOP AT <lt_upload_data> ASSIGNING FIELD-SYMBOL(<ls_upload_data>).
      CLEAR gv_message.
* Create Goods Receipt only for the error free record,
      ASSIGN COMPONENT 'MESSAGE'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_message>).
      IF <lv_message> IS NOT INITIAL.
        CONTINUE.
      ENDIF.

      ASSIGN COMPONENT 'SUCCESS'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_success>).

* Get the required field value to read the MSEG table.
      fill_required_global_field(
        CHANGING
          cs_alv_output_data = <ls_upload_data> ).

      ASSIGN COMPONENT 'MBLNR'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_mblnr>).

      ASSIGN COMPONENT 'MJAHR'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_mjahr>).

* Check Inventory Posting logic
      IF gs_screen_input-gr_rev_check  = abap_true.
        check_inventory_posting( ).
      ENDIF.

      IF gv_message IS NOT INITIAL.
        <lv_message> = gv_message.
        CLEAR gv_message.
        CONTINUE.
      ENDIF.

      IF gs_screen_input-gr_562 = abap_true AND
         gs_screen_input-test_mode = abap_false.
* Get the profit center.
        gv_profit_center = VALUE #( gt_profit_center[ matnr = gv_matnr
                                                      werks = gv_werks ]-prctr OPTIONAL ).

* Decide storage
        DATA(lv_slocation) = VALUE #( gt_slocation[ werks = gv_werks
                                                    lgort = gv_lgort ]-parlg OPTIONAL ).
        IF lv_slocation IS NOT INITIAL.
          gv_lgort = lv_slocation.
        ENDIF.

* Fill header
        DATA(ls_gm_header) = VALUE bapi2017_gm_head_01( pstng_date = gs_screen_input-posting_date
                                                        doc_date   = sy-datum
                                                        pr_uname   = sy-uname ).

* Fill Goods movement code
        DATA(ls_gm_code) = VALUE bapi2017_gm_code( gm_code = '05' ).

* Fill goods movement Item.
        fill_gr_item_table(
          EXPORTING
            iv_move_type = '562'
          IMPORTING
            et_gm_item = DATA(lt_gm_item) ).

        post_goods_receipt(
          EXPORTING
            is_gm_header        = ls_gm_header
            is_gm_code          = ls_gm_code
            it_goodsmvt_item    = lt_gm_item
          IMPORTING
            ev_materialdocument = DATA(lv_materialdocument)
            ev_matdocumentyear  = DATA(lv_matdocumentyear)
            et_return           = DATA(lt_return) ).

        IF lv_materialdocument IS NOT INITIAL AND
           lv_matdocumentyear IS NOT INITIAL.
          <lv_mblnr> = lv_materialdocument.
          <lv_mjahr> = lv_matdocumentyear.
*        GR Reversal successfully completed
          MESSAGE s072(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.
          CLEAR gv_message.
        ENDIF.
      ENDIF.

*      IF gs_screen_input-gr_562 = abap_false AND
      IF gs_screen_input-gr_bapi = abap_true AND
         gs_screen_input-test_mode = abap_false.
        lv_materialdocument = gv_mblnr.
        lv_matdocumentyear  = gv_mjahr.

        CALL FUNCTION 'BAPI_GOODSMVT_CANCEL'
          EXPORTING
            materialdocument    = lv_materialdocument
            matdocumentyear     = lv_matdocumentyear
            goodsmvt_pstng_date = gv_budat_mkpf
            goodsmvt_pr_uname   = sy-uname
          IMPORTING
            goodsmvt_headret    = ls_goodsmvt_headret
          TABLES
            return              = lt_return
            goodsmvt_matdocitem = lt_goodsmovement_items.
      ENDIF.

      IF gs_screen_input-test_mode = abap_true.
*        No issues found in GR Reversal
        MESSAGE e069(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        <lv_success> = abap_true.
        CLEAR gv_message.
        CONTINUE.
      ENDIF.

      LOOP AT lt_return INTO DATA(ls_return) WHERE type = 'E' OR
                                                   type = 'A'.
        MESSAGE e000(zdl_c10156) WITH ls_return-message_v1
                                      ls_return-message_v2
                                      ls_return-message_v3
                                      ls_return-message_v4
                                 INTO gv_message.
        <lv_message> =  gv_message.
        EXIT.
      ENDLOOP.
      IF gv_message IS NOT INITIAL.
        CONTINUE.
      ENDIF.
      IF ls_goodsmvt_headret IS NOT INITIAL.
        <lv_mblnr> = ls_goodsmvt_headret-mat_doc.
        <lv_mjahr> = ls_goodsmvt_headret-doc_year.
*        GR Reversal successfully completed
        MESSAGE s072(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        <lv_success> = abap_true.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.
        CLEAR gv_message.
      ENDIF.

      CLEAR:lv_slocation,
            ls_gm_header,
            ls_gm_code,
            lt_gm_item,
            gv_werks,
            gv_lgort,
            gv_matnr,
            gv_charg,
            gv_kunnr,
            gv_menge,
            gv_meins,
            gv_profit_center,
            gv_vbeln,
            gv_posnr,
            gv_subrc,
            gv_sobkz,
            gv_message.
    ENDLOOP.
  ENDMETHOD.
  METHOD create_hu_pack.
    DATA: lt_item_hu TYPE zdl_hu_itm,
          ls_header  TYPE bapihuheader,
          lt_return  TYPE bapiret2_t,
          ls_message TYPE  huitem_messages.
    DATA: ls_emkpf          TYPE emkpf,
          lt_imseg          TYPE ty_t_imseg,
          lv_message        TYPE string,
          lv_package_number TYPE string.

    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE,
                   <lt_tansactional_data> TYPE STANDARD TABLE,
                   <lt_hu_data>           TYPE STANDARD TABLE.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .
    ASSIGN gt_translation_data_ref->* TO <lt_tansactional_data> .
    ASSIGN gt_alv_hu_ref->* TO <lt_hu_data> .

* Sort dynamic internal table.
    sort_upload_table(
      EXPORTING
        iv_field_name  = 'PACKAGE_NUMBER'
        iv_descending  = abap_false
      CHANGING
        ct_upload_data = <lt_upload_data> ).

    CLEAR : gv_message.
    <lt_hu_data> = CORRESPONDING #( <lt_upload_data> ).
* loop throug the upload data.
    LOOP AT <lt_hu_data> ASSIGNING FIELD-SYMBOL(<ls_hu_data>).
*      READ TABLE <lt_upload_data> ASSIGNING FIELD-SYMBOL(<ls_upload_data>) INDEX sy-tabix.
      ASSIGN <lt_upload_data>[ sy-tabix ] TO FIELD-SYMBOL(<ls_upload_data>).
      IF <ls_upload_data> IS NOT ASSIGNED.
        CONTINUE.
      ENDIF.

* Get the message field, if it is not empty, then do not process any of the below logic.
      ASSIGN COMPONENT 'MESSAGE'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_message>).

      ASSIGN COMPONENT 'SUCCESS'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_success>).

      ASSIGN COMPONENT 'PACKAGE_NUMBER'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_package_number>).
      IF <lv_package_number> IS NOT ASSIGNED OR
         <lv_package_number> IS INITIAL.
*        PACKAGE_NUMBER is missing
        MESSAGE e059(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        CONTINUE.
      ENDIF.

* Check BUNDLE Roll. In BUNDLE Role, if one record is having issue, then the
* program should not allow to create HU and Move it to Stograge location.
      IF lv_package_number = <lv_package_number> AND
         lv_message IS NOT INITIAL.
        MESSAGE e076(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        CONTINUE.
      ENDIF.
      lv_message = <lv_message>.
      lv_package_number = <lv_package_number>.
      IF <lv_message> IS NOT INITIAL.
        CONTINUE.
      ENDIF.

* Get all the required global fields.
      fill_required_global_field(
        CHANGING
          cs_alv_output_data = <ls_upload_data> ).

      ASSIGN 'PACKAGE_NUMBER' TO FIELD-SYMBOL(<lv_pack_num>).

      get_packaging_material(
        IMPORTING
          ev_pack_matnr = DATA(lv_pack_matnr) ).

      fill_gr_item_table(
        EXPORTING
          iv_move_type = '311'
        IMPORTING
          et_gm_item   = DATA(lt_item) ).
      DATA(lv_lgort) = VALUE #( gt_slocation[ werks = gv_werks
                                              lgort = gv_lgort ]-parlg OPTIONAL ).
      IF lv_lgort IS INITIAL.
*        Plant &1 / Storage location &2 is not HU managed
        MESSAGE e064(zdl_c10156) WITH gv_werks
                                     gv_lgort
                                 INTO gv_message.
        CONTINUE.
      ENDIF.
      DATA(ls_item) = VALUE #( lt_item[ 1 ] OPTIONAL ).
      DATA(lv_sp_stck_no) = COND string(
                               WHEN gv_sobkz = 'E'
                                 THEN |{ gv_vbeln }{ gv_posnr }|
                               WHEN gv_sobkz = 'W'
                                 THEN gv_kunnr ).
      lv_lgort  = COND string(
                    WHEN gv_sobkz = 'E'
                      THEN lv_lgort
                    WHEN gv_sobkz = 'W'
                      THEN space
                    WHEN gv_sobkz = space
                      THEN lv_lgort ).

      APPEND VALUE #( hu_item_type   = '1'
                      pack_qty       = ls_item-entry_qnt
                      base_unit_qty  = ls_item-entry_uom
                      material       = ls_item-material
                      batch          = ls_item-batch
                      plant          = ls_item-plant
                      stge_loc       = lv_lgort
                      spec_stock     = ls_item-spec_stock
                      sp_stck_no     = lv_sp_stck_no ) TO lt_item_hu.
      CLEAR ls_item.

      AT END OF (<lv_pack_num>).
* HU Header data.
        DATA(ls_head_prop) = VALUE bapihuhdrproposal( hu_status_init = space
                                                      pack_mat       = lv_pack_matnr
                                                      hu_exid        = <lv_package_number>
                                                      plant          = gv_werks ).
        CALL FUNCTION 'HU_PACKING_REFRESH'.
* Create HU.
        CALL FUNCTION 'BAPI_HU_CREATE'
          EXPORTING
            headerproposal = ls_head_prop
          IMPORTING
            huheader       = ls_header
          TABLES
            itemsproposal  = lt_item_hu
            return         = lt_return.

        IF gs_screen_input-test_mode = abap_false.
          DATA(ls_return) = VALUE #( lt_return[ type = 'E' ] OPTIONAL ).
          IF ls_return IS NOT INITIAL.
            MESSAGE e000(zdl_c10156) WITH ls_return-message
                                    INTO gv_message.
            <lv_message> = gv_message.
            CLEAR:ls_head_prop,
                  ls_header,
                  lt_item_hu,
                  lt_return,
                  lv_lgort,
                  ls_item,
                  lv_sp_stck_no.
            CONTINUE.
          ELSE.
            CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
              EXPORTING
                wait = abap_true.
          ENDIF.
        ELSE.
          CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
        ENDIF.

* Special stoc indicator W, no need to move HU. So do not call the following BAPI
        IF gv_sobkz = 'W'.
          IF gs_screen_input-test_mode = abap_true.
            <lv_success> = abap_true.
            MESSAGE s069(zdl_c10156) INTO gv_message.
            <lv_message> = gv_message.
            CLEAR:ls_head_prop,
                  ls_header,
                  lt_item_hu,
                  lt_return,
                  lv_lgort,
                  ls_item,
                  lv_sp_stck_no,
                  gv_message.
            CONTINUE.
          ENDIF.
          <lv_success> = abap_true.
          MESSAGE s072(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR:ls_head_prop,
                ls_header,
                lt_item_hu,
                lt_return,
                lv_lgort,
                ls_item,
                lv_sp_stck_no,
                gv_message.
          CONTINUE.
        ENDIF.

        DATA(lt_move_to) = VALUE hum_data_move_to_t( ( werks = gv_werks
                                                       lgort = gv_lgort ) ).
        DATA(lt_external_id) = VALUE hum_exidv_t( ( exidv = ls_header-hu_exid ) ).
        IF gs_screen_input-test_mode = abap_false.
          CALL FUNCTION 'HU_PACKING_REFRESH'.
          CALL FUNCTION 'SERIAL_INTTAB_REFRESH'.
          CALL FUNCTION 'HU_CREATE_GOODS_MOVEMENT'
            EXPORTING
              if_event       = '0001'
              it_move_to     = lt_move_to
              it_external_id = lt_external_id
            IMPORTING
              es_message     = ls_message
              es_emkpf       = ls_emkpf
            CHANGING
              ct_imseg       = lt_imseg.
          IF ls_emkpf IS NOT INITIAL AND
             ls_message IS INITIAL.
            CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.
            <lv_success> = abap_true.
            MESSAGE s072(zdl_c10156) INTO gv_message.
            <lv_message> = gv_message.
          ELSEIF ls_emkpf IS INITIAL AND
                 ls_message IS INITIAL.
            MESSAGE s073(zdl_c10156) INTO gv_message.
            <lv_message> = gv_message.
          ELSE.
            CALL FUNCTION 'MESSAGE_TEXT_BUILD'
              EXPORTING
                msgid               = ls_message-msgid
                msgnr               = ls_message-msgno
                msgv1               = ls_message-msgv1
                msgv2               = ls_message-msgv2
                msgv3               = ls_message-msgv3
                msgv4               = ls_message-msgv4
              IMPORTING
                message_text_output = gv_message.
            <lv_message> = gv_message.
          ENDIF.
        ELSE.
          MESSAGE e069(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
        ENDIF.
        CLEAR:ls_head_prop,
              ls_header,
              lt_item_hu,
              lt_return,
              lv_lgort,
              ls_item,
              lv_sp_stck_no,
              gv_message,
              lv_message,
              lv_package_number.
      ENDAT.
      IF lv_package_number = <lv_package_number> AND
         gs_screen_input-test_mode = abap_true.
        IF lv_message IS NOT INITIAL.
          MESSAGE e076(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR gv_message.
        ELSE.
          MESSAGE e069(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
        ENDIF.
      ELSE.
        IF lv_message IS NOT INITIAL.
          MESSAGE e076(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR gv_message.
        ELSE.
          MESSAGE e072(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD create_hu_pack_nomovement.
    DATA: lt_item_hu TYPE zdl_hu_itm,
          ls_header  TYPE bapihuheader,
          lt_return  TYPE bapiret2_t,
          ls_message TYPE  huitem_messages.
    DATA: lv_message        TYPE string,
          lv_package_number TYPE string.

    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE,
                   <lt_tansactional_data> TYPE STANDARD TABLE,
                   <lt_hu_data>           TYPE STANDARD TABLE.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .
    ASSIGN gt_translation_data_ref->* TO <lt_tansactional_data> .
    ASSIGN gt_alv_hu_ref->* TO <lt_hu_data> .

* Sort dynamic internal table.
    sort_upload_table(
      EXPORTING
        iv_field_name  = 'PACKAGE_NUMBER'
        iv_descending  = abap_false
      CHANGING
        ct_upload_data = <lt_upload_data> ).

    CLEAR : gv_message.
    <lt_hu_data> = CORRESPONDING #( <lt_upload_data> ).
* loop throug the upload data.
    LOOP AT <lt_hu_data> ASSIGNING FIELD-SYMBOL(<ls_hu_data>).
      ASSIGN <lt_upload_data>[ sy-tabix ] TO FIELD-SYMBOL(<ls_upload_data>).
      IF <ls_upload_data> IS NOT ASSIGNED.
        CONTINUE.
      ENDIF.

* Get the message field, if it is not empty, then do not process any of the below logic.
      ASSIGN COMPONENT 'MESSAGE'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_message>).

      ASSIGN COMPONENT 'SUCCESS'
             OF STRUCTURE <ls_upload_data>
             TO FIELD-SYMBOL(<lv_success>).

      ASSIGN COMPONENT 'PACKAGE_NUMBER'
            OF STRUCTURE <ls_upload_data>
            TO FIELD-SYMBOL(<lv_package_number>).
      IF <lv_package_number> IS NOT ASSIGNED OR
         <lv_package_number> IS INITIAL.
*        PACKAGE_NUMBER is missing
        MESSAGE e059(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        CONTINUE.
      ENDIF.

* Check BUNDLE Roll. In BUNDLE Role, if one record is having issue, then the
* program should not allow to create HU and Move it to Stograge location.
      IF lv_package_number = <lv_package_number> AND
         lv_message IS NOT INITIAL.
        MESSAGE e076(zdl_c10156) INTO gv_message.
        <lv_message> = gv_message.
        CONTINUE.
      ENDIF.
      lv_message = <lv_message>.
      lv_package_number = <lv_package_number>.
      IF <lv_message> IS NOT INITIAL.
        CONTINUE.
      ENDIF.

* Get all the required global fields.
      fill_required_global_field(
        CHANGING
          cs_alv_output_data = <ls_upload_data> ).

      ASSIGN 'PACKAGE_NUMBER' TO FIELD-SYMBOL(<lv_pack_num>).

      get_packaging_material(
        IMPORTING
          ev_pack_matnr = DATA(lv_pack_matnr) ).

      fill_gr_item_table(
        EXPORTING
          iv_move_type = '311'
        IMPORTING
          et_gm_item   = DATA(lt_item) ).

      DATA(ls_item) = VALUE #( lt_item[ 1 ] OPTIONAL ).
      DATA(lv_sp_stck_no) = COND string(
                               WHEN gv_sobkz = 'E'
                                 THEN |{ gv_vbeln }{ gv_posnr }|
                               WHEN gv_sobkz = 'W'
                                 THEN gv_kunnr ).

      APPEND VALUE #( hu_item_type   = '1'
                      pack_qty       = ls_item-entry_qnt
                      base_unit_qty  = ls_item-entry_uom
                      material       = ls_item-material
                      batch          = ls_item-batch
                      plant          = ls_item-plant
                      spec_stock     = ls_item-spec_stock
                      sp_stck_no     = lv_sp_stck_no ) TO lt_item_hu.
      CLEAR ls_item.

      AT END OF (<lv_pack_num>).
* HU Header data.
        DATA(ls_head_prop) = VALUE bapihuhdrproposal( hu_status_init = space
                                                      pack_mat       = lv_pack_matnr
                                                      hu_exid        = <lv_package_number>
                                                      plant          = gv_werks ).
        CALL FUNCTION 'HU_PACKING_REFRESH'.
* Create HU.
        CALL FUNCTION 'BAPI_HU_CREATE'
          EXPORTING
            headerproposal = ls_head_prop
          IMPORTING
            huheader       = ls_header
          TABLES
            itemsproposal  = lt_item_hu
            return         = lt_return.

        IF gs_screen_input-test_mode = abap_false.
          DATA(ls_return) = VALUE #( lt_return[ type = 'E' ] OPTIONAL ).
          IF ls_return IS NOT INITIAL.
            MESSAGE e000(zdl_c10156) WITH ls_return-message
                                    INTO gv_message.
            <lv_message> = gv_message.
            CLEAR:ls_head_prop,
                  ls_header,
                  lt_item_hu,
                  lt_return,
                  ls_item,
                  lv_sp_stck_no.
            CONTINUE.
          ELSE.
            CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
              EXPORTING
                wait = abap_true.
          ENDIF.
        ELSE.
          CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
        ENDIF.

* Special stoc indicator W, no need to move HU. So do not call the following BAPI
        IF gv_sobkz = 'W'.
          IF gs_screen_input-test_mode = abap_true.
            <lv_success> = abap_true.
            MESSAGE s069(zdl_c10156) INTO gv_message.
            <lv_message> = gv_message.
            CLEAR:ls_head_prop,
                  ls_header,
                  lt_item_hu,
                  lt_return,
                  ls_item,
                  lv_sp_stck_no,
                  gv_message.
            CONTINUE.
          ENDIF.
          <lv_success> = abap_true.
          MESSAGE s072(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR:ls_head_prop,
                ls_header,
                lt_item_hu,
                lt_return,
                ls_item,
                lv_sp_stck_no,
                gv_message.
          CONTINUE.
        ENDIF.

        CLEAR:ls_head_prop,
              ls_header,
              lt_item_hu,
              lt_return,
              ls_item,
              lv_sp_stck_no,
              gv_message,
              lv_message,
              lv_package_number.
      ENDAT.
      IF lv_package_number = <lv_package_number> AND
         gs_screen_input-test_mode = abap_true.
        IF lv_message IS NOT INITIAL.
          MESSAGE e076(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR gv_message.
        ELSE.
          MESSAGE e069(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
        ENDIF.
      ELSE.
        IF lv_message IS NOT INITIAL.
          MESSAGE e076(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          CLEAR gv_message.
        ELSE.
          MESSAGE e072(zdl_c10156) INTO gv_message.
          <lv_message> = gv_message.
          <lv_success> = abap_true.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD post_goods_receipt.
    CLEAR: ev_matdocumentyear,
           ev_materialdocument,
           et_return.
    CALL FUNCTION 'BAPI_GOODSMVT_CREATE'
      EXPORTING
        goodsmvt_header  = is_gm_header
        goodsmvt_code    = is_gm_code
        testrun          = gs_screen_input-test_mode
      IMPORTING
        materialdocument = ev_materialdocument
        matdocumentyear  = ev_matdocumentyear
      TABLES
        goodsmvt_item    = it_goodsmvt_item
        return           = et_return.
  ENDMETHOD.
  METHOD fill_required_global_field.

    DATA: lv_numc TYPE string VALUE '0123456789'.
    CLEAR: gv_sobkz,
           gv_werks,
           gv_lgort,
           gv_matnr,
           gv_charg,
           gv_menge,
           gv_meins,
           gv_vbeln,
           gv_posnr,
           gv_kunnr.

    ASSIGN COMPONENT 'SOBKZ'
             OF STRUCTURE cs_alv_output_data
             TO FIELD-SYMBOL(<lv_sobkz>).
    gv_sobkz = <lv_sobkz>.

    ASSIGN COMPONENT 'WERKS'
             OF STRUCTURE cs_alv_output_data
             TO FIELD-SYMBOL(<lv_werks>).
    gv_werks = <lv_werks>.

    ASSIGN COMPONENT 'LGORT'
             OF STRUCTURE cs_alv_output_data
             TO FIELD-SYMBOL(<lv_lgort>).
    gv_lgort = <lv_lgort>.

    ASSIGN COMPONENT 'MATNR'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_matnr>).
    gv_matnr = <lv_matnr>.

    ASSIGN COMPONENT 'CHARG'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_charg>).
    gv_charg = <lv_charg>.

    ASSIGN COMPONENT 'MENGE'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_menge>).

* Check if the quantity field contains any non numc value
    IF NOT <lv_menge> CA lv_numc.
*      In valid value &1 in weight field
      MESSAGE e067(zdl_c10156) WITH <lv_menge>
                               INTO gv_message.
    ELSE.
      gv_menge = <lv_menge>.
    ENDIF.

    ASSIGN COMPONENT 'MEINS'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_meins>).
    gv_meins = <lv_meins>.

    ASSIGN COMPONENT 'VBELN'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_vbeln>).
    gv_vbeln = <lv_vbeln>.

    ASSIGN COMPONENT 'POSNR'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_posnr>).
    gv_posnr = <lv_posnr>.

    ASSIGN COMPONENT 'KUNNR'
          OF STRUCTURE cs_alv_output_data
          TO FIELD-SYMBOL(<lv_kunnr>).
    gv_kunnr = <lv_kunnr>.
  ENDMETHOD.
  METHOD sort_upload_table.
    DATA(ls_field_name) = VALUE #( gt_primary_table_1[ zzkey2 = CONV zzkey2( iv_field_name ) ] OPTIONAL ).
    IF ls_field_name IS INITIAL.
      RETURN.
    ENDIF.
    DATA(lt_sort) = VALUE abap_sortorder_tab( ( name = ls_field_name-zzkey2
                                                descending = iv_descending ) ).
    TRY .
        SORT ct_upload_data BY (lt_sort).
      CATCH cx_sy_dyn_table_ill_comp_val INTO DATA(lo_sort).
        DATA(lv_text) = lo_sort->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.
  ENDMETHOD.
  METHOD get_packaging_material.
    CLEAR ev_pack_matnr.
    SELECT SINGLE meins
            FROM mara
            INTO @DATA(lv_meins)
            WHERE matnr = @gv_matnr.
    IF sy-subrc <> 0.
      MESSAGE e060(zdl_c10156) WITH gv_matnr
                         INTO gv_message.
      RETURN.
    ENDIF.
*    SELECT matnr
*            FROM mara
*            INTO @ev_pack_matnr
*            UP TO 1 ROWS
*            WHERE mtart = 'VERP' AND
*                  vhart = 'PKG' AND
*                  gewei = @lv_meins.
*    ENDSELECT.
*    IF sy-subrc <> 0.
*      CLEAR ev_pack_matnr.
*    ENDIF.
    SELECT SINGLE lowval
      FROM zdl_fields
      INTO @DATA(lv_pack_matnr)
      WHERE category =  'ITP_LOAD' AND
            fieldname = 'PACK_MAT'.
    IF sy-subrc = 0.
      ev_pack_matnr = CONV matnr( lv_pack_matnr ).
    ENDIF.
  ENDMETHOD.
  METHOD save_file_app_server.
    CHECK gs_screen_input-test_mode = abap_false.
* Save transalation file in application layer
    save_transalation_file( ).

* Save all error data in application layer
    save_error_file( ).

* Save all upload data in application layer
    save_success_error_file( ).
  ENDMETHOD.
  METHOD save_transalation_file.
    DATA: ls_string         TYPE string,
          lt_app_trans_file TYPE table_of_strings.

    FIELD-SYMBOLS: <lt_tansactional_data> TYPE STANDARD TABLE.

    ASSIGN gt_translation_data_ref->* TO <lt_tansactional_data>.

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_fields_in_order) ).

    LOOP AT <lt_tansactional_data> ASSIGNING FIELD-SYMBOL(<ls_tansactional_data>).
      LOOP AT lt_fields_in_order INTO DATA(ls_fields_in_order).

        ASSIGN COMPONENT ls_fields_in_order-zzkey2
           OF STRUCTURE <ls_tansactional_data>
           TO FIELD-SYMBOL(<lv_value>).

        ls_string = COND #( WHEN sy-tabix = 1
                              THEN <lv_value>
                             ELSE ls_string && ',' && <lv_value> ).

        IF ls_fields_in_order-zzkey3 IS NOT INITIAL.
          DATA(lv_name) = |{ ls_fields_in_order-zzkey2 }{ '_NEW' }|.
          ASSIGN COMPONENT lv_name
             OF STRUCTURE <ls_tansactional_data>
             TO <lv_value>.
          ls_string = COND #( WHEN sy-tabix = 1
                                THEN <lv_value>
                               ELSE ls_string && ',' && <lv_value> ).
        ENDIF.

      ENDLOOP.
      APPEND ls_string TO lt_app_trans_file.
      CLEAR ls_string.
    ENDLOOP.

* Save file in application layer.
    cl_rsan_ut_appserv_file_writer=>appserver_file_write(
      EXPORTING
        i_filename      = gs_screen_input-trans_file
        i_data_tab      = lt_app_trans_file
      EXCEPTIONS
        open_failed     = 1
        write_failed    = 2
        close_failed    = 3
        OTHERS          = 4 ).

    IF sy-subrc <> 0.
      CASE sy-subrc.
        WHEN '1'.
          "Error Opening file - &1
          MESSAGE e061(zdl_c10156) WITH gs_screen_input-trans_file INTO gv_message.
        WHEN '2'.
          "Error Creating file - &1
          MESSAGE e062(zdl_c10156) WITH gs_screen_input-trans_file INTO gv_message.
        WHEN '3'.
          "Error Closing file - &1
          MESSAGE e063(zdl_c10156) WITH gs_screen_input-trans_file INTO gv_message.
        WHEN OTHERS.
          "Error Creating file - &1
          MESSAGE e061(zdl_c10156) WITH gs_screen_input-trans_file INTO gv_message.
      ENDCASE.
    ENDIF.
  ENDMETHOD.
  METHOD save_success_error_file.
    DATA: ls_string         TYPE string,
          lt_app_trans_file TYPE table_of_strings.
    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_fields_in_order) ).

    LOOP AT <lt_upload_data> ASSIGNING FIELD-SYMBOL(<ls_upload_data>).
      LOOP AT lt_fields_in_order INTO DATA(ls_fields_in_order).

        ASSIGN COMPONENT 'MESSAGE'
           OF STRUCTURE <ls_upload_data>
           TO FIELD-SYMBOL(<lv_message>).

        ASSIGN COMPONENT ls_fields_in_order-zzkey2
           OF STRUCTURE <ls_upload_data>
           TO FIELD-SYMBOL(<lv_value>).

        ls_string = COND #( WHEN sy-tabix = 1
                              THEN |{ <lv_message> },{ <lv_value> }|
                             ELSE ls_string && ',' && <lv_value> ).

      ENDLOOP.
      APPEND ls_string TO lt_app_trans_file.
      CLEAR ls_string.
    ENDLOOP.

* Save file in application layer.
    cl_rsan_ut_appserv_file_writer=>appserver_file_write(
      EXPORTING
        i_filename      = gs_screen_input-success_file
        i_data_tab      = lt_app_trans_file
      EXCEPTIONS
        open_failed     = 1
        write_failed    = 2
        close_failed    = 3
        OTHERS          = 4 ).

    IF sy-subrc <> 0.
      CASE sy-subrc.
        WHEN '1'.
          "Error Opening file - &1
          MESSAGE e061(zdl_c10156) WITH gs_screen_input-success_file INTO gv_message.
        WHEN '2'.
          "Error Creating file - &1
          MESSAGE e062(zdl_c10156) WITH gs_screen_input-success_file INTO gv_message.
        WHEN '3'.
          "Error Closing file - &1
          MESSAGE e063(zdl_c10156) WITH gs_screen_input-success_file INTO gv_message.
        WHEN OTHERS.
          "Error Creating file - &1
          MESSAGE e061(zdl_c10156) WITH gs_screen_input-success_file INTO gv_message.
      ENDCASE.
    ENDIF.
  ENDMETHOD.
  METHOD save_error_file.
    DATA: ls_string         TYPE string,
          lt_app_trans_file TYPE table_of_strings.
    FIELD-SYMBOLS: <lt_upload_data>       TYPE STANDARD TABLE.

    ASSIGN gt_alv_output_ref->* TO <lt_upload_data> .

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_fields_in_order) ).

    LOOP AT <lt_upload_data> ASSIGNING FIELD-SYMBOL(<ls_upload_data>).
      ASSIGN COMPONENT 'SUCCESS'
           OF STRUCTURE <ls_upload_data>
           TO FIELD-SYMBOL(<lv_success>).
      IF <lv_success> IS NOT INITIAL.
        CONTINUE.
      ENDIF.
      LOOP AT lt_fields_in_order INTO DATA(ls_fields_in_order).

        ASSIGN COMPONENT ls_fields_in_order-zzkey2
           OF STRUCTURE <ls_upload_data>
           TO FIELD-SYMBOL(<lv_value>).

        ls_string = COND #( WHEN sy-tabix = 1
                              THEN <lv_value>
                             ELSE |{ ls_string },{  <lv_value> }| ).
        AT LAST.
          IF <lv_value> IS INITIAL.
            ls_string = |{ ls_string },{ space }|.
          ENDIF.
        ENDAT.
      ENDLOOP.
      APPEND ls_string TO lt_app_trans_file.
      CLEAR ls_string.
    ENDLOOP.

    IF lt_app_trans_file IS NOT INITIAL.
* Save file in application layer.
      cl_rsan_ut_appserv_file_writer=>appserver_file_write(
        EXPORTING
          i_filename      = gs_screen_input-error_file
          i_data_tab      = lt_app_trans_file
        EXCEPTIONS
          open_failed     = 1
          write_failed    = 2
          close_failed    = 3
          OTHERS          = 4 ).

      IF sy-subrc <> 0.
        CASE sy-subrc.
          WHEN '1'.
            "Error Opening file - &1
            MESSAGE e061(zdl_c10156) WITH gs_screen_input-error_file INTO gv_message.
          WHEN '2'.
            "Error Creating file - &1
            MESSAGE e062(zdl_c10156) WITH gs_screen_input-error_file INTO gv_message.
          WHEN '3'.
            "Error Closing file - &1
            MESSAGE e063(zdl_c10156) WITH gs_screen_input-error_file INTO gv_message.
          WHEN OTHERS.
            "Error Creating file - &1
            MESSAGE e061(zdl_c10156) WITH gs_screen_input-error_file INTO gv_message.
        ENDCASE.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD check_hu_exists.
    ASSIGN COMPONENT 'PACKAGE_NUMBER'
         OF STRUCTURE cs_alv_output_data
         TO FIELD-SYMBOL(<lv_package_number>).
    IF <lv_package_number> IS ASSIGNED.
      SELECT *
        FROM vekp
        INTO @DATA(ls_vekp)
        UP TO 1 ROWS
        WHERE exidv = @<lv_package_number> AND
              status <> '0060'.
      ENDSELECT.
      IF sy-subrc = 0.
        MESSAGE e074(zdl_c10156) INTO gv_message.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD program_conversion.
    DATA: lv_value TYPE string VALUE
  'abcdefghijklmnopqrstuvwxyz<,>?/:;"{[}]|\+=_-)(*&^%$#@!'.
    CLEAR rv_new_value.

    DATA(ls_uom_value1) = VALUE #( gt_primary_table_2[ zzgroup    = 'DELIVER'
                                                       zzgroupset = 'GCF_UOM'
                                                       zzkey2     = CONV zzkey2( is_field_details-zzvalue2 ) ] OPTIONAL ).

    IF ls_uom_value1-zzvalue1 IS NOT INITIAL.
      DATA(lv_new_field) = |{ is_field_details-zzkey2 }{ '_NEW' }|.
      ASSIGN COMPONENT lv_new_field
                  OF STRUCTURE cs_translation_data
                  TO FIELD-SYMBOL(<ls_new_field>).

* Get the value from the input file so that it can be used for calculation.
      ASSIGN COMPONENT is_field_details-zzkey2
                  OF STRUCTURE cs_translation_data
                  TO FIELD-SYMBOL(<ls_upload_uom>).
      IF <ls_upload_uom> CA lv_value.
        RETURN.
      ENDIF.
      <ls_new_field> = |{ ( <ls_upload_uom> * ls_uom_value1-zzvalue1 ) / ls_uom_value1-zzkey1  }|.
      <ls_new_field> = |{ <ls_new_field> }|.
      IF is_field_details-zzvalue4 = 'R'.
        DATA: lv_decimal_number TYPE char5.
        DATA(lv_whole_number)  = trunc( <ls_new_field>  ).
        lv_decimal_number = frac( <ls_new_field>  ).
        CONDENSE lv_decimal_number.                         "CD2000007614
        IF lv_decimal_number+2(1) >= 5.
          rv_new_value = lv_whole_number + 1.
        ELSE.
          rv_new_value = lv_whole_number.
        ENDIF.
      ELSE.
        rv_new_value = |{ <ls_new_field> }|.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD system_conversion.
    DATA: lv_ctns_out      TYPE lqua_verme,
          lv_weight_out    TYPE erfmg,
          lv_weight        TYPE erfmg,
          lv_source_meins  TYPE mara-meins,
          lv_dest_meins    TYPE mara-meins,
          lv_conv_quantity TYPE ekpo-menge.
* Check if the material is PAL.
    ASSIGN COMPONENT 'MATNR_NEW'
                OF STRUCTURE cs_translation_data
                TO FIELD-SYMBOL(<ls_material>).
    IF <ls_material> IS NOT ASSIGNED.
      ASSIGN COMPONENT 'MATNR'
                  OF STRUCTURE cs_translation_data
                  TO <ls_material>.
    ENDIF.
    IF <ls_material> IS NOT ASSIGNED.
      RETURN.
    ENDIF.

* Get the value from the input file so that it can be used for calculation.
    ASSIGN COMPONENT is_field_details-zzkey2
                OF STRUCTURE cs_translation_data
                TO FIELD-SYMBOL(<ls_upload_uom>).
    lv_weight = <ls_upload_uom>.
    <ls_upload_uom> = |{ lv_weight }|.
    gv_matnr = |{ <ls_material> ALPHA = IN }|.
    SELECT SINGLE matnr
      FROM marm
      INTO @DATA(lv_matnr)
      WHERE matnr = @gv_matnr AND
            meinh = 'PAL'.
    IF sy-subrc = 0 AND
      ( is_field_details-zzvalue2 = 'CTN' AND
        is_field_details-zzvalue2 = 'LB') AND
      ( is_field_details-zzvalue3 = 'CTN' AND
        is_field_details-zzvalue3 = 'LB' ).
      CALL FUNCTION 'ZDL_WM_E04674_WGT_FROM_CTN'
        EXPORTING
          iv_matnr                 = gv_matnr
          iv_weight                = lv_weight
        IMPORTING
          ev_weight                = lv_weight_out
          ev_ctns                  = lv_ctns_out
        EXCEPTIONS
          ctn_per_pal_not_found    = 1
          wgt_not_return_from_puom = 2
          material_not_entered     = 3
          units_not_entered        = 4
          material_not_setup       = 5
          OTHERS                   = 6.
      IF sy-subrc = 0.
        IF is_field_details-zzvalue3 = 'CTN'.
          rv_new_value = lv_ctns_out.
        ELSE.
          rv_new_value = lv_weight_out.
        ENDIF.
      ENDIF.
    ELSE.
      lv_source_meins = is_field_details-zzvalue2.
      lv_dest_meins   = is_field_details-zzvalue3.
      CALL FUNCTION 'MD_CONVERT_MATERIAL_UNIT'
        EXPORTING
          i_matnr              = gv_matnr
          i_in_me              = lv_source_meins
          i_out_me             = lv_dest_meins
          i_menge              = lv_weight
        IMPORTING
          e_menge              = lv_conv_quantity
        EXCEPTIONS
          error_in_application = 1
          error                = 2
          OTHERS               = 3.
      IF sy-subrc = 0.
        lv_conv_quantity = |{ lv_conv_quantity }|.
        IF is_field_details-zzvalue4 = 'R'.
          DATA: lv_decimal_number TYPE char5.
          DATA(lv_whole_number)  = trunc( lv_conv_quantity  ).
          lv_decimal_number = frac( lv_conv_quantity  ).
          CONDENSE lv_decimal_number.                         "CD2000007614
          IF lv_decimal_number+2(1) >= 5.
            rv_new_value = lv_whole_number + 1.
          ELSE.
            rv_new_value = lv_whole_number.
          ENDIF.
        ELSE.
          rv_new_value = |{ lv_conv_quantity }|.
        ENDIF.
      ENDIF.
    ENDIF.
    CLEAR gv_matnr.
  ENDMETHOD.
  METHOD check_config_uom.
* Check if both UOM is maintained in the table.
    CHECK is_primary_table_1-zzvalue2 IS NOT INITIAL AND
          is_primary_table_1-zzvalue3 IS NOT INITIAL.

    CLEAR rv_config_uom.
* Check if the UOM maintained in  ZZVALUE2 is maintained in system.
    SELECT SINGLE msehi
             FROM t006a
             INTO @DATA(lv_msehi)
             WHERE spras = @sy-langu AND
                   msehi = @is_primary_table_1-zzvalue2.
    IF sy-subrc <> 0.
      rv_config_uom = abap_true.
      RETURN.
    ENDIF.

    SELECT SINGLE msehi
             FROM t006a
             INTO @lv_msehi
             WHERE spras = @sy-langu AND
                   msehi = @is_primary_table_1-zzvalue3.
    IF sy-subrc <> 0.
      rv_config_uom = abap_true.
    ENDIF.

    IF is_primary_table_1-zzvalue1 = abap_true.
      SELECT SINGLE meinh
               FROM marm
               INTO @DATA(lv_meinh)
               WHERE matnr = @gv_matnr AND
                     msehi = @is_primary_table_1-zzvalue2.
      IF sy-subrc <> 0.
        rv_config_uom = abap_true.
      ENDIF.

      SELECT SINGLE meinh
               FROM marm
               INTO @lv_meinh
               WHERE matnr = @gv_matnr AND
                     msehi = @is_primary_table_1-zzvalue3.
      IF sy-subrc <> 0.
        rv_config_uom = abap_true.
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD check_translation_exists.
    CHECK gs_primary_1-zzkey3 IS NOT INITIAL.
    ASSIGN COMPONENT gs_primary_1-zzkey2
           OF STRUCTURE cs_alv_output_data
           TO FIELD-SYMBOL(<ls_value>).
    IF gs_primary_1-zzvalue2 IS NOT INITIAL AND
       gs_primary_1-zzvalue3 IS NOT INITIAL.

      DATA(ls_primary_2) = VALUE #( gt_primary_table_2[ zzgroup = 'DELIVER'
                                                        zzgroupset = 'GCF_UOM'
                                                        zzkey2 = CONV zzkey2( gs_primary_1-zzvalue2 )
                                                        zzvalue2 = gs_primary_1-zzvalue3 ] OPTIONAL ).
      IF ls_primary_2 IS INITIAL.
*      Conversion factor not found in ZZXREFDETAIL
        MESSAGE e077(zdl_c10156) WITH gs_primary_1-zzkey2
                              INTO gv_message.
      ENDIF.
      CLEAR ls_primary_2.
    ELSE.
      ls_primary_2 = VALUE #( gt_primary_table_2[ zzgroup = 'DELIVER'
                                                  zzgroupset = 'GCF_XREF'
*                                                  zzkey1 = CONV zzkey2( gs_primary_1-zzvalue2 )
                                                  zzkey1 = gs_primary_1-zzkey2
                                                  zzvalue1 = <ls_value> ] OPTIONAL ).
      IF ls_primary_2 IS INITIAL.
*      Conversion factor not found in ZZXREFDETAIL
        MESSAGE e077(zdl_c10156) WITH gs_primary_1-zzkey2
                              INTO gv_message.
      ENDIF.
      CLEAR ls_primary_2.
    ENDIF.
  ENDMETHOD.
ENDCLASS.

CLASS lcl_inventory_conversion_batch DEFINITION FINAL INHERITING FROM lcl_inventory_conversion.
  PUBLIC SECTION.
    METHODS constructor.

    METHODS: upload_build_dyn_table_data REDEFINITION,
      validate_input_file_data REDEFINITION,
      translation_file_data REDEFINITION,
      create_revers_process REDEFINITION,
      write_files_in_app_server REDEFINITION.
ENDCLASS.

CLASS lcl_inventory_conversion_batch IMPLEMENTATION.
  METHOD: constructor.
    super->constructor( ).
  ENDMETHOD.
  METHOD upload_build_dyn_table_data.
    CASE abap_true.
      WHEN gs_screen_input-local_drive.
        IF sy-batch = abap_true.
          MESSAGE e065(zdl_c10156) INTO gv_message.
          RETURN.
        ENDIF.

        check_input_file_exists( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        upload_excel_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.

        validate_no_of_xcel_records( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN gs_screen_input-app_server.
        validate_app_file_path( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        read_application_file_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        validate_no_of_app_fields( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.

    build_primary_internal_table( ).
  ENDMETHOD.
  METHOD validate_input_file_data.
*    validate_field_data( ).
    FIELD-SYMBOLS: <lt_translation_file> TYPE STANDARD TABLE,
                   <lt_alv_output>       TYPE STANDARD TABLE,
                   <lt_upload_data>      TYPE STANDARD TABLE.
* Validate all the data and from the translation file and
* prepare output table as well

* Build translation table type from the reference.
    ASSIGN gt_translation_data_ref->* TO <lt_translation_file>.

* Build translation structure type from the reference.
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>).

* Build ALV Output table ref.
    ASSIGN gt_alv_output_ref->* TO <lt_alv_output>.

* Build ALV Output structure ref.
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output>).

* For duplicate record.
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output_dup>).

    ASSIGN gt_upload_data_ref->* TO <lt_upload_data>.

*    <lt_alv_output> = CORRESPONDING #( <lt_translation_file> ).
    <lt_alv_output> = CORRESPONDING #( <lt_upload_data> ).

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_primary_in_order) ).

    LOOP AT <lt_alv_output> ASSIGNING <ls_alv_output>.

* Clear global variable.
      CLEAR: gv_message.

* To capture any error message.
      ASSIGN COMPONENT 'MESSAGE'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_msg>).

      IF <ls_alv_output_dup> = <ls_alv_output>.
*        Duplicate Record
        MESSAGE e037(zdl_c10156) INTO gv_message.
        <lv_msg> = gv_message.
        CONTINUE.
      ENDIF.
      <ls_alv_output_dup> = <ls_alv_output>.

* Check for BUNDLE roll. For BUNDLE roll, SPECIAL STOCK INDICATER should not be different
      ASSIGN COMPONENT 'PACKAGE_NUMBER'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_package_number>).
      ASSIGN COMPONENT 'SOBKZ'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_sobkz>).
      IF sy-tabix <> 1 AND
        gv_pack_num = <lv_package_number>.
        IF gv_special_stk_ind <> <lv_sobkz>.
          MESSAGE e075(zdl_c10156) INTO gv_message.
          <lv_msg> = gv_message.
          CONTINUE.
        ENDIF.
      ENDIF.
      IF <lv_package_number> IS ASSIGNED.
        gv_pack_num = <lv_package_number>.
      ENDIF.
      IF <lv_sobkz> IS ASSIGNED.
        gv_special_stk_ind = <lv_sobkz>.
      ENDIF.

* Read Primary table to apply validation for required fields
      LOOP AT lt_primary_in_order INTO gs_primary_1 WHERE zzgroup = 'DELIVER' AND
                                                         zzgroupset = gs_screen_input-product_type.
* Check if the fields is ignorable. If it is ignorable,
*  then do not validate this field
        IF gs_primary_1-zzvalue4 = 'I'.
          CONTINUE.
        ENDIF.

* Validation for the fields.
* First get the field name and then get the value for the field
        CASE gs_primary_1-zzkey2.
          WHEN 'WERKS'.
* Plant Validation
            validate_werks(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

          WHEN 'LGORT'.
* Storage loctatioin validation.
            validate_lgort(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Material validation.
          WHEN 'MATNR'.
            validate_matnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Batch validation.
          WHEN 'CHARG'.
            validate_create_charg(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Quantity Validation.
          WHEN 'MENGE'.
            validate_menge(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* UOM validation
          WHEN 'MEINS'.
            validate_meins(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Special stock validation
          WHEN 'SOBKZ'.
            validate_sobkz(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Sales Order document validation.
          WHEN 'VBELN'.
            validate_vbeln_posnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Customer number validataion.
          WHEN 'KUNNR'.
            validate_kunnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

*->Begin Of Ins CD2000007614
          WHEN 'HSDAT'.
            validate_hsdat(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).
*-<End Of Ins CD2000007614

          WHEN OTHERS.
        ENDCASE.

        IF gs_primary_1-zzvalue1 = abap_true.
          validate_characteristics(
            CHANGING
              cs_alv_output_data = <ls_alv_output> ).
        ENDIF.

        check_hu_exists(
          CHANGING
            cs_alv_output_data = <ls_alv_output> ).

        check_translation_exists(
          CHANGING
            cs_alv_output_data = <ls_alv_output> ).


        IF gv_message IS NOT INITIAL.
          <lv_msg> = gv_message.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
    go_alv_output_ref = gt_alv_output_ref.
  ENDMETHOD.
  METHOD translation_file_data.
    build_translation_data( ).
  ENDMETHOD.
  METHOD create_revers_process.
    create_batch( ).
  ENDMETHOD.
  METHOD write_files_in_app_server.
    save_file_app_server( ).
  ENDMETHOD.
ENDCLASS.

CLASS lcl_inventory_conversion_goods DEFINITION FINAL INHERITING FROM lcl_inventory_conversion.
  PUBLIC SECTION.
    METHODS constructor.

    METHODS: upload_build_dyn_table_data REDEFINITION,
      validate_input_file_data REDEFINITION,
      translation_file_data REDEFINITION,
      create_revers_process REDEFINITION,
      write_files_in_app_server REDEFINITION.
ENDCLASS.

CLASS lcl_inventory_conversion_goods IMPLEMENTATION.
  METHOD: constructor.
    super->constructor( ).
  ENDMETHOD.
  METHOD upload_build_dyn_table_data.
    CASE abap_true.
      WHEN gs_screen_input-local_drive.
        IF sy-batch = abap_true.
          MESSAGE e065(zdl_c10156) INTO gv_message.
          RETURN.
        ENDIF.

        check_input_file_exists( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        upload_excel_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.

        validate_no_of_xcel_records( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN gs_screen_input-app_server.
        validate_app_file_path( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        read_application_file_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        validate_no_of_app_fields( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.

    build_primary_internal_table( ).
  ENDMETHOD.
  METHOD validate_input_file_data.
*    validate_field_data( ).
    FIELD-SYMBOLS: <lt_translation_file> TYPE STANDARD TABLE,
                   <lt_alv_output>       TYPE STANDARD TABLE,
                   <lt_upload_data>      TYPE STANDARD TABLE.
* Validate all the data and from the translation file and
* prepare output table as well

* Build translation table type from the reference.
    ASSIGN gt_translation_data_ref->* TO <lt_translation_file>.

* Build translation structure type from the reference.
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>).

* Build ALV Output table ref.
    ASSIGN gt_alv_output_ref->* TO <lt_alv_output>.

* Build ALV Output structure ref.
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output>).
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output_dup>).

    ASSIGN gt_upload_data_ref->* TO <lt_upload_data>.

*    <lt_alv_output> = CORRESPONDING #( <lt_translation_file> ).
    <lt_alv_output> = CORRESPONDING #( <lt_upload_data> ).

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_primary_in_order) ).

    LOOP AT <lt_alv_output> ASSIGNING <ls_alv_output>.

* Clear global variable.
      CLEAR: gv_message.

* To capture any error message.
      ASSIGN COMPONENT 'MESSAGE'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_msg>).

      IF <ls_alv_output_dup> = <ls_alv_output>.
        MESSAGE e037(zdl_c10156) INTO gv_message.
        <lv_msg> = gv_message.
        CONTINUE.
      ENDIF.
      <ls_alv_output_dup> = <ls_alv_output>.

*  Check for BUNDLE roll. For BUNDLE roll, SPECIAL STOCK INDICATER should not be different
      ASSIGN COMPONENT 'PACKAGE_NUMBER'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_package_number>).
      ASSIGN COMPONENT 'SOBKZ'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_sobkz>).
      IF sy-tabix <> 1 AND
        gv_pack_num = <lv_package_number>.
        IF gv_special_stk_ind <> <lv_sobkz>.
          MESSAGE e075(zdl_c10156) INTO gv_message.
          <lv_msg> = gv_message.
          CONTINUE.
        ENDIF.
      ENDIF.
      gv_pack_num = <lv_package_number>.
      gv_special_stk_ind = <lv_sobkz>.

* Read Primary table to apply validation for required fields
      LOOP AT lt_primary_in_order INTO gs_primary_1 WHERE zzgroup = 'DELIVER' AND
                                                         zzgroupset = gs_screen_input-product_type.
* Check if the fields is ignorable. If it is ignorable,
*  then do not validate this field
        IF gs_primary_1-zzvalue4 = 'I'.
          CONTINUE.
        ENDIF.
* Validation for the fields.
* First get the field name and then get the value for the field
        CASE gs_primary_1-zzkey2.
          WHEN 'WERKS'.
* Plant Validation
            validate_werks(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

          WHEN 'LGORT'.
* Storage loctatioin validation.
            validate_lgort(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Material validation.
          WHEN 'MATNR'.
            validate_goods_matnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Batch validation.
          WHEN 'CHARG'.
            validate_charg_for_gr_hu(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Quantity Validation.
          WHEN 'MENGE'.
            validate_menge(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* UOM validation
          WHEN 'MEINS'.
            validate_meins(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Special stock validation
          WHEN 'SOBKZ'.
            validate_sobkz(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Sales Order document validation.
          WHEN 'VBELN'.
            validate_vbeln_posnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Customer number validataion.
          WHEN 'KUNNR'.
            validate_kunnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).
          WHEN OTHERS.
        ENDCASE.

        check_hu_exists(
          CHANGING
            cs_alv_output_data = <ls_alv_output> ).

        IF gv_message IS NOT INITIAL.
          <lv_msg> = gv_message.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
    go_alv_output_ref = gt_alv_output_ref.
  ENDMETHOD.
  METHOD translation_file_data.
    build_translation_data( ).
  ENDMETHOD.
  METHOD create_revers_process.
    create_goods_receipt( ).
  ENDMETHOD.
  METHOD write_files_in_app_server.
    save_file_app_server( ).
  ENDMETHOD.
ENDCLASS.

CLASS lcl_inventory_conversion_gr DEFINITION FINAL INHERITING FROM lcl_inventory_conversion.
  PUBLIC SECTION.
    METHODS constructor.

    METHODS: upload_build_dyn_table_data REDEFINITION,
      validate_input_file_data REDEFINITION,
      translation_file_data REDEFINITION,
      create_revers_process REDEFINITION,
      write_files_in_app_server REDEFINITION.
ENDCLASS.

CLASS lcl_inventory_conversion_gr IMPLEMENTATION.
  METHOD: constructor.
    super->constructor( ).
  ENDMETHOD.
  METHOD upload_build_dyn_table_data.
    CASE abap_true.
      WHEN gs_screen_input-local_drive.
        IF sy-batch = abap_true.
          MESSAGE e065(zdl_c10156) INTO gv_message.
          RETURN.
        ENDIF.

        check_input_file_exists( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        upload_excel_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.

        validate_no_of_xcel_records( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN gs_screen_input-app_server.
        validate_app_file_path( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        read_application_file_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        validate_no_of_app_fields( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.

    build_primary_internal_table( ).
  ENDMETHOD.
  METHOD validate_input_file_data.
*    validate_field_data( ).
    FIELD-SYMBOLS: <lt_translation_file> TYPE STANDARD TABLE,
                   <lt_alv_output>       TYPE STANDARD TABLE,
                   <lt_upload_data>      TYPE STANDARD TABLE.

* Validate all the data and from the translation file and
* prepare output table as well

* Build translation table type from the reference.
    ASSIGN gt_translation_data_ref->* TO <lt_translation_file>.

* Build translation structure type from the reference.
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>).

* Build ALV Output table ref.
    ASSIGN gt_alv_output_ref->* TO <lt_alv_output>.

* Build ALV Output structure ref.
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output>).
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output_dup>).

    ASSIGN gt_upload_data_ref->* TO <lt_upload_data>.

*    <lt_alv_output> = CORRESPONDING #( <lt_translation_file> ).
    <lt_alv_output> = CORRESPONDING #( <lt_upload_data> ).

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_primary_in_order) ).

    LOOP AT <lt_alv_output> ASSIGNING <ls_alv_output>.

* Clear global variable.
      CLEAR: gv_message.

* To capture any error message.
      ASSIGN COMPONENT 'MESSAGE'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_msg>).

      IF <ls_alv_output_dup> = <ls_alv_output>.
        MESSAGE e037(zdl_c10156) INTO gv_message.
        <lv_msg> = gv_message.
        CONTINUE.
      ENDIF.
      <ls_alv_output_dup> = <ls_alv_output>.

*  Check for BUNDLE roll. For BUNDLE roll, SPECIAL STOCK INDICATER should not be different
      ASSIGN COMPONENT 'PACKAGE_NUMBER'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_package_number>).
      ASSIGN COMPONENT 'SOBKZ'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_sobkz>).
      IF sy-tabix <> 1 AND
        gv_pack_num = <lv_package_number>.
        IF gv_special_stk_ind <> <lv_sobkz>.
          MESSAGE e075(zdl_c10156) INTO gv_message.
          <lv_msg> = gv_message.
          CONTINUE.
        ENDIF.
      ENDIF.
      gv_pack_num = <lv_package_number>.
      gv_special_stk_ind = <lv_sobkz>.

* Read Primary table to apply validation for required fields
      LOOP AT lt_primary_in_order INTO gs_primary_1 WHERE zzgroup = 'DELIVER' AND
                                                         zzgroupset = gs_screen_input-product_type.
* Check if the fields is ignorable. If it is ignorable,
*  then do not validate this field
        IF gs_primary_1-zzvalue4 = 'I'.
          CONTINUE.
        ENDIF.
* Validation for the fields.
* First get the field name and then get the value for the field
        CASE gs_primary_1-zzkey2.
          WHEN 'WERKS'.
* Plant Validation
            validate_werks(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

          WHEN 'LGORT'.
* Storage loctatioin validation.
            validate_lgort(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Material validation.
          WHEN 'MATNR'.
            validate_goods_matnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Batch validation.
          WHEN 'CHARG'.
            validate_charg_for_gr_hu(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Quantity validation.
          WHEN 'MENGE'.
            validate_menge(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* UOM validation
          WHEN 'MEINS'.
            validate_meins(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Special stock validation
          WHEN 'SOBKZ'.
            validate_sobkz(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Sales Order document validation.
          WHEN 'VBELN'.
            validate_vbeln_posnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Customer number validataion.
          WHEN 'KUNNR'.
            validate_kunnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).
          WHEN OTHERS.
        ENDCASE.

        check_hu_exists(
          CHANGING
            cs_alv_output_data = <ls_alv_output> ).

        IF gv_message IS NOT INITIAL.
          <lv_msg> = gv_message.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
    go_alv_output_ref = gt_alv_output_ref.
  ENDMETHOD.
  METHOD translation_file_data.
    build_translation_data( ).
  ENDMETHOD.
  METHOD create_revers_process.
    goods_receipt_reversal( ).
  ENDMETHOD.
  METHOD write_files_in_app_server.
    save_file_app_server( ).
  ENDMETHOD.
ENDCLASS.

CLASS lcl_inventory_conversion_hu DEFINITION FINAL INHERITING FROM lcl_inventory_conversion.
  PUBLIC SECTION.
    METHODS constructor.

    METHODS: upload_build_dyn_table_data REDEFINITION,
      validate_input_file_data REDEFINITION,
      translation_file_data REDEFINITION,
      create_revers_process REDEFINITION,
      write_files_in_app_server REDEFINITION.
ENDCLASS.

CLASS lcl_inventory_conversion_hu IMPLEMENTATION.
  METHOD: constructor.
    super->constructor( ).
  ENDMETHOD.
  METHOD upload_build_dyn_table_data.
    CASE abap_true.
      WHEN gs_screen_input-local_drive.
        IF sy-batch = abap_true.
          MESSAGE e065(zdl_c10156) INTO gv_message.
          RETURN.
        ENDIF.

        check_input_file_exists( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        upload_excel_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.

        validate_no_of_xcel_records( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN gs_screen_input-app_server.
        validate_app_file_path( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        read_application_file_data( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
        build_dynamic_internal_table( ).
        validate_no_of_app_fields( ).
        IF gv_message IS NOT INITIAL.
          RETURN.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.

    build_primary_internal_table( ).
  ENDMETHOD.
  METHOD validate_input_file_data.
*    validate_field_data( ).
    FIELD-SYMBOLS: <lt_translation_file> TYPE STANDARD TABLE,
                   <lt_alv_output>       TYPE STANDARD TABLE,
                   <lt_upload_data>      TYPE STANDARD TABLE.
* Validate all the data and from the translation file and
* prepare output table as well

* Build translation table type from the reference.
    ASSIGN gt_translation_data_ref->* TO <lt_translation_file>.

* Build translation structure type from the reference.
    ASSIGN gs_translation_data_ref->* TO FIELD-SYMBOL(<ls_translation_data>).

* Build ALV Output table ref.
    ASSIGN gt_alv_output_ref->* TO <lt_alv_output>.

* Build ALV Output structure ref.
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output>).
    ASSIGN gs_alv_output_ref->* TO FIELD-SYMBOL(<ls_alv_output_dup>).

    ASSIGN gt_upload_data_ref->* TO <lt_upload_data>.

*    <lt_alv_output> = CORRESPONDING #( <lt_translation_file> ).
    <lt_alv_output> = CORRESPONDING #( <lt_upload_data> ).

    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = gs_screen_input-product_type
      IMPORTING
        et_fields_in_order = DATA(lt_primary_in_order) ).

    LOOP AT <lt_alv_output> ASSIGNING <ls_alv_output>.

* Clear global variable.
      CLEAR: gv_message.

* To capture any error message.
      ASSIGN COMPONENT 'MESSAGE'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_msg>).

      IF <ls_alv_output_dup> = <ls_alv_output>.
        MESSAGE e037(zdl_c10156) INTO gv_message.
        <lv_msg> = gv_message.
        CONTINUE.
      ENDIF.
      <ls_alv_output_dup> = <ls_alv_output>.

*  Check for BUNDLE roll. For BUNDLE roll, SPECIAL STOCK INDICATER should not be different
      ASSIGN COMPONENT 'PACKAGE_NUMBER'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_package_number>).
      ASSIGN COMPONENT 'SOBKZ'
           OF STRUCTURE <ls_alv_output>
           TO FIELD-SYMBOL(<lv_sobkz>).
      IF sy-tabix <> 1 AND
        gv_pack_num = <lv_package_number>.
        IF gv_special_stk_ind <> <lv_sobkz>.
          MESSAGE e075(zdl_c10156) INTO gv_message.
          <lv_msg> = gv_message.
          CONTINUE.
        ENDIF.
      ENDIF.
      gv_pack_num = <lv_package_number>.
      gv_special_stk_ind = <lv_sobkz>.

* Read Primary table to apply validation for required fields
      LOOP AT lt_primary_in_order INTO gs_primary_1 WHERE zzgroup = 'DELIVER' AND
                                                         zzgroupset = gs_screen_input-product_type.
* Check if the fields is ignorable. If it is ignorable,
*  then do not validate this field
        IF gs_primary_1-zzvalue4 = 'I'.
          CONTINUE.
        ENDIF.
* Validation for the fields.
* First get the field name and then get the value for the field
        CASE gs_primary_1-zzkey2.
          WHEN 'WERKS'.
* Plant Validation
            validate_werks(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

          WHEN 'LGORT'.
* Storage loctatioin validation.
            validate_lgort(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Material validation.
          WHEN 'MATNR'.
            validate_matnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Batch validation.
          WHEN 'CHARG'.
            validate_charg_for_gr_hu(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Quantity validation.
          WHEN 'MENGE'.
            validate_menge(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* UOM validation
          WHEN 'MEINS'.
            validate_meins(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Special stock validation
          WHEN 'SOBKZ'.
            validate_sobkz(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Sales Order document validation.
          WHEN 'VBELN'.
            validate_vbeln_posnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).

* Customer number validataion.
          WHEN 'KUNNR'.
            validate_kunnr(
              CHANGING
                cs_alv_output_data = <ls_alv_output> ).
          WHEN OTHERS.
        ENDCASE.

        check_hu_exists(
          CHANGING
            cs_alv_output_data = <ls_alv_output> ).

        IF gv_message IS NOT INITIAL.
          <lv_msg> = gv_message.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
    go_alv_output_ref = gt_alv_output_ref.
  ENDMETHOD.
  METHOD translation_file_data.
    build_translation_data( ).
  ENDMETHOD.
  METHOD create_revers_process.
*->Begin of CD2000007614/MAIELY/ for coc-HU managed location no GM
*      create_hu_pack( ).
    IF gv_no_xhupf IS INITIAL AND gv_no_parlg IS INITIAL.

*-Check if Exception process check box is set on selection screen
      IF gs_screen_input-except_proc IS INITIAL.
        create_hu_pack( ).
      ELSE.
        create_hu_pack_nomovement( ).
      ENDIF.
    ELSE.
      create_hu_pack_nomovement( ).
    ENDIF.
*-<End of CD2000007614/MAIELY/ for coc-HU managed location no GM
  ENDMETHOD.
  METHOD write_files_in_app_server.
    save_file_app_server( ).
  ENDMETHOD.
ENDCLASS.

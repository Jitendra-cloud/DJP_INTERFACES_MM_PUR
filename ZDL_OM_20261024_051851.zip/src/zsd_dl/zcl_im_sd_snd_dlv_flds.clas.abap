class ZCL_IM_SD_SND_DLV_FLDS definition
  public
  final
  create public .

*"* public components of class ZCL_IM_SD_SND_DLV_FLDS
*"* do not include other source files here!!!
public section.

  interfaces /GCDS04/IF_EX_SND_DLV_FLDS .
protected section.
*"* protected components of class ZCL_IM_SD_SND_DLV_FLDS
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_SD_SND_DLV_FLDS
*"* do not include other source files here!!!

  methods SEND_ERROR_EMAIL
    importing
      !LV_DEL type VBELN_VL
      !LV_DEL_ITEM type POSNR_VL
      !LV_STO type VGBEL
      !LV_STO_ITEM type VGPOS
      !LV_SY_SUBRC type SY-SUBRC
      !LV_LGORT type LGORT_D .
  methods BREAK_POINT .
ENDCLASS.



CLASS ZCL_IM_SD_SND_DLV_FLDS IMPLEMENTATION.


METHOD /gcds04/if_ex_snd_dlv_flds~add_fields .
*----------------------------------------------------------------------*
* Copyright: February 2004 by International Paper Company
* Author  : Maureen Carter
*----------------------------------------------------------------------*
* E1462 enhance delivery CIF to add data
*       sales order and item
*       incoterms 1 and 2
*       purchase order number
*       shipping condition
* requires OSS note 698360 for the original BAdi
* sample code from OSS note 698361
*
* Append structure CT_ATPFIELD with delivery#/item, field name and value
* Requires a matching BAdi in APO to receive the data - ZTP_DLV_ADD
* Field name must match what is used in APO to pull the value from the
* structure.
*
* This method is processed for each delivery line item
*----------------------------------------------------------------------*
* Data Stuctures for this BADI implementation
* I_FXLIKP  Importing  Type   LIKPVB               Delivery Header
* I_FXLIPS  Importing  Type   LIPSVB               Delivery Item
* CT_ATPFIELD	Changing   Type   ATPFIELD_TABLE_TYPE Type for atpfield
*----------------------------------------------------------------------*
* Change History:
* 07/20/04  MACARTE  reorganize and add fields for STO deliveries
* 01/24/05  RWAINW1  Add fields to enhance delivery CIF (RLW01)
* 08/26/05  JHARCRO  Add delivery window fields
* 03/27/06  SKOCHER  Add Unit Weight (Roll Weight) field, CR-04275,
*                    MTS Product Densities
* 05/03/06  MACARTE  R6 change logic to get sales order for MTS orders
* 05/30/06  MACARTE  R7 get export data from Z tables instead of VBAK
* 07/19/06  SNAKKAL  R8 Get sales order and item data for export MTS
*                    order from VBAP when export MTO data fails. -
*                    Refer CR04825 for functional details.
* 07/27/06 SNAKKAL   R8 Get the sales order and item data from EKKO for
*                    export MTS orders.
* 12/12/14 JELLI22   Add fields for Export Optimization
*     **** to see above changes - you need to go to version history
*     **** all old code and comments have been cleaned up.
* 01/22/15 CRAMEY    Rewrite logic to allow ZTP_VALUE to drive data values
*                    to be CIF-ed once table enties are retrieved.
*----------------------------------------------------------------------*

  constants: c_type_sto   type vbtyp value 'V',  "STO
             c_zsloc_name TYPE APO_KFDNA VALUE 'ZSLOC'.
  data: l_lgort type lgort_d.

* Tables for the Export Booking FM call
  DATA: lt_book_hdr    TYPE TABLE OF zsd_book_hdr,
        lt_book_itm    TYPE TABLE OF zsd_book_itm,
        lt_book_cntnrs TYPE TABLE OF zsd_book_cntnrs,
        lt_ret         TYPE bapiret2_t.

  DATA: l_atpfield   TYPE atpfield,
        lv_order     TYPE vbelv,
        lv_item      TYPE posnv,
        lv_matkl     TYPE matkl,
        lv_werks     TYPE werks_d,
        lv_bookdoc   TYPE zsd_book_bookdoc,
        ls_book_hdr  TYPE zsd_book_hdr,
        ls_book_cnt1 TYPE zsd_book_cntnrs,
        ls_book_cnt2 TYPE zsd_book_cntnrs,
        ls_book_cnt3 TYPE zsd_book_cntnrs,
        ls_vbak      TYPE vbak,
        ls_vbap      TYPE vbap.

  DATA: lt_data  TYPE TABLE OF ztp_cif_data.
  FIELD-SYMBOLS: <field>       TYPE any,
                 <valfield>    TYPE any,
                 <ls_data>     TYPE ztp_cif_data,
                 <ls_atpfield> TYPE atpfield.

*---------------------------------------------------------------------
*** START - USED FOR TESTING -> PLEASE DO NOT REMOVE ***
*---------------------------------------------------------------------
* This method is always executed in background and it can
*   be difficult to test
* These data fields and the mail function can be used to verify what
* data is available when the call is made to APO
  DATA:
    lt_recipient TYPE TABLE OF zrecmail,
    ls_recipient TYPE zrecmail,
    lt_message   TYPE TABLE OF soli,
    ls_message   TYPE soli,
    lv_subject   TYPE so_obj_des.
*---------------------------------------------------------------------
*** END - USED FOR TESTING -> PLEASE DO NOT REMOVE ***
*---------------------------------------------------------------------


  IF i_fxlips-vgtyp = ztp_constants=>delivery_for_sto.
    IF NOT i_fxlips-vbelv IS INITIAL.     "MTO STO
      lv_order = i_fxlips-vbelv.
      lv_item  = i_fxlips-posnv.
    ELSE.
* // Get the data from EKKO for export MTS when export MTO were initial
      SELECT SINGLE zzvbeln zzposnr INTO (lv_order, lv_item)
             FROM ekko WHERE ebeln = i_fxlips-vgbel.
    ENDIF.
  ELSE.
* this is a sales order for MTS or MTO
    lv_order = i_fxlips-vgbel.
    lv_item  = i_fxlips-vgpos.
  ENDIF. " i_fxlips-vgtyp = c_type_sto...

* Note: certain values will come from the same fields for both
*    sales orders & STOs
* Shared fields:
  l_atpfield-delnr = i_fxlips-vbeln.
  l_atpfield-delps = i_fxlips-posnr.

  IF NOT lv_order IS INITIAL.
    SELECT SINGLE * INTO ls_vbak
      FROM vbak
      WHERE vbeln = lv_order.

    SELECT SINGLE * INTO ls_vbap
      FROM vbap
     WHERE vbeln = lv_order
       AND posnr = lv_item.
    IF sy-subrc = 0.
      CLEAR: lv_matkl, lv_werks.
      SELECT SINGLE matkl INTO lv_matkl
             FROM mara
             WHERE matnr = ls_vbap-matnr.
      IF sy-subrc = 0.
        SELECT SINGLE werks INTO lv_werks
               FROM zdl_mts_density
               WHERE werks = ls_vbap-werks
               AND   matkl = lv_matkl.
        IF sy-subrc IS NOT INITIAL.
          CLEAR ls_vbap-zz_wgt_roll.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

* Clear booking info
  CLEAR: lt_book_hdr, lt_book_itm, lt_book_cntnrs,lt_ret.
  CLEAR: lv_bookdoc, ls_book_hdr, ls_book_cnt1, ls_book_cnt2, ls_book_cnt3.

  IF i_fxlikp-zzbookdoc IS NOT INITIAL.   "get the booking data.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = i_fxlikp-zzbookdoc
      IMPORTING
        output = lv_bookdoc.

* Get export booking data from ztables.
    CALL FUNCTION 'Z_SD_EXP_BOOK_GETDETAIL'
      EXPORTING
        iv_bookdoc    = lv_bookdoc
      TABLES
        et_book_hdr   = lt_book_hdr
        et_book_item  = lt_book_itm
        et_book_cntnr = lt_book_cntnrs
        et_return     = lt_ret.

* If header data returned, write to output customer record.
    IF lt_book_hdr[] IS NOT INITIAL.
      READ TABLE lt_book_hdr INTO ls_book_hdr INDEX 1.
    ENDIF.
    IF lt_book_cntnrs[] IS NOT INITIAL.
*** new requirement found by Yat Tsoi - 021015 - apparently the OM FM
*** can return the containers in a squence other than sorted by "sequence number"
******* new requirement to sort by sequence number - then pull data from the first 3 rows.
      SORT lt_book_cntnrs BY seqnr.
      READ TABLE lt_book_cntnrs INTO ls_book_cnt1 INDEX 1.
      READ TABLE lt_book_cntnrs INTO ls_book_cnt2 INDEX 2.
      READ TABLE lt_book_cntnrs INTO ls_book_cnt3 INDEX 3.
    ENDIF.
  ENDIF.



*** this code is a bit tricky so I'm going to try and explain it up front.
****************************
*** instead of the old method where find each field and then append to CT_ATPFLD
*** I though it would be best to store them in a Z-table.  There are complications
*** as we cannot dynamically specify the structure that the data is coming
*** from - thus the need for the case statement.
*****
*** But this design allows us to add ANY new field to the CIF (that is in a table
*** already being accessed) - by simply adding it to ZTP_CIF_DATA
****
****   the implications of changing ZTP_CIF_DATA are sufficiently complicated enough
****   to warrent keeping the access to Development Team ONLY!!!!!!
****
*** new fields from new tables must be selected first and the structure added to
*** the case statement.
********
*** I also added the SENDBLANK field since the EOP redesign wanted to send
*** blanks as well - normally we don't send blanks thru the CIF
********
*** ALSO I added the ability to check a field in the table for data validations first - we're
*** currently only doing this for VGTYP = "V" or Deliveries created for STOs
****  if further validations are necessary - they will have to be coded seperately
************************************
**** assign component gets to the data within the value
****   thus if <ls_data>-fieldname = 'VGBEL'
****   ASSIGN COMPONENT <ls_value>-fieldname OF STRUCTURE I_FXLIPS  TO <field>.
****                    becomes the same as
****   ASSIGN I_FXLIPS-VGBEL to <field>.
***********             Thus <field> now points to the actual data.
*******************************************************************************************



  SELECT * INTO TABLE lt_data
    FROM ztp_cif_data
    WHERE  pgrmid = 'DELIVERYCIF'
      AND  logical_delete = ' '.

  LOOP AT lt_data ASSIGNING <ls_data>.
    CLEAR: l_atpfield-kfdna, l_atpfield-value.
    CASE <ls_data>-tabname.
      WHEN 'LIKP'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE i_fxlikp     TO <field>.
        CHECK sy-subrc IS INITIAL.
        IF <ls_data>-check_field IS NOT INITIAL.
*         **** yes I know this is checking an item to send Header info
          ASSIGN COMPONENT <ls_data>-check_field OF STRUCTURE i_fxlips TO <valfield>.
          CHECK sy-subrc IS INITIAL.
          IF <valfield> <> <ls_data>-check_value.
            UNASSIGN: <field>, <valfield>.
            CONTINUE.
          ENDIF.
        ENDIF.
      WHEN 'LIPS'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE i_fxlips     TO <field>.
        CHECK sy-subrc IS INITIAL.
        IF <ls_data>-check_field IS NOT INITIAL.
          ASSIGN COMPONENT <ls_data>-check_field OF STRUCTURE i_fxlips TO <valfield>.
          CHECK sy-subrc IS INITIAL.
          IF <valfield> <> <ls_data>-check_value.
            UNASSIGN: <field>, <valfield>.
            CONTINUE.
          ENDIF.
        ENDIF.
      WHEN 'VBAK'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE ls_vbak      TO <field>.
        CHECK sy-subrc IS INITIAL.
      WHEN 'VBAP'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE ls_vbap      TO <field>.
        CHECK sy-subrc IS INITIAL.
      WHEN 'BOOKHDR'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE ls_book_hdr  TO <field>.
        CHECK sy-subrc IS INITIAL.
      WHEN 'BOOKCNT1'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE ls_book_cnt1 TO <field>.
        CHECK sy-subrc IS INITIAL.
      WHEN 'BOOKCNT2'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE ls_book_cnt2 TO <field>.
        CHECK sy-subrc IS INITIAL.
      WHEN 'BOOKCNT3'.
        ASSIGN COMPONENT <ls_data>-fieldname OF STRUCTURE ls_book_cnt3 TO <field>.
        CHECK sy-subrc IS INITIAL.
    ENDCASE.
****please take special note - Standard SAP deletes any rows with blank values in
****  RV_DELIVERIES_SAVE  (line 58 - Delete fxapoi where value is initial)
**** so short of a CORE mode - you need to find some other solution than sending blanks
    IF <field> IS ASSIGNED.
      IF NOT <field> IS INITIAL.
        l_atpfield-kfdna = <ls_data>-field_id.
        l_atpfield-value = <field>.
        APPEND l_atpfield TO ct_atpfield.
      ENDIF.
    ENDIF.
    UNASSIGN: <field>, <valfield>.
  ENDLOOP.

  SORT ct_atpfield BY delnr delps kfdna.

  "** Special case for Storage Location of Domestic STO delivery
  if i_fxlips-vgtyp = c_type_sto.  "STO delivery V
    READ TABLE ct_atpfield ASSIGNING <ls_atpfield>
      WITH KEY delnr = i_fxlips-vbeln
               delps = i_fxlips-posnr
               kfdna = c_zsloc_name
        BINARY SEARCH.
    IF sy-subrc <> 0.
      l_atpfield-kfdna = c_zsloc_name.
      APPEND l_atpfield TO ct_atpfield ASSIGNING <ls_atpfield>.
      SORT ct_atpfield BY kfdna.
    ENDIF.
    IF <ls_atpfield>-value IS INITIAL.
      select single lgort
        from ekpo
        into l_lgort
        where ebeln = i_fxlips-vgbel
          and ebelp = i_fxlips-vgpos.
      if l_lgort is not initial.
        <ls_atpfield>-value = l_lgort.
      endif.
"          CALL METHOD me->SEND_ERROR_EMAIL
"      EXPORTING
"        LV_DEL      = i_fxlips-vbeln
"        LV_DEL_ITEM = i_fxlips-posnr
"        LV_STO      = i_fxlips-vgbel
"        LV_STO_ITEM = i_fxlips-vgpos
"        LV_SY_SUBRC = sy-subrc
"        LV_LGORT    = l_lgort.
    ENDIF.
  ENDIF.


  "**********************************************************************************
  "*** send the cif to your SAP email.

  "  DATA: lt_unames   TYPE TABLE OF soud3,
  "        lv_unames   TYPE soud3,
  "        lt_text     TYPE TABLE OF soli,
  "        ls_text     TYPE soli.

  "  lv_unames-sapnam = 'CRAMEY'.
  "  lv_unames-usrnam = 'CRAMEY'.
  "  APPEND lv_unames TO lt_unames.

  "  LOOP AT ct_atpfield INTO l_atpfield.
  "    ls_text-line = l_atpfield.
  "    APPEND ls_text TO lt_text.
  "  ENDLOOP.

  "  CALL FUNCTION 'Z_SEND_MAIL'
  "    EXPORTING
  "*   EXPRESS                       = ' '
  "      name                          = 'CRAMEY'
  "      subject                       = 'Delivery CIF'
  "*   MODIFIABLE                    = ' '
  "    TABLES
  "      rec_unames                    = lt_unames
  "      text                          = lt_text
  "*   TEXT_CONT                     =
  "*   TEXT_HEAD                     =
  "*   PACKING_LIST                  =
  "* EXCEPTIONS
  "*   RECEIVER_DOES_NOT_EXIST       = 1
  "*   OTHERS                        = 2
  "            .
  "  IF sy-subrc <> 0.
  "* Implement suitable error handling here
  "  ENDIF.


ENDMETHOD.


method BREAK_POINT .

  break macarte.

endmethod.


  method SEND_ERROR_EMAIL.
    DATA:
      lv_adrc_name TYPE ad_name1,
      ls_mail_text TYPE soli,
      lt_mail_text TYPE TABLE OF soli,
      ls_mailaddr  TYPE ad_smtpadr,
      lt_mailaddr  TYPE TABLE OF ad_smtpadr,
      ls_userid    TYPE string,
      lt_userid    TYPE TABLE OF string.

    DATA : lv_subject       TYPE string,
           lv_text          TYPE string,
           lv_doc_subject   TYPE so_obj_des,
           lt_text          TYPE bcsy_text,
           lo_send_request  TYPE REF TO cl_bcs,
           lo_document      TYPE REF TO cl_document_bcs,
           lo_sender        TYPE REF TO cl_cam_address_bcs,
           lo_recipient     TYPE REF TO if_recipient_bcs,
           lv_sent_to_all   TYPE os_boolean,
           lt_email_cc      TYPE table_of_strings,
           ls_email_cc      TYPE string,
           lv_email         TYPE ad_smtpadr,
           lv_retcode       TYPE sysubrc,
           lv_name          TYPE ad_name1,
           lv_from_name     TYPE  ad_smtpadr,
           lv_from_address  TYPE ad_smtpadr,
           lo_bcs_exception TYPE REF TO cx_bcs.

**************end of local data declarations*************
    lv_subject = 'Delivery CIF Error'.

***insert blank line
    CLEAR ls_mail_text.
    APPEND ls_mail_text TO lt_mail_text.

******build message
    lv_text = 'Delivery: ' && lv_del.
    ls_mail_text = lv_text.
    APPEND ls_mail_text to lt_mail_text.

    lv_text = 'Delivery Item: ' && lv_del_item.
    ls_mail_text = lv_text.
    APPEND ls_mail_text to lt_mail_text.

    lv_text = 'STO: ' && lv_sto.
    ls_mail_text = lv_text.
    APPEND ls_mail_text to lt_mail_text.

    lv_text = 'STO Item: ' && lv_sto_item.
    ls_mail_text = lv_text.
    APPEND ls_mail_text to lt_mail_text.

    lv_text = 'SY-SUBRC: ' && lv_sy_subrc.
    ls_mail_text = lv_text.
    APPEND ls_mail_text to lt_mail_text.

    lv_text = 'LGORT: ' && lv_lgort.
    ls_mail_text = lv_text.
    APPEND ls_mail_text to lt_mail_text.

******set recepient
SELECT ALTKEY FROM ZTP_VALUE
  INTO TABLE lt_userid
  WHERE PGRMID = 'DELIVERY_CIF_EMAIL'
  AND FIELDNAME = 'USERID'.

  LOOP AT lt_userid INTO ls_userid.
    ls_mailaddr = ls_userid && '@ipaper.com'.
    append ls_mailaddr to lt_mailaddr.
  ENDLOOP.

    IF lt_mailaddr[] IS NOT INITIAL .

      TRY.
          lv_doc_subject = lv_subject.

***Create persistent send request
          lo_send_request = cl_bcs=>create_persistent( ).

***Set the document
          lo_document = cl_document_bcs=>create_document(
                         i_type    = 'RAW'
                         i_text    = lt_mail_text
                         i_subject = lv_doc_subject ).

***Add document object to send request
          lo_send_request->set_document( lo_document ).

***Set the email subject
          lo_send_request->set_message_subject( lv_subject ).

*        Set the sender email and name
*        CALL METHOD cl_cam_address_bcs=>create_internet_address
*          EXPORTING
*            i_address_string = lv_from_address
*            i_address_name   = lv_from_name
*          RECEIVING
*            result           = lo_sender.
*
*        lo_send_request->set_sender( lo_sender ).

***Add recipient object to send request
          LOOP AT  lt_mailaddr INTO ls_mailaddr.
            CLEAR lv_email.
            lv_email = ls_mailaddr.
            lo_recipient = cl_cam_address_bcs=>create_internet_address( lv_email ).
            lo_send_request->add_recipient( lo_recipient ).
          ENDLOOP.

***Send document
          lv_sent_to_all = lo_send_request->send( i_with_error_screen = abap_true ).
        CATCH cx_bcs INTO lo_bcs_exception.

      ENDTRY.
    ENDIF.

  endmethod.
ENDCLASS.

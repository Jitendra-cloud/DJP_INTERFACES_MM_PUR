function zdlr10512_sloc.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IT_WERKS) TYPE  TT_RSDSSELOPT OPTIONAL
*"     VALUE(IT_LGORT) TYPE  TT_RSDSSELOPT OPTIONAL
*"  EXPORTING
*"     VALUE(ET_SLOC) TYPE  ZDLR10512_TT_SLOC
*"----------------------------------------------------------------------
  types: t_werks type range of werks_d.
  types: t_lgort type range of lgort_d.

  data: lr_werks type t_werks.
  data: lr_lgort type t_lgort.

  data: ls_werks type line of t_werks.
  data: ls_lgort type line of t_lgort.

  if it_werks[] is initial.
    append 'ICP92*' to lr_werks.
  else.
    lr_werks[] =  it_werks[].
  endif.

  if it_lgort[] is initial.
    append 'ICPHU*' to lr_lgort.
  else.
    lr_lgort[] = it_lgort[].
  endif.

  refresh et_sloc[].

  select
    t001w~werks,
    t001w~name1,
    twlad~lgort,
    adrc~name1 as adrname,
    adrc~house_num1,
    adrc~street,
    adrc~city1,
    adrc~region,
    adrc~post_code1
  from twlad join t001w on twlad~werks = t001w~werks
        join adrc on twlad~adrnr = adrc~addrnumber
        into corresponding fields of table @et_sloc
  where t001w~werks in @lr_werks
    and twlad~lgort in @lr_lgort.

endfunction.

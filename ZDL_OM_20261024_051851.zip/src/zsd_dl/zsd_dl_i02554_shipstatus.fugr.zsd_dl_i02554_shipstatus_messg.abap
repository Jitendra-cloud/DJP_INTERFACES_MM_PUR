FUNCTION zsd_dl_i02554_shipstatus_messg.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(IS_EVENT_INFO) TYPE  ZDL_I02554_EM_EVENT_INFO
*"  EXPORTING
*"     VALUE(ES_ERROR) TYPE  BAPIRET2
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT © 2008 by                             **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT ©                            **
**                          2008, 200n                                **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
* Program Name: RFC FM to trigger                Create Date: 06/17/08 *
*               Outbound 214 Idoc                                      *
* SAP Name    : ZSD_DL_I02554_SHIPSTATUS_MESSG   Version    : V4W3     *
* Programmer  : Chandra Cherupally               Last Update:          *
* Inventory Code : I02554                                              *
************************************************************************
* Description : This function module is an RFC function module called  *
* by SCEM system whenever some event gets trigged in SCEM to send a    *
* Outbound Shipment Status Idoc (214). This FM will be called with     *
* Shipment Number, Itinerary Number, Event code and other EM related   *
* information. After validating the input data and gathering all the   *
* required info from tables like VBPA (Partner data), B980, B981, B982 *
* (condition tables), NACH (Partner output data) few performs of       *
* RSNAST00 program are called to send the IDOC and do the further steps*
************************************************************************
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* Chandra Cherupally  06/17/08  EDVK963368  Initial Version            *
* Chandra Cherupally  07/18/08  EDVK963368  CR 8159 - SO & PO Numbers  *
*                                                                      *
************************************************************************

  DATA ls_itinerary  TYPE zmos_itinerary.

  PERFORM refresh_variables.

* Copy the incoming EM data into a global structure
  gs_em_data = is_event_info.

* Validate the Input data
  PERFORM validate_data CHANGING es_error.
  IF es_error IS NOT INITIAL.
    RETURN.
  ENDIF.

* Read the Shipment Itinerary data
  PERFORM read_shipment_itinerary  USING gs_em_data-itnum
                                CHANGING es_error.
  IF es_error IS NOT INITIAL.
    EXIT.
  ENDIF.

* For input itinerary, ther's always going to be one entry left
  READ TABLE gt_itinerary INTO ls_itinerary INDEX 1.
  gt_stop_delvs[] = ls_itinerary-deliveries[].

  SORT gt_stop_delvs BY vbeln.
* Get VBPA data for the deliveries associated to the input itinerary
  PERFORM get_vbpa_data TABLES gt_stop_delvs
                               gt_vbpa.

* Get SO & PO No.s for the deliveries associated to the input itinerary
  PERFORM get_vbfa_vbak_data.                               " CR 8159

* Get Condition records data from tables B980, B981 & B982
  PERFORM get_condition_records CHANGING es_error.
  IF es_error IS NOT INITIAL.
    EXIT.
  ENDIF.

* Get recipients data from NACH table
  PERFORM get_recipients_info.

* Process the gathered data and send IDOCs
  PERFORM process_send_idoc     CHANGING es_error.

ENDFUNCTION.

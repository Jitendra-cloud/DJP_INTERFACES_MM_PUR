FUNCTION zsd_i02429_pallet_inbound.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  IMPORTING
*"     VALUE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     VALUE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     VALUE(WORKFLOW_RESULT) LIKE  BDWFAP_PAR-RESULT
*"     VALUE(APPLICATION_VARIABLE) LIKE  BDWFAP_PAR-APPL_VAR
*"     VALUE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     VALUE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"      OTHERS
*"----------------------------------------------------------------------
* Programmer  : Naveen Parchuri               Date : 12/19/2006        *
*                                                                      *
*______________________________________________________________________*
* Description : This function module is called from process code ZPAL  *
*               The goal of this FM is to update delivery to include   *
*               miscellaneous pallets and associated weight to weight  *
*               sent from omega                                        *
*                                                                      *
*  COR        : I02429                                                 *
*----------------------------------------------------------------------*

* Read the control data
  READ TABLE idoc_contrl INDEX 1.

* Move the data
  LOOP AT idoc_data WHERE docnum = idoc_contrl-docnum.
    MOVE idoc_data TO isegm.
    CASE isegm-segnam.
      WHEN seg_pi_header.        " Header Segment
* Check For Delivery header
        PERFORM delivery_check.
* if error exit with the error message
        IF returncode = 4 .
          EXIT.
        ENDIF.
      WHEN seg_pi_item.          " Item segment
        MOVE isegm-sdata TO e1vpdli.
* BDC executed only when key word PALLET is available
        IF e1vpdli-matnr_guid = 'PALLET'.
          PERFORM validations_for_pallet.
        ENDIF.
    ENDCASE.
    CLEAR isegm.
  ENDLOOP.

ENDFUNCTION.

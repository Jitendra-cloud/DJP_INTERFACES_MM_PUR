*"* use this source file for any type declarations (class
*"* definitions, interfaces or data types) you need for method
*"* implementation or private method's signature

TYPES : BEGIN OF gs_vttp  ,
         tknum TYPE tknum ,
         vbeln TYPE vbeln_vl,
         tprfo TYPE tprfo,
       END OF gs_vttp,

        BEGIN OF gs_likp ,
         tknum TYPE tknum ,
         vstel TYPE vstel ,
         kunnr TYPE kunnr ,
         kunag TYPE kunag ,
         vbeln TYPE vbeln_vl ,
         vkorg TYPE vkorg,
         posnr TYPE posnr ,
         vgtyp TYPE vbtyp  ,
         vgbel TYPE vgbel ,
         vgpos TYPE vgpos,
         matnr TYPE matnr ,
         vbelv TYPE vbelv ,
         posnv TYPE posnv ,
         spart TYPE spart ,
         vtweg TYPE vtweg ,
         parnr TYPE na_parnr,
       END OF gs_likp,


       BEGIN OF gs_invoice,
          tknum TYPE tknum,
          vbeln TYPE vgbel ,
       END OF gs_invoice,

       BEGIN OF gs_delvery,
        vbeln TYPE vbeln_vf,
        vgbel TYPE vgbel,
       END OF gs_delvery,

       BEGIN OF gs_nast_parnr,
         parnr TYPE na_parnr,
         kschl TYPE kschl ,
         objky TYPE na_objkey,
         parvw TYPE sna_parvw,
         nacha TYPE na_nacha,
         vstat TYPE na_vstat,
         sndbc type ad_adrtype,
         telfx type na_telfx,
         tland type land1,
      END OF gs_nast_parnr,

      BEGIN OF gs_nast_delv,
         objky TYPE na_objkey,
        END OF gs_nast_delv,

      BEGIN OF gs_knvk ,
         parnr TYPE parnr,
         kunnr TYPE kunnr,
         prsnr TYPE ad_persnum,
         namev TYPE namev_vp,
         name1 TYPE name1_gp,
        END OF gs_knvk,

      BEGIN OF gs_knvp,
        kunnr TYPE kunnr,
        parnr TYPE parnr,
      END OF gs_knvp,

      BEGIN OF gs_nast_knvp,
        parnr TYPE parnr,
        parvw TYPE parvw,
      END OF gs_nast_knvp,

    BEGIN OF gs_nast_knvk,
        parnr TYPE parnr,
      END OF gs_nast_knvk,

   BEGIN OF gs_nast_vbeln,
        vbeln TYPE vbeln_vl,
      END OF gs_nast_vbeln.



TYPES : gt_invoice TYPE STANDARD TABLE OF gs_invoice.

* Itinerary view
TYPES : BEGIN OF gs_itin  ,
         tknum TYPE tknum ,
         vstel TYPE  vstel,
         vbeln TYPE vbeln_vl,
       END OF gs_itin.

TYPES : gt_likp TYPE STANDARD TABLE OF gs_likp,
        gt_vttp TYPE STANDARD TABLE OF gs_vttp,
        gt_itin TYPE STANDARD TABLE OF gs_itin,
        gt_nast_parnr TYPE STANDARD TABLE OF gs_nast_parnr,
        gt_nast_delv TYPE STANDARD TABLE OF gs_nast_delv,
        gt_knvk TYPE STANDARD TABLE OF gs_knvk ,
        gt_knvp TYPE STANDARD TABLE OF gs_knvp,
        gt_nast_vbeln TYPE STANDARD TABLE OF  gs_nast_vbeln.

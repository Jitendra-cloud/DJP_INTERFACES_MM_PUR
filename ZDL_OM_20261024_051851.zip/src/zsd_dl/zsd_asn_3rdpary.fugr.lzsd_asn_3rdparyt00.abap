*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSD_ASN_3RDPARTY................................*
DATA:  BEGIN OF STATUS_ZSD_ASN_3RDPARTY              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_ASN_3RDPARTY              .
CONTROLS: TCTRL_ZSD_ASN_3RDPARTY
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSD_ASN_3RDPARTY              .
TABLES: ZSD_ASN_3RDPARTY               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

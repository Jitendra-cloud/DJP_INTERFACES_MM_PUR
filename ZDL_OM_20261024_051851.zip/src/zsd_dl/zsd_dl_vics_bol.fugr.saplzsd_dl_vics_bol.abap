*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_VICS_BOLTOP.               " Global Data
  INCLUDE LZSD_DL_VICS_BOLUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_VICS_BOLF...               " Subprograms
* INCLUDE LZSD_DL_VICS_BOLO...               " PBO-Modules
* INCLUDE LZSD_DL_VICS_BOLI...               " PAI-Modules

INCLUDE LZSD_DL_VICS_BOLSUB.

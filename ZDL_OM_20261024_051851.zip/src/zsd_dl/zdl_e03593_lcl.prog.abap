*&---------------------------------------------------------------------*
*&  Include           ZDL_E03593_LCL
*&---------------------------------------------------------------------*

CLASS lcl_E03593 DEFINITION FINAL.
  PUBLIC SECTION.
    CLASS-DATA: go_e03593 TYPE REF TO lcl_E03593.

    class-METHODS:
      convert_vendor IMPORTING iv_lifnr type ZSP_LOWVAL
                     RETURNING VALUE(rt_lifnr) TYPE lifnr.

    ENDCLASS.

CLASS  lcl_E03593 IMPLEMENTATION.
  METHOD convert_vendor.
    data: lv_lifnr type lifnr.
    lv_lifnr = iv_lifnr.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        INPUT         = lv_lifnr
     IMPORTING
       OUTPUT        = rt_lifnr
              .

  endmethod.
ENDCLASS.

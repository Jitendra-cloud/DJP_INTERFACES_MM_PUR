************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2006                                     **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: Determine Mean of Transport-    Create Date: 07/14/2006*
*               for MoT Shift changes                                  *
*                                                                      *
* Inventory code: U01249                                               *
*                                                                      *
* SAP Name    : LZDL_U01249TOP                  Version    : V2        *
*                                                                      *
* Programmer  : Sreekanth Devis                 Last Update:           *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
*______________________________________________________________________*
* Description :This includes consists of all variable declarations     *
************************************************************************
FUNCTION-POOL zdl_u01249.                   "MESSAGE-ID ..

TABLES : zzxrefdetail.          "Enterprise cross reference detail table

*-- Constants
CONSTANTS: gc_object TYPE balobj_d VALUE 'ZDL_INTERFACE', "App log obj
           gc_subobject TYPE balsubobj VALUE 'ZMOT_SHIPCOND',"Sub Obj
           gc_yes TYPE zdl_supply_drivn-zsto_sc_trf VALUE 'Y',
           gc_ship_cond_container TYPE zstoshipcond-zstovsbed
                                  VALUE 'CX'.

*-- Application log declarations
DATA: gs_log TYPE bal_s_log,
      go_applog TYPE REF TO zcl_ca_applogging,
      gv_message TYPE string.                  "Hold error message

DATA:  gv_zstovsbed TYPE zstoshipcond-zstovsbed,"Hold ZSTOSHIPCOND
       gv_container_size TYPE zsd_book_cntnrs-con_size,"Hold cont. size
       gv_count TYPE i,               "Hold book containers tot. records
       gv_sup_drivn TYPE zdl_supply_drivn-zsto_sc_trf."Hold supp.drv.flg

*-- To hold container size and booking document number
DATA : BEGIN OF gt_zsd_book_cntnrs  OCCURS 0,
          con_size LIKE zsd_book_cntnrs-con_size,
          bookdoc LIKE zsd_book_cntnrs-bookdoc,
       END OF gt_zsd_book_cntnrs .

*-- To hold EXTENSIONIN value into one structure
DATA : gs_extensionin TYPE cifbparex.

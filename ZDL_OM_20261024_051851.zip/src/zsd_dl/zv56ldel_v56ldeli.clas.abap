class ZV56LDEL_V56LDELI definition
  public
  final
  create public .

*"* public components of class ZV56LDEL_V56LDELI
*"* do not include other source files here!!!
public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_SMOD_V56LDELI .
protected section.
*"* protected components of class ZV56LDEL_V56LDELI
*"* do not include other source files here!!!
private section.
*"* private components of class ZV56LDEL_V56LDELI
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZV56LDEL_V56LDELI IMPLEMENTATION.


METHOD if_ex_smod_v56ldeli~exit_saplv56l_002.
  CALL FUNCTION 'EXIT_SAPLV56L_002'
    EXPORTING
      i_langu                     = i_langu
      i_partner_role              = i_partner_role
      opt_minimized_delivery_view = opt_minimized_delivery_view
      opt_items                   = opt_items
      opt_partners                = opt_partners
      opt_customer_data           = opt_customer_data
      opt_customizing_data        = opt_customizing_data
      opt_order_data              = opt_order_data
      opt_export_data             = opt_export_data
    TABLES
      c_vtrlk                     = c_vtrlk
      c_vtrlp                     = c_vtrlp
    EXCEPTIONS
      error                       = 1.

  CASE sy-subrc.
    WHEN  1.
      RAISE EXCEPTION TYPE cx_vtr.
  ENDCASE.
ENDMETHOD.
ENDCLASS.

***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                *
**        This program is the property of International Paper.        *
**        Care should be taken to prevent its unauthorized use.       *
***********************************************************************
***********************************************************************
**                    COPYRIGHT © 2006 by                             *
**                     INTERNATIONAL PAPER                            *
**                     ALL RIGHTS RESERVED                            *
**                   REVISIONS COPYRIGHT ©                            *
**                2006  by INTERNATIONAL PAPER                        *
***********************************************************************
* Program Name: Automatic Goods Receipt  Based On Shipment End Status *
* Creation Date : 09/20/2006                                          *
* SAP Name    : ZDL_E03593_GR_INBOUND_DELIVERY                        *
* Version     : V1W10 R10                                             *
* Programmer  : Naveen Parchuri                                       *
*_____________________________________________________________________*
* Description :                                                       *
*   This program will automate the goods receipt process for freight  *
*   forwarders                                                        *
*_____________________________________________________________________*
* Change History:                                                     *
*     Programmer        Date     Action                               *
* =================  ========    =====================================*
* KKOLLUR           02/06/2007   Added code for microbridge logic     *
*                   Shipment need to mark for shipment completion     *
*                   indicator for  micro bridge       connected       *
*                   deliveries                                        *
* KKOLLUR           06/11/2007   Added code to clear WS_DELIVERY_UPDAT*
*        fields per OSS message - tpr18532 (manually done in E0V after*
*        R8P2 project migration)                                      *
*                                                                     *
* ADEVIN1           07/26/2007   CR05144: Container HU creation on GR *
* Kumar Kolluri      08/01/2008  EDVK964849    TPR 01756              *
*                     Code need to be modified if the container       *
*                     contains multiple sales                         *
*                     orders then fail the container creation         *
* NPARCHU           10/06/2008   CR93478 Soft tickets issue           *
*                                HU creation issue resolution         *
*                                both were happening because of       *
*                                locking issues.
* NBEHERE           11/03/2008   CR93478 Containerized logic put in to*
*                                determine if a Delivery has been     *
*                                manually assigned to a Container or  *
*                                reassigned to a different O/B Dlvry  *
*                                new message types 'R' and 'C' were   *
*                                added for capturing these new valida-*
*                                tions.
* CRAMEY            07/13/2010  Change per CR 9555 to remove logic to *
*                               update Shipment completion on         *
*                               microbridge shipments                 *
* AMAOLE1| 08/03/15| CMS28321                                         *
* - Add container size to container creation                          *
* - Remove check for multiple orders, so that program creates         *
*   containers for multiple orders associted with a shipment          *
* - Add check for multiple orders to make sure they have the same     *
*   sold-to, ship-to & metric indicator                               *
* - Pick 'Booknum' from STO delivery instead of sales order line item *
* AMAOLE1| 05/19/16| CMS30389                                        *
* - Determine container tare weight & pass it to the container        *
*   creation function module ZDL_CREATE_CONTAINER                     *
* PWADEHR| 08/20/18| CMS34029                                         *
* - add check to allow DLK inbound deliveries to build containers for *
*   shipment types ZDIP and ZDIC
* JWILL68| 5/6/2019| CD#1847
* - Check if the shipment cost document is created, if not then do not*
*   allow the exsisting process to create GR.                         *
* ALANKAP 7/28/2021   Sylvamo changes                                 *
* ALANKAP 9/20/2021   CD # 267 Change the report category to          *
* E03593_THIRD while fetching the data from ZSDOMFLD                  *
*_____________________________________________________________________*
* External Calls                                                      *
*   Function Modules:   WS_DELIVERY_UPDATE                            *
*   Transactions    :   ZDL_GR_INBOUND_DELIVERY
*_____________________________________________________________________*
* Transaction       : ZDL_E03593                                      *
*_____________________________________________________________________*
* Scheduling Issues                                                   *
*   Run Frequency   : Daily
*_____________________________________________________________________*
***********************************************************************

REPORT  zdl_e03593_gr_inbound_delivery  LINE-SIZE 140
                                 LINE-COUNT 65(2)
                                 MESSAGE-ID zsd_dl
                                 NO STANDARD PAGE HEADING.

* Includes
INCLUDE <list>.                                             "CR05144

INCLUDE zdl_e03593_lcl.
* Database Tables
TABLES : zdl_ship_compl, likp .


**********************************************************************
* INTERNAL TABLE DECLARATIONS
**********************************************************************
* table for gs_ship_compl
***>>> start of changes NBEHERE CR93478
*DATA : gt_ship_compl LIKE zdl_ship_compl OCCURS 0 WITH HEADER LINE .
TYPES: BEGIN OF ty_ship_compl.
         INCLUDE STRUCTURE zdl_ship_compl.
         TYPES: zz_seal    TYPE zzseal,
         zz_signi   TYPE zdl_signi,
         vbelv      TYPE vbelv,
         vgbel      TYPE vgbel,
         gr_flag(1) TYPE c.
TYPES: END OF ty_ship_compl.

DATA: gt_ship_compl TYPE TABLE OF ty_ship_compl.

*DATA: BEGIN OF gt_ship_compl OCCURS 0.
*        INCLUDE STRUCTURE zdl_ship_compl.
**         TYPES: zz_seal    TYPE zzseal,
**         zz_signi   TYPE zdl_signi,
*         data: gr_flag(1) TYPE c.                    "to indicate GR posted
*DATA: END OF gt_ship_compl .
***<<< end of changes NBEHERE CR93478

TYPES: BEGIN OF ty_ekko,
         ebeln TYPE ebeln,
         bsart TYPE bsart,
         lifnr TYPE lifnr,
       END OF ty_ekko.

DATA: gt_ekko TYPE TABLE OF ty_ekko.

* table for likp entries
*DATA : BEGIN OF gt_lips OCCURS 0 ,
*         vbeln TYPE vbeln_vl,
*         vbelv TYPE vbelv,
*         vgbel TYPE vgbel,
*       END OF gt_lips.

* table for likp entries
DATA : BEGIN OF gt_likp OCCURS 0 ,
         vbeln TYPE vbeln_vl,
       END OF gt_likp .

* table for likp entries
DATA : BEGIN OF gt_likp1 OCCURS 0 ,
         vbeln     TYPE vbeln_vl,
         vstel     TYPE vstel,
         vsbed     TYPE vsbed,
         wadat_ist TYPE wadat_ist,
         bolnr     TYPE bolnr,
         zzbooknum TYPE zzbooknum,
         zzbookdoc TYPE z_bookdoc,
         zz_signi  TYPE zdl_signi,
         zz_seal   TYPE zzseal,
         zz_shtyp  TYPE shtyp,
         vbelv     TYPE vbelv,
         vgbel     TYPE vgbel,
       END OF gt_likp1.

* table for vbuk entries
DATA : BEGIN OF gt_vbuk OCCURS 0 ,
         vbeln     TYPE vbeln,
         wbstk     TYPE wbstk,
         wadat_ist TYPE wadat_ist,
       END OF gt_vbuk.

* table for vttk entries
DATA : BEGIN OF gt_vttk OCCURS 0 ,
         tknum TYPE tknum,
         shtyp TYPE shtyp,                                  "CMS#34029
         daten TYPE datend,
       END OF gt_vttk.

* table for report header
DATA: BEGIN OF it_hdr OCCURS 0.              "Call header func.
        INCLUDE STRUCTURE zrptheader.
      DATA: END OF it_hdr.

* Final table for deletion

*DATA : gt_final_delete TYPE TABLE OF ty_ship_compl." OCCURS 0 WITH HEADER LINE.
*DATA : gt_final_delete LIKE gt_ship_compl OCCURS 0 WITH HEADER LINE.
DATA : gt_final_delete  TYPE ty_ship_compl OCCURS 0 WITH HEADER LINE. " Sylvamo change

* Final table for display
DATA :  BEGIN OF gt_final_display OCCURS 0 .
*          INCLUDE STRUCTURE gt_ship_compl.
          INCLUDE TYPE ty_ship_compl.
          DATA : gr_posted(3) ,
          del_flag(1)  TYPE c,                              "CR93478
        END OF gt_final_display.


*data: begin of gt_final_display occurs 0,
*        include type ty_ship_compl,
*    end of gt_final_display .

* Begin of CR05144
DATA : BEGIN OF gt_hu_create OCCURS 0,
*         tknum     TYPE tknum, "Shipment number " Sylvamo changes
         vbeln     TYPE vbeln_vl,  "Inbound delivery " " Sylvamo changes
         exidv     TYPE exidv, "HU
         mess_type TYPE char2, "Message Type
         werks     TYPE empfw, "Plant
         message   TYPE t100-text, "Error Message
       END OF gt_hu_create,

       BEGIN OF gs_gr_status ,
*         tknum   TYPE tknum,     "Shipment number " Sylvamo changes
         vbeln_i TYPE vbeln_vl,  "Inbound delivery
*         vbeln   TYPE vbeln_vl,  "Outbound delivery " Sylvamo changes
         ebeln   TYPE ebeln,     "Purchase Order
         wbstk   TYPE wbstk,     "Total Goods Movement Status
         signi   TYPE signi,     "Container ID
         text1   TYPE zdl_seal_no, "Seal Number
         sord_no TYPE vbeln_co, "Sales Order Number
         booknum TYPE zsd_book_booknum, "Booking confirm number
         bookdoc TYPE zsd_book_bookdoc, "Booking Doc CMS28321
       END OF gs_gr_status,

       gt_gr_status LIKE gs_gr_status OCCURS 0 WITH HEADER LINE.
* End of CR05144

TYPES: BEGIN OF ty_container_size,
         vbeln     TYPE vbeln_vl,  "Inbound delivery " " Sylvamo changes
*         tknum     TYPE tknum,
         size      TYPE zsd_book_con_size,
         cont_tare TYPE zsd_cont_tare,
       END OF ty_container_size.
DATA gt_container_size TYPE STANDARD TABLE OF ty_container_size.

DATA: BEGIN OF gs_multi_ord_fails,
*        tknum     TYPE tknum,
        vbeln     TYPE vbeln_vl,  "Inbound delivery " " Sylvamo changes
        mess_type TYPE char2,
      END OF gs_multi_ord_fails.

DATA gt_multi_ord_fails LIKE STANDARD TABLE OF gs_multi_ord_fails.

*******************************************************************
* Data Variables
*******************************************************************

DATA : gv_ship_compl  TYPE i,
       gv_gr_post     TYPE i,
       gv_fail        TYPE i,
* Begin of CR05144
       gv_ship_attmpt TYPE i , " No. of shipments attempted
       gv_ship_create TYPE i , " No. of shipments created Hus
       gv_ship_fail   TYPE i , " No. of shipments failed Hus
       gv_ship_skip   TYPE i . " No. of shipments skipped HU

" creation
* End of CR05144
* Begin of change / nparchu / CR93478
DATA : gt_zsdomfld LIKE TABLE OF zsdomfld,
       gs_zsdomfld LIKE LINE OF gt_zsdomfld.
DATA : gv_process   TYPE i,
       gv_proc_wait TYPE i,
       gv_job       TYPE i.

DATA : BEGIN OF gt_sto OCCURS 0 ,
         ebeln TYPE ebeln,
         vbeln TYPE vbeln_vl,
       END OF gt_sto.
* End of change / nparchu / CR93478
**********************************************************************
*                         SELECTION-SCREEN                           *
**********************************************************************
SELECTION-SCREEN BEGIN OF BLOCK blk WITH FRAME TITLE TEXT-f01.
SELECT-OPTIONS: so_vbeln FOR likp-vbeln,
                so_erdat FOR likp-erdat, " S0VK900184 Sylvamo changes
                so_werks FOR likp-werks,
                so_tknum FOR zdl_ship_compl-tknum .
SELECTION-SCREEN END OF BLOCK blk.


**********************************************************************
***       TOP OF PAGE
**********************************************************************
TOP-OF-PAGE.
  PERFORM sub_print_header .


**********************************************************************
*                       START-OF-SELECTION                           *
**********************************************************************
START-OF-SELECTION.

* get the deliveries from table zdl_ship_compl
  PERFORM get_delivery.

* check whether the PO is 'TPS' Type.
  PERFORM check_ekko. " Sylvamo change

*** Start of changes by ALANKAP 6/18/2021 Sylvamo changes
* check whether the deliveries exist in likp .
  PERFORM check_likp .

* check for gr posting .
  PERFORM check_vbuk .

** check for shipment
*  PERFORM check_vttk .

** Start of change JWILL68 CD#1847 5/6/2019
*  PERFORM check_shipment_cost.
** End of change JWILL68 CD#1847 5/6/2019


* post the gr greceipt
  PERFORM gr_post.

* Begin of CR05144
* create container HU ( Handling unit ) on GR ( goods receipt )
*  PERFORM create_container_hu.
* End of CR05144
*** End of changes by ALANKAP 6/18/2021 Sylvamo changes

**********************************************************************
* END-OF-SELECTION                                                   *
**********************************************************************
END-OF-SELECTION.

* delete the entries from the database table
*  IF NOT gt_final_delete[] IS INITIAL.
* Commenting this code as this is not relevant for Sylvamo
*  IF NOT gt_final_delete IS INITIAL.
*    DELETE zdl_ship_compl FROM TABLE gt_final_delete.
*    COMMIT WORK.
*  ENDIF.

* display the report
  IF  NOT gt_final_display[] IS INITIAL .
    PERFORM display_report .
  ENDIF.

* Commented by ALANKAP for Sylvamo changes
* Begin of CR05144
*  CHECK gt_hu_create[] IS NOT INITIAL.
*  PERFORM con_hu_report.
* End of CR05144

*&-------------------------------------------------------------------*
*&      Form  sub_print_header
*&-------------------------------------------------------------------*
*       Standard Header For The Report
*--------------------------------------------------------------------*
FORM sub_print_header .
  DATA: ws_line3_left(120)   TYPE c,
        ws_line3_center(120) TYPE c.


  FORMAT INTENSIFIED ON.

  CALL FUNCTION 'Z_RPT_HEADER'
    EXPORTING
*     primary      = text-001           "del CR93478
      primary      = TEXT-056            "ins CR93478
      line3_center = ws_line3_center
      line3_left   = ws_line3_left
    TABLES
      header_lines = it_hdr
    EXCEPTIONS
      error_found  = 1
      OTHERS       = 2.
  IF  sy-subrc = 0.
    ULINE.
    SKIP 2.
    WRITE : / it_hdr-line1,
              it_hdr-line2,
             it_hdr-line3.
  ENDIF.
  FORMAT INTENSIFIED OFF.
  ULINE.


ENDFORM.                    " sub_print_header

*&-------------------------------------------------------------------*
*&      Form  get_delivery
*&-------------------------------------------------------------------*
*       get the deliveries from the table zdl_ship_compl for the
*       select options
*--------------------------------------------------------------------*
FORM get_delivery .

* Start changes by ALANKAP for Sylvamo changes 7/23
  TYPES: BEGIN OF ty_shtyp,
           sign   TYPE c LENGTH 1,
           option TYPE c LENGTH 2,
           low    TYPE shtyp,
           high   TYPE shtyp,
         END OF ty_shtyp.

    TYPES: BEGIN OF ty_vstel,
           sign   TYPE c LENGTH 1,
           option TYPE c LENGTH 2,
           low    TYPE vstel,
           high   TYPE vstel,
         END OF ty_vstel.
  DATA: gr_shtyp TYPE RANGE OF shtyp,
        gs_shtyp TYPE ty_shtyp,
        gr_vstel TYPE RANGE OF vstel.

* Start of Changes for Sylvamo S0VK900184 by ALANKAP
  SELECT * FROM  zsdomfld CLIENT SPECIFIED
        INTO TABLE gt_zsdomfld
        WHERE mandt = sy-mandt
*          AND category = 'E03593'.
    AND category = 'E03593_THIRD'. " CD # 267
  IF sy-subrc IS INITIAL.
    gr_shtyp = VALUE #( FOR ls_zsdomfld IN gt_zsdomfld WHERE ( fieldname = 'SHTYP' )
                                  ( sign   = 'I'
                                    option = 'EQ'
                                    low = ls_zsdomfld-lowval
                                    ) ).

    gr_vstel = VALUE #( FOR ls_zsdomfld IN gt_zsdomfld WHERE ( fieldname = 'VSTEL' )
                                  ( sign   = 'I'
                                    option = 'EQ'
                                    low = ls_zsdomfld-lowval
                                    ) ).
  ENDIF.

  DATA(lv_lfart) = VALUE #( gt_zsdomfld[ fieldname = 'LFART' ]-lowval OPTIONAL ).

  SELECT a~vbeln
         a~vstel
         a~vsbed
         a~wadat_ist
         a~bolnr
         a~zzbooknum
         a~zzbookdoc
         a~zz_signi
         a~zz_seal
         a~zz_shtyp
         b~vbelv
         b~vgbel
         INTO TABLE gt_likp1
         FROM likp AS a INNER JOIN lips AS b
         ON a~vbeln = b~vbeln
         WHERE a~vbeln IN so_vbeln
         AND   a~erdat IN so_erdat
         AND   a~VSTEL in gr_vstel
         AND   a~werks IN so_werks
         AND   a~lfart = lv_lfart
         AND   a~wadat_ist = '00000000'
         AND   a~vsbed NE space
         AND   a~zz_shtyp IN gr_shtyp.

  IF sy-subrc IS INITIAL.
    SORT gt_likp1 BY vbeln.
    DELETE ADJACENT DUPLICATES FROM gt_likp1 COMPARING vbeln.
    SELECT vbeln
           wbstk
           INTO TABLE gt_vbuk
           FROM vbuk
           FOR ALL ENTRIES IN gt_likp1
           WHERE vbeln = gt_likp1-vbeln
           AND   wbstk NE 'C'.
  ELSE.
    MESSAGE s264." WITH 'No entries exist in table likp'(002)
    "    'for the select options'(003) .
    STOP .
  ENDIF.

  REFRESH: gt_ship_compl.
  gt_ship_compl = VALUE #( FOR ls_likp IN gt_likp1
                              ( vbeln = ls_likp-vbeln
                                werks = ls_likp-vstel
                                zz_seal = ls_likp-zz_seal
                                zz_signi = ls_likp-zz_signi
                                vbelv = ls_likp-vbelv
                                vgbel = ls_likp-vgbel
                                ) ).

*gt_ship_compl = CORRESPONDING #( gt_likp1 MAPPING
*                                vbeln = vbeln
*                                werks = vstel
*                                zz_seal = zz_seal
*                                zz_signi = zz_signi
*                                vbelv = vbelv
*                                vgbel = vgbel
*                                ) .

* Commented by ALANKAP for Sylvamo changes 7/23
*  SELECT *
*    FROM zdl_ship_compl
*    INTO TABLE gt_ship_compl
*    WHERE vbeln IN so_vbeln AND
*          werks IN so_werks AND
*          tknum IN so_tknum .
*  IF sy-subrc <> 0 .
*    MESSAGE s000 WITH 'No entries exist in table zdl_ship_compl'(002)
*                      'for the select options'(003) .
*    STOP .
*  ENDIF.
* End changes by ALANKAP for Sylvamo changes 7/23
ENDFORM.                    " get_delivery

*&-------------------------------------------------------------------*
*&      Form  check_likp
*&-------------------------------------------------------------------*
*       check whether the entries exist in likp and delete in if not
*       available .
*--------------------------------------------------------------------*
FORM check_likp .

  DATA : lv_tabix TYPE i .

* Commented by ALANKAP for Sylvamo changes 7/23
*  SELECT vbeln
*  FROM likp
*  INTO TABLE gt_likp
*  FOR ALL ENTRIES IN gt_ship_compl
*  WHERE  vbeln = gt_ship_compl-vbeln .
*
*  IF sy-subrc <> 0 .
*    MOVE gt_ship_compl[] TO gt_final_delete[].
*    MESSAGE s000 WITH 'No enties exist in LIKP table'(004)
*                      'for the select options'(003) .
*    STOP .
*  ELSE .
  LOOP AT gt_ship_compl INTO DATA(ls_ship_compl).
    lv_tabix = sy-tabix .
* check if plant is not in database table
    IF ls_ship_compl-werks IS INITIAL .
      DELETE gt_ship_compl INDEX lv_tabix .
*      CLEAR gt_ship_compl.
      CONTINUE .
    ENDIF.

* Commented by ALANKAP for Sylvamo changes 7/23
** check if shipment is not in database table
*      IF gt_ship_compl-tknum IS INITIAL .
*        DELETE gt_ship_compl INDEX lv_tabix .
*        CLEAR gt_ship_compl.
*        CONTINUE .
*      ENDIF.

* Commented by ALANKAP for Sylvamo changes 7/23
*      READ TABLE gt_likp WITH KEY vbeln = gt_ship_compl-vbeln.
*      IF sy-subrc <> 0 .
*        MOVE gt_ship_compl TO gt_final_delete.
*        APPEND gt_final_delete .
*        DELETE gt_ship_compl INDEX lv_tabix .
*      ENDIF .
    CLEAR lv_tabix .
*    CLEAR gt_ship_compl.
  ENDLOOP .
*  ENDIF.

ENDFORM.                    " check_likp

*&-------------------------------------------------------------------*
*&      Form  check_vbuk
*&-------------------------------------------------------------------*
*       check whether the a GR has been already posted
*--------------------------------------------------------------------*
FORM check_vbuk .

  DATA : lv_tabix TYPE i .

  CLEAR gt_likp .
  REFRESH  gt_likp .

  CHECK NOT gt_ship_compl[] IS INITIAL.
  SELECT vbeln
  FROM vbuk
  INTO TABLE gt_likp
 FOR ALL ENTRIES IN gt_ship_compl
 WHERE vbeln =  gt_ship_compl-vbeln AND
       wbstk = 'C' .
  IF sy-subrc = 0 .
    LOOP AT gt_ship_compl INTO DATA(ls_ship_compl).
      lv_tabix = sy-tabix .
      READ TABLE gt_likp WITH KEY vbeln = ls_ship_compl-vbeln .
      " If it is already GR
      IF sy-subrc = 0 .
***>>> NBEHERE CR93478
        MOVE 'X' TO ls_ship_compl-gr_flag .
        MODIFY gt_ship_compl FROM ls_ship_compl INDEX lv_tabix .
***<<< NBEHERE CR93478
        MOVE ls_ship_compl TO gt_final_delete.
        APPEND gt_final_delete .
***>>> start of changes NBEHERE
*       DELETE gt_ship_compl INDEX lv_tabix . "NBEHERE CR93478
        MOVE: ls_ship_compl TO gt_final_display,
              'YES'         TO gt_final_display-gr_posted .
        APPEND gt_final_display .
***<<< end of changes NBEHERE
      ENDIF .
      CLEAR lv_tabix .
*      CLEAR gt_ship_compl.
    ENDLOOP .
  ENDIF.

  IF gt_ship_compl[] IS INITIAL .
    MESSAGE s000 WITH 'goods receipt has been posted'(005)
                      'for all the deliveries selected'(006)
                      'for the select options'(003) .
    STOP .
  ENDIF.
ENDFORM.                    " check_vbuk

*&-------------------------------------------------------------------*
*&      Form  check_vttk
*&-------------------------------------------------------------------*
*       check for shipment completion status
*--------------------------------------------------------------------*

FORM check_vttk .
  DATA : lv_tabix LIKE sy-tabix .
  DATA : ls_flag_del TYPE c.

  IF NOT gt_ship_compl[] IS INITIAL .
    SELECT tknum
           shtyp                                            "CMS#34029
           daten
    FROM vttk
    INTO TABLE gt_vttk
    FOR ALL ENTRIES IN gt_ship_compl
    WHERE tknum  =  gt_ship_compl-tknum .

    SORT gt_vttk.

    IF sy-subrc = 0 .
      LOOP AT gt_ship_compl INTO DATA(ls_ship_compl).
        lv_tabix = sy-tabix .
        READ TABLE gt_vttk
             WITH KEY tknum = ls_ship_compl-tknum
                      daten = '00000000'
                      BINARY SEARCH.
*  shipment end status not received
        IF sy-subrc = 0 .
**check if the delivery is related to Micro bridge and perform
***Shipment completion
*          CLEAR : ls_flag_del .
*          PERFORM micro_ship_complete CHANGING ls_flag_del .
*          IF ls_flag_del IS INITIAL.
          DELETE gt_ship_compl INDEX lv_tabix.
*          ENDIF.
        ENDIF.
        CLEAR lv_tabix.
*        CLEAR gt_ship_compl.
      ENDLOOP.
    ENDIF.
  ENDIF.

*  if no shipments are found to process - generate error
  IF gt_ship_compl[] IS INITIAL .
    MESSAGE s000 WITH 'No entries to be processed'(015) .
    STOP .
  ENDIF .
ENDFORM.                    " check_vttk

*&-------------------------------------------------------------------*
*&      Form  gr_post
*&-------------------------------------------------------------------*
*       post the gr for the entries in table gt_ship_compl. raise an
*       AHD ticket in case of an error
*--------------------------------------------------------------------*
FORM gr_post .
  DATA : ls_vbkok LIKE vbkok,
         lv_error TYPE xfeld,
         lv_text5 TYPE char50,
         lv_text6 TYPE char50,
         lv_text1 TYPE char50,
         lv_text2 TYPE char50,
         lv_text3 TYPE char50,
         lv_text4 TYPE char50.
  DATA: lv_success   TYPE c,
        lv_userid(9) TYPE c.

  CHECK NOT gt_ship_compl[] IS INITIAL.
  DESCRIBE TABLE gt_ship_compl LINES gv_ship_compl .

*  IF NOT gt_ship_compl[] IS INITIAL .
* begin of changes / nparchu / CR93478
  PERFORM get_details.
* end of change / nparchu / CR93478
  LOOP AT gt_ship_compl INTO DATA(ls_ship_compl) WHERE gr_flag = space.

* Start modification by ALANKAP for Sylvamo
    IF NOT line_exists( gt_ekko[ ebeln = ls_ship_compl-vgbel ] ).
      CONTINUE.
    ENDIF.
    IF  NOT line_exists( gt_vbuk[ vbeln = ls_ship_compl-vbeln ] ).
      CONTINUE.
    ENDIF.
* End modification by ALANKAP for Sylvamo

    ls_vbkok-vbeln_vl = ls_ship_compl-vbeln .
    ls_vbkok-wabuc    = 'X'  .
*Need to refresh HU reason being if one delivery fail to GR all
*subsequent deliveries fail.
*  Solution recommended by sap .
    CALL FUNCTION 'HU_PACKING_REFRESH' .
    CALL FUNCTION 'SERIAL_INTTAB_REFRESH'
      EXPORTING
        objects_status_refresh = 'C '.
*   End OSS solution
    CLEAR : lv_error .
* begin of change / nparchu /  CR93478
    CLEAR: lv_success, lv_userid .
** check if the STO can be locked.
    PERFORM check_lock_sto USING ls_ship_compl-vbeln
                           CHANGING lv_success lv_userid.

    IF lv_success = 'X' .  "Locking STO was successfull
** the SYNCHRON flag was checked in the function module below
** this will update the tables immediately rather than in update task
* end of change / nparchu / CR93478
      CALL FUNCTION 'WS_DELIVERY_UPDATE'
        EXPORTING
          vbkok_wa       = ls_vbkok
          commit         = 'X'
          delivery       = ls_ship_compl-vbeln
        IMPORTING
          ef_error_any_0 = lv_error.
    ELSE.
      lv_error = 'X' .
    ENDIF.

    IF lv_error = 'X' .
* begin of change / nparchu /  CR93478
      ls_ship_compl-job_count = ls_ship_compl-job_count + 1.
* end of change / nparchu /  CR93478
      gv_fail = gv_fail + 1 .
      MOVE ls_ship_compl TO gt_final_display .
      gt_final_display-gr_posted = 'NO' .
      APPEND gt_final_display .
      IF ls_ship_compl-usdflag <> 'S'.
        CLEAR : lv_text1 , lv_text2 ,
                lv_text3 , lv_text4 ,lv_text5 .


        lv_text1 =
           'Goods receipt was not posted for IB delivery.'(033).
        IF lv_success IS INITIAL .
          CONCATENATE ls_ship_compl-vbeln
                      'STO was locked by userID'(034) lv_userid
                      INTO lv_text2 SEPARATED BY space.
        ELSE.
          CONCATENATE ls_ship_compl-vbeln '.' INTO lv_text2 .
*            lv_text2 =  gt_ship_compl-vbeln.
        ENDIF.
        lv_text3 = TEXT-052 .     "ins CR93478
***>>> Del CR93478
*   lv_text3 = 'Please disregard the initial statement'(035).
*   lv_text4 = 'Idoc not created'(036) .
*   lv_text5 = 'included in this USD ticket, as IDocs are'(037).
*   lv_text6 = 'not used by Export AutoPGR processes.'(038).
***<<< Del CR93478

* begin of change / nparchu /  CR93478
        IF ls_ship_compl-job_count GE gv_job.
* end of change / nparchu /  CR93478

          CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
            EXPORTING
              inventory_code         = 'E3593'
              text_1                 = lv_text1
              text_2                 = lv_text2
              text_3                 = lv_text3
              text_4                 = lv_text4
              text_5                 = lv_text5
              text_6                 = lv_text6
            EXCEPTIONS
              invalid_inv_code       = 1
              ahdgrp_not_found       = 2
              invalid_idoc_number    = 3
              webmd_connection_error = 4
              OTHERS                 = 5.
          IF sy-subrc = 0.
            ls_ship_compl-usdflag = 'S'.
*              UPDATE zdl_ship_compl FROM gt_ship_compl.
          ELSEIF ls_ship_compl-usdflag IS INITIAL.
            ls_ship_compl-usdflag = 'F'.
*              UPDATE zdl_ship_compl FROM gt_ship_compl.
          ENDIF.
* Begin of change / nparchu / CR93478
        ELSE.
*            UPDATE zdl_ship_compl FROM gt_ship_compl.
        ENDIF.
* End of change / nparchu / CR93478
      ENDIF.
    ELSE .
      gv_gr_post = gv_gr_post + 1 .
      MOVE ls_ship_compl TO gt_final_display .
      gt_final_display-gr_posted = 'YES' .
      APPEND gt_final_display .

      MOVE ls_ship_compl TO gt_final_delete.
      APPEND gt_final_delete .
    ENDIF.
    CLEAR ls_vbkok .
    CLEAR lv_error .
    CLEAR gt_final_display .
*      CLEAR gt_ship_compl.
  ENDLOOP .
*  ENDIF.

ENDFORM.                    " gr_post

*&-------------------------------------------------------------------*
*&      Form  display_report
*&-------------------------------------------------------------------*
*       display the report
*--------------------------------------------------------------------*
FORM display_report .
  SKIP .
  ULINE /2(105).
  WRITE : /2  sy-vline NO-GAP .
  FORMAT COLOR COL_HEADING ON INTENSIFIED OFF.
  WRITE : 106  sy-vline NO-GAP .
  WRITE : 35 'Inbound Delivery GR Report'(026).
  FORMAT COLOR OFF.

  ULINE /2(105).
  WRITE : /2  sy-vline NO-GAP .
  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
  WRITE : 106  sy-vline NO-GAP .
  WRITE : 3 'Number of Inbound deliveries attempted :'(008),
             gv_ship_compl.
  FORMAT COLOR OFF.

  ULINE /2(105).
  WRITE : /2  sy-vline NO-GAP .
  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
  WRITE : 106  sy-vline NO-GAP .
  WRITE : 3 'Number of Inbound deliveries Posted GR :'(009) ,
             gv_gr_post.
  WRITE 80 icon_green_light AS ICON  .
  FORMAT COLOR OFF.

  ULINE /2(105).
  WRITE : /2  sy-vline NO-GAP .
  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
  WRITE : 106  sy-vline NO-GAP .
  WRITE : 3 'Number of Inbound deliveries Failed GR :'(010) ,
             gv_fail .
  WRITE 80 icon_red_light AS ICON.
  FORMAT COLOR OFF.

  ULINE /2(105).

  WRITE : /2  sy-vline NO-GAP .
  FORMAT COLOR COL_HEADING ON INTENSIFIED OFF.
  WRITE : 106  sy-vline NO-GAP .

  WRITE : 11  'Delivery'(011)  ,
          30  sy-vline         ,
          35  'Shipment'(012)  ,
          49  sy-vline         ,
          53  'Plant'(013)     ,
          63  sy-vline         ,
          71  'GR Posted'(014) .
  FORMAT COLOR OFF.

  ULINE /2(105).

  LOOP AT gt_final_display.
    WRITE: /2 sy-vline NO-GAP.
    FORMAT COLOR COL_NORMAL INTENSIFIED OFF.
    WRITE: 10 gt_final_display-vbeln     ,
           30 sy-vline                   ,
           37 gt_final_display-tknum     ,
           49 sy-vline                   ,
           53 gt_final_display-werks     ,
           63 sy-vline                   ,
           75 gt_final_display-gr_posted ,
           106 sy-vline                   .
    FORMAT RESET.
    ULINE /2(105)   .
  ENDLOOP .

ENDFORM.                    " display_report

*  Code to check and update Microbridge ship complete is removed by
*  CRAMEY 7/13/2010 per CR 9555.
**&------------------------------------------------------------------*
**&      Form  micro_ship_complete
**&------------------------------------------------------------------*
**-------------------------------------------------------------------*
*FORM micro_ship_complete CHANGING ls_flag_del .
*
*  DATA : ls_vgbel TYPE vgbel ,
*         ls_vgpos TYPE vgpos ,
*         ls_vbeln TYPE vbeln_co ,
*         ls_vbelp TYPE posnr_co,
*         ls_bookdoc TYPE zsd_book_bookdoc ,
*         ls_micro_flag TYPE zsd_book_microbrg,
*         lt_zdlship_tknum TYPE tknum,
*         lv_error TYPE c.
*
*  DATA: lt_logfile LIKE sprot_u OCCURS 0.
*  CONSTANTS:  gc_sttrg_7 TYPE vttk-sttrg VALUE '7'.
*
*
*  CLEAR : ls_vgbel, ls_vgpos , ls_micro_flag , ls_flag_del .
*
*
** Select the Po Number and Item for the inbound delivery from LIPS
*  SELECT SINGLE vgbel vgpos FROM lips INTO (ls_vgbel,ls_vgpos)
*                               WHERE vbeln = gt_ship_compl-vbeln.
**
*  IF sy-subrc = 0.
*    CLEAR : ls_vbeln , ls_vbelp .
** Select the Sales Order and Item from account assignment table EKKN
*    SELECT SINGLE vbeln vbelp FROM ekkn INTO (ls_vbeln, ls_vbelp)
*                    WHERE ebeln = ls_vgbel
*                      AND ebelp = ls_vgpos.
**If there is no account assignment then get the sales order and item
**from EKKO
*    IF sy-subrc <> 0.
*      SELECT SINGLE zzvbeln zzposnr
*         FROM ekko INTO (ls_vbeln, ls_vbelp)
*        WHERE ebeln = ls_vgbel .
*    ENDIF.
** If there is sales order then get the booking document number
*    IF NOT ls_vgbel IS INITIAL.
*      CLEAR : ls_bookdoc .
*      SELECT  SINGLE bookdoc FROM zsd_book_itm INTO ls_bookdoc
*                          WHERE vbeln =  ls_vbeln
*                          AND posnr =  ls_vbelp.
** If there is a booking document get the micro bridge flag
*      IF sy-subrc = 0.
*        SELECT SINGLE microbrg FROM zsd_book_hdr INTO ls_micro_flag
*              WHERE bookdoc = ls_bookdoc .
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
**If there is a micro bridge flag set then attempt posting shipment
**completion
*  IF NOT ls_micro_flag IS INITIAL.
*    CLEAR : lt_zdlship_tknum .
*    lt_zdlship_tknum = gt_ship_compl-tknum.
** Set shipment status to shipment complete
*    CALL FUNCTION 'SD_SHIPMENT_STATUS_SET'
*      EXPORTING
*        i_tknum                 = lt_zdlship_tknum
*        i_status                = gc_sttrg_7
*        opt_dialog              = ' '
*      TABLES
*        c_logfile               = lt_logfile
*      CHANGING
*        c_error_warning_occured = lv_error
*      EXCEPTIONS
*        status_not_set          = 1
*        OTHERS                  = 2.
*    IF sy-subrc = 0.
*      COMMIT WORK.
*      ls_flag_del = 'X' .
** Need to adjust table gt_vttk so it is marked shipment complete.
*      DELETE gt_vttk WHERE tknum = lt_zdlship_tknum .
*    ENDIF.
*  ENDIF.
*ENDFORM.                    " micro_ship_complete
*&-------------------------------------------------------------------*
*&      Form  create_container_hu
*&-------------------------------------------------------------------*
*       Create Container HU. On failure, generate USD ticket.
*--------------------------------------------------------------------*
*FORM create_container_hu .

*  CONSTANTS: lc_e3593 TYPE zzinv VALUE 'E3593'.
*
*  DATA: BEGIN OF lt_vttk OCCURS 0,
*          tknum       TYPE tknum,
*          signi       TYPE signi,
*          text1       TYPE vttk_text1,
*          del_flag(1) TYPE c,                               "CR93478
*          seal        TYPE zdl_seal_no,                     "CR93478
*        END OF lt_vttk,
*
** Temporary table to hold inbound deliveries
*        BEGIN OF lt_del_in OCCURS 0,
*          vbeln   TYPE vbeln_vl,
*          vbeln_i TYPE vbeln_vl,
*        END OF lt_del_in,
*
** Temporary table to hold purchase order nos.
*        BEGIN OF lt_pur_ord OCCURS 0,
*          belnr TYPE mblnr,
*          ebeln TYPE ebeln,
*        END OF lt_pur_ord,
*
** Temporary table to hold Sales order nos. from EKKO ( MTS )
*        BEGIN OF lt_sord_mts OCCURS 0,
*          ebeln   TYPE ebeln,
*          zzvbeln TYPE zsde3483_vbeln,
*          zzposnr TYPE zsde3483_posnr,
*        END OF lt_sord_mts,
*
** Temporary table to hold Sales order nos. from EKKO ( MTO )
*        BEGIN OF lt_sord_mto OCCURS 0,
*          ebeln TYPE ebeln,
*          vbeln TYPE vbeln_co,
*          vbelp TYPE posnr_co,
*        END OF lt_sord_mto,
*
** Temporary table to hold ZSD_BOOK_ITM entries
*        BEGIN OF lt_book_itm OCCURS 0,
*          bookdoc TYPE zsd_book_bookdoc,
*          vbeln   TYPE zsd_book_vbeln,
*          posnr   TYPE zsd_book_posnr,
*        END OF lt_book_itm,
*
** Temporary table to hold ZSD_BOOK_HDR entries
*        BEGIN OF lt_book_hdr OCCURS 0,
*          bookdoc TYPE zsd_book_bookdoc,
*          booknum TYPE zsd_book_booknum,
*        END OF lt_book_hdr,
*
** Temporary table to hold GR status
*        BEGIN OF lt_gr_status OCCURS 0,
*          vbeln TYPE vbeln_vl,
*          wbstk TYPE wbstk,
*        END OF lt_gr_status,
** Temporary table to hold outbound deliveries
**        BEGIN OF lt_del_out OCCURS 0,
**          tknum  TYPE tknum,
*** CMR 9/10 - Change data type due to change in field size per 6.0 upgr
**         vbeln   TYPE bbxbl,
**          vbeln  TYPE xblnr_long,
**          vbeln1 TYPE vbeln_vl,
**        END OF lt_del_out,
*
** Temporary table to hold outbound deliveries
*        BEGIN OF lt_del_out_tmp OCCURS 0,
*          tknum  TYPE tknum,
**          vbeln TYPE vbeln,    " CMS#34029
*          vbeln  TYPE xblnr1,   " CMS#34029
*          vbeln1 TYPE vbeln_vl, " CMS#34029
*        END OF lt_del_out_tmp.
*
*  DATA ls_container_size TYPE ty_container_size.
*
*  TYPES: BEGIN OF ty_del_out,
*           vbeln TYPE vbeln_vl,
*         END OF ty_del_out.
*  DATA: lt_del_out TYPE TABLE OF ty_del_out.
*
*  TYPES:BEGIN OF ty_bookdoc,
*          vbeln     TYPE vbeln_vl,
*          zzbookdoc TYPE z_bookdoc,
*        END OF ty_bookdoc.
*
*  DATA lt_bookdoc TYPE STANDARD TABLE OF ty_bookdoc.
*
*  DATA: lv_tabix           LIKE sy-tabix,
*        lt_hus_to_pack     TYPE zdl_exidv_tab,
*        ls_hus_to_pack     TYPE zdl_exidv,
*        lt_return          TYPE STANDARD TABLE OF bapiret2,
*        ls_return          TYPE bapiret2,
*        lt_deliv           TYPE STANDARD TABLE OF ship_deliv,
*        ls_deliv           TYPE ship_deliv,
*        lv_text_1          TYPE char50,
*        lv_hu_flag         TYPE c,
*        lv_book_num        TYPE zsd_book_booknum,
*        lv_book_doc        TYPE zsd_book_bookdoc,           "CMS28321
*        lv_container_venum TYPE venum , "container HU created int
*        lv_sord            TYPE  vbeln_co.
*
****>>> start of changes NBEHERE CR93478
*  DATA: lv_ctext           TYPE char50 .
*  DATA: lv_vbeln      TYPE vbeln_vl,
*        ls_fields     LIKE zsdomfld,
*        lv_text_2     TYPE char50,
*        lv_text_3     TYPE char50,
*        lv_text_4     TYPE char50,
*        lv_text_5     TYPE char50,
*        lv_text_6     TYPE char50,
*        lv_reassigned TYPE c.
*  RANGES: rg_shtyp FOR vttk-shtyp .
****<<< end of changes NBEHERE CR93478
** >> Begin insert by pwadehr - CMS#34029
*  DATA:lt_rf_shiptypes  TYPE RANGE OF shtyp.
*
*  SELECT   'I'    AS sign ,
*           'EQ'   AS option,
*           lowval AS low,
*           '  '   AS high
*                  FROM zsdomfld
*                  INTO TABLE @lt_rf_shiptypes
*                  WHERE category   = 'E03593_DLK'
*                  AND   fieldname  = 'SHTYP'.
** >> End insert by pwadehr - CMS#34029
*
**// Clear all the variables
*  CLEAR: gt_hu_create[]  , gt_gr_status[]  , lt_vttk[]     ,
*         lt_del_out[]    , lt_del_out_tmp[], lt_del_in[]   ,
*         lt_pur_ord[]    , lt_sord_mts[]   , lt_sord_mto[] ,
*         lt_book_itm[]   , lt_book_hdr[]   , lt_gr_status[],
*         lt_hus_to_pack[],lt_return[]      , lt_deliv[]    ,
*         ls_hus_to_pack  , ls_deliv        , lv_tabix      ,
*         lv_text_1.
*  lv_ctext = TEXT-054 . "'HU creation failed for shipment'(054),
**  CHECK gt_final_display[] IS NOT INITIAL. "del NBEHERE CR93478
*  IF gt_final_display[] IS NOT INITIAL .    "add NBEHERE CR93478
** Commit so that LUW is complete and database tables are updated
**    WAIT UP TO 5 SECONDS.   "del NBEHERE CR93478 moved down below
****>>> start of changes NBEHERE CR93478
*** get the Shipment type from ZSDOMFLD
*    LOOP AT gt_zsdomfld INTO ls_fields
*               WHERE category = 'E03593' AND
*               fieldname = 'SHTYP' .
*      CLEAR rg_shtyp .
*      MOVE: ls_fields-sign    TO rg_shtyp-sign,
*            ls_fields-optn    TO rg_shtyp-option,
*            ls_fields-lowval  TO rg_shtyp-low,
*            ls_fields-highval TO rg_shtyp-high .
*      APPEND rg_shtyp.
*    ENDLOOP .
*    IF sy-subrc NE 0 OR rg_shtyp IS INITIAL .
*      MOVE: 'I'               TO rg_shtyp-sign,
*            'EQ'              TO rg_shtyp-option,
*            'ZINP'            TO rg_shtyp-low.
*      APPEND rg_shtyp .
*    ENDIF.
*** if all deliveries have been processed then the display table
*** will be blank. We need to populate it with the ones which are
*** reprcessing
**  ENDIF.
****<<< end of changes NBEHERE / CR93478
*
** Commented by ALANKAP for Sylvamo changes 7/23
***// Get the shipment type data from vttk
**    SELECT tknum signi text1
**      INTO TABLE lt_vttk
**      FROM vttk
**      FOR ALL ENTRIES IN gt_final_display
**      WHERE tknum = gt_final_display-tknum
***    AND   shtyp = 'ZINP'.  "del CR93478
**       AND shtyp IN rg_shtyp . "ins CR93478
*
**// Build the gt_hu_create table
*    LOOP AT gt_final_display.
*      CLEAR gt_hu_create.
** if GR is posted select the entry
*      CHECK gt_final_display-gr_posted = 'YES'.
**      gt_hu_create-tknum = gt_final_display-tknum.
*      gt_hu_create-vbeln = gt_final_display-vbeln. " Sylvamo change
*      gt_hu_create-werks = gt_final_display-werks.
** if shtyp is 'ZINP' select the entry
*      READ TABLE gt_likp1 WITH KEY vbeln = gt_final_display-vbeln. " Sylvamo change
**      READ TABLE lt_vttk WITH KEY tknum = gt_final_display-tknum.
*      CHECK sy-subrc = 0.
*      APPEND gt_hu_create.
*    ENDLOOP.
*
**// Check if there any entries in gt_hu_create to proceed further
*    CHECK gt_hu_create[] IS NOT INITIAL.
****>>> added wait here rather than up above NBEHERE CR93478
**// Wait for the Commit work to update tables
*    WAIT UP TO gv_proc_wait SECONDS .
****<<< end of addition NBEHERE CR93478
**// Sort
**    SORT gt_hu_create BY tknum.
*    SORT gt_hu_create BY vbeln. " Sylvamo change
**// Delete duplicates comparing shipment number
**    DELETE ADJACENT DUPLICATES FROM gt_hu_create
**      COMPARING tknum.
*    DELETE ADJACENT DUPLICATES FROM gt_hu_create
*  COMPARING vbeln.
**// Delete shipments with no goods receipt for any inbound del.
*    LOOP AT gt_hu_create.
*      CLEAR lv_tabix .
*      lv_tabix = sy-tabix.
**      READ TABLE gt_final_display WITH KEY
**                              tknum     = gt_hu_create-tknum
**                              gr_posted = 'NO'.
*      READ TABLE gt_final_display WITH KEY
*                        vbeln     = gt_hu_create-vbeln
*                        gr_posted = 'NO'. " Sylvamo change
*      CHECK sy-subrc = 0.
*      DELETE gt_hu_create INDEX lv_tabix.
*    ENDLOOP.
*
**// Check if there any entries in gt_hu_create to proceed further
*    CHECK gt_hu_create[] IS NOT INITIAL.
*
** Commented by ALANKAP for Sylvamo changes 7/23
***// Get the outbound deliveries from shipment item table
**    SELECT tknum vbeln
**      INTO TABLE lt_del_out
**      FROM vttp
**      FOR ALL ENTRIES IN gt_hu_create
**      WHERE tknum = gt_hu_create-tknum.
**
*
*    lt_del_out = VALUE #( FOR ls_ship_compl IN gt_ship_compl
*                                  ( vbeln = ls_ship_compl-vbeln ) ).
*
**    IF sy-subrc = 0.
***Begin of insert "CMS#34029
**      LOOP AT lt_del_out ASSIGNING FIELD-SYMBOL(<line1>).
**        <line1>-vbeln1 = <line1>-vbeln.
**      ENDLOOP.
**
**      READ TABLE gt_vttk INTO DATA(ls_vttk)
**         WITH KEY tknum = gt_hu_create-tknum BINARY SEARCH.
**      IF sy-subrc EQ 0.
**        IF ls_vttk-shtyp NOT IN lt_rf_shiptypes.
***End of insert "CMS#34029
***// Get all the corresponding inbound deliveries for outbound
*** deliveries
**
**          SELECT xblnr vbeln
**            INTO TABLE lt_del_in
**            FROM ekes
**            FOR ALL ENTRIES IN lt_del_out
**            WHERE xblnr = lt_del_out-vbeln.
**
***// Get the purchase order no. using outbound delivery
*** Build the outbound delivery table compatible for
*** for the select statement to get purchase orders
**          lt_del_out_tmp[] = lt_del_out[].
*** Get the purchase order nos.
**          SELECT belnr ebeln
**            INTO TABLE lt_pur_ord
**            FROM ekbe
**            FOR ALL ENTRIES IN lt_del_out_tmp
***            WHERE belnr = lt_del_out_tmp-vbeln "CMS#34029
**            WHERE belnr = lt_del_out_tmp-vbeln1             "CMS#34029
**            AND vgabe = '8'.
***Begin of insert "CMS#34029
**        ELSE.
***// Get all the corresponding inbound deliveries for outbound
*** deliveries
**
**          SELECT xblnr vbeln
**            INTO TABLE lt_del_in
**            FROM ekes
**            FOR ALL ENTRIES IN lt_del_out
**            WHERE vbeln = lt_del_out-vbeln1.
**
**          IF sy-subrc = 0.
**            LOOP AT lt_del_in ASSIGNING FIELD-SYMBOL(<line2>).
**              <line2>-vbeln = <line2>-vbeln_i.
**            ENDLOOP.
**          ENDIF.
**
***// Get the purchase order no. using outbound delivery
*** Build the outbound delivery table compatible for
*** for the select statement to get purchase orders
**          lt_del_out_tmp[] = lt_del_out[].
*** Get the purchase order nos.
**          SELECT belnr ebeln
**            INTO TABLE lt_pur_ord
**            FROM ekbe
**            FOR ALL ENTRIES IN lt_del_out_tmp
**            WHERE xblnr = lt_del_out_tmp-vbeln
**            AND vgabe = '1'.
**        ENDIF.
**      ENDIF.
**      IF lt_pur_ord[] IS NOT INITIAL.
***      IF sy-subrc = 0.
***End of insert "CMS#34029
***// Get the Sales order no. from EKKO (MTS)
**        SELECT ebeln zzvbeln zzposnr
**          INTO TABLE lt_sord_mts
**          FROM ekko
**          FOR ALL ENTRIES IN lt_pur_ord
**          WHERE ebeln = lt_pur_ord-ebeln AND
**                zzvbeln <> space.
***CMS: 28321| Changed By: AMAOLE1| Changed On: 10/06/15| START5
*** - Comment logic to pick 'Bookdoc' for MTS orders from the sales order line
***        IF sy-subrc = 0.
****// Get booking document information
***          SELECT bookdoc vbeln posnr
***            INTO TABLE lt_book_itm
***            FROM zsd_book_itm
***            FOR ALL ENTRIES IN lt_sord_mts
***            WHERE vbeln = lt_sord_mts-zzvbeln
***            AND   posnr = lt_sord_mts-zzposnr.
***        ENDIF.
***CMS: 28321| Changed By: AMAOLE1| Changed On: 10/06/15| END5
**
***// Get the Sales order no. from EKKN (MTO)
**        SELECT ebeln vbeln vbelp
**          INTO TABLE lt_sord_mto
**          FROM ekkn
**          FOR ALL ENTRIES IN lt_pur_ord
**          WHERE ebeln = lt_pur_ord-ebeln.
**
***CMS: 28321| Changed By: AMAOLE1| Changed On: 10/06/15| START6
*** - Comment logic to pick 'Bookdoc' for MTOs from the sales order line
*** - Add logic to pick 'Bookdoc' from STO delivery header
***        IF sy-subrc = 0.
****// Get booking document information
***          SELECT bookdoc vbeln posnr
***            APPENDING TABLE lt_book_itm
***            FROM zsd_book_itm
***            FOR ALL ENTRIES IN lt_sord_mto
***            WHERE vbeln = lt_sord_mto-vbeln
***            AND   posnr = lt_sord_mto-vbelp.
***        ENDIF.
***
***        IF lt_book_itm[] IS NOT INITIAL.
****//Get the booking document nos.
***          SELECT bookdoc booknum
***            INTO TABLE lt_book_hdr
***            FROM zsd_book_hdr
***            FOR ALL ENTRIES IN lt_book_itm
***            WHERE  bookdoc = lt_book_itm-bookdoc.
***        ENDIF.
**
**      ENDIF.
**
**      IF lt_del_out[] IS NOT INITIAL.
**
**        LOOP AT lt_del_out ASSIGNING FIELD-SYMBOL(<line>).
**          <line>-vbeln1 = <line>-vbeln.
**        ENDLOOP.
**
**        SELECT vbeln zzbookdoc FROM likp INTO TABLE lt_bookdoc
**          FOR ALL ENTRIES IN lt_del_out
**          WHERE vbeln = lt_del_out-vbeln1.
**
**        SORT lt_bookdoc BY vbeln.
**
**      ENDIF.
**
***//Get the booking document nos.
**      IF lt_bookdoc[] IS NOT INITIAL.
**
**        SELECT bookdoc booknum
**          INTO TABLE lt_book_hdr
**          FROM zsd_book_hdr
**          FOR ALL ENTRIES IN lt_bookdoc
**          WHERE  bookdoc = lt_bookdoc-zzbookdoc.
**
**        SORT lt_book_hdr BY bookdoc.
**      ENDIF.
**
***CMS: 28321| Changed By: AMAOLE1| Changed On: 10/06/15| END6
**
**
***// Get the GR Status information from VBUK
*    SELECT vbeln wbstk
*      INTO TABLE lt_gr_status
*      FROM vbuk
*      FOR ALL ENTRIES IN lt_del_out
*      WHERE vbeln = lt_del_out-vbeln.
**
**    ENDIF.
*
**// Build the gt_gr_status table with shipment number,
** outbound deliveries, inbound deliveries, GR status,
** purchase order info., Sales Order Number,
** Booking confirmation number, Container ID and Seal number
*    LOOP AT lt_del_out INTO DATA(ls_del_out).
*      CLEAR gt_gr_status.
** Get shipment number & outbound deliveries
**      gt_gr_status-tknum = lt_del_out-tknum.
*      gt_gr_status-vbeln_i = ls_del_out-vbeln.
*
** Get inbound delivery info
**      READ TABLE lt_del_in
**           WITH KEY vbeln = lt_del_out-vbeln.
**      IF sy-subrc = 0.
**        gt_gr_status-vbeln_i = lt_del_in-vbeln_i.
** Get the GR status information
*      READ TABLE lt_gr_status
*           WITH KEY vbeln = ls_del_out-vbeln.
*      IF sy-subrc = 0.
*        gt_gr_status-wbstk = lt_gr_status-wbstk.
*      ENDIF.
*
**      ENDIF.
*
** Get the PO and SO info Added for Sylvamo 7/26/2021
**      DATA(ls_lips) = VALUE #( gt_lips[ vbeln = ls_del_out-vbeln ] OPTIONAL ).
**      IF NOT ls_lips IS INITIAL.
**        gt_gr_status-sord_no = ls_lips-vbelv.
**        gt_gr_status-ebeln = VALUE #( gt_ekko[ ebeln = ls_lips-vgbel ]-ebeln OPTIONAL ).
**      ENDIF.
*
** Get the Container ID and SEAL numbers
*      DATA(ls_likp) = VALUE #( gt_likp1[ vbeln = ls_del_out-vbeln ] OPTIONAL ).
*      IF NOT ls_likp IS INITIAL.
*        gt_gr_status-sord_no = ls_likp-vbelv.
*        gt_gr_status-signi = ls_likp-zz_signi.
*        gt_gr_status-text1 = ls_likp-zz_seal.
*        gt_gr_status-booknum = ls_likp-zzbooknum.
*        gt_gr_status-bookdoc = ls_likp-zzbookdoc.
*        gt_gr_status-ebeln = VALUE #( gt_ekko[ ebeln = ls_likp-vgbel ]-ebeln OPTIONAL ).
*      ENDIF.
** Commented out by ALANKAP for Sylvamo changesw
*** Get purchase order info.
**      READ TABLE lt_pur_ord
**           WITH KEY belnr = lt_del_out-vbeln.
**      IF sy-subrc = 0.
**        gt_gr_status-ebeln = lt_pur_ord-ebeln.
*** Get Sales Order Number
**        READ TABLE lt_sord_mts
**             WITH KEY ebeln = lt_pur_ord-ebeln.
**        IF sy-subrc = 0 . "MTS
**          gt_gr_status-sord_no = lt_sord_mts-zzvbeln.
**
***CMS: 28321| Changed By: AMAOLE1| Changed On: 10/06/15| START7
*** - Read table LT_BOOKDOC instead of LT_BOOK_ITM to get 'Bookdoc'
**** Get Booking confirmation number
***          READ TABLE lt_book_itm
***               WITH KEY vbeln = lt_sord_mts-zzvbeln
***                        posnr = lt_sord_mts-zzposnr.
***          IF sy-subrc = 0.
**** Get Booking confirmation number
***            READ TABLE lt_book_hdr
***                 WITH KEY bookdoc = lt_book_itm-bookdoc.
***            IF sy-subrc = 0.
***              gt_gr_status-booknum = lt_book_hdr-booknum.
***            ENDIF.
***          ENDIF.
**        ELSE.                                         "MTO
**          READ TABLE lt_sord_mto
**               WITH KEY ebeln = lt_pur_ord-ebeln.
**          IF sy-subrc = 0.
*** Get Sales Order Number
**            gt_gr_status-sord_no = lt_sord_mto-vbeln.
**** Get Booking confirmation number
***            READ TABLE lt_book_itm
***                 WITH KEY vbeln = lt_sord_mto-vbeln
***                          posnr = lt_sord_mto-vbelp.
***            IF sy-subrc = 0.
**** Get Booking confirmation number
***              READ TABLE lt_book_hdr
***                   WITH KEY bookdoc = lt_book_itm-bookdoc.
***              IF sy-subrc = 0.
***                gt_gr_status-booknum = lt_book_hdr-booknum.
***              ENDIF.
***            ENDIF.
**          ENDIF.
**        ENDIF.
**      ENDIF.
*
** Commented by ALANKAP 7/26/2021
*** Get Booking confirmation number
**      READ TABLE lt_bookdoc INTO DATA(ls_bookdoc)
**          WITH KEY vbeln = ls_del_out-vbeln BINARY SEARCH.
**      IF sy-subrc EQ 0.
**
**        READ TABLE lt_book_hdr
**             WITH KEY bookdoc = ls_bookdoc-zzbookdoc BINARY SEARCH.
**        IF sy-subrc = 0.
**          gt_gr_status-booknum = lt_book_hdr-booknum.
**          gt_gr_status-bookdoc = ls_bookdoc-zzbookdoc. "MAIELY/28321
**        ENDIF.
**      ENDIF.
**CMS: 28321| Changed By: AMAOLE1| Changed On: 10/06/15| END7
*
** Commented by ALANKAP for Sylvamo changes 7/23
*** Get Container ID and Seal number
**      READ TABLE lt_vttk
**           WITH KEY tknum = lt_del_out-tknum.
**      IF sy-subrc = 0.
**        gt_gr_status-signi = lt_vttk-signi.
**        gt_gr_status-text1 = lt_vttk-text1.
**      ENDIF.
*
*      APPEND gt_gr_status.
*    ENDLOOP.
*
*
**// Sort by Shipment/Delivery
*    SORT gt_gr_status BY vbeln_i.
*    SORT gt_likp1 BY vbeln.
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| START1
*
** Validation for multi orders
**  - Check if all orders have the same "Sold-to" (Message Code S1)
**  - Check if all orders have the same "Ship-to" (Message Code S2)
**  - Check if all orders have the same "Metric Indicators" (Message Code S3)
*    PERFORM multi_orders_check TABLES gt_gr_status.
*
** Get Container Size
*    PERFORM get_container_size.
*
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| END1
*
**// clear counters
*    CLEAR: gv_ship_attmpt, gv_ship_create,
*           gv_ship_fail  , gv_ship_skip  .
**// Attempt to Create Container HU. On fail raise AHD
** ticket
*    LOOP AT gt_gr_status.
*      CLEAR gs_gr_status.
*      gs_gr_status = gt_gr_status.
*      MOVE: gt_gr_status-vbeln_i TO lv_vbeln.               "CR93478
*
** Clear the variables for each new shipment
**      AT NEW tknum.
*      AT NEW vbeln_i. " Sylvamo Change
*        CLEAR: lv_hu_flag, lt_deliv[], lt_hus_to_pack[], lv_book_num,
*        lv_sord .
*        gv_ship_attmpt = gv_ship_attmpt + 1.
*        lv_book_num = gs_gr_status-booknum .
*        lv_book_doc = gs_gr_status-bookdoc .                "CMS28321
*        lv_sord  = gs_gr_status-sord_no .
*      ENDAT.
*
**// proceed if Shipment status is complete for inbound deliveries of
**   the shipment, otherwise go to next shipment
*      CHECK lv_hu_flag IS INITIAL.
*
*      CLEAR gt_hu_create.
*      READ TABLE gt_hu_create
*           WITH KEY vbeln = gt_gr_status-vbeln_i.
*      CHECK sy-subrc = 0.
** If ship STATUS is not 'C' update gt_hu_create table and go to
** next shipment. Set the lv_hu_flag so that this shipment is skipped.
**      IF gt_gr_status-wbstk <> 'C'.                                           "CMS#34029
**      READ TABLE gt_vttk INTO ls_vttk                       "CMS#34029
**         WITH KEY tknum = gt_gr_status-tknum BINARY SEARCH. "CMS#34029
*      READ TABLE gt_likp1 "INTO ls_likp
*        WITH KEY vbeln = gt_gr_status-vbeln_i BINARY SEARCH.
*      IF sy-subrc EQ 0.                                     "CMS#34029
*        IF gt_gr_status-wbstk <> 'C' AND gt_likp1-zz_shtyp NOT IN lt_rf_shiptypes. "CMS#34029
****>>> start of changes NBEHERE / CR93478
*          PERFORM check_dlvry_status .
****<<< end of changes NBEHERE / CR93478
*          gt_hu_create-mess_type = 'X'.
*          MODIFY gt_hu_create
*            FROM gt_hu_create
*            TRANSPORTING mess_type
*            WHERE vbeln = gt_gr_status-vbeln_i.
*          lv_hu_flag = 'X'.
*          gv_ship_skip = gv_ship_skip + 1.
*          CONTINUE.
*        ENDIF.
*      ENDIF.                                                "CMS#34029
*
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| START2
*** EDVK964849 TPR 01756
*** If multiples sales order loaded on this shipment/container
*** update gt_hu_create table and go to next shipment.
*** Set the lv_hu_flag so that this shipment is skipped.
**      IF lv_sord <> gt_gr_status-sord_no.
**        gt_hu_create-mess_type = 'M'.
**        MODIFY gt_hu_create
**          FROM gt_hu_create
**          TRANSPORTING mess_type
**          WHERE tknum = gt_gr_status-tknum.
**        lv_hu_flag = 'X'.
**        gv_ship_skip = gv_ship_skip + 1.      " EDVK964849 TPR 01756
*****>>> start of changes NBEHERE CR93478
**** we are now generating a USD ticket for this conditions
**** and deleting the record from the ZDL_SHIP_COMPL table
**        READ TABLE lt_vttk
**             WITH KEY tknum = gt_gr_status-tknum .
**        lv_text_1 =
**            'Export AutoPGR failed to create a handling unit'(040).
**        CONCATENATE 'for shipment'(041)
**                     gt_gr_status-tknum 'and container'(042)
**                    lt_vttk-signi
**                    INTO lv_text_2 SEPARATED BY space.
**        CONCATENATE 'seal'(043)
**                    lt_vttk-text1(21)
**                    'because it is'(044)
**                    INTO lv_text_3 SEPARATED BY space.
**        CONCATENATE 'associated with multiple'(045)
**                    ' sales orders.'(046)
**                    INTO lv_text_4 SEPARATED BY space.
**
**        PERFORM create_usd_tiket USING lc_e3593
**                                       lv_text_1
**                                       lv_text_2
**                                       lv_text_3
**                                       lv_text_4
**                                       lv_text_5 .
**** we want to check if the entries exist in the delete table
**** if not insert so they get deleted from the table (ZDL_SHIP_COMPL)
**        READ TABLE gt_final_delete
**             WITH KEY tknum = gt_gr_status-tknum
**                      vbeln = gt_gr_status-vbeln_i .
**        IF sy-subrc NE 0 .
**          LOOP AT gt_final_display
**             WHERE tknum = gt_gr_status-tknum .
**            MOVE-CORRESPONDING gt_final_display TO gt_final_delete .
**            APPEND gt_final_delete .
**          ENDLOOP .
**        ENDIF .
*****<<< end of changes NBEHERE CR93478
**        CONTINUE.
**      ENDIF.
*
*      READ TABLE gt_multi_ord_fails INTO gs_multi_ord_fails
*                                    WITH KEY vbeln = lv_vbeln.
*      IF sy-subrc EQ 0.
*
*        gt_hu_create-mess_type = gs_multi_ord_fails-mess_type.
*
*        READ TABLE gt_likp1
*             WITH KEY vbeln = gt_gr_status-vbeln_i.
*
*        IF     gs_multi_ord_fails-mess_type EQ 'S1'.
*          MESSAGE e136(zsd_dl) WITH gt_likp1-zz_signi INTO gt_hu_create-message.
*          lv_text_4 = gt_hu_create-message+0(26).
*          lv_text_5 = gt_hu_create-message+25(46).
*
*        ELSEIF gs_multi_ord_fails-mess_type EQ 'S2'.
*          MESSAGE e137(zsd_dl) WITH gt_likp1-zz_signi INTO gt_hu_create-message.
*          lv_text_4 = gt_hu_create-message+0(26).
*          lv_text_5 = gt_hu_create-message+25(46).
*
*        ELSEIF gs_multi_ord_fails-mess_type EQ 'S3'.
*          MESSAGE e138(zsd_dl) WITH gt_likp1-zz_signi INTO gt_hu_create-message.
*          lv_text_4 = gt_hu_create-message+0(26).
*          lv_text_5 = gt_hu_create-message+25(46).
*
*        ENDIF.
*
*        MODIFY gt_hu_create
*             FROM gt_hu_create
*             TRANSPORTING mess_type message
*             WHERE vbeln = gt_gr_status-vbeln_i.
*
*        lv_hu_flag = 'X'.
*        gv_ship_skip = gv_ship_skip + 1.
*
*
*        lv_text_1 =
*           'Export AutoPGR failed to create a handling unit'(040).
*        CONCATENATE 'for shipment'(041)
*                    gt_gr_status-vbeln_i
*                    'and container'(042)
*                    lt_vttk-signi
*                    INTO lv_text_2 SEPARATED BY space.
*        CONCATENATE 'seal'(043)
*                    lt_vttk-text1(21)
*                     'because'(053)
*                    INTO lv_text_3 SEPARATED BY space.
*
*
*
*        PERFORM create_usd_tiket USING lc_e3593 lv_text_1 lv_text_2
*                                       lv_text_3 lv_text_4 lv_text_5 .
*
*        READ TABLE gt_final_delete WITH KEY vbeln = gt_gr_status-vbeln_i .
*
*        IF sy-subrc NE 0 .
*          LOOP AT gt_final_display
*            WHERE vbeln = gt_gr_status-vbeln_i.
*            MOVE gt_final_display TO gt_final_delete .
*            APPEND gt_final_delete .
*          ENDLOOP .
*        ENDIF .
*
*        CONTINUE.
*      ENDIF.
*
*
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| END2
*
** If Booking doc is different update gt_hu_create table and go to
** next shipment. Set the lv_hu_flag so that this shipment is skipped.
*      IF gt_gr_status-booknum <> lv_book_num AND            "CMS28321
*         gt_gr_status-bookdoc <> lv_book_doc.               "CMS28321
*        gt_hu_create-mess_type = 'B'.
*        MODIFY gt_hu_create
*             FROM gt_hu_create
*             TRANSPORTING mess_type
*             WHERE vbeln = gt_gr_status-vbeln_i.
*        lv_hu_flag = 'X'.
*        gv_ship_skip = gv_ship_skip + 1.
****>>> start of changes NBEHERE CR93478
*** we are now generating a USD ticket for this conditions and
***deleting the record from the ZDL_SHIP_COMPL table
*        READ TABLE gt_likp1
*             WITH KEY vbeln = gt_gr_status-vbeln_i.
*        lv_text_1 =
*           'Export AutoPGR failed to create a handling unit'(040).
*        CONCATENATE 'for shipment'(041)
*                    gt_gr_status-vbeln_i
*                    'and container'(042)
*                    gt_likp1-zz_signi
*                    INTO lv_text_2 SEPARATED BY space.
*        CONCATENATE 'seal'(043)
*                    lt_vttk-text1(21)
*                    'because it is'(044)
*                    INTO lv_text_3 SEPARATED BY space.
*        CONCATENATE 'associated with multiple'(045)
*                    'bookings.'(047)
*                    INTO lv_text_4 SEPARATED BY space.
*
*        PERFORM create_usd_tiket USING lc_e3593
*                                       lv_text_1
*                                       lv_text_2
*                                       lv_text_3
*                                       lv_text_4
*                                       lv_text_5 .
*** we want to check if the entries exist in the delete table
*** if not insert so they get deleted from the table (ZDL_SHIP_COMPL)
*        READ TABLE gt_final_delete
*             WITH KEY vbeln = gt_gr_status-vbeln_i .
*        IF sy-subrc NE 0 .
*          LOOP AT gt_final_display
*            WHERE vbeln = gt_gr_status-vbeln_i.
*            MOVE gt_final_display TO gt_final_delete .
*            APPEND gt_final_delete .
*          ENDLOOP .
*        ENDIF .
****<<< end of changes NBEHERE CR93478
*
*        CONTINUE.
*      ENDIF.
*
** Build internal table with inbound deliveries
*      CLEAR ls_deliv.
*      ls_deliv-vbeln = gt_gr_status-vbeln_i.
*      APPEND ls_deliv TO lt_deliv.
*
*      AT END OF vbeln_i.
**** start of addition CR93478
*        CLEAR lv_reassigned .
*        PERFORM check_hus USING lt_deliv[]
*                      CHANGING lv_reassigned .
*        IF lv_reassigned IS NOT INITIAL .
*** delivery has already been assigned
*          READ TABLE gt_likp1
*               WITH KEY vbeln = lv_vbeln.
*          lv_text_1 =
*             'Export AutoPGR failed to create a handling unit'(040).
*          CONCATENATE 'for shipment'(041)
*                      gt_likp1-vbeln
*                      'and container'(042)
*                      gt_likp1-zz_signi
*                      INTO lv_text_2 SEPARATED BY space.
*          CONCATENATE 'seal'(043)
*                      lt_vttk-text1(21)
*                      'because'(053)
*                      INTO lv_text_3 SEPARATED BY space.
*
*          IF lv_reassigned = '1' .
*            MOVE:
*              'product level HUs were assigned to subsequent'(048)
*                 TO lv_text_4,
*              'deliveries prior to execution of AutoPGR.'(049)
*                 TO lv_text_5 .
*            gt_hu_create-mess_type = 'R'.
*            MODIFY gt_hu_create
*              FROM gt_hu_create
*              TRANSPORTING mess_type
*              WHERE vbeln = lv_vbeln.
*
*          ELSE.
*            MOVE: 'product level HUs were containerized'(051)
*               TO lv_text_4,
*                  'prior to execution of AutoPGR.'(050)
*               TO lv_text_5 .
*            gt_hu_create-mess_type = 'C'.
*            MODIFY gt_hu_create
*              FROM gt_hu_create
*              TRANSPORTING mess_type
*              WHERE vbeln = lv_vbeln.
*
*          ENDIF.
*** create a USD ticket for the errors found
*          PERFORM create_usd_tiket USING lc_e3593
*                                         lv_text_1
*                                         lv_text_2
*                                         lv_text_3
*                                         lv_text_4
*                                         lv_text_5 .
*** we want to check if the entries exist in the delete table
*** if not insert so they get deleted from the table (ZDL_SHIP_COMPL)
** Commented by ALANKAP for Sylvamo
**          LOOP AT lt_deliv INTO ls_deliv .
**            READ TABLE gt_final_delete
**                 WITH KEY vbeln = ls_deliv-vbeln .
**            IF sy-subrc NE 0 .
**              LOOP AT gt_final_display
**                WHERE tknum = lv_tknum .
**                MOVE gt_final_display TO gt_final_delete .
**                APPEND gt_final_delete .
**              ENDLOOP .
**            ENDIF .
**
**          ENDLOOP .
*          lv_hu_flag = 'X'.
*          gv_ship_skip = gv_ship_skip + 1.
*          CONTINUE .
*        ENDIF.
****>>> end of changes
** Get the Handling Units to Pack in to Container
*        PERFORM get_hus USING    lt_deliv[]
*                        CHANGING lt_hus_to_pack[].
*
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| START3
*        READ TABLE gt_container_size INTO ls_container_size
*             WITH KEY vbeln = gs_gr_status-vbeln_i.
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| END3
*
** Create container HU
*        CALL FUNCTION 'ZDL_CREATE_CONTAINER'
*          EXPORTING
*            iv_signi                       = gs_gr_status-signi
*            iv_seal                        = gs_gr_status-text1
*            iv_size                        = ls_container_size-size
*            iv_tare                        = ls_container_size-cont_tare "CMS30389
*            iv_booknum                     = gs_gr_status-booknum
*            iv_bookdoc                     = gs_gr_status-bookdoc "CMS28321
*            iv_werks                       = gt_hu_create-werks
*            iv_vbeln                       = gs_gr_status-sord_no
*          IMPORTING
*            ev_container_exidv             = gt_hu_create-exidv
*            ev_container_venum             = lv_container_venum
*          TABLES
*            it_hus_to_pack                 = lt_hus_to_pack
*            et_return                      = lt_return
*          EXCEPTIONS
*            error_retrieving_unique_exidv  = 1
*            error_calling_unique_exidv     = 2
*            no_container_packing_material  = 3
*            bapi_hu_create_failed          = 4
*            bapi_transaction_commit_failed = 5
*            bapi_hu_pack_failed            = 6
*            error_inserting_zdlu01267_vekp = 7
*            error_retrieving_container     = 8
*            handling_unit_locked           = 9
*            invalid_hu_passed              = 10
*            containerid_seal_already_exist = 11
*            invalid_booking_number         = 12
*            invalid_booking_document       = 13
*            OTHERS                         = 14.
*        IF sy-subrc <> 0.
**// Generate USD if failure
*          CLEAR lv_text_1.
*          CONCATENATE lv_ctext
*          gs_gr_status-vbeln_i INTO lv_text_1 SEPARATED BY space.
** Read error table info to pass on to AHD ticket creater
*          CLEAR ls_return.
*          READ TABLE lt_return INTO ls_return INDEX 1.
*          lv_text_6 = TEXT-052 .                        "ins CR93478
** Generate USD
*          CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
*            EXPORTING
*              inventory_code         = lc_e3593
*              text_1                 = lv_text_1
*              text_2                 = ls_return-message_v1
*              text_3                 = ls_return-message_v2
*              text_4                 = ls_return-message_v3
*              text_5                 = ls_return-message_v4
*              text_6                 = lv_text_6       "ins CR93478
*            EXCEPTIONS
*              invalid_inv_code       = 1
*              ahdgrp_not_found       = 2
*              invalid_idoc_number    = 3
*              webmd_connection_error = 4
*              OTHERS                 = 5.
*          IF sy-subrc <> 0.
*            gt_hu_create-mess_type = 'FF'.  "USD Creation Failure
*          ELSE.
*            gt_hu_create-mess_type = 'FS'.  "USD Creation Successful
*          ENDIF.
*          MODIFY gt_hu_create TRANSPORTING mess_type
*                             WHERE vbeln = gs_gr_status-vbeln_i.
*          gv_ship_fail = gv_ship_fail + 1.
*        ELSE.
*          gt_hu_create-mess_type = 'S'.
*          MODIFY gt_hu_create TRANSPORTING exidv mess_type
*                              WHERE vbeln = gs_gr_status-vbeln_i.
*          gv_ship_create = gv_ship_create + 1.
*        ENDIF.
*      ENDAT.
*    ENDLOOP.
****>>> NBEHERE CR93478
*  ELSE .
*    MESSAGE s000 WITH 'No entries to be processed'(015) .
*    STOP .
*  ENDIF.
*
****<<< end of chanage

*ENDFORM.                    " create_container_hu
*&-------------------------------------------------------------------*
*&      Form  get_hus
*&-------------------------------------------------------------------*
*       text
*--------------------------------------------------------------------*
*      -->P_LT_DELIV[]  text
*      <--P_LT_HUS_TO_PACK[]  text
*--------------------------------------------------------------------*
FORM get_hus  USING    it_deliv       TYPE pdt_t_ship_deliv
              CHANGING et_hus_to_pack TYPE zdl_exidv_tab.

  DATA: lt_vbplk       TYPE STANDARD TABLE OF vbplk,
        ls_vbplk       TYPE vbplk,
        lt_vbplp       TYPE STANDARD TABLE OF vbplp,
        ls_hus_to_pack TYPE zdl_exidv.

  CLEAR: lt_vbplk[], lt_vbplp[].

  CALL FUNCTION 'SD_DELIVERY_PACKING_VIEW'
    EXPORTING
      i_langu                  = sy-langu
      opt_read_delivery_data   = 'X'
      opt_unpacked_items       = 'X'
      opt_packing_sum          = 'X'
      opt_packing_general_data = 'X'
    TABLES
      i_deliv                  = it_deliv[]
      c_vbplk                  = lt_vbplk[]
      c_vbplp                  = lt_vbplp[]
    EXCEPTIONS
      no_deliveries            = 1
      OTHERS                   = 2.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

* Build et_hus_to_pack return table
  LOOP AT lt_vbplk INTO ls_vbplk.
    CLEAR ls_hus_to_pack.
    ls_hus_to_pack-exidv = ls_vbplk-exidv.
    APPEND ls_hus_to_pack TO et_hus_to_pack.
    CLEAR ls_vbplk.
  ENDLOOP.

ENDFORM.                    " get_hus
*&-------------------------------------------------------------------*
*&      Form  con_hu_report
*&-------------------------------------------------------------------*
*       Displays the report relating to Container HU creation
*       functionality
*--------------------------------------------------------------------*
*FORM con_hu_report .
*  SKIP 2.
*  ULINE /2(105).
*  WRITE : /2  sy-vline NO-GAP .
*  FORMAT COLOR COL_HEADING ON INTENSIFIED OFF.
*  WRITE : 106  sy-vline NO-GAP .
*  WRITE : 35 'Container HU Creation Report'(016).
*  FORMAT COLOR OFF.
*
*  ULINE /2(105).
*  WRITE : /2  sy-vline NO-GAP .
*  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
*  WRITE : 106  sy-vline NO-GAP .
*  WRITE : 3 'Number of distinct inbound deliveries attempted          :'(027),
*             gv_ship_attmpt.
*  FORMAT COLOR OFF.
*
*  ULINE /2(105).
*  WRITE : /2  sy-vline NO-GAP .
*  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
*  WRITE : 106  sy-vline NO-GAP .
*  WRITE : 3 'Number of distinct inbound deliveries created HUs        :'(028) ,
*             gv_ship_create .
*  WRITE 80 icon_green_light AS ICON  .
*  FORMAT COLOR OFF.
*
*  ULINE /2(105).
*  WRITE : /2  sy-vline NO-GAP .
*  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
*  WRITE : 106  sy-vline NO-GAP .
*  WRITE : 3 'Number of distinct inbound deliveries failed HU creation :'(029) ,
*             gv_ship_fail .
*  WRITE 80 icon_red_light AS ICON.
*  FORMAT COLOR OFF.
*
*  ULINE /2(105).
*  WRITE : /2  sy-vline NO-GAP .
*  FORMAT COLOR COL_TOTAL ON INTENSIFIED OFF.
*  WRITE : 106  sy-vline NO-GAP .
*  WRITE : 3 'Number of distinct inbound deliveries skipped HU creation:'(030) ,
*             gv_ship_skip .
*  WRITE 80 icon_skip AS ICON.
*  FORMAT COLOR OFF.
*
*  ULINE /2(105).
*  WRITE : /2  sy-vline NO-GAP .
*  FORMAT COLOR COL_HEADING ON INTENSIFIED OFF.
*  WRITE : 106  sy-vline NO-GAP .
*
*  WRITE : 11  'Inbound Delivery'(057)     ,
*          30  sy-vline            ,
*          35  'Handling Unit'(017),
*          49  sy-vline            ,
*          53  'Message Type'(018) ,
*          106  sy-vline            .
*  FORMAT COLOR OFF.
*
*  ULINE /2(105).
*
*  LOOP AT gt_hu_create.
*
*    WRITE: /2 sy-vline NO-GAP       .
*    FORMAT COLOR COL_NORMAL INTENSIFIED OFF.
*    WRITE: 10 gt_hu_create-vbeln    ,
*           30 sy-vline              ,
*           37 gt_hu_create-exidv    ,
*           49 sy-vline              .
*
*    IF gt_hu_create-mess_type = 'X'.
*      WRITE 53 'One or More deliveries not Received'(019).
*    ELSEIF gt_hu_create-mess_type = 'B'.
*      WRITE 53 'Booking document number not unique'(031).
*
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| START4
** - Comment message type 'M' for multiple order check
** - Add message for same sold-tos
** - Add message for same ship-tos
** - Add message for same metric indicators
*
**    ELSEIF gt_hu_create-mess_type = 'M'.    " EDVK964849 TPR 01756
**      WRITE 53 'HU not from single sales order'(032).
*    ELSEIF gt_hu_create-mess_type = 'S1'.
*      WRITE 53 gt_hu_create-message.
*    ELSEIF gt_hu_create-mess_type = 'S2'.
*      WRITE 53 gt_hu_create-message.
*    ELSEIF gt_hu_create-mess_type = 'S3'.
*      WRITE 53 gt_hu_create-message.
*
**CMS: 28321| Changed By: AMAOLE1| Changed On: 08/03/15| END4
*
*    ELSEIF gt_hu_create-mess_type = 'R'.                    "CR93478
*      WRITE 53 'Delivery has subsequent procecssing'(055).  "CR93478
*    ELSEIF gt_hu_create-mess_type = 'S'.
*      WRITE 53 'HU creation successful'(020).
*    ELSEIF gt_hu_create-mess_type = 'FS'.
*      WRITE 53 'HU Creation failed, USD ticket created'(021).
*    ELSEIF gt_hu_create-mess_type = 'C'.
*      WRITE 53 'HU Creation skipped, Container already created'(035).
*    ELSE.
*      WRITE 53 'HU Creation failed, USD ticket not created'(025).
*    ENDIF.
*
*    WRITE 106 sy-vline              .
*    FORMAT RESET.
*    ULINE /2(105).
*  ENDLOOP.
*ENDFORM.                    " con_hu_report
*&-------------------------------------------------------------------*
*&      Form  CHECK_LOCK_STO
*&-------------------------------------------------------------------*
*       text
*--------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*--------------------------------------------------------------------*
FORM check_lock_sto USING pv_vbeln TYPE vbeln_vl
                    CHANGING p_success TYPE c
                             p_userid TYPE any .
  READ TABLE gt_sto WITH KEY vbeln = pv_vbeln.
  IF sy-subrc = 0 .
    DO gv_process TIMES.
      CALL FUNCTION 'ENQUEUE_EMEKKOE'
        EXPORTING
          mode_ekko      = 'E'
          mode_ekpo      = 'E'
          mandt          = sy-mandt
          ebeln          = gt_sto-ebeln
*         EBELP          =
*         X_EBELN        = ' '
*         X_EBELP        = ' '
*         _SCOPE         = '2'
*         _WAIT          = ' '
*         _COLLECT       = ' '
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc <> 0 AND sy-index LT gv_process.
        WAIT UP TO gv_proc_wait SECONDS.
      ELSEIF sy-subrc NE 0 AND sy-index = gv_process .
        MOVE sy-msgv1 TO p_userid .
        CONCATENATE p_userid '.' INTO p_userid .
        EXIT .
      ELSE.
        CALL FUNCTION 'DEQUEUE_EMEKKOE'
          EXPORTING
            mode_ekko = 'E'
            mode_ekpo = 'E'
            mandt     = sy-mandt
            ebeln     = gt_sto-ebeln
*           EBELP     =
*           X_EBELN   = ' '
*           X_EBELP   = ' '
*           _SCOPE    = '3'
*           _SYNCHRON = ' '
*           _COLLECT  = ' '
          .
        p_success = 'X' .
        EXIT.
      ENDIF.
    ENDDO.
  ENDIF.
ENDFORM.                    " CHECK_LOCK_STO
*&-------------------------------------------------------------------*
*&      Form  GET_DETAILS
*&-------------------------------------------------------------------*
*  Get details of STO and processing attemp & job attempt from tables
*  if not found default to agreed upon values
*--------------------------------------------------------------------*
FORM get_details .

  REFRESH : gt_sto .
*            gt_zsdomfld.
  CLEAR :  gs_zsdomfld ,
           gv_process ,
           gv_job.

* get the STO
  SELECT ebeln
         vbeln
    FROM ekes
    INTO TABLE gt_sto
    FOR ALL ENTRIES IN gt_ship_compl
    WHERE vbeln = gt_ship_compl-vbeln.

* get the processing time and number of attemps from the table
* ZSDOMFLD
* Commented the below code for Sylvamo changes by ALANKAP
*  SELECT * FROM  zsdomfld CLIENT SPECIFIED
*        INTO TABLE gt_zsdomfld
*        WHERE mandt = sy-mandt
*          AND category = 'E03593'.

*  IF sy-subrc = 0.
  IF NOT gt_zsdomfld IS INITIAL. "Sylvamo changes
* get the number of processing attempts
    READ TABLE gt_zsdomfld  INTO gs_zsdomfld
                  WITH KEY fieldname = 'PROCESSING_ATTEMPTS'.
    IF sy-subrc = 0 .
      gv_process = gs_zsdomfld-lowval.
    ELSE.
      gv_process = 5 .
    ENDIF.
* get the number of job attempts
    READ TABLE gt_zsdomfld INTO gs_zsdomfld
                 WITH KEY fieldname = 'JOB_ATTEMPTS'.
    IF sy-subrc = 0 .
      gv_job = gs_zsdomfld-lowval.
    ELSE.
      gv_job = 3 .
    ENDIF.
* get the number of seconds to wait
    READ TABLE gt_zsdomfld INTO gs_zsdomfld
                 WITH KEY fieldname = 'PROCESSING_WAIT'.
    IF sy-subrc = 0 .
      gv_proc_wait = gs_zsdomfld-lowval.
    ELSE.
      gv_proc_wait = 3 .
    ENDIF.

* if no values found default to agreed upon values
  ELSE.
    gv_process = 5 .
    gv_job = 3 .
    gv_proc_wait = 3 .
  ENDIF.
ENDFORM.                    " GET_DETAILS
*&-------------------------------------------------------------------*
*&      Form  CHECK_DLVRY_STATUS_DB
*&-------------------------------------------------------------------*
*       text
*--------------------------------------------------------------------*
*      <--P_GT_GR_STATUS_WBSTK  text
*--------------------------------------------------------------------*
FORM check_dlvry_status .
** if the Status(WBSTK) of the Delivery is not 'C' then we need to
** stop the program from deleting it from the ZDL_SHIP_COMPL table
** so that the entry can be reprocessed. The program will stop the
** HU container creation for the entire shipment.  the field USDFLAG
** is used as a deletion indicator in this case
  LOOP AT gt_final_delete
      WHERE vbeln = gt_gr_status-vbeln_i.
*      AND vbeln = gt_gr_status-vbeln_i .
    MOVE 'X' TO gt_final_delete-usdflag .
    MODIFY gt_final_delete .
  ENDLOOP .
  DELETE gt_final_delete WHERE usdflag = 'X' .

ENDFORM.                    " CHECK_DLVRY_STATUS
*&---------------------------------------------------------------------*
*&      Form  CREATE_USD_TIKET
*&---------------------------------------------------------------------*
*       Subroutine added as part of changes NBEHERE CR93478
* to raise a USD ticket
*----------------------------------------------------------------------*
*      -->P_LV_TEXT_1  text
*      -->P_LV_TEXT_2  text
*      -->P_LV_TEXT_3  text
*      -->P_LV_TEXT_4  text
*      -->P_LV_TEXT_5  text
*----------------------------------------------------------------------*
FORM create_usd_tiket  USING    p_invcode
                                p_text_1 TYPE char50
                                p_text_2 TYPE char50
                                p_text_3 TYPE char50
                                p_text_4 TYPE char50
                                p_text_5 TYPE char50.
** local
  DATA: lv_text_6 TYPE char50.

  MOVE 'Disregard statement "IDoc not created".'(052) TO lv_text_6 .

* Generate USD
  CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
    EXPORTING
      inventory_code         = p_invcode
      text_1                 = p_text_1
      text_2                 = p_text_2
      text_3                 = p_text_3
      text_4                 = p_text_4
      text_5                 = p_text_5
      text_6                 = lv_text_6
    EXCEPTIONS
      invalid_inv_code       = 1
      ahdgrp_not_found       = 2
      invalid_idoc_number    = 3
      webmd_connection_error = 4
      OTHERS                 = 5.
  IF sy-subrc <> 0.
    gt_hu_create-mess_type = 'FF'.  "USD Creation Failure
  ELSE.
    gt_hu_create-mess_type = 'FS'.  "USD Creation Successful
  ENDIF.
  MODIFY gt_hu_create TRANSPORTING mess_type
                     WHERE vbeln = gs_gr_status-vbeln_i.

ENDFORM.                    " CREATE_USD_TIKET
*&---------------------------------------------------------------------*
*&      Form  CHECK_HUS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_DELIV[]  text
*      <--P_LV_HU_FLAG  text
*----------------------------------------------------------------------*
FORM check_hus  USING    p_t_deliv TYPE pdt_t_ship_deliv
                CHANGING p_hu_flag TYPE c.
** local
  DATA: lt_delnos TYPE vbeln_vl_t,
        ls_delnos TYPE vbeln_vl,
        ls_deliv  TYPE ship_deliv,
        lv_subrc  TYPE sy-subrc.


  LOOP AT p_t_deliv INTO ls_deliv.
    MOVE ls_deliv-vbeln TO ls_delnos .
    APPEND ls_delnos TO lt_delnos .
  ENDLOOP .
** call function to determine containerization
  CALL FUNCTION 'ZDL_E03593_CONT_DETERMINE'
    EXPORTING
      t_delnos              = lt_delnos
    IMPORTING
      e_subrc               = lv_subrc
    EXCEPTIONS
      no_data               = 1
      wrong_delivery_status = 2
      OTHERS                = 3.
  IF lv_subrc <> 0 .
    p_hu_flag = lv_subrc .
  ELSEIF sy-subrc NE 0 .
    p_hu_flag  = '1' .
  ENDIF.

ENDFORM.                    " CHECK_HUS

FORM get_container_size.

  TYPES:BEGIN OF ty_vttk,
          tknum TYPE tknum,
          vsbed TYPE vsbed,
          text4	TYPE vttk_text4,
        END OF ty_vttk.

  DATA lt_vttk TYPE STANDARD TABLE OF ty_vttk.
  DATA ls_vttk TYPE ty_vttk.
  DATA lt_zsdomfld TYPE STANDARD TABLE OF zsdomfld.
  DATA ls_zsdomfld TYPE zsdomfld.
  DATA ls_container_size TYPE ty_container_size.
  DATA lv_cont_tare TYPE zsd_cont_tare.
  CHECK gt_ship_compl[] IS NOT INITIAL.

* Commented by ALANKAP for Sylvamo changes 7/23
*  SELECT tknum vsbed text4 FROM vttk INTO TABLE lt_vttk
*    FOR ALL ENTRIES IN gt_ship_compl
*    WHERE tknum = gt_ship_compl-tknum
*          AND vsart = 'ZD'.
*
*  CHECK lt_vttk[] IS NOT INITIAL.

  SELECT * FROM zsdomfld INTO TABLE lt_zsdomfld
          WHERE category = 'E03593_CONT'.

* Commented by ALANKAP for Sylvamo changes 7/23
*  LOOP AT lt_vttk INTO ls_vttk.
*
*    CLEAR: ls_container_size,ls_zsdomfld.
*
*    IF ls_vttk-text4 IS NOT INITIAL.
*      ls_container_size-size = ls_vttk-text4.
*    ELSEIF ls_vttk-vsbed IS NOT INITIAL.
*      ls_container_size-size = ls_vttk-vsbed.
*    ENDIF.
*
*    CHECK ls_container_size-size IS NOT INITIAL.
*
*    READ TABLE lt_zsdomfld INTO ls_zsdomfld WITH KEY fieldname = ls_container_size-size.
*
*    CHECK ls_zsdomfld-lowval IS NOT INITIAL.
*
** CMS30389|Changed By:AMAOLE1|Changed On:05192016|START1
*    SELECT SINGLE vbeln FROM vttp INTO @DATA(lv_vbeln)
*           WHERE tknum = @ls_vttk-tknum.
*    IF sy-subrc EQ 0.
*      SELECT SINGLE zzbookdoc FROM likp INTO @DATA(lv_zzbookdoc)
*             WHERE vbeln = @lv_vbeln.
*    ENDIF.
*
*    IF lv_zzbookdoc IS NOT INITIAL.
*
*      SELECT SINGLE stmshpline, req_steamshpline FROM zsd_book_hdr
*        INTO @DATA(ls_zsd_book_hdr)
*        WHERE bookdoc = @lv_zzbookdoc.
*
*      IF ls_zsd_book_hdr-stmshpline IS NOT INITIAL.
*        SELECT SINGLE cont_tare FROM zsd_book_con_tar INTO lv_cont_tare
*         WHERE stmshpline = ls_zsd_book_hdr-stmshpline
*          AND con_size  = ls_zsdomfld-lowval.
*      ELSE.
*        SELECT SINGLE cont_tare FROM zsd_book_con_tar INTO lv_cont_tare
*         WHERE stmshpline = ls_zsd_book_hdr-req_steamshpline
*          AND con_size  = ls_zsdomfld-lowval.
*      ENDIF.
*
*    ENDIF.
*
** CMS30389|Changed By:AMAOLE1|Changed On:05192016|END1
*
*    ls_container_size-tknum      = ls_vttk-tknum.
*    ls_container_size-size       = ls_zsdomfld-lowval.
*    ls_container_size-cont_tare  = lv_cont_tare.            "CMS30389
*    APPEND ls_container_size TO gt_container_size.
*
*  ENDLOOP.

  LOOP AT gt_likp1 INTO DATA(ls_likp).

    CLEAR: ls_container_size,ls_zsdomfld.

    ls_container_size-vbeln = ls_likp-vbeln.
    ls_container_size-size = ls_likp-vsbed.

    CHECK ls_container_size-size IS NOT INITIAL.

    READ TABLE lt_zsdomfld INTO ls_zsdomfld WITH KEY fieldname = ls_container_size-size.

    CHECK ls_zsdomfld-lowval IS NOT INITIAL.

    SELECT SINGLE zzbookdoc FROM likp INTO @DATA(lv_zzbookdoc)
           WHERE vbeln = @ls_likp-vbeln.

    IF lv_zzbookdoc IS NOT INITIAL.

      SELECT SINGLE stmshpline, req_steamshpline FROM zsd_book_hdr
        INTO @DATA(ls_zsd_book_hdr)
        WHERE bookdoc = @lv_zzbookdoc.

      IF ls_zsd_book_hdr-stmshpline IS NOT INITIAL.
        SELECT SINGLE cont_tare FROM zsd_book_con_tar INTO lv_cont_tare
       	WHERE stmshpline = ls_zsd_book_hdr-stmshpline
          AND con_size  = ls_zsdomfld-lowval.
      ELSE.
        SELECT SINGLE cont_tare FROM zsd_book_con_tar INTO lv_cont_tare
       	WHERE stmshpline = ls_zsd_book_hdr-req_steamshpline
          AND con_size  = ls_zsdomfld-lowval.
      ENDIF.

    ENDIF.

*    ls_container_size-tknum      = ls_vttk-tknum.
    ls_container_size-size       = ls_zsdomfld-lowval.
    ls_container_size-cont_tare  = lv_cont_tare.            "CMS30389
    APPEND ls_container_size TO gt_container_size.

  ENDLOOP.

ENDFORM.


FORM multi_orders_check TABLES gt_gr_status STRUCTURE gs_gr_status.

  DATA lt_gr_status LIKE STANDARD TABLE OF gs_gr_status.

*  SORT gt_ship_compl BY tknum.
  SORT gt_ship_compl BY vbeln. " Sylvamo change

  LOOP AT gt_gr_status.

*    AT NEW tknum.
    AT NEW vbeln_i. " Sylvamo change
      lt_gr_status[] = gt_gr_status[].

*     1 Shipment <--> 1 Container
      PERFORM check_individual_shipment TABLES lt_gr_status
                                               gt_multi_ord_fails
                                        USING gt_gr_status-vbeln_i.
    ENDAT.
  ENDLOOP.
ENDFORM.

FORM check_individual_shipment TABLES pt_gr_status STRUCTURE gs_gr_status
                        pt_multi_ord_fails STRUCTURE gs_multi_ord_fails
                 USING pv_vbeln TYPE vbeln_vl.

  TYPES: BEGIN OF ty_vbpa,
           parvw TYPE parvw,
           kunnr TYPE kunnr,
         END OF ty_vbpa.

  DATA lt_vbpa TYPE STANDARD TABLE OF ty_vbpa.
  DATA lt_vbpa_ag TYPE STANDARD TABLE OF ty_vbpa.
  DATA lt_vbpa_we TYPE STANDARD TABLE OF ty_vbpa.
  DATA lt_zz_metric_ind TYPE STANDARD TABLE OF zz_metric_indicator.
  DATA ls_vbpa TYPE ty_vbpa.
  DATA lv_lines TYPE i.

  DELETE pt_gr_status WHERE vbeln_i NE pv_vbeln.

  DESCRIBE TABLE pt_gr_status LINES lv_lines.

* Check if there are multiple orders associated with the shipment
  CHECK lv_lines GT 1.

* Check if all sales orders have the same "Sold-to"
  SELECT parvw kunnr FROM vbpa
    INTO TABLE lt_vbpa
    FOR ALL ENTRIES IN pt_gr_status
    WHERE vbeln = pt_gr_status-sord_no
    AND posnr = '000000'.

  lt_vbpa_ag = lt_vbpa.
  DELETE lt_vbpa_ag WHERE parvw NE 'AG'.

  SORT lt_vbpa_ag BY kunnr.

  DELETE ADJACENT DUPLICATES FROM lt_vbpa_ag COMPARING kunnr.

  DESCRIBE TABLE lt_vbpa_ag LINES lv_lines.

  IF lv_lines GT 1.
    gs_multi_ord_fails-vbeln = pv_vbeln.
    gs_multi_ord_fails-mess_type = 'S1'.
    APPEND gs_multi_ord_fails TO gt_multi_ord_fails.

    EXIT.
  ENDIF.

* Check if all sales orders have the same "Ship-to"
  lt_vbpa_we = lt_vbpa.
  DELETE lt_vbpa_we WHERE parvw NE 'WE'.

  SORT lt_vbpa_we BY kunnr.

  DELETE ADJACENT DUPLICATES FROM lt_vbpa_we COMPARING kunnr.

  DESCRIBE TABLE lt_vbpa_we LINES lv_lines.

  IF lv_lines GT 1.
    gs_multi_ord_fails-vbeln = pv_vbeln.
    gs_multi_ord_fails-mess_type = 'S2'.
    APPEND gs_multi_ord_fails TO gt_multi_ord_fails.

    EXIT.
  ENDIF.

* Check if all sales orders have the same "Metric Indicator"
  SELECT zz_metric_ind FROM vbak
    INTO TABLE lt_zz_metric_ind
    FOR ALL ENTRIES IN pt_gr_status
    WHERE vbeln = pt_gr_status-sord_no.

  SORT lt_zz_metric_ind.

  DELETE ADJACENT DUPLICATES FROM lt_zz_metric_ind.

  DESCRIBE TABLE lt_zz_metric_ind LINES lv_lines.

  IF lv_lines GT 1.
    gs_multi_ord_fails-vbeln = pv_vbeln.
    gs_multi_ord_fails-mess_type = 'S3'.
    APPEND gs_multi_ord_fails TO gt_multi_ord_fails.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_SHIPMENT_COST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_shipment_cost.
  zcl_dl_e3637_dcgr_checks=>check_dcgr(
    EXPORTING
      it_vbeln_tknum = VALUE #( FOR ls_vbeln IN gt_ship_compl
                               ( vbeln = ls_vbeln-vbeln ) )
  IMPORTING
    et_dcgr_tab    =  DATA(lt_dcgr) ).   " DCGR table type

* Remove the shipment for which cost document is not created.
  IF lt_dcgr IS NOT INITIAL.
    LOOP AT gt_ship_compl ASSIGNING FIELD-SYMBOL(<ls_inb_dlvry>).
*      Read table lt_inb_dlvry.
      DATA(ls_inb_del) = VALUE #( lt_dcgr[ vbeln = <ls_inb_dlvry>-vbeln ] OPTIONAL ).

      CASE ls_inb_del-dcgr.
        WHEN abap_true.
          IF ls_inb_del-frkrl = abap_true AND
             ls_inb_del-fbsta = 'C' AND
             ls_inb_del-inb_assgnd = abap_true AND
             ls_inb_del-ship_ref   = abap_true AND
             ls_inb_del-ship_bolnr = abap_true.
            " Do nothing
          ELSE.
            DELETE TABLE gt_ship_compl FROM <ls_inb_dlvry>.
          ENDIF.
        WHEN OTHERS.
      ENDCASE.
      CLEAR ls_inb_del.
    ENDLOOP.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_EKPO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_ekpo .

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_EKKO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_ekko .

  TYPES: BEGIN OF ty_lifnr,
           sign   TYPE c LENGTH 1,
           option TYPE c LENGTH 2,
           low    TYPE lifnr,
           high   TYPE lifnr,
         END OF ty_lifnr.
  DATA: gr_lifnr TYPE RANGE OF lifnr,
        gs_lifnr TYPE ty_lifnr.

** table for likp entries
  DATA: lv_lifnr TYPE lifnr.

  NEW lcl_e03593( ).

  gr_lifnr = VALUE #( FOR ls_zsdomfld IN gt_zsdomfld WHERE ( fieldname = 'LIFNR' )
                                  ( sign   = 'I'
                                    option = 'EQ'
                                    low = lcl_e03593=>convert_vendor( iv_lifnr = ls_zsdomfld-lowval )
                                    ) ).

  IF NOT gt_likp1[] IS INITIAL.
*    SELECT vbeln vbelv vgbel
*      FROM lips
*      INTO TABLE gt_lips
*      FOR ALL ENTRIES IN gt_likp1
*      WHERE  vbeln = gt_likp1-vbeln .
*    IF sy-subrc IS INITIAL.
    DATA(lv_bsart) = VALUE #( gt_zsdomfld[ fieldname = 'BSART' ]-lowval OPTIONAL ).
    SELECT ebeln bsart lifnr INTO TABLE gt_ekko
      FROM ekko
      FOR ALL ENTRIES IN gt_likp1
      WHERE ebeln = gt_likp1-vgbel
      AND   bsart = lv_bsart
      AND   lifnr IN gr_lifnr.
*    ENDIF.
  ENDIF.


ENDFORM.

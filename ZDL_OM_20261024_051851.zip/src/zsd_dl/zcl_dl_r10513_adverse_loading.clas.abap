class ZCL_DL_R10513_ADVERSE_LOADING definition
  public
  create public .

public section.

  types:
    BEGIN OF ty_s_alv_data,
        mill                  TYPE char24,
        shipment              TYPE tknum,
        from_scac             TYPE tdlnr,
        to_scac               TYPE tdlnr,
        storage_location      TYPE lgort_d,
        ship_to               TYPE kunwe,
        customer_info         TYPE name1_gp,
        city_state            TYPE string,
        planned_ship_date     TYPE dptbg,
        car_size              TYPE char24,
        primary_carrier       TYPE tdlnr,
        primary_rate          TYPE kbetr_kond,
        secondary_carrier     TYPE tdlnr,
        secondary_rate        TYPE kbetr_kond,
        primary_secondary     TYPE kbetr_kond,
        adverse_load_fee      TYPE bwert,
        low_cost_option       TYPE string,
        primary_penalty       TYPE kbetr_kond,
        primary_rate_est_cost TYPE kbetr_kond,
        alternate_route       TYPE kbetr_kond,
      END OF ty_s_alv_data .
  types:
    BEGIN OF ty_s_input,
        mill TYPE tplst,
        date TYPE dptbg,
      END OF ty_s_input .

  class-data MV_MESSAGE type STRING .
  class-data:
    mt_alv_data TYPE STANDARD TABLE OF ty_s_alv_data .

  methods CONSTRUCTOR
    importing
      !IS_INPUT type TY_S_INPUT
      !IR_DATE type PIQ_SELOPT_T .
  methods VALIDATE_SCREEN_FIELD .
  methods GET_DATA .
  methods PREPARE_ALV_DATA .
  methods SEND_EMAIL .
protected section.
private section.

  data MO_ADVERSE_LOADING type ref to LCL_ADVERSE_LOADING .
ENDCLASS.



CLASS ZCL_DL_R10513_ADVERSE_LOADING IMPLEMENTATION.


  METHOD constructor.
* Pass the screen fields to the local class implementaion
    lcl_adverse_loading=>gs_screen_input = is_input.
    lcl_adverse_loading=>gr_date = ir_date.

    mo_adverse_loading = NEW lcl_adverse_loading( ).
  ENDMETHOD.


  METHOD get_data.
    mo_adverse_loading->get_data( ).
    mv_message = lcl_adverse_loading=>gv_message.
  ENDMETHOD.


  METHOD prepare_alv_data.
    mo_adverse_loading->prepare_alv_data( ).
    mt_alv_data = lcl_adverse_loading=>gt_alv_data.
  ENDMETHOD.


  METHOD send_email.

**********************************************************************
    CONSTANTS: c_attach_name  TYPE so_obj_des VALUE 'Adverse Laoding Data',
               c_4103         TYPE abap_encod VALUE '4103',
               lc_status_n    TYPE bcs_stml  VALUE 'N',
               lc_attype_xls  TYPE so_obj_tp VALUE 'XLS',
               lc_doctype_raw TYPE so_obj_tp VALUE 'RAW'.

    DATA: lt_maintext   TYPE bcsy_text,
          ls_excel_data TYPE string.

* Concordinating labe to show as a header in the attached excel
CLEAR ls_excel_data.
    CONCATENATE ls_excel_data
                 TEXT-001 " 'Mill'
                 TEXT-002 "'Shipment'
                 TEXT-003 "'From SCAC'
                 TEXT-004 "'To SCAC'
                 TEXT-005 "'Storage Location'
                 TEXT-006 "'Ship-To'
                 TEXT-007 "'Customer Info'
                 TEXT-008 "'City/State'
                 TEXT-009 "'Planned Shipped Date'
                 TEXT-010 "'Car Size'
                 TEXT-011 "'Primary Carrier'
                 TEXT-012 "'Primary Rate'
                 TEXT-013 "'Secondary Carrier'
                 TEXT-014 "'Secondary Rate'
                 TEXT-015 "'Primary - Secondary'
                 TEXT-016 "'Adverse Loading Fee'
                 TEXT-017 "'Low Cost Option'
                 TEXT-018 "'Primary + Penalty'
                 TEXT-019 "'Primary Rate Est. Cost'
                 TEXT-020 "'Alternate Route - Adverse Loading Fee'
                 cl_abap_char_utilities=>cr_lf
                INTO ls_excel_data SEPARATED BY
                cl_abap_char_utilities=>horizontal_tab.

    LOOP AT mt_alv_data INTO DATA(ls_alv_data).
      DATA(lv_primary_rate)      = CONV string( ls_alv_data-primary_rate ).
      DATA(lv_secondary_rate)    = CONV string( ls_alv_data-secondary_rate ).
      DATA(lv_primary_secondary) = CONV string( ls_alv_data-primary_secondary ).
      DATA(lv_adverse_load_fee)  = CONV string( ls_alv_data-adverse_load_fee ).
      DATA(lv_primary_penalty)   = CONV string( ls_alv_data-primary_penalty ).
      DATA(lv_primary_rate_est_cost) = CONV string( ls_alv_data-primary_rate_est_cost ).
      DATA(lv_alternate_route)       = CONV string( ls_alv_data-alternate_route ).
      CONCATENATE ls_excel_data
                  ls_alv_data-mill
                  ls_alv_data-shipment
                  ls_alv_data-from_scac
                  ls_alv_data-to_scac
                  ls_alv_data-storage_location
                  ls_alv_data-ship_to
                  ls_alv_data-customer_info
                  ls_alv_data-city_state
                  ls_alv_data-planned_ship_date
                  ls_alv_data-car_size
                  ls_alv_data-primary_carrier
                  lv_primary_rate
                  ls_alv_data-secondary_carrier
                  lv_secondary_rate
                  lv_primary_secondary
                  lv_adverse_load_fee
                  ls_alv_data-low_cost_option
                  lv_primary_penalty
                  lv_primary_rate_est_cost
                  lv_alternate_route
                  cl_abap_char_utilities=>cr_lf
                  INTO ls_excel_data SEPARATED BY
                  cl_abap_char_utilities=>horizontal_tab.
    ENDLOOP.

    TRY.
        CALL METHOD cl_bcs_convert=>string_to_solix
          EXPORTING
            iv_string   = ls_excel_data
            iv_codepage = c_4103
            iv_add_bom  = abap_true
          IMPORTING
            et_solix    = DATA(lt_excel_attach)
            ev_size     = DATA(lv_size).
      CATCH  cx_bcs.
        MESSAGE e445(so).
    ENDTRY.

    CLEAR: ls_excel_data.

    "Excel Subject for atachment
    DATA(lv_attach_subj) = c_attach_name.

**********************************************************************
*Mail Body Part
**********************************************************************
    APPEND VALUE #( line = 'Please find the attachment for Adverse Loading Fee Data' ) TO lt_maintext.

* Subject of the message
    DATA(lv_subject_mail) = CONV so_obj_des( |Adverse Laod Data { sy-datum DATE = USER }| ).

    TRY.
*Create persistent send request
        DATA(lo_send_request) = cl_bcs=>create_persistent( ).

        DATA(lo_document) = cl_document_bcs=>create_document(
                i_type    = lc_doctype_raw
                i_text    = lt_maintext
                i_subject = lv_subject_mail ).

*Add the TCODE Shortcut as attachment to document object
        lo_document->add_attachment(
         i_attachment_type    = lc_attype_xls
         i_attachment_subject = lv_attach_subj
         i_attachment_size    = lv_size
         i_att_content_hex    = lt_excel_attach ).

* Add document object to send request
        lo_send_request->set_document( lo_document ).

*     --------- add recipient (e-mail address) -----------------------
*     create recipient object
        DATA(lo_recipient) = cl_cam_address_bcs=>create_internet_address(
                        'ronna.woods@ipaper.com' ).

* Add recipient object to send request
        lo_send_request->add_recipient( lo_recipient ).

        lo_send_request->set_status_attributes(
          EXPORTING
            i_requested_status = lc_status_n
            i_status_mail      = lc_status_n ).

* Send the document
        CALL METHOD lo_send_request->send( ).
        COMMIT WORK.
      CATCH cx_bcs INTO DATA(lx_bcs_exception).
        DATA(lv_message) = lx_bcs_exception->get_text( ).
        MESSAGE e000(zdl_r10513) WITH lv_message.
    ENDTRY.
  ENDMETHOD.


  METHOD validate_screen_field.
    mo_adverse_loading->validate_mill( ).

* Add any new method here for screen validation

    mv_message = lcl_adverse_loading=>gv_message.
  ENDMETHOD.
ENDCLASS.

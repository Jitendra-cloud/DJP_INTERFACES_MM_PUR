*---------------------------------------------------------------------*
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E04010TOP.                    " Global Data
  INCLUDE LZDL_E04010UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E04010F...                    " Subprograms
* INCLUDE LZDL_E04010O...                    " PBO-Modules
* INCLUDE LZDL_E04010I...                    " PAI-Modules

INCLUDE LZDL_E04010F01.

INCLUDE LZDL_E04010F02.

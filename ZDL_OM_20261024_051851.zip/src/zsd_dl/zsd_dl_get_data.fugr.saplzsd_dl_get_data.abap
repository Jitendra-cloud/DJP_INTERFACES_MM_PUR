*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_GET_DATATOP.               " Global Data
  INCLUDE LZSD_DL_GET_DATAUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_GET_DATAF...               " Subprograms
* INCLUDE LZSD_DL_GET_DATAO...               " PBO-Modules
* INCLUDE LZSD_DL_GET_DATAI...               " PAI-Modules

************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         20xx                                       **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Fun. Name: ZDL_E3637_GEN_OUT_DLVRY                  Date: 10/09/2006 *
*                                                                      *
* Programmer  : Savithri Renganathan                                   *
*______________________________________________________________________*
* Description :                                                        *
*  Function to create outbound delivery with reference to a sales order*
*                                                                      *
* Logic: Call BDC routine for the transaction VL01N to create outbound *
* delivery for a given sales order. Call function SLS_MISC_CONVERT_TO_ *
* DATE to convert Max Date to the format based on the user who is      *
* processing IDoc.                                                     *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
* Date       TPR #/Progr Ch#  Remarks                                  *
*                                                                      *
*______________________________________________________________________*

************************************************************************
* External Calls                                                       *
*   Function Modules:                                                  *
*    SLS_MISC_CONVERT_TO_DATE    -  Convert date into user's format    *
*    CONVERSION_EXIT_ALPHA_INPUT -  Alpha conversion for outbound del. *
*______________________________________________________________________*


FUNCTION zdl_e3637_gen_out_dlvry.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_SHIP_POINT) LIKE  LIKP-VSTEL OPTIONAL
*"     REFERENCE(IV_SALE_ORD) LIKE  LIPS-VGBEL OPTIONAL
*"     REFERENCE(IV_INB_DLVRY) LIKE  LIKP-VBELN OPTIONAL
*"     REFERENCE(IV_DLK) TYPE  CHAR1 OPTIONAL
*"  EXPORTING
*"     REFERENCE(EV_OUT_DLVRY) LIKE  LIKP-VBELN
*"  TABLES
*"      ET_MESSAGES TYPE  ZCA_BAL_MSG_TAB
*"      LT_OUTBOUND_DATA TYPE  ZDL_BAPIDLVREFTOSALESORDER_T
*"  EXCEPTIONS
*"      DATE_CONVERT_FAILED
*"      ERROR_CREATE_OUTDEL
*"----------------------------------------------------------------------

  CONSTANTS:
    lc_max_date TYPE begdatum VALUE '99991231'.  "Max date allowed

  DATA:
    lv_date     TYPE char10,
    ls_messages TYPE bal_s_msg.

  CLEAR   gs_bdcdata.
  REFRESH gt_bdcdata.

* Convert Max date to the format based on the user who is processing the
* IDoc.  It could be by BPM_USER or someone else who is running WE19 or
* BD87.  Feed this function module P_DATE in the format YYYYMMDD.
* It will give sy-uname's date format from the table USR01 in the
* parameter P_DATE.  Since we want max date in MM/DD/YYYY format, we put
* it in a constant.

  CALL FUNCTION 'SLS_MISC_CONVERT_TO_DATE'
    EXPORTING
      p_date                        = lc_max_date
    IMPORTING
      p_date_string                 = lv_date
    EXCEPTIONS
      error_selecting_user_defaults = 1
      OTHERS                        = 2.

  IF sy-subrc <> 0.
* Call to function mod SLS_MISC_CONVERT_TO_DATE failed &.

    ls_messages-msgty  = gc_error.
    ls_messages-msgid  = gc_msgid.
    ls_messages-msgno  = '190'.
    ls_messages-msgv1  = sy-subrc.
    ls_messages-msgv2  = space.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO et_messages.
    CLEAR  ls_messages.

    RAISE date_convert_failed.

  ENDIF.

  PERFORM sub_vl01     USING    iv_ship_point
                                iv_sale_ord
                                lc_max_date "lv_date "CMS30577 E0VK9A0KS2 06/23/2016 SMITHAI
                                iv_inb_dlvry
                                iv_dlk                          "33303
                                lt_outbound_data[]   "JWILL68 CD#1626
                       CHANGING et_messages[]
                                ev_out_dlvry.

  IF et_messages[] IS INITIAL.
* Successfully created outbound delivery & for the sales order &.
    ls_messages-msgty  = gc_success.
    ls_messages-msgid  = gc_msgid.
    ls_messages-msgno  = '209'.
    ls_messages-msgv1  = ev_out_dlvry.
    ls_messages-msgv2  = iv_sale_ord.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO et_messages.
    CLEAR  ls_messages.
  ELSE.
    RAISE error_create_outdel.
  ENDIF.

ENDFUNCTION.

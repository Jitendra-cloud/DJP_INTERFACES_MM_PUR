*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTF01 .
*----------------------------------------------------------------------*
*----------------------------------------------------------------------*
*       Form  get_shipment_data
*----------------------------------------------------------------------*
* This form gets the shipment data from Shipment Number
*----------------------------------------------------------------------*
FORM get_shipment_data  USING    iv_tknum.

  REFRESH : gt_vttp, gt_vtts, gt_vtsp, gt_vttk.
  CLEAR   : gt_vttp, gt_vtts, gt_vtsp, gs_vttk, gt_vttk.

  CALL FUNCTION 'RV_SHIPMENT_VIEW'
    EXPORTING
      shipment_number  = iv_tknum
      option_items     = 'X'
      option_segments  = 'X'
    IMPORTING
      f_vttkvb         = gs_vttk
    TABLES
      f_vttp           = gt_vttp
      f_vtts           = gt_vtts
      f_vtsp           = gt_vtsp
    EXCEPTIONS
      not_found        = 1
      no_authority     = 2
      delivery_missing = 3
      delivery_lock    = 4
      OTHERS           = 5.

  CASE sy-subrc.
    WHEN '0'.
      MOVE-CORRESPONDING gs_vttk TO gt_vttk.
      APPEND gt_vttk.
    WHEN '1'.
      RAISE shipment_not_found.
    WHEN '2'.
      RAISE no_authority.
    WHEN '3'.
      RAISE no_deliveries_found.
    WHEN OTHERS.
  ENDCASE.

ENDFORM.                    " get_shipment_data
*----------------------------------------------------------------------*
*       Form  stage_to_stop_conversion
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM stage_to_stop_conversion.

* >> Based on Stage count, determine whether its a single stage
*    shipment or multi stage shipment
  IF gv_stage_count EQ 1.
    PERFORM single_stage_process.
  ELSE.
    PERFORM muli_stage_process.
  ENDIF.

ENDFORM.                    "stage_to_stop_conversion
*----------------------------------------------------------------------*
*       Form  single_stage_process
*----------------------------------------------------------------------*
* This form prepares the required output for a single stage process
* scenario
*----------------------------------------------------------------------*
FORM single_stage_process .

  DATA : ls_stop1 LIKE gt_stops,
         ls_stop2 LIKE gt_stops,
         lv_location(10),
         lv_loc_ind.

  READ TABLE gt_vtts INDEX 1.

  IF gt_vtts-sdabw IS INITIAL.  " Special processing indicator
* >> 'CL' - Complete Load activity with all the deliveries
    ls_stop1-seqnm = '01'.
    ls_stop1-stpty = 'CL'.
    CLEAR : lv_location, lv_loc_ind.
    PERFORM determine_location USING 'O'
                            CHANGING lv_location
                                     lv_loc_ind.
    ls_stop1-location = lv_location.
    ls_stop1-loc_ind  = lv_loc_ind.
    ls_stop1-tsrfo    = gt_vtts-tsrfo.
    ls_stop1-tsnum    = gt_vtts-tsnum.

* >> 'CU' - Complete Unload activity with all the deliveries
    ls_stop2-seqnm = '02'.
    ls_stop2-stpty = 'CU'.
    CLEAR : lv_location, lv_loc_ind.
    PERFORM determine_location USING 'D'
                            CHANGING lv_location
                                     lv_loc_ind.
    ls_stop2-location = lv_location.
    ls_stop2-loc_ind  = lv_loc_ind.
    ls_stop2-tsrfo    = gt_vtts-tsrfo.
    ls_stop2-tsnum    = gt_vtts-tsnum.

* >> Getting all the deliveries on the stage
    LOOP AT gt_vttp.
      ls_stop1-vbeln = gt_vttp-vbeln.
      APPEND ls_stop1 TO gt_stops.
      ls_stop2-vbeln = gt_vttp-vbeln.
      APPEND ls_stop2 TO gt_stops.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " single_stage_process
*----------------------------------------------------------------------*
*       Form  muli_stage_process
*----------------------------------------------------------------------*
* This form prepares the required output for a multiple stage process
* scenario
*----------------------------------------------------------------------*
FORM muli_stage_process .

  DATA : lv_seqnm      TYPE  zstopseq,
         lt_load       LIKE  gt_stage_data OCCURS 0 WITH HEADER LINE,
         lt_unload     LIKE  gt_stage_data OCCURS 0 WITH HEADER LINE,
         lv_curr_index LIKE  sy-tabix,
         lv_prev_index LIKE  sy-tabix,
         lv_next_index LIKE  sy-tabix,
         lv_location(10),
         lv_loc_ind.

  REFRESH : gt_prev_stage, gt_curr_stage, gt_next_stage.
  CLEAR   : gt_prev_stage, gt_curr_stage, gt_next_stage.

  SORT gt_vtts BY tsrfo.
  SORT gt_vttp BY tpnum.
  gt_vtts_copy[] = gt_vtts[].
  LOOP AT gt_vtts.
    lv_curr_index = sy-tabix.
    lv_prev_index = lv_curr_index - 1.
    lv_next_index = lv_curr_index + 1.
* >> Getting Previous Stage data
    REFRESH gt_prev_stage.
    CLEAR   gt_prev_stage.
    gt_prev_stage[] = gt_curr_stage[].

* >> Getting Current Stage data
    REFRESH gt_curr_stage.
    CLEAR   gt_curr_stage.
    IF gt_next_stage[] IS NOT INITIAL.
      gt_curr_stage[] = gt_next_stage[].
      REFRESH gt_next_stage.
      CLEAR   gt_next_stage.
    ELSE.
      PERFORM get_current_stage_data.
    ENDIF.

* >> Getting Next Stage data
    READ TABLE gt_vtts_copy INDEX lv_next_index.
    IF sy-subrc EQ 0.
      PERFORM get_next_stage_data.
    ENDIF.

    CLEAR : lv_location, lv_loc_ind.
    PERFORM determine_location USING 'O'  " Origin
                            CHANGING lv_location
                                     lv_loc_ind.
    gt_stops-location = lv_location.
    gt_stops-loc_ind  = lv_loc_ind.

* >> If this is the first stage, the activity is 'CL' for all the
*    deliveries
    IF gt_prev_stage[] IS INITIAL.
      ADD 1 TO lv_seqnm.
      LOOP AT gt_curr_stage.
        gt_stops-seqnm = lv_seqnm.
        gt_stops-stpty = 'CL'.
        MOVE-CORRESPONDING gt_curr_stage TO gt_stops.
        APPEND gt_stops.
      ENDLOOP.
    ELSE.
* >> Assumption that VSTEL will always have a value even shipped from
*    a plant - by Matthew & HariHara
      IF gt_vtts-vstel IS NOT INITIAL.
        PERFORM check_overflow_scenario CHANGING lv_seqnm.
      ENDIF.
* >> Checking for 'Load' Activity on the current stage based on the
*    previous stage deliveries
      REFRESH lt_load.
      CLEAR   lt_load.
      LOOP AT gt_curr_stage.
        READ TABLE gt_prev_stage WITH KEY vbeln = gt_curr_stage-vbeln.
* >> If there is any new delivery on the current stage which is not
*    present on the previous stage, that indicates loading activity
*    on the current stage and all those deliveries are captured
        IF sy-subrc NE 0.
          "ADD 1 TO lv_seqnm.
          gt_stops-seqnm = lv_seqnm.
          gt_stops-stpty = 'PL'.
          "MOVE-CORRESPONDING gt_curr_stage TO gt_stops.
          "APPEND gt_stops.
          MOVE-CORRESPONDING gt_curr_stage TO lt_load.
          APPEND lt_load.
          CLEAR  lt_load.
        ENDIF.
      ENDLOOP.
* >> All the new deliveries captured indicates the activity 'PL' meaning
*    Partial Load
      IF lt_load[] IS NOT INITIAL.
        ADD 1 TO lv_seqnm.
        gt_stops-seqnm = lv_seqnm.
        gt_stops-stpty = 'PL'.
        LOOP AT lt_load.
          MOVE-CORRESPONDING lt_load TO gt_stops.
          APPEND gt_stops.
        ENDLOOP.
      ENDIF.
    ENDIF.

    CLEAR : lv_location, lv_loc_ind.
    PERFORM determine_location USING 'D'    " Destination
                            CHANGING lv_location
                                     lv_loc_ind.
    gt_stops-location = lv_location.
    gt_stops-loc_ind  = lv_loc_ind.

* >> If this is the last stage, the activity is 'CU' for all the
*    deliveries
    IF gt_next_stage[] IS INITIAL.
      ADD 1 TO lv_seqnm.
      LOOP AT gt_curr_stage.
        gt_stops-seqnm = lv_seqnm.
        gt_stops-stpty = 'CU'.
        MOVE-CORRESPONDING gt_curr_stage TO gt_stops.
        APPEND gt_stops.
      ENDLOOP.
    ELSE.
* >> Checking for 'Unload' Activity on the current stage based on the
*    previous stage deliveries
      REFRESH lt_unload.
      CLEAR   lt_unload.
      LOOP AT gt_curr_stage.
        READ TABLE gt_next_stage WITH KEY vbeln = gt_curr_stage-vbeln.
* >> If any delivery on the current stage not present on the next stage,
*    that indicates unloading activity on the current stage and all
*    those deliveries are captured
        IF sy-subrc NE 0.
          "ADD 1 TO lv_seqnm.
          gt_stops-seqnm = lv_seqnm.
          gt_stops-stpty = 'PU'.
          "MOVE-CORRESPONDING gt_curr_stage TO gt_stops.
          "APPEND gt_stops.
          MOVE-CORRESPONDING gt_curr_stage TO lt_unload.
          APPEND lt_unload.
          CLEAR  lt_unload.
        ENDIF.
      ENDLOOP.
* >> All the unloaded deliveries captured indicates the activity 'PU'
*    meaning Partial Unload
      IF lt_unload[] IS NOT INITIAL.
        ADD 1 TO lv_seqnm.
        gt_stops-seqnm = lv_seqnm.
        gt_stops-stpty = 'PU'.
        LOOP AT lt_unload.
          MOVE-CORRESPONDING lt_unload TO gt_stops.
          APPEND gt_stops.
        ENDLOOP.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " muli_stage_process
*----------------------------------------------------------------------*
*       Form  get_current_stage_data
*----------------------------------------------------------------------*
* This form gets the current stage data
*----------------------------------------------------------------------*
FORM get_current_stage_data.

  LOOP AT gt_vtsp WHERE tsnum = gt_vtts-tsnum.
    READ TABLE gt_vttp WITH KEY tpnum = gt_vtsp-tpnum
                                BINARY SEARCH.
    MOVE-CORRESPONDING gt_vtts TO gt_curr_stage.
    MOVE-CORRESPONDING gt_vtsp TO gt_curr_stage.
    gt_curr_stage-tpnum = gt_vttp-tpnum.
    gt_curr_stage-vbeln = gt_vttp-vbeln.
    APPEND gt_curr_stage.
    CLEAR  gt_curr_stage.
  ENDLOOP.

ENDFORM.                    "get_current_stage_data
*----------------------------------------------------------------------*
*       Form  get_next_stage_data
*----------------------------------------------------------------------*
* This form gets the next stage data
*----------------------------------------------------------------------*
FORM get_next_stage_data.

  LOOP AT gt_vtsp WHERE tsnum = gt_vtts_copy-tsnum.
    READ TABLE gt_vttp WITH KEY tpnum = gt_vtsp-tpnum
                                BINARY SEARCH.
    MOVE-CORRESPONDING gt_vtts_copy TO gt_next_stage.
    MOVE-CORRESPONDING gt_vtsp TO gt_next_stage.
    gt_next_stage-tpnum = gt_vttp-tpnum.
    gt_next_stage-vbeln = gt_vttp-vbeln.
    APPEND gt_next_stage.
    CLEAR  gt_next_stage.
  ENDLOOP.

ENDFORM.                    "get_next_stage_data
*----------------------------------------------------------------------*
*       Form  determine_location
*----------------------------------------------------------------------*
* This form determines the location and location indicator based on
* WERKA/WERKZ, VSTEL/VSTEZ, KUNNA/KUNNZ & LIFNA/LIFNZ
*----------------------------------------------------------------------*
FORM determine_location USING iv_stoptype
                     CHANGING lv_location
                              lv_loc_ind.

  IF iv_stoptype EQ 'O'.
    IF gt_vtts-werka IS NOT INITIAL.
      lv_location = gt_vtts-werka.
      lv_loc_ind  = 'P'.   " Plant
    ELSEIF gt_vtts-vstel IS NOT INITIAL.
      lv_location = gt_vtts-vstel.
      lv_loc_ind  = 'S'.   " Shipping Point
    ELSEIF gt_vtts-kunna IS NOT INITIAL.
      lv_location = gt_vtts-kunna.
      lv_loc_ind  = 'C'.   " Customer
    ELSEIF gt_vtts-lifna IS NOT INITIAL.
      lv_location = gt_vtts-lifna.
      lv_loc_ind  = 'V'.   " Vendor
    ENDIF.
  ELSEIF iv_stoptype EQ 'D'.
    IF gt_vtts-werkz IS NOT INITIAL.
      lv_location = gt_vtts-werkz.
      lv_loc_ind = 'P'.   " Plant
    ELSEIF gt_vtts-vstez IS NOT INITIAL.
      lv_location = gt_vtts-vstez.
      lv_loc_ind = 'S'.   " Shipping Popint
    ELSEIF gt_vtts-kunnz IS NOT INITIAL.
      lv_location = gt_vtts-kunnz.
      lv_loc_ind = 'C'.   " Customer
    ELSEIF gt_vtts-lifnz IS NOT INITIAL.
      lv_location = gt_vtts-lifnz.
      lv_loc_ind = 'V'.   " Vendor
    ENDIF.
  ENDIF.

ENDFORM.                    "determine_location
*----------------------------------------------------------------------*
*       Form  check_overflow_scenario
*----------------------------------------------------------------------*
* This form checks for Plant-Overflow/Overflow-Plant scenario and
* determines the activity accordingly
*----------------------------------------------------------------------*
FORM check_overflow_scenario CHANGING cv_seqnm TYPE zstopseq.

  DATA : lv_werks TYPE  werks_d,
         lv_skip  TYPE  c,
         lt_tvswz LIKE tvswz OCCURS 0 WITH HEADER LINE.

  SELECT SINGLE werks
         INTO   lv_werks
         FROM   tvswz
         WHERE  vstel EQ gt_vtts-vstel.
  IF sy-subrc EQ 0.
    SELECT *
          FROM tvswz
          INTO TABLE lt_tvswz
          WHERE werks EQ lv_werks.
    READ TABLE gt_prev_stage INDEX 1.
    CLEAR lt_tvswz.
    READ TABLE lt_tvswz WITH KEY werks = gt_prev_stage-werka
                                 vstel = gt_prev_stage-vstez.
    IF sy-subrc NE 0.
      READ TABLE lt_tvswz WITH KEY werks = lv_werks
                                   vstel = gt_prev_stage-vstez.
    ENDIF.
    IF lt_tvswz IS NOT INITIAL.
      LOOP AT gt_curr_stage.
        CLEAR gt_prev_stage.
        READ TABLE gt_prev_stage WITH KEY vbeln = gt_curr_stage-vbeln.
        IF sy-subrc NE 0.
          lv_skip = 'X'.    " Skip means not plant overflow scenario
          EXIT.
        ENDIF.
      ENDLOOP.
      LOOP AT gt_prev_stage.
        CLEAR gt_curr_stage.
        READ TABLE gt_curr_stage WITH KEY vbeln = gt_prev_stage-vbeln.
        IF sy-subrc NE 0.
          lv_skip = 'X'.    " Skip means not plant overflow scenario
          EXIT.
        ENDIF.
      ENDLOOP.
      IF lv_skip NE 'X'.
        ADD 1 TO cv_seqnm.
        LOOP AT gt_curr_stage.
          gt_stops-seqnm = cv_seqnm.
          gt_stops-stpty = 'PL'.
          MOVE-CORRESPONDING gt_curr_stage TO gt_stops.
          CLEAR gt_stops-vbeln.
          APPEND gt_stops.
        ENDLOOP.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    "check_overflow_scenario
*----------------------------------------------------------------------*
*       Form  fill_itineray_data
*----------------------------------------------------------------------*
* This form fills the Itinerary data based on the Stop data
*----------------------------------------------------------------------*
FORM fill_itineray_data .

  DATA : lt_stops       LIKE gt_stops OCCURS 0 WITH HEADER LINE,
         lt_stops_dest  LIKE gt_stops OCCURS 0 WITH HEADER LINE,
         lv_old_seqnm   LIKE gt_stops-seqnm,
         lv_old_stage   LIKE gt_stops-tsrfo,
         BEGIN OF lt_itnum OCCURS 0,
*           loc(10),                                        "E0VK946867
            loc(11),                                        "E0VK946867
         END OF lt_itnum.

  CONSTANTS : lc_itnum(10) TYPE c VALUE 'ABBCCDDEEF'.

  REFRESH lt_itnum.
  SORT gt_stops BY seqnm.

  lt_stops[]      = gt_stops[].
  lt_stops_dest[] = gt_stops[].
  DELETE lt_stops_dest WHERE stpty EQ 'CL' OR
                             stpty EQ 'PL' OR
                             stpty EQ space.
  SORT lt_stops_dest BY vbeln.

  LOOP AT gt_stops.
    IF lv_old_seqnm NE gt_stops-seqnm OR
       lv_old_stage NE gt_stops-tsrfo.
      lv_old_seqnm = gt_stops-seqnm.
      lv_old_stage = gt_stops-tsrfo.

      gs_itinerary-seqnm = gt_stops-seqnm.
      gs_itinerary-stpty = gt_stops-stpty.
      CASE gt_stops-loc_ind.
        WHEN 'P'. " Plant
          gs_itinerary-werks = gt_stops-location.
        WHEN 'S'. " Shipping Point
          gs_itinerary-vstel = gt_stops-location.
        WHEN 'C'. " Customer
          gs_itinerary-kunnr = gt_stops-location.
        WHEN 'V'. " Vendor
          gs_itinerary-lifnr = gt_stops-location.
      ENDCASE.
      gs_itinerary-tsnum = gt_stops-tsnum.
      gs_itinerary-tsrfo = gt_stops-tsrfo.
* >> Stage Origin/Destination indicator
      IF gt_stops-stpty EQ 'PL' OR gt_stops-stpty EQ 'CL'.
        gs_itinerary-stpod = 'O'.
      ELSEIF gt_stops-stpty EQ 'PU' OR gt_stops-stpty EQ 'CU'.
        gs_itinerary-stpod = 'D'.
      ENDIF.
*      gv_loc = gt_stops-location.
* >> Continuous moves to make ITNUM unique (A,B,C appending)
      CONCATENATE 'A' gt_stops-location INTO gt_stops-itnum.
* >> Translate the Itinerary Num to a unique number until you make it
*    unique in a Do-Loop.
      DO.
        READ TABLE lt_itnum WITH KEY loc = gt_stops-itnum.
        IF sy-subrc EQ 0.
          TRANSLATE gt_stops-itnum USING lc_itnum.
        ELSE.
          lt_itnum-loc = gt_stops-itnum.
          APPEND lt_itnum.
          CLEAR lt_itnum.
          EXIT.
        ENDIF.
      ENDDO.
      gs_itinerary-itnum = gt_stops-itnum.
      LOOP AT lt_stops WHERE seqnm EQ gs_itinerary-seqnm AND
                             tsrfo EQ gs_itinerary-tsrfo.   " TPR 30404
        IF lt_stops-vbeln IS INITIAL.
          CONTINUE.
        ENDIF.
        gs_deliveries-vbeln = lt_stops-vbeln.
* >> To get Destination Stop# and Destination Stage# on the deliveries
*    table per stop
        IF lt_stops-stpty EQ 'CL' OR lt_stops-stpty EQ 'PL'.
          READ TABLE lt_stops_dest WITH KEY vbeln = lt_stops-vbeln
                                            BINARY SEARCH.
          IF sy-subrc EQ 0.
*          LOOP AT lt_stops_dest WHERE vbeln EQ lt_stops-vbeln.
*            IF lt_stops_dest-stpty EQ 'CU' OR
*               lt_stops_dest-stpty EQ 'PU'.
            gs_deliveries-dstst = lt_stops_dest-seqnm.
            gs_deliveries-dstsg = lt_stops_dest-tsnum.      " TPR 30404
          ENDIF.
*          ENDLOOP.
        ELSEIF lt_stops-stpty EQ 'CU' OR lt_stops-stpty EQ 'PU'.
          gs_deliveries-dstst = lt_stops-seqnm.
          gs_deliveries-dstsg = lt_stops-tsnum.             " TPR 30404
        ENDIF.
        APPEND gs_deliveries TO gt_deliveries.
        CLEAR  gs_deliveries.
      ENDLOOP.
      gs_itinerary-deliveries[] = gt_deliveries[].
      APPEND  gs_itinerary TO gt_itinerary.
      CLEAR : gs_itinerary, gs_deliveries, gt_deliveries.
      REFRESH gt_deliveries.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " fill_itineray_data
*----------------------------------------------------------------------*
*       Form  fill_itineray_dates_times
*----------------------------------------------------------------------*
* This form determines the dates & times for every stop
*----------------------------------------------------------------------*
FORM fill_itineray_dates_times .

  DATA  : lv_vtts_extended.

  CLEAR : gv_vstel_count, gv_kunnr_count, gv_lifnr_count.

* >> Determine whether VTTS is populated with Z fields
  LOOP AT gt_vtts WHERE zz_itin_o IS NOT INITIAL .
    lv_vtts_extended = 'X'.
    EXIT.
  ENDLOOP.

* >> Get the first & last stop numbers
  PERFORM get_first_last_stop.

  READ TABLE gt_vttk INDEX 1.

  LOOP AT gt_itinerary.
    PERFORM determine_origin_count.
    READ TABLE gt_vtts WITH KEY tsnum = gt_itinerary-tsnum.
    IF lv_vtts_extended EQ 'X'.
* >> Complete/Partial Load - Origin
      IF gt_itinerary-stpty EQ 'CL' OR gt_itinerary-stpty EQ 'PL'.
        PERFORM arrival_gate_entry_date_time. " Arrival Gate/Entry
        PERFORM load_start_date_time.         " Load Start
        PERFORM load_end_date_time.           " Load End
        PERFORM gate_exit_date_time.          " Gate Exit
      ENDIF.  " Origin
* >> Complete/Partial Unload - Destination
      IF gt_itinerary-stpty EQ 'CU' OR gt_itinerary-stpty EQ 'PU'.
        PERFORM gate_entry_dest_arrival.  " Gate Entry at Dest./Arrvl
      ENDIF.    " Destination
    ELSE. " VTTS Extension is False
      IF gt_vtts-tsrfo EQ '0001'.
        PERFORM single_origin_legacy_dates.
      ENDIF.
    ENDIF.        " End of VTTS Extension
    gt_itinerary-date_time[] = gt_date_time[].
    MODIFY gt_itinerary.
    REFRESH gt_date_time.
    CLEAR   gt_date_time.
  ENDLOOP.        " End of Itinerary

ENDFORM.                    " fill_itineray_dates_times
*----------------------------------------------------------------------*
*       Form  determine_origin_count
*----------------------------------------------------------------------*
* This form gets the origin count that helps to determine the
* multi origin indicator
*----------------------------------------------------------------------*
FORM determine_origin_count .

  IF gt_itinerary-vstel IS NOT INITIAL.
    ADD 1 TO gv_vstel_count.
  ENDIF.
  IF gt_itinerary-kunnr IS NOT INITIAL.
    ADD 1 TO gv_kunnr_count.
  ENDIF.
  IF gt_itinerary-lifnr IS NOT INITIAL.
    ADD 1 TO gv_lifnr_count.
  ENDIF.

ENDFORM.                    " determine_origin_count
*----------------------------------------------------------------------*
*       Form  arrival_gate_entry_date_time
*----------------------------------------------------------------------*
* This form determines the Gate Entry dates & times
*----------------------------------------------------------------------*
FORM arrival_gate_entry_date_time .

* >> Forecast Pickup date/time
  IF gt_vtts-zz_f_pa_dt IS NOT INITIAL.
    gs_date_time-qualf = 'A10'.
    gs_date_time-ntanf  = gt_vtts-zz_f_pa_dt.
    gs_date_time-ntanz  = gt_vtts-zz_f_pa_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

* >> Pickup Appointment date/time
  IF gt_vtts-zz_e_pa_dt IS NOT INITIAL.
    IF gt_vtts-zz_pa_conf NE 'A' AND "OR
       gt_vtts-zz_pa_conf NE 'B' AND "OR
       gt_vtts-zz_pa_conf NE 'C'.
      gs_date_time-qualf = 'B10'.
    ELSEIF gt_vtts-zz_pa_conf EQ 'A' OR
           gt_vtts-zz_pa_conf EQ 'B' OR
           gt_vtts-zz_pa_conf EQ 'C'.
      gs_date_time-qualf = 'C10'.
    ENDIF.
    gs_date_time-ntanf  = gt_vtts-zz_e_pa_dt.
    gs_date_time-ntanz  = gt_vtts-zz_e_pa_ti.
    gs_date_time-ntend  = gt_vtts-zz_l_pa_dt.
    gs_date_time-ntenz  = gt_vtts-zz_l_pa_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

* >> Actual Gate Entry
  IF gt_vtts-zz_a_ge_dt IS NOT INITIAL.
    gs_date_time-qualf  = 'Z10'.
    gs_date_time-ntanf  = gt_vtts-zz_a_ge_dt.
    gs_date_time-ntanz  = gt_vtts-zz_a_ge_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

ENDFORM.                    " arrival_gate_entry_date_time
*----------------------------------------------------------------------*
*       Form  load_start_date_time
*----------------------------------------------------------------------*
* This form determines the Load Start dates & times
*----------------------------------------------------------------------*
FORM load_start_date_time .

* >> Planned Load Start Date
  IF gt_vtts-zz_p_ls_dt IS NOT INITIAL.
    gs_date_time-qualf  = 'C40'.
    gs_date_time-ntanf  = gt_vtts-zz_p_ls_dt.
    gs_date_time-ntanz  = gt_vtts-zz_p_ls_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'C40'.
    gs_date_time-ntanf  = gt_vttk-dplbg.
    gs_date_time-ntanz  = gt_vttk-uplbg.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

* >> Actual Load Start Date
  IF gt_vtts-zz_a_ls_dt IS NOT INITIAL.
    gs_date_time-qualf  = 'Z40'.
    gs_date_time-ntanf  = gt_vtts-zz_a_ls_dt.
    gs_date_time-ntanz  = gt_vtts-zz_a_ls_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'Z40'.
    gs_date_time-ntanf  = gt_vttk-dalbg.
    gs_date_time-ntanz  = gt_vttk-ualbg.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

ENDFORM.                    " load_start_date_time
*----------------------------------------------------------------------*
*       Form  load_end_date_time
*----------------------------------------------------------------------*
* This form determines the Load End dates & times
*----------------------------------------------------------------------*
FORM load_end_date_time.

* >> Planned Load End Date
  IF gt_vtts-zz_p_le_dt IS NOT INITIAL.
    gs_date_time-qualf  = 'C60'.
    gs_date_time-ntanf  = gt_vtts-zz_p_le_dt.
    gs_date_time-ntanz  = gt_vtts-zz_p_le_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'C60'.
    gs_date_time-ntanf  = gt_vttk-dplen.
    gs_date_time-ntanz  = gt_vttk-uplen.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

* >> Actual Load End Date
  IF gt_vtts-zz_a_le_dt IS NOT INITIAL.
    gs_date_time-qualf  = 'Z60'.
    gs_date_time-ntanf  = gt_vtts-zz_a_le_dt.
    gs_date_time-ntanz  = gt_vtts-zz_a_le_ti.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'Z60'.
    gs_date_time-ntanf  = gt_vttk-dalen.
    gs_date_time-ntanz  = gt_vttk-ualen.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

ENDFORM.                    "load_end_date_time
*----------------------------------------------------------------------*
*       Form  gate_exit_date_time
*----------------------------------------------------------------------*
* This form determines the Gate Exit dates & times
*----------------------------------------------------------------------*
FORM gate_exit_date_time.

* >> Planned Gate Exit Date
  IF gt_vtts-dptbg IS NOT INITIAL.
    gs_date_time-qualf  = 'C90'.
    gs_date_time-ntanf  = gt_vtts-dptbg.
    gs_date_time-ntanz  = gt_vtts-uptbg.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'C90'.
    gs_date_time-ntanf  = gt_vttk-dptbg.
    gs_date_time-ntanz  = gt_vttk-uptbg.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

* >> Actual Load End Date
  IF gt_vtts-datbg IS NOT INITIAL.
    gs_date_time-qualf  = 'Z90'.
    gs_date_time-ntanf  = gt_vtts-datbg.
    gs_date_time-ntanz  = gt_vtts-uatbg.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'Z90'.
    gs_date_time-ntanf  = gt_vttk-datbg.
    gs_date_time-ntanz  = gt_vttk-uatbg.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

ENDFORM.                    "gate_exit_date_time
*----------------------------------------------------------------------*
*       Form  gate_entry_dest_arrival
*----------------------------------------------------------------------*
* This form determines the Gate Entry Destination Arrival dates & times
*----------------------------------------------------------------------*
FORM gate_entry_dest_arrival.

* >> Delivery appointment
  IF gt_vtts-zz_f_see_dt      IS NOT INITIAL.
    IF gt_vtts-zz_cda_made_dt IS INITIAL.
      gs_date_time-qualf  = 'B10'.
    ELSE.
      gs_date_time-qualf  = 'C10'.
    ENDIF.
    gs_date_time-ntanf  = gt_vtts-zz_f_see_dt.
    gs_date_time-ntanz  = gt_vtts-zz_f_see_ti.
    gs_date_time-ntend  = gt_vtts-zz_f_sel_dt.
    gs_date_time-ntenz  = gt_vtts-zz_f_sel_ti.
    gs_date_time-tzonis = gt_vtts-zz_dest_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

* >> Planned/Del. Appointment
*  IF gt_vtts-dpten IS NOT INITIAL.
*    gs_date_time-qualf  = 'C10'.
*    gs_date_time-ntanf  = gt_vtts-dpten.
*    gs_date_time-ntanz  = gt_vtts-upten.
*    gs_date_time-tzonis = gt_vtts-zz_dest_tz.
*    APPEND gs_date_time TO gt_date_time.
*    CLEAR  gs_date_time.
*  ELSEIF gt_vtts-tsrfo EQ gv_last_stop.
*    gs_date_time-qualf  = 'C10'.
*    gs_date_time-ntanf  = gt_vttk-dpten.
*    gs_date_time-ntanz  = gt_vttk-upten.
*    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
*    APPEND gs_date_time TO gt_date_time.
*    CLEAR  gs_date_time.
*  ENDIF.

* >> Actual Shipment End Date
  IF gt_vtts-daten IS NOT INITIAL.
    gs_date_time-qualf  = 'Z10'.
    gs_date_time-ntanf  = gt_vtts-daten.
    gs_date_time-ntanz  = gt_vtts-uaten.
    gs_date_time-tzonis = gt_vtts-zz_dest_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ELSEIF gt_vtts-tsrfo EQ gv_first_stop.
    gs_date_time-qualf  = 'Z10'.
    gs_date_time-ntanf  = gt_vttk-daten.
    gs_date_time-ntanz  = gt_vttk-uaten.
    gs_date_time-tzonis = gt_vtts-zz_dep_tz.
    APPEND gs_date_time TO gt_date_time.
    CLEAR  gs_date_time.
  ENDIF.

ENDFORM.                    "gate_entry_dest_arrival
*----------------------------------------------------------------------*
*       Form  single_origin_legacy_dates
*----------------------------------------------------------------------*
* This form determines the Single Origin Legacy dates & times
*----------------------------------------------------------------------*
FORM single_origin_legacy_dates.

  DATA  : lv_likp_tzonis LIKE likp-tzonis.

  READ TABLE gt_vttp INDEX 1.

  SELECT SINGLE tzonis
         FROM   likp
         INTO   lv_likp_tzonis
         WHERE  vbeln EQ gt_vttp-vbeln.
  IF sy-subrc EQ 0.
    READ TABLE gt_vttk INDEX 1.
* >> Planned Load Start
    IF gt_vttk-dplbg IS NOT INITIAL.
* --- Forecast Gate Arrival
      gs_date_time-qualf  = 'A10'.
      gs_date_time-ntanf  = gt_vttk-dplbg.
      gs_date_time-ntanz  = gt_vttk-uplbg.
      gs_date_time-tzonis = lv_likp_tzonis.
      APPEND gs_date_time TO gt_date_time.

* --- Planned Gate Arrival
      gs_date_time-qualf  = 'B10'.
      APPEND gs_date_time TO gt_date_time.

* --- Forecast Load Start
      gs_date_time-qualf  = 'A40'.
      APPEND gs_date_time TO gt_date_time.

* -- Planned Load Start
      gs_date_time-qualf  = 'B40'.
      APPEND gs_date_time TO gt_date_time.
      CLEAR  gs_date_time.
    ENDIF.

* >> Actual Load Start
    IF gt_vttk-dalbg IS NOT INITIAL.
      gs_date_time-qualf  = 'Z40'.
      gs_date_time-ntanf  = gt_vttk-dalbg.
      gs_date_time-ntanz  = gt_vttk-ualbg.
      gs_date_time-tzonis = lv_likp_tzonis.
      APPEND gs_date_time TO gt_date_time.
      CLEAR gs_date_time.
    ENDIF.

* >> Planned Load End
    IF gt_vttk-dplen IS NOT INITIAL.
      gs_date_time-qualf  = 'B60'.
      gs_date_time-ntanf  = gt_vttk-dplen.
      gs_date_time-ntanz  = gt_vttk-uplen.
      gs_date_time-tzonis = lv_likp_tzonis.
      APPEND gs_date_time TO gt_date_time.
      CLEAR gs_date_time.
    ENDIF.

* >> Actual Load End
    IF gt_vttk-dalen IS NOT INITIAL.
      gs_date_time-qualf  = 'Z60'.
      gs_date_time-ntanf  = gt_vttk-dalen.
      gs_date_time-ntanz  = gt_vttk-ualen.
      gs_date_time-tzonis = lv_likp_tzonis.
      APPEND gs_date_time TO gt_date_time.
      CLEAR gs_date_time.
    ENDIF.

* >> Planned Gate Exit/Shipment Start
    IF gt_vttk-dptbg IS NOT INITIAL.
      gs_date_time-qualf  = 'B90'.
      gs_date_time-ntanf  = gt_vttk-dptbg.
      gs_date_time-ntanz  = gt_vttk-uptbg.
      gs_date_time-tzonis = lv_likp_tzonis.
      APPEND gs_date_time TO gt_date_time.
      CLEAR gs_date_time.
    ENDIF.

* >> Actual Gate Exit/Shipment Start
    IF gt_vttk-datbg IS NOT INITIAL.
      gs_date_time-qualf  = 'Z90'.
      gs_date_time-ntanf  = gt_vttk-datbg.
      gs_date_time-ntanz  = gt_vttk-uatbg.
      gs_date_time-tzonis = lv_likp_tzonis.
      APPEND gs_date_time TO gt_date_time.
      CLEAR gs_date_time.
    ENDIF.
  ENDIF.

ENDFORM.                    "single_origin_legacy_dates
*----------------------------------------------------------------------*
*       Form  get_first_last_stop
*----------------------------------------------------------------------*
* This form gets the First & Last Stops of the Itinerary
*----------------------------------------------------------------------*
FORM get_first_last_stop .

* >> Get the First & Last stop of the Itinerary
  SORT gt_itinerary BY seqnm DESCENDING.
  READ TABLE gt_itinerary INDEX 1.
  gv_last_stop = gt_itinerary-seqnm.

  SORT gt_itinerary BY seqnm.
  READ TABLE gt_itinerary INDEX 1.
  gv_first_stop = gt_itinerary-seqnm.

ENDFORM.                    " get_first_last_stop
*----------------------------------------------------------------------*
*       Form  determine_mos_indicator
*----------------------------------------------------------------------*
* This form determines the Multi Origin Indicator
*----------------------------------------------------------------------*
FORM determine_mos_indicator .

  CLEAR gv_mos_ind.

*>> Add up shipping points and customer numbers to determine the result.
  IF gv_vstel_count EQ 1.
    IF gv_kunnr_count EQ 1.
      gv_mos_ind = 1.
    ENDIF.
    IF gv_kunnr_count GT 1.
      gv_mos_ind = 3.
    ENDIF.
  ENDIF.

  IF gv_vstel_count GT 1.
    IF gv_kunnr_count EQ 1.
      gv_mos_ind = 2.
    ENDIF.
    IF gv_kunnr_count GT 1.
      gv_mos_ind = 4.
    ENDIF.
  ENDIF.

ENDFORM.                    " determine_mos_indicator

************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2007                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: VTTS Z TRANSCATION              Create Date: 05/14/07  *
*                                                                      *
* SAP Name    : Z03732_VTTS_Z_TRANSCATION_F01        Version    :      *
*                                                                      *
* Programmer  : Naveen Parchuri                                        *
*______________________________________________________________________*

* Change History:                                                     *
*     Programmer        Date     Req. #            Action              *
* ==================  ========   ======  ==============================*
*  Naveen Parchuri    11/08/07 EDVK958506  TPR-21257, Descriptions not *
*                                         showing correctly . added    *
*                                         option sy-langu in the select*
* Padma Sunkara       03/26/08 EDEK911301 Enchanced Big-Button        *
*                                         functionality for            *
*                                         Pick-Pack-VTTSTXN-D004       *
*                                         Print BOL-VTTSTXN-D005       *
*                                         Gate-Exit-VTTSTXN-D006       *
*
*Pick-Pack button should initiate a series of pre-defined steps        *
*for the origin of the current stage including: set load start         *
*(if not already load started and launch custom transaction for        *
*picking and packing of the deliveries on a shipment.                  *
*Bill of lading button should initiate a series of pre-defined steps   *
*for the origin of the current stage including: set load end (if not   *
* already load end and print bill of lading output and print packing   *
* list output.                                                         *
* Gate-Exit button should initiate a process for gate-exit,when user   *
* presses this button, the program should check that the user has      *
* security to change shipments and associated with making changes      *
* at the given origin of the identified stage. If not,the user should  *
* be warned that they don't have sufficient privileges.                *
*                                                                      *
* Kishor Thakur      08/12/08  CR-8022  - Implemented gate Exit       *
*                               Reversal logic for external and Z03732 *
*                               Added a Reverse button in screen 303   *
*                               for gate-exit reversal.                *
*                               Transport# EDEK912945                  *
*                               Transport# EDEK913754                  *
* Kishor Thakur/Padma Sunkara  11/05/08  pricef  -E07126, E07127      *
*                               Added functionality for updating dock  *
*                               and trailer id(container id) in        *
*                               screen 303 and in screen 304 added     *
*                               the functionality to capture the intent*
*                               if the user is requested or confirmed  *
*                               and set the code for qualifier         *
*                               accordingly(i.e.IDOC for behalf of     *
*                               distribution center in pickup          *
*                               appointment date/time window.          *
*                               Transport# ESBK9A07VO
* Padma Sunkara                 03/25/2009  CR 8887                    *
*                               Transport# EDVK969541
*                               Validation of Dilveries/HU's pick pack
*                               before BOL.
* Kishor Thakur                 TPR# 03495 Tr#EDVK969962  kthakur+
*                               Added sy-zonlo to ship start time
*                               and Ship end time to calculate proper
*                               time according to Departing time zone
*                               of the stage
* Kishor Thakur                 TPR# 31735   TR# E0VK950315  Repack
*                               Authorization check at Plant level
*                               when "CHANGE" button pressed.
* Kishor Thakur                 TPR# 32023 TR# EDVK971306
*                               Transaction Z03732 sometimes blocks the
*                               user from entering Change mode on their
*                               leg of a multi-origin shipment.
*                               Clear/Refresh internal table
*                               gt_stages_valid.
* Kishor Thakur                 CHG102464 TR#E0VK952755
*                               Error while printing V2 Ship Packing
*                               List 'DC' plant validation.
* Padma Sunkara                 08/26/09 TR# EDVK973207 R15  CR# 9246
*                               Printing ZCCI outputthrough
*                               Big Button (Z03732)
* Kishor Thakur/Padma Sunkara  Begin of R16I Big Button Update Staging *
*                              Area changes 10/13/09                   *
* Mallik Aiely                 CMS29557:CHG179961:E03732:Big button    *
*                              export validation - 2/1/2016            *
* Sukanya      11/2/2017       CMS#32822: Big button heuristic         *
*                              protection checkbox updation.           *
* Sukanya      04/2/2018       CMS#33493: Heuristic protection checkbox*
*                              Production fix-Icon change              *
* Helena Malkowska  11/2018    E0V34502: Add validation to Container ID*
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  prepare_control
*&---------------------------------------------------------------------*


FORM prepare_control .

* create the container & grid
  IF go_custom_container IS NOT BOUND.
    CREATE OBJECT go_custom_container
      EXPORTING
        container_name = gv_container.
    CREATE OBJECT go_grid
      EXPORTING
        i_parent = go_custom_container.
* build the fieldcatalog
    PERFORM build_fieldcat USING 'GT_STAGES_FINAL'.

** to get the grey background color
******************************************************************
* The default background color of the alv grid is white,even
* when it is in the display mode .  the user wanted it to be
* grey in color . to get that we have made the field TSNUM
* as editable in field catalog. once we do that all the fields
* except tsnum will get grey color . now to make the tsnum fiels
* as display only we use the below perform
*******************************************************************
    PERFORM set_style.

* Build Layout
    PERFORM sub_build_layout.

* set table for display
    CALL METHOD go_grid->set_table_for_first_display
      EXPORTING
        i_bypassing_buffer            = 'X'
        is_layout                     = gs_layout
      CHANGING
        it_outtab                     = gt_stages_final[]
        it_fieldcatalog               = gt_fieldcat
      EXCEPTIONS
        invalid_parameter_combination = 1
        program_error                 = 2
        too_many_lines                = 3
        OTHERS                        = 4.

* Create Object to receive events and link them to handler methods.
    CREATE OBJECT event_receiver.
    SET HANDLER event_receiver->handle_double_click FOR go_grid.
  ELSE.
** perform set style
    PERFORM set_style.
    CALL METHOD go_grid->refresh_table_display.
  ENDIF.
ENDFORM.                    " prepare_control

*&      Form  create_custom_control
*&---------------------------------------------------------------------*
*&      Form  VALIDATIONS
*&---------------------------------------------------------------------*
FORM validations .

* check for authorization for display
  IF gv_tsnum IS INITIAL.                                   "BCB01
    gv_code = 'VT03N'.
* Begin BCB01
* If gv_tsnum (a non-display Shipment Stage field on screen 0100)
* has a value then we know we've come into this program from a
* calling program (ie Daily Shipping Report R02740) and we want to
* come in Change mode so we have to make sure the user has change
* authorization.
  ELSE.
    gv_code = 'VT02N'.
  ENDIF.
* End BCB01

* check authority
  PERFORM authority_check USING gv_code .
  CLEAR gv_code.
  CLEAR gv_tknum.
*Begin of change CMS#32822

  CLEAR :vttk-zz_heur_protect, gv_heur_protect.
  SELECT SINGLE zz_heur_protect FROM vttk INTO vttk-zz_heur_protect
  WHERE tknum = vttk-tknum.
  gv_heur_protect = vttk-zz_heur_protect.
*End of change "CMS#32822
* check for blank shipment number
  IF vttk-tknum IS INITIAL.
    MESSAGE e000(zsd_dl) WITH 'Please enter shipment number'(035).
  ENDIF.

* check for shipment
  SELECT SINGLE tknum INTO gv_tknum
   FROM  vttk
   WHERE tknum = vttk-tknum .
  IF sy-subrc <> 0 .
    MESSAGE e000(zsd_dl) WITH 'Shipment'(001)
                      vttk-tknum
                      'is not available in the database'(002).
  ELSE.
    IF gv_tsnum IS INITIAL.                                 "BCB01
      CALL SCREEN 0200.
*   Begin BCB01
*   If gv_tsnum has a value then we know we've come into this program
*   from an external program and we want to go skip screen 0200 and
*   go directly to screen 0300.
    ELSE.

*     Perform this PBO 0100 subroutine
      PERFORM get_data. "retrieve shipment header and stage data

*     Perform certain functions of   get_data_change

*     Perform certain functions of 0200 PAI subroutine get_data_change
      PERFORM lock_shipment.
      CLEAR gv_code.
      gv_change = 'X'.     "set Change mode ON
      gv_display = space.  "set Display mode OFF

      READ TABLE gt_stages_final INDEX 1.
      IF gt_stages_final-tsnum IS NOT INITIAL.
        APPEND gt_stages_final TO gt_stages_valid .
      ENDIF.
      CLEAR gt_stages_final.

*     Default the 0300 subscreen to Dispatch subscreen 0303
      g_tc_chg1_master-pressed_tab = c_tc_chg1_master-tab3.

*     Initialize Dispatch Screen 0303 header fields and
*     retrieve current Stage information and store it
      PERFORM set_header_fields_init.

      CALL SCREEN 0300. "Stage info
    ENDIF.
*   End BCB01

  ENDIF.

ENDFORM.                    " VALIDATIONS
*&---------------------------------------------------------------------*
*&      Form  get_data
*&---------------------------------------------------------------------*
FORM get_data .
*get header details
  PERFORM get_header_information.
* get stage details
  PERFORM get_stage_information.

ENDFORM.                    " get_data
*&---------------------------------------------------------------------*
*&      Form  get_header_information
*&---------------------------------------------------------------------*
FORM get_header_information .
  CLEAR : vttk,
          tvtkt,
          lfa1,
          tvsbt,
          ttdst.

* get the shipment details from vttk
  SELECT SINGLE * FROM vttk INTO vttk
      WHERE tknum = gv_tknum.

* to get shipment type desc
  SELECT SINGLE bezei FROM  tvtkt
      INTO tvtkt-bezei
      WHERE spras = sy-langu AND
            shtyp = vttk-shtyp.

* to get forwarding agent name
  SELECT SINGLE name1
                scacd
                adrnr FROM lfa1
      INTO (lfa1-name1, lfa1-scacd , lfa1-adrnr)
       WHERE lifnr = vttk-tdlnr.

* to get shipping condition descp
  SELECT SINGLE vtext FROM tvsbt
       INTO tvsbt-vtext
       WHERE spras = sy-langu AND
             vsbed = vttk-vsbed.

*to get transportation planning point desc
  SELECT SINGLE bezei FROM ttdst
       INTO ttdst-bezei
        WHERE spras = sy-langu AND
              tplst = vttk-tplst.
*to get description for MOS indicator
  CLEAR des_mos.
  CASE vttk-vlstk.
    WHEN 1.
      des_mos = 'Single Origin, Single Destination'.
    WHEN 2.
      des_mos = 'Multiple Origin, Single destination'.
    WHEN 3.
      des_mos = 'Single Origin, Multiple Destination'.
    WHEN 4.
      des_mos = 'Multiple Origin, Multiple Destination'.
  ENDCASE.
ENDFORM.                    " get_header_information
*&---------------------------------------------------------------------*
*&      Form  get_stage_information
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_stage_information .

  DATA : ls_stages       LIKE LINE OF gt_stages,
         ls_stages_final LIKE LINE OF gt_stages_final,
         lv_sttrg(10).
  REFRESH gt_stages.
  REFRESH gt_stages_final.
  REFRESH gt_stages.

* get  stages details from vtts
  SELECT tsnum
         tsrfo
         vstel
         lifna
         kunna
         vstez
         lifnz
         kunnz
         zz_sttrg
         zz_stoptype_o
         zz_stoptype_d
        FROM  vtts
   INTO TABLE gt_stages
   WHERE tknum = vttk-tknum.
  IF sy-subrc <> 0 .
    MESSAGE s000(zsd_dl) WITH 'No stages exist for the'(003)
                              'shipment number'(004)
                               vttk-tknum.
  ELSE.
    SORT gt_stages BY tsrfo.
  ENDIF.

* Begin BCB01
* If a Shipment Stage was passed in then only keep this stage
  IF gv_tsnum IS NOT INITIAL.
    DELETE gt_stages WHERE tsnum NE gv_tsnum.
  ENDIF.
* End BCB01

*move the data to the final table
  LOOP AT gt_stages INTO ls_stages.
* sending in leading zeroes
    IF ls_stages-tsnum IS NOT INITIAL.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = ls_stages-tsnum
        IMPORTING
          output = ls_stages-tsnum.
    ENDIF.

    ls_stages_final-tsnum  = ls_stages-tsnum.

* check for departure point
* when plant
    IF  ls_stages-vstel  <> space.
      ls_stages_final-dep_point = ls_stages-vstel.
      SELECT SINGLE vtext INTO ls_stages_final-dep_point_desc
        FROM tvstt
        WHERE spras = sy-langu AND
              vstel = ls_stages-vstel.
* when customer
    ELSEIF ls_stages-kunna  <> space.

      SELECT SINGLE name1 INTO ls_stages_final-dep_point_desc
        FROM kna1
        WHERE kunnr = ls_stages-kunna.
      CONDENSE ls_stages-kunna.
* conversion exit
      PERFORM conv_exit USING ls_stages-kunna.
      ls_stages_final-dep_point = ls_stages-kunna.
* when vendor
    ELSEIF ls_stages-lifna  <> space.
      SELECT SINGLE name1 INTO ls_stages_final-dep_point_desc
        FROM lfa1
        WHERE lifnr = ls_stages-lifna.
      PERFORM conv_exit USING ls_stages-lifna.
      ls_stages_final-dep_point = ls_stages-lifna.

    ENDIF.

* check for destination point
    IF  ls_stages-vstez <> space.
* when plant
      ls_stages_final-des_point = ls_stages-vstez.
      SELECT SINGLE vtext INTO ls_stages_final-des_point_desc
        FROM tvstt
        WHERE spras = sy-langu AND
              vstel = ls_stages-vstez.
* when customer
    ELSEIF ls_stages-kunnz <> space.

      SELECT SINGLE name1 INTO ls_stages_final-des_point_desc
        FROM kna1
        WHERE kunnr = ls_stages-kunnz.
      PERFORM conv_exit USING ls_stages-kunnz.
      ls_stages_final-des_point = ls_stages-kunnz.

* when vendor
    ELSEIF ls_stages-lifnz <> space.

      SELECT SINGLE name1 INTO ls_stages_final-des_point_desc
        FROM lfa1
        WHERE lifnr = ls_stages-lifnz.
      PERFORM conv_exit USING ls_stages-kunnz.
      ls_stages_final-des_point = ls_stages-lifnz.

    ENDIF.
* transportation status
    ls_stages_final-sttrg = ls_stages-sttrg.
    IF ls_stages_final-sttrg <> space.
      lv_sttrg = ls_stages_final-sttrg.
      CONDENSE lv_sttrg.

* get the domain textx for trn. status
      CALL FUNCTION 'RV_DOMAIN_VALUE_TEXTS'
        EXPORTING
          domname  = 'STTRG'
          domvalue = lv_sttrg
          single   = 'X'
        IMPORTING
          ddtext   = ls_stages_final-stage_desc.
    ENDIF.
    ls_stages_final-dep_stop  = ls_stages-zz_stoptype_o.
    ls_stages_final-des_stop  = ls_stages-zz_stoptype_d.
    APPEND ls_stages_final TO gt_stages_final.
  ENDLOOP.

  CLEAR ls_stages_final.

* check for number of lines to fill up the screen
* in case there are less then 6 lines
  DATA : lv_lines TYPE i,
         lv_do    TYPE i.
  DESCRIBE TABLE gt_stages_final LINES lv_lines.
  IF lv_lines LT 6.
    lv_do =  6 - lv_lines.
    DO lv_do TIMES.
      APPEND ls_stages_final TO gt_stages_final.
    ENDDO.
  ENDIF.
ENDFORM.                    " get_stage_information
*&---------------------------------------------------------------------*
*&      Form  build_fieldcat
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM build_fieldcat  USING pv_inttab TYPE  slis_tabname.

  CLEAR gt_reuse_fcat.
  CLEAR gw_fieldcat.
  REFRESH gt_reuse_fcat.
  REFRESH gt_fieldcat.

* stage
  gw_fieldcat-col_pos   = 1.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'TSNUM'.
  gw_fieldcat-scrtext_s = 'Stage'(005).
  gw_fieldcat-scrtext_m = 'Stage'(005).
  gw_fieldcat-scrtext_l = 'Stage'(005).
  gw_fieldcat-edit = 'X'.
  gw_fieldcat-outputlen =  5.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.

* departure point
  gw_fieldcat-col_pos   = 2.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'DEP_POINT'.
  gw_fieldcat-scrtext_s = 'Departure'(006).
  gw_fieldcat-scrtext_m = 'Departure Point'(007).
  gw_fieldcat-scrtext_l = 'Departure Point'(007).
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.

* departure description
  gw_fieldcat-col_pos   = 3.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'DEP_POINT_DESC'.
  gw_fieldcat-scrtext_s = 'Description'(008).
  gw_fieldcat-scrtext_m = 'Description'(008).
  gw_fieldcat-scrtext_l = 'Description'(008).
  gw_fieldcat-outputlen =  25.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.

* departure stop type
  gw_fieldcat-col_pos   = 4.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'DEP_STOP'.
  gw_fieldcat-scrtext_s = 'Dep. Type'(023).
  gw_fieldcat-scrtext_m = 'Dep. Type'(023).
  gw_fieldcat-scrtext_l = 'Departure Type'(024).
  gw_fieldcat-outputlen =  8.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.


* destination point
  gw_fieldcat-col_pos   = 5.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'DES_POINT'.
* gw_fieldcat-scrtext_s = 'Destination'(040).
  gw_fieldcat-scrtext_m = 'Destination'(040).
* gw_fieldcat-scrtext_m = 'Destination Point'(010).
  gw_fieldcat-scrtext_l = 'Destination Point'(010).
  gw_fieldcat-outputlen =  12.
*  gw_fieldcat-emphasize = 'C200' .
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.

* destination point description
  gw_fieldcat-col_pos   = 6.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'DES_POINT_DESC'.
  gw_fieldcat-scrtext_s = 'Description'(008).
  gw_fieldcat-scrtext_m = 'Description'(008).
  gw_fieldcat-scrtext_l = 'Description'(008).
  gw_fieldcat-outputlen =  25.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.

* destination stop type
  gw_fieldcat-col_pos   = 7.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'DES_STOP'.
  gw_fieldcat-scrtext_s = 'Des. Type'(025).
  gw_fieldcat-scrtext_m = 'Des. Type'(025).
  gw_fieldcat-scrtext_l = 'Destination Type'(026).
  gw_fieldcat-outputlen =  8.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.

* transportation status
  gw_fieldcat-col_pos   = 8.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'STTRG'.
  gw_fieldcat-scrtext_s = 'Status'(011).
  gw_fieldcat-scrtext_m = 'Transp. Status'(012).
  gw_fieldcat-scrtext_l = 'Transportation Status'(013).
  gw_fieldcat-outputlen =  5.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.


* transportation status description
  gw_fieldcat-col_pos   = 9.
  gw_fieldcat-row_pos   = 1.
  gw_fieldcat-fieldname = 'STAGE_DESC'.
  gw_fieldcat-scrtext_s = 'Description'(008).
  gw_fieldcat-scrtext_m = 'Description'(008).
  gw_fieldcat-scrtext_l = 'Description'(008).
  gw_fieldcat-outputlen =  20.
  APPEND gw_fieldcat TO gt_fieldcat.
  CLEAR gw_fieldcat.


ENDFORM.                    " build_fieldcat

*&---------------------------------------------------------------------*
*&      Form  sub_build_layout
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM sub_build_layout .
  CLEAR gs_layout.
  gs_layout-no_toolbar   = 'X'.
  gs_layout-sel_mode = 'A'.
  gs_layout-stylefname = 'CELLTAB'.
ENDFORM.                    " sub_build_layout
*&---------------------------------------------------------------------*
*&      Form  get_addr_details
*&---------------------------------------------------------------------*
*       text
FORM get_addr_details .
  DATA: lt_handle_tab LIKE addr1_dia OCCURS 0 WITH HEADER LINE.

  lt_handle_tab-addrnumber = lfa1-adrnr.

  lt_handle_tab-maint_mode = 'DISPLAY'.

  APPEND lt_handle_tab.
  CALL FUNCTION 'ADDR_DIALOG'
    TABLES
      number_handle_tab = lt_handle_tab
    EXCEPTIONS
      address_not_exist = 1
      group_not_valid   = 2
      parameter_error   = 3
      internal_error    = 4
      OTHERS            = 5.

ENDFORM.                    " get_addr_details
*&---------------------------------------------------------------------*
*&      Form  get_status_icon
*&---------------------------------------------------------------------*
*       text
***********************************************************************
FORM get_status_icon .
  DATA: lv_icon_name(20),
        lv_icon TYPE string.
* building up the icons for trns. status
  CASE vttk-sttrg.
    WHEN '0'.
      lv_icon_name = 'ICON_LIGHT_OUT'.
    WHEN '1'.
      lv_icon_name = 'ICON_RED_LIGHT'.
    WHEN '2'.
      lv_icon_name = 'ICON_YELLOW_LIGHT'.
    WHEN '3'.
      lv_icon_name = 'ICON_YELLOW_LIGHT'.
    WHEN '4'.
      lv_icon_name = 'ICON_YELLOW_LIGHT'.
    WHEN '5'.
      lv_icon_name = 'ICON_GREEN_LIGHT'.
    WHEN '6'.
      lv_icon_name = 'ICON_GREEN_LIGHT'.
    WHEN '7'.
      lv_icon_name = 'ICON_GREEN_LIGHT'.
  ENDCASE.

* setting the icon
  IF lv_icon_name <> space.
    CALL FUNCTION 'ICON_CREATE'
      EXPORTING
        name       = lv_icon_name
        add_stdinf = ' '
      IMPORTING
        result     = lv_icon.
    rv56a-trg_ampel = lv_icon.

  ENDIF.
ENDFORM.                    " get_status_icon
*&---------------------------------------------------------------------*
*&      Form  get_changes_history
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_changes_history .

  DATA: seltab    TYPE TABLE OF rsparams,
        seltab_wa LIKE LINE OF seltab,
        lv_repid  LIKE sy-repid.

* check for shipment number not blank
  IF vttk-tknum IS INITIAL.
    MESSAGE e000(zsd_dl) WITH 'Please enter shipment number'(035).
  ENDIF.


* check for existence of the shipment
  SELECT SINGLE tknum INTO gv_tknum
   FROM  vttk
   WHERE tknum = vttk-tknum .
  IF sy-subrc <> 0 .
    MESSAGE e000(zsd_dl) WITH 'Shipment'(001)
                      vttk-tknum
                      'is not available in the database'(002).
  ENDIF.

* check for authority
  CALL FUNCTION 'AUTHORITY_CHECK_TCODE'
    EXPORTING
      tcode  = 'VT22'
    EXCEPTIONS
      ok     = 0
      not_ok = 2
      OTHERS = 3.
  IF sy-subrc <> 0.
    MESSAGE e172(00) WITH 'VT22'.
  ENDIF.


*get the selection parameter
  MOVE 'TPSTSHOW_LISTVIEW' TO lv_repid.
  CALL FUNCTION 'RS_REFRESH_FROM_SELECTOPTIONS'
    EXPORTING
      curr_report     = lv_repid
    TABLES
      selection_table = seltab
    EXCEPTIONS
      not_found       = 1
      no_report       = 2
      OTHERS          = 3.
  IF sy-subrc <> 0.
  ENDIF.


  IF seltab[] IS NOT INITIAL.
    LOOP AT seltab INTO seltab_wa.
      CASE seltab_wa-selname.

        WHEN 'G_USER'.
          seltab_wa-sign = 'I'.
          seltab_wa-option = 'CP'.
          seltab_wa-low = '*'.

        WHEN 'OBJECT'.
          seltab_wa-sign = 'I'.
          seltab_wa-option = 'EQ'.
          seltab_wa-low = vttk-tknum.
          seltab_wa-high = space.

      ENDCASE.
      MODIFY seltab FROM seltab_wa.
    ENDLOOP.

*  Submit program .
    SUBMIT tpstshow_listview
           WITH  SELECTION-TABLE seltab
           AND RETURN.
  ENDIF.

ENDFORM.                    " get_changes_history
*&---------------------------------------------------------------------*
*&      Form  get_data_change
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_data_change .
*  DATA: lt_rows TYPE lvc_t_row,
  DATA : lt_rows          TYPE lvc_t_roid,
         lt_cell          TYPE lvc_t_cell,
         ls_selected_line LIKE lvc_s_roid,
         ls_selected_cell TYPE lvc_s_cell,
         ls_selected_row  TYPE lvc_s_row,
         lv_rows          TYPE i,
         lv_vstel         TYPE vstel .     "TPR# 31735    kthakur+

  IF sy-ucomm = 'CHNG'.
    gv_code = 'VT02N'.
* check authority
    PERFORM authority_check USING gv_code .
* lock shipment.
    PERFORM lock_shipment .
    CLEAR gv_code.
* set the variale for change or display
    gv_change = 'X'.
  ELSE.
    gv_display = 'X'.
  ENDIF.


* Get the row-ids of the selected records
  CALL METHOD go_grid->get_selected_rows
    IMPORTING
      et_row_no = lt_rows.


* Read those records from GT_LIST
  DESCRIBE TABLE lt_rows LINES lv_rows.
  IF lv_rows GT 0 .
    LOOP AT lt_rows INTO ls_selected_line.
      READ TABLE gt_stages_final
            INDEX ls_selected_line-row_id.

      IF gt_stages_final-tsnum IS NOT INITIAL.
        APPEND gt_stages_final TO gt_stages_valid .
      ENDIF.

      CLEAR gt_stages_final.
      CLEAR ls_selected_line.
    ENDLOOP.
  ELSE.
* check position of cursor on a cell in the grid
    CALL METHOD go_grid->get_selected_cells
      IMPORTING
        et_cell = lt_cell.
    READ TABLE lt_cell INTO ls_selected_cell INDEX 1.
    MOVE ls_selected_cell-row_id TO ls_selected_row.
    READ TABLE gt_stages_final
          INDEX ls_selected_row-index.
    IF gt_stages_final-tsnum IS NOT INITIAL.
      APPEND gt_stages_final TO gt_stages_valid .
    ELSE.
      MESSAGE s000(zsd_dl) WITH 'Select atleast one record'(014)
                                'to process'(015).

    ENDIF.
  ENDIF.
* begin insert TPR# 31735   TR# E0VK950315   kthakur  Repack
  IF sy-ucomm = 'CHNG'.
    LOOP AT gt_stages_valid .
      IF ( gt_stages_valid-dep_stop = 'CL' )
          OR
         ( gt_stages_valid-dep_stop = 'PL' ).
        MOVE gt_stages_valid-dep_point TO lv_vstel.
        CLEAR gv_stage_authority.
        PERFORM authority_check_stage USING lv_vstel
                                CHANGING gv_stage_authority.
      ENDIF.
    ENDLOOP.
    CLEAR gv_stage_authority.
  ENDIF.
* End insert TPR# 31735 TR# E0VK950315   kthakur
  IF gt_stages_valid[] IS NOT INITIAL.
    gv_index = 1 .
    CALL SCREEN 0300.
  ENDIF.


ENDFORM.                    " get_data_change
*&---------------------------------------------------------------------*
*&      Form  set_header_fields
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM set_header_fields .

* if user has hit enter or not used cancel button or
* not used the validation button
  IF ( sy-ucomm <> 'ENTR' AND
       gv_answer <> 'A' AND
       sy-ucomm <> 'CHK1' AND
       sy-ucomm <> 'CHK2' AND
       sy-ucomm <> 'CHK3' ).

*   Begin BCB01
*   Header Field intialization must be upfront when coming in from the
*   DSR (Daily Shipping Report) regardless of what the sy-ucomm is.
*   This is why the logic is being extracted from this subrouting
*   and moved into new subroutine set_header_fields_init.
    PERFORM set_header_fields_init.
*   End BCB01
    " PERFORM get_dock_door_data.
  ENDIF.

  PERFORM get_dock_door_data.

  CLEAR gv_answer.

ENDFORM.                    " set_header_fields
*&---------------------------------------------------------------------*
*&      Form  authority_check
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM authority_check USING gv_code.
* check for authorization
  CALL FUNCTION 'AUTHORITY_CHECK_TCODE'
    EXPORTING
      tcode  = gv_code
    EXCEPTIONS
      ok     = 0
      not_ok = 2
      OTHERS = 3.
  IF sy-subrc <> 0.
    IF gv_code = 'VT02N'.
      MESSAGE s000(zsd_dl) WITH 'No authorization to change'(016)
                        'the records'(017).
    ELSE.
      MESSAGE s000(zsd_dl) WITH 'You are not authorized to use'(038)
                                'this transcation'(039).

    ENDIF.
    gv_display = 'X'.

  ENDIF.

ENDFORM.                    " authority_check
*&---------------------------------------------------------------------*
*&      Form  lock_shipment
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM lock_shipment .
  DATA : lv_uzeit  LIKE sy-uzeit,
         lv_uzeit1 LIKE sy-uzeit.
  CLEAR gv_user.
  lv_uzeit1 = sy-uzeit + 10.

* if we are locking the shipment from second screen
* no need to wait
  IF gv_code = 'VT02N'.
    CALL FUNCTION 'ENQUEUE_EVVTTKE'
      EXPORTING
        tknum          = vttk-tknum
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
  ELSE.
* if we are locking the shipment after th FM has been run we
* need to try till the shipment is locked as there will some
* delay for the shipment to be unlocked by the FM
* lock the shipment
    DO.
      WAIT UP TO 1 SECONDS.
      lv_uzeit = sy-uzeit.
      CALL FUNCTION 'ENQUEUE_EVVTTKE'
        EXPORTING
          tknum          = vttk-tknum
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc = 0 .
        EXIT.
      ENDIF.
    ENDDO.
  ENDIF.

  CASE sy-subrc .
    WHEN 1.
      WRITE sy-msgv1 TO gv_user.
      MESSAGE e000(zsd_dl) WITH 'Shipment'(001)
                                 vttk-tknum
              'is currently being processed by user'(018)
                                 gv_user.
    WHEN 2.

      MESSAGE e000(zsd_dl) WITH 'Shipment'(001)
                                 vttk-tknum
                               'is locked due to system failure'(019).
    WHEN 3.
      MESSAGE e000(zsd_dl) WITH 'Shipment'(001)
                                 vttk-tknum
                               'is locked'(020).
  ENDCASE.

* lock the deliveries
  PERFORM lock_deliveries.
ENDFORM.                    " lock_shipment
*&---------------------------------------------------------------------*
*&      Form  lock_deliveries
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM lock_deliveries .
  CLEAR gv_user.
  CLEAR gt_vttp.
  REFRESH gt_vttp.
* get the deliveries assocaiated with tknum
  SELECT vbeln FROM vttp
     INTO TABLE gt_vttp
     WHERE tknum = vttk-tknum.

* lock all the deliveries
  IF sy-subrc = 0 .
    LOOP AT gt_vttp.
      CALL FUNCTION 'ENQUEUE_EVVBLKE'
        EXPORTING
          mandt          = sy-mandt
          vbeln          = gt_vttp-vbeln
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.

      IF sy-subrc <> 0.
        CASE sy-subrc.
          WHEN 1.
            WRITE sy-msgv1 TO gv_user.
* dequeue the deliveries
            CALL FUNCTION 'DEQUEUE_EVVTTKE'
              EXPORTING
                tknum = vttk-tknum.
            MESSAGE e000(zsd_dl) WITH 'Deleveries'(021)
                                       gt_vttp-vbeln
                    'is currently being processed by user'(018)
                                       gv_user.
          WHEN 2.
            CALL FUNCTION 'DEQUEUE_EVVTTKE'
              EXPORTING
                tknum = vttk-tknum.


            MESSAGE e000(zsd_dl) WITH 'Deleveries'(021)
                                       gt_vttp-vbeln
                                 'is locked due to system failure'(019).
          WHEN 3.
            CALL FUNCTION 'DEQUEUE_EVVTTKE'
              EXPORTING
                tknum = vttk-tknum.

            MESSAGE e000(zsd_dl) WITH 'Deleveries'(021)
                                       gt_vttp-vbeln
                                        'is locked'(020).
        ENDCASE.
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " lock_deliveries
*&---------------------------------------------------------------------*
*&      Form  unlock_shipment
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM unlock_shipment .

  IF gv_change =  'X'.
* unlock shipment.
    CALL FUNCTION 'DEQUEUE_EVVTTKE'
      EXPORTING
        tknum = vttk-tknum.
* unlock deliveries.
    LOOP AT gt_vttp.
      CALL FUNCTION 'DEQUEUE_EVVBLKE'
        EXPORTING
          mandt = sy-mandt
          vbeln = gt_vttp-vbeln.

    ENDLOOP.
  ENDIF.
ENDFORM.                    " unlock_shipment
*&---------------------------------------------------------------------*
*&      Form  popup_to_confirm
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM popup_to_confirm .
* popup to confirm
* check for the following values have been changed
* planned estimate date of arrivial and time
* actual date and time for end of shipment

  IF   gv_display <> 'X'.

    IF vtts-zz_eta_dt      <> gt_vtts_old-zz_eta_dt       OR
       vtts-zz_eta_ti+0(4) <> gt_vtts_old-zz_eta_ti+0(4)  OR
       vtts-daten          <> gt_vtts_old-daten           OR
       vtts-uaten+0(4)     <> gt_vtts_old-uaten+0(4).
      CLEAR gv_answer.
* confirmation
      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          text_question         = TEXT-022
          text_button_1         = 'Yes'
          text_button_2         = 'No'
          default_button        = '2'
          display_cancel_button = 'X'
        IMPORTING
          answer                = gv_answer
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.

      CASE gv_answer.
        WHEN '1'.
          gv_commit = 'X'.
* when yes
          PERFORM save_changes USING gv_commit.
        WHEN '2'.
* when no - revert the data to the old values
          vtts-zz_eta_dt   = gt_vtts_old-zz_eta_dt.
          vtts-zz_eta_ti   = gt_vtts_old-zz_eta_ti.
          vtts-daten       = gt_vtts_old-daten.
          vtts-uaten       = gt_vtts_old-uaten.
* when cancel - remain in the same tab
        WHEN 'A'.
          g_tc_chg1_master-pressed_tab = tc_chg1_master-activetab.
      ENDCASE.

      IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
      ENDIF.
    ENDIF.
  ENDIF.
ENDFORM.                    " popup_to_confirm
*&---------------------------------------------------------------------*
*&      Form  save_changes
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM save_changes USING gv_commit.

  REFRESH : gt_z1edstc ,
            gt_z1edstz ,
            gt_errors .

  CLEAR gt_z1eds01.
  CLEAR gt_errors.


* set up the header
  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'D'.

  IF gv_commit = 'X'.
* for qualifier D10
    IF vtts-zz_eta_dt      <> gt_vtts_old-zz_eta_dt OR
       vtts-zz_eta_ti+0(4) <> gt_vtts_old-zz_eta_ti+0(4).
      gt_z1edstz-qualf = 'D10'.
      gt_z1edstz-ntanf =  vtts-zz_eta_dt.
      gt_z1edstz-ntanz =  vtts-zz_eta_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier C10

* begin of change / nparchu / 02/262008
* planned shipment end date is being made non editable
* and earliest and latest forecast CDA editable

* Planned Shipment end
*    IF vtts-dpten <> gt_vtts_old-dpten OR
*       vtts-upten <> gt_vtts_old-upten.
*      gt_z1edstz-qualf = 'C10'.
*      gt_z1edstz-ntanf =  vtts-dpten.
*      gt_z1edstz-ntanz =  vtts-upten.
*      APPEND gt_z1edstz.
*      CLEAR gt_z1edstz.
*    ENDIF.

* Earliest forecast/CDA
    IF vtts-zz_f_see_dt      <> gt_vtts_old-zz_f_see_dt OR
       vtts-zz_f_see_ti+0(4) <> gt_vtts_old-zz_f_see_ti+0(4).
      gt_z1edstz-qualf = 'C10'.
      gt_z1edstz-ntanf =  vtts-zz_f_see_dt.
      gt_z1edstz-ntanz =  vtts-zz_f_see_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
*
** Latest forecast/CDA
    IF vtts-zz_f_sel_dt      <> gt_vtts_old-zz_f_sel_dt OR
       vtts-zz_f_sel_ti+0(4) <> gt_vtts_old-zz_f_sel_ti+0(4).
      gt_z1edstz-qualf = 'C10'.
      gt_z1edstz-ntanf =  vtts-zz_f_sel_dt.
      gt_z1edstz-ntanz =  vtts-zz_f_sel_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier Z10
    IF vtts-daten      <> gt_vtts_old-daten OR
       vtts-uaten+0(4) <> gt_vtts_old-uaten+0(4) .

      gt_z1edstz-qualf = 'Z10'.
      gt_z1edstz-ntanf =  vtts-daten.
      gt_z1edstz-ntanz =  vtts-uaten.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
  ELSE.

* for qualifier D10
    IF vtts-zz_eta_dt <> 00000000 .
      gt_z1edstz-qualf = 'D10'.
      gt_z1edstz-ntanf =  vtts-zz_eta_dt.
      gt_z1edstz-ntanz =  vtts-zz_eta_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier C10
*    IF vtts-dpten <> 00000000.
*      gt_z1edstz-qualf = 'C10'.
*      gt_z1edstz-ntanf =  vtts-dpten.
*      gt_z1edstz-ntanz =  vtts-upten.
*      APPEND gt_z1edstz.
*      CLEAR gt_z1edstz.
*    ENDIF.
* Earliest forecast/CDA
    IF vtts-zz_f_see_dt <> 00000000 .
      gt_z1edstz-qualf = 'C10'.
      gt_z1edstz-ntanf =  vtts-zz_f_see_dt.
      gt_z1edstz-ntanz =  vtts-zz_f_see_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
*
** Latest forecast/CDA
    IF vtts-zz_f_sel_dt <> 00000000.
      gt_z1edstz-qualf = 'C10'.
      gt_z1edstz-ntanf =  vtts-zz_f_sel_dt.
      gt_z1edstz-ntanz =  vtts-zz_f_sel_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier Z10
    IF vtts-daten <>  00000000.
      gt_z1edstz-qualf = 'Z10'.
      gt_z1edstz-ntanf =  vtts-daten.
      gt_z1edstz-ntanz =  vtts-uaten.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
  ENDIF.

  PERFORM unlock_shipment.

* call the FM to update the data
  CALL FUNCTION 'ZDL_PROCESS_SHPSTAT'
    EXPORTING
      is_z1eds01 = gt_z1eds01
      iv_source  = 'R3TR'
      iv_commit  = gv_commit
    TABLES
      it_z1edstz = gt_z1edstz[]
      et_errors  = gt_errors[].

* check for errors
  READ TABLE gt_errors WITH KEY type = 'E' .
  IF sy-subrc = 0 .
    MESSAGE e000(zsd_dl) WITH gt_errors-message.
  ELSE.
    IF gv_commit = 'X'.
      gv_save = 'X'.
      MESSAGE s000(zsd_dl) WITH 'Entries saved succesfully'(027).
    ELSE.
      MESSAGE s000(zsd_dl) WITH 'Validation succesful'(028).
    ENDIF.
  ENDIF.
  CLEAR gv_commit.

ENDFORM.                    " save_changes
*&---------------------------------------------------------------------*
*&      Form  popup_to_confirm_303
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM popup_to_confirm_303 .

* check for the any of the following values have been changed
* load indicator
* seal number
* load quantity 1
* load uom 1
* load quantity 2
* load uom 2
* actual load start date
* actual load start time
* actual load end date
* actual load end time
* current date
* current time
* planned load start
* planned load end
* planned gate exit

  IF  gv_display <> 'X'.


    IF     vtts-zz_load_ind      <> gt_vtts_old-zz_load_ind      OR
            vtts-zz_seal_no      <> gt_vtts_old-zz_seal_no       OR
            vtts-zz_load_q1      <> gt_vtts_old-zz_load_q1       OR
            vtts-zz_load_u1      <> gt_vtts_old-zz_load_u1       OR
            vtts-zz_load_q2      <> gt_vtts_old-zz_load_q2       OR
            vtts-zz_load_u2      <> gt_vtts_old-zz_load_u2       OR
            vtts-zz_a_ls_dt      <> gt_vtts_old-zz_a_ls_dt       OR
            vtts-zz_a_ls_ti+0(4) <> gt_vtts_old-zz_a_ls_ti+0(4)  OR
            vtts-zz_a_le_dt      <> gt_vtts_old-zz_a_le_dt       OR
            vtts-zz_a_le_ti+0(4) <> gt_vtts_old-zz_a_le_ti+0(4)  OR
            vtts-datbg           <> gt_vtts_old-datbg            OR
            vtts-uatbg           <> gt_vtts_old-uatbg+0(4)       OR
* begin of change / nparchu / v4W3
            vtts-zz_p_ls_dt       <> gt_vtts_old-zz_p_ls_dt      OR
            vtts-zz_p_ls_ti+0(4)  <> gt_vtts_old-zz_p_ls_ti+0(4) OR
            vtts-zz_p_le_dt       <> gt_vtts_old-zz_p_le_dt      OR
            vtts-zz_p_le_ti+0(4)  <> gt_vtts_old-zz_p_le_ti+0(4) OR
            vtts-dptbg            <> gt_vtts_old-dptbg           OR
            vtts-uptbg+0(4)       <> gt_vtts_old-uptbg+0(4)      OR
*end of change / nparchu / v4W3
* Begin of changes 11/06/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
              t30b-lgtor           <>  scr_dock_door               OR
              vttk-signi           <>  gv_signi_old                OR
* End of changes 11/06/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
* //psunkar 10/13/2009
             t30c-lgbzo           <>  scr_staging_area             OR
             vttk-exti2           <>  gv_exti2_old.
*//End of changes 10/13/2009
      CLEAR gv_answer.
      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          text_question         = TEXT-022
          text_button_1         = 'Yes'
          text_button_2         = 'No'
          default_button        = '2'
          display_cancel_button = 'X'
        IMPORTING
          answer                = gv_answer
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.
      CASE gv_answer.
        WHEN '1'.
          gv_commit = 'X'.
          PERFORM save_changes_303 USING gv_commit.

        WHEN '2'.
          vtts-zz_load_ind = gt_vtts_old-zz_load_ind.
          vtts-zz_seal_no = gt_vtts_old-zz_seal_no.
          vtts-zz_load_q1 = gt_vtts_old-zz_load_q1.
          vtts-zz_load_u1 = gt_vtts_old-zz_load_u1.
          vtts-zz_load_q2 = gt_vtts_old-zz_load_q2.
          vtts-zz_load_u2 = gt_vtts_old-zz_load_u2.
          vtts-zz_a_ls_dt = gt_vtts_old-zz_a_ls_dt.
          vtts-zz_a_ls_ti = gt_vtts_old-zz_a_ls_ti.
          vtts-zz_a_le_dt = gt_vtts_old-zz_a_le_dt.
          vtts-zz_a_le_ti = gt_vtts_old-zz_a_le_ti.
          vtts-datbg      = gt_vtts_old-datbg.
          vtts-uatbg      = gt_vtts_old-uatbg.
* begin of change / nparchu / v4W3
          vtts-zz_p_ls_dt  = gt_vtts_old-zz_p_ls_dt.
          vtts-zz_p_ls_ti  = gt_vtts_old-zz_p_ls_ti.
          vtts-zz_p_le_dt  = gt_vtts_old-zz_p_le_dt.
          vtts-zz_p_le_ti  = gt_vtts_old-zz_p_le_ti.
          vtts-dptbg       = gt_vtts_old-dptbg.
          vtts-uptbg       = gt_vtts_old-uptbg.
* Begin of changes 11/06/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
          t30b-lgtor     =  scr_dock_door  .
          vttk-signi     =  gv_signi_old.
* kthakur CMS 14392 - Transport E0VK951221
*          CLEAR : gv_signi_old.
* kthakur CMS 14392 - Transport E0VK951221
* End of changes 11/06/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
*end of change / nparchu / v4W3
* //Begin of R16I Big Button Update Staging Area changes 10/13/09
          t30c-lgbzo   =   scr_staging_area .
          vttk-exti2   =   gv_exti2_old.
*//EBegin of R16I Big Button Update Staging Area changes 10/13/09
        WHEN 'A'.
          g_tc_chg1_master-pressed_tab = tc_chg1_master-activetab.
      ENDCASE.

    ENDIF.
  ENDIF.
ENDFORM.                    " popup_to_confirm_303
*&---------------------------------------------------------------------*
*&      Form  save_changes_300
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM save_changes_303  USING    gv_commit.
  DATA : lv_date_time(12) TYPE c.

  REFRESH : gt_z1edstc ,
            gt_z1edstz ,
            gt_errors .
  CLEAR gt_z1eds01.
  CLEAR gt_errors.

* check for the fields not being blank

*
  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.

  IF gv_commit = 'X'.

* for qualifier LTY
    IF vtts-zz_load_ind <> gt_vtts_old-zz_load_ind.
      gt_z1edstc-qualf = 'LTY'.
      gt_z1edstc-param = vtts-zz_load_ind.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

* for qualifier S01
    IF vtts-zz_seal_no <> gt_vtts_old-zz_seal_no.
      gt_z1edstc-qualf = 'S01'.
      gt_z1edstc-param = vtts-zz_seal_no.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

* for qualifier U01
    IF vtts-zz_load_q1 <> gt_vtts_old-zz_load_q1 OR
       vtts-zz_load_u1 <> gt_vtts_old-zz_load_u1.
      gt_z1edstc-qualf = 'W01'.
      gt_z1edstc-param = vtts-zz_load_q1.
      gt_z1edstc-meins = vtts-zz_load_u1.
      CONDENSE gt_z1edstc-param.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

* for qualifier W01
    IF vtts-zz_load_q2 <> gt_vtts_old-zz_load_q2 OR
       vtts-zz_load_u2 <> gt_vtts_old-zz_load_u2.
      gt_z1edstc-qualf = 'U01'.
      gt_z1edstc-param = vtts-zz_load_q2.
      gt_z1edstc-meins = vtts-zz_load_u2.
      CONDENSE gt_z1edstc-param.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

* for qualifier Z40
    IF vtts-zz_a_ls_dt      <> gt_vtts_old-zz_a_ls_dt OR
       vtts-zz_a_ls_ti+0(4) <> gt_vtts_old-zz_a_ls_ti+0(4) .
      gt_z1edstz-qualf = 'Z40'.
      gt_z1edstz-ntanf =  vtts-zz_a_ls_dt.
      gt_z1edstz-ntanz =  vtts-zz_a_ls_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier Z60
    IF vtts-zz_a_le_dt      <> gt_vtts_old-zz_a_le_dt OR
       vtts-zz_a_le_ti+0(4) <> gt_vtts_old-zz_a_le_ti+0(4) .
      gt_z1edstz-qualf = 'Z60'.
      gt_z1edstz-ntanf =  vtts-zz_a_le_dt.
      gt_z1edstz-ntanz =  vtts-zz_a_le_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier Z90
    IF vtts-datbg      <> gt_vtts_old-datbg          OR
       vtts-uatbg+0(4) <> gt_vtts_old-uatbg+0(4) .
      gt_z1edstz-qualf = 'Z90'.
      gt_z1edstz-ntanf =  vtts-datbg.
      gt_z1edstz-ntanz =  vtts-uatbg.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* Begin of change / nparchu /02/07/08
* for qualifier C40
    IF vtts-zz_p_ls_dt      <> gt_vtts_old-zz_p_ls_dt OR
      vtts-zz_p_ls_ti+0(4)  <> gt_vtts_old-zz_p_ls_ti+0(4).
      gt_z1edstz-qualf = 'C40'.
      gt_z1edstz-ntanf =  vtts-zz_p_ls_dt.
      gt_z1edstz-ntanz =  vtts-zz_p_ls_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
* for qualifier C60
    IF vtts-zz_p_le_dt         <> gt_vtts_old-zz_p_le_dt OR
         vtts-zz_p_le_ti+0(4)  <> gt_vtts_old-zz_p_le_ti+0(4).
      gt_z1edstz-qualf = 'C60'.
      gt_z1edstz-ntanf =  vtts-zz_p_le_dt.
      gt_z1edstz-ntanz =  vtts-zz_p_le_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier C90
    IF vtts-dptbg         <> gt_vtts_old-dptbg OR
         vtts-uptbg+0(4)  <> gt_vtts_old-uptbg+0(4).
      gt_z1edstz-qualf = 'C90'.
      gt_z1edstz-ntanf =  vtts-dptbg.
      gt_z1edstz-ntanz =  vtts-uptbg.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
* End of change / nparchu / 02/07/08

* Begin of changes 11/06/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
* for qualifier DDA
    IF t30b-lgtor <> scr_dock_door.
      gt_z1edstc-qualf = 'DDA'.
      gt_z1edstc-param = t30b-lgtor.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

    IF vttk-signi <> gv_signi_old.
      gt_z1edstc-qualf = 'T01'.
      gt_z1edstc-param = vttk-signi.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.
* End of changes 11/06/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
*//Begin of R16I Big Button Update Staging Area changes 10/13/09
* Update Staging Area
    IF t30c-lgbzo <> scr_staging_area.
      gt_z1edstc-qualf = 'SAA'.
      gt_z1edstc-param = t30c-lgbzo.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.
* Update Pro#
*   Begin BCB03
*   If this Shipment was created in APO the PRO# might be defaulted to
*   value 'APO'. If this is the case then treat it as blanks so it
*   does not trigger a db update
    IF vttk-exti2 = 'APO'.
      CLEAR: vttk-exti2.
    ENDIF.
*   End BCB03
    IF vttk-exti2 <> gv_exti2_old.
      gt_z1edstc-qualf = 'P01'.
      gt_z1edstc-param = vttk-exti2.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

*//End of R16I Big Button Update Staging Area changes 10/13/09
  ELSE.
* for checking only
* for qualifier LTY
    IF vtts-zz_load_ind <> ' '.
      gt_z1edstc-qualf = 'LTY'.
      gt_z1edstc-param = vtts-zz_load_ind.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.
* seal no
*    if vtts-zz_seal_no <> 00000000.
    IF vtts-zz_seal_no IS NOT INITIAL.
      gt_z1edstc-qualf = 'S01'.
      gt_z1edstc-param = vtts-zz_seal_no.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.
*//Begin of R16I Big Button Update Staging Area changes 10/13/09
* Update Staging Area
*Pro#
*   Begin BCB03
*   If this Shipment was created in APO the PRO# might be defaulted to
*   value 'APO'. If this is the case then treat it as blanks so it
*   does not trigger a db update
    IF vttk-exti2 = 'APO'.
      CLEAR: vttk-exti2.
    ENDIF.
*   End BCB03
    IF vttk-exti2 IS NOT INITIAL.
      gt_z1edstc-qualf = 'P01'.
      gt_z1edstc-param = vttk-exti2.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.
*//End of R16I Big Button Update Staging Area changes 10/13/09
* Update Staging Area
* load 1
    IF vtts-zz_load_q1 <> 00000000.
      gt_z1edstc-qualf = 'U01'.
      gt_z1edstc-param = vtts-zz_load_q1.
      gt_z1edstc-meins = vtts-zz_load_u1.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.

* load 2
    IF vtts-zz_load_q2 <> 00000000.
      gt_z1edstc-qualf = 'U02'.
      gt_z1edstc-param = vtts-zz_load_q2.
      gt_z1edstc-meins = vtts-zz_load_u2.
      APPEND gt_z1edstc.
      CLEAR gt_z1edstc.
    ENDIF.
* for qualifier Z40
    IF  vtts-zz_a_ls_dt <> 00000000.
      gt_z1edstz-qualf = 'Z40'.
      gt_z1edstz-ntanf =  vtts-zz_a_ls_dt.
      gt_z1edstz-ntanz =  vtts-zz_a_ls_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
* for qualifier Z60

    IF vtts-zz_a_le_dt <> 00000000.
      gt_z1edstz-qualf = 'Z60'.
      gt_z1edstz-ntanf =  vtts-zz_a_le_dt.
      gt_z1edstz-ntanz =  vtts-zz_a_le_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

    IF vtts-datbg <> 00000000.
      gt_z1edstz-qualf = 'Z90'.
      gt_z1edstz-ntanf =  vtts-datbg.
      gt_z1edstz-ntanz =  vtts-uatbg.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.

    ENDIF.

* for qualifier C40
    IF vtts-zz_p_ls_dt <> 00000000.
      gt_z1edstz-qualf = 'C40'.
      gt_z1edstz-ntanf =  vtts-zz_p_ls_dt.
      gt_z1edstz-ntanz =  vtts-zz_p_ls_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier C60
    IF vtts-zz_p_le_dt <> 00000000.
      gt_z1edstz-qualf = 'C60'.
      gt_z1edstz-ntanf =  vtts-zz_p_le_dt.
      gt_z1edstz-ntanz =  vtts-zz_p_le_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier C90
    IF vtts-dptbg <> 00000000.
      gt_z1edstz-qualf = 'C90'.
      gt_z1edstz-ntanf =  vtts-dptbg.
      gt_z1edstz-ntanz =  vtts-uptbg.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

  ENDIF.
  PERFORM unlock_shipment.

  CALL FUNCTION 'ZDL_PROCESS_SHPSTAT'
    EXPORTING
      is_z1eds01 = gt_z1eds01
      iv_source  = 'R3TR'
      iv_commit  = gv_commit
    TABLES
      it_z1edstz = gt_z1edstz[]
      it_z1edstc = gt_z1edstc[]
      et_errors  = gt_errors[].


  WAIT UP TO gv_lowval SECONDS.

  READ TABLE gt_errors WITH KEY type = 'E' .
  IF sy-subrc = 0 .
    MESSAGE e000(zsd_dl) WITH gt_errors-message.
  ELSE.
    IF gv_commit = 'X'.
      gv_save = 'X'.
      MESSAGE s000(zsd_dl) WITH 'Entries saved succesfully'(027).
    ELSE.
      MESSAGE s000(zsd_dl) WITH 'Validation succesful'(028).
    ENDIF.
  ENDIF.
  CLEAR gv_commit.
ENDFORM.                    " save_changes_300



*&---------------------------------------------------------------------*
*&      Form  popup_to_confirm_304
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM popup_to_confirm_304 .
* check for the any of the following values have been changed
* actual gate entry date
* actual gate entry time
* earliest pickup appointment date
* earliest pickup appointment time
* latest pickup appointment date
* latest pickup appointment time

  IF  gv_display <> 'X'.

    IF  vtts-zz_a_ge_dt      <> gt_vtts_old-zz_a_ge_dt      OR
        vtts-zz_a_ge_ti+0(4) <> gt_vtts_old-zz_a_ge_ti+0(4) OR
        vtts-zz_e_pa_dt      <> gt_vtts_old-zz_e_pa_dt      OR
        vtts-zz_e_pa_ti+0(4) <> gt_vtts_old-zz_e_pa_ti+0(4) OR
        vtts-zz_l_pa_dt      <> gt_vtts_old-zz_l_pa_dt      OR
        vtts-zz_l_pa_ti+0(4) <> gt_vtts_old-zz_l_pa_ti+0(4).

      CLEAR gv_answer.
      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          text_question         = TEXT-022
          text_button_1         = 'Yes'
          text_button_2         = 'No'
          default_button        = '2'
          display_cancel_button = 'X'
        IMPORTING
          answer                = gv_answer
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.
      CASE gv_answer.
        WHEN '1'.
          gv_commit = 'X'.
          PERFORM save_changes_304 USING gv_commit.
        WHEN '2'.
          vtts-zz_a_ge_dt = gt_vtts_old-zz_a_ge_dt.
          vtts-zz_a_ge_ti = gt_vtts_old-zz_a_ge_ti.
          vtts-zz_e_pa_dt = gt_vtts_old-zz_e_pa_dt.
          vtts-zz_e_pa_ti = gt_vtts_old-zz_e_pa_ti.
          vtts-zz_l_pa_dt = gt_vtts_old-zz_l_pa_dt.
          vtts-zz_l_pa_ti = gt_vtts_old-zz_l_pa_ti.
        WHEN 'A'.
          g_tc_chg1_master-pressed_tab = tc_chg1_master-activetab.
      ENDCASE.
    ENDIF.
  ENDIF.
ENDFORM.                    " popup_to_confirm_304

*&---------------------------------------------------------------------*
*&      Form  save_changes_304
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM save_changes_304  USING  gv_commit.
  "data : lv_source
  REFRESH : gt_z1edstc ,
            gt_z1edstz ,
            gt_errors .

  CLEAR gt_z1eds01.
  CLEAR gt_errors.

  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.

  IF gv_commit = 'X'.
* for qualifier Z10
    IF vtts-zz_a_ge_dt      <> gt_vtts_old-zz_a_ge_dt OR
       vtts-zz_a_ge_ti+0(4) <> gt_vtts_old-zz_a_ge_ti+0(4) .
      gt_z1edstz-qualf = 'Z10'.
      gt_z1edstz-ntanf =  vtts-zz_a_ge_dt.
      gt_z1edstz-ntanz =  vtts-zz_a_ge_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier B10
    IF vtts-zz_e_pa_dt           <> gt_vtts_old-zz_e_pa_dt      OR
       vtts-zz_e_pa_ti+0(4)      <> gt_vtts_old-zz_e_pa_ti+0(4) OR
       vtts-zz_l_pa_dt           <> gt_vtts_old-zz_l_pa_dt      OR
       vtts-zz_l_pa_ti+0(4)      <> gt_vtts_old-zz_l_pa_ti+0(4).
* Begin of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
* If user requested flag is requested then set the qualifier to B10,
* If requested flag is confirmed then set the qualifier to C10

      IF rdb_requested = 'X'.
        gt_z1edstz-qualf = 'B10'.
      ELSEIF rdb_confirmed = 'X'.
        gt_z1edstz-qualf = 'C10'.
      ENDIF.
* End of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
      gt_z1edstz-ntanf =  vtts-zz_e_pa_dt.
      gt_z1edstz-ntanz =  vtts-zz_e_pa_ti.
      gt_z1edstz-ntend =  vtts-zz_l_pa_dt.
      gt_z1edstz-ntenz =  vtts-zz_l_pa_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
* Begin of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
* If the pickup appointment date/times have NOT changed,
* the flags need to be verified:
* if the user_flag is requested then set the qualifier to 'B10'
* (Pick-Up Request/Appointments)
* if the user_flag is confirmed then set the qualifier to 'C10'
* Confirmed Delivery Date
    ELSE.   "Date and Time has not changed, Confirmation
      IF rdb_requested = 'X'.
        gt_z1edstz-qualf = 'B10'.
      ELSEIF rdb_confirmed = 'X'.
        gt_z1edstz-qualf = 'C10'.
      ENDIF.
* end of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
      gt_z1edstz-ntanf =  vtts-zz_e_pa_dt.
      gt_z1edstz-ntanz =  vtts-zz_e_pa_ti.
      gt_z1edstz-ntend =  vtts-zz_l_pa_dt.
      gt_z1edstz-ntenz =  vtts-zz_l_pa_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.
  ELSE.

* for qualifier Z10
    IF vtts-zz_a_ge_dt <> 00000000.
      gt_z1edstz-qualf = 'Z10'.
      gt_z1edstz-ntanf =  vtts-zz_a_ge_dt.
      gt_z1edstz-ntanz =  vtts-zz_a_ge_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.
    ENDIF.

* for qualifier B10

    IF vtts-zz_e_pa_dt <> 00000000 OR
       vtts-zz_l_pa_dt <> 00000000.
      gt_z1edstz-qualf = 'B10'.
      gt_z1edstz-ntanf =  vtts-zz_e_pa_dt.
      gt_z1edstz-ntanz =  vtts-zz_e_pa_ti.
      gt_z1edstz-ntend =  vtts-zz_l_pa_dt.
      gt_z1edstz-ntenz =  vtts-zz_l_pa_ti.
      APPEND gt_z1edstz.
      CLEAR gt_z1edstz.

    ENDIF.
  ENDIF.
  PERFORM unlock_shipment.

  CALL FUNCTION 'ZDL_PROCESS_SHPSTAT'
    EXPORTING
      is_z1eds01 = gt_z1eds01
      iv_source  = 'IDOC'
      iv_commit  = gv_commit
    TABLES
      it_z1edstz = gt_z1edstz[]
      it_z1edstc = gt_z1edstc[]
      et_errors  = gt_errors[].

* lock shipment.
*  PERFORM lock_shipment.

  READ TABLE gt_errors WITH KEY type = 'E' .
  IF sy-subrc = 0 .
    MESSAGE e000(zsd_dl) WITH gt_errors-message.
  ELSE.
    IF gv_commit = 'X'.
      gv_save = 'X'.
      MESSAGE s000(zsd_dl) WITH 'Entries saved succesfully'(027).
      WAIT UP TO gv_lowval SECONDS.                         "12/12/08
    ELSE.
      MESSAGE s000(zsd_dl) WITH 'Validation succesful'(028).
    ENDIF.
  ENDIF.
  CLEAR gv_commit.

ENDFORM.                    " save_changes_304

*&---------------------------------------------------------------------*
*&      Form  set_titlebar
*&---------------------------------------------------------------------*
FORM set_titlebar .

  DATA : lv_head(17) TYPE c,
         lv_text(50) ,
         lv_tknum    TYPE tknum.

* converting the shipment number
  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
    EXPORTING
      input  = vttk-tknum
    IMPORTING
      output = lv_tknum.

  lv_head = 'Display Overview'(046).

* build the title bar
  CONCATENATE tvtkt-bezei
              lv_tknum
              lv_head
   INTO lv_text SEPARATED BY space.
* set the title bar
  SET TITLEBAR 'MAIN02' WITH lv_text.

ENDFORM.                    " set_titlebar
*&---------------------------------------------------------------------*
*&      Form  get_all_records
*&---------------------------------------------------------------------*
* For the select all button
*----------------------------------------------------------------------*
FORM get_all_records .
  DATA : lt_rows_sel TYPE lvc_t_row,
         ls_rows_sel TYPE lvc_s_row,
         lv_lines_a  TYPE i.
  DATA : lt_stages_final LIKE gt_stages_final OCCURS 0 .

* for select all button
  IF sy-ucomm = 'SALL'.

* get the data in local table
    MOVE gt_stages_final[] TO lt_stages_final.
    DELETE  lt_stages_final WHERE tsnum IS INITIAL.
    DESCRIBE TABLE lt_stages_final LINES lv_lines_a.

* delete the blank lines
    IF lv_lines_a > 0.
      DO lv_lines_a TIMES.
        ls_rows_sel-index = ls_rows_sel-index + 1 .
        APPEND ls_rows_sel TO lt_rows_sel.
      ENDDO.
    ENDIF.

    CALL METHOD go_grid->set_selected_rows
      EXPORTING
        it_index_rows = lt_rows_sel.

  ENDIF.
ENDFORM.                    " get_all_records
*&---------------------------------------------------------------------*
*&      Form  conv_exit
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM conv_exit USING p_point .

  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
    EXPORTING
      input  = p_point
    IMPORTING
      output = p_point.

ENDFORM.                    " conv_exit
*&---------------------------------------------------------------------*
*&      Form  rev_start_date
*&---------------------------------------------------------------------*
FORM rev_date .
  CLEAR gt_z1eds01.
  CLEAR gt_z1edstz.
  REFRESH gt_z1edstz.
* check for the fields not being blank

  IF sy-ucomm = 'REVS'.
    IF vtts-zz_a_ls_dt IS INITIAL.
      MESSAGE e000(zsd_dl) WITH
            'Load start cannot be blank'(041).
    ENDIF.
  ELSE.
    IF vtts-zz_a_le_dt IS INITIAL.
      MESSAGE e000(zsd_dl) WITH
           'Load end cannot be blank'(042).
    ENDIF.
  ENDIF.

  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.

  IF sy-ucomm = 'REVS'.
* for qualifier Z40
    gt_z1edstz-qualf = 'Z40'.
    gt_z1edstz-ntanf =  vtts-zz_a_ls_dt.
    gt_z1edstz-ntanz =  vtts-zz_a_ls_ti.
    APPEND gt_z1edstz.
    CLEAR gt_z1edstz.
  ELSE.
* for qualifier Z60
    gt_z1edstz-qualf = 'Z60'.
    gt_z1edstz-ntanf =  vtts-zz_a_le_dt.
    gt_z1edstz-ntanz =  vtts-zz_a_le_ti.
    APPEND gt_z1edstz.
    CLEAR gt_z1edstz.
  ENDIF.

*unlock the shipment
  PERFORM unlock_shipment.

* update the shipment
  CALL FUNCTION 'ZDL_PROCESS_SHPSTAT'
    EXPORTING
      is_z1eds01 = gt_z1eds01
      iv_source  = 'R3TR'
      iv_mescod  = 'REV'
      iv_commit  = 'X'
    TABLES
      it_z1edstz = gt_z1edstz[]
      et_errors  = gt_errors[].

* lock shipment.
  PERFORM lock_shipment.

  READ TABLE gt_errors INDEX 1 .
  IF sy-subrc = 0 .
    MESSAGE s000(zsd_dl) WITH gt_errors-message.
  ELSE.
    IF gv_commit = 'X'.
      MESSAGE s000(zsd_dl) WITH 'Entries saved succesfully'(027).
      WAIT UP TO gv_lowval SECONDS.

    ELSEIF gv_commit ='R'.
      MESSAGE s000(zsd_dl) WITH 'Reverse succesful'(045).
      WAIT UP TO gv_lowval SECONDS.
      CLEAR vttk-signi.
    ELSE.
      MESSAGE s000(zsd_dl) WITH 'Validation succesful'(028).
    ENDIF.
  ENDIF.

ENDFORM.                    " rev_start_date

* Begin of changes /psunkar/08/12/08 EDEK912945
*&---------------------------------------------------------------------*
*&      Form  gate_exit_rev_303
*&---------------------------------------------------------------------*
* This sub-routine permit's the user  to reverse the gate-exit
*----------------------------------------------------------------------*

FORM gate_exit_rev_303 USING gv_commit.

* check for the fields not being blank
  IF vtts-datbg IS INITIAL.
    MESSAGE e117(zdl_shpstat).
  ENDIF.

  gv_commit = 'X'.
  CLEAR gt_z1eds01.
  CLEAR gt_z1edstz.
  REFRESH: gt_z1edstz, gt_errors.

  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.

* for qualifier Z90
  gt_z1edstz-qualf = 'Z90'.
  gt_z1edstz-ntanf =  vtts-datbg.
  gt_z1edstz-ntanz =  vtts-uatbg.
  APPEND gt_z1edstz.
  CLEAR gt_z1edstz.

  PERFORM unlock_shipment.
  gv_mescod = gc_rev.
  PERFORM zdl_process_shipstat_303 USING gv_mescod.

ENDFORM.                    "gate_exit_rev_303

"End of changes /psunkar/08/12/08 EDEK912945

* Begin of changes /psunkar/03/26/08
* Transport# EDEK911301
*&---------------------------------------------------------------------*
*&      Form  load_start_stage_303
*&---------------------------------------------------------------------*
*  If status of current stage is not load-start(3) Initiating
*  load-start for the current stage using the current
*  system date/time.If error in initiating load-start pass the error
*  message to the user using zdl_process_shipstat logic.
*----------------------------------------------------------------------*

FORM load_start_stage_303 USING gv_commit.

  DATA: lv_vstel     TYPE vstel.
  REFRESH : gt_z1edstc,
            gt_z1edstz,
            gt_errors.
  CLEAR   : gt_z1eds01,
            gt_errors.



  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.
* for qualifier Z40 (Actual Load start)
* Initiate load start for current stage using system date and time

  gt_z1edstz-qualf = 'Z40'.
  gt_z1edstz-ntanf =  sy-datlo.
  gt_z1edstz-ntanz =  sy-timlo.
  gt_z1edstz-tzonis = sy-zonlo. "TPR# 03495 Tr#EDVK969962  kthakur+
  .
  APPEND gt_z1edstz.
  CLEAR gt_z1edstz.
* Insert by kthakur  12/17/2008
* save container ID when BOL pressed.
  IF vttk-signi <> gv_signi_old.
    gt_z1edstc-qualf = 'T01'.
    gt_z1edstc-param = vttk-signi.
    APPEND gt_z1edstc.
    CLEAR gt_z1edstc.
  ENDIF.
* End insert
  PERFORM unlock_shipment.
  CLEAR gv_mescod.
  PERFORM zdl_process_shipstat_303 USING gv_mescod. " added gv_mescode
  "on 08/12/08
  "Transport# EDEK912945

ENDFORM.                    "load_start_stage_303

*&---------------------------------------------------------------------*
*&      Form  bol_stage_303
*&---------------------------------------------------------------------*
* If status of current stage is not load-end(4) Initiating
*  load-end for the current stage using the current system date/time.
*  If error in initiating load-start pass the error message to the user
* using zdl_process_shipstat logic.
*----------------------------------------------------------------------*

FORM load_end_stage_303 USING gv_commit.

  REFRESH : gt_z1edstc,
            gt_z1edstz,
            gt_errors.
  CLEAR   : gt_z1eds01,
            gt_errors.
  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.
* for qualifier Z60 (Load End)
* Initiate load end for current stage using system date and time

  gt_z1edstz-qualf = 'Z60'.
  gt_z1edstz-ntanf =  sy-datlo.
  gt_z1edstz-ntanz =  sy-timlo.
  gt_z1edstz-tzonis = sy-zonlo. "TPR# 03495 Tr#EDVK969962  kthakur+
  APPEND gt_z1edstz.
  CLEAR gt_z1edstz.
*Insert kthakur  12/17/2008
* save container ID when BOL pressed.
  IF vttk-signi <> gv_signi_old.
    gt_z1edstc-qualf = 'T01'.
    gt_z1edstc-param = vttk-signi.
    APPEND gt_z1edstc.
    CLEAR gt_z1edstc.
  ENDIF.
* End insert
  PERFORM unlock_shipment.
  CLEAR gv_mescod.
  PERFORM zdl_process_shipstat_303 USING gv_mescod." added gv_mescode
  "on 08/12/08
  "Transport# EDEK912945

ENDFORM.                    "load_end_stage_303
*&---------------------------------------------------------------------*
*&      Form  gate_exit_stage_303
*&---------------------------------------------------------------------*
* If status of current stage is not gate-exit(6) Initiating
* gate-exit for the current stage using the current system date/time.
*  If error in initiating gate-exit pass the error message to the user
* using zdl_process_shipstat logic.
*----------------------------------------------------------------------*

FORM gate_exit_stage_303 USING gv_commit.

  REFRESH : gt_z1edstc,
            gt_z1edstz,
            gt_errors.
  CLEAR   : gt_z1eds01,
            gt_errors.
  gt_z1eds01-tknum = vttk-tknum.
  gt_z1eds01-tsnum = vtts-tsnum.
  gt_z1eds01-stpod = 'O'.
* for qualifier Z90

  gt_z1edstz-qualf = 'Z90'.
  gt_z1edstz-ntanf =  sy-datlo.
  gt_z1edstz-ntanz =  sy-timlo.
  gt_z1edstz-tzonis = sy-zonlo. "TPR# 03495 Tr#EDVK969962  kthakur+
  APPEND gt_z1edstz.
  CLEAR gt_z1edstz.
  PERFORM unlock_shipment.
  CLEAR gv_mescod.
  PERFORM zdl_process_shipstat_303 USING gv_mescod. " added gv_mescode
  "on 08/12/08
  "Transport# EDEK912945

ENDFORM.                    "gate_exit_stage_303

*&---------------------------------------------------------------------*
*&      Form  zdl_process_shipstat_303
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM zdl_process_shipstat_303 USING p_mescod TYPE edi_mescod.

  gv_mescod = p_mescod.
  CALL FUNCTION 'ZDL_PROCESS_SHPSTAT'
    EXPORTING
      is_z1eds01 = gt_z1eds01
      iv_source  = 'R3TR'
      iv_mescod  = gv_mescod
      iv_commit  = gv_commit
    TABLES
      it_z1edstz = gt_z1edstz[]
      it_z1edstc = gt_z1edstc[]
      et_errors  = gt_errors[].

  READ TABLE gt_errors WITH KEY type = 'E' .
  IF sy-subrc = 0 .
*    message e000(zsd_dl) with gt_errors-message.
    MESSAGE e000(zsd_dl) WITH gt_errors-message vttk-tknum.
  ELSE.
    IF gv_commit = 'X'.
      gv_save = 'X'.
      MESSAGE s000(zsd_dl) WITH 'Entries saved succesfully'(027).
* Start of change JWILL68 CD#366 2/21/2020
      DATA(lt_z1edstz) = gt_z1edstz[].
      DELETE lt_z1edstz[] WHERE qualf <> 'Z60'.
      IF gv_mescod <> 'REV' AND
         lt_z1edstz IS NOT INITIAL.
        PERFORM print_proforma_zpfm.
      ENDIF.

* Get wait time.
    SELECT SINGLE lowval
           FROM zdl_fields
           INTO @DATA(lv_wait_time)
           WHERE category = 'E03732' AND
                 fieldname = 'ZPFM_WAIT'.
    IF sy-subrc <> 0.
      lv_wait_time = 2.
    ENDIF.
    WAIT UP TO lv_wait_time SECONDS.

* End of change JWILL68 CD#366 2/21/2020
      PERFORM lock_shipment.
*     wait UP TO  gv_lowval SECONDS."12/12/08  Trans.#EDVK967185

    ELSE.
      MESSAGE s000(zsd_dl) WITH 'Validation succesful'(028).
    ENDIF.
  ENDIF.
  CLEAR gv_commit.

ENDFORM.   "zdl_process_shipstat_303

*&---------------------------------------------------------------------*
*&      Form  authority_check_stage
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM authority_check_stage USING     lv_vstel LIKE vtts-vstel
                           CHANGING  gv_stage_authority .
  DATA: lv_werks     TYPE werks_d.
* Ensure User has authority to the plant entered
  SELECT SINGLE werks
   INTO lv_werks
   FROM tvswz
   WHERE vstel = lv_vstel.
  IF sy-subrc = 0.
    AUTHORITY-CHECK OBJECT 'V_VTTK_TDS'
                    ID     'TPLST'      FIELD lv_werks
                    ID     'ACTVT'      FIELD '02'.   "change

    IF sy-subrc <> 0.
      gv_stage_authority = 'F'.

* Begin insert TPR# 31735 TR# E0VK950315   kthakur  Repack
      IF sy-ucomm = 'CHNG'.
* Unlock Shipment.
        PERFORM unlock_shipment.
* Begin insert TPR# 32023 TR# EDVK971306 kthakur
        CLEAR gt_stages_valid.
        REFRESH gt_stages_valid.
* End insert TPR# 32023  TR# EDVK971306 kthakur
      ENDIF.
* End insert TPR# 31735 TR# E0VK950315   kthakur
* No authority for plant
      MESSAGE e111(zdl_shpstat).
    ELSE.
      gv_stage_authority = 'T'.
    ENDIF.
  ENDIF.

ENDFORM.                    "authority_check_stage
* end of changes /psunkar/03/26/08

* Transport# EDEK911301

*&---------------------------------------------------------------------*
*&      Form  set_style
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_style .

* At each level of the field tsnum we are making the cells as
* non editable.

  DATA : ls_celltab TYPE lvc_s_styl,
         lt_celltab TYPE lvc_t_styl,
         lv_index   TYPE sy-tabix.

  LOOP AT gt_stages_final.
    lv_index = sy-tabix.
    ls_celltab-fieldname = 'TSNUM'.
    ls_celltab-style     = go_grid->mc_style_disabled.
    INSERT ls_celltab INTO TABLE lt_celltab.
    INSERT LINES OF lt_celltab INTO TABLE gt_stages_final-celltab.
    MODIFY gt_stages_final INDEX lv_index.
    CLEAR lv_index.
  ENDLOOP.

ENDFORM.                    " set_style
*&---------------------------------------------------------------------*
*&      Form  save
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
FORM save .
  IF ( sy-ucomm = 'ARRS'  OR
       sy-ucomm = 'DISPS' OR
       sy-ucomm = 'GATES' ) AND
        gv_save = 'X'.
    CLEAR gv_save.
* commented on 12/11/08 Transport # EDVK967185
*     set screen 0.
    "leave screen.
*    leave to screen 100. " changed on 12/04/08 Transport # ESBK9A07VO
* //12/11/08 Transport # EDVK967185
  ENDIF.
ENDFORM.                    " save
*&---------------------------------------------------------------------*
*&      Form  SAVE_ENTRIES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM save_entries .

ENDFORM.                    " SAVE_ENTRIES


* Begin of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.
*&---------------------------------------------------------------------*
*&      Form  get_dock_door_data.
*&---------------------------------------------------------------------*
*       Get dock door Number and description
*----------------------------------------------------------------------*
FORM get_dock_door_data.
  DATA: ls_likp_lgtor  LIKE LINE OF gt_likp_lgtor.
  DATA: BEGIN OF ls_lips ,
          vbeln LIKE lips-vbeln,
          werks LIKE lips-werks,
          lgort LIKE lips-lgort,
        END OF ls_lips.
  DATA: ls_t320 LIKE t320.

  DATA: lv_blank TYPE char1.                                "BCB05

  CALL FUNCTION 'ZSD_DL_MOS_ITINERARY_VIEW'
    EXPORTING
      i_tknum                        = vttk-tknum
    TABLES
      t_itinerary                    = gt_itinerary
    EXCEPTIONS
      invalid_input                  = 1
      shipment_not_found             = 2
      no_deliveries_found            = 3
      no_stages_on_shipment          = 4
      no_authority                   = 5
      deliveries_unassigned_to_stage = 6
      flex_multi_origin_not_allowed  = 7
      OTHERS                         = 8.

  CHECK sy-subrc = 0.

* read the itinerary table with the stage
  READ TABLE gt_itinerary INTO gs_itinerary
                      WITH KEY tsnum = vtts-tsnum.
  CHECK sy-subrc EQ 0.

  gt_deliveries[] = gs_itinerary-deliveries[].
* read the first delivery at this stop
  READ TABLE  gt_deliveries INTO gs_deliveries  INDEX 1.
  CHECK sy-subrc = 0.

  gv_vbeln = gs_deliveries-vbeln. "store 1st Delivery

* Begin BCB05 insert
* If the enter key has been pressed last and the Dock Door screen field
* is blank then clear the Dock Door screen description and do NOT
* overlay the Dock Door screen field with the previous version of the
* field.
  IF gv_enter_pressed = gc_x AND t30b-lgtor IS INITIAL.
    CLEAR: scr_dock_desc,
           gv_ltort.
    lv_blank = gc_x.
  ENDIF.

* If the enter key has been pressed last and the Staging Area screen
* field is blank then clear the Staging Area screen description and do
* NOT overlay the Staging Area screen field with the previous version
* of the field.
  IF gv_enter_pressed = gc_x AND t30c-lgbzo IS INITIAL.
    CLEAR: scr_stagearea_desc,
           gv_lbzot.
    lv_blank = gc_x.
  ENDIF.

* If either Dock Door or Staging Area was spaced out and user hit Enter
* then leave this subroutine.
  CHECK lv_blank IS INITIAL.
* End BCB05 insert

* pick the dock door and staging area from first delivery at this stop
  CLEAR: gv_lgtor,gv_lgbzo.
  SELECT SINGLE lgtor lgbzo
     FROM likp
     INTO (gv_lgtor,gv_lgbzo)
     WHERE vbeln = gs_deliveries-vbeln.
* Begin of R16I Big Button Update Staging Area changes 10/13/09
  IF gv_lgbzo IS NOT INITIAL.
    scr_staging_area = gv_lgbzo.
    CLEAR gv_lbzot.
*   Begin BCB04 insert
*   If a Staging Area Door values exists on the screen that use
*   THAT value to retrieve the Staging Area description.
*   Otherwise, use the Dock Door on the Delivery (LIKP-LGBZO)
    IF t30c-lgbzo IS NOT INITIAL.
      SELECT SINGLE lbzot
        FROM t30ct
        INTO gv_lbzot
        WHERE lgbzo = t30c-lgbzo. "Staging Area screen field
    ELSE.
*       End BCB04 insert
      SELECT SINGLE lbzot
        FROM t30ct
        INTO gv_lbzot
        WHERE lgbzo = gv_lgbzo.
*   Begin BCB04 insert
    ENDIF.
*   End BCB04 insert
    scr_stagearea_desc = gv_lbzot.
* Begin BCB04 insert
  ELSEIF t30c-lgbzo IS NOT INITIAL.
*   If the Staging Area database value (gv_lgbzo) is blank but
*   the user entered a value into the Staging Area screen
*   field (t30c-lgbzo) then retrieve the Staging Area description
*   based on the screen field value
    SELECT SINGLE lbzot
      FROM t30ct
      INTO gv_lbzot
      WHERE lgbzo = t30c-lgbzo. "Staging Area screen field
    IF sy-subrc = 0.
      scr_stagearea_desc = gv_lbzot.
    ENDIF.
* End BCB04 insert
  ENDIF.
*End of R16I Big Button Update Staging Area changes 10/13/09

  IF gv_lgtor IS NOT INITIAL.
    scr_dock_door = gv_lgtor.

*   select plant and dock door for the delivery
    CLEAR: ls_lips. "BCB08 insert
    SELECT SINGLE vbeln werks lgort
      INTO ls_lips
      FROM lips
      WHERE vbeln = gs_deliveries-vbeln
        AND pstyv NE gc_tatx. "BCB08 insert
    IF sy-subrc = 0.
*     select storage location data
      SELECT SINGLE * INTO ls_t320
      FROM t320
      WHERE werks = ls_lips-werks
      AND   lgort = ls_lips-lgort.
      IF sy-subrc = 0.
*       select dock door description
        CLEAR: gv_lgnum, gv_ltort.
        gv_lgnum = ls_t320-lgnum.
*       Begin BCB04 insert
*       If a Dock Door value exists on the screen that use THAT
*       value to retrieve the Dock Door description. Otherwise,
*       use the Dock Door on the Delivery (LIKP-LGTOR)
        IF t30b-lgtor IS NOT INITIAL.
          SELECT SINGLE ltort
            INTO gv_ltort
            FROM t30bt
            WHERE lgtor = t30b-lgtor "Dock Door screen field
            AND  lgnum = ls_t320-lgnum.
        ELSE.
*       End BCB04 insert
          SELECT SINGLE ltort
            INTO gv_ltort
            FROM t30bt
            WHERE lgtor = gv_lgtor
            AND  lgnum = ls_t320-lgnum.
*       Begin BCB04 insert
        ENDIF.
*       End BCB04 insert
        scr_dock_desc = gv_ltort.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    "get_dock_door_data
* End of changes 11/04/08 Transport # ESBK9A07VO   R13W  E07126,
* E07127 (WM) Z03732  transaction.

*&---------------------------------------------------------------------*
*&      Form  wm_status.
*&---------------------------------------------------------------------*
*       Get Pick Pack Status
*----------------------------------------------------------------------*
FORM wm_status.

  DATA: lv_uecha_blank LIKE lips-uecha,
        lv_vpobjkey    LIKE vekp-vpobjkey,
        count          TYPE i,
        lv_vstel       TYPE vstel,
        lv_lines       TYPE i,

        BEGIN OF lt_vpobjkey OCCURS 0,
          vpobjkey LIKE vekp-vpobjkey,
        END OF lt_vpobjkey,

        BEGIN OF lt_vbup OCCURS 0,
          vbeln LIKE vbup-vbeln,
          posnr LIKE vbup-posnr,
          kosta LIKE vbup-kosta,
          pksta LIKE vbup-pksta,
        END  OF lt_vbup,
* Begin insert TPR# 31358  TR# EDVK970882  kthakur
        BEGIN OF lt_vbuk OCCURS 0,
          vbeln LIKE vbuk-vbeln,
          kostk LIKE vbuk-kostk,
        END OF lt_vbuk.
* End insert TPR# 31358  TR# EDVK970882  kthakur
  DATA: gt_hudat2 LIKE STANDARD TABLE OF  gt_hudat WITH HEADER LINE.
  CLEAR : gt_hudat[],gt_lips[],lt_vbup[],gt_vekp[],
          lt_vpobjkey[],gt_hudat,gt_lips,lt_vbup,gt_vekp,
          lt_vpobjkey.

* Get the deliveries loaded at this stage
  CHECK gt_deliveries[] IS NOT INITIAL.
* Begin insert TPR# 31358  TR# EDVK970882  kthakur
* Validate all deliveries are not in 'A' or 'B' picking status.
  SELECT vbeln kostk
     INTO TABLE lt_vbuk
     FROM vbuk
     FOR ALL ENTRIES IN gt_deliveries
     WHERE vbeln = gt_deliveries-vbeln
     AND   kostk IN ('A' , 'B' ).
  IF NOT lt_vbuk[] IS INITIAL.
    READ TABLE lt_vbuk INDEX 1.
    MESSAGE e527(zsd_dl) WITH lt_vbuk-vbeln.
    "Delivery# needs to be confirmed
  ENDIF.
* End insert TPR# 31358  TR# EDVK970882  kthakur

  SELECT vbeln posnr lfimg lgnum uecha zz_pickconf_ind pstyv
      INTO TABLE gt_lips
      FROM lips
      FOR ALL ENTRIES IN gt_deliveries
      WHERE vbeln = gt_deliveries-vbeln.
  "and   uecha = lv_uecha_blank.
* Begin insert  TPR# 31358 TR# EDVK970882
  IF NOT gt_lips[] IS INITIAL.                        "kthakur+
*    DELETE gt_lips WHERE pstyv = 'TATX'.  "BCB08 delete
    DELETE gt_lips WHERE pstyv = gc_tatx.  "BCB08 insert
  ENDIF.                                              "kthakur+
* End of insert TPR# 31358 TR# EDVK970882
  IF NOT gt_lips[] IS INITIAL.
* get HU for deliveries in shipment stage.
    READ TABLE gt_lips INDEX 1.
    IF NOT gt_lips-lgnum IS INITIAL.

* Check Whether it is Warehouse Managed facility or not
      CLEAR gt_lips.
      READ TABLE gt_lips WITH KEY uecha = lv_uecha_blank
                                  zz_pickconf_ind = ' '.
      IF sy-subrc = 0.
        MESSAGE e524(zsd_dl) WITH gt_lips-vbeln gt_lips-posnr.
        "Delivery. & Item & needs to be confirmed
      ENDIF.

      SELECT vbeln posnr kosta pksta  INTO TABLE lt_vbup
            FROM vbup
            FOR ALL ENTRIES IN gt_lips
            WHERE vbeln = gt_lips-vbeln
            AND  posnr = gt_lips-posnr.
*          and  pksta <> 'C'.
      IF sy-subrc = 0.
        SORT lt_vbup BY vbeln posnr.
        READ TABLE lt_vbup WITH KEY pksta = 'A'.
        IF sy-subrc = 0.
          MESSAGE e524(zsd_dl) WITH gt_lips-vbeln gt_lips-posnr.
          "Delivery. & Item & needs to be confirmed
        ELSE.
          READ TABLE lt_vbup WITH KEY pksta = 'B'.
          IF sy-subrc = 0.
            MESSAGE e524(zsd_dl) WITH gt_lips-vbeln gt_lips-posnr.
            "Delivery. & Item & needs to be confirmed
          ENDIF.
        ENDIF.
        LOOP AT gt_lips.
          IF gt_lips-uecha IS INITIAL.
            CONTINUE.
          ENDIF.
          CLEAR lt_vbup.
          READ TABLE lt_vbup WITH KEY vbeln = gt_lips-vbeln
                                       posnr = gt_lips-posnr
                                       BINARY SEARCH.
          IF sy-subrc = 0.
            IF lt_vbup-pksta <> 'C'.
              MESSAGE e526(zsd_dl) WITH gt_lips-vbeln gt_lips-posnr.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDIF.

* Get the Pick Pallet entries from HUDAT table
      REFRESH gt_hudat.
      SELECT pexidv cexidv tknum vbeln posnr
        INTO TABLE gt_hudat
        FROM zdl_wm_hudat
        FOR ALL ENTRIES IN gt_deliveries
        WHERE tknum = vttk-tknum
        AND   vbeln = gt_deliveries-vbeln.

      CHECK  gt_hudat[]  IS NOT INITIAL.

* Get HU's for deliveries in stage from vekp
      SELECT venum exidv status vpobjkey  INTO TABLE gt_vekp
        FROM vekp FOR ALL ENTRIES IN gt_hudat
        WHERE vpobj = '01'
        AND  exidv = gt_hudat-cexidv.

* Delete the records if HU is deleted from shipment (status = 0060).
* TPR# 03495      TR#EDVK969962
      DELETE gt_vekp WHERE status = '0060'.    "kthakur+

* Get Shipment level HU's
      lv_vpobjkey = vttk-tknum.
      SELECT venum exidv status vpobjkey  INTO TABLE gt_vekp_s
        FROM vekp FOR ALL ENTRIES IN gt_hudat
        WHERE exidv = gt_hudat-pexidv.

* Delete the records if HU is deleted from shipment (status = 0060).
* TPR# 03495      TR#EDVK969962
      DELETE gt_vekp_s WHERE status = '0060'.  "kthakur+

      IF gt_vekp_s[] IS NOT INITIAL.
        SELECT venum vbeln posnr unvel
               INTO TABLE gt_vepo
               FROM vepo
               FOR ALL ENTRIES IN gt_vekp_s
               WHERE venum = gt_vekp_s-venum.
      ENDIF.
      SORT gt_vekp BY exidv.
      SORT gt_vekp_s BY exidv.
      SORT gt_hudat BY pexidv.

      gt_hudat2[] = gt_hudat[].

      LOOP AT gt_hudat.
        CLEAR gt_vekp_s.
        READ TABLE gt_vekp_s
               WITH KEY exidv = gt_hudat-pexidv
               BINARY SEARCH.
        IF sy-subrc = 0.
          IF gt_vekp_s-vpobjkey = vttk-tknum.
            LOOP AT gt_hudat2 WHERE pexidv = gt_hudat-pexidv.
              READ TABLE gt_vekp WITH KEY exidv = gt_hudat2-cexidv.
              IF sy-subrc = 0.
                IF gt_vekp-vpobjkey = gt_hudat2-vbeln.
                  READ TABLE gt_vepo WITH KEY venum = gt_vekp_s-venum
                           unvel = gt_vekp-venum.
                  IF sy-subrc <> 0.
                    " Child not packed to parent
                    MESSAGE e525(zsd_dl).
                  ENDIF.
                ELSE.
                  MESSAGE e524(zsd_dl) WITH gt_hudat2-vbeln
                  gt_hudat2-posnr.
                  "Child is referring to wrong delivery  error

                ENDIF.
              ELSE.
                MESSAGE e524(zsd_dl) WITH gt_hudat2-vbeln
                gt_hudat2-posnr.
                "The child HU is not picked

              ENDIF.
            ENDLOOP.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ELSE.
** Begin insert  CHG102464 TR#E0VK952755  by kthakur
** Check for DC facility
*
*     select SINGLE *  from tvswz where vstel = vtts-vstel.
*       if sy-subrc = 0  and tvswz-werks <> ' '.
*         SELECT SINGLE * from zplant
*             where werks = tvswz-werks
*             and   type  = 'DC'.
*          if sy-subrc = 0 .
*            delete gt_lips WHERE lfimg =< 0.
*            SELECT vbeln posnr kosta pksta  INTO TABLE lt_vbup
*              FROM vbup
*              FOR ALL ENTRIES IN gt_lips
*              WHERE vbeln = gt_lips-vbeln
*              AND  posnr = gt_lips-posnr.
** Delete line items from internal table where pick(kosta) and
** pack(pksta) flag is set to 'C' or picking status is blank
*              DELETE lt_vbup WHERE kosta = 'C'
*                              and  pksta = 'C'.
*              DELETE lt_vbup WHERE kosta = ' '
*                              and  pksta = 'C'.
** If any line item found with picking or packing flag not set
** to 'C'  then give error message .
*              DESCRIBE TABLE lt_vbup LINES lv_lines.
*              if lv_lines > 0.
*                READ TABLE lt_vbup index 1.
*                MESSAGE e528(zsd_dl) WITH gt_lips-vbeln gt_lips-posnr.
*                "Delivery & Item & needs to be picked and packed.
*              ENDIF.
*
*          else.
* End insert  CHG102464 TR#E0VK952755  by kthakur

      LOOP AT gt_vekp
        WHERE exidv = gt_hudat-pexidv.
        IF gt_vekp-vpobjkey = gt_hudat-vbeln.
          MESSAGE e525(zsd_dl) . "HU not packed
        ENDIF.
      ENDLOOP.
*          ENDIF.
*      ENDIF.
    ENDIF.
  ELSE.
    READ TABLE gt_vekp_s
          WITH KEY exidv = gt_hudat-pexidv
          BINARY SEARCH.
  ENDIF.

ENDFORM.                    " wm_status
*&---------------------------------------------------------------------*
*&      Form  AUTHORITY_CHECK_GATE_EXIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM authority_check_gate_exit .
  AUTHORITY-CHECK OBJECT 'Z_DL_GATE'
                   ID    'ACTVT'      FIELD '16'.   "execute
  IF sy-subrc <> 0.
    gv_gate_exit_rev_auth = 'F'.
* No authority for reversing gate exit
    MESSAGE e111(zdl_shpstat).
  ELSE.
    gv_gate_exit_rev_auth = 'T'.

  ENDIF.
ENDFORM.                    " AUTHORITY_CHECK_GATE_EXIT

* >> Begin of Change - CC01
*&---------------------------------------------------------------------*
*&      Form  PRINT_BILL_OF_LADING_OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM print_bill_of_lading_output .

  DATA : lt_nast TYPE TABLE OF nast,
         ls_nast TYPE nast.

  REFRESH lt_nast.
  SELECT *
      FROM nast
      INTO TABLE lt_nast
      WHERE  kappl EQ gc_kappl                       AND
             objky EQ vttk-tknum                     AND
             kschl IN (gc_kschl_zbol, gc_kschl_zbl2) AND
             spras EQ sy-langu                       AND
             vstat EQ '0'.
  IF sy-subrc EQ 0.
    CLEAR ls_nast.
    READ TABLE lt_nast INTO ls_nast WITH KEY kschl = gc_kschl_zbol.
    IF sy-subrc EQ 0.
      PERFORM send_output USING ls_nast.
      RETURN.
    ENDIF.

    CLEAR ls_nast.
    READ TABLE lt_nast INTO ls_nast WITH KEY kschl = gc_kschl_zbl2.
    IF sy-subrc EQ 0.
      PERFORM send_output USING ls_nast.
    ENDIF.
  ELSE.
    MESSAGE i115(zdl_shpstat).
  ENDIF.

ENDFORM.                    " PRINT_BILL_OF_LADING_OUTPUT
*&---------------------------------------------------------------------*
*&      Form  PRINT_PACKING_LIST_OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM print_packing_list_output .

  DATA : lt_nast TYPE TABLE OF nast,
         ls_nast TYPE nast.

  REFRESH lt_nast.
  SELECT *
      FROM nast
      INTO TABLE lt_nast
      WHERE  kappl EQ gc_kappl                       AND
             objky EQ vttk-tknum                     AND
             kschl IN (gc_kschl_zpkl, gc_kschl_zpl2) AND
             spras EQ sy-langu                       AND
             vstat EQ '0'.
  IF sy-subrc EQ 0.
    READ TABLE lt_nast INTO ls_nast WITH KEY kschl = gc_kschl_zpkl.
    IF sy-subrc EQ 0.
      PERFORM send_output USING ls_nast.
      RETURN.
    ENDIF.

    READ TABLE lt_nast INTO ls_nast WITH KEY kschl = gc_kschl_zpl2.
    IF sy-subrc EQ 0.
      PERFORM send_output USING ls_nast.
    ENDIF.
  ELSE.
    MESSAGE i116(zdl_shpstat).
  ENDIF.

ENDFORM.                    " PRINT_PACKING_LIST_OUTPUT
*&---------------------------------------------------------------------*
*&      Form  SEND_OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM send_output  USING is_nast TYPE nast.

  CLEAR nast.
  nast = is_nast.
  nast-pfld1 = vtts-vstel.
  IF sy-tcode EQ 'Z03732_PORTAL'.
    nast-ldest = 'LPDF'.
  ELSE.
    nast-ldest = 'LOCL'.
  ENDIF.
  PERFORM einzelnachricht_screen(rsnast00) USING gv_rcode.
  IF gv_rcode EQ 0.
    PERFORM nast_update(rsnast00) USING gv_rcode.
  ELSE.
*    MESSAGE e113(zdl_shpstat).      "E0VK952755   Kthakur-
    MESSAGE s113(zdl_shpstat).      "E0VK952755   Kthakur+
  ENDIF.

ENDFORM.                    " SEND_OUTPUT
* << End of Change - CC01
*&---------------------------------------------------------------------*
*&      Form  SET_HEADER_FIELDS_INIT
*&---------------------------------------------------------------------*
*       Perform Header Field housekeeping
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_header_fields_init .

* If gv_tsnum (Stage) has a value it means this transaction was
* entered from the DSR and only one Stage will exist
  IF gv_tsnum IS NOT INITIAL.
    gv_index = 1. "only one rec will exist in gt_stages_valid
  ENDIF.

* Clear variables
  CLEAR: gt_stages_valid,
         scr_dep_pt,
         scr_des_pt,
         scr_dep_pt_des,
         scr_des_pt_des,
         gv_signi_old,
         scr_dock_door,
         scr_dock_desc,
* Begin of R16I Big Button Update Staging Area changes 10/13/09
         scr_staging_area,
         scr_stagearea_desc,
         gv_exti2_old.
* End of R16I Big Button Update Staging Area changes 10/13/09

  "scr_txt_door.

* Retrieve Stage information
  READ TABLE gt_stages_valid INDEX gv_index .
  IF sy-subrc = 0.
    CLEAR vtts.
    SELECT SINGLE * FROM vtts
      WHERE tknum = vttk-tknum AND
            tsnum = gt_stages_valid-tsnum.
  ENDIF.

* dep point & des point can be plant,customer or vendor
  scr_dep_pt      = gt_stages_valid-dep_point.
  scr_des_pt      = gt_stages_valid-des_point.
  scr_dep_pt_des  = gt_stages_valid-dep_point_desc.
  scr_des_pt_des  = gt_stages_valid-des_point_desc.

* set the description for stop type - origin
  CASE vtts-zz_stoptype_o.
    WHEN 'CL'.
      scr_txt_org = 'Complete Load'(029).
    WHEN 'PL'.
      scr_txt_org = 'Partial Load'(030).
    WHEN 'CU'.
      scr_txt_org = 'Complete Unload'(031).
    WHEN 'PU'.
      scr_txt_org = 'Partial UnLoad'(032).
    WHEN ' ' .
      scr_txt_org = 'No Activity'(033).
  ENDCASE.
* set the description for stop type - destination

  CASE vtts-zz_stoptype_d.
    WHEN 'CL'.
      scr_txt_dest = 'Complete Load'(029).
    WHEN 'PL'.
      scr_txt_dest = 'Partial Load'(030).
    WHEN 'CU'.
      scr_txt_dest = 'Complete Unload'(031).
    WHEN 'PU'.
      scr_txt_dest = 'Partial UnLoad'(032).
    WHEN ' ' .
      scr_txt_dest = 'No Activity'(033).
  ENDCASE.

* Store current stage info into an hold structure
  MOVE vtts TO gt_vtts_old.

* Store current Container Id into a hold field
  MOVE vttk-signi TO gv_signi_old.
* Begin of R16I Big Button Update Staging Area changes 10/13/09
* Begin BCB03.
  IF vttk-exti2 = 'APO'.
    CLEAR: vttk-exti2.
  ENDIF.
* End BCB03
  MOVE vttk-exti2 TO gv_exti2_old.
* End of R16I Big Button Update Staging Area changes 10/13/09
ENDFORM.                    " SET_HEADER_FIELDS_INIT
*<<Begin of Change - 08/21/09 EDVK973207 R15  CR# 9246
*  Printing ZCCI output through  Big Button (Z03732)
*&---------------------------------------------------------------------*
*&      Form  PRINT_ZCI_OUTPUT
*&---------------------------------------------------------------------*
*       Print ZCCI output for all deliveries in the stage
*       where output is proposed for the delivery.
*----------------------------------------------------------------------*

FORM print_canadian_cust_inv_output.

  TYPES : BEGIN OF ts_deliveries,
            vbeln TYPE  na_objkey,     " Delivery Number
          END OF ts_deliveries.

  DATA : lt_deliveries TYPE STANDARD TABLE OF ts_deliveries,
         ls_deliveries LIKE LINE OF  lt_deliveries,
         lt_nast       TYPE TABLE OF nast,
         ls_nast       TYPE nast.

  CONSTANTS: lc_nacha LIKE nast-nacha VALUE 1,    "Print output
             lc_vstat LIKE nast-vstat VALUE '0'.  "Proposed

*  Deliveries in a stage
  IF gt_deliveries[] IS NOT INITIAL.
    LOOP AT gt_deliveries INTO gs_deliveries.
      ls_deliveries-vbeln = gs_deliveries-vbeln.
      APPEND ls_deliveries TO lt_deliveries.
    ENDLOOP.
  ENDIF.

  REFRESH lt_nast.

* Select all records from NAST table for proposed output
* for deliveries in the stage
  IF NOT lt_deliveries[] IS INITIAL.
    SELECT *
    FROM nast
    INTO TABLE lt_nast
    FOR ALL ENTRIES IN lt_deliveries
    WHERE  kappl EQ gc_v2                       AND
           objky EQ lt_deliveries-vbeln         AND
           kschl EQ gc_kschl_zcci               AND
           spras EQ sy-langu                    AND
           nacha EQ lc_nacha                   AND
           vstat EQ lc_vstat.


    IF sy-subrc EQ 0.
      SORT lt_deliveries  BY vbeln.
      CLEAR ls_nast.
* Print ZCCI output for all entries in NAST table with
* proposed output
      LOOP AT lt_nast INTO ls_nast .
        CLEAR ls_deliveries.
        READ TABLE lt_deliveries INTO ls_deliveries
                             WITH KEY vbeln = ls_nast-objky
                             BINARY SEARCH.
        IF sy-subrc EQ 0.
          PERFORM send_output USING ls_nast.
        ENDIF.
      ENDLOOP.
    ENDIF.
    RETURN.
  ENDIF.
ENDFORM.                    " PRINT_ZCI_OUTPUT

*>>End of Change - 08/21/09 EDVK973207 R15   Printing ZCCI output
* through  Big Button (Z03732)
*
*&---------------------------------------------------------------------*
*&      Form  DC_VALIDATIONS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*    Check if Pick and Pack flag is set to C for all
*      delivery  line items
*----------------------------------------------------------------------*
FORM dc_validations .
  DATA : lv_lines TYPE i,
         lv_tabix TYPE sy-tabix.

* Begin insert  CHG102464 TR#E0VK952755  by kthakur
* Check for DC facility

  SELECT SINGLE *  FROM tvswz WHERE vstel = vtts-vstel.
  IF sy-subrc = 0  AND tvswz-werks <> ' '.
    SELECT SINGLE * FROM zplant
        WHERE werks = tvswz-werks
        AND   type  = 'DC'.
    IF sy-subrc = 0 .
      DELETE gt_lips WHERE lfimg <= 0.


* Delete line items from internal table where pick(kosta) and
* pack(pksta) flag is set to 'C' or picking status is blank
      DELETE gt_vbup WHERE kosta = 'C'
                      AND  pksta = 'C'.
      DELETE gt_vbup WHERE kosta = ' '
                      AND  pksta = 'C'.
* Delete line item status records from vbup table if does not match
* with lips table records.
      LOOP AT gt_vbup.
        lv_tabix = sy-tabix.
        READ TABLE gt_lips WITH KEY vbeln = gt_vbup-vbeln
                                    posnr = gt_vbup-posnr.

        IF sy-subrc <> 0.
          DELETE gt_vbup INDEX lv_tabix.
        ENDIF.
      ENDLOOP.
* If any line item found with picking or packing flag not set
* to 'C'  then give error message .
      DESCRIBE TABLE gt_vbup LINES lv_lines.
      IF lv_lines > 0.
        READ TABLE gt_vbup INDEX 1.
        MESSAGE e528(zsd_dl) WITH gt_lips-vbeln gt_lips-posnr.
        "Delivery & Item & needs to be picked and packed.
      ENDIF.
    ENDIF.
  ENDIF.
ENDFORM.                    " DC_VALIDATIONS

*&---------------------------------------------------------------------*
*&      Form  GET_SALESDOC_HEADER_ITM_STATUS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_delv_header_itm_status .

  CLEAR : gt_vbup[], gt_vbup,gt_lips[], gt_lips,
          gt_vbuk[], gt_vbuk.

  CHECK gt_deliveries[] IS NOT INITIAL.

* Begin insert TPR# 31358  TR# EDVK970882  kthakur
* Validate all deliveries are not in 'A' or 'B' picking status.
  SELECT vbeln kostk
      INTO TABLE gt_vbuk
      FROM vbuk
      FOR ALL ENTRIES IN gt_deliveries
      WHERE vbeln = gt_deliveries-vbeln
      AND   kostk IN ('A' , 'B' ).

  SELECT vbeln posnr lfimg lgnum uecha zz_pickconf_ind pstyv
       INTO TABLE gt_lips
       FROM lips
       FOR ALL ENTRIES IN gt_deliveries
       WHERE vbeln = gt_deliveries-vbeln.
  IF gt_lips[] IS NOT INITIAL.
    DELETE gt_lips WHERE pstyv = gc_tatx.  "BCB08 insert
    SELECT vbeln posnr kosta pksta  INTO TABLE gt_vbup
            FROM vbup
            FOR ALL ENTRIES IN gt_lips
            WHERE vbeln = gt_lips-vbeln
            AND  posnr = gt_lips-posnr.
  ENDIF.
ENDFORM.                    " GET_SALESDOC_HEADER_ITM_STATUS
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_PICK_DELIVERY_QTYS
*&---------------------------------------------------------------------*
*       Validate that all Delivery Item pick quantities are equal to
*       their corresponding delivery quantities for the Deliveries on
*       the Stage
*----------------------------------------------------------------------*
*      <--P_LV_PD_ERROR  text
*      <--P_LV_VBELN  text
*      <--P_LV_POSNR  text
*----------------------------------------------------------------------*
FORM validate_pick_delivery_qtys  CHANGING cv_pd_error
                                           cv_pd_vbeln
                                           cv_pd_posnr.

  TYPES:

    BEGIN OF lts_lips,
      vbeln TYPE vbeln_vl, "delivery
      posnr TYPE posnr_vl, "delivery item
      lgmng TYPE lgmng,    "base uom
      pstyv TYPE pstyv_vl, "item category BCB08 insert
    END OF lts_lips,

    BEGIN OF lts_vbfa,
      vbelv TYPE vbeln_von, "preceding sales doc
      posnv TYPE posnr_von, "preceding sales doc item
      vbeln TYPE vbeln_nach,                            "BCB07
      posnn TYPE posnr_nach,                            "BCB07
      rfmng TYPE rfmng, "reference quantity
      plmin TYPE plmin, "BCB06 Quantity is calculated positively,
      "negatively or not at all
      erdat TYPE erdat,                                 "BCB07
      erzet TYPE erzet,                                 "BCB07
    END OF lts_vbfa.


  DATA:

    lt_lips   TYPE STANDARD TABLE OF lts_lips,
    ls_lips   TYPE lts_lips,

    lt_vbfa   TYPE STANDARD TABLE OF lts_vbfa,
    ls_vbfa   TYPE lts_vbfa,

    lv_qmenge TYPE xmenge.  "pick quantity variable


  CONSTANTS:

        lc_vbtyp_q TYPE char1 VALUE 'Q'. "doc flow type for Pick qty


  CLEAR: cv_pd_error,
         cv_pd_vbeln,
         cv_pd_posnr.


  CHECK gt_deliveries IS NOT INITIAL.

* Retrieve all pertinent LIPS info
  SELECT vbeln
         posnr
         lgmng
         pstyv "BCB08 insert
    FROM lips
    INTO TABLE lt_lips
    FOR ALL ENTRIES IN gt_deliveries
    WHERE vbeln = gt_deliveries-vbeln.
  SORT lt_lips.

  CHECK lt_lips IS NOT INITIAL.
  DELETE lt_lips WHERE pstyv = gc_tatx.  "BCB08 insert

* Retrieve all pertinent doc flow info for Pick Qty's
  SELECT vbelv
         posnv
         vbeln                                              "BCB07
         posnn                                              "BCB07
         rfmng
         plmin                                              "BCB06
         erdat                                              "BCB07
         erzet                                              "BCB07
    FROM vbfa
    INTO TABLE lt_vbfa
    FOR ALL ENTRIES IN lt_lips
    WHERE vbelv = lt_lips-vbeln
      AND posnv = lt_lips-posnr
      AND vbtyp_n = lc_vbtyp_q.
  SORT lt_vbfa.

* Process each Delivery on the Stage
  LOOP AT gt_deliveries INTO gs_deliveries.

    LOOP AT lt_lips INTO ls_lips WHERE vbeln = gs_deliveries-vbeln.

      CLEAR lv_qmenge.
*     Total up the Pick Qty for this delivery line item
      LOOP AT lt_vbfa INTO ls_vbfa
        WHERE vbelv = ls_lips-vbeln
          AND posnv = ls_lips-posnr.
*        ADD ls_vbfa-rfmng TO lv_qmenge. "BCB06 delete
*       Begin BCB06 insert
*       If the sign is not negative then add
        IF ls_vbfa-plmin NE '-'.
          ADD ls_vbfa-rfmng TO lv_qmenge.
        ELSE.
*         otherwise, subtract
          SUBTRACT ls_vbfa-rfmng FROM lv_qmenge.
        ENDIF.
*       End BCB06 insert
      ENDLOOP. "VBFA

*     If any Pick / Delivery quantity does not exist for a Delivery Item
*     then return to generate an error
      IF ls_lips-lgmng <> lv_qmenge.
        cv_pd_error = gc_x.  "error occurred
        cv_pd_vbeln = ls_lips-vbeln. "delivery number
        cv_pd_posnr = ls_lips-posnr.          "delivery item
        RETURN.
      ENDIF.

    ENDLOOP. "LT_LIPS

  ENDLOOP. "gt_deliveries

ENDFORM.                    " VALIDATE_PICK_DELIVERY_QTYS
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_IF_OPEN_TO_EXIST
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_if_open_to_exist .

  DATA: lv_lgnum LIKE t320-lgnum,
        lv_werks LIKE lips-werks,
        lv_lgort LIKE lips-lgort.

  DATA: lt_del_info TYPE STANDARD TABLE OF zdl_wm_del_info,
        lt_to_open  TYPE STANDARD TABLE OF zdl_wm_to_open_delv_lineitms,
        ls_to_open  TYPE  zdl_wm_to_open_delv_lineitms,
        ls_del_info TYPE zdl_wm_del_info,
        lv_lines    TYPE i.


* select the Plant & Storage Location of any Line Item
  CLEAR lv_werks.
  SELECT SINGLE werks lgort
    INTO (lv_werks, lv_lgort)
    FROM lips
    WHERE vbeln = gv_vbeln
      AND pstyv NE gc_tatx. "BCB08 insert
  IF lv_werks IS INITIAL.

  ELSE.
*   Select the Warehouse
    CLEAR lv_lgnum.
    SELECT SINGLE lgnum
      INTO lv_lgnum
      FROM t320
      WHERE werks = lv_werks
      AND   lgort = lv_lgort.
  ENDIF.

  REFRESH: lt_del_info, lt_to_open.
  CLEAR : ls_to_open.
* call the function module with the deliveries that are being
* loaded at the ware house.
  LOOP AT gt_deliveries INTO gs_deliveries.
    ls_del_info-vbeln = gs_deliveries-vbeln.
    APPEND ls_del_info TO lt_del_info.
    CLEAR ls_del_info.
  ENDLOOP.
  CALL FUNCTION 'ZDL_WM_DELIVERY_OPEN_PICK_QTY'
    EXPORTING
      i_tknum                        = vttk-tknum
      i_lgnum                        = lv_lgnum
    TABLES
      et_del_info                    = lt_del_info
      et_to_open                     = lt_to_open
    EXCEPTIONS
      shipment_not_entered           = 1
      no_deliveries_found_for_shpmnt = 2
      OTHERS                         = 3.
  DESCRIBE TABLE lt_to_open  LINES lv_lines.
  IF lv_lines > 0.
    CLEAR lv_lines.
    MESSAGE e000(zsd_dl) WITH 'Unconfirmed TOs exist'(064).
  ENDIF.

ENDFORM.                    " VALIDATE_IF_OPEN_TO_EXIST
*&---------------------------------------------------------------------*
*&      Form  GET_EXPORT_IND CMS29557
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_VTTP_VBELN TYPE likp-vbeln
*      <--P_LV_EXPKZ TYPE likp-expkz
*      <--P_LV_EXNUM TYPE likp-exnum
*----------------------------------------------------------------------*
FORM get_export_ind  USING    pv_vttp_vbeln TYPE likp-vbeln
                     CHANGING pv_lv_expkz TYPE likp-expkz
                              pv_lv_exnum TYPE likp-exnum.

  SELECT SINGLE expkz exnum INTO ( pv_lv_expkz, pv_lv_exnum )
                     FROM likp WHERE vbeln EQ pv_vttp_vbeln.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_MODE_TRANSPORT CMS29557
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LV_EXNUM TYPE likp-exnum
*      <--P_LR_EXPVZ  text
*      <--P_LV_EXPVZ TYPE eikp-expvz
*----------------------------------------------------------------------*
FORM get_mode_transport  USING   pv_lv_exnum TYPE likp-exnum
                         CHANGING pv_lr_expvz TYPE ltr_expvz
                                  pv_lv_expvz TYPE eikp-expvz.

  DATA lr_texpvz TYPE ltr_expvz.

  CLEAR:pv_lr_expvz,pv_lv_expvz.

  SELECT * INTO TABLE @DATA(lt_zdl_fields) FROM zdl_fields
                WHERE category EQ 'E03732'
                  AND fieldname EQ 'EXPVZ'.
  IF sy-subrc EQ 0.
    LOOP AT lt_zdl_fields INTO DATA(lw_zdl_fields).
      lr_texpvz = VALUE #( sign = 'I' option = 'EQ'
                             ( low = lw_zdl_fields-lowval
                               high = lw_zdl_fields-highval ) ).
      APPEND LINES OF lr_texpvz TO pv_lr_expvz.
    ENDLOOP.
  ENDIF.

  SELECT SINGLE expvz INTO pv_lv_expvz FROM eikp
                      WHERE exnum EQ pv_lv_exnum.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPDATE_HEURISTIC_FIELD  CMS#32822
*&---------------------------------------------------------------------*
*       Heuristic Protection value is updated to table VTTS
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
*Start of modification CMS 33493
*Start of modification CMS 32822
FORM update_heuristic_field .

  DATA : ls_vttk    TYPE vttkvb,
         lt_vttk    TYPE STANDARD TABLE OF vttkvb,
         lv_extid   TYPE balnrext,
         lt_app_log TYPE zca_bal_msg_tab,
         ls_app_log TYPE bal_s_msg,
         wa_msg_tab TYPE ztp_carrier_msg_str,
         lv_garg    TYPE seqg3-garg,
         lt_enq     TYPE STANDARD TABLE OF seqg3,
         ls_enq     TYPE seqg3,
         w_objectid LIKE cdhdr-objectid,
         w_newdata  LIKE vttk,
         w_olddata  LIKE vttk.

  REFRESH : lt_app_log, lt_enq.
  CLEAR : ls_app_log, wa_msg_tab, lv_garg, ls_enq, ls_vttk, lt_vttk, w_objectid, w_newdata, w_olddata.

  CASE sy-ucomm.
    WHEN 'LOCK'.
      vttk-zz_heur_protect = 'X'.
    WHEN 'UNLOCK'.
      vttk-zz_heur_protect = ' '.
  ENDCASE.

  IF vttk-tknum IS NOT INITIAL.

    CONCATENATE sy-mandt vttk-tknum INTO lv_garg.
    CALL FUNCTION 'ENQUEUE_READ'
      EXPORTING
        gclient               = sy-mandt
        gname                 = 'VTTK'
        garg                  = lv_garg
        guname                = '************'
        local                 = '0'
      TABLES
        enq                   = lt_enq
      EXCEPTIONS
        communication_failure = 1
        system_failure        = 2
        OTHERS                = 3.

    IF sy-subrc EQ 0.
      LOOP AT lt_enq INTO ls_enq.
        MESSAGE e000(zsd_dl) WITH vttk-tknum ':' TEXT-068 ls_enq-guname.
      ENDLOOP.
    ENDIF.

    CALL FUNCTION 'ENQUEUE_EZVTTK_BIGBUTTON'
      EXPORTING
        mode_vttk      = 'E'
        mandt          = sy-mandt
        tknum          = vttk-tknum
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.

    IF sy-subrc EQ 0.

      CALL FUNCTION 'RV_SHIPMENT_VIEW'
        EXPORTING
          shipment_number = vttk-tknum
          language        = sy-langu
          activity        = gc_a
        IMPORTING
          f_vttkvb        = ls_vttk
        EXCEPTIONS
          not_found       = 1
          no_authority    = 2
          OTHERS          = 5.

      IF sy-subrc EQ 0.
        w_olddata = ls_vttk.

        IF vttk-zz_heur_protect EQ gc_x.
          IF ls_vttk-zz_heur_protect EQ gc_x.
            MESSAGE e000(zsd_dl) WITH TEXT-067.  "Shipment already updated
          ENDIF.
          ls_vttk-zz_heur_protect = gc_x.
        ELSE.
          ls_vttk-zz_heur_protect = ' '.
        ENDIF.
        ls_vttk-aenam = sy-uname.
        ls_vttk-aedat = sy-datum.
        ls_vttk-aezet = sy-uzeit.

        APPEND ls_vttk TO lt_vttk.

        CALL FUNCTION 'RV_SHIPMENT_UPDATE_DB'
          EXPORTING
            i_flag_tra_complete = 'X'
            i_tra_save_caller   = 'X'
          TABLES
            db_vttk_upd         = lt_vttk.

        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = 'X'.

        IF sy-subrc EQ 0.
          IF ls_vttk-zz_heur_protect = gc_x.
            MESSAGE s000(zsd_dl) WITH TEXT-066.  " Shipment Protected
          ELSE.
            MESSAGE s000(zsd_dl) WITH TEXT-069.  " Shipment Unprotected
          ENDIF.

          w_objectid = vttk-tknum.
          w_newdata = ls_vttk.

          CALL FUNCTION 'CHANGEDOCUMENT_OPEN'
            EXPORTING
              objectclass             = 'TRANSPORT'
              objectid                = w_objectid
              planned_or_real_changes = 'R'
            EXCEPTIONS
              sequence_invalid        = 1
              OTHERS                  = 2.
          IF sy-subrc EQ 0.

            CALL FUNCTION 'CHANGEDOCUMENT_SINGLE_CASE'
              EXPORTING
                change_indicator       = 'U'
                tablename              = 'VTTK'
                workarea_new           = w_newdata
                workarea_old           = w_olddata
              EXCEPTIONS
                nametab_error          = 1
                open_missing           = 2
                position_insert_failed = 3
                OTHERS                 = 4.
          ENDIF.

          CALL FUNCTION 'CHANGEDOCUMENT_CLOSE'
            EXPORTING
              date_of_change          = sy-datum
              objectclass             = 'TRANSPORT'
              objectid                = w_objectid
              tcode                   = sy-tcode
              time_of_change          = sy-uzeit
              username                = sy-uname
              planned_or_real_changes = 'R'
              no_change_pointers      = 'X'
            EXCEPTIONS
              header_insert_failed    = 1
              no_position_inserted    = 2
              object_invalid          = 3
              open_missing            = 4
              position_insert_failed  = 5
              OTHERS                  = 6.

        ELSE.
          MESSAGE e000(zsd_dl) WITH TEXT-065.  " error in updating table

        ENDIF.

        CALL FUNCTION 'DEQUEUE_EZVTTK_BIGBUTTON'
          EXPORTING
            mode_vttk = 'E'
            mandt     = sy-mandt
            tknum     = vttk-tknum.
      ENDIF.

* Wirting the first line of the messages with Shipment #,
      ls_app_log-msgty = 'I'.
      ls_app_log-msgid = 'ZDL_SHPSTAT'.
      ls_app_log-msgno = '124'.

      CONCATENATE 'Shipment number: ' vttk-tknum
                  ' Heuristic protection'
                   ' set to: ' ls_vttk-zz_heur_protect
                  ' On :' ls_vttk-aedat
                  ' changed by :' ls_vttk-aenam
                  INTO wa_msg_tab-text SEPARATED BY space.

      ls_app_log-msgv1 = wa_msg_tab-text+0(50).
      ls_app_log-msgv2 = wa_msg_tab-text+50(50).
      ls_app_log-msgv3 = wa_msg_tab-text+100(50).
      ls_app_log-msgv4 = wa_msg_tab-text+150(50).
      APPEND ls_app_log TO lt_app_log.

* Populate Shipment number date and time stamp in the external ID
      CONCATENATE vttk-tknum '-' sy-datum '-' sy-uzeit INTO
                  lv_extid.

*** Write the return messages to the APP Log
      CALL METHOD zcl_wm_misc_func=>write_application_log
        EXPORTING
          iv_repid        = sy-repid
          iv_log_object   = 'ZDL_SHIPMENT'
          iv_log_subobj   = 'ZDL_HEUR_PROTECT'
          iv_applog_extid = lv_extid
          it_messages     = lt_app_log[].

    ENDIF.
  ENDIF.
ENDFORM.
*End of modification CMS 32822
*&---------------------------------------------------------------------*
*&      Form  SHIPMENT_SCREEN_PROTECT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM shipment_screen_protect .

  LOOP AT SCREEN.
    CASE screen-name.
      WHEN 'VTTK-ZZ_HEUR_PROTECT'.
        screen-input = '0'.
      WHEN 'HEUR_UNLOCK'.
        IF vttk-zz_heur_protect IS NOT INITIAL.
          screen-active = '1'.
        ELSE.
          screen-active = '0'.
        ENDIF.
      WHEN 'HEUR_LOCK'.
        IF vttk-zz_heur_protect IS INITIAL.
          screen-active = '1'.
        ELSE.
          screen-active = '0'.
        ENDIF.
    ENDCASE.

    MODIFY SCREEN.

  ENDLOOP.

ENDFORM.
*End of modification CMS 33493

*&---------------------------------------------------------------------*
*&      Form  GET_STR_DIFF
*&---------------------------------------------------------------------*
* CMS 34502
* Form returns chars from string IV_STR2 which are not found in IV_STR1
*----------------------------------------------------------------------*

FORM get_str_diff USING iv_str1 TYPE string
                        iv_str2 TYPE c
                        cv_result TYPE string.

  DATA: lv_n TYPE i.

  CLEAR: cv_result.

  DO.
    IF lv_n >= strlen( iv_str2 ). EXIT. ENDIF.
    TRY.
        IF iv_str2+lv_n(1) <> space AND
           NOT contains( val = iv_str1
                         sub = to_upper( iv_str2+lv_n(1) ) ).
          cv_result = cv_result && iv_str2+lv_n(1).
        ENDIF.
      CATCH cx_sy_strg_par_val.
        EXIT.
    ENDTRY.

    lv_n = lv_n + 1.

  ENDDO.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRINT_PROFORMA_ZPFM
*&---------------------------------------------------------------------*
*   This is a Copy Code from Canadian Invoice form and
*   the KSCHL is Changed to ZPFM.
*----------------------------------------------------------------------*
FORM print_proforma_zpfm .

  TYPES : BEGIN OF ty_s_deliveries,
            vbeln TYPE  na_objkey,     " Delivery Number
          END OF ty_s_deliveries,
          ty_t_deliveries TYPE STANDARD TABLE OF ty_s_deliveries WITH EMPTY KEY.

*  DATA : "lt_deliveries TYPE STANDARD TABLE OF ts_deliveries,
  "ls_deliveries LIKE LINE OF  lt_deliveries,
*    lt_nast TYPE TABLE OF nast,
*    ls_nast TYPE nast.

  CONSTANTS: "lc_nacha      LIKE nast-nacha VALUE 1,    "Print output JWILL68 CD#366
    lc_nacha_8    TYPE nast-nacha VALUE 8, "JWILL68 CD#366
    lc_vstat      LIKE nast-vstat VALUE '0',  "Proposed
    lc_kschl_zpfm TYPE c LENGTH 4 VALUE 'ZPFM'. "Pro Forma Output


*  Deliveries in a stage
*  IF gt_deliveries[] IS NOT INITIAL.
*    LOOP AT gt_deliveries INTO gs_deliveries.
*      ls_deliveries-vbeln = gs_deliveries-vbeln.
*      APPEND ls_deliveries TO lt_deliveries.
*    ENDLOOP.
*  ENDIF.

  DATA(lt_deliveries) = VALUE ty_t_deliveries(
                                     FOR ls_deliveries IN gt_deliveries
                                     ( vbeln = ls_deliveries-vbeln ) ).

*  REFRESH lt_nast.

* Select all records from NAST table for proposed output
* for deliveries in the stage
  IF NOT lt_deliveries[] IS INITIAL.
    SELECT *
    FROM nast
    INTO TABLE @DATA(lt_nast)
    FOR ALL ENTRIES IN @lt_deliveries
    WHERE  kappl EQ @gc_v2                       AND
           objky EQ @lt_deliveries-vbeln         AND
           kschl EQ @lc_kschl_zpfm               AND
           spras EQ @sy-langu                    AND
*           nacha EQ lc_nacha                    AND JWILL68 CD#366
           nacha EQ @lc_nacha_8                  AND "JWILL68 CD#366
           vstat EQ @lc_vstat.


    IF sy-subrc EQ 0.
*      SORT lt_deliveries  BY vbeln.
*      CLEAR ls_nast.
* Print ZCCI output for all entries in NAST table with
* proposed output
      LOOP AT lt_nast INTO DATA(ls_nast).
*        CLEAR ls_deliveries.
*        READ TABLE lt_deliveries INTO ls_deliveries
*                             WITH KEY vbeln = ls_nast-objky
*                             BINARY SEARCH.
        DATA(ls_deliveries_output) = VALUE #( lt_deliveries[ vbeln = ls_nast-objky
                                                           ] OPTIONAL ).
*        IF sy-subrc EQ 0.
        IF ls_deliveries_output IS NOT INITIAL.
* Lock Delivery.
          DATA(lv_vbeln) = CONV likp-vbeln( ls_nast-objky ).
          CALL FUNCTION 'ENQUEUE_EVVBLKE'
            EXPORTING
              mode_likp      = 'E'
              mandt          = sy-mandt
              vbeln          = lv_vbeln
            EXCEPTIONS
              foreign_lock   = 1
              system_failure = 2
              OTHERS         = 3.
          IF sy-subrc <> 0.
*            Do nothing
          ENDIF.

          PERFORM send_output USING ls_nast.

* Unlock Delivery.
          CALL FUNCTION 'DEQUEUE_EVVBLKE'
            EXPORTING
              mode_likp = 'E'
              mandt     = sy-mandt
              vbeln     = lv_vbeln.
        ENDIF.
      ENDLOOP.
    ENDIF.
    RETURN.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PRINT_PROFORMA_ZPFD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print_proforma_zpfd .
  TYPES : BEGIN OF ty_s_vbeln,
            vbeln TYPE  na_objkey,
          END OF ty_s_vbeln,
          ty_t_vbeln TYPE STANDARD TABLE OF ty_s_vbeln WITH EMPTY KEY.

  DATA: lt_invoice TYPE ty_t_vbeln.

  CONSTANTS: lc_nacha      TYPE na_nacha VALUE 1,
             lc_vstat_0    TYPE na_vstat VALUE '0',
             lc_vstat_1    TYPE na_vstat VALUE '1',
             lc_v3         TYPE sna_kappl VALUE 'V3',
             lc_kschl_zpfm TYPE c LENGTH 4 VALUE 'ZPFM', "Pro Forma Output
             lc_kschl_zpfd TYPE c LENGTH 4 VALUE 'ZPFD'. "Pro Forma Output

*To get the invoices for each delivery Use VBFA where
*VBELV = Delivery number and VPTYP_N = ‘U’ then
*get the value in VBELN.  Save this to lt_invoices.
*Do this for each delivery returned from gt_deliveries

  LOOP AT gt_deliveries INTO DATA(ls_deliveries).
    SELECT SINGLE MAX( vbeln ) AS latest_invoice,
           MAX( erdat ) AS create_date,
           MAX( erzet ) AS create_time
      FROM vbfa
      INTO @DATA(ls_latest_invoice)
      WHERE vbelv = @ls_deliveries-vbeln AND
            vbtyp_n = 'U'.
    APPEND VALUE #( vbeln = ls_latest_invoice-latest_invoice ) TO lt_invoice.
  ENDLOOP.

  DATA(lt_invoice_adjusted) = VALUE ty_t_vbeln(
                              FOR ls_invoice IN lt_invoice
                              ( vbeln = ls_invoice-vbeln ) ).
  IF lt_invoice_adjusted IS NOT INITIAL.
    SELECT *
      FROM nast
      INTO TABLE @DATA(lt_nast_invoice)
      FOR ALL ENTRIES IN @lt_invoice_adjusted
      WHERE  kappl = @lc_v3                     AND
             objky = @lt_invoice_adjusted-vbeln AND
             kschl = @lc_kschl_zpfd             AND
             spras = @sy-langu                  AND
             nacha = @lc_nacha                  AND
             ( vstat = @lc_vstat_0              OR
             vstat = @lc_vstat_1 ).
    IF sy-subrc EQ 0.

* Print ZCCI output for all entries in NAST table with
* proposed output
      LOOP AT lt_nast_invoice INTO DATA(ls_nast_invoice).
        DATA(ls_invoice_output) = VALUE #( lt_invoice_adjusted[ vbeln = ls_nast_invoice-objky
                                                           ] OPTIONAL ).
        IF ls_invoice_output IS NOT INITIAL.
          PERFORM send_output USING ls_nast_invoice.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDFORM.

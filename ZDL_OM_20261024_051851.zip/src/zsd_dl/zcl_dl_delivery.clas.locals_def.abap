*"* use this source file for any type declarations (class
*"* definitions, interfaces or data types) you need for method
*"* implementation or private method's signature

TYPES : BEGIN OF gty_item_info,
          vbeln  TYPE vbeln_vl,
          posnr  TYPE posnr_vl,
          object TYPE REF TO zcl_dl_delivery_item,
        END OF gty_item_info,

        gt_item_info TYPE TABLE OF gty_item_info,
        gs_item_info TYPE          gty_item_info.

FUNCTION-POOL ZSD_DL_F01276.                "MESSAGE-ID .



Data:
  gc_app_log_object        Type balobj_d  value 'ZDL_F01276',
  gc_app_log_subobj        Type balsubobj value 'ZDL_F01276_TALLY',
  gc_inv_code(7)           Type c         value 'F01276_',
  gc_msg_typ               Type SYMSGTY   value 'I',
  gc_msg_id                Type SYMSGID   value 'ZDL_F01276',
  gc_msg_no                Type SYMSGNO   value '000'.
.

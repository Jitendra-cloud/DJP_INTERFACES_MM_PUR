*&---------------------------------------------------------------------*
*&  Include           ZDL_C10156_INVENTORY_TOP
*&---------------------------------------------------------------------*
*This tables declaration is for menu button in the screen.
TABLES: sscrfields.

*This type pools declaration is for the ALV colour coloumn.
TYPE-POOLS: col.

* Local class defention
INCLUDE zdl_c10156_inventory_def.

*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_ORD_DETAILMAC .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  ORD_MACHINE_SINGLE
*&---------------------------------------------------------------------*
*       Returns a single machine number for a single order
*----------------------------------------------------------------------*
  FORM ord_machine_single CHANGING st_ord_machines
                                          STRUCTURE zst_orders_machines.

* Single record SELECT fields
    DATA: l_aufpl LIKE afko-aufpl,
          l_arbid LIKE afvc-arbid,
          l_arbpl LIKE crhd-arbpl.

    SELECT SINGLE aufpl
      FROM afko
      INTO l_aufpl
     WHERE aufnr = st_ord_machines-aufnr.
    IF sy-subrc = 0.

      SELECT SINGLE arbid
        FROM afvc
        INTO l_arbid
       where aufpl = l_aufpl
         AND aplzl = c_aplzl.
      IF sy-subrc = 0.

        SELECT SINGLE arbpl
          FROM crhd
          INTO l_arbpl
         WHERE objty = c_objty
           AND OBJID = l_arbid.
        IF sy-subrc = 0.

          st_ord_machines-arbpl = l_arbid.

        ENDIF. "SELECT SINGLE arbpl success
      ENDIF."SELECT SINGLE arbid success
    ENDIF."SELECT SINGLE aufpl success

    IF st_ord_machines-arbpl IS INITIAL.
      RAISE machine_number_not_found.
    ENDIF.

  ENDFORM.                    " ORD_MACHINE_SINGLE

*&---------------------------------------------------------------------*
*&  Include           ZSDE10539_TOP
*&---------------------------------------------------------------------*


tables: sscrfields,
        likp,
        vbuk,
        ekkn,
        makt,
        mara,
        kna1,
        edidc,
        edids,
        zbt_alter.

type-pools: slis.

* data for ALV processing
data: gr_ba         type ref to cl_gui_alv_grid.
data: gt_fcat_ba    type lvc_t_fcat.
data: gs_variant_ba type disvariant.

data: gr_li         type ref to cl_gui_alv_grid.
data: gt_fcat_li    type lvc_t_fcat.
data: gs_variant_li type disvariant.

data: gt_listhead type slis_t_listheader with header line.

data: g_ucomm type sy-ucomm.
data: okcode  type sy-ucomm.

data: g_output_type like bapioutptype-output_type.
data: gt_char type table of klvmera.

ranges: r_vstel for likp-vstel.

** table for report output
data: begin of gt_ba occurs 0,
        vbeln1  like likp-vbeln,
        posnr   like lips-posnr,
        matnr   like lips-matnr,
        maktx   like makt-maktx,
        vbeln   like ekkn-vbeln,
        vbelp   like ekkn-vbelp,
        ebeln   like ekkn-ebeln,
        ebelp   like ekkn-ebelp,
        werks   like lips-werks,
        lgort   like lips-lgort,
        appm_gsm(3)  type n,
     "   um_APPM_GSM  like BAPI_CHAR-unit,
        charg   like mska-charg,
        kalab   like mska-kalab,
        meins   like mara-meins,

        appm_reel_width           type p decimals 1,
     "   um_APPM_REEL_WIDTH        like BAPI_CHAR-unit,
        appm_reel_diameter        type p decimals 0,
     "   um_APPM_REEL_DIAMETER     like BAPI_CHAR-unit,
        appm_posting_date         like sy-datum,
        age                       type i,
        appm_production_order(10) type c,
        appm_net_weight           type p decimals 2,
     "   um_APPM_NET_WEIGHT        like BAPI_CHAR-unit,
        appm_gross_weight         type p decimals 2,
     "   um_APPM_GROSS_WEIGHT      like BAPI_CHAR-unit,
        tare                      type p decimals 2,

        mark(1) type c,
      end of gt_ba.

data: begin of gt_li occurs 0,
        vbeln1  like likp-vbeln,
        posnr   like lips-posnr,
        matnr   like lips-matnr,
        maktx   like makt-maktx,
        vbeln   like ekkn-vbeln,
        vbelp   like ekkn-vbelp,
        ebeln   like ekkn-ebeln,
        ebelp   like ekkn-ebelp,
        werks   like lips-werks,
        lgort   like lips-lgort,
        uebtk   like vbap-uebtk,
        uebto   like vbap-uebto,
        untto   like vbap-untto,
        lfimg1  like lips-lfimg,
        vrkme   like lips-vrkme,
        lfimg   like lips-lfimg,
        meins   like mara-meins,
        lftot   like lips-lfimg,
        lfdif   like lips-lfimg,
        lfovt   like lips-lfimg,
        lfovr   like lips-lfimg,
        lfunt   like lips-lfimg,
        lfund   like lips-lfimg,
        gewei   like lips-gewei,
        icon(4) type c,
        comment(20) type c,
        begin of err,
          no_batch(1) type c,
          error(1)    type c,
          conv(1)     type c,
        end of err,
      end of gt_li.

constants: c_xx type lvc_s_stbl value 'XX'.

*-----------------------------------------------------------------------
* Selection screen
* Select options
selection-screen begin of block b1 with frame title text-s01.
"parameters: p_vstel like likp-vstel matchcode object h_tvst.
parameters: p_vbeln like likp-vbeln matchcode object vmvl
                                    memory id vl obligatory.
selection-screen skip.
parameters: p_mark as checkbox default 'X'.
selection-screen end of block b1.

* Display options
selection-screen begin of block b0 with frame title text-s00.
selection-screen begin of line.
selection-screen comment (30) for field p_var_ba.
parameters: p_var_ba type disvariant-variant.
selection-screen comment 48(30) g_vtx_ba.
selection-screen end of line.
selection-screen begin of line.
selection-screen comment (30) for field p_var_li.
parameters: p_var_li type disvariant-variant.
selection-screen comment 48(30) g_vtx_li.
selection-screen end of line.
selection-screen end of block b0.

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_DELY_WINDOWTOP.            " Global Data
  INCLUDE LZSD_DL_DELY_WINDOWUXX.            " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_DELY_WINDOWF...            " Subprograms
* INCLUDE LZSD_DL_DELY_WINDOWO...            " PBO-Modules
* INCLUDE LZSD_DL_DELY_WINDOWI...            " PAI-Modules

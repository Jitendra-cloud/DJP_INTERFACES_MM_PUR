*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations
CLASS lcl_rail_frght_fuel_schrg DEFINITION FINAL.
  PUBLIC SECTION.

* Types Declaration.
* Shipment Header
    TYPES: BEGIN OF ty_s_vttk,
             tknum TYPE tknum,
             shtyp TYPE shtyp,
             tplst TYPE tplst,
             vsart TYPE vsarttr,
             vsbed TYPE vsbed,
             route TYPE routr,
             signi TYPE signi,
             dalen TYPE dalend,
             sttrg TYPE sttrg,
             datbg TYPE datbg,
             daten TYPE datend,
             tdlnr TYPE tdlnr,
             distz TYPE distz,
             sdabw TYPE sdabw,
           END OF ty_s_vttk,

* Mill Texts ( TVSBT ) data
           BEGIN OF ty_s_tplst,
             tplst TYPE tplst,
             bezei TYPE bezei20,
           END OF ty_s_tplst,

* Route text
           BEGIN OF ty_s_route_text,
             route TYPE route,
             bezei TYPE routbez,
           END OF ty_s_route_text,

* Shipment Condition Text
           BEGIN OF ty_s_vsbed_text,
             vsbed TYPE vsbed,
             vtext TYPE vsbed_bez,
           END OF ty_s_vsbed_text,

*Stage of Shipment
           BEGIN OF ty_s_vtts,
             tknum      TYPE tknum,
             tsnum      TYPE tsnum,
             knota      TYPE knota,
             knotz      TYPE knotz,
             kunnz      TYPE kunnz,
             edpstlz    TYPE edpstlz,
             edort01    TYPE edort01,
             zz_load_q1 TYPE zdl_load_q1,
             zz_load_u1 TYPE zdl_load_u1,
           END OF ty_s_vtts,

* Shipment Item
           BEGIN OF ty_s_vttp,
             tknum TYPE tknum,
             tpnum TYPE tpnum,
             vbeln TYPE vbeln_vl,
           END OF ty_s_vttp,

* Sales Document: Item Data
           BEGIN OF ty_s_vbap,
             vbeln TYPE vbeln_vl,
             spart TYPE spart,
             mfrgr TYPE mfrgr,
           END OF ty_s_vbap,

* SD Document: Delivery Header Data
           BEGIN OF ty_s_likp,
             vbeln TYPE vbeln_vl,
             btgew TYPE gsgew,
             gewei TYPE gewei,
           END OF ty_s_likp,

* SD document: Delivery: Item data
           BEGIN OF ty_s_lips,
             vbeln TYPE vbeln_vl,
             posnr TYPE posnr_vl,
             vgbel TYPE vgbel,
             vgpos TYPE vgpos,
           END OF  ty_s_lips,

* General Data in Customer Master
           BEGIN OF ty_s_kna1,
             kunnr TYPE kunnr,
             land1 TYPE land1_gp,
             name1 TYPE name1_gp,
             ort01 TYPE ort01_gp,
             pstlz TYPE pstlz,
             regio TYPE regio,
           END OF ty_s_kna1,

* Shipment Costs: Item Data
           BEGIN OF ty_s_vkfp,
             fknum  TYPE fknum,
             netwr  TYPE netwr_p,
             waers  TYPE waers_p,
             exti1  TYPE exti1_p,
             trfzna TYPE trfzna,
             trfznz TYPE trfznz,
             kzwi2  TYPE kzwi2,
             kzwi4  TYPE kzwi4,
           END OF ty_s_vkfp,

* General Data in Customer Master
           BEGIN OF ty_s_lfa1,
             lifnr TYPE lifnr,
             name1 TYPE name1_gp,
           END OF ty_s_lfa1,

* AP Data
*Document Item: Incoming Invoice
           BEGIN OF ty_s_rseg,
             belnr TYPE belnr_d,
             gjahr TYPE gjahr,
             bukrs TYPE bukrs,
             werks TYPE werks_d,
             xblnr TYPE xblnr1,
           END OF ty_s_rseg,

* Document Header: Invoice Receipt
           BEGIN OF ty_s_rbkp,
             belnr TYPE belnr_d,
             gjahr TYPE gjahr,
             lifnr TYPE lifre,
             xblnr TYPE xblnr1,
           END OF ty_s_rbkp,

* Accounting: Secondary Index for Vendors (Cleared Items)
           BEGIN OF ty_s_bsak,
             bukrs TYPE bukrs,
             lifnr TYPE lifnr,
             gjahr TYPE gjahr,
             augdt TYPE augdt,
             augbl TYPE augbl,
             belnr TYPE belnr_d,
             budat TYPE budat,
             bldat TYPE bldat,
             cpudt TYPE cpudt,
             waers TYPE waers,
             xblnr TYPE xblnr1,
             bschl TYPE bschl,
             dmbtr TYPE dmbtr,
             wrbtr TYPE wrbtr,
             sgtxt TYPE sgtxt,
           END OF ty_s_bsak,

* Posting key text
           BEGIN OF ty_s_posting_text,
             bschl TYPE bschl,
             ltext TYPE text_bslt,
           END OF ty_s_posting_text,

* Route information
           BEGIN OF ty_s_route_info,
             bezei  TYPE routbez,
             routid TYPE routid,
             route  TYPE route,
           END OF ty_s_route_info,

* Rate information
           BEGIN OF ty_s_rate_info,
             fright_rate      TYPE kbetr_kond,
             fright_surcharge TYPE kbetr_kond,
           END OF ty_s_rate_info,

* Rate info input structure
           BEGIN OF ty_s_input_data,
             kappl     TYPE kappl,
             vsart     TYPE vsart,
             sdabw     TYPE sdabw,
             tplst     TYPE tplst,
             knota     TYPE knota,
             knotz     TYPE knotz,
             shtyp     TYPE shtyp,
             mfrgr     TYPE zzstcc,
             kunnr     TYPE kunnr,
             kunwe     TYPE kunwe,
             ort01     TYPE /saprgx/cstvnd_city,
             regio     TYPE regioz,
             rail_name TYPE zsdc1976_region_name,
             trfzna    TYPE trfzna,
             trfznz    TYPE trfznz,
             land1     TYPE land1z,
             vsbed     TYPE vsbed,
             route     TYPE routr,
             tdlnr     TYPE tdlnr,
             date      TYPE dptbg,
           END OF ty_s_input_data,

* Archive Key
           BEGIN OF ty_s_archive,
             arch_key TYPE arkey,
             date     TYPE char4,
           END OF ty_s_archive,

*Rail carrier region names
           BEGIN OF ty_s_rail_name,
             cstvnd_city  TYPE zsdc1976_city,
             cstvnd_state TYPE regio,
             region_name  TYPE zsdc1976_region_name,
           END OF  ty_s_rail_name,

           ty_t_vttk        TYPE STANDARD TABLE OF ty_s_vttk WITH DEFAULT KEY,
           ty_t_tplst_text  TYPE STANDARD TABLE OF ty_s_tplst WITH DEFAULT KEY,
           ty_t_route_text  TYPE STANDARD TABLE OF ty_s_route_text WITH DEFAULT KEY,
           ty_t_vsbed_text  TYPE STANDARD TABLE OF ty_s_vsbed_text WITH DEFAULT KEY,
           ty_t_vtts        TYPE STANDARD TABLE OF ty_s_vtts WITH DEFAULT KEY,
           ty_t_vttp        TYPE STANDARD TABLE OF ty_s_vttp WITH DEFAULT KEY,
           ty_t_vbap        TYPE STANDARD TABLE OF ty_s_vbap WITH DEFAULT KEY,
           ty_t_kna1        TYPE STANDARD TABLE OF ty_s_kna1 WITH DEFAULT KEY,
           ty_t_vfkp        TYPE STANDARD TABLE OF ty_s_vkfp WITH DEFAULT KEY,
           ty_t_lfa1        TYPE STANDARD TABLE OF ty_s_lfa1 WITH DEFAULT KEY,
           ty_t_rseg        TYPE STANDARD TABLE OF ty_s_rseg WITH DEFAULT KEY,
           ty_t_rbkp        TYPE STANDARD TABLE OF ty_s_rbkp WITH DEFAULT KEY,
           ty_t_bsak        TYPE STANDARD TABLE OF ty_s_bsak WITH DEFAULT KEY,
           ty_t_archive     TYPE STANDARD TABLE OF ty_s_archive WITH DEFAULT KEY,
           ty_t_likp        TYPE STANDARD TABLE OF ty_s_likp WITH DEFAULT KEY,
           ty_t_lips        TYPE STANDARD TABLE OF ty_s_lips WITH DEFAULT KEY,
           ty_t_rail_name   TYPE STANDARD TABLE OF ty_s_rail_name WITH DEFAULT KEY,
           ty_t_posting_key TYPE STANDARD TABLE OF ty_s_posting_text WITH DEFAULT KEY,
           ty_t_archive_key TYPE STANDARD TABLE OF admi_file_davlnk.

    CLASS-DATA:gr_date    TYPE piq_selopt_t,
               gr_tknum   TYPE RANGE OF tknum,
               gv_tplst   TYPE tplst,
               gv_message TYPE string.

    CLASS-DATA: gt_vttk           TYPE  ty_t_vttk,
                gt_tplst_text     TYPE ty_t_tplst_text,
                gt_route_text     TYPE ty_t_route_text,
                gt_vsbed_text     TYPE ty_t_vsbed_text,
                gt_vtts           TYPE ty_t_vtts,
                gt_vttp           TYPE ty_t_vttp,
                gt_vbap           TYPE ty_t_vbap,
                gt_kna1           TYPE ty_t_kna1,
                gt_vfkp           TYPE ty_t_vfkp,
                gt_lfa1           TYPE ty_t_lfa1,
                gt_rseg           TYPE ty_t_rseg,
                gt_rbkp           TYPE ty_t_rbkp,
                gt_bsak           TYPE ty_t_bsak,
                gt_likp           TYPE ty_t_likp,
                gt_lips           TYPE ty_t_lips,
                gt_rail_name      TYPE ty_t_rail_name,
                gt_post_key       TYPE ty_t_posting_key,
                gt_rail_route_911 TYPE zdle11462_lt_rail_route_t,
                gt_rail_route_909 TYPE zdle11462_lt_rail_route_t,
                gt_rail_route_902 TYPE zdle11462_lt_rail_route_t,
                gt_rail_route_907 TYPE zdle11462_lt_rail_route_t,
                gt_rail_route_908 TYPE zdle11462_lt_rail_route_t,
                gt_rail_route_910 TYPE zdle11462_lt_rail_route_t,
                gt_rail_rate_958  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_946  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_936  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_929  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_933  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_967  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_944  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_959  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_922  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_965  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_947  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_966  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_942  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_934  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_919  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_906  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_983  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_969  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_920  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_981  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_992  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_995  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_900  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_971  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_943  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_937  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_923  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_925  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_941  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_930  TYPE zdle11459_lt_rail_rate_t,
                gt_alv_data       TYPE STANDARD TABLE OF zcl_dl_r10514_frght_fuel_schrg=>ty_s_alv_data.

    CLASS-METHODS: get_data,
      prepare_output_data,
      validate_tplst,
      validate_tknum.

  PRIVATE SECTION.
    CLASS-METHODS:
      get_archive_key
        IMPORTING
          iv_object   TYPE arch_obj-object
        EXPORTING
          et_arch_key TYPE ty_t_archive_key,
      filter_archive_key
        IMPORTING
          it_arch_key TYPE ty_t_archive_key
        EXPORTING
          et_arch_key TYPE ty_t_archive,
      archive_read
        IMPORTING
          iv_archiv_key     TYPE arkey
          iv_object         TYPE arch_obj-object
        EXPORTING
          ev_archive_handle TYPE sy-tabix,
      get_archive_next_object
        IMPORTING
          iv_archive_handle TYPE sy-tabix
        EXPORTING
          ev_exit           TYPE boolean,
      get_archive_next_record
        IMPORTING
          iv_archive_handle TYPE sy-tabix
        EXPORTING
          ev_exit           TYPE boolean
          eo_record_ref     TYPE REF TO data
          ev_object_name    TYPE rkz_dbna,
      get_vttk_archive_data,
      get_vtts_archive_data,
      get_vttp_archive_data,
      get_tplst_text,
      get_route_text,
      get_vsbed_text,
      get_lips_archive_data,
      get_likp_archive_data,
      get_vbap_archive_data,
      get_vfkp_archive_data,
      get_kna1_data,
      get_rail_names,
      get_lfa1_data,
      get_rail_route_data,
      get_rail_rate_data,
      get_rseg_data,
      get_rbkp_data,
      get_bsak_data,
      get_posting_key_text,
      get_freight_route_info
        IMPORTING iv_kappl             TYPE kappl DEFAULT 'RG'
                  iv_tplst             TYPE tplst
                  iv_kunnr             TYPE kunnr OPTIONAL
                  iv_vsbed             TYPE vsbed OPTIONAL
                  iv_route             TYPE routr
                  iv_tdlnr             TYPE tdlnr
                  iv_date              TYPE dptbg
                  iv_pstlz             TYPE pstlz
        RETURNING VALUE(es_route_info) TYPE ty_s_route_info,
      get_freight_route_info_tdlnr
        IMPORTING iv_kappl             TYPE kappl DEFAULT 'RG'
                  iv_tplst             TYPE tplst
                  iv_kunnr             TYPE kunnr OPTIONAL
                  iv_vsbed             TYPE vsbed OPTIONAL
                  iv_route             TYPE routr
                  iv_date              TYPE dptbg
                  iv_pstlz             TYPE pstlz
        RETURNING VALUE(es_route_info) TYPE ty_s_route_info,
      get_freight_rate_info
        IMPORTING
          is_rate_input TYPE ty_s_input_data
          iv_distz      TYPE distz
        EXPORTING
          es_rate_info  TYPE ty_s_rate_info,
      get_freight_rate_info_tdlnr
        IMPORTING
          is_rate_input TYPE ty_s_input_data
          iv_distz      TYPE distz
        EXPORTING
          es_rate_info  TYPE ty_s_rate_info,
      read_zrrw_tables
        IMPORTING
          is_rate_input  TYPE ty_s_input_data
        EXPORTING
          ev_fright_rate TYPE kbetr_kond,
      read_zrrw_tables_tdlnr
        IMPORTING
          is_rate_input  TYPE ty_s_input_data
        EXPORTING
          ev_fright_rate TYPE kbetr_kond,
      read_zrbw_tables
        IMPORTING
          is_rate_input  TYPE ty_s_input_data
        EXPORTING
          ev_fright_rate TYPE kbetr_kond,
      read_zrbw_tables_tdlnr
        IMPORTING
          is_rate_input  TYPE ty_s_input_data
        EXPORTING
          ev_fright_rate TYPE kbetr_kond,
      read_fuel_surcharge_tables
        IMPORTING
          is_rate_input       TYPE ty_s_input_data
          iv_fright_rate      TYPE kbetr_kond
          iv_distz            TYPE distz
          iv_kschl            TYPE kscha
        EXPORTING
          ev_fright_surcharge TYPE kbetr_kond,
      read_fuel_surcharge_tble_tdlnr
        IMPORTING
          is_rate_input       TYPE ty_s_input_data
          iv_fright_rate      TYPE kbetr_kond
          iv_distz            TYPE distz
          iv_kschl            TYPE kscha
        EXPORTING
          ev_fright_surcharge TYPE kbetr_kond.
ENDCLASS.
CLASS lcl_rail_frght_fuel_schrg IMPLEMENTATION.
  METHOD validate_tplst.
    CHECK gv_tplst IS NOT INITIAL.
    SELECT SINGLE tplst
      FROM ttds
      INTO @DATA(lv_tplst)
      WHERE tplst = @gv_tplst.
    IF sy-subrc <> 0.
      MESSAGE e002(zdl_r10514) WITH gv_tplst
                               INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD validate_tknum.
    CHECK gr_tknum[] IS NOT INITIAL.
    SELECT tknum
      FROM zvttk_archive
      INTO TABLE @DATA(lt_tknum)
      WHERE tknum IN @gr_tknum.
    IF sy-subrc <> 0.
      MESSAGE e003(zdl_r10514) INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD get_data.
    get_vttk_archive_data( ).
    IF gt_vttk IS INITIAL.
      MESSAGE e001(zdl_r10514) INTO gv_message.
      RETURN.
    ENDIF.
    get_vtts_archive_data( ).
    get_vttp_archive_data( ).
    get_tplst_text( ).
    get_route_text( ).
    get_vsbed_text( ).
    get_lips_archive_data( ).
    get_likp_archive_data( ).
    get_vbap_archive_data( ).
    get_kna1_data( ).
    get_rail_names( ).
    get_vfkp_archive_data( ).
    get_lfa1_data( ).
    get_rail_route_data( ).
    get_rail_rate_data( ).
    get_rseg_data( ).
    get_rbkp_data( ).
    get_bsak_data( ).
    get_posting_key_text( ).
  ENDMETHOD.
  METHOD get_archive_key.
    DATA: lt_runs  TYPE TABLE OF admi_run,
          lt_files TYPE TABLE OF admi_files,
          lt_varia TYPE arch_t_varia.
    CLEAR et_arch_key.
    CALL FUNCTION 'ARCHIVE_REMOTE_SELECT_ADMIN'
      EXPORTING
        iv_object  = iv_object
      TABLES
        et_runs    = lt_runs
        et_files   = lt_files
        et_varia   = lt_varia
        et_davlnk  = et_arch_key
      EXCEPTIONS
        open_error = 1
        OTHERS     = 2.
    IF sy-subrc = 0.
      SORT et_arch_key BY start_retention ASCENDING.
    ENDIF.
  ENDMETHOD.
  METHOD filter_archive_key.
    DATA lr_filter_year TYPE RANGE OF char4.
    CLEAR et_arch_key.
    et_arch_key = VALUE #( FOR ls_arch_key IN it_arch_key
                           ( arch_key   = ls_arch_key-archiv_key
                             date       = |{ ls_arch_key-start_retention }| ) ).
    lr_filter_year = VALUE #( FOR ls_date IN gr_date
                       ( sign   = ls_date-sign
                         option = ls_date-option
                         low    = ls_date-low
                         high   = ls_date-high ) ).
    DELETE et_arch_key WHERE date NOT IN lr_filter_year.
  ENDMETHOD.
  METHOD archive_read.
    CLEAR ev_archive_handle.
    CALL FUNCTION 'ARCHIVE_OPEN_FOR_READ'
      EXPORTING
        archive_name                 = iv_archiv_key
        object                       = iv_object
      IMPORTING
        archive_handle               = ev_archive_handle
      EXCEPTIONS
        file_already_open            = 1
        file_io_error                = 2
        internal_error               = 3
        no_files_available           = 4
        object_not_found             = 5
        open_error                   = 6
        not_authorized               = 7
        archiving_standard_violation = 8
        OTHERS                       = 9.
    IF sy-subrc <> 0.
      CLEAR ev_archive_handle.
    ENDIF.
  ENDMETHOD.
  METHOD get_archive_next_object.
* Local variable declaration
    DATA: lv_arch_name     TYPE arkey,
          lv_object_offset TYPE admi_offst.
    CLEAR ev_exit.
    CALL FUNCTION 'ARCHIVE_GET_NEXT_OBJECT'
      EXPORTING
        archive_handle          = iv_archive_handle
      IMPORTING
        object_offset           = lv_object_offset
        archive_name            = lv_arch_name
      EXCEPTIONS
        end_of_file             = 1
        file_io_error           = 2
        internal_error          = 3
        open_error              = 4
        wrong_access_to_archive = 5
        OTHERS                  = 6.
    IF sy-subrc <> 0.
      ev_exit = abap_true.
    ENDIF.
  ENDMETHOD.
  METHOD get_archive_next_record.
    CLEAR: ev_exit,
           eo_record_ref.
    CALL FUNCTION 'ARCHIVE_GET_NEXT_RECORD'
      EXPORTING
        archive_handle          = iv_archive_handle
        get_real_structure_name = abap_true
      IMPORTING
        record_structure        = ev_object_name
        record_ref              = eo_record_ref
      EXCEPTIONS
        end_of_object           = 1
        internal_error          = 2
        wrong_access_to_archive = 3
        OTHERS                  = 4.
    IF sy-subrc <> 0.
      ev_exit = abap_true.
    ENDIF.
  ENDMETHOD.
  METHOD get_vttk_archive_data.
    DATA: lr_tdlnr TYPE RANGE OF tdlnr.
* Get required TDLNR into a range table.
    lr_tdlnr = VALUE #( sign = 'I'
                        option = 'EQ'
                       ( low    = '0000644603' )
                       ( low    = '0000650236' )
                       ( low    = '0000656753' )
                       ( low    = '0000028052' ) ).
    CLEAR gt_vttk.
    SELECT tknum,
           shtyp,
           tplst,
           vsart,
           vsbed,
           route,
           signi,
           dalen,
           sttrg,
           datbg,
           daten,
           tdlnr,
           distz,
           sdabw
      FROM zvttk_archive
      INTO TABLE @gt_vttk
      WHERE tknum IN @gr_tknum AND
            shtyp = 'ZRLP' AND
            tplst = @gv_tplst AND
            vsart = 'ZB' AND
            dalen IN @gr_date AND
            sttrg = '7' AND
            tdlnr IN @lr_tdlnr.
    IF sy-subrc <> 0.
      CLEAR gt_vttk.
    ENDIF.
  ENDMETHOD.
  METHOD get_vtts_archive_data.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT tknum,
           tsnum,
           knota,
           knotz,
           kunnz,
           edpstlz,
           edort01,
           zz_load_q1,
           zz_load_u1
      FROM zvtts_archive
      INTO TABLE @gt_vtts
      FOR ALL ENTRIES IN @gt_vttk
      WHERE tknum = @gt_vttk-tknum.
    IF sy-subrc <> 0.
      CLEAR gt_vttk.
    ENDIF.
  ENDMETHOD.
  METHOD get_vttp_archive_data.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT tknum,
           tpnum,
           vbeln
      FROM zvttp_archive
      INTO TABLE @gt_vttp
      FOR ALL ENTRIES IN @gt_vttk
      WHERE tknum = @gt_vttk-tknum.
    IF sy-subrc <> 0.
      CLEAR gt_vttp.
    ENDIF.
  ENDMETHOD.
  METHOD get_tplst_text.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT tplst,
           bezei
      FROM ttdst
      INTO TABLE @gt_tplst_text
      FOR ALL ENTRIES IN @gt_vttk
      WHERE spras = @sy-langu AND
            tplst = @gt_vttk-tplst.
    IF sy-subrc <> 0.
      CLEAR gt_tplst_text.
    ENDIF.
  ENDMETHOD.
  METHOD get_route_text.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT route,
           bezei
      FROM tvrot
      INTO TABLE @gt_route_text
      FOR ALL ENTRIES IN @gt_vttk
      WHERE spras = @sy-langu AND
            route = @gt_vttk-route.
    IF sy-subrc <> 0.
      CLEAR gt_route_text.
    ENDIF.
  ENDMETHOD.
  METHOD get_vsbed_text.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT vsbed,
           vtext
      FROM tvsbt
      INTO TABLE @gt_vsbed_text
      FOR ALL ENTRIES IN @gt_vttk
      WHERE vsbed = @gt_vttk-vsbed.
    IF sy-subrc = 0.
      SORT gt_vsbed_text BY vsbed ASCENDING.
      DELETE ADJACENT DUPLICATES FROM gt_vsbed_text COMPARING ALL FIELDS.
    ENDIF.
  ENDMETHOD.
  METHOD get_lips_archive_data.
    CHECK gt_vttp IS NOT INITIAL.
    SELECT  vbeln,
            posnr,
            vgbel,
            vgpos
      FROM zlips_archive
      INTO TABLE @gt_lips
      FOR ALL ENTRIES IN @gt_vttp
      WHERE vbeln = @gt_vttp-vbeln.
    IF sy-subrc <> 0.
      CLEAR gt_lips.
    ENDIF.
  ENDMETHOD.
  METHOD get_likp_archive_data.
    CHECK gt_vttp IS NOT INITIAL.
    SELECT  vbeln,
            btgew,
            gewei
      FROM zlikp_archive
      INTO TABLE @gt_likp
      FOR ALL ENTRIES IN @gt_vttp
      WHERE vbeln = @gt_vttp-vbeln.
    IF sy-subrc <> 0.
      CLEAR gt_likp.
    ENDIF.
  ENDMETHOD.
  METHOD get_vbap_archive_data.
    CHECK gt_lips IS NOT INITIAL.
    SELECT vbeln,
           spart,
           mfrgr
      FROM zvbap_archive
      INTO TABLE @gt_vbap
      FOR ALL ENTRIES IN @gt_lips
      WHERE vbeln = @gt_lips-vgbel.
    IF sy-subrc <> 0.
      CLEAR gt_vbap.
    ENDIF.
  ENDMETHOD.
  METHOD get_vfkp_archive_data.
    DATA: lr_tknum TYPE RANGE OF exti1_p.
    CHECK gt_vttk IS NOT INITIAL.
    lr_tknum = VALUE #( FOR ls_tknum IN gt_vttk
                        ( sign = 'I'
                          option = 'EQ'
                          low = ls_tknum-tknum ) ).
    SELECT fknum,
           netwr,
           waers,
           exti1,
           trfzna,
           trfznz,
           kzwi2,
           kzwi4
      FROM zvfkp_archive
      INTO TABLE @gt_vfkp
      WHERE exti1 IN @lr_tknum.
    IF sy-subrc <> 0.
      CLEAR gt_vfkp.
    ENDIF.
  ENDMETHOD.
  METHOD get_kna1_data.
    CHECK gt_vtts IS NOT INITIAL.
    SELECT kunnr,
           land1,
           name1,
           ort01,
           pstlz,
           regio
      FROM kna1
      INTO TABLE @gt_kna1
      FOR ALL ENTRIES IN @gt_vtts
      WHERE kunnr = @gt_vtts-kunnz.
    IF sy-subrc <> 0.
      CLEAR gt_kna1.
    ENDIF.
  ENDMETHOD.
  METHOD get_rail_names.
    DATA: lr_state TYPE RANGE OF regio.
    CHECK gt_vtts IS NOT INITIAL.
    lr_state = VALUE #( FOR ls_kna1 IN gt_kna1
                        ( sign = 'I'
                          option = 'EQ'
                          low = ls_kna1-regio ) ).
    SORT lr_state BY low ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lr_state COMPARING low.
    SELECT cstvnd_city,
           cstvnd_state,
           region_name
      FROM zsdc1976_region
      INTO TABLE @gt_rail_name
      FOR ALL ENTRIES IN @gt_vtts
      WHERE cstvnd_city = @gt_vtts-edort01 AND
            cstvnd_state IN @lr_state.
    IF sy-subrc <> 0.
      CLEAR gt_rail_name.
    ENDIF.
  ENDMETHOD.
  METHOD get_lfa1_data.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT lifnr,
           name1
      FROM lfa1
      INTO TABLE @gt_lfa1
      FOR ALL ENTRIES IN @gt_vttk
      WHERE lifnr = @gt_vttk-tdlnr.
    IF sy-subrc <> 0.
      CLEAR gt_lfa1.
    ENDIF.
  ENDMETHOD.
  METHOD get_rail_route_data.
    DATA: lt_rail_route        TYPE zdle11462_lt_rail_route_t.
    CALL FUNCTION 'ZDL_RAIL_ROUTE_ECC'
      EXPORTING
        ir_plnd_shp_date = gr_date
      IMPORTING
        et_adverse_rout  = lt_rail_route.

    gt_rail_route_911 = gt_rail_route_909 = gt_rail_route_902 =
    gt_rail_route_907 = gt_rail_route_908 = gt_rail_route_910 = lt_rail_route.

    DELETE gt_rail_route_911 WHERE kotabnr <> '911'.
    DELETE gt_rail_route_909 WHERE kotabnr <> '909'.
    DELETE gt_rail_route_902 WHERE kotabnr <> '902'.
    DELETE gt_rail_route_907 WHERE kotabnr <> '907'.
    DELETE gt_rail_route_908 WHERE kotabnr <> '908'.
    DELETE gt_rail_route_910 WHERE kotabnr <> '910'.

  ENDMETHOD.
  METHOD get_rail_rate_data.
    DATA: lt_rail_rate         TYPE zdle11459_lt_rail_rate_t.
    CALL FUNCTION 'ZDL_RAIL_RATE_ECC'
      EXPORTING
        ir_plnd_shp_date     = gr_date
      IMPORTING
        et_adverse_rail_rate = lt_rail_rate.

    gt_rail_rate_958 = gt_rail_rate_946 = gt_rail_rate_936 =
    gt_rail_rate_929 = gt_rail_rate_933 = gt_rail_rate_967 =
    gt_rail_rate_944 = gt_rail_rate_959 = gt_rail_rate_922 =
    gt_rail_rate_965 = gt_rail_rate_947 = gt_rail_rate_966 =
    gt_rail_rate_942 = gt_rail_rate_934 = gt_rail_rate_919 =
    gt_rail_rate_906 = gt_rail_rate_983 = gt_rail_rate_969 =
    gt_rail_rate_920 = gt_rail_rate_981 = gt_rail_rate_992 =
    gt_rail_rate_995 = gt_rail_rate_900 = gt_rail_rate_971 =
    gt_rail_rate_943 = gt_rail_rate_937 = gt_rail_rate_923 =
    gt_rail_rate_925 = gt_rail_rate_941 = gt_rail_rate_930 = lt_rail_rate.

    DELETE gt_rail_rate_958 WHERE kotabnr <> '958'.
    DELETE gt_rail_rate_946 WHERE kotabnr <> '946'.
    DELETE gt_rail_rate_936 WHERE kotabnr <> '936'.
    DELETE gt_rail_rate_929 WHERE kotabnr <> '929'.
    DELETE gt_rail_rate_933 WHERE kotabnr <> '933'.
    DELETE gt_rail_rate_967 WHERE kotabnr <> '967'.
    DELETE gt_rail_rate_944 WHERE kotabnr <> '944'.
    DELETE gt_rail_rate_959 WHERE kotabnr <> '959'.
    DELETE gt_rail_rate_922 WHERE kotabnr <> '922'.
    DELETE gt_rail_rate_965 WHERE kotabnr <> '965'.
    DELETE gt_rail_rate_947 WHERE kotabnr <> '947'.
    DELETE gt_rail_rate_966 WHERE kotabnr <> '966'.
    DELETE gt_rail_rate_942 WHERE kotabnr <> '942'.
    DELETE gt_rail_rate_934 WHERE kotabnr <> '934'.
    DELETE gt_rail_rate_919 WHERE kotabnr <> '919'.
    DELETE gt_rail_rate_906 WHERE kotabnr <> '906'.
    DELETE gt_rail_rate_983 WHERE kotabnr <> '983'.
    DELETE gt_rail_rate_969 WHERE kotabnr <> '969'.
    DELETE gt_rail_rate_920 WHERE kotabnr <> '920'.
    DELETE gt_rail_rate_981 WHERE kotabnr <> '981'.
    DELETE gt_rail_rate_992 WHERE kotabnr <> '992'.
    DELETE gt_rail_rate_995 WHERE kotabnr <> '995'.
    DELETE gt_rail_rate_900 WHERE kotabnr <> '900'.
    DELETE gt_rail_rate_971 WHERE kotabnr <> '971'.
    DELETE gt_rail_rate_943 WHERE kotabnr <> '943'.
    DELETE gt_rail_rate_937 WHERE kotabnr <> '937'.
    DELETE gt_rail_rate_923 WHERE kotabnr <> '923'.
    DELETE gt_rail_rate_925 WHERE kotabnr <> '925'.
    DELETE gt_rail_rate_941 WHERE kotabnr <> '941'.
    DELETE gt_rail_rate_930 WHERE kotabnr <> '930'.
  ENDMETHOD.
  METHOD get_rseg_data.
    DATA lr_xblnr TYPE RANGE OF xblnr1.
    CHECK gt_vttk IS NOT INITIAL.
    lr_xblnr = VALUE #( FOR ls_tknum IN gt_vttk
                        ( sign = 'I'
                          option = 'EQ'
                          low = ls_tknum-tknum ) ).
    SELECT belnr,
           gjahr,
           bukrs,
           werks,
           xblnr
      FROM rseg
      INTO TABLE @gt_rseg
      FOR ALL ENTRIES IN @lr_xblnr
      WHERE xblnr = @lr_xblnr-low AND
            werks = @gv_tplst.
    IF sy-subrc <> 0.
      CLEAR gt_rseg.
    ENDIF.
  ENDMETHOD.
  METHOD get_rbkp_data.
    DATA lr_lifnr TYPE RANGE OF lifre.
    CHECK gt_rseg IS NOT INITIAL.
    lr_lifnr = VALUE #( FOR ls_lifnr IN gt_vttk
                        ( sign = 'I'
                          option = 'EQ'
                          low = ls_lifnr-tdlnr ) ).
    SELECT belnr,
           gjahr,
           lifnr,
           xblnr
      FROM rbkp
      INTO TABLE @gt_rbkp
      FOR ALL ENTRIES IN @gt_rseg
      WHERE belnr = @gt_rseg-belnr AND
            gjahr = @gt_rseg-gjahr AND
            lifnr IN @lr_lifnr.
    IF sy-subrc <> 0.
      CLEAR gt_rbkp.
    ENDIF.
  ENDMETHOD.
  METHOD get_bsak_data.
    DATA: lr_bukrs TYPE RANGE OF bukrs.
    CHECK gt_rbkp IS NOT INITIAL.
    lr_bukrs = VALUE #( FOR ls_bukrs IN gt_rseg
                        ( sign = 'I'
                          option = 'EQ'
                          low = ls_bukrs-bukrs ) ).
    SORT lr_bukrs BY low ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lr_bukrs COMPARING low.
    SELECT bukrs,
           lifnr,
           gjahr,
           augdt,
           augbl,
           belnr,
           budat,
           bldat,
           cpudt,
           waers,
           xblnr,
           bschl,
           dmbtr,
           wrbtr,
           sgtxt
      FROM bsak
      INTO TABLE @gt_bsak
      FOR ALL ENTRIES IN @gt_rbkp
      WHERE bukrs IN @lr_bukrs AND
            lifnr = @gt_rbkp-lifnr AND
            gjahr = @gt_rbkp-gjahr AND
            xblnr = @gt_rbkp-xblnr.
    IF sy-subrc <> 0.
      CLEAR gt_bsak.
    ENDIF.
  ENDMETHOD.
  METHOD get_posting_key_text.
    CHECK gt_bsak IS NOT INITIAL.
    SELECT bschl,
           ltext
      FROM tbslt
      FOR ALL ENTRIES IN @gt_bsak
      WHERE spras = @sy-langu AND
            bschl = @gt_bsak-bschl
      INTO TABLE @gt_post_key.
    IF sy-subrc <> 0.
      CLEAR gt_post_key.
    ENDIF.
  ENDMETHOD.
  METHOD prepare_output_data.
    DATA: lv_btgew TYPE gsgew,
          lt_bsak  TYPE ty_t_bsak.
    LOOP AT gt_vttk INTO DATA(ls_vttk).

* Read shipment stage table.
      DATA(ls_vtts) = VALUE #( gt_vtts[ tknum = ls_vttk-tknum ] OPTIONAL ).

* Read Shipment Item
*      DATA(ls_vttp) = VALUE #( gt_vttp[ tknum = ls_vttk-tknum ] OPTIONAL ).
      LOOP AT gt_vttp INTO DATA(ls_vttp) WHERE tknum = ls_vttk-tknum.
* SD Document: Delivery Header Data
        DATA(ls_likp) = VALUE #( gt_likp[ vbeln = ls_vttp-vbeln ] OPTIONAL ).
        lv_btgew = lv_btgew + ls_likp-btgew.
        CLEAR ls_likp-btgew.
      ENDLOOP.

      DATA(ls_lips) = VALUE #( gt_lips[ vbeln = ls_vttp-vbeln ] OPTIONAL ).
* Read Sales Document: Item Data
      DATA(ls_vbap) = VALUE #( gt_vbap[ vbeln = ls_lips-vgbel ] OPTIONAL ).

* Read General Data in Customer Master
      DATA(ls_kna1) = VALUE #( gt_kna1[ kunnr = ls_vtts-kunnz ] OPTIONAL ).

* Read Shipment Costs: Item Data
      DATA(ls_vfkp) = VALUE #( gt_vfkp[ exti1 = ls_vttk-tknum ] OPTIONAL ).

* Read Rail Names
      DATA(ls_rail_name) = VALUE #( gt_rail_name[ cstvnd_city = ls_vtts-edort01
                                                  cstvnd_state = ls_kna1-regio ] OPTIONAL ).

* Determine Fright Route and Rate. This would be determined from the function call.
      IF ls_vttk-tdlnr = '000025460'.
        get_freight_route_info_tdlnr(
          EXPORTING
            iv_kappl      = 'RG'
            iv_tplst      = ls_vttk-tplst
*          iv_kunnr      = ls_vtts-kunnz
            iv_vsbed      = ls_vttk-vsbed
            iv_route      = ls_vttk-route
            iv_date       = ls_vttk-dalen
            iv_pstlz      = ls_kna1-pstlz
          RECEIVING
            es_route_info = DATA(ls_freight_route_info) ).
        CONDENSE ls_freight_route_info-route NO-GAPS.
        get_freight_rate_info_tdlnr(
          EXPORTING
            is_rate_input = VALUE #( kappl = 'F'
                                     vsart = 'ZB'
                                     sdabw = ls_vttk-sdabw
                                     tplst = ls_vttk-tplst
                                     knota = ls_vtts-knota
                                     knotz = ls_vtts-knotz
                                     shtyp = ls_vttk-shtyp
                                     mfrgr = ls_vbap-mfrgr
                                     kunnr = ls_kna1-kunnr
                                     kunwe = ls_vtts-kunnz
                                     ort01 = ls_vtts-edort01"ls_kna1-ort01
                                     regio = ls_kna1-regio
                                     rail_name = ls_rail_name-region_name
                                     trfzna = ls_vfkp-trfzna
                                     trfznz = ls_vfkp-trfznz
                                     land1 = ls_kna1-land1
                                     vsbed = ls_vttk-vsbed
                                     route = ls_freight_route_info-route"ls_vttk-route
                                     date  = ls_vttk-dalen )
            iv_distz      = ls_vttk-distz
          IMPORTING
            es_rate_info  = DATA(ls_fright_surcharge_rate) ).
      ELSE.
        get_freight_route_info(
          EXPORTING
            iv_kappl      = 'RG'
            iv_tplst      = ls_vttk-tplst
*          iv_kunnr      = ls_vtts-kunnz
            iv_vsbed      = ls_vttk-vsbed
            iv_route      = ls_vttk-route
            iv_tdlnr      = ls_vttk-tdlnr
            iv_date       = ls_vttk-dalen
            iv_pstlz      = ls_kna1-pstlz
          RECEIVING
            es_route_info = ls_freight_route_info ).
        CONDENSE ls_freight_route_info-route NO-GAPS.
        get_freight_rate_info(
          EXPORTING
            is_rate_input = VALUE #( kappl = 'F'
                                     vsart = 'ZB'
                                     sdabw = ls_vttk-sdabw
                                     tplst = ls_vttk-tplst
                                     knota = ls_vtts-knota
                                     knotz = ls_vtts-knotz
                                     shtyp = ls_vttk-shtyp
                                     mfrgr = ls_vbap-mfrgr
                                     kunnr = ls_kna1-kunnr
                                     kunwe = ls_vtts-kunnz
                                     ort01 = ls_vtts-edort01"ls_kna1-ort01
                                     regio = ls_kna1-regio
                                     rail_name = ls_rail_name-region_name
                                     trfzna = ls_vfkp-trfzna
                                     trfznz = ls_vfkp-trfznz
                                     land1 = ls_kna1-land1
                                     vsbed = ls_vttk-vsbed
                                     route = ls_freight_route_info-route"ls_vttk-route
                                     tdlnr = ls_vttk-tdlnr
                                     date  = ls_vttk-dalen )
            iv_distz      = ls_vttk-distz
          IMPORTING
            es_rate_info  = ls_fright_surcharge_rate ).
      ENDIF.


      DATA(lv_total_cost) = ls_fright_surcharge_rate-fright_rate + ls_fright_surcharge_rate-fright_surcharge.

*      DATA(ls_rseg) = VALUE #( gt_rseg[ xblnr = ls_vttk-tknum
*                                        werks = ls_vttk-tplst ] OPTIONAL ).
*
*      DATA(ls_rbkp) = VALUE #( gt_rbkp[ belnr = ls_rseg-belnr
*                                        gjahr = ls_rseg-gjahr
*                                        lifnr = ls_vttk-tdlnr ] OPTIONAL ).
*
*      DATA(ls_bsak) = VALUE #( gt_bsak[ bukrs = ls_rseg-bukrs
*                                        lifnr = ls_rbkp-lifnr
*                                        gjahr = ls_rbkp-gjahr
*                                        xblnr = ls_rbkp-xblnr
*                                         ] OPTIONAL ).

      DATA(lt_rseg) = gt_rseg.
      SORT lt_rseg BY xblnr ASCENDING
                      werks ASCENDING
                      belnr ASCENDING.
      DELETE lt_rseg WHERE xblnr <> ls_vttk-tknum.
      DELETE ADJACENT DUPLICATES FROM lt_rseg COMPARING xblnr
                                                        werks
                                                        belnr.
*      DELETE lt_rseg WHERE gjahr <> ls_vttk-dalen+0(4).

*      DATA(lt_rbkp) = gt_rbkp.
*      SORT lt_rbkp BY belnr ASCENDING
*                      gjahr ASCENDING
*                      lifnr ASCENDING.
*      DELETE lt_rbkp WHERE lifnr <> ls_vttk-tdlnr.
*      DELETE ADJACENT DUPLICATES FROM lt_rbkp COMPARING belnr
*                                                        gjahr
*                                                        lifnr.

* It has to be looped because for a shipment, there could multiple AP data
      LOOP AT lt_rseg INTO DATA(ls_rseg).
        DATA(lv_tabix) = sy-tabix.
*      LOOP AT lt_rbkp INTO DATA(ls_rbkp).

*        DATA(ls_rseg) = VALUE #( gt_rseg[ xblnr = ls_vttk-tknum
*                                          werks = ls_vttk-tplst
*                                          belnr = ls_rbkp-belnr ] OPTIONAL ).

        DATA(ls_rbkp) = VALUE #( gt_rbkp[ belnr = ls_rseg-belnr
                                          gjahr = ls_rseg-gjahr
                                          lifnr = ls_vttk-tdlnr ] OPTIONAL ).
        IF ls_rbkp IS NOT INITIAL.
          CLEAR lt_bsak.
          lt_bsak = gt_bsak.
          SORT lt_bsak BY bukrs ASCENDING
                          lifnr ASCENDING
                          gjahr ASCENDING
                          xblnr ASCENDING.

          DELETE lt_bsak WHERE "bukrs <> ls_rseg-bukrs OR
*                               lifnr <> ls_rbkp-lifnr OR
*                               gjahr <> ls_rbkp-gjahr OR
                               xblnr <> ls_rbkp-xblnr.

          IF lines( lt_bsak ) <= lines( lt_rseg ).
*            LOOP AT gt_bsak INTO DATA(ls_bsak).
            DATA(ls_bsak) = VALUE #( lt_bsak[ lv_tabix ] OPTIONAL ).
            IF ls_bsak IS INITIAL.
              CLEAR:lv_tabix,
                    ls_bsak,
                    ls_rseg,
                    lt_bsak.
              CONTINUE.
            ENDIF.
*          DATA(ls_bsak) = VALUE #( gt_bsak[ bukrs = ls_rseg-bukrs
*                                            lifnr = ls_rbkp-lifnr
*                                            gjahr = ls_rbkp-gjahr
*                                            xblnr = ls_rbkp-xblnr
*                                             ] OPTIONAL ).
*        ASSIGN gt_bsak[ bukrs = ls_rseg-bukrs
*                        lifnr = ls_rbkp-lifnr
*                        gjahr = ls_rbkp-gjahr
*                        xblnr = ls_rbkp-xblnr
*                        check = ' ' ] TO FIELD-SYMBOL(<ls_bsak>).

*        IF <ls_bsak> IS ASSIGNED.
*          <ls_bsak>-check = abap_true.
*          DATA(ls_bsak) = CORRESPONDING ty_s_bsak( <ls_bsak> ).
*        ELSE.
*          CLEAR ls_bsak.
*        ENDIF.
*        IF lines( lt_rbkp ) > 1.
*          DATA(lv_check) = abap_true.
*        ENDIF.
            IF lines( lt_rseg ) > 1.
              DATA(lv_check) = abap_true.
            ENDIF.
* Fill output table.
            APPEND VALUE #( check         = lv_check
                            tplst         = ls_vttk-tplst
                            tplst_text    = VALUE #( gt_tplst_text[ tplst = ls_vttk-tplst ]-bezei OPTIONAL )
                            tknum         = ls_vttk-tknum
                            dalen         = ls_vttk-dalen
                            datbg         = ls_vttk-datbg
                            daten         = ls_vttk-daten
                            mfrgr         = ls_vbap-mfrgr
                            sdabw         = ls_vttk-sdabw
                            btgew         = lv_btgew"ls_likp-btgew
                            gewei         = ls_likp-gewei
                            distz         = ls_vttk-distz
                            tdlnr         = ls_vttk-tdlnr
                            lfa1_name1    = VALUE #( gt_lfa1[ lifnr = ls_vttk-tdlnr ]-name1 OPTIONAL ) "ls_lfa1-name1
                            route         = ls_vttk-route
                            route_text    = VALUE #( gt_route_text[ route = ls_vttk-route ]-bezei OPTIONAL )"ls_route_text-bezei
                            routid        = ls_freight_route_info-routid
                            edort01       = ls_vtts-edort01
                            regio         = ls_kna1-regio
                            vsbed_text    = VALUE #( gt_vsbed_text[ vsbed = ls_vttk-vsbed ]-vtext OPTIONAL )"ls_vsbed_text-vtext
                            signi         = ls_vttk-signi
                            kunnz         = ls_vtts-kunnz
                            kna1_name1    = ls_kna1-name1
                            ort01         = ls_kna1-ort01
                            ship_to_state = ls_kna1-regio
                            fknum         = ls_vfkp-fknum
                            kzwi2         = ls_vfkp-kzwi2
                            kzwi4         = ls_vfkp-kzwi4
                            netwr         = ls_vfkp-netwr
                            waers         = ls_vfkp-waers
                            xblnr         = ls_bsak-xblnr
                            belnr         = ls_bsak-belnr
                            augbl         = ls_bsak-augbl
                            sgtxt         = ls_bsak-sgtxt
                            bldat         = ls_bsak-bldat
                            cpudt         = ls_bsak-cpudt
                            budat         = ls_bsak-budat
                            augdt         = ls_bsak-augdt
                            bschl         = ls_bsak-bschl
                            wrbtr         = ls_bsak-wrbtr
                            waers_bsak    = ls_bsak-waers
                            fright_rate   = ls_fright_surcharge_rate-fright_rate
                            fuel_surcharg = ls_fright_surcharge_rate-fright_surcharge
                            total_cost    = lv_total_cost ) TO gt_alv_data.
            CLEAR: lv_check,
                   lv_tabix,
                   ls_bsak,
                   ls_rbkp,
                   ls_rseg,
                   lt_bsak.
*            ENDLOOP.
          ELSE.
            LOOP AT lt_bsak INTO ls_bsak.
              IF lines( lt_bsak ) > 1.
                lv_check = abap_true.
              ENDIF.
* Fill output table.
              APPEND VALUE #( check         = lv_check
                              tplst         = ls_vttk-tplst
                              tplst_text    = VALUE #( gt_tplst_text[ tplst = ls_vttk-tplst ]-bezei OPTIONAL )
                              tknum         = ls_vttk-tknum
                              dalen         = ls_vttk-dalen
                              datbg         = ls_vttk-datbg
                              daten         = ls_vttk-daten
                              mfrgr         = ls_vbap-mfrgr
                              sdabw         = ls_vttk-sdabw
                              btgew         = lv_btgew"ls_likp-btgew
                              gewei         = ls_likp-gewei
                              distz         = ls_vttk-distz
                              tdlnr         = ls_vttk-tdlnr
                              lfa1_name1    = VALUE #( gt_lfa1[ lifnr = ls_vttk-tdlnr ]-name1 OPTIONAL ) "ls_lfa1-name1
                              route         = ls_vttk-route
                              route_text    = VALUE #( gt_route_text[ route = ls_vttk-route ]-bezei OPTIONAL )"ls_route_text-bezei
                              routid        = ls_freight_route_info-routid
                              edort01       = ls_vtts-edort01
                              regio         = ls_kna1-regio
                              vsbed_text    = VALUE #( gt_vsbed_text[ vsbed = ls_vttk-vsbed ]-vtext OPTIONAL )"ls_vsbed_text-vtext
                              signi         = ls_vttk-signi
                              kunnz         = ls_vtts-kunnz
                              kna1_name1    = ls_kna1-name1
                              ort01         = ls_kna1-ort01
                              ship_to_state = ls_kna1-regio
                              fknum         = ls_vfkp-fknum
                              kzwi2         = ls_vfkp-kzwi2
                              kzwi4         = ls_vfkp-kzwi4
                              netwr         = ls_vfkp-netwr
                              waers         = ls_vfkp-waers
                              xblnr         = ls_bsak-xblnr
                              belnr         = ls_bsak-belnr
                              augbl         = ls_bsak-augbl
                              sgtxt         = ls_bsak-sgtxt
                              bldat         = ls_bsak-bldat
                              cpudt         = ls_bsak-cpudt
                              budat         = ls_bsak-budat
                              augdt         = ls_bsak-augdt
                              bschl         = ls_bsak-bschl
                              wrbtr         = ls_bsak-wrbtr
                              waers_bsak    = ls_bsak-waers
                              fright_rate   = ls_fright_surcharge_rate-fright_rate
                              fuel_surcharg = ls_fright_surcharge_rate-fright_surcharge
                              total_cost    = lv_total_cost ) TO gt_alv_data.
            ENDLOOP.
          ENDIF.
        ENDIF.
        CLEAR: lv_check,
               lv_tabix,
               ls_bsak,
               ls_rbkp,
               ls_rseg,
               lt_bsak.
      ENDLOOP.

*      IF lt_rbkp IS INITIAL.
*      IF lt_rseg IS INITIAL.
*        APPEND VALUE #( check         = lv_check
*                        tplst         = ls_vttk-tplst
*                        tplst_text    = VALUE #( gt_tplst_text[ tplst = ls_vttk-tplst ]-bezei OPTIONAL )
*                        tknum         = ls_vttk-tknum
*                        dalen         = ls_vttk-dalen
*                        datbg         = ls_vttk-datbg
*                        daten         = ls_vttk-daten
*                        mfrgr         = ls_vbap-mfrgr
*                        sdabw         = ls_vttk-sdabw
*                        btgew         = lv_btgew"ls_likp-btgew
*                        gewei         = ls_likp-gewei
*                        distz         = ls_vttk-distz
*                        tdlnr         = ls_vttk-tdlnr
*                        lfa1_name1    = VALUE #( gt_lfa1[ lifnr = ls_vttk-tdlnr ]-name1 OPTIONAL ) "ls_lfa1-name1
*                        route         = ls_vttk-route
*                        route_text    = VALUE #( gt_route_text[ route = ls_vttk-route ]-bezei OPTIONAL )"ls_route_text-bezei
*                        routid        = ls_freight_route_info-routid
*                        edort01       = ls_vtts-edort01
*                        regio         = ls_kna1-regio
*                        vsbed_text    = VALUE #( gt_vsbed_text[ vsbed = ls_vttk-vsbed ]-vtext OPTIONAL )"ls_vsbed_text-vtext
*                        signi         = ls_vttk-signi
*                        kunnz         = ls_vtts-kunnz
*                        kna1_name1    = ls_kna1-name1
*                        ort01         = ls_kna1-ort01
*                        ship_to_state = ls_kna1-regio
*                        fknum         = ls_vfkp-fknum
*                        kzwi2         = ls_vfkp-kzwi2
*                        kzwi4         = ls_vfkp-kzwi4
*                        netwr         = ls_vfkp-netwr
*                        waers         = ls_vfkp-waers
*                        xblnr         = ls_bsak-xblnr
*                        belnr         = ls_bsak-belnr
*                        augbl         = ls_bsak-augbl
*                        sgtxt         = ls_bsak-sgtxt
*                        bldat         = ls_bsak-bldat
*                        cpudt         = ls_bsak-cpudt
*                        budat         = ls_bsak-budat
*                        augdt         = ls_bsak-augdt
*                        wrbtr         = ls_bsak-wrbtr
*                        waers_bsak    = ls_bsak-waers
*                        fright_rate   = ls_fright_surcharge_rate-fright_rate
*                        fuel_surcharg = ls_fright_surcharge_rate-fright_surcharge
*                        total_cost    = lv_total_cost ) TO gt_alv_data.
*        CLEAR: lv_check,
*               ls_bsak,
*               ls_rbkp,
*               lv_tabix,
*               ls_rseg,
*               lt_bsak.
*      ENDIF.
      CLEAR: ls_vtts,
             ls_vttp,
             ls_vbap,
             ls_kna1,
             ls_vfkp,
             ls_rseg,
             ls_rbkp,
             ls_likp,
             ls_bsak,
             lv_check,
             lv_tabix,
             lv_btgew,
             lt_rseg,
             lt_bsak.
*             lt_rbkp.
    ENDLOOP.
    SORT gt_alv_data.
    DELETE ADJACENT DUPLICATES FROM gt_alv_data COMPARING ALL FIELDS.
  ENDMETHOD.
  METHOD get_freight_route_info.
    CLEAR es_route_info.
* Find route information from the function module return.
    LOOP AT gt_rail_route_911 INTO DATA(ls_route_info)
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                route = iv_route AND
                                                pstlz = iv_pstlz AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_909 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL'   AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                route = iv_route AND
                                                pstlz = iv_pstlz AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_902 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                vsbed = iv_vsbed AND
                                                route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_907 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                route = iv_route AND
                                                tdlnr = iv_tdlnr AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_910 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
                                                 route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_908 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vsbed = iv_vsbed AND
                                                route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD get_freight_route_info_tdlnr.
    CLEAR es_route_info.
* Find route information from the function module return.
    LOOP AT gt_rail_route_911 INTO DATA(ls_route_info)
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                route = iv_route AND
                                                pstlz = iv_pstlz AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_909 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL'   AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                route = iv_route AND
                                                pstlz = iv_pstlz AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_902 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                vsbed = iv_vsbed AND
                                                route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_907 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
*                                                kunwe = iv_kunnr AND
                                                route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_910 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vstel = iv_tplst AND
                                                 route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_908 INTO ls_route_info
                                          WHERE kappl = iv_kappl AND
                                                kschl = 'ZRRL' AND
                                                vsbed = iv_vsbed AND
                                                route = iv_route AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( bezei  = ls_route_info-bezei
                                 routid = ls_route_info-routid
                                 route  = ls_route_info-routid4 ).
        RETURN.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD get_freight_rate_info.
    CLEAR es_rate_info.
    CASE is_rate_input-sdabw.
      WHEN 'RR11' OR 'RF11'.
* Read all tables related to ZRRW
        read_zrrw_tables(
          EXPORTING
            is_rate_input = is_rate_input
          IMPORTING
            ev_fright_rate  = DATA(lv_fright_rate) ).

        read_fuel_surcharge_tables(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFS'
          IMPORTING
            ev_fright_surcharge   = DATA(lv_fuel_surcharge_rate_1) ).

        read_fuel_surcharge_tables(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFM'
          IMPORTING
            ev_fright_surcharge   = DATA(lv_fuel_surcharge_rate_2) ).

        es_rate_info = VALUE #( fright_rate = lv_fright_rate
                                fright_surcharge = lv_fuel_surcharge_rate_1 + lv_fuel_surcharge_rate_2 ).

      WHEN space.
* Read all tables related to ZRBW
        read_zrbw_tables(
          EXPORTING
            is_rate_input = is_rate_input
          IMPORTING
            ev_fright_rate  = lv_fright_rate ).

        read_fuel_surcharge_tables(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFS'
          IMPORTING
            ev_fright_surcharge   = lv_fuel_surcharge_rate_1 ).

        read_fuel_surcharge_tables(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFM'
          IMPORTING
            ev_fright_surcharge   = lv_fuel_surcharge_rate_2 ).
        es_rate_info = VALUE #( fright_rate = lv_fright_rate
                                fright_surcharge = lv_fuel_surcharge_rate_1 + lv_fuel_surcharge_rate_2 ).
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD get_freight_rate_info_tdlnr.
    CLEAR es_rate_info.
    CASE is_rate_input-sdabw.
      WHEN 'RR11' OR 'RF11'.
* Read all tables related to ZRRW
        read_zrrw_tables_tdlnr(
          EXPORTING
            is_rate_input = is_rate_input
          IMPORTING
            ev_fright_rate  = DATA(lv_fright_rate) ).

        read_fuel_surcharge_tble_tdlnr(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFS'
          IMPORTING
            ev_fright_surcharge   = DATA(lv_fuel_surcharge_rate_1) ).

        read_fuel_surcharge_tble_tdlnr(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFM'
          IMPORTING
            ev_fright_surcharge   = DATA(lv_fuel_surcharge_rate_2) ).

        es_rate_info = VALUE #( fright_rate = lv_fright_rate
                                fright_surcharge = lv_fuel_surcharge_rate_1 + lv_fuel_surcharge_rate_2 ).

      WHEN space.
* Read all tables related to ZRBW
        read_zrbw_tables_tdlnr(
          EXPORTING
            is_rate_input = is_rate_input
          IMPORTING
            ev_fright_rate  = lv_fright_rate ).

        read_fuel_surcharge_tble_tdlnr(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFS'
          IMPORTING
            ev_fright_surcharge   = lv_fuel_surcharge_rate_1 ).

        read_fuel_surcharge_tble_tdlnr(
          EXPORTING
            is_rate_input  = is_rate_input
            iv_fright_rate = lv_fright_rate
            iv_distz       = iv_distz
            iv_kschl       = 'ZTFM'
          IMPORTING
            ev_fright_surcharge   = lv_fuel_surcharge_rate_2 ).
        es_rate_info = VALUE #( fright_rate = lv_fright_rate
                                fright_surcharge = lv_fuel_surcharge_rate_1 + lv_fuel_surcharge_rate_2 ).
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD read_zrrw_tables.
    CLEAR ev_fright_rate.
    LOOP AT gt_rail_rate_983 INTO DATA(ls_rail_rate)
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   knotz = is_rate_input-knotz AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_969 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_920 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_981 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   tplst = is_rate_input-tplst AND
                                   knotz = is_rate_input-knotz AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_992 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_995 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   tplst = is_rate_input-tplst AND
                                   knotz = is_rate_input-knotz AND
                                   tdlnr = is_rate_input-tdlnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.
  ENDMETHOD.
  METHOD read_zrrw_tables_tdlnr.
    CLEAR ev_fright_rate.
    LOOP AT gt_rail_rate_983 INTO DATA(ls_rail_rate)
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   knotz = is_rate_input-knotz AND
                                   vsbed = is_rate_input-vsbed AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_969 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_920 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_981 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   tplst = is_rate_input-tplst AND
                                   knotz = is_rate_input-knotz AND
                                   vsbed = is_rate_input-vsbed AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_992 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   knota = is_rate_input-knota AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_995 INTO ls_rail_rate
                             WHERE kschl = 'ZRRW' AND
                                   tplst = is_rate_input-tplst AND
                                   knotz = is_rate_input-knotz AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.
  ENDMETHOD.
  METHOD read_zrbw_tables.
    CLEAR ev_fright_rate.
    LOOP AT gt_rail_rate_958 INTO DATA(ls_rail_rate)
                             WHERE tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                   zstcc = is_rate_input-mfrgr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.
    LOOP AT gt_rail_rate_946 INTO ls_rail_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_936 INTO ls_rail_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_929 INTO ls_rail_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_933 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   kunnr = is_rate_input-kunnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_967 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   zstcc = is_rate_input-mfrgr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_944 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_959 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   zstcc = is_rate_input-mfrgr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_922 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_965 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   vsbed = is_rate_input-vsbed AND
                                   zzrail_region = is_rate_input-rail_name AND
                                   zstcc = is_rate_input-mfrgr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_947 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   vsbed = is_rate_input-vsbed AND
                                   zzrail_region = is_rate_input-rail_name AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_966 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   zzrail_region = is_rate_input-rail_name AND
                                   zstcc = is_rate_input-mfrgr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_942 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   regioz = is_rate_input-regio AND
                                   zzrail_region = is_rate_input-rail_name AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_934 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_919 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_906 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tdlnr = is_rate_input-tdlnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.
  ENDMETHOD.
  METHOD read_zrbw_tables_tdlnr.
    CLEAR ev_fright_rate.
    LOOP AT gt_rail_rate_958 INTO DATA(ls_rail_rate)
                             WHERE tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                   zstcc = is_rate_input-mfrgr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.
    LOOP AT gt_rail_rate_946 INTO ls_rail_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_936 INTO ls_rail_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_929 INTO ls_rail_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_933 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   kunnr = is_rate_input-kunnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_967 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   zstcc = is_rate_input-mfrgr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_944 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_959 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   zstcc = is_rate_input-mfrgr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_922 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_965 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   vsbed = is_rate_input-vsbed AND
                                   zzrail_region = is_rate_input-rail_name AND
                                   zstcc = is_rate_input-mfrgr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_947 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   vsbed = is_rate_input-vsbed AND
                                   zzrail_region = is_rate_input-rail_name AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_966 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   zzrail_region = is_rate_input-rail_name AND
                                   zstcc = is_rate_input-mfrgr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_942 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   regioz = is_rate_input-regio AND
                                   zzrail_region = is_rate_input-rail_name AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_934 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_919 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_906 INTO ls_rail_rate
                             WHERE kschl = 'ZRBW' AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_rail_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_rail_rate IS NOT INITIAL.
      ev_fright_rate = ls_rail_rate-kbetr.
      RETURN.
    ENDIF.
  ENDMETHOD.
  METHOD read_fuel_surcharge_tables.
    CLEAR ev_fright_surcharge.
    LOOP AT gt_rail_rate_900 INTO DATA(ls_fuel_surcharge_rate)
                             WHERE tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   tdlnr = is_rate_input-tdlnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_933 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS'
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   kunnr = is_rate_input-kunnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_971 INTO ls_fuel_surcharge_rate
                             WHERE vsart = is_rate_input-vsart AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_919 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_943 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_936 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_929 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_937 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_923 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_925 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   tdlnr = is_rate_input-tdlnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_941 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   tdlnr = is_rate_input-tdlnr AND
                                   vsbed = is_rate_input-vsbed AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_906 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   tdlnr = is_rate_input-tdlnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_930 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.
  ENDMETHOD.
  METHOD read_fuel_surcharge_tble_tdlnr.
    CLEAR ev_fright_surcharge.
    LOOP AT gt_rail_rate_900 INTO DATA(ls_fuel_surcharge_rate)
                             WHERE tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_933 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS'
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                   kunnr = is_rate_input-kunnr AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_971 INTO ls_fuel_surcharge_rate
                             WHERE vsart = is_rate_input-vsart AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_919 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   tplst = is_rate_input-tplst AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_943 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   route = is_rate_input-route AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_936 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_929 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   vsbed = is_rate_input-vsbed AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_937 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                   land1z = is_rate_input-land1 AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_923 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                   cstvnd_city = is_rate_input-ort01 AND
                                   regioz = is_rate_input-regio AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_925 INTO ls_fuel_surcharge_rate
                             WHERE tplst = is_rate_input-tplst AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_941 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                   vsbed = is_rate_input-vsbed AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_906 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.

    LOOP AT gt_rail_rate_930 INTO ls_fuel_surcharge_rate
                             WHERE kschl = iv_kschl AND "'ZFTS' AND
                                 ( datab <= is_rate_input-date AND
                                   datbi >= is_rate_input-date ).
      IF ls_fuel_surcharge_rate IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
    IF ls_fuel_surcharge_rate IS NOT INITIAL AND
       ls_fuel_surcharge_rate-kmein = 'MI' AND
       ls_fuel_surcharge_rate-konwa = 'USD'.
      ev_fright_surcharge = ls_fuel_surcharge_rate-kbetr * iv_distz.
      RETURN.
    ELSEIF ls_fuel_surcharge_rate-kmein = space AND
           ls_fuel_surcharge_rate-konwa = '%'.
      ev_fright_surcharge = ( ls_fuel_surcharge_rate-kbetr * iv_fright_rate ) / 100.
      RETURN.
    ENDIF.
  ENDMETHOD.
ENDCLASS.

class ZCL_IM_SD_DL_SHP_DELIVERY definition
  public
  final
  create public .

*"* public components of class ZCL_IM_SD_DL_SHP_DELIVERY
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_LE_SHP_DELIVERY_PROC .
protected section.
*"* protected components of class ZCL_IM_SD_DL_SHP_DELIVERY
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_SD_DL_SHP_DELIVERY
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_SD_DL_SHP_DELIVERY IMPLEMENTATION.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_HEADER .
endmethod.


METHOD if_ex_le_shp_delivery_proc~change_delivery_item .


  DATA:  lv_matkl    TYPE matkl,
         lv_kostk    TYPE kostk,
         lv_spart    TYPE spart,
         lv_lfart    TYPE lfart.


  SELECT SINGLE lowval INTO lv_matkl
    FROM zdl_fields
   WHERE category = 'Z_PACKINTONS'
     AND fieldname = 'EXCLUDE_MATKL'
     AND lowval    = cs_lips-matkl.
*** if the value is found - then we do NOT want to process since it is
*** and exclude - therefore we only continue if SY_SUBRC = 4.
  IF sy-subrc = 4.

    IF cs_lips-vrkme = 'TON'.
*  - - - - - -    if ordered in "TONS'  (which should weed out STOs)
      SELECT SINGLE lowval INTO lv_spart
        FROM zdl_fields
       WHERE category  = 'Z_PACKINTONS'
         AND fieldname = 'DIVISION'
         AND lowval    = cs_lips-spart.
      IF sy-subrc IS INITIAL.
*  - - - - - -    if division is setup as one that we convert
        SELECT SINGLE lowval INTO lv_lfart
          FROM zdl_fields
         WHERE category  = 'Z_PACKINTONS'
           AND fieldname = 'DELYTYPE'
           AND lowval    = cs_likp-lfart.
        IF sy-subrc IS INITIAL.
*  - - - - - -    if delivery type is setup as one that we convert
          SELECT SINGLE kostk INTO lv_kostk
           FROM vbuk
          WHERE vbeln = cs_lips-vbeln.
          IF sy-subrc = 04.
*  - - - - - -    if Delivery not created yet (insert)
            cs_lips-vrkme     = 'LB'.
            cs_lips-lfimg     = cs_lips-lfimg * 2000.
            cs_lips-lfimg_flo = cs_lips-lfimg_flo * 2000.
            cs_lipsd-ofmng    = cs_lipsd-ofmng * 2000.
            cs_lips-umvkz = 1.
          ENDIF.                   " VBUK not found (Dely not Saved)
          IF sy-subrc IS INITIAL.
            IF lv_kostk = 'A' OR
               lv_kostk = ' '.
*  - - - - - -    if not picked
              cs_lips-vrkme     = 'LB'.
              cs_lips-lfimg     = cs_lips-lfimg * 2000.
              cs_lips-lfimg_flo = cs_lips-lfimg_flo * 2000.
              cs_lipsd-ofmng    = cs_lipsd-ofmng * 2000.
              cs_lips-umvkz = 1.
            ENDIF.                  " KOSTK = A or ' ' (not picked)
          ENDIF.                    " VBUK found (Dely Saved)
        ENDIF.                      " Delivery Type
      ENDIF.                        " Division Check
    ENDIF.                          " Delivery in tons
  ENDIF.                            " exclude matkl






*** if export sto delivery - pull sales order material description

  DATA:  lv_vbeln     TYPE vbeln,
         lv_vbelp     TYPE vbelp,
         lv_dpr       TYPE zsto_dpr,
         lv_arktx     TYPE arktx.


  IF NOT cs_lips-vgbel IS INITIAL.
****   sto shipment - check for DPR
    SELECT SINGLE zsto_dpr INTO lv_dpr
      FROM zdl_supply_drivn
     WHERE locno = cs_lips-werks
       AND matkl = cs_lips-matkl.
    IF sy-subrc IS INITIAL.
      IF lv_dpr IS INITIAL OR
         lv_dpr = 'N'.

*
*    not DPR - so proceed.
        SELECT SINGLE vbeln vbelp
          INTO (lv_vbeln, lv_vbelp)
          FROM ekkn
         WHERE ebeln = cs_lips-vgbel
           AND ebelp = cs_lips-vgpos.
        IF sy-subrc IS INITIAL.
**** export port as a plant - get arktx from sales order
          SELECT SINGLE arktx INTO lv_arktx
            FROM vbap
           WHERE vbeln = lv_vbeln
             AND posnr = lv_vbelp.
          IF sy-subrc IS INITIAL.
**** change only if it's different
            IF NOT lv_arktx IS INITIAL.
              IF cs_lips-arktx <> lv_arktx.
                cs_lips-arktx = lv_arktx.
              ENDIF.      "change ARKTX
            ENDIF.      "ARKTX is populated
          ENDIF.      "select ARKTX
        ENDIF.      "Get Sales Order from PO
      ENDIF.      "Check DPR value
    ENDIF.      "select DPR
  ENDIF.      "if PO

*
ENDMETHOD.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FCODE_ATTRIBUTES .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FIELD_ATTRIBUTES .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~CHECK_ITEM_DELETION .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_DELETION .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_FINAL_CHECK .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~DOCUMENT_NUMBER_PUBLISH .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_HEADER .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_ITEM .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~INITIALIZE_DELIVERY .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~ITEM_DELETION .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~PUBLISH_DELIVERY_ITEM .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~READ_DELIVERY .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_BEFORE_OUTPUT.
endmethod.


METHOD if_ex_le_shp_delivery_proc~save_and_publish_document .
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**   COPYRIGHT (C) 2006 by INTERNATIONAL PAPER ALL RIGHTS RESERVED   **
**     REVISIONS COPYRIGHT (C) 2006, 20xx by INTERNATIONAL PAPER     **
***********************************************************************
* COR# E03167  V2 FPED Logic                           Added: 04/2006 *
*_____________________________________________________________________*
* Description:                                                        *
* Write some data to table ZPPFPED_STATUS                             *
*   only for outbound deliveries for Apriso/Flexnet facilities        *
*_____________________________________________________________________*
* Change History:                                                     *
* Programmer      Date     Action                                     *
* ==============  ======== =========================================  *
* MACARTE         06/2002  created as part of V2W1 Nov 2006 go-live   *
*                                                                     *
* PRAGUPA         10/26/2006   Setting the processing status to 0.    *
*                              It means record not processed in table *
*                              ZPPFPED_STATUS.                        *
*                                                                     *
* PRAGUPA         09/24/2007   As per new design in U01217 this code  *
*                              can be commented out as we will no longer
*                              need, as the new userexit will         *
*                              only process deliveries which SAP      *
*                              retrieves as part of the VL06T         *
*                              selection logic                        *
*                              Also populating FPED start date/time   *
*                                                                     *
* PRAGUPA        06/18/2008   V2 Rollback  EDEK912215                 *
*____________________________________________________________________ *
***********************************************************************
* COR# E03167  V2 FPED Logic begin                     Added: 04/2006 *
***********************************************************************
    constants:
       lc_vbtyp_j  type vbtyp value 'J',    "outbound delivery
       lc_true     type boolean   value 'X',
       lc_false    type boolean   value space,
       lc_prog_id  type programm value 'ZDL_E03167',
       lc_lfart_nl type lfart value 'NL',   "dlvry for STO
       lc_lfart_lf type lfart value 'LF',   "dlvry for cust ord
       lc_lfart    type zsp_fieldname value 'LFART%',
       lc_updkz_d  type updkz_d value 'D',
       lc_updkz_i  type updkz_d value 'I',
       lc_updkz_u  type updkz_d value 'U',
       lc_updkz_blank type updkz_d value ' ',
       lc_n(1)     value 'N',

*Code added for FPED by PRAGUPA 10/26/2006 TPR # 15572
*This constant value '0' indicates Records not processed
*Begin of Code commented 09/24/2007 as per new design in U01217
*      lc_proc_status(1) value '0',
*End of Code commented 09/24/2007 as per new design in U01217

*End of Code added for FPED by PRAGUPA 10/26/2006 TPR # 15572

       lc_blank(1) value ' '.

  TYPES:
     s_xlips        TYPE lipsvb.
  DATA:
     ln_fped_loc       TYPE zdl_fped_loc,
     ln_zsp_value      TYPE zsp_value,
     ln_zppfped_status TYPE zppfped_status,
     ln_zppkiwifped    TYPE zppkiwifped,
     lt_zppkiwifped    TYPE STANDARD TABLE OF zppkiwifped,
     ln_xlikp          LIKE LINE OF it_xlikp,
     ln_xlips          TYPE s_xlips,
     lt_xlips          LIKE STANDARD TABLE OF ln_xlips,
     lv_modify         TYPE boolean,
     lv_aufnr          TYPE aufnr,
     lv_timestamp      TYPE zdl_timestamp.


  LOOP AT it_xlikp INTO ln_xlikp
      WHERE vbtyp = lc_vbtyp_j.               "only outbound deliveries
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*
*  check certain delivery header/line fields to bypass most deliveries
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*
* exclude deliveries for all but V2 plant/shipping points combinations
* by reading ZDL_FPED_LOC
*   (assumption - all delivery line items are from the same plant)
*   get 1st delivery line item
    LOOP AT it_xlips INTO ln_xlips
            WHERE vbeln = ln_xlikp-vbeln.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0.
**  validate shipping point/plant by reading ZDP_FPED_LOC
      SELECT SINGLE * FROM zdl_fped_loc
         INTO ln_fped_loc
        WHERE werks = ln_xlips-werks
          AND vstel = ln_xlikp-vstel.
      IF sy-subrc <> 0.
        CONTINUE.
      ENDIF.
    ENDIF.

**  check the delivery type in zsp_value
    SELECT SINGLE * FROM zsp_value INTO ln_zsp_value
        WHERE pgrmid = lc_prog_id
          AND fieldname LIKE lc_lfart
          AND fieldvalue = ln_xlikp-lfart.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*
*   these are the deliveries we need to process for V2 FPED logic
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*
    IF ln_xlikp-updkz = lc_updkz_d.
**    entire delivery deleted? delete matching ZPPFPED_STATUS records
      SELECT SINGLE * FROM zppfped_status INTO ln_zppfped_status
             WHERE vbeln = ln_xlips-vbeln.
      IF sy-subrc = 0.
        DELETE FROM zppfped_status
               WHERE vbeln = ln_xlikp-vbeln.
      ENDIF.

    ELSE.

*** process delivery data at a line item level

**    set-up some data before processing delivery line items
*     - build internal table of sales order / STOs on this delivery
      lt_xlips[] = it_xlips[].
      DELETE lt_xlips WHERE vbeln <> ln_xlikp-vbeln.
      SORT lt_xlips BY vgbel vgpos.
      DELETE ADJACENT DUPLICATES FROM lt_xlips
            COMPARING vgbel vgpos.
*     get any production order data from zppkiwifped
*       for the sales order / STOs on the delivery line items
      REFRESH lt_zppkiwifped.
      SELECT * FROM zppkiwifped INTO TABLE lt_zppkiwifped
           FOR ALL ENTRIES IN lt_xlips
           WHERE vbeln = lt_xlips-vgbel
             AND posnr = lt_xlips-vgpos.
      IF sy-subrc = 0.
**      there may be several production orders per order/item
*       this delete will eliminate the oldest duplicates
        SORT lt_zppkiwifped BY vbeln posnr etenr create_timestam.
        DELETE ADJACENT DUPLICATES FROM lt_zppkiwifped
               COMPARING vbeln posnr etenr.
      ENDIF.
      FREE lt_xlips[].

**    process each delivery line item of the delivery
      LOOP AT it_xlips INTO ln_xlips
          WHERE vbeln = ln_xlikp-vbeln.
        CASE ln_xlips-updkz.
*         do nothing when line item changes
          WHEN lc_updkz_u.

*         no action if item unchanged
          WHEN lc_updkz_blank.

**        line item delete?
*         delete zppfped_status entries for delivery item
          WHEN lc_updkz_d.
            SELECT SINGLE * FROM zppfped_status INTO ln_zppfped_status
                     WHERE vbeln = ln_xlips-vbeln
                       AND posnr = ln_xlips-posnr.
            IF sy-subrc = 0.
              DELETE FROM zppfped_status
                     WHERE vbeln = ln_xlips-vbeln
                       AND posnr = ln_xlips-posnr.
            ENDIF.

**         new delivery line item?
          WHEN lc_updkz_i.
*           does zppfped_status entry already exist?
*           (this is to catch errors & avoid SQL duplicate errors)
            CLEAR ln_zppfped_status.
            SELECT SINGLE * FROM zppfped_status INTO ln_zppfped_status
                 WHERE vbeln = ln_xlips-vbeln
                   AND posnr = ln_xlips-posnr.
            IF sy-subrc = 0.
              lv_modify = lc_true.
            ELSE.
              lv_modify = lc_false.
            ENDIF.
**          does production order exist for the sales order/STO?
*             get production order status from lt_zppkiwifped
            READ TABLE lt_zppkiwifped INTO ln_zppkiwifped
                  WITH KEY vbeln = ln_xlips-vgbel
                           posnr = ln_xlips-vgpos.
            IF sy-subrc = 0.
              ln_zppfped_status-prod_status =
                             ln_zppkiwifped-prod_status.
* Begin of changes to populate the previous and current statuses
* required as per E04022.
* Begin of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
*              ln_zppfped_status-ZPRV_PROD_STATUS =
*                             ln_zppkiwifped-ZPRV_PROD_STATUS.
*              ln_zppfped_status-ZCUR_PROD_STATUS =
*                             ln_zppkiwifped-ZCUR_PROD_STATUS.
* End of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
* End of changes for E04022.

            ELSE.
* Begin of changes to populate the previous and current statuses
* required as per E04022.
* Begin of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
*              clear ln_zppfped_status-ZPRV_PROD_STATUS.
*              ln_zppfped_status-ZCUR_PROD_STATUS = 'N'.
* End of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
* End of changes for E04022.

*          no production order yet so
*           delivery type is for stock transfer LFART=NL
              IF ln_xlikp-lfart =  lc_lfart_nl.
**               assume MTS material
*                if production order comes later, status will be reset
                ln_zppfped_status-prod_status = lc_n.
              ELSEIF ln_xlikp-lfart =  lc_lfart_lf.
*           delivery type is for customer delivery LFART=LF
*              (index exists for kdauf/kdpos)
                SELECT SINGLE aufnr FROM afpo INTO lv_aufnr
                   WHERE kdauf = ln_xlips-vgbel
                     AND kdpos = ln_xlips-vgpos.
                IF sy-subrc = 0.
*prod ord is in SAP but Kiwi fped data hasn't come yet
*                   the kiwi fped i/f will change it later
                  ln_zppfped_status-prod_status = lc_blank.
                ELSE.
**                  no production order in SAP or Kiwi
*                   may be from ncp or inventory
*                   but if kiwi prod ord comes later it will change
                  ln_zppfped_status-prod_status = lc_n.
                ENDIF.
              ENDIF.
            ENDIF.
*           convert system date/time fields to a timestamp value
            CLEAR lv_timestamp.
            CONVERT DATE sy-datum TIME sy-uzeit
                INTO TIME STAMP lv_timestamp TIME ZONE 'UTC   '.
**          build zppfped_status record for delivery and update
            ln_zppfped_status-change_timestam = lv_timestamp.

*Code added for FPED by PRAGUPA 10/26/2006 TPR # 15572
* Record not processed
*Begin of Code commented 09/24/2007 as per new design in U01217
*              ln_zppfped_status-proc_status =  lc_proc_status.
*End of Code commented 09/24/2007 as per new design in U01217
*End of Code added for FPED by PRAGUPA 10/26/2006 TPR # 15572


            IF lv_modify = lc_true.
              MODIFY zppfped_status FROM ln_zppfped_status.
            ELSE.
              ln_zppfped_status-vbeln = ln_xlips-vbeln.
              ln_zppfped_status-posnr = ln_xlips-posnr.
              ln_zppfped_status-vbeln_v = ln_xlips-vgbel.
              ln_zppfped_status-posnr_v = ln_xlips-vgpos.
              ln_zppfped_status-create_timestam = lv_timestamp.
              ln_zppfped_status-mbdat = ln_xlikp-kodat.
              ln_zppfped_status-mbuhr = ln_xlikp-kouhr.
              INSERT zppfped_status FROM ln_zppfped_status.
            ENDIF.
          WHEN OTHERS.
*             no action
        ENDCASE.              "ln_xlips-updkz
      ENDLOOP.              "ct_xlips
    ENDIF.
  ENDLOOP.              "ct_xlikp
***********************************************************************
* COR# E03167  V2 FPED Logic end                                      *
***********************************************************************
************************************************************************
* E04022- V2-Custom trigger for STO based on Delivery Creation         *
* Transport: ESBK9A06A9                                                *
* Programmer  : Padma Sunkara                                          *
************************************************************************
* Begin of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
* Include ZDL_E04022_FLEX_TRIG.
* End of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215

ENDMETHOD.


METHOD if_ex_le_shp_delivery_proc~save_document_prepare .
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**   COPYRIGHT (C) 2005 by INTERNATIONAL PAPER ALL RIGHTS RESERVED   **
**     REVISIONS COPYRIGHT (C) 2006, 20xx by INTERNATIONAL PAPER     **
***********************************************************************
* COR# U01168  Delivery Windows                  Create Date: 08/2005 *
*_____________________________________________________________________*
* Description: R6  U01168 delivery windows on SO deliveries           *
*_____________________________________________________________________*
* Change History:                                                     *
* Programmer        Date     Action                                   *
* ================  ======== =====================================    *
* Maureen Carter    11/14/06 reworked to add filter logic - only      *
*   called when delivery is inserted of item is inserted/deleted      *
*  (break/fix CO69438)                                                *
* Randall Wainwright 04/11/07 STO LFT Rounding Error fix              *
*  (break/fix CHG74069   Transport: E0VK928151) Search 'RLW01'        *
*   Note that the window logic may need to be updated for multiple    *
*   delivery processing (more than one record in ct_xlikp)            *
*   e.g., if the index 1 record is not VBTYP = 'J', but deliv. 2 is.  *
* Bala Mandla      02/13/09  EDEK914518                               *
*                            Delivery Window Intersection Update      *
* ____________________________________________________________________*

***********************************************************************
* COR# U01168  Delivery Windows on deliveries  begin                  *
***********************************************************************
  DATA: lv_update_needed(1) TYPE c,
        wa_lips             LIKE LINE OF ct_xlips,
        wa_xlikp            LIKE LINE OF ct_xlikp.

*** Start of change AFULWAR CD# 2000001528 5/14/2019
* Add application log for error analysis. this log will be
* removed once the error is found.
  CALL METHOD zcl_dl_delivery=>PICK_MISSING_BATCH
    EXPORTING
      it_xlips      = ct_xlips
      iv_class_name = 'Cl:ZCL_IM_SD_DL_SHP_DELIVERY/SAVE_DOCUMENT_PREP'.
*** End of change AFULWAR CD# 2000001528 5/14/2019

  CLEAR wa_xlikp.                                           " <<RLW01+
  READ TABLE ct_xlikp INTO wa_xlikp INDEX 1.

* outbound deliveries only
  IF wa_xlikp-vbtyp = 'J'.

    CLEAR lv_update_needed.

*   and only on insert of delivery
    IF wa_xlikp-updkz = 'I'.
      lv_update_needed = 'X'.

    ELSE.
*     or insert/delete of line item
      LOOP AT ct_xlips INTO wa_lips.
*        IF wa_lips-updkz = 'I' OR wa_lips-updkz = 'D'.
*          lv_update_needed = 'X'.
*          EXIT.
*        ENDIF.
        IF wa_lips-updkz = 'D'.
          lv_update_needed = 'X'.
          EXIT.
        ELSEIF wa_lips-updkz = 'I'.
          IF wa_lips-uecha IS INITIAL.
            lv_update_needed = 'X'.
            EXIT.
          ENDIF.
        ENDIF.
      ENDLOOP.

    ENDIF.

    IF lv_update_needed = 'X'.

      CALL FUNCTION 'ZSD_DL_GEN_DELY_ITEM_WINDOWS'
        TABLES
          it_lips = ct_xlips.

      CALL FUNCTION 'ZSD_DL_GEN_DELY_HDR_WINDOWS'
        TABLES
          it_lips = ct_xlips
          it_likp = ct_xlikp.

    ENDIF.
  ENDIF.
***********************************************************************
* COR# U01168  Delivery Windows   end                                 *
***********************************************************************

***********************************************************************
* << BEGIN BLOCK RLW01+                             " E0VK928151      *
***********************************************************************
  CLEAR wa_xlikp.
* Recalculate Item Volumes
  INCLUDE zsd_dl_u01168_recalc_volums.

***********************************************************************
* << END BLOCK RLW01+                               " E0VK928151      *
***********************************************************************
*  ** Start of change AFULWAR CD# 2000001528 5/14/2019
* Add application log for error analysis. this log will be
* removed once the error is found.
*DATA lt_xlips type TABLE OF shp_likp_t.
  IF ct_xlips IS NOT INITIAL.

    CALL METHOD zcl_dl_delivery=>pick_missing_batch
      EXPORTING
        it_xlips = ct_xlips
        update_flag = abap_true
      IMPORTING
        et_xlips = DATA(lt_xlips).

    IF lt_xlips IS NOT INITIAL.
      ct_xlips[] = lt_xlips[].
    ENDIF.

  ENDIF.

** End of change AFULWAR CD# 2000001528 5/14/2019
ENDMETHOD.
ENDCLASS.

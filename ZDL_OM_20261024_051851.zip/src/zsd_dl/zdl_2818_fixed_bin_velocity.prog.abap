*&---------------------------------------------------------------------*
*& Report  ZDL_2818_FIXED_BIN_VELOCITY                                 *
*&                                                                     *
*&---------------------------------------------------------------------*

INCLUDE zdl_fixed_bin_velocity_top.
INCLUDE zdl_fixed_bin_velocity_form.

INITIALIZATION.
* restrict the selection screen for storage type and materials
  PERFORM restrict_range.

AT SELECTION-SCREEN.
* check for fixed bin
  PERFORM bin_check.

START-OF-SELECTION.
* get teansfer order
  PERFORM get_transfer_ord.
* get replenishment values
  PERFORM get_mlgt.
* preapre the final table
  PERFORM prepare_final.

END-OF-SELECTION.
* display the output
CHECK gt_final is not INITIAL.
  PERFORM display_output.

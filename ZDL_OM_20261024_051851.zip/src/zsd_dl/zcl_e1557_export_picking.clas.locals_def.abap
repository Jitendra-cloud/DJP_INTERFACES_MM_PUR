*"* use this source file for any type declarations (class
*"* definitions, interfaces or data types) you need for method
*"* implementation or private method's signature

* structure of usapplreff table
TYPES : Begin of ts_usapp,
          objkey TYPE SWO_OBJTYP,
        End of ts_usapp.

TYPES : tt_usapp TYPE TABLE OF ts_usapp.

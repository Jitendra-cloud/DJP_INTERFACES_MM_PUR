*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_SLOTSTOP.                  " Global Data
  INCLUDE LZSD_DL_SLOTSUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_SLOTSF...                  " Subprograms
* INCLUDE LZSD_DL_SLOTSO...                  " PBO-Modules
* INCLUDE LZSD_DL_SLOTSI...                  " PAI-Modules

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_MATLTYPE....................................*
DATA:  BEGIN OF STATUS_ZDL_MATLTYPE                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_MATLTYPE                  .
CONTROLS: TCTRL_ZDL_MATLTYPE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_MATLTYPE                  .
TABLES: ZDL_MATLTYPE                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

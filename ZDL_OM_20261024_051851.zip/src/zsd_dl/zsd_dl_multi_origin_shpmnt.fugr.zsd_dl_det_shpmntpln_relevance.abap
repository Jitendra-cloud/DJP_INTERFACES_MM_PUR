FUNCTION zsd_dl_det_shpmntpln_relevance.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  EXPORTING
*"     VALUE(E_RELV_IND) TYPE  BOOLEAN
*"  TABLES
*"      T_VTRLP STRUCTURE  VTRLP
*"  EXCEPTIONS
*"      INVALID_INPUT
*"----------------------------------------------------------------------
* Change History :                                                     *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ====== ===============================*
* RMYNEEDU 06/23/2008 E0VK940669 If any item doesn't appear in the     *
*                                table ZDL_FIELDS, mark the output as  *
*                                relevant.                             *
*______________________________________________________________________*

  DATA  : lt_zsd_dl_no_sto  LIKE  zsd_dl_no_sto
                                  OCCURS 0 WITH HEADER LINE.
*  DATA  : lt_zmaprmatyp     LIKE  zmaprmatyp
*                                  OCCURS 5 WITH HEADER LINE.
  DATA  : lt_zdl_fields LIKE zdl_fields OCCURS 0 WITH HEADER LINE.


  IF t_vtrlp[] IS INITIAL.
    RAISE invalid_input.
  ENDIF.

*  SELECT * FROM zmaprmatyp INTO TABLE lt_zmaprmatyp.
*  IF sy-subrc EQ 0.
*    SORT lt_zmaprmatyp BY mtart.
*  ENDIF.
  REFRESH lt_zdl_fields.
  CLEAR lt_zdl_fields.
  SELECT * FROM zdl_fields   INTO TABLE lt_zdl_fields
               WHERE category  =  'I02419'   AND
                     fieldname =  'MAT_TYPE' AND
                     sign      =  'I'        AND
                     optn      =  'EQ'.
  SORT lt_zdl_fields BY lowval.

  SELECT * FROM zsd_dl_no_sto INTO TABLE lt_zsd_dl_no_sto.
  IF sy-subrc EQ 0.
    SORT lt_zsd_dl_no_sto BY matnr werks.
  ENDIF.

  e_relv_ind = 'X'.
  LOOP AT t_vtrlp.
    CLEAR lt_zsd_dl_no_sto.
    READ TABLE lt_zsd_dl_no_sto WITH KEY matnr = t_vtrlp-matnr
                                         werks = t_vtrlp-werks
                                         BINARY SEARCH.
    IF sy-subrc EQ 0.
      CLEAR e_relv_ind.
      EXIT.
    ENDIF.
  ENDLOOP.
  IF e_relv_ind IS INITIAL.
    EXIT.
  ENDIF.
  CLEAR e_relv_ind.
  LOOP AT t_vtrlp.
*    READ TABLE lt_zmaprmatyp WITH KEY mtart = t_vtrlp-mtart
*                                        BINARY SEARCH.
* Check material type in the table ZDL_FIELDS
* Any item doesn't appear in the table, mark the output as relevant.
    READ TABLE lt_zdl_fields
               WITH KEY lowval = t_vtrlp-mtart BINARY SEARCH.

    IF sy-subrc NE 0.
      e_relv_ind = 'X'.
      EXIT.
    ENDIF.
  ENDLOOP.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_FPED_LOC....................................*
DATA:  BEGIN OF STATUS_ZDL_FPED_LOC                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_FPED_LOC                  .
CONTROLS: TCTRL_ZDL_FPED_LOC
            TYPE TABLEVIEW USING SCREEN '9001'.
*...processing: ZPPFPED_STATUS..................................*
DATA:  BEGIN OF STATUS_ZPPFPED_STATUS                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPPFPED_STATUS                .
CONTROLS: TCTRL_ZPPFPED_STATUS
            TYPE TABLEVIEW USING SCREEN '0100'.
*...processing: ZPPKIWIFPED.....................................*
DATA:  BEGIN OF STATUS_ZPPKIWIFPED                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPPKIWIFPED                   .
CONTROLS: TCTRL_ZPPKIWIFPED
            TYPE TABLEVIEW USING SCREEN '9100'.
*.........table declarations:.................................*
TABLES: *ZDL_FPED_LOC                  .
TABLES: *ZPPFPED_STATUS                .
TABLES: *ZPPKIWIFPED                   .
TABLES: ZDL_FPED_LOC                   .
TABLES: ZPPFPED_STATUS                 .
TABLES: ZPPKIWIFPED                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

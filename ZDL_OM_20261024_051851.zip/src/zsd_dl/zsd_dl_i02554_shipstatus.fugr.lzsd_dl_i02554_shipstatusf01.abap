*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_I02554_SHIPSTATUSF01 .
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
* Form routine for ZSD_DL_I02554_SHIPSTATUS_RELEV function module
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       Form  VALIDATE_RELEV_INPUT_DATA
*----------------------------------------------------------------------*
* This form validates the Input data
*----------------------------------------------------------------------*
FORM validate_relev_input_data  USING    iv_tknum
                                         iv_itnum
                                CHANGING cs_error.

  DATA : lv_msg TYPE string.

  PERFORM validate_shipment_number USING iv_tknum
                                CHANGING lv_msg.
  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message    USING lv_msg
                                CHANGING cs_error.
    RETURN.
  ENDIF.

  IF iv_itnum IS NOT INITIAL.
    PERFORM validate_itinerary_number USING iv_itnum
                                   CHANGING lv_msg.
  ENDIF.
  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message    USING lv_msg
                                CHANGING cs_error.
    RETURN.
  ENDIF.

ENDFORM.                    " VALIDATE_RELEV_INPUT_DATA
*----------------------------------------------------------------------*
*       Form  DETERMINE_RELEVANCY_CODES
*----------------------------------------------------------------------*
* This form determines the Relevancy Action codes
*----------------------------------------------------------------------*
FORM determine_relevancy_codes  TABLES ct_result STRUCTURE gs_result.

  DATA : ls_itinerary  TYPE zmos_itinerary,
         lt_deliveries TYPE zmos_deliveries_s,
         lt_vbpa       TYPE STANDARD TABLE OF vbpa,
         lt_codes      TYPE zdl_i02554_action_code_t.

*--> Process itineraries of the shipment
  LOOP AT gt_itinerary INTO ls_itinerary.

    REFRESH lt_deliveries.
*--> Collect delivery information
    lt_deliveries[] = ls_itinerary-deliveries[].

*--> Get the partners for all above deliveries from VBPA
    PERFORM get_vbpa_data TABLES lt_deliveries
                                 lt_vbpa.

*--> Get the Action codes for the deliveries
    PERFORM get_codes     TABLES lt_deliveries
                                 lt_vbpa
                                 lt_codes.
    SORT lt_codes.
    DELETE ADJACENT DUPLICATES FROM lt_codes.

*--> Populate final output table
    ct_result-tknum = gs_vttk-tknum.
    ct_result-itnum = ls_itinerary-itnum.
    ct_result-zz_zssoa =  lt_codes[].
    APPEND ct_result.
    CLEAR  ct_result.

  ENDLOOP.

ENDFORM.                    " DETERMINE_RELEVANCY_CODES
*----------------------------------------------------------------------*
*       Form  GET_CODES
*----------------------------------------------------------------------*
* This form gets the Action codes relevant for the deliveries by
* checking the Condition tables B980, B981, B982
*----------------------------------------------------------------------*
FORM get_codes  TABLES  it_deliveries TYPE      zmos_deliveries_s
                        it_vbpa       STRUCTURE vbpa
                        ct_codes      TYPE zdl_i02554_action_code_t.

  DATA : ls_deliveries TYPE zmos_deliveries,
         ls_vbpa       TYPE vbpa,
         lv_kunnr_we   TYPE kunnr,
         lv_kunnr_ag   TYPE kunnr.

  REFRESH ct_codes.

  SORT it_vbpa BY vbeln parvw.

  LOOP AT it_deliveries INTO ls_deliveries.

    CLEAR : lv_kunnr_we, lv_kunnr_ag.
*--> Check if ship-to exists
    CLEAR ls_vbpa.
    READ TABLE it_vbpa INTO ls_vbpa WITH KEY
                                    vbeln = ls_deliveries-vbeln
                                    parvw = gc_parvw_we
                                    BINARY SEARCH.
    IF sy-subrc EQ 0.
      lv_kunnr_we = ls_vbpa-kunnr.
    ENDIF.

*--> Check if sold-to exists
    CLEAR ls_vbpa.
    READ TABLE it_vbpa INTO ls_vbpa WITH KEY
                                    vbeln = ls_deliveries-vbeln
                                    parvw = gc_parvw_ag
                                    BINARY SEARCH.
    IF sy-subrc EQ 0.
      lv_kunnr_ag = ls_vbpa-kunnr.
    ENDIF.

*--> If exists, Get Action Code(s) for ship-to from condition tables
    IF lv_kunnr_we IS NOT INITIAL.
      SELECT zz_zssoa
             FROM b982
             APPENDING TABLE ct_codes
             WHERE kappl EQ gc_kappl_v7
             AND   kschl EQ gc_kschl_zsso
             AND   kunwe EQ lv_kunnr_we.
    ENDIF.


*--> If exists, Get Action Code(s) for sold-to from condition tables
    IF lv_kunnr_ag IS NOT INITIAL.
      SELECT zz_zssoa
             FROM b981
             APPENDING TABLE ct_codes
             WHERE kappl    EQ gc_kappl_v7
             AND   kschl    EQ gc_kschl_zsso
             AND   zz_kunag EQ lv_kunnr_ag.
    ENDIF.

*--> If both ship-to and sold-to exists.
    IF lv_kunnr_we IS NOT INITIAL AND lv_kunnr_ag IS NOT INITIAL.
      SELECT zz_zssoa
             FROM b980
             APPENDING TABLE ct_codes
             WHERE kappl    EQ gc_kappl_v7
             AND   kschl    EQ gc_kschl_zsso
             AND   zz_kunag EQ lv_kunnr_ag
             AND   kunwe    EQ lv_kunnr_we.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " GET_CODES

* >> Begin of Change - CC01

*&---------------------------------------------------------------------*
*&      Form  READ_SHIPMENT_ITINERARY_STRUCT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM read_shipment_itinerary_struct  TABLES it_vttk  STRUCTURE vttk
                                            it_vtts  STRUCTURE vtts
                                            it_vttp  STRUCTURE vttp
                                            it_vtsp  STRUCTURE vtsp
                                   CHANGING cs_error STRUCTURE bapiret2.

  DATA : lv_msg  TYPE string,
         ls_vttk TYPE vttk.

  READ TABLE it_vttk INTO ls_vttk INDEX 1.

  CALL FUNCTION 'ZSD_DL_MOS_ITINERARY_VIEW'
    TABLES
      t_vttk                         = it_vttk[]
      t_vtts                         = it_vtts[]
      t_vttp                         = it_vttp[]
      t_vtsp                         = it_vtsp[]
      t_itinerary                    = gt_itinerary
    EXCEPTIONS
      invalid_input                  = 1
      shipment_not_found             = 2
      no_deliveries_found            = 3
      no_stages_on_shipment          = 4
      no_authority                   = 5
      deliveries_unassigned_to_stage = 6
      flex_multi_origin_not_allowed  = 7
      OTHERS                         = 8.
  CASE sy-subrc.
    WHEN 0.
      IF gt_itinerary[] IS INITIAL.
* Error while reading Itinerary Function Module
        MESSAGE e016 INTO lv_msg.
      ENDIF.
    WHEN 1.
* Invalid input to the Itinerary Function Module
      MESSAGE e010 INTO lv_msg.
    WHEN 2.
* Shipment & not found
      MESSAGE e011 WITH ls_vttk-tknum INTO lv_msg.
    WHEN 3.
* Deliveries not found on shipment &
      MESSAGE e012 WITH ls_vttk-tknum INTO lv_msg.
    WHEN 4.
* No Stages exist on shipment &
      MESSAGE e013 WITH ls_vttk-tknum INTO lv_msg.
    WHEN 5.
* No Authority for reading the Itinerary Function Module
      MESSAGE e014 INTO lv_msg.
    WHEN 6.
* Deliveries unassigned to stage for shipment &
      MESSAGE e015 WITH ls_vttk-tknum INTO lv_msg.
    WHEN OTHERS.
* Error while reading Itinerary Function Module
      MESSAGE e016 INTO lv_msg.
  ENDCASE.

  IF lv_msg IS NOT INITIAL.
    PERFORM build_error_message     USING lv_msg
                                 CHANGING cs_error.
  ENDIF.

ENDFORM.                    " READ_SHIPMENT_ITINERARY_STRUCT

* << End of Change - CC01

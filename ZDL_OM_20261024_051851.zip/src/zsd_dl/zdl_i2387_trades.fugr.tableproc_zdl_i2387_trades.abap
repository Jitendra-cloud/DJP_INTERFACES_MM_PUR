*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_I2387_TRADES
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_I2387_TRADES    .

  PERFORM TABLEPROC.

ENDFUNCTION.

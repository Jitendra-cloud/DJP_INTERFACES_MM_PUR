*&---------------------------------------------------------------------*
*& Module pool       ZDL_E04624_WF_GR                                  *
*&                                                                     *
*&---------------------------------------------------------------------*
***********************************************************************
***                                                                  **
***             C O M P A N Y   C O N F I D E N T I A L              **
***                                                                  **
***        This program is the property of International Paper.      **
***        Care should be taken to prevent its unauthorized use.     **
***                                                                  **
***********************************************************************
***********************************************************************
***                                                                  **
***                    COPYRIGHT (C) 2009                            **
***                     INTERNATIONAL PAPER                          **
***                                                                  **
***                     ALL RIGHTS RESERVED                          **
***                                                                  **
***                   REVISIONS COPYRIGHT (C)                        **
***                            2010                                  **
***                                                                  **
***                             by                                   **
***                     INTERNATIONAL PAPER                          **
***********************************************************************
**____________________________________________________________________*
** Program Name :ZDL_E04624_WF_GR        Create Date:    08/09/2010   *
**                                                                    *
** SAP Name     :ZDL_E04624_WF_GR        Version : Initial            *
**                                                                    *
** Programmer   :Meenakshi Yadav         Last Update:                 *
**____________________________________________________________________*
** Background of this developement :
** An inbound goods receipt Workflow application routes Trades IDOC   *
** failure task to an appropriate SAP mail inbox, based on            *
** organizational unit, IDOC status, and error message.  The recipient*
** ascertains the next appropriate action, which includes execution of*
** this transaction; whenever, the decision is to edit the IDOC data. *
** This transaction will facilitate the IDOC edit and reprocessing    *
** functionality.                                                     *
**       Workflow tasks initiate the execution of this program which  *
** receives the IDOC number in a screen parameter.  This application  *
** returns control to Workflow inbox, upon competition.               *
**____________________________________________________________________*
** Change History:                                                    *
**     Programmer        Date       Req. #            Action          *
** ==================  =======     =========  ========================*
**  Meenakshi Yadav    08/09/2010  EDVK977663    New Program          *
**  Steve Pieri        09/13/2010                                     *
**                             New funcationality, add the ability    *
**                             to archive and reprocess the IDOC.     *
**                             Redesign the application toolbar.      *
*_____________________________________________________________________*
***********************************************************************
* Includes    :  zdl_e04624_top                                       *
*                zdl_e04624_o01                                       *
*                zdl_e04624_i01                                       *
*                zdl_e04624_f01                                       *
*_____________________________________________________________________*
* Logical Databases :                                                 *
*_____________________________________________________________________*
* External Calls                                                      *
*   Function Modules:  EDI_DOCUMENT_OPEN_FOR_READ                     *
*                      EDI_SEGMENTS_GET_ALL                           *
*                      EDI_DOCUMENT_READ_LAST_STATUS                  *
*                      EDI_DOCUMENT_CLOSE_READ                        *
*                      Z_SD_IDOC_INPUT_ZDELVRY03_GR                   *
*                      EDI_DOCUMENT_OPEN_FOR_PROCESS                  *
*                      EDI_DOCUMENT_STATUS_SET                        *
*                      EDI_DOCUMENT_CLOSE_PROCESS                     *
*   Transactions    :                                                 *
*   Programs        :                                                 *
*_____________________________________________________________________*
* Size Limitations                                                    *
*   Max Number Recs : Not Specified                                   *
*_____________________________________________________________________*
* Execution Requirements : Launched by Workflow                       *
*_____________________________________________________________________*
***********************************************************************

PROGRAM  zdl_e04624_wf_gr MESSAGE-ID zsd_dl.

INCLUDE  zdl_e04624_top.  " Global Data

INCLUDE zdl_e04624_o01.  " PBO-Modules

INCLUDE zdl_e04624_i01.  " PAI-Modules

INCLUDE zdl_e04624_f01.  " FORM-Routines

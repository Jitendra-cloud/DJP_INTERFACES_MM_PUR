*&---------------------------------------------------------------------*
*&  Include           ZSDE10539_F01
*&---------------------------------------------------------------------*


*&---------------------------------------------------------------------*
*&      Form  top_of_page
*&---------------------------------------------------------------------*
*       Process IP standard page header
*----------------------------------------------------------------------*
form top_of_page.

  data: lt_header like zrptheader occurs 0.
  data: ls_header like zrptheader.
  data: l_line3_left(20)   type c.

* user name
  l_line3_left = 'User: &1'.
  replace '&1' with sy-uname into l_line3_left.

* IP standard header
  call function 'Z_RPT_HEADER'
    exporting
      primary      = sy-title
      line3_left   = l_line3_left
      line3_center = space
    importing
      report_line  = ls_header
    tables
      header_lines = lt_header[]
    exceptions
      error_found.

  if sy-subrc = 0 .
    write : / ls_header-line1,
            / ls_header-line2,
            / ls_header-line3.
  endif.

* Build ALV comments
  perform build_commentary.
  if not gt_listhead[] is initial.
    call function 'REUSE_ALV_COMMENTARY_WRITE'
        exporting it_list_commentary = gt_listhead[].
  endif.

endform.                    " top_of_page

*&---------------------------------------------------------------------*
*&      Form  check_var
*&--------------------------------------------------------------------*
*       Verify entered at selection screen variant name
*---------------------------------------------------------------------*
form check_var using ls_variant type disvariant
                              l_vari     like disvariant-variant
                              l_vtext    type c
                              l_err      type c.

  clear ls_variant-variant.
  clear l_vtext.
  if l_vari is initial.
    clear l_vtext.
    return.
  endif.
  ls_variant-variant = l_vari.

  call function 'REUSE_ALV_VARIANT_EXISTENCE'
    exporting
      i_save     = 'A'
    changing
      cs_variant = ls_variant
    exceptions
      others     = 1.

  if sy-subrc <> 0 and l_err = 'X'.
    message e064(zapr2883_msg) with l_vari.
*   Layout & is invalid
  endif.
  l_vtext = ls_variant-text.

endform.                    " check_var

*&--------------------------------------------------------------------*
*&      Form  get_variant
*&--------------------------------------------------------------------*
*       Get display variant
*---------------------------------------------------------------------*
form get_variant using ls_variant type disvariant
                       l_vari     like disvariant-variant
                       l_vtext    type c.

  data: l_exit(1) type c.
  data: lt_dynpfields like dynpread occurs 0 with header line.
  data: ls_variant1 type disvariant.

  ls_variant1 = ls_variant.

  call function 'REUSE_ALV_VARIANT_F4'
    exporting
      is_variant = ls_variant1
      i_save     = 'A'
    importing
      e_exit     = l_exit
      es_variant = ls_variant1
    exceptions
      not_found  = 1
      others     = 2.

  if sy-subrc <> 0.
    message id sy-msgid type 'S' number sy-msgno
            with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  elseif l_exit = space.

    l_vari  = ls_variant1-variant.

    lt_dynpfields-fieldname  = l_vtext.
    lt_dynpfields-fieldvalue = ls_variant1-text.
    append lt_dynpfields.

    call function 'DYNP_VALUES_UPDATE'
      exporting
        dyname     = sy-repid
        dynumb     = '1000'
      tables
        dynpfields = lt_dynpfields[]
      exceptions
        others     = 1.

    check sy-subrc = 0.
  endif.

endform.                    " get_variant

*&---------------------------------------------------------------------*
*&      Form  get_default_variant
*&--------------------------------------------------------------------*
*       Verify entered at selection screen variant name
*---------------------------------------------------------------------*
form get_default_variant using ls_variant type disvariant
                               l_vari     type disvariant-variant
                               l_vtext    type c.

  check l_vari is initial.

  call function 'REUSE_ALV_VARIANT_DEFAULT_GET'
    changing
      cs_variant = ls_variant
    exceptions
      others     = 1.

  if sy-subrc = 0.
    l_vari = ls_variant-variant.
    l_vtext = ls_variant-text.
  endif.

endform.                    " get_default_variant


*&---------------------------------------------------------------------*
*&      Form  build_commentary
*&---------------------------------------------------------------------*
*       Set commentary for ALV
*----------------------------------------------------------------------*
form build_commentary.

  refresh gt_listhead. clear gt_listhead.

  gt_listhead-typ  = 'S'.
  gt_listhead-key  = 'Delivery:'.
  write likp-vbeln to gt_listhead-info.
  append gt_listhead.

endform.                    " build_commentary

*&---------------------------------------------------------------------*
*&      Form  select_data
*&---------------------------------------------------------------------*
*       Data selection for report
*----------------------------------------------------------------------*
form select_data .

  data: lt_lips   type table of lips.
  data: ls_lips   type lips.
  data: lt_mska   type table of mska.
  data: ls_mska   type mska.
  data: l_err(1)  type c.
  data: lt_ausp   type table of ausp.
  data: ls_ausp   type ausp.
  data: l_field   type string.
  data: ls_char   type klvmera.
  data: l_date(8) type n.
  data: ls_mcha   type mcha.

  field-symbols: <l_value> type any.

*****

  refresh: gt_ba.
  clear: likp, vbuk.

  perform lock_delivery using l_err.
  check l_err is initial.

  select single * from likp where vbeln = p_vbeln.
  check sy-subrc = 0.

  select single * from vbuk where vbeln = p_vbeln.
  check sy-subrc = 0.

  check vbuk-kostk = 'A'.

  select * from lips into table lt_lips where vbeln = p_vbeln.
  check sy-subrc = 0.

  select single * from kna1 where kunnr = likp-kunnr.

  sort gt_char by atinn.

  loop at lt_lips into ls_lips.
    clear: gt_ba, gt_li.
    gt_ba-werks  = ls_lips-werks.
    gt_ba-lgort  = ls_lips-lgort.
    gt_ba-posnr  = ls_lips-posnr.
    gt_ba-matnr  = ls_lips-matnr.
    gt_ba-vbeln1 = likp-vbeln.

    case ls_lips-vgtyp.
      when 'C'.
        gt_ba-vbeln = ls_lips-vgbel.
        gt_ba-vbelp = ls_lips-vgpos.
      when 'V'.

        clear ekkn.
        select * from ekkn up to 1 rows
         where ebeln = ls_lips-vgbel
           and ebelp = ls_lips-vgpos.
        endselect.
        if sy-subrc = 0.
          gt_ba-vbeln = ekkn-vbeln.
          gt_ba-vbelp = ekkn-vbelp.
          gt_ba-ebeln = ekkn-ebeln.
          gt_ba-ebelp = ekkn-ebelp.

        endif.

    endcase.

    perform get_makt.
    gt_ba-maktx = makt-maktx.
    gt_ba-meins = mara-meins.

** summary table (delivery items)
    clear gt_li.
    move-corresponding gt_ba to gt_li.
    gt_li-lfimg1 = ls_lips-lfimg.
    gt_li-vrkme  = ls_lips-vrkme.
    gt_li-gewei  = ls_lips-gewei.

    if gt_li-vrkme = gt_li-meins.
      gt_li-lfimg  = ls_lips-lfimg.
    else.
      call function 'UNIT_CONVERSION_SIMPLE'
        exporting
          input      = gt_li-lfimg
          unit_in    = gt_li-vrkme
          unit_out   = gt_li-meins
        importing
          output     = gt_li-lfimg
        exceptions
          others     = 1.

      if sy-subrc <> 0.
        " gt_li-lfimg = ls_lips-lfimg.
        " gt_li-meins = ls_lips-vrkme.
        gt_li-err-conv = 'X'.
      endif.
    endif.

    select single uebtk uebto untto
      from vbap
      into (gt_li-uebtk, gt_li-uebto, gt_li-untto)
     where vbeln = gt_ba-vbeln
       and posnr = gt_ba-vbelp.

** batches (rolls)

    refresh lt_mska.

    select * from mska
       into table lt_mska
     where matnr = ls_lips-matnr
       and werks = ls_lips-werks
       and lgort = ls_lips-lgort
       and sobkz = 'E'
       and vbeln = gt_ba-vbeln
       and posnr = gt_ba-vbelp
       and kalab > 0
       and charg <> space.

    loop at lt_mska into ls_mska.
      gt_ba-charg = ls_mska-charg.
      gt_ba-kalab = ls_mska-kalab.
      gt_ba-mark  = p_mark.

      clear: gt_ba-appm_gsm             ,
             gt_ba-appm_reel_width      ,
             gt_ba-appm_reel_diameter   ,
             gt_ba-appm_posting_date    ,
             gt_ba-age                  ,
             gt_ba-appm_production_order,
             gt_ba-appm_net_weight      ,
             gt_ba-appm_gross_weight    ,
             gt_ba-tare                 .

      call function 'VB_BATCH_GET_DETAIL'
        exporting
          matnr                    = ls_lips-matnr
          charg                    = ls_mska-charg
          werks                    = ls_lips-werks
          get_classification       = 'X'
        importing
          ymcha                    = ls_mcha
        exceptions
          others                   = 1.

      if sy-subrc = 0.

        refresh lt_ausp.
        select * from ausp into table lt_ausp
               where mafid = 'O'
               and   klart = '023'
               and   objek = ls_mcha-cuobj_bm
               and   atcod between '1' and '9'.

        loop at lt_ausp into ls_ausp.

          read table gt_char into ls_char
            with key atinn = ls_ausp-atinn
            binary search.

          check sy-subrc = 0.

          l_field = 'GT_BA-' && ls_char-atnam.
          assign (l_field) to <l_value>.
          if sy-subrc = 0.
            try.
                case ls_char-atfor.
                  when 'CHAR'.
                    <l_value> = ls_ausp-atwrt.
                  when 'DATE'.
                    l_date = ls_ausp-atflv.
                    <l_value> = l_date.
                  when others.
                    <l_value> = ls_ausp-atflv.
                endcase.
              catch cx_root.
            endtry.
          endif.

*          l_field = 'GT_BA-UM_' && ls_char-atnam.
*          assign (l_field) to <l_value>.
*          if sy-subrc = 0.
*            try.
*                <l_value> = ls_char-dimen.
*              catch cx_root.
*            endtry.
*          endif.
        endloop.
      endif.

* cms 28324 - 10/1/15 - mbruno - begin
      if gt_ba-appm_gross_weight = 0.
        gt_ba-appm_gross_weight = gt_ba-appm_net_weight.
      endif.
* cms 28324 - 10/1/15 - mbruno - end

      gt_ba-tare = gt_ba-appm_gross_weight - gt_ba-appm_net_weight.
      gt_ba-age  = sy-datum - gt_ba-appm_posting_date.
      append gt_ba.
    endloop.
    if sy-subrc <> 0.
      gt_li-comment      = 'No Reel Id'.
      gt_li-err-no_batch = 'X'.
      gt_li-icon         = icon_led_yellow.
    endif.
    append gt_li.
  endloop.

  perform update_li.

endform.                    " select_data

*&---------------------------------------------------------------------*
*&      Form  STATUS_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form status_0100 .

  data: lt_excl type table of sy-ucomm.

*  read table gt_li with key err-error = 'X'.
*  if sy-subrc = 0.
*    append 'ISSUE' to lt_excl.
*  endif.

  set pf-status '0100' excluding lt_excl.
  set titlebar  'GENERIC' with 'India Reel OBD Picking Front-end'.

  perform create_grid.

endform.
*&---------------------------------------------------------------------*
*&      Form  CREATE_GRID
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form create_grid .

  data: ls_layout        type lvc_s_layo.
  data: ls_print         type lvc_s_prnt.
  data: lr_container     type ref to cl_gui_custom_container.
  data: lr_split         type ref to cl_gui_easy_splitter_container.
  data: lr_container_li  type ref to cl_gui_container.
  data: lr_container_ba  type ref to cl_gui_container.
  data: lt_excl          type ui_functions.

  check gr_ba is not bound.

  if sy-batch is initial.
    create object lr_container
      exporting
        container_name = 'C100'
      exceptions
        others         = 1.

    create object lr_split
       exporting
         parent        = lr_container
         orientation   = 0
         sash_position = 50.

    lr_container_ba  = lr_split->top_left_container.
    lr_container_li  = lr_split->bottom_right_container.
  endif.

  create object gr_ba
    exporting
      i_parent = lr_container_ba.

  perform build_fieldcat_ba.

  ls_print-no_colwopt  = 'X'.

  if gs_variant_ba-variant is initial.
    ls_layout-cwidth_opt  = 'X'.
  endif.
  ls_layout-sel_mode    = 'A'.
  ls_layout-smalltitle  = 'X'.
  ls_layout-no_rowmove  = 'X'.
  ls_layout-no_rowins   = 'X'.
*  concatenate: 'Delivery:' likp-vbeln
*         into ls_layout-grid_title separated by space.

* exclude functions from standard toolbar
  append cl_gui_alv_grid=>mc_fc_graph          to lt_excl.
  append cl_gui_alv_grid=>mc_fc_info           to lt_excl.
  append cl_gui_alv_grid=>mc_fc_loc_cut        to lt_excl.
  append cl_gui_alv_grid=>mc_fc_loc_copy       to lt_excl.
  append cl_gui_alv_grid=>mc_mb_paste          to lt_excl.
  append cl_gui_alv_grid=>mc_fc_loc_copy_row   to lt_excl.
  append cl_gui_alv_grid=>mc_fc_check          to lt_excl.
  append cl_gui_alv_grid=>mc_fc_refresh        to lt_excl.

* display grid
  call method gr_ba->set_table_for_first_display
    exporting
      is_layout             = ls_layout
      is_print              = ls_print
      i_save                = 'A'
      is_variant            = gs_variant_ba
      it_toolbar_excluding  = lt_excl
    changing
      it_outtab             = gt_ba[]
      it_fieldcatalog       = gt_fcat_ba[]
    exceptions
      others                = 1.

  check sy-subrc = 0.

  create object g_rec.
  set handler g_rec->top_of_page  for gr_ba.
  set handler g_rec->double_click for gr_ba.
  set handler g_rec->user_command for gr_ba.
  set handler g_rec->toolbar      for gr_ba.
  set handler g_rec->data_changed_finished for gr_ba.

  call method gr_ba->set_toolbar_interactive.

  call method gr_ba->register_edit_event
    exporting
      i_event_id = cl_gui_alv_grid=>mc_evt_enter.

  if sy-batch is initial.

    create object gr_li
      exporting
        i_parent = lr_container_li.

    perform build_fieldcat_li.

    clear ls_layout.
    if gs_variant_li-variant is initial.
      ls_layout-cwidth_opt  = 'X'.
    endif.
    ls_layout-sel_mode    = 'A'.

* display grid
    call method gr_li->set_table_for_first_display
      exporting
        is_layout             = ls_layout
        is_print              = ls_print
        i_save                = 'A'
        is_variant            = gs_variant_li
        it_toolbar_excluding  = lt_excl
      changing
        it_outtab             = gt_li[]
        it_fieldcatalog       = gt_fcat_li[]
      exceptions
        others                = 1.

    check sy-subrc = 0.

    set handler g_rec->top_of_page  for gr_li.
    set handler g_rec->double_click for gr_li.
    set handler g_rec->user_command for gr_li.
    set handler g_rec->toolbar      for gr_li.

    call method gr_li->set_toolbar_interactive.
  endif.

endform.

*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCAT_BA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form build_fieldcat_ba .

  data: ls_fcat  type lvc_s_fcat.
  data: ls_char type klvmera.

  perform build_fieldcatalog using 'GT_BA' gt_fcat_ba[].

  sort gt_fcat_ba by fieldname.

* characteristics
  loop at gt_char into ls_char.
    read table gt_fcat_ba into ls_fcat
                          with key fieldname = ls_char-atnam
                          binary search.
    if sy-subrc = 0.
      ls_fcat-tooltip =
      ls_fcat-coltext = ls_char-atbez.
      if ls_char-dimen is not initial.
        ls_fcat-tooltip = ls_fcat-tooltip && '(' &&
                          ls_char-dimen && ')'.
      endif.
      modify gt_fcat_ba from ls_fcat index sy-tabix.
    endif.

*    l_field = 'UM_' && ls_char-atnam.
*    read table gt_fcat_ba into ls_fcat
*                          with key fieldname = l_field
*                          binary search.
*    if sy-subrc = 0.
*      ls_fcat-tooltip =
*      ls_fcat-seltext = ls_fcat-scrtext_s && '-' && ls_char-atbez.
*      modify gt_fcat_ba from ls_fcat index sy-tabix.
*    endif.
  endloop.


* modify field settings
  loop at gt_fcat_ba into ls_fcat.

    ls_fcat-key     = space.
    ls_fcat-no_zero = 'X'.

    case ls_fcat-fieldname.
      when 'MARK'.
        ls_fcat-edit     = 'X'.
        ls_fcat-checkbox  = 'X'.
        ls_fcat-outputlen = 3.
        ls_fcat-emphasize = 'C200'.
        ls_fcat-col_pos   = 0.
        ls_fcat-coltext   = 'Pick'.
      when 'KALAB'.
        ls_fcat-qfieldname = 'MEINS'.
        ls_fcat-coltext =
        ls_fcat-tooltip =
        ls_fcat-seltext = 'Nominal Weight'.
      when 'APPM_GSM'.
        ls_fcat-coltext = 'GSM'.
      when 'TARE'.
        ls_fcat-coltext = 'Tare'.
      when 'AGE'.
        ls_fcat-coltext = 'Age'.
        ls_fcat-tooltip = 'Age in days'.
      when 'APPM_REEL_DIAMETER'.
        ls_fcat-coltext = 'Diameter'.
      when 'APPM_REEL_WIDTH'.
        ls_fcat-coltext = 'Size'.
    endcase.

    modify gt_fcat_ba from ls_fcat.
  endloop.

endform.  " BUILD_FIELDCAT_BA


*&---------------------------------------------------------------------*
*&      Form  BUILD_FIELDCAT_LI
*&---------------------------------------------------------------------*
*       Field catalog - delivery line items
*----------------------------------------------------------------------*
form build_fieldcat_li.

  data: ls_fcat  type lvc_s_fcat.

  perform build_fieldcatalog using 'GT_LI' gt_fcat_li[].

* modify field settings
  loop at gt_fcat_li into ls_fcat.

    ls_fcat-key     = space.
    ls_fcat-no_zero = 'X'.

    case ls_fcat-fieldname.
      when 'LFTOT'.
        ls_fcat-scrtext_s   = 'Picked'.
        ls_fcat-scrtext_m  =
        ls_fcat-coltext    =
        ls_fcat-tooltip    =
        ls_fcat-seltext    =
        ls_fcat-scrtext_l  = 'Picked for delivery'.
        ls_fcat-qfieldname = 'MEINS'.
      when 'LFDIF'.
        ls_fcat-scrtext_s  =
         ls_fcat-scrtext_m  =
         ls_fcat-coltext    =
         ls_fcat-tooltip    =
         ls_fcat-seltext    =
         ls_fcat-scrtext_l  = 'Difference'.
        ls_fcat-qfieldname = 'MEINS'.
      when 'LFOVR'.
        ls_fcat-scrtext_s  =
         ls_fcat-scrtext_m  =
         ls_fcat-coltext    =
         ls_fcat-tooltip    =
         ls_fcat-seltext    =
         ls_fcat-scrtext_l  = 'Overdelivery'.
        ls_fcat-qfieldname = 'MEINS'.
      when 'LFUND'.
        ls_fcat-scrtext_s  =
        ls_fcat-scrtext_m  =
        ls_fcat-coltext    =
        ls_fcat-tooltip    =
        ls_fcat-seltext    =
        ls_fcat-scrtext_l  = 'Underdelivery'.
        ls_fcat-qfieldname = 'MEINS'.
      when 'LFUNT'.
        ls_fcat-scrtext_s  = 'Under.Tol'.
        ls_fcat-scrtext_m  =
        ls_fcat-coltext    =
        ls_fcat-tooltip    =
        ls_fcat-seltext    =
        ls_fcat-scrtext_l  = 'Under.Tol.Quantity'.
        ls_fcat-qfieldname = 'MEINS'.
      when 'LFOVT'.
        ls_fcat-scrtext_s  = 'Over.Tol'.
        ls_fcat-scrtext_m  =
        ls_fcat-coltext    =
        ls_fcat-tooltip    =
        ls_fcat-seltext    =
        ls_fcat-scrtext_l  = 'Over.Tol.Quantity'.
        ls_fcat-qfieldname = 'MEINS'.
      when 'LFIMG1'.
        ls_fcat-qfieldname = 'VRKME'.
        ls_fcat-seltext    =
        ls_fcat-tooltip = ls_fcat-tooltip && '(Sales Unit)'.
      when 'LFIMG'.
        ls_fcat-qfieldname = 'MEINS'.
        ls_fcat-seltext    =
        ls_fcat-tooltip = ls_fcat-tooltip && '(Base Unit)'.
      when 'UEBTK'.
        ls_fcat-checkbox = 'X'.
      when 'ICON'.
        ls_fcat-coltext    = 'Icon'.
        ls_fcat-icon = 'X'.
      when 'COMMENT'.
        ls_fcat-scrtext_s  =
        ls_fcat-scrtext_m  =
        ls_fcat-coltext    =
        ls_fcat-tooltip    =
        ls_fcat-seltext    =
        ls_fcat-scrtext_l  = 'Comment'.
      when 'ERR'.
        delete gt_fcat_li.
        continue.
    endcase.

    modify gt_fcat_li from ls_fcat.
  endloop.


endform.  " BUILD_FIELDCAT_LI


*&---------------------------------------------------------------------*
*&      Form  build_fieldcatalog
*&---------------------------------------------------------------------*
*       Build field catalog for ALV
*----------------------------------------------------------------------*
form build_fieldcatalog using l_tabname   type c
                              lt_fieldcat1 type lvc_t_fcat .

  data: l_repid like sy-repid.
  data: lt_fieldcat  type kkblo_t_fieldcat.

  l_repid = sy-repid.

  "check lt_fieldcat1[] is initial.

  call function 'K_KKB_FIELDCAT_MERGE'
    exporting
      i_callback_program     = l_repid
      i_tabname              = l_tabname
      i_inclname             = l_repid
    changing
      ct_fieldcat            = lt_fieldcat[]
    exceptions
      inconsistent_interface = 1
      others                 = 2.

  check sy-subrc = 0.

  call function 'LVC_TRANSFER_FROM_KKBLO'
    exporting
      it_fieldcat_kkblo = lt_fieldcat[]
    importing
      et_fieldcat_lvc   = lt_fieldcat1[]
    exceptions
      others            = 1.

  check sy-subrc = 0.

endform.                    " build_fieldcatalog

*&---------------------------------------------------------------------*
*&      Form  INITIALIZATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form initialization .

  gs_variant_ba-report = sy-repid.
  gs_variant_ba-handle = 'BA'.
  gs_variant_li-report = sy-repid.
  gs_variant_li-handle = 'LI'.

  perform get_default_variant using gs_variant_ba p_var_ba g_vtx_ba.
  perform get_default_variant using gs_variant_li p_var_li g_vtx_li.

  select * from zbt_alter where progname = 'E10539'.
    case zbt_alter-fieldname.
      when 'VSTEL'.
        clear r_vstel.
        r_vstel-sign   = zbt_alter-sign.
        r_vstel-option = zbt_alter-opti.
        r_vstel-low    = zbt_alter-low.
        r_vstel-high   = zbt_alter-high.
        append r_vstel.
      when 'OUTPUTTYPE'.
        g_output_type = zbt_alter-low.
    endcase.
  endselect.

endform.

*&---------------------------------------------------------------------*
*&      Form  GET_MAKT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form get_makt .

  if makt-matnr <> gt_ba-matnr.
    clear makt.
    select single * from makt where matnr = gt_ba-matnr
                                and spras = sy-langu.
    if sy-subrc <> 0.
      select single * from makt where matnr = gt_ba-matnr
                                  and spras = 'E'.
    endif.
  endif.

  if mara-matnr <> gt_ba-matnr.
    select single * from mara where matnr = gt_ba-matnr.
  endif.
endform.


*&---------------------------------------------------------------------*
*&      Form  ISSUE_TO_ODB
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form issue_to_odb .

  data: l_kalab like mska-kalab.
  data: l_count type i.
  data: l_answer(1) type c.
  data: l_question(400) type c.
  data: l_text(20) type c.

  data: lt_data    type table of edi_dd40.
  data: ls_data    type edi_dd40.
  data: ls_e1vpdlh type e1vpdlh.
  data: ls_e1vpdli type e1vpdli.
  data: l_segnum   type edidd-segnum.

  data: ls_control type edi_dc40.
  data: l_docnum   type edidc-docnum.

  data: l_message(220) type c.
****

  ls_e1vpdlh-vbeln_vl = likp-vbeln.
  ls_e1vpdlh-vbeln    = likp-vbeln.
  ls_e1vpdlh-komue    = 'X'.

  clear ls_data.
  ls_data-segnam   = 'E1VPDLH'.
  add 1 to l_segnum.
  ls_data-segnum   = l_segnum.
  ls_data-sdata    = ls_e1vpdlh.
  append ls_data to lt_data.


  loop at gt_ba where mark = 'X'.
    add 1 to l_count.
    add gt_ba-kalab to l_kalab.

    clear gt_li.
    read table gt_li with key vbeln = gt_ba-vbeln
                              posnr = gt_ba-posnr.

    clear ls_e1vpdli.
    ls_e1vpdli-vbeln_vl = gt_ba-vbeln.
    ls_e1vpdli-posnr_vl = gt_ba-posnr.
    ls_e1vpdli-vbeln    = gt_ba-vbeln.
    ls_e1vpdli-posnn    = gt_ba-posnr.
    ls_e1vpdli-pikmg    = gt_ba-kalab.
    ls_e1vpdli-meins    = gt_ba-meins.
    ls_e1vpdli-ntgew    = gt_ba-appm_net_weight.
    ls_e1vpdli-brgew    = gt_ba-appm_gross_weight.
    ls_e1vpdli-gewei    = gt_li-gewei.
    ls_e1vpdli-charg    = gt_ba-charg.
    ls_e1vpdli-matnr    = gt_ba-matnr.

    clear ls_data.
    ls_data-segnam   = 'E1VPDLI'.
    add 1 to l_segnum.
    ls_data-segnum   = l_segnum.
    ls_data-sdata    = ls_e1vpdli.
    append ls_data to lt_data.

  endloop.
  if sy-subrc <> 0.
    message 'No batches selected for issue' type 'S'.
    return.
  endif.

  concatenate
  'Total number of units selected: &1. Total weight: &2 &3.'
  'Are you sure you have selected appropriate units?'
         into l_question separated by space.

  write l_count to l_text left-justified.
  replace '&1' with l_text into l_question.
  write l_kalab to l_text left-justified unit gt_ba-meins.
  replace '&2' with l_text into l_question.
  write gt_ba-meins to l_text left-justified.
  replace '&3' with l_text into l_question.
  condense l_question.

  call function 'POPUP_TO_CONFIRM'
    exporting
      text_question = l_question
    importing
      answer        = l_answer.

  check l_answer = '1'.


  ls_control-direct  = '2'.
  ls_control-mestyp  = 'SDPICK'.
  ls_control-idoctyp = 'SDPIID01'.
  ls_control-sndprt  = 'US'.
  ls_control-sndprn  = sy-sysid && 'CLNT' && sy-mandt.
  ls_control-sndpor  = 'TRFC'.
  ls_control-rcvprt  = 'US'.
  ls_control-rcvprn  = ls_control-sndprn.
*

  call function 'IDOC_INBOUND_SINGLE'
    exporting
      pi_idoc_control_rec_40        = ls_control
      pi_do_commit                  = 'X'
    importing
      pe_idoc_number                = l_docnum
    tables
      pt_idoc_data_records_40       = lt_data
    exceptions
      idoc_not_saved                = 1
      others                        = 2.

  if sy-subrc <> 0.
    message id sy-msgid type 'I' number sy-msgno
            with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
            display like 'E'.
  else.

    select single * from edidc where docnum = l_docnum.

    if sy-subrc = 0 and edidc-status = '53'.

      data: lt_deliv   type table of bapishpdelivnumb.
      data: ls_deliv   type bapishpdelivnumb.
      data: lt_output  type table of bapioutptype.
      data: ls_output  type bapioutptype.
      data: lt_message type table of bapimsgprot.
      data: lt_return  type table of bapiret2.
      data: ls_return  type bapiret2.

      ls_deliv-deliv_numb = likp-vbeln.
      append ls_deliv to lt_deliv.

      ls_output-output_type  = g_output_type.
      "   ls_output-trans_medium = '1'.
      append ls_output to lt_output.

      call function 'BAPI_LIKP_PROCESS_MSG_DIRECT'
        tables
          deliverynumber    = lt_deliv
          outputtype        = lt_output
          messageprotocol   = lt_message
          return            = lt_return.

      loop at lt_return into ls_return where type ca 'AE'.
        message id     ls_return-id
                type   'I'
                number ls_return-number
                with   ls_return-message_v1
                       ls_return-message_v2
                       ls_return-message_v3
                       ls_return-message_v4
                display like ls_return-type.
      endloop.

      message 'Delivery picked' type 'I'.
      perform unlock_delivery.
      set screen 0.
      leave screen.

    else.

      clear edids.
      select * from edids where docnum = edidc-docnum
                            and status = edidc-status.
      endselect.

      message id     edids-stamid
              type   'I'
              number edids-stamno
              with   edids-stapa1
                     edids-stapa2
                     edids-stapa3
                     edids-stapa4
              into l_message.

      concatenate 'Picking failed - ' l_message into l_message
                  separated by space.
      perform archive_idoc using edidc.
      message l_message type 'I' display like 'E'.

    endif.
  endif.

endform.

*&---------------------------------------------------------------------*
*&      Form  UPDATE_LI
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form update_li .

  data: lt_ba like sorted table of gt_ba
              with non-unique key vbeln1 posnr
              with header line.

  loop at gt_ba where mark = 'X'.
    insert gt_ba into table lt_ba.
  endloop.

  loop at gt_li where err-no_batch is initial.
    clear: gt_li-lftot,
           gt_li-lfdif,
           gt_li-lfovr,
           gt_li-lfund,
           gt_li-lfovt,
           gt_li-lfunt,
           gt_li-icon,
           gt_li-err-error,
           gt_li-comment.

    loop at lt_ba where vbeln1 = gt_li-vbeln1
                    and posnr = gt_li-posnr.
      add lt_ba-kalab to gt_li-lftot.
    endloop.

    if gt_li-err-conv is not initial.
      gt_li-err-error = 'X'.
      gt_li-icon = icon_led_red.
      gt_li-comment = 'UOM conversion error'.
    else.

      gt_li-lfdif = gt_li-lftot - gt_li-lfimg.
      if gt_li-lfdif = 0.
        gt_li-icon = icon_equal_green.
      else.
        gt_li-icon = icon_pattern_include_green.
        gt_li-comment = 'Within tolerance'.
      endif.

      if gt_li-uebtk is initial and gt_li-lfdif <> 0.
* check overdelivery
        gt_li-lfovt = gt_li-lfimg * gt_li-uebto / 100.
        if gt_li-lftot >  gt_li-lfimg + gt_li-lfovt.
          gt_li-lfovr = gt_li-lftot - gt_li-lfimg - gt_li-lfovt.
          gt_li-icon = icon_greater_red.
          gt_li-comment = 'Overdelivery'.
          gt_li-err-error = 'X'.
        endif.
* check underdelivery
        gt_li-lfunt = gt_li-lfimg * gt_li-untto / 100.
        if gt_li-lftot <  gt_li-lfimg - gt_li-lfunt.
          gt_li-lfund = gt_li-lfimg - gt_li-lftot - gt_li-lfunt.
          gt_li-icon = icon_less_red.
          gt_li-comment = 'Underdelivery'.
          gt_li-err-error = 'X'.
        endif.
      endif.
    endif.
    modify gt_li.
  endloop.

  if gr_li is bound.
    gr_li->refresh_table_display( exporting is_stable =  c_xx ).
  endif.

endform.

*&---------------------------------------------------------------------*
*&      Form  data_changed_finished_ba
*&---------------------------------------------------------------------*
*       data changed finished - batches
*----------------------------------------------------------------------*
form data_changed_finished_ba using l_modified type c.

  check l_modified = 'X'.
  perform update_li.

*  call function 'SAPGUI_SET_FUNCTIONCODE'
*    exceptions
*      function_not_supported = 1
*      others                 = 2.
*  check sy-subrc = 0.

endform.                    " data_changed_finished_ba

*&---------------------------------------------------------------------*
*&      Form  set_toolbar_ba
*&---------------------------------------------------------------------*
*       set the toolbar - batches
*----------------------------------------------------------------------*
form set_toolbar_ba using e_object  type ref to
                                             cl_alv_event_toolbar_set.

  data: ls_toolbar type stb_button.
  data: lt_filter	type lvc_t_filt.

  clear ls_toolbar.
  ls_toolbar-butn_type  = 3.
  append ls_toolbar to e_object->mt_toolbar.

  clear ls_toolbar.
  ls_toolbar-function  = 'PICK'.
  ls_toolbar-icon      = icon_checkbox.
  ls_toolbar-quickinfo = 'Pick selected'.
  append ls_toolbar to e_object->mt_toolbar.

  clear ls_toolbar.
  ls_toolbar-function  = 'UNPICK'.
  ls_toolbar-icon      = icon_wd_iframe.
  ls_toolbar-quickinfo = 'Unpick selected'.
  append ls_toolbar to e_object->mt_toolbar.


  clear ls_toolbar.
  ls_toolbar-butn_type  = 3.
  append ls_toolbar to e_object->mt_toolbar.

  gr_ba->get_filter_criteria( importing et_filter = lt_filter ).
  clear ls_toolbar.
  ls_toolbar-function  = 'FILTD'.
  ls_toolbar-icon      = icon_filter_undo.
  ls_toolbar-quickinfo = 'Remove batches filter'.
  read table lt_filter transporting no fields
            with key fieldname = 'POSNR'.
  if sy-subrc <> 0.
    ls_toolbar-disabled = 'X'.
  endif.
  append ls_toolbar to e_object->mt_toolbar.

endform.                    " set_toolbar_ba

*&---------------------------------------------------------------------*
*&      Form  set_toolbar_li
*&---------------------------------------------------------------------*
*       set the toolbar - line items
*----------------------------------------------------------------------*
form set_toolbar_li using e_object  type ref to
                                             cl_alv_event_toolbar_set.

  data: ls_toolbar type stb_button.

  clear ls_toolbar.
  ls_toolbar-butn_type  = 3.
  append ls_toolbar to e_object->mt_toolbar.

  clear ls_toolbar.
  ls_toolbar-function  = 'FILTER'.
  ls_toolbar-icon      = icon_filter.
  ls_toolbar-quickinfo = 'Filter batches to sel.items'.
  append ls_toolbar to e_object->mt_toolbar.

  clear ls_toolbar.
  ls_toolbar-function  = 'FILTD'.
  ls_toolbar-icon      = icon_filter_undo.
  ls_toolbar-quickinfo = 'Remove batches filter'.
  append ls_toolbar to e_object->mt_toolbar.

endform.                    " set_toolbar_li

*&---------------------------------------------------------------------*
*&      Form  user_command_toolbar_ba
*&---------------------------------------------------------------------*
*       Additional push-buttons - batches
*----------------------------------------------------------------------*
form user_command_toolbar_ba using e_ucomm like sy-ucomm.

  case e_ucomm.
    when 'PICK'.
      perform pick_selected using 'X'.
    when 'UNPICK'.
      perform pick_selected using ' '.
    when 'FILTD'.
      perform filter_delete.
  endcase.

  gr_ba->set_user_command( exporting i_ucomm = space ).

endform.                    " user_command_toolbar_ba

*&---------------------------------------------------------------------*
*&      Form  user_command_toolbar_li
*&---------------------------------------------------------------------*
*       Additional push-buttons - batches
*----------------------------------------------------------------------*
form user_command_toolbar_li using e_ucomm like sy-ucomm.

  gr_ba->check_changed_data( ).

  case e_ucomm.
    when 'FILTER'.
      perform set_filter.
    when 'FILTD'.
      perform filter_delete.
  endcase.

  gr_li->set_user_command( exporting i_ucomm = space ).

endform.                    " user_command_toolbar_li

*&---------------------------------------------------------------------*
*&      Form  PICK_SELECTED
*&---------------------------------------------------------------------*
*       Set checkbox on selected grid lines
*----------------------------------------------------------------------*
form pick_selected  using l_mark type c.

  data: lt_rows type lvc_t_roid.
  data: ls_rows type lvc_s_roid.

  gr_ba->get_selected_rows( importing et_row_no = lt_rows[] ).
  check lt_rows[] is not initial.

  loop at lt_rows into ls_rows.
    read table gt_ba index ls_rows-row_id.
    check sy-subrc = 0.
    gt_ba-mark = l_mark.
    modify gt_ba index ls_rows-row_id.
  endloop.

  gr_ba->refresh_table_display( exporting is_stable =  c_xx ).
  perform update_li.

endform.

*&---------------------------------------------------------------------*
*&      Form  USER_COMMAND_LI
*&---------------------------------------------------------------------*
*       User command - Line Items.
*       Set filter on batches
*----------------------------------------------------------------------*
form user_command_li using  l_row    type lvc_s_row
                            l_column type lvc_s_col.        "#EC NEEDED

  data: lt_rows type lvc_t_roid.
  data: ls_rows type lvc_s_roid.

  read table gt_li index l_row-index.
  check sy-subrc = 0.

  ls_rows-row_id = l_row-index.
  append ls_rows to lt_rows.
  perform filter_ba using lt_rows[].

endform.                    " USER_COMMAND_li

*&---------------------------------------------------------------------*
*&      Form  FILTER_DELETE
*&---------------------------------------------------------------------*
*       Delete ALV filter
*----------------------------------------------------------------------*
form filter_delete.

  data: lt_filter type lvc_t_filt.

  gr_ba->check_changed_data( ).
  gr_ba->get_filter_criteria( importing et_filter = lt_filter ).
  delete lt_filter where fieldname = 'POSNR'.

  gr_ba->set_filter_criteria( exporting it_filter = lt_filter[] ).
  gr_ba->refresh_table_display( ).

endform.                    " FILTER_DELETE

*&---------------------------------------------------------------------*
*&      Form  PICK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form pick .

  data: l_cursor type dynfnam.

  get cursor field l_cursor.

  case l_cursor.
    when 'LIKP-VBELN'.
      set parameter id 'VL' field likp-vbeln.
      call transaction 'VL03N' and skip first screen.
  endcase.

endform.

*&---------------------------------------------------------------------*
*&      Form  LOCK_DELIVERY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form lock_delivery using l_err type c.

  data: l_vbeln(10) type c.
  data: l_user  type symsgv.

  l_err = 'X'.

  call function 'ENQUEUE_EVVBLKE'
    exporting
      vbeln          = p_vbeln
    exceptions
      foreign_lock   = 2
      system_failure = 3.

  case sy-subrc.
    when 0.
      clear l_err.
    when 2.
      write p_vbeln to l_vbeln no-zero.
      write sy-msgv1 to l_user.
      message i046(vl) with l_vbeln l_user display like 'E'.
    when 3.
      message i047(vl) display like 'E'.
  endcase.

endform.

*&---------------------------------------------------------------------*
*&      Form  UNLOCK_DELIVERY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form unlock_delivery .

  call function 'DEQUEUE_EVVBLKE'
    exporting
      vbeln  = p_vbeln.

endform. "UNLOCK_DELIVERY


*&---------------------------------------------------------------------*
*&      Form  VALIDATE_INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form validate_input .

  data: l_message(220) type c.

  select single * from likp where vbeln = p_vbeln.
  if sy-subrc <> 0.
    message e559(vl) with p_vbeln.
  endif.

  if likp-vstel not in r_vstel.
    l_message = 'Shipping point &1 is not relevant for transaction.'.
    replace '&1' with likp-vstel into l_message.
    condense l_message.
    message l_message type 'E'.
  endif.

* User authorization for shipping point
  authority-check object 'V_LIKP_VST'
       id 'VSTEL' field likp-vstel
       id 'ACTVT' field '02'.

  if sy-subrc <> 0.
    message e081(vl) with likp-vstel.
  endif.

  select single * from vbuk where vbeln = p_vbeln.

  case vbuk-kostk.
    when 'B'.
      message 'Delivery partially picked. Check delivery' type 'E'.
    when 'C'.
      case vbuk-wbstk.
        when 'C'.
          message 'Delivery PGI’d. Check delivery' type 'E'.
        when 'A'.
          message 'Delivery picked, not PGI’d. Check delivery' type 'E'.
        when others.
          message 'Check delivery' type 'E'.
      endcase.
  endcase.


endform.

*&---------------------------------------------------------------------*
*&      Form  ARCHIVE_IDOC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form archive_idoc using ls_edidc type edidc .

  data: lt_stat type table of bdidocstat.
  data: ls_stat type bdidocstat.

  ls_stat-docnum = ls_edidc-docnum.
  ls_stat-status = '68'.
  ls_stat-msgty = 'I'.
  ls_stat-msgid = 'EA'.
  ls_stat-msgno = '120'.
  ls_stat-uname = sy-uname.
  ls_stat-repid = sy-repid.
  append ls_stat to lt_stat.

  call function 'IDOC_STATUS_WRITE_TO_DATABASE'
    exporting
      idoc_number               = ls_edidc-docnum
      idoc_opened_flag          = ' '
      no_dequeue_flag           = 'X'
    importing
      idoc_control              = ls_edidc
    tables
      idoc_status               = lt_stat
    exceptions
      idoc_foreign_lock         = 1
      idoc_not_found            = 2
      idoc_status_records_empty = 3
      idoc_status_invalid       = 4
      db_error                  = 5
      others                    = 6.

  if sy-subrc <> 0.
    message 'Error archiving IDoc' type 'I' display like 'E'.
  endif.
*
endform.                    " archive_idoc

*&---------------------------------------------------------------------*
*&      Form  SET_FILTER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form set_filter .

  data: lt_rows type lvc_t_roid.
  data: ls_rows type lvc_s_roid.

  gr_li->get_selected_rows( importing et_row_no = lt_rows[] ).
  if lt_rows[] is initial.
    gr_li->get_current_cell( importing es_row_no =  ls_rows ).
    if ls_rows-row_id is not initial.
      append ls_rows to lt_rows.
    endif.
  endif.

  perform filter_ba using lt_rows.

endform.

*&---------------------------------------------------------------------*
*&      Form  FILTER_BA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form filter_ba  using  lt_rows type lvc_t_roid.

  data: ls_rows    type lvc_s_roid.
  data: lt_filter   type lvc_t_filt.
  data: ls_filter   type lvc_s_filt.

  check lt_rows[] is not initial.

  gr_ba->check_changed_data( ).
  gr_ba->get_filter_criteria( importing et_filter = lt_filter ).
  delete lt_filter where fieldname = 'POSNR'.

  loop at lt_rows into ls_rows.
    read table gt_li index ls_rows-row_id.
    check sy-subrc = 0.
    clear ls_filter.
    ls_filter-fieldname = 'POSNR'.
    ls_filter-low       = gt_li-posnr.
    ls_filter-sign      = 'I'.
    ls_filter-option    = 'EQ'.
    append ls_filter to lt_filter.
  endloop.

  gr_ba->set_filter_criteria( exporting it_filter = lt_filter ).
  gr_ba->refresh_table_display( ).

endform.

*&---------------------------------------------------------------------*
*&      Form  GET_CHAR
*&---------------------------------------------------------------------*
*       Get characteristics definition
*----------------------------------------------------------------------*
form get_char .

  call function 'CLME_FEATURE_ATTR_OF_CLASS_ALL'
    exporting
      class       = 'APPM_SALES_REEL_1'
      classtype   = '023'
    tables
      tfeatures   = gt_char
    exceptions
      others      = 1.

  check sy-subrc = 0.

endform.

FUNCTION-POOL zsd_dl_alerts MESSAGE-ID ZSD_DL.

TABLES: zzproddoc,
        zzcontact.

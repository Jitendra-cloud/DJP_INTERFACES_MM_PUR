************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2006                                     **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: Determine Mean of Transport-    Create Date: 07/13/2006*
*               for MoT Shift changes                                  *
*                                                                      *
* Inventory code: U01249                                               *
*                                                                      *
* SAP Name    : LZDL_U01249F01                  Version    : V2        *
*                                                                      *
* Programmer  : Sreekanth Devis                 Last Update:           *
*                                                                      *
*______________________________________________________________________*
* Description :All subroutines included in this included. These will be*
*              called from function module                             *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
*                                                                      *
* ADHUMBA             07/24/2007        change to pull the Shipping    *
*                                       condition on an STO from the   *
*                                       Sales Order Line Item instead  *
*                                       of Sales Order header Item.    *
*                                                                      *
************************************************************************
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
***INCLUDE LZDL_U01249F01 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  applog_open
*&---------------------------------------------------------------------*
*       Open an application log                                        *
*----------------------------------------------------------------------*
FORM applog_open .

  gs_log-alprog    = sy-repid.
  gs_log-aluser    = sy-uname.
  gs_log-object    = gc_object.    "ZDL_INTERFACE
  gs_log-subobject = gc_subobject. "ZMOT_SHIPCOND
  gs_log-extnumber = sy-title.

*// Create the logging object
  TRY.
      CREATE OBJECT go_applog
        EXPORTING
          is_log = gs_log.

    CATCH zcx_ca_applog_init_failure .
  ENDTRY.

ENDFORM.                    " applog_open

*&---------------------------------------------------------------------*
*&      Form  GET_MTO_SHIPPING_CONDITION
*&---------------------------------------------------------------------*
*  Make to Order Export(MTO).
*----------------------------------------------------------------------*
FORM get_mto_shipping_condition TABLES p_tx_output STRUCTURE cifpuorout
                                       p_tx_input  STRUCTURE cifpuorout
                           p_tx_mto_shipcond STRUCTURE zdl_mto_shipcond.


  DATA : lv_vsbed_message TYPE string,
         lv_bookdoc_message TYPE string,
         lv_container_message TYPE string,
         lv_trunc_zero(1) TYPE c VALUE '0',
         lv_mat_message TYPE string,
         lv_loc_message TYPE string,
         lv_tabix LIKE sy-tabix,
         lv_log_write.

  DATA: BEGIN OF lt_supply_drivn_log OCCURS 0,
*          message(500),
          mat_message TYPE string,
          loc_message TYPE string,
          sto_message TYPE string,
          tbl_message TYPE string,
        END OF lt_supply_drivn_log.

  DATA: BEGIN OF lt_mto_data OCCURS 0,
          matnr LIKE mara-matnr,
          plant LIKE p_tx_input-plant,
          vbeln LIKE p_tx_mto_shipcond-zz_vbeln,
          posnr LIKE p_tx_mto_shipcond-zz_posnr,
        END OF lt_mto_data.

  DATA: BEGIN OF lt_mara OCCURS 0,
          matnr LIKE mara-matnr,
          matkl LIKE mara-matkl,
        END OF lt_mara.

*** 07/24/2007 Start of changes by Anand Dhumbala
*  DATA: BEGIN OF lt_vbak OCCURS 0,
*          vbeln LIKE vbak-vbeln,
*          vsbed LIKE vbak-vsbed,
*        END OF lt_vbak.
*** 07/24/2007 End of changes by Anand Dhumbala

  DATA: BEGIN OF lt_vbap OCCURS 0,
          vbeln LIKE vbap-vbeln,
          posnr LIKE vbap-posnr,
          zzbookdoc LIKE vbap-zzbookdoc,
          zzvsbed LIKE vbap-zzvsbed,
        END OF lt_vbap.

*-- Clear the global, local variables and internal table
  CLEAR   gt_zsd_book_cntnrs.
* Please DO NOT SORT the following table as this will be used in memory
* transfers.
  LOOP AT p_tx_output.
    lv_tabix = sy-tabix.
    READ TABLE p_tx_input INDEX lv_tabix.
    IF sy-subrc = 0.
*-- Since the Material number coming from APO would be of 40 Characters
*-- we will have to convert it to 18 Characters for passing it to
*-- MARA-MATNR.
      SHIFT p_tx_input-material LEFT DELETING LEADING lv_trunc_zero.
*-- Get correct Material number format using CONVERSION_EXIT_MATN2_INPUT
      CALL FUNCTION 'CONVERSION_EXIT_MATN2_INPUT'
        EXPORTING
          input            = p_tx_input-material
        IMPORTING
          output           = lt_mto_data-matnr
        EXCEPTIONS
          number_not_found = 1
          length_error     = 2
          OTHERS           = 3.

      IF sy-subrc EQ 0.

        lt_mto_data-plant = p_tx_input-plant.
*-- SPEC_STOCK field would hold Sales Order/Item.  The first 10
*-- characters would hold sales order and the next 6 characters would
*-- hold item number.
        lt_mto_data-vbeln =  p_tx_output-spec_stock(10).
        lt_mto_data-posnr =  p_tx_output-spec_stock+10(6).
* Please DO NOT SORT the following table as this will be used in memory
* transfers.
        APPEND lt_mto_data.
        CLEAR lt_mto_data.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF NOT lt_mto_data[] IS INITIAL.
*-- Pass lt_mto_data-matnr to Database table MARA and retrieve
*-- the Material group
    SELECT matnr matkl
                 INTO TABLE lt_mara
                  FROM mara
                  FOR ALL ENTRIES IN lt_mto_data
                  WHERE matnr = lt_mto_data-matnr.

*** 07/24/2007 Start of changes by Anand Dhumbala
*-- Pass the Sales order to Database table VBAK and get the Shipping
*-- Condition VBAK-VSBED.
*    SELECT vbeln vsbed
*           INTO TABLE lt_vbak
*           FROM vbak
*           FOR ALL ENTRIES IN lt_mto_data
*           WHERE vbeln = lt_mto_data-vbeln.

    SELECT vbeln posnr zzbookdoc zzvsbed
*** 07/24/2007 End of changes by Anand Dhumbala
                 INTO TABLE lt_vbap
                    FROM vbap
                    FOR ALL ENTRIES IN lt_mto_data
                     WHERE vbeln = lt_mto_data-vbeln
                       AND posnr = lt_mto_data-posnr.

    SORT lt_mara BY matnr.
*** 07/24/2007 Start of changes by Anand Dhumbala
*    SORT lt_vbak BY vbeln.
*** 07/24/2007 End of changes by Anand Dhumbala
    SORT lt_vbap BY vbeln posnr.
  ENDIF.


  LOOP AT lt_mto_data.
* Memory table being populated below with Sales Order/Item data.
    p_tx_mto_shipcond-zz_vbeln =  lt_mto_data-vbeln.
    p_tx_mto_shipcond-zz_posnr =  lt_mto_data-posnr.


    READ TABLE lt_mara WITH KEY matnr = lt_mto_data-matnr
                                        BINARY SEARCH.
    IF sy-subrc = 0.
*-- Pass Material group and Plant to get Shipping Condition transfer
*-- flag from table ZDL_SUPPLY_DRIVN. Check to see if GV_SUP_DRIVN flag
*-- is equals to 'Y', If YES, proceed further otherwise write into
*-- Appliction log
      SELECT SINGLE zsto_sc_trf INTO gv_sup_drivn
             FROM zdl_supply_drivn
             WHERE matkl = lt_mara-matkl
               AND locno = lt_mto_data-plant.
      IF gv_sup_drivn = gc_yes.            "'Y'.
* Since we want to write information to Application log ONLY IF at least
* one record is found in the Supply Driven Table, we mark the following
* flag LV_LOG_WRITE and check it later.
        lv_log_write = gc_yes.                        "'Y'.
*** 07/24/2007 Start of changes by Anand Dhumbala
*        READ TABLE lt_vbak WITH KEY vbeln = lt_mto_data-vbeln
*** 07/24/2007 End of changes by Anand Dhumbala
        READ TABLE lt_vbap WITH KEY vbeln = lt_mto_data-vbeln
                                    posnr = lt_mto_data-posnr
                                            BINARY SEARCH.
*-- If it contains a value proceed futher otherwise write to Application
*-- Log and continue with the next record.
        IF sy-subrc = 0.
*-- Pass GV_VSBED to ZSTOSHIPCOND-ZSALESVSBED and retrieve
*-- ZSTOPSHIPCOND-ZSTOVSBED. If no record is found write to the
*-- application log and proceed further
          SELECT SINGLE zstovsbed INTO gv_zstovsbed
                   FROM zstoshipcond
*** 07/24/2007 Start of changes by Anand Dhumbala
*                   WHERE zsalesvsbed = lt_vbak-vsbed.
*** 07/24/2007 End of changes by Anand Dhumbala
                   WHERE zsalesvsbed = lt_vbap-zzvsbed.
          IF sy-subrc EQ 0.
*-- Check to see if ZSTOSHIPCOND-ZSTOVSBED relates to a container(CX),
*-- If not then return the value to P_EX_ZSHIP_COND
            IF gv_zstovsbed <> gc_ship_cond_container.        "'CX'.
              p_tx_mto_shipcond-zz_vsbed = gv_zstovsbed.      "'CX'.
            ELSE.
*-- if gv_zstovsbed = 'CX' then we will have to determine the shipping
*-- condition based on the booking information.
*-- Pass the sales order and item to database table VBAP and get
*-- VBAP-ZZBOOKDOC.  If no record found, write to the Application Log.
              READ TABLE lt_vbap WITH KEY vbeln = lt_mto_data-vbeln
                                          posnr = lt_mto_data-posnr
                                          BINARY SEARCH.
*-- If record is found pass GV_ZZBOOKDOC to database table
*-- ZSD_BOOK_CNTNRS and get the Container size. If more than one record
*-- is found then check to see if the Container size is same,if they are
*-- different use 'TL' as the shipping condition and there is no need to
*-- access ZZXREFDETAIL. If no record is found in ZSD_BOOK_CNTNRS, write
*-- to application log.
              IF sy-subrc EQ 0.
                SELECT con_size bookdoc
                         FROM zsd_book_cntnrs
                         INTO TABLE gt_zsd_book_cntnrs
                         WHERE bookdoc = lt_vbap-zzbookdoc.
                IF sy-subrc EQ 0.
*-- Check for number of records in internal table, if it is more than
*-- one record then check to see if the Container size is same,
*-- if they are different use VBAK-VSBED as the shipping condition.
                  SORT gt_zsd_book_cntnrs BY con_size.
                  DELETE ADJACENT DUPLICATES FROM gt_zsd_book_cntnrs
                                             COMPARING con_size.
                  DESCRIBE TABLE gt_zsd_book_cntnrs LINES gv_count.
                  IF gv_count GT 1.
*** 07/24/2007 Start of changes by Anand Dhumbala
*                    p_tx_mto_shipcond-zz_vsbed = lt_vbak-vsbed.
*** 07/24/2007 End of changes by Anand Dhumbala
                    p_tx_mto_shipcond-zz_vsbed = lt_vbap-zzvsbed.
                  ELSE.
* If the Book Containers has more than one record but if all the
* container sizes are same then we do not pass VBAK-VSBED we will have
* to determine the Shipping Condition from ZZXREFDETAIL table.
                    READ TABLE gt_zsd_book_cntnrs INDEX 1.
                    IF sy-subrc = 0.
                      gv_container_size = gt_zsd_book_cntnrs-con_size.
                      PERFORM get_shipcond_zzxrefdetail
                                          USING gv_container_size
                                                'CONT_SHIPCOND'
                                  CHANGING p_tx_mto_shipcond-zz_vsbed.
*-- If no value is returned then write the application log.
*-- Application log message 'Container' not found in ZZXREFDETAIL for
*-- ZZGROUP = 'DELIVER' and ZZGROUPSET = 'CONT_SHIPCOND'
                      IF p_tx_mto_shipcond-zz_vsbed IS INITIAL.
*** 07/24/2007 Start of changes by Anand Dhumbala
*                        p_tx_mto_shipcond-zz_vsbed = lt_vbak-vsbed.
*** 07/24/2007 End of changes by Anand Dhumbala
                        p_tx_mto_shipcond-zz_vsbed = lt_vbap-zzvsbed.
                       CONCATENATE text-e13 gt_zsd_book_cntnrs-con_size
                       INTO lv_container_message SEPARATED BY space.
                        MESSAGE e000(zsd_dl) WITH lv_container_message
                                                  text-e14
                                                  text-e15
                                                  text-e16
                                             INTO gv_message.
                        PERFORM applog_msgs_add.
                      ENDIF.
                    ENDIF.
                  ENDIF.
                ELSE.
*-- Pass Sales Order Shipping Condition and log the following message
*-- Application log message "Booking Document# lt_vbap-zzbookdoc not
*-- maintained in table ZSD_BOOK_CNTNRS.
                  MESSAGE e000(zsd_dl) WITH text-e11
                                            lt_vbap-zzbookdoc
                                            text-e12
                                            space
                                       INTO gv_message.
                  PERFORM applog_msgs_add.
                ENDIF.
              ELSE.
*-- Application log message - "Booking document not maintained
*-- in table VBAP for Sales Order# and Item#"
                CONCATENATE text-e07 lt_mto_data-vbeln
                           INTO lv_bookdoc_message SEPARATED BY space.
                MESSAGE e000(zsd_dl) WITH text-e09
                                          lv_bookdoc_message
                                          text-e10
                                          lt_mto_data-posnr
                                          INTO gv_message.
                PERFORM applog_msgs_add.
              ENDIF.
            ENDIF.
          ELSE.
*-- Application log Message "STO Shipping condition not maintained in
*-- ZSTOSHIPCOND for Sales Order# and Sales order Shipping Condition"
*            CONCATENATE text-e07 lt_vbak-vbeln
            CONCATENATE text-e07 lt_vbap-vbeln '/' lt_vbap-posnr
                        INTO lv_vsbed_message SEPARATED BY space.
            MESSAGE e000(zsd_dl) WITH text-e06
                                      lv_vsbed_message
                                      text-e08
*** 07/24/2007 Start of changes by Anand Dhumbala
*                                      lt_vbak-vsbed
*** 07/24/2007 End of changes by Anand Dhumbala
                                      lt_vbap-zzvsbed
                                      INTO gv_message.
            PERFORM applog_msgs_add.
          ENDIF.
        ENDIF.
      ELSE.
*-- Application log Message "For Material Group: lt_mara-matkl
*-- Source Location:lt_mto_data-plant STO Shipping condition transfer
*-- flag not maintained in ZDL_SUPPLY_DRIVN table.
        CONCATENATE text-e17 lt_mara-matkl INTO lv_mat_message
                            SEPARATED BY space.
        CONCATENATE text-e18 lt_mto_data-plant INTO lv_loc_message
                            SEPARATED BY space.

        lt_supply_drivn_log-mat_message = lv_mat_message.
        lt_supply_drivn_log-loc_message = lv_loc_message.
        lt_supply_drivn_log-sto_message = text-e19.
        lt_supply_drivn_log-tbl_message = text-e20.
        APPEND lt_supply_drivn_log.
        CLEAR lt_supply_drivn_log.
      ENDIF.
    ENDIF.
* Please DO NOT SORT the following table as this will be used in memory
* transfers.
    APPEND p_tx_mto_shipcond.
    CLEAR p_tx_mto_shipcond.
  ENDLOOP.

* Writing to Application if atleast one record was found in Supply
* Driven Table
  IF lv_log_write = gc_yes.                            "'Y'.
    LOOP AT lt_supply_drivn_log.
      MESSAGE e000(zsd_dl) WITH lt_supply_drivn_log-mat_message
                                lt_supply_drivn_log-loc_message
                                lt_supply_drivn_log-sto_message
                                lt_supply_drivn_log-tbl_message
                           INTO gv_message.
      PERFORM applog_msgs_add.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " GET_MTO_SHIPPING_CONDITION
*&---------------------------------------------------------------------*
*&      Form  GET_MTS_SHIPPING_CONDITION
*&---------------------------------------------------------------------*
*   To Get Shipping condition for MTS, Pass input values for fields
*   zzgroup, zzgroupset, zzkey1 to the table ZZXREFDETAIL.
*----------------------------------------------------------------------*

FORM get_mts_shipping_condition
                            USING  p_tx_extensionin STRUCTURE cifbparex
                            CHANGING p_ex_zship_cond TYPE vbak-vsbed.

  DATA: lv_groupmsg(50) TYPE c,
        lv_zzkeymsg(50) TYPE c.

  PERFORM get_shipcond_zzxrefdetail USING p_tx_extensionin-valuepart1
                                          'MOT_SHIPCOND'
                                    CHANGING p_ex_zship_cond.
*-- If Shipping Condition is not found write to Application log
  IF p_ex_zship_cond IS INITIAL.
    CONCATENATE text-e02 zzxrefdetail-zzgroup
                text-e03 zzxrefdetail-zzgroupset
                         INTO lv_groupmsg
                         SEPARATED BY space.
    CONCATENATE text-e04 zzxrefdetail-zzkey1
                         INTO  lv_zzkeymsg
                         SEPARATED BY space.
    MESSAGE e000(zsd_dl) WITH text-e01
                              lv_groupmsg
                              lv_zzkeymsg
                              text-e05
                              INTO gv_message.
    PERFORM applog_msgs_add.
  ENDIF.
ENDFORM.                    " GET_MTS_SHIPPING_CONDITION

*&---------------------------------------------------------------------*
*&      Form  applog_msgs_add
*&---------------------------------------------------------------------*
*  Adds a message to App log that has been stored in the SYST variable
*----------------------------------------------------------------------*
FORM applog_msgs_add.

  go_applog->handle_message( ).

ENDFORM.                    " applog_msgs_add
*&---------------------------------------------------------------------*
*&      Form  applog_close
*&---------------------------------------------------------------------*
*   Closes the log and saves the log information to the DB
*----------------------------------------------------------------------*
FORM applog_close .

*// Save the Logging
  TRY.
      go_applog->log_save( ).
    CATCH zcx_ca_applog_log_not_found .
      RETURN.
    CATCH zcx_ca_applog .
      RETURN.
  ENDTRY.
ENDFORM.                    " applog_close

*&---------------------------------------------------------------------*
*&      Form get_shipcond_zzxrefdetail
*&---------------------------------------------------------------------*
*   Get shipping condition from ZZXREFDETAIL table. Retrieve shipping
*   condition from field ZZXREFDETAIL-ZZVALUE1 and move to
*   p_l_ex_zship_cond.
*----------------------------------------------------------------------*
FORM get_shipcond_zzxrefdetail USING p_gv_value TYPE any
                                     p_zzgroupset TYPE any
                             CHANGING p_l_ex_zship_cond TYPE vbak-vsbed.

  SELECT SINGLE * FROM zzxrefdetail
                WHERE zzgroup = 'DELIVER'
                  AND zzgroupset = p_zzgroupset
                  AND zzkey1 = p_gv_value.

  IF sy-subrc EQ 0.
    p_l_ex_zship_cond = zzxrefdetail-zzvalue1.
  ENDIF.

ENDFORM.                    "get_shipcond_zzxrefdetail

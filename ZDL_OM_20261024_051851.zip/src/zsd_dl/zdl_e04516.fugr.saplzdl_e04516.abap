*---------------------------------------------------------------------*
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E04516TOP.                    " Global Data
  INCLUDE LZDL_E04516UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E04516F...                    " Subprograms
* INCLUDE LZDL_E04516O...                    " PBO-Modules
* INCLUDE LZDL_E04516I...                    " PAI-Modules

*INCLUDE LZDL_E04516F01.

INCLUDE LZDL_E04516F02.

INCLUDE LZDL_E04516F01.

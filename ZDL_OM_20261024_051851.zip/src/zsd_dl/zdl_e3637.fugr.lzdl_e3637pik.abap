*&---------------------------------------------------------------------*
*&  Include           LZDL_E3637PIK                                    *
*&---------------------------------------------------------------------*
*** Added 10/12/06 by Randall Wainwright - RWAINW1
* 10/16/06 - Savithri Renganathan - fine tuning
*----------------------------------------------------------------------*

************************************************************************
************ ZDL_E3637_PICK_PACK SUBROUTINES ***************************
************************************************************************
* The picking function module needs inbound IDoc that contains
* information about outbound delivery for which pick has to be
* done.  So build an inbound SDPICK IDoc.
************************************************************************
*&---------------------------------------------------------------------*
*&      Form  pp_build_picking_header_seg
*&---------------------------------------------------------------------*
*       Builds the Picking IDoc header segment
*----------------------------------------------------------------------*
FORM pp_build_picking_header_seg
                  TABLES  ct_idoc_data40 STRUCTURE edi_dd40
                   USING  uv_out_dlvry   TYPE      vbeln_vl
                          us_inb_likp    LIKE      likp
                CHANGING  cs_idoc_ctrl40 TYPE      edi_dc40.

  CONSTANTS:
    lc_e1vpdlh TYPE  edilsegtyp  VALUE  'E1VPDLH'.  "Picking hdr

  DATA:
    ls_e1vpdlh     TYPE  e1vpdlh,    "Picking Header
    ls_idoc_data40 TYPE  edi_dd40.   "edidd

  CLEAR:
    cs_idoc_ctrl40,  "Control record
    ls_idoc_data40,  "Data record
    ls_e1vpdlh.      "Picking header segment

  REFRESH    ct_idoc_data40[].    "IDoc data table

* Build Control Record SDPIID01
  CLEAR: cs_idoc_ctrl40.
  cs_idoc_ctrl40-direct   = '2'.         "Direction -inbound
  cs_idoc_ctrl40-mestyp   = 'SDPICK'.
  cs_idoc_ctrl40-idoctyp  = 'SDPIID01'.
  cs_idoc_ctrl40-rcvprt   = 'US'.
  cs_idoc_ctrl40-rcvpfc   = '3P'.        "Receiver Partner function
  CONCATENATE sy-sysid
              'CLNT'
              sy-mandt INTO cs_idoc_ctrl40-rcvprn. "Receiver

  cs_idoc_ctrl40-sndpor = 'TRFC'.
  cs_idoc_ctrl40-sndprt = 'US'.
  cs_idoc_ctrl40-sndprn = cs_idoc_ctrl40-rcvprn.

* Build Picking Header Segment
  gv_segnum = 1.

* Picking the Outbound Delivery...
  ls_e1vpdlh-vbeln_vl   = uv_out_dlvry. "Outbound Delivery
  ls_e1vpdlh-vbeln      = uv_out_dlvry. "Outbound Delivery

* ...Using the Inbound Delivery Data
  ls_e1vpdlh-tanum      = '0000000000'.
  ls_e1vpdlh-kodat      = us_inb_likp-kodat.
  ls_e1vpdlh-kouhr      = us_inb_likp-kouhr.
  ls_e1vpdlh-komue      = gc_true.  "set pick qty
  ls_e1vpdlh-wabuc      = space.    "PGI
  ls_e1vpdlh-wadat_ist  = us_inb_likp-wadat_ist.

  ls_idoc_data40-segnam = lc_e1vpdlh.  "segment name E1VPDLH
  ls_idoc_data40-segnum = gv_segnum.
  ls_idoc_data40-sdata  = ls_e1vpdlh.
  APPEND ls_idoc_data40 TO ct_idoc_data40.

ENDFORM.                    " build_picking_header_seg

*&---------------------------------------------------------------------*
*&      FORM pp_build_picking_item_seg
*&---------------------------------------------------------------------*
*       Builds the Picking IDoc item segment
*----------------------------------------------------------------------*
FORM pp_build_picking_item_seg
            TABLES ct_idoc_data40 STRUCTURE edi_dd40
             USING uv_outb_vbeln  LIKE      lips-vbeln  "Out.dlvry
                   uv_outb_posnr  LIKE      lips-posnr  "Out.dlvry item
                   us_inb_lips    LIKE      lips.  "Inbound dlvry info

  CONSTANTS:
    lc_e1vpdli TYPE  edilsegtyp  VALUE  'E1VPDLI'.  "Picking item

  DATA:
    ls_idoc_data40 TYPE edi_dd40, "edidd
* Segments referenced in SDPIID01 for picking
    ls_e1vpdli     TYPE  e1vpdli. "Picking Item

  CLEAR: ls_e1vpdli.  "Picking item segment

* Build Picking Item Segment
  gv_segnum = gv_segnum + 1.

* Picking the Outbound Delivery...
  ls_e1vpdli-vbeln_vl   = uv_outb_vbeln. "Outbound delivery
  ls_e1vpdli-vbeln      = uv_outb_vbeln. "Outbound delivery

  ls_e1vpdli-posnr_vl = uv_outb_posnr. "Outbound Delivery item
  ls_e1vpdli-posnn    = uv_outb_posnr. "Outbound Delivery item

* ...Using the Inbound Delivery Data
  ls_e1vpdli-pikmg    = us_inb_lips-lfimg.
  ls_e1vpdli-meins    = us_inb_lips-meins.
  ls_e1vpdli-brgew    = us_inb_lips-brgew.
  ls_e1vpdli-ntgew    = us_inb_lips-ntgew.
  ls_e1vpdli-charg    = us_inb_lips-charg.
  ls_e1vpdli-matnr    = us_inb_lips-matnr.
  ls_e1vpdli-orpos    = '000000'.    "Set this one to 000000

****Begin of changes pragup1 12/06/2011
**** To roll up the weights from line item to the header
  ls_e1vpdli-gewei = us_inb_lips-meins.
****End of changes pragup1 12/06/2011

  ls_idoc_data40-segnam = lc_e1vpdli.  "segment name E1VPDLI
  ls_idoc_data40-segnum = gv_segnum.
  ls_idoc_data40-sdata  = ls_e1vpdli.
  APPEND ls_idoc_data40 TO ct_idoc_data40.

ENDFORM.                    " build_picking_item_seg

*&---------------------------------------------------------------------*
*&      Form  pp_pick_outbound_delivery
*&---------------------------------------------------------------------*
* Pick the outbound delivery - all information about the outbound
* delivery are in the form of IDoc - the function module
* IDOC_INBOUND_SINGLE is used to pick the outbound delivery
*----------------------------------------------------------------------*
FORM pp_pick_outbound_delivery
        USING uv_outb_dlvry  LIKE lips-vbeln
              us_idoc_ctrl40 TYPE edi_dc40
     CHANGING ct_messages    TYPE zca_bal_msg_tab.

  DATA:
    lv_locked(1),     " = 'X' If the delivery is locked
    ls_messages  TYPE bal_s_msg,
    lv_credat    TYPE edi_ccrdat,  "idoc creation date
    lv_cretim    TYPE edi_ccrtim,  "idoc creation time
    lv_status    TYPE edi_status,  "idoc status
    lv_stamid    TYPE edi_stamid,  "msg id from EDIDS
    lv_stamno    TYPE edi_stamno,  "msg no from EDIDS
    lv_stapa1    TYPE edi_stapa1,  "msg parm 1 from EDIDS
    lv_stapa2    TYPE edi_stapa2,  "msg parm 2 from EDIDS
    lv_stapa3    TYPE edi_stapa3,  "msg parm 3 from EDIDS
    lv_stapa4    TYPE edi_stapa4.  "msg parm 4 from EDIDS

* Need to ensure the Delivery is not locked
  PERFORM pp_check_delivery_lock
              USING uv_outb_dlvry
           CHANGING lv_locked.

  IF NOT lv_locked IS INITIAL.
* Move into an internal table and post into application log later
* Unable to lock delivery & for update
    ls_messages-msgty  = gc_error.
    ls_messages-msgid  = gc_msgid.
    ls_messages-msgno  = '055'.
    ls_messages-msgv1  = uv_outb_dlvry.
    ls_messages-msgv2  = space.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO ct_messages.
    CLEAR  ls_messages.
    RETURN.
  ENDIF. " NOT l_locked is initial.

* Create SDPIID01 Inbound Picking Idoc against the Outbound Delivery
  CLEAR: gv_idoc_num.
  CALL FUNCTION 'IDOC_INBOUND_SINGLE'
    EXPORTING
      pi_idoc_control_rec_40        = us_idoc_ctrl40
      pi_do_commit                  = gc_true
    IMPORTING
      pe_idoc_number                = gv_idoc_num
      pe_error_prior_to_application = gv_error_app
    TABLES
      pt_idoc_data_records_40       = gt_idoc_data40
    EXCEPTIONS
      idoc_not_saved                = 1
      OTHERS                        = 2.

  IF sy-subrc <> 0 OR gv_error_app = gc_true.
* Move into an internal table and post into application log later
* "Picking idoc & of Outbound Delivery & in error status"
    ls_messages-msgty  = gc_error.
    ls_messages-msgid  = gc_msgid.
    ls_messages-msgno  = '180'.
    ls_messages-msgv1  = gv_idoc_num.
    ls_messages-msgv2  = uv_outb_dlvry.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO ct_messages.
    CLEAR  ls_messages.
    RETURN. "leave subroutine
  ELSE.

*   Determine idoc status
    SELECT SINGLE credat
                  cretim
                  status
     INTO (lv_credat,
           lv_cretim,
           lv_status)
     FROM edidc
     WHERE docnum = gv_idoc_num.

    IF NOT ( lv_status = '52' OR
             lv_status = '53' ).

* Move into an internal table and post into application log later
* "Picking idoc & of Outbound Delivery & in error status"
      ls_messages-msgty  = gc_error.
      ls_messages-msgid  = gc_msgid.
      ls_messages-msgno  = '180'.
      ls_messages-msgv1  = gv_idoc_num.
      ls_messages-msgv2  = uv_outb_dlvry.
      ls_messages-msgv3  = space.
      ls_messages-msgv4  = space.
      APPEND ls_messages TO ct_messages.
      CLEAR  ls_messages.

* Retrieve the actual status msg for the idoc not in status 52 or 53
      SELECT stamid  "msg id
             stamno  "msg no
             stapa1                                         "msgv1
             stapa2                                         "msgv2
             stapa3                                         "msgv3
             stapa4                                         "msgv4
        UP TO 1 ROWS
        INTO (lv_stamid,
              lv_stamno,
              lv_stapa1,
              lv_stapa2,
              lv_stapa3,
              lv_stapa4)
        FROM edids
        WHERE docnum =  gv_idoc_num
         AND  logdat =  lv_credat   "edidc-credat
         AND  logtim >= lv_cretim   "edidc-cretim
         AND  status =  lv_status   "edidc-status
         AND  statyp =  gc_error.   "Error message
      ENDSELECT.

* Move into an internal table and post into application log later
      ls_messages-msgty  = gc_error.
      ls_messages-msgid  = lv_stamid.
      ls_messages-msgno  = lv_stamno.
      ls_messages-msgv1  = lv_stapa1.
      ls_messages-msgv2  = lv_stapa2.
      ls_messages-msgv3  = lv_stapa3.
      ls_messages-msgv4  = lv_stapa4.
      APPEND ls_messages TO ct_messages.
      CLEAR  ls_messages.

      RETURN. "leave subroutine

    ENDIF.

  ENDIF.

ENDFORM.                    " pick_outbound_delivery

*&---------------------------------------------------------------------*
*&      Form  pp_check_delivery_lock
*&---------------------------------------------------------------------*
*   Checks the lock status of a delivery, returning a flag
*   response in cv_locked ('X') when attempts to lock the delivery fail.
*----------------------------------------------------------------------*
FORM pp_check_delivery_lock
              USING uv_vbeln   LIKE likp-vbeln   "Outbound delivery
           CHANGING cv_locked  TYPE char1.  "lock status

  DATA:
    lv_subrc TYPE sysubrc VALUE 4.

  CLEAR cv_locked.

* Attempt to lock the batch to make sure it is not already locked
  DO 20 TIMES.
    CALL FUNCTION 'ENQUEUE_EVVBLKE'
      EXPORTING
        mode_likp      = gc_error
        mandt          = sy-mandt
        vbeln          = uv_vbeln
        _scope         = '2'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.

    IF sy-subrc = 0.
      lv_subrc = sy-subrc.
      EXIT.
    ELSE.
      WAIT UP TO 3 SECONDS.
    ENDIF.
  ENDDO.

  IF lv_subrc = 0.
*   Unlock the delivery
    CALL FUNCTION 'DEQUEUE_EVVBLKE'
      EXPORTING
        mode_likp = gc_error
        mandt     = sy-mandt
        vbeln     = uv_vbeln
        _scope    = '3'.
  ELSE.
    cv_locked = gc_true.
  ENDIF.

ENDFORM.                    " check_delivery_lock

*&---------------------------------------------------------------------*
*&      Form  pp_assign_hu_to_delivery
*&---------------------------------------------------------------------*
* Update Outbound delivery with Inbound Delivery HU details
* 1 delivery at a time (multiple delivery line items)
*----------------------------------------------------------------------*
FORM pp_assign_hu_to_delivery
              TABLES it_inb_lips   STRUCTURE lips  "Inb. dlvry item
               USING uv_outb_dlvry LIKE      likp-vbeln  "Out. dlvry #
            CHANGING ct_messages   TYPE      zca_bal_msg_tab.

  DATA:
    lv_locked(1),
    ls_inb_lips       LIKE lips,    "inb. ddelivery item
    ls_oub_lips       LIKE lips,    "oub. ddelivery item
    lt_oub_lips       LIKE TABLE OF lips,    "oub. ddelivery item

* HU SELECT tables
    ls_vekp           LIKE vekp,        "HU header
    lt_vekp           LIKE TABLE OF ls_vekp,

    ls_vepo           LIKE vepo,
    lt_vepo           LIKE TABLE OF ls_vepo,

* HU tables
    ls_handling_units LIKE hum_rehang_hu,  "Copy HU into Delivery
    lt_handling_units TYPE STANDARD TABLE OF hum_rehang_hu,

    ls_vbkok          TYPE vbkok,   "confirm picking structure
* Log for Picking Report
    lt_prot           TYPE STANDARD TABLE OF prott,
    ls_prot           TYPE prott,

    ls_messages       TYPE bal_s_msg.    "error messages

  SORT it_inb_lips BY charg.

*** Start modificatio by ALANKAP CMS 29123
* Need to ensure the Delivery is not locked
  PERFORM pp_check_delivery_lock
              USING uv_outb_dlvry
           CHANGING lv_locked.

  IF NOT lv_locked IS INITIAL.
* Move into an internal table and post into application log later
* Unable to lock delivery & for update
    ls_messages-msgty  = gc_error.
    ls_messages-msgid  = gc_msgid.
    ls_messages-msgno  = '055'.
    ls_messages-msgv1  = uv_outb_dlvry.
    ls_messages-msgv2  = space.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO ct_messages.
    CLEAR  ls_messages.
    RETURN.
  ENDIF. " NOT l_locked is initial.
*** End modificatio by ALANKAP CMS 29123
* Retrieve Inbound Delivery Handling Units
* (using index 'M' - Material Plant Storage Loc. Batch)
  REFRESH lt_vepo.

  IF NOT it_inb_lips[] IS INITIAL.
*** Start m odificatio by ALANKAP CMS 29123
    SELECT * INTO TABLE lt_oub_lips FROM lips
         WHERE vbeln = uv_outb_dlvry
          AND  NOT charg IS NULL.
* Take HU information
*    SELECT venum vepos
*      INTO CORRESPONDING FIELDS OF TABLE lt_vepo
*      FROM vepo
*      FOR ALL ENTRIES IN it_inb_lips
*      WHERE matnr = it_inb_lips-matnr
*        AND werks = it_inb_lips-werks
*        AND lgort = it_inb_lips-lgort
*        AND charg = it_inb_lips-charg.
    SELECT venum vepos
          INTO CORRESPONDING FIELDS OF TABLE lt_vepo
          FROM vepo
          FOR ALL ENTRIES IN lt_oub_lips
          WHERE matnr = lt_oub_lips-matnr
            AND werks = lt_oub_lips-werks
            AND lgort = lt_oub_lips-lgort
            AND charg = lt_oub_lips-charg.
*** End modification by ALANKAP CMS 29123
    IF sy-subrc = 0.
      SORT lt_vepo BY venum.
* Retrieve External Handling Unit Identification using key
      REFRESH lt_vekp.
      IF NOT lt_vepo[] IS INITIAL.
        SELECT venum exidv
          INTO CORRESPONDING FIELDS OF TABLE lt_vekp
          FROM vekp
          FOR ALL ENTRIES IN lt_vepo
          WHERE venum = lt_vepo-venum.
      ENDIF.  "VEKP
    ELSE.
* Pack failed.  HU info not available for the outbound delivery &
      CLEAR ls_messages.
      ls_messages-msgty  = gc_error.
      ls_messages-msgid  = gc_msgid.
      ls_messages-msgno  = '215'.
      ls_messages-msgv1  = uv_outb_dlvry.
      ls_messages-msgv2  = space.
      ls_messages-msgv3  = space.
      ls_messages-msgv4  = space.
      APPEND ls_messages TO ct_messages.
      CLEAR  ls_messages.
      RETURN.

    ENDIF.  "success VEPO
  ENDIF. "Retrieve from VEPO

* Since this subroutine only processes one Delivery at a time,
*  all Inbound HUs may be added to the table and assigned
*  to the Outbound Delivery.
  CLEAR ls_vekp.
  LOOP AT lt_vekp INTO ls_vekp.
    CLEAR ls_handling_units.
    ls_handling_units-top_hu_external = ls_vekp-exidv.
    APPEND ls_handling_units TO lt_handling_units.
  ENDLOOP. " at lt_vekp into lx_vekp.

* If HU's need assigning to the inbound then do so
  IF NOT lt_handling_units[] IS INITIAL.

*   Format header structure with Inbound Delivery Number
    CLEAR: ls_vbkok.
    ls_vbkok-vbeln_vl = uv_outb_dlvry.

*   Assign HU to the Delivery since not currently assigned
    CLEAR: ls_prot, lt_prot[].
    CALL FUNCTION 'WS_DELIVERY_UPDATE'
      EXPORTING
        vbkok_wa                 = ls_vbkok
        commit                   = gc_true
        delivery                 = uv_outb_dlvry
        if_database_update       = '1' "check & save
        if_error_messages_send_0 = gc_true
      TABLES
        prot                     = lt_prot
        it_handling_units        = lt_handling_units.

    IF NOT lt_prot[] IS INITIAL.
* Insert a Label record which identifies which document
* is now at problem
      CLEAR ls_messages.
      ls_messages-msgty  = gc_info.
      ls_messages-msgid  = gc_msgid.
* Problem packing outbound delivery &:
      ls_messages-msgno  = '214'.
      ls_messages-msgv1  = uv_outb_dlvry.
      ls_messages-msgv2  = space.
      ls_messages-msgv3  = space.
      ls_messages-msgv4  = space.
      APPEND ls_messages TO ct_messages.
      CLEAR  ls_messages.

*     Write error messages from function
      LOOP AT lt_prot INTO ls_prot.
* Move into an internal table and post into application log later
        CLEAR ls_messages.
        ls_messages-msgty  = ls_prot-msgty.
        ls_messages-msgid  = ls_prot-msgid.
        ls_messages-msgno  = ls_prot-msgno.
        ls_messages-msgv1  = ls_prot-msgv1.
        ls_messages-msgv2  = ls_prot-msgv2.
        ls_messages-msgv3  = ls_prot-msgv3.
        ls_messages-msgv4  = ls_prot-msgv4.
        APPEND ls_messages TO ct_messages.
        CLEAR  ls_messages.
      ENDLOOP.
    ENDIF.

  ENDIF.

ENDFORM.                    " assign_hu_to_delivery
*&---------------------------------------------------------------------*
*&      Form  get_likp
*&---------------------------------------------------------------------*
* Retrieve inbound header information from the table LIKP for the given
* inb. delivery
*----------------------------------------------------------------------*
*      <--CS_LIKP       Inbound delivery header information
*      -->UV_INB_VBELN  Inbound delivery number
*----------------------------------------------------------------------*
FORM get_likp  USING    uv_inb_vbeln TYPE vbeln_vl
               CHANGING cs_likp      LIKE likp.

  IF NOT uv_inb_vbeln IS INITIAL.
    SELECT SINGLE *
        INTO cs_likp
        FROM likp
       WHERE vbeln = uv_inb_vbeln.
  ENDIF.

ENDFORM.                    " get_likp
*&---------------------------------------------------------------------*
*&      Form  get_lips
*&---------------------------------------------------------------------*
* Retrieve inbound item information from the table LIPS for the given
* inbound delivery
*----------------------------------------------------------------------*
*      <--CT_LIPS      Inbound delivery item details
*      -->UV_INB_VBELN Inbound delivery
*----------------------------------------------------------------------*
FORM get_lips  TABLES   ct_lips STRUCTURE lips
               USING    uv_inb_vbeln.

  IF NOT uv_inb_vbeln IS INITIAL.
    SELECT *
      INTO TABLE ct_lips
      FROM lips
      WHERE vbeln = uv_inb_vbeln.
  ENDIF.

ENDFORM.                    " get_lips

*&---------------------------------------------------------------------*
*&      Form  get_status
*&---------------------------------------------------------------------*
* Get pick and pack status of the given outbound delivery from VBUP
* table (sales order line item status) and outbound delivery details
* from LIPS table
*----------------------------------------------------------------------*
*  -->  uv_out_delv    Outbound delivery
*  <--  ct_messages    Error message table
*----------------------------------------------------------------------*
FORM get_status    USING  uv_out_delv  LIKE likp-vbeln
                CHANGING  ct_messages  TYPE zca_bal_msg_tab.

  REFRESH gt_vbup.

  SELECT vbeln    "Outbound delivery
         posnr    "Outbound delivery line item
         kosta    "Picking status
         pksta    "Packing status
    INTO CORRESPONDING FIELDS OF TABLE gt_vbup
    FROM vbup
   WHERE vbeln = uv_out_delv
     AND posnr NOT LIKE '9*'  "Ignore batch splits
     AND kosta = 'C'.  "Picked

*  SELECT vbeln posnr matnr
*      INTO CORRESPONDING FIELDS OF TABLE gt_lips
*      FROM lips
*      WHERE vbeln = uv_out_delv
*        AND posnr NOT LIKE '9*'. "ignore batch splits
  SELECT vbeln posnr matnr vbelv posnv vgbel vgpos
      INTO CORRESPONDING FIELDS OF TABLE gt_lips
      FROM lips
      WHERE vbeln = uv_out_delv
        AND posnr NOT LIKE '9*'. "ignore batch splits " CMS 29123
ENDFORM.                    " get_status
*&---------------------------------------------------------------------*
*&      Form  check_status
*&---------------------------------------------------------------------*
* Check whether this outbound delivery line item is already picked
*----------------------------------------------------------------------*
*      -->US_LIPS          Inbound delivery line item
*      <--CV_PICK_FLAG     Set Pick Flag
*----------------------------------------------------------------------*
FORM check_pick    USING    us_lips         LIKE lips
                   CHANGING cv_pick_flag    TYPE char1
                            cv_posnr        LIKE lips-posnr.

  DATA:
    ls_odlvry LIKE lips.

*  SORT gt_lips BY matnr.
  SORT gt_lips BY matnr vgbel vgpos.                        "CMS 29123
  SORT gt_vbup BY vbeln posnr.

*  READ TABLE gt_lips INTO ls_odlvry
*                WITH KEY matnr = us_lips-matnr
*                BINARY SEARCH.
  READ TABLE gt_lips INTO ls_odlvry
                WITH KEY matnr = us_lips-matnr
*                         charg = us_lips-charg
                         vgbel = us_lips-vbelv
                         vgpos = us_lips-posnv
                BINARY SEARCH. " CMS 29123

  IF sy-subrc = 0.
    cv_posnr = ls_odlvry-posnr.
* Picking for even batch-split line item, if it is picked,
* KOSTA should be 'C'
* Get corresponding status info
    READ TABLE gt_vbup TRANSPORTING NO FIELDS
              WITH KEY vbeln = ls_odlvry-vbeln
                       posnr = ls_odlvry-posnr
              BINARY SEARCH.

    IF sy-subrc = 0.
      cv_pick_flag = 'X'.
    ELSE.
      CLEAR cv_pick_flag.
    ENDIF.
  ENDIF.

ENDFORM.                    " check_status
*&---------------------------------------------------------------------*
*&      Form  DELETE_DELIVERY_ITEM
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IV_OUT_VBELN  text
*      <--P_ET_MESSAGES[]  text
*----------------------------------------------------------------------*
FORM delete_delivery_item  USING uv_outb_dlvry LIKE      likp-vbeln
                           CHANGING ct_messages   TYPE  zca_bal_msg_tab.

  DATA : ls_vbkok  TYPE vbkok,
         ls_vbpok  TYPE vbpok,
         lv_commit LIKE rvsel-xfeld,
         lt_vbpok  TYPE TABLE OF vbpok,
         lt_prott  TYPE STANDARD TABLE OF prott.

  REFRESH lt_prott.

  CLEAR ls_vbkok.

  SELECT * INTO TABLE @DATA(lt_vbup) FROM vbup
                  WHERE vbeln = @uv_outb_dlvry
                  AND   kosta = 'A'.
  IF sy-subrc IS INITIAL.
    ls_vbkok-vbeln_vl = uv_outb_dlvry.

    lv_commit = 'X'.

    LOOP AT lt_vbup INTO DATA(ls_vbup).
      CLEAR ls_vbpok.
      ls_vbpok-vbeln_vl = ls_vbup-vbeln.
      ls_vbpok-posnr_vl = ls_vbup-posnr.
      ls_vbpok-lips_del = 'X'.
      APPEND ls_vbpok TO lt_vbpok.
    ENDLOOP.

    CALL FUNCTION 'WS_DELIVERY_UPDATE'
      EXPORTING
        vbkok_wa      = ls_vbkok
        commit        = lv_commit
        delivery      = ls_vbkok-vbeln_vl
      TABLES
        vbpok_tab     = lt_vbpok
        prot          = lt_prott
      EXCEPTIONS
        error_message = 1.
    IF sy-subrc IS INITIAL.

    ENDIF.
  ENDIF.
ENDFORM.

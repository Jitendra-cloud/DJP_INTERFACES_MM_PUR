*&---------------------------------------------------------------------*
*&  Include           ZDL_E04019_PREPLAN_SHPMNT_TRIG                   *
*&---------------------------------------------------------------------*
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2008 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2008, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Badi Implementation Name : ZDL_E03979_FLEX                01/08/2008 *
* Programmer  : Padma Sunkara                                          *
* Inventory Code :  E04019 - V2- Trigger when Pre-planned Shipment is  *
* deleted or delivery add/removed                                      *
*______________________________________________________________________*
* Description :                                                        *
*  This implementation is for V2-Custom trigger for STO based on       *
*  Shiment Change and is implemented in this BADI                      *
*  BADI: BADI_LE_SHIPMENT and METHOD : Before_Update .                 *
*_____________________________________________________________________ *
* Change History:                                                      *
*                                                                      *
*                                                                      *
************************************************************************
* External Calls  ZDL_E04010_FLEX_STO_TRIG_CHECK,                      *
*                 ZDL_I02539_FLEX_STO_TRIGGER                          *
*                                                                      *
*______________________________________________________________________*
************************************************************************

  data: gt_fields             type table of zdl_fields,
        gs_fields             type zdl_fields.
  constants :
    gc_fields_name         type zdl_fields-fieldname value 'Z_V2_TPP',
    gc_f                   type zdl_fped_loc-z_flex_ind
                                            value 'F',
    gc_b                   type zdl_fped_loc-z_flex_ind
                                            value 'B'.

  field-symbols: <gt_old_vttp> type vttpvb,
                 <gt_new_vttp> type vttpvb.

  data: gs_vttk   type vttkvb,
        gt_vtrlp  type table of vtrlp,
        gs_vtrlp  type vtrlp,
        gs_vtrlk  type vtrlk,
        gs_zd_fped_loc type zdl_fped_loc,
        gs_zsp_value  type zsp_value,
        gt_vttp type table of vttpvb,
        gs_vttp type vttpvb,
        gv_ebeln type  ebeln,
        gv_ebelp type  ebelp,
        gv_status type  flag,
        gv_exception type char30,
        gt_sto_result type table of zdl_fpedstat,
        gs_sto_result type zdl_fpedstat.


  constants :

   gc_updkz_d             type updkz_d value 'D',
   gc_updkz_i             type updkz_d value 'I',
   gc_prog_id             type programm value 'ZDL_E03167',
   gc_lfart               type zsp_fieldname value 'LFART%',
   gc_fsh                  type  zdl_ref_type value 'FSH'.

do 1 times.
* When Shipment is deleted or Delivery is unassigned from Shipment
* Old_Vttp will have entries with Update Indicator 'D' collect all
* these deliveries into temporary internal table
  refresh gt_vttp.
  loop at im_shipments_before_update-old_vttp into gs_vttp
    where updkz = gc_updkz_d.
    append gs_vttp to gt_vttp."Collect them into internal table gt_vttp
  endloop.
* When Delivery is assigned to Shipment the new_vttp indicator will
* have 'I' as the Update Indicator.
  loop at im_shipments_before_update-new_vttp into gs_vttp
    where updkz = gc_updkz_i.
    append gs_vttp to gt_vttp.
  endloop.
  if gt_vttp[] is initial." We are not assiging/Deleting any Deliveries
    exit.
  endif.
*  refresh gt_tvarvc.
  refresh gt_fields.
* Select the V2 Transportation Planning points.
*  select  *
*    into  table gt_tvarvc
*    from  tvarvc
*    where name = gc_tvarvc_name.
*
  select  *
    into  table gt_fields
    from  zdl_fields
    where category  eq 'E03979'
    and   fieldname eq gc_fields_name.

* Loop at all deliveries collected from above internal table and check
* if any of the STO's behind the STO related for deliveries are relevant
* for poking
  loop at gt_vttp into gs_vttp.
    clear gs_vttk.
    read table im_shipments_before_update-new_vttk into gs_vttk
         with key tknum = gs_vttp-tknum.
    if sy-subrc <> 0.
      read table im_shipments_before_update-old_vttk into gs_vttk
           with key tknum = gs_vttp-tknum.
    endif.
    if gs_vttk-tknum is initial.
      continue.
    endif.
    if gs_vttk-sdabw = 'FLEX'.
      continue.
    endif.
*    clear gs_tvarvc.
*    read table gt_tvarvc into gs_tvarvc
*         with key low = gs_vttk-tplst.
*    if sy-subrc <> 0." Not a V2 shipment
*      continue.
*    endif.
*
    clear gs_fields.
    read table gt_fields into gs_fields
         with key lowval = gs_vttk-tplst.
    if sy-subrc <> 0." Not a V2 shipment
      continue.
    endif.
* Validate that the Delivery belongs to STO
    clear gs_vtrlk.
    read table im_shipments_before_update-new_vtrlk into gs_vtrlk
    with key vbeln = gs_vttp-vbeln.
    clear gs_zsp_value.
    select single *
      into gs_zsp_value
      from zsp_value
      where pgrmid = gc_prog_id
      and fieldname like gc_lfart
      and fieldvalue = gs_vtrlk-lfart.
    if sy-subrc <> 0. " Do not Poke
      continue.
    endif.

* Validate the Shipping Point

    loop at im_shipments_before_update-new_vtrlp into
                            gs_vtrlp where vbeln = gs_vtrlk-vbeln.
      clear gs_zd_fped_loc.
      select single *
        into gs_zd_fped_loc
        from zdl_fped_loc
        where werks = gs_vtrlp-werks
        and vstel = gs_vtrlk-vstel
        and z_flex_ind in (gc_f, gc_b).
      if sy-subrc = 0.
        gv_ebeln = gs_vtrlp-vgbel.
        gv_ebelp = gs_vtrlp-vgpos.
        clear: gv_status,gv_exception.
        call function 'ZDL_E04010_FLEX_STO_TRIG_CHECK'
          exporting
            sto_header                       = gv_ebeln
            sto_item                         = gv_ebelp
            delv_docu                        = gs_vttp-vbeln
            ref_type                         = gc_fsh
            ref_docu                         = gs_vttk-tknum
       importing
         status                             = gv_status
         EXCEPTION                          = gv_exception
         TABLES
        STO_RESULTS                        =  gt_sto_result.


        if gv_status is not initial.
          read table gt_sto_result into gs_sto_result
               with key sto_header = gv_ebeln
                        sto_item   = gv_ebelp
                        DELV_DOCU  = gs_vttp-vbeln.

          call function 'ZDL_I02539_FLEX_STO_TRIGGER'
            exporting
              iv_dlvry_doc         = gs_vttp-vbeln
              iv_ref_type          = gc_fsh
              iv_sto_no            = gv_ebeln
              iv_sto_line          = gv_ebelp
             IV_FPED_CURR          = gs_sto_result-CURR_STATUS
             IV_FPED_PREV          = gs_sto_result-PREV_STATUS
*             IV_FPED_DATE        =
*             IV_FPED_TIME        =
*             IV_PROD_ORDER       =
              iv_shpmnt           = gs_vttk-tknum
                    .
        endif.
      else.   " Not Valid Shipping Point
        continue.
      endif.
    endloop. " End of Validating the Shipping Point
  endloop.  " End of loop when Deliveries are deleted/added.
  enddo.

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDL_E04516_TBL_M
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDL_E04516_TBL_M   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

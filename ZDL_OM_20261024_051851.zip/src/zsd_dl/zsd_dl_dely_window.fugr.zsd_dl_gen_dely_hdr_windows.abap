FUNCTION zsd_dl_gen_dely_hdr_windows.
*"----------------------------------------------------------------------
*"*"Global Interface:
*"  TABLES
*"      IT_LIPS TYPE  SHP_LIPS_T
*"      IT_LIKP TYPE  SHP_LIKP_T
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**  COPYRIGHT (C) 2006 by INTERNATIONAL PAPER   ALL RIGHTS RESERVED   **
**     REVISIONS COPYRIGHT (C) 2006  by INTERNATIONAL PAPER           **
*______________________________________________________________________*
* Programmer  : Charles Ramey                   Date : 06/02/2006      *
* COR#  U01168                                                         *
* created for R5 March 2006 implementation                             *
*______________________________________________________________________*
* Description :
* This FM is used to generate the Delivery Windows that are put on     *
* the delivery header                                                  *
*______________________________________________________________________*
* Change History :                                                     *
* CRAMEY       06/02/2006  R7 Don't update time for V2 deliveries      *
*                                                                      *
* Bala Mandla  02/23/2009  EDEK914518                                  *
*                          Delivery Window Intersection Update         *
* Bala Mandla  07/14/2009  EDVK972369                                  *
*                          Putting the Initial vale for time when it   *
*                          is blank                                    *
*______________________________________________________________________*
*----------------------------------------------------------------------*

  DATA wa_likp LIKE LINE OF it_likp.
  DATA l_hold_tabix LIKE sy-tabix.


  LOOP AT it_likp INTO wa_likp.
    l_hold_tabix = sy-tabix.
    PERFORM find_header_window CHANGING wa_likp.
    MODIFY it_likp FROM wa_likp INDEX l_hold_tabix.
  ENDLOOP.
ENDFUNCTION.

*&---------------------------------------------------------------------*
*&      Form  find_header_window
*&---------------------------------------------------------------------*
* loop thru the delivery items and use the earliest and latest date
* for the window.
*----------------------------------------------------------------------*
FORM find_header_window CHANGING wa_likp LIKE LINE OF it_likp.

  CONSTANTS: c_eod     TYPE i VALUE 86399,
             c_24hours TYPE i VALUE 24,
             c_sod     TYPE i VALUE 000001.


  DATA    wa_lips LIKE LINE OF it_lips.
  DATA:   l_datefrom   LIKE wa_lips-zz_dly_date_from,
          l_dateto     LIKE wa_lips-zz_dly_date_to,
          l_timefrom   LIKE wa_lips-zz_dly_time_from,
          l_timeto     LIKE wa_lips-zz_dly_time_to.

  DATA:   l_value      LIKE zsp_value-fieldvalue,
          l_v2_dely    TYPE c.

*Delivery Window Intersection Variables Declarations
  DATA:     i_datefrom   LIKE it_lips-zz_dly_date_from,
            i_dateto     LIKE it_lips-zz_dly_date_to,
            i_timefrom   LIKE it_lips-zz_dly_time_from,
            i_timeto     LIKE it_lips-zz_dly_time_to,
            i_zone       LIKE it_likp-tzonrc.

*Delivery Window A
  DATA : lv_aw_fdate TYPE tzntstmps,
         lv_aw_tdate TYPE tzntstmps,
*Delivery Window B
         lv_bw_fdate TYPE tzntstmps,
         lv_bw_tdate TYPE tzntstmps,
* Delivery Window Intersection
         lv_dwi_fdate TYPE tzntstmps,
         lv_dwi_tdate TYPE tzntstmps,
*Final dates
       lv_fdwi_fdate   TYPE tzntstmps,
       lv_fdwi_tdate   TYPE tzntstmps,
       lv_final_date_f TYPE likp-zz_dly_date_from,
       lv_final_time_f TYPE likp-zz_dly_time_from,
       lv_final_date_t TYPE likp-zz_dly_date_from,
       lv_final_time_t TYPE likp-zz_dly_time_from,
       lc_date_f       LIKE likp-zz_dly_date_from,
       lc_time_f       LIKE likp-zz_dly_time_from,
       lc_date_t       LIKE likp-zz_dly_date_from,
       lc_time_t       LIKE likp-zz_dly_time_from.

  DATA: lv_w_date_from TYPE tzntstmps,
        lv_w_date_to   TYPE tzntstmps.

  CLEAR l_v2_dely.
  READ TABLE it_lips
     WITH KEY vbeln = wa_likp-vbeln
     BINARY SEARCH.
  CHECK sy-subrc IS INITIAL.

* we use division to determine if the time should be overwritten
* (V2-no; V1-yes)
  SELECT SINGLE fieldvalue INTO l_value
     FROM zsp_value
    WHERE pgrmid    = 'ZSD_DL_DELY_WINDOWS'
      AND fieldname = 'V2_DIVISION'.

*  LOOP AT it_lips INTO wa_lips FROM sy-subrc.
  LOOP AT it_lips INTO wa_lips FROM sy-subrc WHERE updkz NE 'D'.
    CHECK wa_lips-vbeln = wa_likp-vbeln.

    IF wa_lips-spart = l_value.
      l_v2_dely = 'X'.
    ENDIF.

    IF l_datefrom IS INITIAL.
      l_datefrom = wa_lips-zz_dly_date_from.
      l_dateto   = wa_lips-zz_dly_date_to.
      l_timefrom = wa_lips-zz_dly_time_from.
      l_timeto   = wa_lips-zz_dly_time_to.
*Start of Change EDEK914518
*First Time in ITEM (LIPS) LOOP Assign the delivery date and time values
      i_datefrom = wa_lips-zz_dly_date_from.
      i_timefrom = wa_lips-zz_dly_time_from.
      i_dateto   = wa_lips-zz_dly_date_to.
      i_timeto   = wa_lips-zz_dly_time_to.
      i_zone     = wa_likp-tzonrc.

*Build the Time Stamp for Window A
      PERFORM build_timestamp USING i_datefrom
                                    i_dateto
                                    i_zone
                           CHANGING i_timefrom
                                    i_timeto
                                    lv_w_date_from
                                    lv_w_date_to.

*First time In LIPS LOOP Assign the Time Stamp values for window A
      lv_aw_fdate = lv_w_date_from.
      lv_aw_tdate = lv_w_date_to.

    ELSE.
*Find the Delivery Intersection Dates Betwen Window A and Window B.
      IF lv_dwi_fdate IS INITIAL.
        CLEAR: i_datefrom, i_dateto, i_timefrom, i_timeto.
        CLEAR: lv_w_date_from, lv_w_date_to.

*Second Time in ITEM (LIPS) LOOP Assign the delivery date and time
*values
        i_datefrom = wa_lips-zz_dly_date_from.
        i_dateto   = wa_lips-zz_dly_date_to.
        i_timefrom = wa_lips-zz_dly_time_from.
        i_timeto   = wa_lips-zz_dly_time_to.
        i_zone     = wa_likp-tzonrc.

*Build the Time Stamp for Window B
        PERFORM build_timestamp USING i_datefrom
                                      i_dateto
                                      i_zone
                             CHANGING i_timefrom
                                      i_timeto
                                      lv_w_date_from
                                      lv_w_date_to.

*Assign the Time Stamp values for window B
        lv_bw_fdate = lv_w_date_from.
        lv_bw_tdate = lv_w_date_to.
*
*Find the Delivery Intersection Dates Betwen Window A and Window B.
        PERFORM find_del_window_intersection USING lv_aw_fdate
                                                   lv_aw_tdate
                                                   lv_bw_fdate
                                                   lv_bw_tdate
                                         CHANGING  lv_dwi_fdate
                                                   lv_dwi_tdate.


      ELSE.
        lv_aw_fdate = lv_dwi_fdate.
        lv_aw_tdate = lv_dwi_tdate.

        CLEAR: i_datefrom, i_dateto, i_timefrom, i_timeto.
        CLEAR: lv_w_date_from, lv_w_date_to.

        i_datefrom = wa_lips-zz_dly_date_from.
        i_dateto   = wa_lips-zz_dly_date_to.
        i_timefrom = wa_lips-zz_dly_time_from.
        i_timeto   = wa_lips-zz_dly_time_to.
        i_zone     = wa_likp-tzonrc.

*Build the Time Stamp for Window B
        PERFORM build_timestamp USING i_datefrom
                                      i_dateto
                                      i_zone
                             CHANGING i_timefrom
                                      i_timeto
                                      lv_w_date_from
                                      lv_w_date_to.
*Assign the Time Stamp values for window B
        lv_bw_fdate = lv_w_date_from.
        lv_bw_tdate = lv_w_date_to.

        PERFORM find_del_window_intersection USING lv_aw_fdate
                                                   lv_aw_tdate
                                                   lv_bw_fdate
                                                   lv_bw_tdate
                                         CHANGING  lv_dwi_fdate
                                                   lv_dwi_tdate.


      ENDIF.

*    find the earliest from date
      IF wa_lips-zz_dly_date_from < l_datefrom.
        l_datefrom = wa_lips-zz_dly_date_from.
      ENDIF.
*    take the latest to date
      IF wa_lips-zz_dly_date_to > l_dateto.
        l_dateto = wa_lips-zz_dly_date_to.
      ENDIF.
*  if appointment broken - let the carrier contact the customer
      IF wa_lips-zz_dly_time_from <> l_timefrom OR
         wa_lips-zz_dly_time_to   <> l_timeto.
        l_timefrom = 000000.
        l_timeto   = c_eod.
      ENDIF.
    ENDIF.
  ENDLOOP.

*If Intersection Dates Finds
  IF  lv_dwi_fdate IS NOT INITIAL.
    DATA: lv_hours TYPE i.
    CLEAR: lc_date_f, lc_time_f, lc_date_t, lc_time_t.

    i_zone =  wa_likp-tzonrc.

*Find The No of hours between Intersection
    PERFORM get_hours_from_intersection USING  lv_dwi_fdate
                                               lv_dwi_tdate
                                      CHANGING lv_hours.
    DATA lv_pld_del_date TYPE tzntstmps.

*Planned Delivery time stamp
    PERFORM get_delivery_timesatmp USING wa_likp-lfdat
                                         wa_likp-tzonrc
                              CHANGING   wa_likp-lfuhr
                                         lv_pld_del_date.

*When the Intersection is greater or equal to 24 hours
    IF lv_hours GE c_24hours.

      CLEAR : lv_fdwi_fdate, lv_fdwi_tdate, lv_final_date_f,
      lv_final_time_f,
              lv_final_date_t, lv_final_time_t.
* If Planned Delivery window fall in Delivery Window Intervel
      IF ( lv_pld_del_date LE lv_dwi_tdate ) AND ( lv_pld_del_date GE
      lv_dwi_fdate ).
*Build the Final Delivery window Intersection
        lv_fdwi_fdate = lv_pld_del_date.
        lv_fdwi_tdate = lv_dwi_tdate.


        CONVERT TIME STAMP lv_fdwi_fdate TIME ZONE wa_likp-tzonrc
                INTO DATE  lv_final_date_f TIME lv_final_time_f.

        CONVERT TIME STAMP lv_fdwi_tdate TIME ZONE wa_likp-tzonrc
                INTO DATE  lv_final_date_t TIME lv_final_time_t.

*Provide the Entire Day Window Hours between - 00:00:01 to 23:59:59
        lv_final_time_f = c_sod.
        lv_final_time_t = c_eod.
*Assign the final dates to Header (likp).
        wa_likp-zz_dly_date_from = lv_final_date_f.
        wa_likp-zz_dly_date_to   = lv_final_date_t.
        wa_likp-zz_dly_time_from = lv_final_time_f.
        wa_likp-zz_dly_time_to   = lv_final_time_t.
      ELSE.
        "Delivery Intersection falls outside of the Intersection
        CONVERT TIME STAMP lv_pld_del_date TIME ZONE wa_likp-tzonrc
                INTO DATE  lv_final_date_f TIME lv_final_time_f.
*Assign the final dates to Header (likp).
        wa_likp-zz_dly_date_from = lv_final_date_f.
        wa_likp-zz_dly_date_to   = lv_final_date_f.
        wa_likp-zz_dly_time_from = lv_final_time_f.
        wa_likp-zz_dly_time_to   = lv_final_time_f.

      ENDIF.
    ELSE.
*When the Intersection is less than 24 hours

      CLEAR : lv_fdwi_fdate, lv_fdwi_tdate, lv_final_date_f,
      lv_final_time_f,
              lv_final_date_t, lv_final_time_t.
*Delivery Time Falls with in the Delivery window
      IF ( lv_pld_del_date LE lv_dwi_tdate ) AND ( lv_pld_del_date GE
      lv_dwi_fdate ).
*Build the Final Delivery window Intersection
        lv_fdwi_fdate = lv_dwi_fdate.
        lv_fdwi_tdate = lv_dwi_tdate.

        CONVERT TIME STAMP lv_fdwi_fdate TIME ZONE wa_likp-tzonrc
                INTO DATE  lv_final_date_f TIME lv_final_time_f.

        CONVERT TIME STAMP lv_fdwi_tdate TIME ZONE wa_likp-tzonrc
                INTO DATE  lv_final_date_t TIME lv_final_time_t.


*Assign the final dates to Header (likp).
        wa_likp-zz_dly_date_from = lv_final_date_f.
        wa_likp-zz_dly_date_to   = lv_final_date_t.
        wa_likp-zz_dly_time_from = lv_final_time_f.
        wa_likp-zz_dly_time_to   = lv_final_time_t.
      ELSE.
        "Delivery Intersection falls outside of the Intersection
        CONVERT TIME STAMP lv_pld_del_date TIME ZONE wa_likp-tzonrc
                INTO DATE  lv_final_date_f TIME lv_final_time_f.
*Assign the final dates to Header (likp).
        wa_likp-zz_dly_date_from = lv_final_date_f.
        wa_likp-zz_dly_date_to   = lv_final_date_f.
        wa_likp-zz_dly_time_from = lv_final_time_f.
        wa_likp-zz_dly_time_to   = lv_final_time_f.

      ENDIF.
    ENDIF.

  ELSE.
    wa_likp-zz_dly_date_from = l_datefrom.
    wa_likp-zz_dly_date_to   = l_dateto.
    wa_likp-zz_dly_time_from = l_timefrom.
    wa_likp-zz_dly_time_to   = l_timeto.
  ENDIF.
*Start of Change EDEK914518
*When adding or deleting lines from the delivery the delivery time is
*overwriting with 00:00:00 and therefore the window can not potentially
*be calculated correctly with 00:00:00 time and date
*Commenting out this below code
*As per the Paul Yoch and Matthew Montano

*  IF l_v2_dely IS INITIAL.
*    wa_likp-lfuhr            = l_timefrom.
*  ENDIF.
*Emd of Change EDEK914518
ENDFORM.                    "find_header_window

*&---------------------------------------------------------------------*
*&      Form  build_timestamp
*&---------------------------------------------------------------------*
*  Build Time Stamp
*----------------------------------------------------------------------*
*      -->LC_LIPS    text
*----------------------------------------------------------------------*
FORM build_timestamp USING i_datefrom     LIKE it_lips-zz_dly_date_from
                           i_dateto       LIKE it_lips-zz_dly_date_to
                           i_zone         LIKE it_likp-tzonrc
                  CHANGING i_timefrom     LIKE it_lips-zz_dly_time_from
                           i_timeto       LIKE it_lips-zz_dly_time_to
                           lv_w_date_from TYPE tzntstmps
                           lv_w_date_to   TYPE tzntstmps.
*Start of Change EDVK972369
*TPR # 32962
*This Function Call is Terminating when time field is space
*to prevent this initializing the time fields when it is blank
  IF i_timefrom = space.
    i_timefrom = '000000'.
  ENDIF.
  IF i_timeto = space.
    i_timeto = '000000'.
  ENDIF.
*End of Change EDVK972369

  CALL FUNCTION 'IB_CONVERT_INTO_TIMESTAMP'
    EXPORTING
      i_datlo     = i_datefrom
      i_timlo     = i_timefrom
      i_tzone     = i_zone
    IMPORTING
      e_timestamp = lv_w_date_from.

  CALL FUNCTION 'IB_CONVERT_INTO_TIMESTAMP'
    EXPORTING
      i_datlo     = i_dateto
      i_timlo     = i_timeto
      i_tzone     = i_zone
    IMPORTING
      e_timestamp = lv_w_date_to.


ENDFORM.                    "build_timestamp

**&---------------------------------------------------------------------
**
**&      Form  build_del_window_intersection
**&---------------------------------------------------------------------
**
** Find Delivery Window Intersection
**----------------------------------------------------------------------
**
**      -->LC_LIPS    text
**----------------------------------------------------------------------
**
FORM find_del_window_intersection USING  lv_aw_fdate  TYPE tzntstmps
                                         lv_aw_tdate  TYPE tzntstmps
                                         lv_bw_fdate  TYPE tzntstmps
                                         lv_bw_tdate  TYPE tzntstmps
                               CHANGING  lv_dwi_fdate TYPE tzntstmps
                                         lv_dwi_tdate TYPE tzntstmps.
*Scenario 1
*  lv_bw_fdate<-----------------B----------->lv_bw_tdate
*                         |<****************>|
*              lv_aw_fdate<------------A-------------->lv_aw_tdate

  IF  ( lv_aw_tdate  GE lv_bw_tdate )  AND
      ( lv_aw_fdate  GE lv_bw_fdate )  AND
      ( lv_aw_fdate  LE lv_bw_tdate ) .

    lv_dwi_fdate = lv_aw_fdate.
    lv_dwi_tdate = lv_bw_tdate.
*Scenario 2
*             lv_bw_fdate<--------------B---------------->lv_bw_tdate
*                        |<****************>|
*lv_aw_fdate<--------------A---------------->lv_aw_tdate

  ELSEIF ( lv_aw_tdate  LE lv_bw_tdate ) AND
         ( lv_aw_fdate  LE lv_bw_fdate ) AND
         ( lv_aw_tdate  GE lv_bw_fdate ).

    lv_dwi_fdate = lv_bw_fdate.
    lv_dwi_tdate = lv_aw_tdate.

*Scenario 3
*              lv_bw_fdate<------B------->lv_bw_tdate
*                         |<*************>|
*lv_aw_fdate<----------------A-------------------->lv_aw_tdate
  ELSEIF ( lv_aw_tdate  GE lv_bw_tdate ) AND
         ( lv_aw_fdate  LE lv_bw_fdate ).

    lv_dwi_fdate = lv_bw_fdate.
    lv_dwi_tdate = lv_bw_tdate.

*Scenario 4
*  Window 'A' is inside Window 'B'
*lv_bw_fdate<-------------B------------------>lv_bw_tdate
*                         |<*************>|
*              lv_aw_fdate<-------A------->lv_aw_tdate
  ELSEIF ( lv_aw_tdate  LE lv_bw_tdate ) AND
         ( lv_aw_fdate  GE lv_bw_fdate ).

    lv_dwi_fdate = lv_aw_fdate.
    lv_dwi_tdate = lv_aw_tdate.
*   others
  ELSE.

  ENDIF.

ENDFORM.                    "build_del_window_intersection


*&---------------------------------------------------------------------*
*&      Form  get_hours_from_intersection
*&---------------------------------------------------------------------*
* Find No of Hours between Intersection Dates
*----------------------------------------------------------------------*
*      -->LV_DWI_FDATE  text
*      -->LV_DWI_TDATE  text
*      -->LV_HOURS      text
*----------------------------------------------------------------------*
FORM get_hours_from_intersection USING  lv_dwi_fdate TYPE tzntstmps
                                        lv_dwi_tdate TYPE tzntstmps
                               CHANGING lv_hours     TYPE i.

  DATA : lc_time1 TYPE cacstimestamp,
         lc_time2 TYPE cacstimestamp.

  MOVE lv_dwi_fdate TO lc_time1.
  MOVE lv_dwi_tdate TO lc_time2.

  CALL FUNCTION 'CCU_TIMESTAMP_DIFFERENCE'
    EXPORTING
      timestamp1 = lc_time2
      timestamp2 = lc_time1
    IMPORTING
      difference = lv_hours.

  lv_hours = lv_hours DIV 3600.


ENDFORM.                    "get_hours_from_intersection

*&---------------------------------------------------------------------*
*&      Form  get_delivery_timesatmp
*&---------------------------------------------------------------------*
* Delivery Time Stamp
*----------------------------------------------------------------------*
FORM get_delivery_timesatmp USING wa_likp_lfdat   TYPE likpvb-lfdat
                                  wa_likp_tzonrc  TYPE likpvb-tzonrc
                       CHANGING   wa_likp_lfuhr   TYPE likpvb-lfuhr
                                  lv_pld_del_date TYPE tzntstmps.

*Start of Change EDVK972369
*TPR # 32962
*This Function Call is Terminating when time field is space
*to prevent this initializing the time fields when it is blank
  IF wa_likp_lfuhr = space.
    wa_likp_lfuhr = '000000'.
  ENDIF.
*End of Change EDVK972369

  CALL FUNCTION 'IB_CONVERT_INTO_TIMESTAMP'
    EXPORTING
      i_datlo     = wa_likp_lfdat
      i_timlo     = wa_likp_lfuhr
      i_tzone     = wa_likp_tzonrc
    IMPORTING
      e_timestamp = lv_pld_del_date.

ENDFORM.                    "get_delivery_timesatmp

FUNCTION zdl_e03593_cont_determine.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(T_DELNOS) TYPE  VBELN_VL_T
*"  EXPORTING
*"     REFERENCE(E_SUBRC) TYPE  SY-SUBRC
*"  EXCEPTIONS
*"      NO_DATA
*"      WRONG_DELIVERY_STATUS
*"----------------------------------------------------------------------
**  Change History
*  Date      programer          Change
* 12/10/09     CRAMEY    modified format so it would fit within 72
*                        and added fields to GT_LIPS and select on
*                        VEPO so Index M would be utilized.
*
***********************************************************************
** get inbound delivery iniformation from LIPS
  IF t_delnos IS INITIAL .
    RAISE no_data .
  ENDIF.
** check if all deliveries have been Received
*// Get the GR Status information from VBUK
  SELECT vbeln wbstk
    INTO TABLE gt_status
    FROM vbuk
    FOR ALL ENTRIES IN t_delnos
    WHERE vbeln = t_delnos-table_line
      AND wbstk = 'C' .
  IF sy-subrc NE 0 .
    RAISE wrong_delivery_status .
  ELSE.
    DESCRIBE TABLE gt_status LINES sy-tfill .
    DESCRIBE TABLE t_delnos LINES gv_lines .
    IF gv_lines NE sy-tfill .
      RAISE wrong_delivery_status .
    ENDIF.
  ENDIF.

** get the batches from delivery
  SELECT vbeln matnr werks lgort charg
    INTO TABLE gt_lips
    FROM lips
    FOR ALL ENTRIES IN t_delnos
    WHERE vbeln = t_delnos-table_line
      AND charg <> space .
  IF sy-subrc EQ 0 .
    SORT gt_lips BY vbeln .
** get the handling unit internal number from batch
    SELECT venum vepos unvel charg
      INTO TABLE gt_vepo_lower
      FROM vepo
      FOR ALL ENTRIES IN gt_lips
      WHERE matnr = gt_lips-matnr
        and werks = gt_lips-werks
        and lgort = gt_lips-lgort
        and charg = gt_lips-charg  .

    IF sy-subrc EQ 0 .
      SORT gt_vepo_lower BY charg .
      SELECT venum vpobjkey
        INTO TABLE gt_vekp_lower
        FROM vekp
        FOR ALL ENTRIES IN gt_vepo_lower
        WHERE venum = gt_vepo_lower-venum .
      LOOP AT gt_vekp_lower INTO gs_vekp_lower.
        MOVE gs_vekp_lower-vpobjkey TO gs_vekp_lower-vbeln .
        MODIFY gt_vekp_lower FROM gs_vekp_lower INDEX sy-tabix .
      ENDLOOP .
      IF gt_vekp_lower IS NOT INITIAL .
        SELECT vbeln INTO TABLE gt_likp
           FROM likp
           FOR ALL ENTRIES IN gt_vekp_lower
          WHERE vbeln = gt_vekp_lower-vbeln .
        SORT gt_likp  .
      ENDIF.
    ENDIF.
  ELSE.
    RAISE no_data .
  ENDIF.
** now get the Upper level if they exist
  IF gt_vepo_lower[] IS NOT INITIAL .
    SELECT venum vepos unvel charg
      INTO TABLE gt_vepo_upper
      FROM vepo
      FOR ALL ENTRIES IN gt_vepo_lower
      WHERE unvel = gt_vepo_lower-venum .
    IF sy-subrc EQ 0 .
** get the VEKP of the Upper level
      SELECT venum vpobjkey vhart FROM vekp
        INTO TABLE gt_vekp_upper
        FOR ALL ENTRIES IN gt_vepo_upper
        WHERE venum = gt_vepo_upper-venum .
    ENDIF.
  ENDIF.
  CLEAR gv_error .
** get the Batches for the Inbound delivery
  LOOP AT t_delnos INTO gs_inbdel .
    IF gv_error = 'X' .
      EXIT .
    ENDIF.
** check if all the batches in the delivery have the same assignment
    LOOP AT gt_lips INTO gs_lips WHERE vbeln = gs_inbdel.
** get the VEPO entry for this Batch
      READ TABLE gt_vepo_lower
        INTO gs_vepo_lower
        WITH KEY charg = gs_lips-charg
        BINARY SEARCH.
      IF sy-subrc EQ  0 .
** read the header information of HU and get the VPOBJKEY
**(assignment key)
        READ TABLE gt_vekp_lower
          INTO gs_vekp_lower
          WITH KEY venum = gs_vepo_lower-venum
          BINARY SEARCH.
        IF sy-subrc EQ 0 AND
           gs_vekp_lower-vpobjkey IS NOT INITIAL .
          CLEAR gs_likp .
** if assignment is not blank then check if its against the
** Inbound delivery
          READ TABLE gt_likp
            INTO gs_likp
            WITH KEY vbeln = gs_vekp_lower-vbeln
            BINARY SEARCH.
          IF sy-subrc EQ 0 .
            IF gs_likp-vbeln = gs_lips-vbeln  .
** no issues
            ELSE.
              e_subrc = 1 .   "Delivery HU reassigned
              gv_error = 'X' .
              EXIT .
            ENDIF.
          ENDIF.
        ELSE.
** no issues Delivery not assigned to HU
        ENDIF.
** setup a loop to get to the highest level of HU
** we are looking for a Container at a higher level this is to
** determine if the delivery has been containerized
** (put in a container)there is no direct means of achieving this
** through std SAP
        READ TABLE gt_vepo_upper INTO gs_vepo_upper
                    WITH KEY unvel = gs_vepo_lower-venum .
        IF sy-subrc EQ 0 .
          READ TABLE gt_vekp_upper INTO gs_vekp_upper
                   WITH KEY venum = gs_vepo_upper-venum .
        ENDIF.
** upper level HU exists
        IF sy-subrc EQ 0 AND
           gs_vekp_upper-vhart = gc_cont.   "Upper level is cntr
          e_subrc = '2' .
          gv_error = 'X' .
          EXIT .
        ELSEIF sy-subrc NE 0.
** if no upper level record was found - No issues
          CLEAR e_subrc .
        ELSEIF sy-subrc EQ 0 AND
               gs_vekp_upper-vhart NE gc_cont .
** more than one level of Hierarchy exists in this iteration
** we try to find the upper level hierarchy

          CLEAR: gv_venum_u, gv_unvel,
                 gv_cont_found, gv_venum .
          MOVE gs_vepo_upper-venum TO gv_venum_u .

          DO.
** get the item details of Upper level HU
            SELECT SINGLE venum unvel
              INTO (gv_venum , gv_unvel)
              FROM vepo
               WHERE unvel = gv_venum_u .
            IF sy-subrc EQ 0 AND gv_unvel IS NOT INITIAL .
              SELECT SINGLE venum vhart
                INTO (gv_venum , gv_vhart)
                FROM vekp
                WHERE venum = gv_venum .
              IF sy-subrc EQ 0 AND
                 gv_vhart = gc_cont .
                   gv_cont_found = 'X' .
                   EXIT .
              ELSEIF sy-subrc NE 0 .
                EXIT .
              ELSEIF sy-subrc EQ 0 AND
                     gv_vhart NE gc_cont .
                MOVE gv_venum  TO gv_venum_u .
                CLEAR gv_unvel .
              ELSE.
                EXIT.
              ENDIF.
            ELSEIF sy-subrc EQ 0 AND
              gv_unvel IS INITIAL.
** the upper level HU is not a container no error
*              gv_hu_error = 'X' .
              EXIT .
            ELSEIF sy-subrc NE 0 .
              EXIT .
            ENDIF.
          ENDDO .
          IF gv_cont_found = 'X' .
            e_subrc = 2 .
            gv_error = 'X' .
            EXIT .
          ENDIF.

        ENDIF.
      ENDIF.
    ENDLOOP .

  ENDLOOP .

ENDFUNCTION.


PROCESS BEFORE OUTPUT.
  MODULE status_0100.
*
PROCESS AFTER INPUT.

  MODULE leave_transaction_0100 AT EXIT-COMMAND .

  CHAIN.

    FIELD: zdlu01267_0100-signi,   "container id
           zdlu01267_0100-seal.    "seal id
    MODULE user_command_0100.

  ENDCHAIN.

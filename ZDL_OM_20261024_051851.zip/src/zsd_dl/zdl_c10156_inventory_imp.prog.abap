*&---------------------------------------------------------------------*
*&  Include           ZDL_C10156_INVENTORY_IMP
*&---------------------------------------------------------------------*
CLASS lcl_inventory_conv IMPLEMENTATION.
  METHOD main.
* Build dynamic internal table and update the upload file data
* to the internal table
    go_inventory_conversion->upload_build_dyn_table( ).

* If any error found, then give the message and retrun to the screen
    IF zcl_dl_c10156_inventory_conv=>mv_message IS NOT INITIAL.
      MESSAGE s000(zdl_c10156)
              WITH zcl_dl_c10156_inventory_conv=>mv_message
              DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.

* Build translation file data based on the upload file data.
* This translation file data will contain conversion data as well
    go_inventory_conversion->build_translation_file( ).

* Validate upload file data field.
    go_inventory_conversion->validate_input_data( ).

* Create process method for BATCH, GOODS RECEIPT,
*GOODS REVERSAL and HANDLING UNIT
    go_inventory_conversion->create_revers_process( ).

* Write files in applicatoin layer.
    go_inventory_conversion->write_files_in_app_server( ).

* Display the data in the ALV
    display( ).

  ENDMETHOD.
  METHOD modify_screen.
* Modify the screen based on the user action.
    LOOP AT SCREEN.
* Process Block and Selction Parameter block changes
      IF ( p_bat = abap_true OR p_uni = abap_true ) AND
         ( screen-group1 = 'PRD' OR screen-group1 = 'GRS' OR
           screen-group1 = 'PDT' ).
        screen-active = '0'.
      ENDIF.

* Selction Parameter GR 562.
      IF ( p_bat = abap_true OR p_uni = abap_true OR
           p_goods = abap_true ) AND
        screen-group1 = 'GRS'.
        screen-active = '0'.
      ENDIF.

* Selction Parameter GR 562.
      IF ( p_bat = abap_true OR p_uni = abap_true OR
           p_goodre = abap_true ) AND
        screen-group1 = 'PRD'.
        screen-active = '0'.
      ENDIF.

* File option block changes
      IF ( p_local = abap_true AND screen-group1 = 'APP' ) OR
         ( p_app   = abap_true AND screen-group1 = 'LOC' ).
        screen-input = '0'.
      ENDIF.

* Run and Output option block changes
      IF p_test = abap_true AND ( screen-group1 = 'BAC' OR
                                  screen-group1 = 'FOR' OR
                                  screen-group1 = 'BGR' ).
        screen-active = '0'.
      ENDIF.

* Run and Output option block changes
      IF p_update = abap_true AND p_fore = abap_true AND screen-group1 = 'BAC'.
        screen-active = '0'.
      ENDIF.

* Run and Output option block changes
      IF p_update = abap_true AND p_back = abap_true AND screen-group1 = 'TXT'.
        screen-active = '0'.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ENDMETHOD.
  METHOD download_excel_template.
* Get desktop location.
    get_desktop_location(
      IMPORTING
        ev_desktop_loc = DATA(lv_desktop_loc) ).

    DATA(lv_path) = COND #(
                   WHEN p_bat = abap_true
                         THEN |{ lv_desktop_loc }{ '\BATCH_CREATE_' }{ sy-datum }_{ sy-timlo }|
                   WHEN p_goods = abap_true
                         THEN |{ lv_desktop_loc }{ '\GOODS_RECEIPT_' }{ sy-datum }_{ sy-timlo }|
                   WHEN p_goodre = abap_true
                         THEN |{ lv_desktop_loc }{ '\GOODS_RECEIPT_REV_' }{ sy-datum }_{ sy-timlo }|
                   WHEN p_uni = abap_true
                         THEN |{ lv_desktop_loc }{ '\HANDLING_UNIT_REV_' }{ sy-datum }_{ sy-timlo }|
                         ).

    go_inventory_conversion->excel_create_template(
      EXPORTING
        iv_path     = CONV localfile( lv_path )
        iv_prod     = p_prod ).
  ENDMETHOD.
  METHOD button_event.
    CASE sscrfields-ucomm.
      WHEN 'FC01'.
        lcl_inventory_conv=>download_excel_template( ).
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD get_desktop_location.
    cl_gui_frontend_services=>get_desktop_directory(
      CHANGING
        desktop_directory    = ev_desktop_loc
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        not_supported_by_gui = 3
        OTHERS               = 4 ).
    IF sy-subrc <> 0.
      " Failed to get desktop directory
      MESSAGE e001(zdl_c10156).
    ENDIF.

    cl_gui_cfw=>flush(
      EXCEPTIONS
        cntl_system_error = 1
        cntl_error        = 2
        OTHERS            = 3 ).
    IF sy-subrc <> 0.
      "Exception in method - cl_gui_cfw=>flush
      MESSAGE e002(zdl_c10156).
    ENDIF.
  ENDMETHOD.
  METHOD drop_down.
* Local Constant declaration.
    CONSTANTS: lc_c10156 TYPE zcatgory            VALUE 'C10156',
               lc_load   TYPE zsp_highval         VALUE 'LOAD',
               lc_c      TYPE dfies-fieldname     VALUE 'C',
               lc_prod   TYPE help_info-dynprofld VALUE 'P_PROD',
               lc_s      TYPE ddbool_d            VALUE 'S'.
*p_prod
    SELECT lowval
      FROM zdl_fields
      INTO TABLE @DATA(lt_lowval)
      WHERE category = @lc_c10156 AND
            highval  = @lc_load.
    IF sy-subrc = 0.
      CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
        EXPORTING
          retfield    = lc_c "'C'
          dynpprog    = sy-cprog
          dynpnr      = sy-dynnr
          dynprofield = lc_prod "'P_PROD'
          value_org   = lc_s "'S'
        TABLES
          value_tab   = lt_lowval.
    ELSE.
      MESSAGE s066(zdl_c10156) DISPLAY LIKE 'E'.
    ENDIF.
  ENDMETHOD.
  METHOD file_f4_help.
* Local variable declaration
    DATA: lv_gui_extension  TYPE string,
          lv_gui_ext_filter TYPE string.

* Method to display application server file
    cl_rsan_ut_files=>f4(
      EXPORTING
        i_applserv              = iv_path_flag
        i_title                 = CONV string( TEXT-003 )
        i_gui_extension         = lv_gui_extension
        i_gui_ext_filter        = lv_gui_ext_filter
      IMPORTING
        e_canceled              = DATA(lv_cancel)
      CHANGING
        c_file_name             = cv_field_name
      EXCEPTIONS
        failed                  = 1
        OTHERS                  = 2 ).

    IF sy-subrc = 0 AND lv_cancel = abap_true.
      lcl_inventory_conv=>default_screen_value(
        IMPORTING
          ev_app_file_path     = p_serv ).
    ENDIF.
  ENDMETHOD.
  METHOD display.
    DATA: lt_success_error_data_ref TYPE REF TO data.
    FIELD-SYMBOLS: <lt_success_error_alv_table> TYPE STANDARD TABLE.

* If there is no data, then do not proceed to the next ALV screen.
* give an error message and return
    lt_success_error_data_ref = zcl_dl_c10156_inventory_conv=>mo_excel_data.
    ASSIGN lt_success_error_data_ref->* TO <lt_success_error_alv_table>.
    IF <lt_success_error_alv_table> IS INITIAL.
      MESSAGE s045(zdl_c10156) DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.
    IF sy-batch = abap_true.
      lcl_inventory_conv=>display_success_error_data( ).
    ELSE.
* Call Screen 900 for displaying the data
      CALL SCREEN 9000.
    ENDIF.

  ENDMETHOD.
  METHOD pai_event.
    CASE sy-ucomm.
      WHEN 'BACK' OR 'CANCEL'.
        LEAVE TO SCREEN 0.
      WHEN 'EXIT'.
        LEAVE PROGRAM.
      WHEN OTHERS.
        RETURN.
    ENDCASE.
  ENDMETHOD.
  METHOD display_success_error_data.
* Local reference declaration
    DATA: lt_success_error_data_ref TYPE REF TO data.

* Local field symbol declaration
    FIELD-SYMBOLS: <lt_success_error_alv_table> TYPE STANDARD TABLE.

* At this stage, we will have the reference with data.
    lt_success_error_data_ref = zcl_dl_c10156_inventory_conv=>mo_excel_data.

* Get the data into an internal table from the reference
    ASSIGN lt_success_error_data_ref->* TO <lt_success_error_alv_table>.

* Decide the container in which the data has to be displayed
    IF p_alv_t = abap_true.
      DATA(lo_container) = go_left_container.
    ELSE.
      lo_container = go_bottom_container.
    ENDIF.

* Call the method to diplay the data.
    TRY.
        CALL METHOD cl_salv_table=>factory
          EXPORTING
            r_container  = lo_container
          IMPORTING
            r_salv_table = DATA(lo_left_table)
          CHANGING
            t_table      = <lt_success_error_alv_table>.
      CATCH cx_salv_msg INTO DATA(lo_msg).
        DATA(lv_text) = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.

* Set the header text for the ALV
    set_header(
      EXPORTING
        iv_header_text = TEXT-002
      CHANGING
        co_alv      = lo_left_table ).

* Set the coloumn in the ALV display
    set_column(
      CHANGING
        co_alv                = lo_left_table
        ct_success_error_data = <lt_success_error_alv_table> ).

* Set layout for ALV
    set_layout(
      CHANGING
        co_alv = lo_left_table ).

* Set standard functions for the ALV
    set_functions(
    CHANGING
      co_alv = lo_left_table ).

* add sort
    add_sort(
      CHANGING
        co_alv = lo_left_table ).

* Display the data
    lo_left_table->display( ).
  ENDMETHOD.
  METHOD display_translation_data.
* Local reference declaration
    DATA: lt_translation_data_ref TYPE REF TO data.

* Local field symbol declaration
    FIELD-SYMBOLS: <lt_translation_alv_table> TYPE STANDARD TABLE.

* This is only applicable if the Transation data is checked in the screen
    CHECK p_alv_t = abap_true.

* At this stage, we will have the reference with data.
    lt_translation_data_ref = zcl_dl_c10156_inventory_conv=>mo_translation_data.

* Get the data into an internal table from the reference
    ASSIGN lt_translation_data_ref->* TO <lt_translation_alv_table>.

* Call the method to diplay the data.
    TRY.
        CALL METHOD cl_salv_table=>factory
          EXPORTING
            r_container  = go_right_container
          IMPORTING
            r_salv_table = DATA(lo_right_table)
          CHANGING
            t_table      = <lt_translation_alv_table>.
      CATCH cx_salv_msg INTO DATA(lo_msg1).
        DATA(lv_text) = lo_msg1->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.

* Set the header text for the ALV
    set_header(
      EXPORTING
        iv_header_text = TEXT-001
      CHANGING
        co_alv      = lo_right_table ).

* Set the coloumn in the ALV display
    set_column_optimize(
      IMPORTING
        eo_columns = DATA(lo_colomns)
      CHANGING
        co_col_opt = lo_right_table ).

* Set the coloumn text in the ALV display
    set_trans_coloumn_text(
      CHANGING
        co_columns = lo_colomns ).

* Set layout for ALV
    set_layout(
      CHANGING
        co_alv = lo_right_table ).

* Set standard functions for the ALV
    set_functions(
      CHANGING
        co_alv = lo_right_table ).

* add sort
    add_sort(
      CHANGING
        co_alv = lo_right_table ).

* Display the data
    lo_right_table->display( ).
  ENDMETHOD.
  METHOD add_toolbar.
* Adding a custom tool bar in the selection screen.
    DATA(ls_toolbar) = VALUE smp_dyntxt( text      = TEXT-s14
                                         icon_id   = icon_create
                                         icon_text = TEXT-s14
                                         quickinfo = TEXT-s14 ).
    sscrfields-functxt_01 = ls_toolbar.
  ENDMETHOD.
  METHOD set_column.
    set_column_optimize(
      IMPORTING
        eo_columns = DATA(lo_coloumns)
      CHANGING
        co_col_opt = co_alv ).

    hide_coloumn(
      CHANGING
        co_columns = lo_coloumns ).

    set_colors(
      CHANGING
        co_columns            = lo_coloumns
        ct_success_error_data = ct_success_error_data ).

    set_coloumn_text(
      CHANGING
        co_columns            = lo_coloumns ).
  ENDMETHOD.
  METHOD set_column_optimize.
    eo_columns = co_col_opt->get_columns( ).
    eo_columns->set_optimize( abap_true ).
  ENDMETHOD.
  METHOD hide_coloumn.
    TRY .
        DATA(lo_visibility) = CAST cl_salv_column_table( co_columns->get_column( columnname = 'SUCCESS' ) ).
        lo_visibility->set_visible( value = if_salv_c_bool_sap=>false ).
      CATCH cx_salv_not_found INTO DATA(lo_msg).
        DATA(lv_text) = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.
  ENDMETHOD.
  METHOD set_colors.
* Local table type declaration
    DATA: lt_t_color TYPE lvc_t_scol.

* Local field symbol declaration
    FIELD-SYMBOLS: <ls_success_error_alv_table> TYPE any.

* Apply color to the entire row
    LOOP AT ct_success_error_data ASSIGNING <ls_success_error_alv_table>.

* Get the Success value. the logic is, that if the message coloumn is filled,
* then it is a error record, if it is empty, then it is success record.
      ASSIGN COMPONENT 'SUCCESS'
              OF STRUCTURE <ls_success_error_alv_table>
              TO FIELD-SYMBOL(<ls_success>).

      ASSIGN COMPONENT 'COLOR'
              OF STRUCTURE <ls_success_error_alv_table>
              TO FIELD-SYMBOL(<ls_color>).

      IF <ls_success> IS INITIAL.
* Applu red color to the error row
        APPEND VALUE #( color-col = col_negative
                        color-int = space
                        color-inv = space ) TO lt_t_color.
      ENDIF.

      <ls_color> = lt_t_color.
      CLEAR lt_t_color.
    ENDLOOP.

*   We will set this COLOR to the internal table
    TRY.
        co_columns->set_color_column( 'COLOR' ).
      CATCH cx_salv_data_error INTO DATA(lo_exception).
        DATA(lv_message) = lo_exception->get_text( ).
        MESSAGE lv_message TYPE 'W'.
    ENDTRY.
  ENDMETHOD.
  METHOD set_layout.
* Set layout
    DATA(lo_layout) = co_alv->get_layout( ).
    lo_layout->set_key( VALUE salv_s_layout_key( report = sy-repid ) ).
    lo_layout->set_save_restriction( if_salv_c_layout=>restrict_none ).

*   set initial Layout
    lo_layout->set_default( if_salv_c_bool_sap=>true ).
  ENDMETHOD.
  METHOD set_functions.
* activate ALV generic Functions
    DATA(lo_functions) = co_alv->get_functions( ).
    lo_functions->set_all( abap_true ).
  ENDMETHOD.
  METHOD set_header.
    DATA(lo_display) = co_alv->get_display_settings( ).
    lo_display->set_striped_pattern( cl_salv_display_settings=>true ).
    lo_display->set_list_header( iv_header_text ).
  ENDMETHOD.
  METHOD set_coloumn_text.
* This method will give us the table field in a sequential order
    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
         EXPORTING
           iv_group = 'DELIVER'
           iv_groupset = p_prod
         IMPORTING
           et_fields_in_order = DATA(lt_fields_in_order) ).

* Get field text for each field from the data element maitained and from
* CABN table
    get_fields_text(
      EXPORTING
        it_fields_in_order = lt_fields_in_order
      IMPORTING
        et_fields          = DATA(lt_fieldnames) ).

* set each field description to the respective field
    LOOP AT lt_fieldnames INTO DATA(ls_fieldnames).
      DATA(ls_text_field) = VALUE #( lt_fields_in_order[ sy-tabix ] OPTIONAL ).
      TRY.
          DATA(lo_col) = co_columns->get_column( ls_text_field-zzkey2 ).
          lo_col->set_fixed_header_text( 'L' ).
          lo_col->set_long_text( CONV #( ls_fieldnames-zzkey2 ) ).

        CATCH cx_salv_not_found INTO DATA(lo_exception).
          DATA(lv_message) = lo_exception->get_text( ).
          MESSAGE lv_message TYPE 'W'.
      ENDTRY.
      CLEAR:ls_text_field.
    ENDLOOP.
  ENDMETHOD.
  METHOD get_fields_text.
* Local type declaration
    TYPES: BEGIN OF ty_s_rollname,
             rollname TYPE rollname,
           END OF ty_s_rollname,

* Local table type declaration
           ty_t_rollname TYPE STANDARD TABLE OF ty_s_rollname WITH EMPTY KEY.

    CLEAR et_fields.

* Separate into 2 internal tables.
*1. Field with data element
*2. Field with Char element
    DATA(lt_data_element) = it_fields_in_order.
    DELETE lt_data_element WHERE zzvalue5 IS INITIAL.

    DATA(lt_char) = it_fields_in_order.
    DELETE lt_char WHERE zzvalue5 IS NOT INITIAL.

    DATA(lt_rollname) = VALUE ty_t_rollname( FOR ls_data_element IN lt_data_element
                                          ( rollname = ls_data_element-zzvalue5 ) ).
* Select all data element description.
    IF lt_rollname IS NOT INITIAL.
      SELECT rollname,
             ddtext
        FROM dd04t
        INTO TABLE @DATA(lt_de_description)
        FOR ALL ENTRIES IN @lt_rollname
        WHERE rollname = @lt_rollname-rollname AND
              ddlanguage = @sy-langu.
      IF sy-subrc <> 0.
        CLEAR lt_de_description.
      ENDIF.
    ENDIF.

* Get characteristics field description.
    IF lt_char IS NOT INITIAL.
      SELECT atinn,
             adzhl,
             atnam
        FROM cabn
        INTO TABLE @DATA(lt_cban)
        FOR ALL ENTRIES IN @lt_char
        WHERE atnam = @lt_char-zzkey2.
      IF sy-subrc = 0.
        SELECT atinn,
               adzhl,
               atbez
          FROM cabnt
          INTO TABLE @DATA(lt_char_description)
          FOR ALL ENTRIES IN @lt_cban
          WHERE atinn = @lt_cban-atinn AND
                spras = @sy-langu       AND
                adzhl = @lt_cban-adzhl.
        IF sy-subrc <> 0.
          CLEAR lt_char_description.
        ENDIF.
      ENDIF.
    ENDIF.

** Get the required field names for upload template.
    LOOP AT it_fields_in_order INTO DATA(ls_fields_in_order).
* Read table with data element available.
      DATA(ls_de_description) = VALUE #( lt_de_description[
                                        rollname = ls_fields_in_order-zzvalue5 ]
                                                 OPTIONAL ).
      IF ls_de_description IS NOT INITIAL.
        APPEND VALUE #( zzkey2 = ls_de_description-ddtext ) TO et_fields.
      ELSE.
* Read CABN table to get the characterisitcs ID
        DATA(ls_cabn) = VALUE #( lt_cban[ atnam = ls_fields_in_order-zzkey2 ] OPTIONAL ).
        IF ls_cabn IS NOT INITIAL.
* Read characterisitcs description table.
          DATA(ls_char_description) = VALUE #( lt_char_description[ atinn = ls_cabn-atinn
                                                                    adzhl = ls_cabn-adzhl ] OPTIONAL ).
          IF ls_char_description IS NOT INITIAL.
            APPEND VALUE #( zzkey2 = ls_char_description-atbez ) TO et_fields.
          ENDIF.
        ELSE.
          APPEND VALUE #( zzkey2 = ls_fields_in_order-zzkey2 ) TO et_fields.
        ENDIF.
      ENDIF.
      CLEAR: ls_de_description,
             ls_cabn,
             ls_char_description.
    ENDLOOP.
  ENDMETHOD.
  METHOD set_trans_coloumn_text.
* Local variable declaration
    DATA: lv_name TYPE lvc_fname,
          lv_text TYPE scrtext_l.

* This method will give us the table field in a sequential order
    zcl_dl_c10156_inventory_conv=>get_fields_in_order(
         EXPORTING
           iv_group = 'DELIVER'
           iv_groupset = p_prod
         IMPORTING
           et_fields_in_order = DATA(lt_fields_in_order) ).

* Get field text for each field from the data element maitained and from
* CABN table
    get_fields_text(
      EXPORTING
        it_fields_in_order = lt_fields_in_order
      IMPORTING
        et_fields          = DATA(lt_fieldnames) ).

* set each field description to the respective field
    LOOP AT lt_fieldnames INTO DATA(ls_fieldnames).
      DATA(ls_text_field) = VALUE #( lt_fields_in_order[ sy-tabix ] OPTIONAL ).
      TRY.
          DATA(lo_col) = co_columns->get_column( ls_text_field-zzkey2 ).
          lo_col->set_fixed_header_text( 'L' ).
          lo_col->set_long_text( CONV #( ls_fieldnames-zzkey2 ) ).

        CATCH cx_salv_not_found INTO DATA(lo_exception).
          DATA(lv_message) = lo_exception->get_text( ).
          MESSAGE lv_message TYPE 'W'.
      ENDTRY.

      IF ls_text_field-zzkey3 = abap_true OR
         ls_text_field-zzvalue2 IS NOT INITIAL OR
         ls_text_field-zzvalue3 IS NOT INITIAL.
        lv_name = |{ ls_text_field-zzkey2 }{ '_NEW' }|.
        lv_text = |{ ls_fieldnames-zzkey2 } { 'New' }|.
        TRY.
            lo_col = co_columns->get_column( lv_name ).
            lo_col->set_fixed_header_text( 'L' ).
            lo_col->set_long_text( lv_text ).
          CATCH cx_salv_not_found INTO lo_exception.
            lv_message = lo_exception->get_text( ).
            MESSAGE lv_message TYPE 'W'.
        ENDTRY.
      ENDIF.
      CLEAR: lv_name,
             lv_text,
             ls_text_field.
    ENDLOOP.
  ENDMETHOD.
  METHOD default_screen_value.
* Local Constant declaration.
    CONSTANTS: lc_c10156 TYPE zcatgory            VALUE 'C10156',
               lc_load   TYPE zsp_highval         VALUE 'LOAD'.

    CLEAR:"ev_app_file_path, " This export parameter should not be cleared as
                              " it has to hold the value
          ev_translations_file,
          ev_error_file,
          ev_success_file.

    DATA(lv_screen_value) = COND string(
                     WHEN p_bat = abap_true
                       THEN TEXT-010
                     WHEN p_goods = abap_true
                       THEN TEXT-011
                     WHEN p_goodre = abap_true
                       THEN TEXT-012
                     WHEN p_uni = abap_true
                       THEN TEXT-013 ).

    DATA(lv_app_file_path) = |/SAPLOCAL/{ sy-sysid }/TEMP/|.

    IF p_serv IS INITIAL.
      ev_app_file_path = lv_app_file_path.
    ENDIF.
    ev_translations_file = |{ lv_app_file_path }{ lv_screen_value }TRANSLATION_{ sy-timlo }_{ sy-datlo }|.
    ev_error_file = |{ lv_app_file_path }{ lv_screen_value }ERROR_{ sy-timlo }_{ sy-datlo }|.
    ev_success_file = |{ lv_app_file_path }{ lv_screen_value }OUTPUT_{ sy-timlo }_{ sy-datlo }|.

    SELECT lowval
      FROM zdl_fields
      INTO TABLE @DATA(lt_lowval)
      WHERE category = @lc_c10156 AND
            highval  = @lc_load.
    IF sy-subrc = 0.
      DATA(lv_count) = lines( lt_lowval ).
      IF lv_count = 1.
        p_prod = VALUE #( lt_lowval[ 1 ]-lowval OPTIONAL ).
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD create_container.
* Create docking container for full size screen
    full_doc_container( ).
* Create splitter container for Header and ALV
    horizontal_splitter_for_header( ).
* plitter container for ALV
    vertical_splitter_for_alv( ).
  ENDMETHOD.
  METHOD full_doc_container.
    IF go_docking_container IS NOT BOUND.
      go_docking_container = NEW cl_gui_docking_container(
        repid                   = sy-repid
        dynnr                   = '9000'
        extension               = '2000'
        style                   = cl_gui_control=>ws_child ).
    ENDIF.
  ENDMETHOD.
  METHOD horizontal_splitter_for_header.
*- Create Docking Container
    CREATE OBJECT go_splitter_container
      EXPORTING
        parent  = go_docking_container
        rows    = 2
        columns = 1.
*- Set column Mode
    CALL METHOD go_splitter_container->set_column_mode
      EXPORTING
        mode = go_splitter_container->mode_absolute.

*- Set Row Hight
    CALL METHOD go_splitter_container->set_row_height
      EXPORTING
        id     = 1
        height = '13'.

*- Set column to moveable, visible, style
    CALL METHOD go_splitter_container->set_column_sash
      EXPORTING
        id    = 1
        type  = 1
        value = 1.
*- Container for Header area
    CALL METHOD go_splitter_container->get_container
      EXPORTING
        row       = 1
        column    = 1
      RECEIVING
        container = go_top_container.
*- Container for ALV Data area
    CALL METHOD go_splitter_container->get_container
      EXPORTING
        row       = 2
        column    = 1
      RECEIVING
        container = go_bottom_container.
  ENDMETHOD.
  METHOD vertical_splitter_for_alv.
    CHECK p_alv_t = abap_true.
    CREATE OBJECT go_splitter_con_vert
      EXPORTING
        parent  = go_bottom_container
        rows    = 1
        columns = 2.

    CALL METHOD go_splitter_con_vert->set_row_height
      EXPORTING
        id     = 1
        height = '120'.
*- Moveable, visible, style
    CALL METHOD go_splitter_con_vert->set_row_sash
      EXPORTING
        id    = 1
        type  = 1
        value = 1.
    go_splitter_con_vert->get_container(
      EXPORTING
        row       = 1
        column    = 1
      RECEIVING
        container = go_left_container ).

    go_splitter_con_vert->get_container(
      EXPORTING
        row       = 1
        column    = 2
      RECEIVING
        container = go_right_container ).
  ENDMETHOD.
  METHOD create_header_area_layout.
* Local reference declaration
    DATA: lt_success_error_data_ref TYPE REF TO data.
    DATA: lv_error TYPE i,
          lv_text  TYPE string.
* Local field symbol declaration
    FIELD-SYMBOLS: <lt_success_error_alv_table> TYPE STANDARD TABLE.

* At this stage, we will have the reference with data.
    lt_success_error_data_ref = zcl_dl_c10156_inventory_conv=>mo_excel_data.

* Get the data into an internal table from the reference
    ASSIGN lt_success_error_data_ref->* TO <lt_success_error_alv_table>.

    LOOP AT <lt_success_error_alv_table> ASSIGNING FIELD-SYMBOL(<ls_success_error>).
      ASSIGN COMPONENT 'SUCCESS'
             OF STRUCTURE <ls_success_error>
             TO FIELD-SYMBOL(<lv_success>).
      IF <lv_success> IS INITIAL.
        lv_error = lv_error + 1.
      ENDIF.
    ENDLOOP.

    DATA(lv_total_lines) = lines( <lt_success_error_alv_table> ).

* Create instance for the hader ALV layout
    go_dd_doc_hdr = NEW #( ).

* Add header(Title) to the ALV
    add_header_text( ).

    go_dd_doc_hdr->add_form(
      IMPORTING
        formarea  = DATA(lo_form) ).

    lo_form->new_line( repeat = 1 ).

* Add field Total Number of Records:
    add_text_input(
      EXPORTING
        iv_field_text = TEXT-008
        io_form_area  = lo_form
        iv_value      = CONV sdydo_text_element( lv_total_lines ) ).

* Add space between the fields
    lo_form->add_gap(
      EXPORTING
        width      = '10' ).

* Add field Total Number Error of Records:
    add_text_input(
      EXPORTING
        iv_field_text = TEXT-014
        io_form_area  = lo_form
        iv_value      = CONV sdydo_text_element( lv_error ) ).

*    lo_form->new_line( repeat = 0 ).
* Add space between the fields
    lo_form->add_gap(
      EXPORTING
        width      = '10' ).

    CASE lv_error.
      WHEN 0.
        IF p_test IS INITIAL.
          lv_text = space.
        ELSE.
          lv_text = TEXT-015.
        ENDIF.
      WHEN OTHERS.
        IF p_test IS INITIAL.
          lv_text = p_error.
        ELSE.
          lv_text = TEXT-015.
        ENDIF.
    ENDCASE.
* Add field Error File Path:
    add_text_input(
      EXPORTING
        iv_field_text = TEXT-009
        io_form_area  = lo_form
        iv_value      = CONV sdydo_text_element( lv_text ) ).


    go_dd_doc_hdr->merge_document( ).

    go_dd_doc_hdr->display_document(
      EXPORTING
        parent    = go_top_container ).
  ENDMETHOD.
  METHOD add_header_text.
    go_dd_doc_hdr->add_table(
      EXPORTING
        no_of_columns               = 1
        border                      = '0'
        width                       = '100%'
      IMPORTING
        table                       = DATA(lo_table) ).

    lo_table->add_column(
      EXPORTING
        width  = '43%' ).

    lo_table->add_column(
      EXPORTING
        width               = '500'
      IMPORTING
        column              = DATA(lo_coloumn_word) ).

    DATA(lv_header_text) = COND string( WHEN p_bat = abap_true
                                         THEN TEXT-004
                                        WHEN p_goods = abap_true
                                         THEN TEXT-005
                                        WHEN p_goodre = abap_true
                                         THEN TEXT-006
                                        WHEN p_uni = abap_true
                                         THEN TEXT-007 ).

*    DATA(lv_header) = |<b><span style="background-color:#cfccf3"> { lv_header_text } </span></b>|.
*    DATA(lv_header) = |<b><span style="background-color: #9999ff;">{ lv_header_text } </span></b>|.
    DATA(lv_header) = |<b><span style="color: #9999ff;">{ lv_header_text } </span></b>|.

    lo_coloumn_word->add_static_html(
      EXPORTING
        string_with_html = lv_header ).

    lo_coloumn_word->new_line( ).
  ENDMETHOD.
  METHOD add_text_input.
    io_form_area->add_text(
      EXPORTING
        text          = iv_field_text
        sap_emphasis  = cl_dd_document=>strong ).

    io_form_area->add_gap( ).

    io_form_area->add_text(
      EXPORTING
        text          = iv_value ).
  ENDMETHOD.
  METHOD shcedule_background.
    CHECK p_update = abap_true AND
          p_back   = abap_true AND
          sy-batch IS INITIAL  AND
          sscrfields-ucomm = 'ONLI'.
    sscrfields-ucomm = 'SJOB'.
  ENDMETHOD.
  METHOD create_insatance.
    lcl_inventory_conv=>go_inventory_conversion = NEW #(
                                          is_input = VALUE #( batch            = p_bat
                                                              goods            = p_goods
                                                              goods_rev        = p_goodre
                                                              hu               = p_uni
                                                              product_type     = p_prod
                                                              posting_date     = p_pdate
                                                              check_inventory  = p_cb_gr
                                                              gr_rev_check     = p_cb_re
                                                              gr_bapi          = p_rb_bpi
                                                              gr_562           = p_rb_562
                                                              local_drive      = p_local
                                                              app_server       = p_app
                                                              local_file_path  = p_loc1
                                                              app_file_path    = p_serv
                                                              test_mode        = p_test
                                                              update_mode      = p_update
                                                              except_proc      = p_excep
                                                              forground        = p_fore
                                                              background       = p_back
                                                              trans_file       = p_trans
                                                              error_file       = p_error
                                                              success_file     = p_succ ) ).
  ENDMETHOD.
  METHOD set_title_bar.
    DATA(lv_screen_value) = COND string(
                     WHEN p_bat = abap_true
                       THEN TEXT-004
                     WHEN p_goods = abap_true
                       THEN TEXT-005
                     WHEN p_goodre = abap_true
                       THEN TEXT-006
                     WHEN p_uni = abap_true
                       THEN TEXT-007 ).
    IF p_test = abap_true.
      DATA(lv_test_mode) = |( Test Mode )|.
    ENDIF.
    SET TITLEBAR 'TITLE_BAR' WITH lv_screen_value lv_test_mode.
  ENDMETHOD.
  METHOD add_sort.
    DATA(lo_groups) = co_alv->get_sorts( ) .
    lo_groups->clear( ).
    TRY.
        lo_groups->add_sort(
       columnname = 'PACKAGE_NUMBER'
       sequence   = if_salv_c_sort=>sort_up ).
      CATCH cx_salv_not_found
            cx_salv_existing
            cx_salv_data_error INTO DATA(lo_msg).

        DATA(lv_text) = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.
  ENDMETHOD.
ENDCLASS.

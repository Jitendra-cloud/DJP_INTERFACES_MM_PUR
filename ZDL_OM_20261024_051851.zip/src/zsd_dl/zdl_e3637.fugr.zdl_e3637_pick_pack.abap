************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         20xx                                       **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Fun. Name: ZDL_E3637_PICK_PACK                      Date: 10/11/2006 *
*                                                                      *
* Programmer  : Savithri Renganathan                                   *
*______________________________________________________________________*
* Description :                                                        *
*  Function to split batch, pick and pack the deliveries               *
*                                                                      *
* Logic:  If you do pick, it automatically does batch split.  Hence    *
* pick the outbound delivery by passing information from inbound       *
* delivery.  Then pack it by using HU information.                     *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
* Date       TPR #/Progr Ch#  Remarks                                  *
* 12/06/2011 CHG#130260        To Roll up the weights from Line item to*
*                              HDR                                     *
* 2/11/2016  ALANKAP: CMS 29123 When creating the multiple outbounds for
*            a single Inbound map the correct items to different       *
*            O/B Deliveries.                                           *
*______________________________________________________________________*

************************************************************************
* External Calls                                                       *
*   Function Modules:                                                  *
*______________________________________________________________________*

FUNCTION zdl_e3637_pick_pack .
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_INB_VBELN) LIKE  LIKP-VBELN
*"     REFERENCE(IV_OUT_VBELN) LIKE  LIKP-VBELN
*"  TABLES
*"      ET_MESSAGES TYPE  ZCA_BAL_MSG_TAB
*"  EXCEPTIONS
*"      ERROR_PICK_PACK
*"----------------------------------------------------------------------

************************************************************************
* Local declarations
************************************************************************
  DATA:
    ls_likp     LIKE likp,     "Inb. delivery header
    ls_lips     LIKE lips,     "Inb. delivery item,
    lt_lips     LIKE TABLE OF lips,
    lv_posnr    LIKE lips-posnr,
    ls_messages TYPE bal_s_msg,
    rt_prott    TYPE tab_prott,
    lv_lines    TYPE i.

* Get the picking and packing status of the outbound delivery
* and outbound delivery line item details
  PERFORM get_status     USING iv_out_vbeln
                      CHANGING et_messages[].


* Get inbound delivery details
  PERFORM get_likp   USING  iv_inb_vbeln  "Inb. dlvry
                  CHANGING  ls_likp.  "Inb. dlvry header

  PERFORM get_lips   TABLES lt_lips        "Inb. delivery item
                     USING  iv_inb_vbeln.

* Populate picking idoc header segment of the outbound
* delivery with LIKP value of inbound delivery
  PERFORM pp_build_picking_header_seg
                     TABLES gt_idoc_data40  "Idoc data
                      USING iv_out_vbeln    "Outbound delivery
                            ls_likp         "Inb. delivery info
                   CHANGING gs_idoc_ctrl40.

* Populate picking idoc item segment with LIPS table
* line item details of inbound delivery
  LOOP AT lt_lips INTO ls_lips.
    CLEAR: gv_pick_flag, lv_posnr.                          "CMS 29123
* Check for picking status - whether it is already picked
    PERFORM check_pick       USING ls_lips
                          CHANGING gv_pick_flag
                                   lv_posnr.

* If this line item is already picked, continue with next line item
    CHECK gv_pick_flag IS INITIAL.
    CHECK NOT lv_posnr IS INITIAL.                          "CMS 29123
** The POSNR in the IDoc should always be the first line item;
** it should not increment as in Inbound deliveries
*    IF sy-tabix = 1.
*      lv_posnr = ls_lips-posnr.
*    ENDIF.

    PERFORM pp_build_picking_item_seg
                       TABLES gt_idoc_data40
                        USING iv_out_vbeln    "Outbound delivery
                              lv_posnr        "Outbound delivery item
                              ls_lips.        "Inbound delivery details
  ENDLOOP.

* If idoc_data record contains one more line segment, then continue
* picking
  DESCRIBE TABLE gt_idoc_data40 LINES lv_lines.
  IF lv_lines > 1.

* Pick outbound delivery by calling IDOC_INBOUND_SINGLE
    PERFORM pp_pick_outbound_delivery
                       USING iv_out_vbeln
                             gs_idoc_ctrl40
                    CHANGING et_messages[].

    IF NOT et_messages[] IS INITIAL.
      RAISE error_pick_pack.
    ENDIF.

*** Start of modification by ALANKAP 11/20/2015 "CMS 29123
* Delete any other items from the outbound delivery if it has the
* status ‘A’. To eliminate the issue with blocking the open qty of
* the sales order.  (Out Bound Delivery was getting created against
* all open qty on Sales order because of which multiple Outbound
* deliveries are not created.)
    PERFORM delete_delivery_item
                    USING iv_out_vbeln
                    CHANGING et_messages[].
*** End of modification by ALANKAP 11/20/2015 "CMS 29123
  ENDIF.

* Assigning HU with delivery - Pack
  PERFORM pp_assign_hu_to_delivery
                    TABLES lt_lips
                     USING iv_out_vbeln
                  CHANGING et_messages[].

  IF et_messages[] IS INITIAL.
* Successfully picked and pack the outbound delivery &.
    ls_messages-msgty  = gc_success.
    ls_messages-msgid  = gc_msgid.
    ls_messages-msgno  = '207'.
    ls_messages-msgv1  = iv_out_vbeln.
    ls_messages-msgv2  = gv_idoc_num.
    ls_messages-msgv3  = space.
    ls_messages-msgv4  = space.
    APPEND ls_messages TO et_messages.
    CLEAR  ls_messages.
  ELSE.
    RAISE error_pick_pack.
  ENDIF.


ENDFUNCTION.

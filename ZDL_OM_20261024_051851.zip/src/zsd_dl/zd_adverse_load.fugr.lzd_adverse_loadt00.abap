*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_ADVERSE_LOAD................................*
DATA:  BEGIN OF STATUS_ZDL_ADVERSE_LOAD              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_ADVERSE_LOAD              .
CONTROLS: TCTRL_ZDL_ADVERSE_LOAD
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_ADVERSE_LOAD              .
TABLES: ZDL_ADVERSE_LOAD               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

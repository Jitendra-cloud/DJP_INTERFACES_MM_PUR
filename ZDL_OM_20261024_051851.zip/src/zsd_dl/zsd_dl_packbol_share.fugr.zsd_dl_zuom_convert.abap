FUNCTION zsd_dl_zuom_convert.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**             COPYRIGHT (C) 2005 by INTERNATIONAL PAPER              **
**                     ALL RIGHTS RESERVED                            **
**              REVISIONS COPYRIGHT (C) 20xx, 20yy, 20zz              **
**                    by INTERNATIONAL PAPER                          **
*______________________________________________________________________*
* Program Name: ZSD_DL_F01266_VICS_BOL          Create Date: 11/29/07  *
* Programmer  : Randall Wainwright                                     *
*______________________________________________________________________*
* Description :                                                        *
* Driver program for VICS Bill of Lading.                              *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======      ===========================*
* Randall Wainwright 11/12/07   EDVK958589  Search 'RLW09' in F01266   *
*                               Formatting/legal changes to Smartform  *
*                               Added Ship-From Name                   *
*                               (Manually repacked from EDV 11/29/07)  *
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IV_ZUOM) TYPE  CHAR3
*"  EXPORTING
*"     REFERENCE(OV_MUOM) TYPE  CHAR3
*"  EXCEPTIONS
*"      MAPPING_FAILED
*"----------------------------------------------------------------------

  CONSTANTS: c_zzgroup    LIKE zzxrefdetail-zzgroup VALUE 'OM',
             c_zzgroupset LIKE zzxrefdetail-zzgroupset
                                              VALUE 'SALES_UOM'.

  DATA: x_zzxrefdetail LIKE zzxrefdetail,
        t_zzxrefdetail LIKE zzxrefdetail OCCURS 0.

  DATA: g_zzkey1 LIKE zzxrefdetail-zzkey1.

  CLEAR g_zzkey1.
  CLEAR x_zzxrefdetail.
  REFRESH t_zzxrefdetail.

  g_zzkey1 = iv_zuom.

  SELECT *
    FROM zzxrefdetail
    INTO TABLE t_zzxrefdetail
   WHERE zzgroup    = c_zzgroup
     AND zzgroupset = c_zzgroupset
     AND zzkey1     = g_zzkey1.

  SORT t_zzxrefdetail BY zzvalue1.
  READ TABLE t_zzxrefdetail INTO x_zzxrefdetail INDEX 1.

  IF NOT x_zzxrefdetail-zzvalue1 IS INITIAL.
    ov_muom = x_zzxrefdetail-zzvalue1.
  ELSE.
* If the mapping fails, use the original value.
    ov_muom = iv_zuom.
    RAISE mapping_failed.
  ENDIF.

ENDFUNCTION.

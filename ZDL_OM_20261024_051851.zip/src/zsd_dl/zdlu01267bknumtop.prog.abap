*&---------------------------------------------------------------------*
*&  Include           ZSDU01267BKNUMTOP                                *
*&---------------------------------------------------------------------*
PROGRAM zsdu01267_update_book_num MESSAGE-ID zdl_container.

***********************************************************************
* TABLES                                                              *
***********************************************************************
TABLES: vepo,                  "Packing: Handling Unit Item (Contents)
        zdlu01267_0100.        "screen 0100 fields


***********************************************************************
* CONSTANTS                                                           *
***********************************************************************
CONSTANTS:

  gc_true              TYPE  boolean VALUE 'X'.   "True

***********************************************************************
* TYPE DECLARATIONS                                                   *
***********************************************************************

* Booking header info
TYPES: BEGIN OF ts_book_hdr,
         bookdoc     TYPE zsd_book_hdr-bookdoc,
         werks       type zsd_book_hdr-plant_code,
       END OF ts_book_hdr.
TYPES: tt_book_hdr TYPE TABLE OF ts_book_hdr.

***********************************************************************
* DATA DECLARATIONS                                                   *
***********************************************************************

DATA: BEGIN OF gs_t001w,
        werks TYPE t001w-werks,
        name1 TYPE t001w-name1,
      END OF gs_t001w.

DATA: gs_zvekp     TYPE zdlu01267_vekp, "New/changed values
      gs_old_zvekp TYPE zdlu01267_vekp. "Existing values

DATA:

  ok_code   TYPE char20.

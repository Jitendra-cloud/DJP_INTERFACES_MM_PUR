FUNCTION Z_INTERFACE_GEN_AHD_TICKET .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(INVENTORY_CODE) TYPE  ZZINV
*"     VALUE(IDOC_NUMBER) TYPE  EDI_DOCNUM OPTIONAL
*"     VALUE(MESSAGE_TYPE) TYPE  EDI_MESTYP OPTIONAL
*"     VALUE(RECEIVER_NUMBER) TYPE  EDI_RCVPRN OPTIONAL
*"     VALUE(SENDER_NUMBER) TYPE  EDI_SNDPRN OPTIONAL
*"     VALUE(TEXT_1) TYPE  CHAR50
*"     VALUE(TEXT_2) TYPE  CHAR50 OPTIONAL
*"     VALUE(TEXT_3) TYPE  CHAR50 OPTIONAL
*"     VALUE(TEXT_4) TYPE  CHAR50 OPTIONAL
*"     VALUE(TEXT_5) TYPE  CHAR50 OPTIONAL
*"     VALUE(TEXT_6) TYPE  CHAR50 OPTIONAL
*"  EXCEPTIONS
*"      INVALID_INV_CODE
*"      AHDGRP_NOT_FOUND
*"      INVALID_IDOC_NUMBER
*"      WEBMD_CONNECTION_ERROR
*"----------------------------------------------------------------------
*  CHG103262 E0VK952208 Muthu 07/06/2009 to get correct AHD group
*  using addional  key TEAM field
*// Local variable definitions
data : l_group_name like ZZCONTACT-AHDGROUP,
       l_name like THEAD-TDNAME ,
       l_string(132) ,
       l_pos like sy-fdpos ,
       l_priority(1),
       l_severity(1) ,
       l_message_type type EDI_MESTYP,
       l_receiver type EDI_RCVPRN,
       l_sender type EDI_SNDPRN,
       l_serial_no type EDI_SERIAL ,
       l_return like RFCTEST-RFCDATA1,
       l_idoc_no type EDI_DOCNUM ,
       l_idoc_no_char(16).

constants C_DEST(8) value 'WMBAPI'.  "'WM61BAPI'.

data RFC_MESS(80).

data : l_wmd_sender(10),
       l_text(400) .

data ITAB_LINES like TLINE occurs 1 with header line.

*// 1. Get Functional Area & team name from ZZPRODDOC
     select * up to 1 rows into ZZPRODDOC from ZZPRODDOC
            where ZZINV = INVENTORY_CODE.
     endselect.
     if sy-subrc ne 0.
         raise INVALID_INV_CODE.
     endif.

*// 2. Get AHD group from ZZCONTACT
*// To get correct group use additional Key TEAM
     select single * into ZZCONTACT from ZZCONTACT
            where TEAM = ZZPRODDOC-ZZTEAM "CHG103262 Muthu 07/06/2009
            and AREA = ZZPRODDOC-ZFUNC .
     if sy-subrc = 0.
          l_group_name = ZZCONTACT-AHDGROUP .
     else.
          raise AHDGRP_NOT_FOUND.
     endif.

*// 3. Get Priority & Severity from READ_TEXT

     concatenate ZZPRODDOC-ZZPDOC 'PO' into l_name.

     call function 'READ_TEXT'
       exporting
         CLIENT                        = SY-MANDT
         id                            = 'ZST'
         language                      = 'E'
         name                          = l_name
         object                        = 'ZUPDATE'
*      IMPORTING
*        HEADER                        =
       tables
         lines                         = itab_lines
       EXCEPTIONS
         ID                            = 1
         LANGUAGE                      = 2
         NAME                          = 3
         NOT_FOUND                     = 4
         OBJECT                        = 5
         REFERENCE_CHECK               = 6
         WRONG_ACCESS_TO_ARCHIVE       = 7
         OTHERS                        = 8
               .
     if sy-subrc <> 0.
         l_priority = '2'.
         l_severity = '2'.
     else.
*// Get Priority & Severity from the document in ZZPD
*        read table itab_lines index 1.
       clear : l_priority, l_severity.
       loop at itab_lines.
         l_string = itab_lines-TDLINE.
         condense l_string no-gaps.
         translate l_string to upper case.

         search l_string for 'PRIORITY'.
         if sy-subrc = 0.
              l_pos = sy-fdpos.
              add 8 to l_pos.
              l_priority = l_string+l_pos(1).
         endif.

         search l_string for 'SEVERITY'.
         if sy-subrc = 0.
              l_pos = sy-fdpos.
              add 8 to l_pos.
              l_severity = l_string+l_pos(1).
         endif.
       endloop.

       if l_priority = ' '.
             l_priority = '1'.
       endif.

       if l_severity = ' '.
             l_severity = l_priority.
       endif.
    endif.

*// 4. Get Message Type, Receiver, Sender, and Serial No.
*// If IDOC number is not generated, use import parameters to
*// fill in message_type, receiver, sender fields.  Otherwise,
*// use EDIDC's data
     clear l_idoc_no_char.
     if IDOC_NUMBER is initial.
         l_idoc_no_char = 'Idoc not created'.
         l_message_type = MESSAGE_TYPE .
         l_receiver = RECEIVER_NUMBER .
         l_sender = SENDER_NUMBER .
         l_serial_no = ' '.
     else.
         select single * into EDIDC from EDIDC
              where DOCNUM = IDOC_NUMBER.
         if sy-subrc = 0.
            l_idoc_no = IDOC_NUMBER .
            l_message_type = EDIDC-MESTYP .
            l_receiver = EDIDC-RCVPRN .
            l_sender = EDIDC-SNDPRN .
            l_serial_no = EDIDC-SERIAL .
         else.
            raise INVALID_IDOC_NUMBER.
         endif.
     endif.

*// 5. Call RFC function to send AHD information
*// to Webmethod port

     concatenate sy-sysid sy-mandt into l_wmd_sender.

*// Per WEBMETHODS request, combine all of the error information fields
*// into one 400-char long field.  Right now we only use 386 char
     if l_idoc_no_char eq space.
         concatenate l_idoc_no l_receiver l_sender l_message_type
                   l_serial_no text_1 text_2 text_3 text_4 text_5 text_6
                   into l_text separated by space.
     else.
         concatenate l_idoc_no_char l_receiver l_sender l_message_type
                   l_serial_no text_1 text_2 text_3 text_4 text_5 text_6
                   into l_text separated by space.
     endif.


*// Don't get confused, l_receiver, l_sender, l_serial_no are different
*// from the sender, receiver, and serial_id used in the following
*// function.
*//
*// The l_* are IDOC information, the latter ones are control
*// information needed by WEBMETHODs.


     call function 'Z_AHD_TO_WEBMETHODS'
       DESTINATION  C_DEST
       EXPORTING
*// Control information needed by WEBMETHODS
         sender           = l_wmd_sender
         receiver         = 'AP'
         doctype          = 'APPLICATIONERROR'
         docid            = ' '
         serial_id        = ' '
*// AHD message header
         groupname        =  l_group_name
         priority         =  l_priority
         SEVERITY         =  l_severity
*// AHD message body
         TEXT             =  l_text
*// Fields requested by WEBMETHODS
         KEYID            =  ' '   "//l_group_name
         SEQID            =  ' '   "//'1'

       IMPORTING
         RETURN           =  l_return

*// Exceptions to handle errors
       EXCEPTIONS
         SYSTEM_FAILURE   = 1
            MESSAGE RFC_MESS
         COMMUNICATION_FAILURE = 2
            MESSAGE RFC_MESS
         others = 99.

       if l_return ne 'S'.
            raise WEBMD_CONNECTION_ERROR.
       endif.

ENDFUNCTION.

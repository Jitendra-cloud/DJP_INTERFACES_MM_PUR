*&---------------------------------------------------------------------*
*&  Include           ZDLR02740_CLASS                                  *
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       CLASS gcl_event_handler DEFINITION
*----------------------------------------------------------------------*
CLASS gcl_event_handler DEFINITION.

  PUBLIC SECTION.

    METHODS:

      handle_double_click FOR EVENT double_click OF cl_gui_alv_grid
        IMPORTING e_row
                  e_column
                  es_row_no.

ENDCLASS.                    "gcl_event_handler DEFINITION

*----------------------------------------------------------------------*
*       CLASS gcl_event_handler IMPLEMENTATION
*----------------------------------------------------------------------*
CLASS gcl_event_handler IMPLEMENTATION.

  METHOD handle_double_click.

    PERFORM handle_double_click USING e_row
                                      e_column
                                      es_row_no.

  ENDMETHOD.                    "handle_double_click

ENDCLASS.                    "

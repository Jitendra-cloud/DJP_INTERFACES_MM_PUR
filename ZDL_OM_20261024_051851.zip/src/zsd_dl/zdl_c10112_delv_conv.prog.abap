************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2014 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: Delivery Conversion Program                            *
*                                                                      *
* SAP Name    : ZDL_C10112_DELV_CONV             Create Date: 12/02/14 *
*                                                                      *
* Programmer  : Amit Maole                       Last Update: 12/02/14 *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*                                                                      *
*    This program will be used to populate the booking document number *
*    on the desired in-flight deliveries.  If this field is not        *
*    populated on in flight deliveries, the output for those           *
*    associated shipments when they are executed will not contain      *
*    booking related information.                                      *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* Amit Maole          12/02/14                                         *
*                                                                      *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************

REPORT zdl_c10112_delv_conv NO STANDARD PAGE HEADING MESSAGE-ID zdl_wm.

TABLES: likp,vbuk.

TYPES:BEGIN OF ty_likp_vbuk,
      vbeln TYPE vbeln_vl,
      erdat TYPE erdat,
      lfart TYPE lfart,
      zzfrtfwd TYPE zzfrtfwd,
      zzbooknum TYPE zzbooknum,
      zzbookdoc TYPE z_bookdoc,
      wbstk TYPE wbstk,
      status TYPE char15,
      END OF ty_likp_vbuk.

TYPES:BEGIN OF ty_lips,
      vbeln TYPE vbeln_vl,
      posnr TYPE posnr_vl,
      vgtyp TYPE vgtyp,
      vgbel TYPE vgbel,
      vgpos TYPE vgpos,
      END OF ty_lips.


DATA lt_likp_vbuk TYPE STANDARD TABLE OF ty_likp_vbuk.
DATA lt_lips TYPE STANDARD TABLE OF ty_lips.
DATA ls_lips TYPE ty_lips.


FIELD-SYMBOLS: <fs_likp_vbuk> TYPE ty_likp_vbuk.

* ---------------------------------------------------------------- *
*                           SELECTION SCREEN                       *
* ---------------------------------------------------------------- *
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-t01.
SELECT-OPTIONS s_vbeln FOR likp-vbeln." Delivery
SELECT-OPTIONS s_lfart FOR likp-lfart." Delivery Type
SELECT-OPTIONS s_erdat FOR likp-erdat OBLIGATORY NO-EXTENSION." Created On Date
SELECT-OPTIONS s_zzfrt FOR likp-zzfrtfwd NO-EXTENSION." Freight Forwarder
SELECT-OPTIONS s_bknum FOR likp-zzbooknum NO INTERVALS." Export booking confirmation number
SELECT-OPTIONS s_bkdoc FOR likp-zzbookdoc NO INTERVALS." Booking - Document number
SELECT-OPTIONS s_wbstk FOR vbuk-wbstk NO INTERVALS." Total Goods Movement Status
SELECTION-SCREEN END OF BLOCK b1.

* ----------------------------------------------------------------- *
*                  START OF SELECTION                               *
* ----------------------------------------------------------------- *
START-OF-SELECTION.

  PERFORM get_deliveries.


*&---------------------------------------------------------------------*
*&      Form  GET_DELIVERIES
*&---------------------------------------------------------------------*
FORM get_deliveries.

  SELECT a~vbeln a~erdat a~lfart a~zzfrtfwd a~zzbooknum a~zzbookdoc b~wbstk
         INTO TABLE lt_likp_vbuk
         FROM likp AS a INNER JOIN vbuk AS b
         ON a~vbeln EQ b~vbeln
         WHERE a~vbeln IN s_vbeln AND
               a~erdat IN s_erdat AND
               a~lfart IN s_lfart AND
               b~wbstk IN s_wbstk.



  IF s_zzfrt[] IS NOT INITIAL.
    DELETE lt_likp_vbuk WHERE zzfrtfwd NOT IN s_zzfrt[].
  ENDIF.

  IF s_bknum[] IS NOT INITIAL.
    DELETE lt_likp_vbuk WHERE zzbooknum NOT IN s_bknum[].
  ENDIF.

  IF s_bkdoc[] IS NOT INITIAL.
    DELETE lt_likp_vbuk WHERE zzbookdoc NOT IN s_bkdoc[].
  ENDIF.

  IF lt_likp_vbuk[] IS INITIAL.

*      ERROR MSG
    MESSAGE e000 WITH text-e01.

  ENDIF.
  break amaole1.

  SELECT vbeln posnr vgtyp vgbel vgpos
         INTO TABLE lt_lips
         FROM lips
         FOR ALL ENTRIES IN lt_likp_vbuk
         WHERE vbeln = lt_likp_vbuk-vbeln.

  SORT lt_lips BY vbeln posnr.

  DELETE ADJACENT DUPLICATES FROM lt_lips COMPARING vbeln.

  LOOP AT lt_likp_vbuk ASSIGNING <fs_likp_vbuk>.

*    IF <fs_likp_vbuk>-zzbooknum IS NOT INITIAL.
*      UPDATE likp SET zzbookdoc = <fs_likp_vbuk>-vbeln WHERE vbeln = <fs_likp_vbuk>-vbeln.
*    ENDIF.

* A. Booking already exists
    IF <fs_likp_vbuk>-zzbookdoc IS NOT INITIAL.
      <fs_likp_vbuk>-status = text-002.
      CONTINUE.
    ENDIF.

* B. No delivery line exists
    READ TABLE lt_lips INTO ls_lips WITH KEY vbeln = <fs_likp_vbuk>-vbeln BINARY SEARCH.
    IF sy-subrc NE 0.
      <fs_likp_vbuk>-status = text-003.
      CONTINUE.
    ENDIF.

* C. Ocean delivery doesn't have to updated
    IF ls_lips-vgtyp EQ 'C'.
      <fs_likp_vbuk>-status = text-004.
      CONTINUE.
    ENDIF.

  ENDLOOP.

ENDFORM.                    " GET_DELIVERIES

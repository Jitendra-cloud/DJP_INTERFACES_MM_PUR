FUNCTION z_sd_dl_i2301_input_zvasn.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     VALUE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     VALUE(WORKFLOW_RESULT) LIKE  BDWF_PARAM-RESULT
*"     VALUE(APPLICATION_VARIABLE) LIKE  BDWF_PARAM-APPL_VAR
*"     VALUE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     VALUE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"      ERROR_PROCESSING_IDOC_FUNCTION
*"----------------------------------------------------------------------

*--*
* IDOC - DELVRY03                       Delivery interface
*-----------------------------------------------------------------------
*--*
*   +E1EDL20               Delivery header
*      E1EDL22             Delivery Header Descriptions
*     +E1EDL21             Delivery Header Additional Data
*      E1EDL51             Delivery Header External Release Number
*      E1EDD01             DG header data (delivery)
*      E1EDL18             IDOC: Controlling (Delivery)
*      E1EDL55             IDOC Reference Number
*     + E1ADRM1            Central Address Segment Group, Main Segment
*     + E1EDT13            IDoc: Deadline (delivery)
*     +E1TXTH8             General Text Header
*     +E1EDDH2             IDOC: DG text header (delivery header)
*     +E1EDL33             Export Data Delivery Header
*     +E1EDL28             Routes
*     +E1EDL47             Express Delivery Company's
*                              Tracking Connection Data
*     +E1EDL24             Delivery Item
*      -E1EDL25            Delivery Item Descriptions
*      -E1EDL26            Delivery Item Additional Data
*      -E1EDL52            Delivery Item External Release Number
*      -E1EDL53            Delivery Item POD
*      -E1EDD10            DG item data 1 (delivery)
*      -E1EDD14            DG control data (delivery item)
*      -E1EDL19            IDOC: Controlling (Delivery Item)
*      -E1EDL11            IDOC: Serial Number
*      -E1EDL15            IDOC: Batch Characteristic
*      -E1EDL35            Export Data Delivery Item
*      -E1EDL43            IDoc: Reference
*      -E1EDL41            Reference data ordering party
*      -E1TXTH9            General Text Header
*      -E1EDL12            IDOC: Configuration
*     +E1EDL37             Handling unit header
*      -E1EDL39            Control Segment for Handling Units
*      -E1EDL38            Handling Unit Header Descriptions
*      -E1EDL49            Express Delivery Company's
*                                        Tracking Connection Data
*      -E1EDL44            IDoc: Handling Unit Item (Delivery)
*     +E1EDL54             Repack Handling Units
*
*----------------------------------------------------------------------*
*  TABLES                                                              *
*----------------------------------------------------------------------*
*Note: Please maintain the Change history in include LZSD_DL_VENASN_CL *
*----------------------------------------------------------------------*
* Initialize workflow result
  workflow_result = c_wf_result_ok.
  PERFORM initialization.

* Validate message type
  READ TABLE idoc_contrl INTO gs_idoc_ctrl INDEX 1.

* Begin CR-8050
* Fail the IDOC unconditionally if it is a reversal
  IF gs_idoc_ctrl-mesfct = 'REV'.
*   Read the E1EDL20 to get the BOL no.
    READ TABLE idoc_data INTO gs_idoc_data
         WITH KEY segnam = gc_e1edl20.
    gs_e1edl20 = gs_idoc_data-sdata.
*   Read the E1EDL43 segment to get the PO no.
    READ TABLE idoc_data INTO gs_idoc_data
         WITH KEY segnam = gc_e1edl43.
    gs_e1edl43 = gs_idoc_data-sdata.

    REFRESH idoc_data.

*   Begin BCB10 delete
*   We only want to set the Workflow Result error if this is a Trades
*   ASN1 and we encountered a specific error where we want Workflow to
*   be triggered
**   Error occured
*    workflow_result               = c_wf_result_error.
*    return_variables-wf_param     = c_wf_par_error_idocs.
*    return_variables-doc_number   = gs_idoc_ctrl-docnum.
*    APPEND return_variables.
*   End BCB10 delete

    PERFORM sub_idoc_status_fill USING
        c_idoc_status_error                                 "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '314'                   "err msg
        gs_e1edl20-bolnr                                    "msgv1
        gs_e1edl43-belnr                                    "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        ' '                     "routid
        ' '                     "seg num
        ' '.                    "seg field

    idoc_status[] = gt_idoc_status[].

    RETURN.  "leave function

  ENDIF.    "Reversal Logic

  CASE gs_idoc_ctrl-mescod.
    WHEN gc_ppr.
      gv_parnr_ppr = gc_ppr.

*Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface
    WHEN gc_bzl.
      gv_parnr_bzl = gc_bzl.
* End insert CR#8805/8806   Brazil to SAP ASN interface
    WHEN OTHERS.
      CLEAR: gv_parnr_ppr,gv_parnr_bzl.

  ENDCASE.
* End CR-8050

* Get IDoc data and status records
  gt_idoc_data[]      =  idoc_data[].   "Idoc data table
  gt_idoc_status[]    =  idoc_status[]. "Idoc status table
  gv_idoc_error       =  gc_false.
  gv_inb_vbeln_exists = gc_false.
* Check for message type and process the idoc.

  CASE gs_idoc_ctrl-mestyp.
*Delete  CR#8805/8806 V4.0   EDEK914995
*   This message code is used for Vendor ASN(I2301) and Non OMD ASN
*   process the inbound idoc.
*    WHEN 'ZDL_VASN' OR      "not from Terre Haute or Georgetown
*         'ZDL_NONOMD_ASN'.  "from Terre Haute or Georgetown
*      PERFORM process_idoc.
* End delete  CR#8805/8806 V4.0   EDEK914995

    WHEN 'ZDL_VASN'.       "not from Terre Haute or Georgetown

      PERFORM process_idoc.


*   This message code is used for Portal ASN(E03261).
    WHEN 'ZDL_PASN'.
      PERFORM process_idoc_pasn.

    WHEN 'ZDL_NONOMD_ASN'.  "from Terre Haute or Georgetown or Brazil
      IF gv_parnr_bzl = gc_bzl.   "from Brazil
*Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN interface
* Get Weight of Pallet in LBS.
        PERFORM get_weight_of_pallet.
        PERFORM move_wop_to_all_segments. "WOP = WEIGHT_OF_PALLETS
* Check batch format of all records '6C' and length = 10.
        PERFORM get_batch_format.
* Process Brazil ASN IDoc.
        PERFORM process_idoc_pasn.

* End Insert EDEK914995 CR#8805/8806 V4.0 R14 Brazil to SAP ASN

      ELSE.
        PERFORM process_idoc.   "from Terre Haute or Georgetown
      ENDIF.

*   If any other message, raise an error message
    WHEN OTHERS.
      MESSAGE e029(e0)
            WITH gs_idoc_ctrl-mestyp
               'Function module'(200)
               'Z_SD_DL_I2301_INPUT_ZVASN'
    RAISING wrong_function_called.
  ENDCASE.

* No idoc formatting/validation errors occurred. Use the converted idoc
* data to create the new inbound delivery (if it needs to be created).
  idoc_data[]   = gt_idoc_data[].
  idoc_status[] = gt_idoc_status[].

* If an error occurred, fill the ALE export parameters for an error and
* exit the function module
  IF gv_idoc_error = gc_true.
    REFRESH idoc_data.
*   Begin BCB10 insert
*   We only want to set the Workflow Result error if this is a Trades
*   ASN1 and we encountered a specific error where we want Workflow to
*   be triggered
    IF gv_trigger_wf = gc_true.
*   End BCB10 insert
*     Error occured
      workflow_result               = c_wf_result_error.
      return_variables-wf_param     = c_wf_par_error_idocs.
      return_variables-doc_number   = gs_idoc_ctrl-docnum.
      APPEND return_variables.
    ENDIF. "BCB10 insert
    EXIT.
  ENDIF.


*--> Begin EDVK949484
* If the Inbound Delivery 2 already exists for the key to ZDL_TRADES,
* which is Inbound 1 and PO1, then generate a '53' message stating it
* already exists
  IF gv_trades_asn2 = gc_true AND gv_ib2_exists = gc_true.
*   Inb2 already exists for Inb1 PO1 & & &
    PERFORM sub_idoc_status_fill USING
*------>CMS29286 E0VK9A0IEH 01/20/2016 SMITHAI
*       c_idoc_status_ok                                    "status 53
        c_idoc_status_delete                                "status 68
*<------CMS29286 E0VK9A0IEH 01/20/2016 SMITHAI
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '000'                   "err msg
        text-206                                            "msgv1
        gs_tr_po_h-ib_delivery_2                            "msgv2
        gs_tr_po_h-ib_delivery_1                            "msgv3
        gs_tr_po_h-zz_trnpricepo                            "msgv4
        ' '                                        "routid
        ' '                                        "seg num
        ' '.                                       "seg field

    idoc_status[] = gt_idoc_status[].

    RETURN.  "leave function
  ENDIF.
*--> End EDVK949484


* For a Vendor ASN, a Portal ASN or a Trades ASN1, determine if the
* Inbound Delivery already exists. If so, we do not want to recreate one
  IF gv_trades_asn2 = gc_false.
    IF NOT gt_hu[] IS INITIAL.
** Begin of change by rsured1 for CMS 28753
* Commented below logic
**     Retrieve HU information to determine the HU assignments
*        SELECT exidv     "external HU number
*               vpobj     "type of delivery: 01 = outb; 03 = inb
*               vpobjkey  "delivery number
*          INTO TABLE gt_assign
*          FROM vekp
**        FOR ALL ENTRIES IN gt_hu "by rsured1 for CMS 28753
**        WHERE exidv = gt_hu-exidv "by rsured1 for CMS 28753
*           FOR ALL ENTRIES IN gt_hu_tmp "by rsured1 for CMS 28753
*           WHERE exidv = gt_hu_tmp-batch_num  "by rsured1 for CMS 28753
*            AND inhalt = gt_hu_tmp-exidv "by rsured1 for CMS 28753
*            AND status NE '0060'.    "deleted
*        IF sy-subrc = 0.
*          SORT gt_assign BY vpobj.
**       Determine if any of the HU's is already assigned to an Inbound
**       Delivery. If so, then we don't want to recreate another inbound
*          READ TABLE gt_assign INTO gs_assign
*            WITH KEY vpobj = gc_inbound_delivery
*            BINARY SEARCH.
*          IF sy-subrc = 0.
*            gv_inb_vbeln = gs_assign-vpobjkey.
*          ENDIF.
*        ENDIF.
*      ENDIF. " for gt_hu_tmp initial check

      CLEAR: gs_hu, gs_mbh_tmp, gt_mbh_tmp[].
      SORT gt_mbh BY batch_num.
      LOOP AT gt_hu INTO gs_hu.
        READ TABLE gt_mbh
                      WITH KEY  batch_num = gs_hu-exidv
                      BINARY SEARCH.
        IF sy-subrc = 0.
          gs_mbh_tmp-bolnr  = gt_mbh-bolnr.
          gs_mbh_tmp-exidv    = gt_mbh-exidv.
          APPEND gs_mbh_tmp TO gt_mbh_tmp.
          CLEAR gs_mbh_tmp.
        ENDIF.
      ENDLOOP.

      IF gt_mbh_tmp[] IS NOT INITIAL.
* Query on LIKP,LIPS&VBUK to find if there is
* any inbound deliv created for the BOL
* If yes then do not create new Inbd Deliv
        SELECT a~vbeln
               b~charg
               b~lichn
         INTO TABLE gt_deliv
         FROM likp AS a
         INNER JOIN lips AS b ON a~vbeln = b~vbeln
         INNER JOIN vbuk AS c ON c~vbeln = a~vbeln
         FOR ALL ENTRIES IN gt_mbh_tmp
         WHERE a~bolnr = gt_mbh_tmp-bolnr  "Bol Number
           AND b~lichn = gt_mbh_tmp-exidv  "Vendor batch
           AND wbstk  NE 'C'.         " Total goods movement status
        IF sy-subrc EQ 0.

* Build an internal table gt_hu_tmp so that vendor batch and
* batch declarations match while querying on VEKP using for all entries in
          CLEAR: gs_hu,gs_deliv, gs_hu_tmp, gt_hu_tmp[].
* This logic only applies when there is re-processing happens
* and when there is an issue while HU assignment to created Inbd deliv
* in original processing.
          LOOP AT gt_deliv INTO gs_deliv.
*Delivery already created
            gv_inb_vbeln = gs_deliv-vbeln.  "Assign the delivery no
            gs_hu_tmp-batch_num = gs_deliv-batch_no.
            gs_hu_tmp-exidv    = gs_deliv-lichn.  "
            APPEND gs_hu_tmp TO gt_hu_tmp.
            CLEAR gs_hu_tmp.
          ENDLOOP.
*     Retrieve HU information to determine the HU assignments
          IF gt_hu_tmp[] IS NOT INITIAL.
            SELECT exidv
                   vpobj
                   vpobjkey
                INTO TABLE gt_assign
                FROM vekp
                FOR ALL ENTRIES IN gt_hu_tmp
                WHERE exidv = gt_hu_tmp-batch_num
                AND inhalt = gt_hu_tmp-exidv
                AND status NE '0060'.    "deleted
            IF sy-subrc = 0.
              SORT gt_assign BY vpobj.
            ENDIF.
          ENDIF.
        ELSE   . "select on likp/lips/vbuk
* Only when first time processing the select will fail and
* need to populate   gt_assign which will later be used
* when assign HU to inbd deliv
          CLEAR: gs_hu, gs_assign, gt_assign[].
          LOOP AT gt_hu INTO gs_hu.
            gs_assign-exidv = gs_hu-exidv.
            APPEND gs_assign TO gt_assign.
            CLEAR: gs_assign.
          ENDLOOP.
        ENDIF.
      ENDIF.
* End of change by rsured1 for CMS 28753
    ENDIF.
  ENDIF.

* Execute the standard SAP Inbound Delivery create function module if an
* inbound delivery doesn't already exist.
  IF gv_inb_vbeln   IS INITIAL.
*   Create Inbound Delivery
*    CALL FUNCTION 'BORES_IDOC_INPUT_DESADV1'   " TPR# 40946 EDVK982442
    CALL FUNCTION '/SPE/IDOC_INPUT_DESADV1'    " TPR# 40946 EDVK982442
      EXPORTING
        input_method          = input_method
        mass_processing       = mass_processing
      TABLES
        idoc_contrl           = idoc_contrl[]
        idoc_data             = idoc_data[]
        idoc_status           = idoc_status[]
        return_variables      = return_variables
        serialization_info    = serialization_info
      EXCEPTIONS
        wrong_function_called = 1
        OTHERS                = 2.
    IF sy-subrc <> 0.
*     Then there's a error at creation of inbound delivery   " TPR# 40946 EDVK982442
*      MESSAGE e503(e0) WITH 'BORES_IDOC_INPUT_DESADV1'(202) " TPR# 40946 EDVK982442
      MESSAGE e503(e0) WITH '/SPE/IDOC_INPUT_DESADV1'(202)
        RAISING error_processing_idoc_function.
    ELSE.
      COMMIT WORK.
    ENDIF.

*   Attempt to retrieve the Inbound Delivery number if one was created
    READ TABLE idoc_status INTO gs_idoc_status
      WITH KEY msgty = 'S'
* Begin TPR# 40946 EDVK982442
               msgid = 'BORGR'
               msgno = '520'.
*               msgid = 'ME'
*               msgno = '780'.
* End TPR# 40946 EDVK982442
    IF sy-subrc = 0.
      gv_inb_vbeln = gs_idoc_status-msgv1.  " TPR# 40946 EDVK982442
*      gv_inb_vbeln = gs_idoc_status-msgv2.
      PERFORM check_hu_exist.
    ELSEIF gv_trades_asn1 = gc_true.                        "BCB01
*     If the Inbound Delivery 1 could not be created then the BCB01
*     CHECK statement below will prevent a ZDL_TRADES entry   BCB01
*     from being created through subroutine                   BCB01
*     update_zdl_trades_table                                 BCB01
      gv_idoc_error = gc_true.                              "BCB01
    ELSEIF gv_trades_asn2 = gc_true.
*     If this is Trades ASN2 and there was an error creating the
*     inbound delivery 2 (ie idoc created in status 51) then concatenate
*     an asterisk and the idoc number into the ZDL_TRADES-IB_DELIVERY_2
*     field. It will be used in the Goods Receipt function.
      SHIFT gs_idoc_ctrl-docnum LEFT DELETING LEADING '0'.
      CONCATENATE '*'
                  gs_idoc_ctrl-docnum
        INTO gv_inb_vbeln.
    ENDIF.

  ELSE. "this idoc is being reprocessed
    gv_inb_vbeln_exists = gc_true.
  ENDIF.

  CHECK gv_idoc_error = gc_false.


* If Inbound Delivery exists then make sure it is not locked
* Do not assign the HU's to the delivery if it's Trades ASN2 EDVK946089
* which creates Trades Inbound Delivery 2 against PO2.       EDVK946089
  IF NOT gv_inb_vbeln IS INITIAL
    AND gv_trades_asn2 = gc_false.                          "EDVK946089

    PERFORM check_delivery_lock.
*   If errors occurred then add them to idoc_status[] and exit
    IF gv_idoc_error = gc_true.
      idoc_status[] = gt_idoc_status[].
      RETURN.
    ENDIF.

*   Assign the HU's to the Inbound Delivery
    PERFORM assign_hu_to_delivery.
*   If errors occurred OR a '53' created then update idoc status table
    IF NOT gt_idoc_status[] IS INITIAL.
      idoc_status[] = gt_idoc_status[].
    ENDIF.

  ENDIF.

*--> Begin insert EDVK946089
* If this is Trades ASN1 (Inbound Delivery against PO1) or Trades
* ASN2 (Inbound Delivery against PO2) then update ZDL_TRADES with
* specific information
  CHECK gv_idoc_error = gc_false.
  IF gv_trades_asn1 = gc_true OR
     gv_trades_asn2 = gc_true.
*   Update Trades table
    PERFORM update_zdl_trades_table.
    IF gv_idoc_error = gc_true.
      idoc_status[] = gt_idoc_status[].
      RETURN.
    ENDIF.
*   Begin BCB11 insert
*   Trigger the proposed Output Type ZCTA if this is a Trades ASN1
*   (excluding a Manual Trades ASN1). Output Type ZCTA would have
*   already been proposed (set to "send with periodically scheduled job"
*   instead of "Immediate" because we have to wait for table ZDL_TRADES
*   to be updated. The code inside user exit
*   ZSD_DL_I02624_DELVRY03_INCLUDE relies on data in ZDL_TRADES. Our
*   Inbound Delivery is created which triggers Output Type ZCTA (at this
*   point the data is not in ZDL_TRADES) and THEN table ZDL_TRADES is
*   updated. This subroutine allows for ZDL_TRADES to FIRST be updated
*   BEFORE the user exit code in ZSD_DL_I02624_DELVRY03_INCLUDE executes
*   (this user exit code is part of user exit ZXTRKU02 inside SAP
*   function IDOC_OUTPUT_DELVRY which will send an outbound ASN idoc,
*   for Trades ASN1, to our CTA partners).
    IF gv_trades_asn1 = gc_true AND gs_idoc_ctrl-mestyp = 'ZDL_VASN'.
      PERFORM send_trades_asn1_output.
    ENDIF.
*   End BCB11 insert
  ENDIF.
*--> End insert EDVK946089

ENDFUNCTION. "#EC CI_VALPAR

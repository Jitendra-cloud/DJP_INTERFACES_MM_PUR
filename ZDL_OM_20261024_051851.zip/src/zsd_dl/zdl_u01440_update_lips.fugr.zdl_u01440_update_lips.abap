FUNCTION zdl_u01440_update_lips.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IS_VBAK) LIKE  VBAK STRUCTURE  VBAK OPTIONAL
*"     REFERENCE(IS_XVBUK) LIKE  VBUKVB STRUCTURE  VBUKVB OPTIONAL
*"     REFERENCE(IS_YVBUK) LIKE  VBUKVB STRUCTURE  VBUKVB OPTIONAL
*"  TABLES
*"      XLIPS TYPE  SHP_LIPS_T
*"      YLIPS TYPE  SHP_LIPS_T
*"----------------------------------------------------------------------
*______________________________________________________________________*
* Change History:                                                      *
* Programmer Date      CMS       Description                           *
* ========== ======== ======== ========================================*
* AMAOLE1    10/12/18 CMS34366 Fix: Madrid FOC missing MES fields      *
* ALANKAP    5/21/2020 CD 2000008466  Update Metrics indicator         *
* Logic to update the metric indicator to populate values in LIPS table*
*______________________________________________________________________*
************************************************************************

  INCLUDE zsd_dl_u01440_update_lips.



ENDFUNCTION.

FUNCTION Z_GEN_AHD_TICKET_ZZINV6.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IF_INVENTORY_CODE) TYPE  ZZINV6
*"     VALUE(IF_PRIORITY) TYPE  CHAR1 DEFAULT '2'
*"     VALUE(IF_SEVERITY) TYPE  CHAR1 DEFAULT '2'
*"     VALUE(IF_TEXT) TYPE  ZCHAR400
*"     VALUE(IF_USD_GROUP) TYPE  CHAR30 OPTIONAL
*"  EXCEPTIONS
*"      INVALID_INV_CODE
*"      AHDGRP_NOT_FOUND
*"      WEBMD_CONNECTION_ERROR
*"----------------------------------------------------------------------

*// Constants
  CONSTANTS c_dest(8) VALUE 'WMBAPI'.  "'WM61BAPI'.

*// Local variable definitions
  DATA : l_group_name LIKE zzcontact-ahdgroup,
         l_return LIKE rfctest-rfcdata1.

  DATA : l_wmd_sender(10),
*// Per WEBMETHODS request, combine all of the error information fields
*// into one 400-char long field.
         l_ticket_body(400).

* RFC Exception messages
  DATA : rfc_mess(80).

*// 1. Get Functional Area & team name from ZZPRODDOC
  SELECT * UP TO 1 ROWS INTO zzproddoc FROM zzproddoc
         WHERE zzinv = if_inventory_code.
  ENDSELECT.
  IF sy-subrc NE 0.
    RAISE invalid_inv_code.
  ENDIF.

*// 2. Get AHD group from ZZCONTACT
  IF if_usd_group IS INITIAL.
    SELECT SINGLE * INTO zzcontact FROM zzcontact
           WHERE team = zzproddoc-zzteam AND "schalla
           area = zzproddoc-zfunc.

    IF sy-subrc = 0.
      l_group_name = zzcontact-ahdgroup .
    ELSE.
      RAISE ahdgrp_not_found.
    ENDIF.
  ELSE.
    l_group_name = if_usd_group.
  ENDIF.

*// 3. Call RFC function to send AHD information
*// to Webmethod port
  CONCATENATE sy-sysid sy-mandt INTO l_wmd_sender.

*// 4. Populate Ticket Body
  CLEAR l_ticket_body.
  l_ticket_body = if_text.

  CALL FUNCTION 'Z_AHD_TO_WEBMETHODS'
    DESTINATION  c_dest
    EXPORTING
*// Control information needed by WEBMETHODS
      sender           = l_wmd_sender
      receiver         = 'AP'
      doctype          = 'APPLICATIONERROR'
      docid            = ' '
      serial_id        = ' '
*// AHD message header
      groupname        =  l_group_name
      priority         =  if_priority
      severity         =  if_severity
*// AHD message body
      text             =  l_ticket_body
*// Fields requested by WEBMETHODS
      keyid            =  ' '   "//l_group_name
      seqid            =  ' '                               "//'1'
    IMPORTING
      return           =  l_return
    EXCEPTIONS
      system_failure   = 1
         MESSAGE rfc_mess
      communication_failure = 2
         MESSAGE rfc_mess
      OTHERS = 99.
  IF l_return NE 'S'.
    RAISE webmd_connection_error.
  ENDIF.

ENDFUNCTION.

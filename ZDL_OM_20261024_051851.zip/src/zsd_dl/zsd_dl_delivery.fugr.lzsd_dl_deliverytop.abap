FUNCTION-POOL zsd_dl_delivery.              "MESSAGE-ID ..

DATA gv_lineal_char TYPE zsdc_cn.                           "CMS32311
DATA gv_weight_of_roll TYPE zsdc_cn.                        "CMS32311
DATA gt_zdl_fields TYPE STANDARD TABLE OF zdl_fields.       "CMS32311
DATA gv_convert_to_raw TYPE boolean.                        "CMS32568

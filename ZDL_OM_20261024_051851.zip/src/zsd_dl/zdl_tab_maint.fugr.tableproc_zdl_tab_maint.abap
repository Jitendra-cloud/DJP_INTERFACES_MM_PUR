*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_TAB_MAINT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_TAB_MAINT       .

  PERFORM TABLEPROC.

ENDFUNCTION.

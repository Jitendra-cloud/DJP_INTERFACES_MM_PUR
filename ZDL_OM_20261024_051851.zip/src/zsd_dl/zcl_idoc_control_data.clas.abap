class ZCL_IDOC_CONTROL_DATA definition
  public
  final
  create public .

*"* public components of class ZCL_IDOC_CONTROL_DATA
*"* do not include other source files here!!!
public section.

  class-methods READ_PARTNER_DATA
    importing
      value(ELEMENT_NAME) type FIELDNAME
      value(ELEMENT_VALUE) type CHAR30
      value(MESSAGE_TYPE_NAME) type EDI_MESTYP
      !IDOC_TYPE_NAME type EDI_IDOCTP optional
      !EXTENDED_IDOC_NAME type EDI_CIMTYP optional
    exporting
      !RECEIPIENT_PARTNER type EDIPPARNUM
      !RECEIPIENT_TYPE type RCVPRT
    exceptions
      PARTNER_NOT_FOUND .
protected section.
*"* protected components of class ZCL_IDOC_CONTROL_DATA
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IDOC_CONTROL_DATA
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IDOC_CONTROL_DATA IMPLEMENTATION.


METHOD READ_PARTNER_DATA.


  DATA :  WA_PARTNER TYPE ZZALE_PARTNER.


  SELECT  SINGLE RECEIPIENT_PART PARTNER_TYPE IDOC_TYPE INTO
                (WA_PARTNER-RECEIPIENT_PART, WA_PARTNER-PARTNER_TYPE,
                 WA_PARTNER-IDOC_TYPE)
                     FROM ZZALE_PARTNER
                      WHERE FIELDNAME         = ELEMENT_NAME
                      AND   FIELDVALUE        = ELEMENT_VALUE
                      AND   MESSAGE_TYPE      = MESSAGE_TYPE_NAME .

  IF SY-SUBRC <> 0 .
    RAISE PARTNER_NOT_FOUND .

  ELSE.

    IF IDOC_TYPE_NAME <> SPACE.
      CHECK WA_PARTNER-IDOC_TYPE = IDOC_TYPE_NAME .

      RECEIPIENT_PARTNER = WA_PARTNER-RECEIPIENT_PART.
      RECEIPIENT_TYPE    = WA_PARTNER-PARTNER_TYPE .
    ELSE.
      RECEIPIENT_PARTNER = WA_PARTNER-RECEIPIENT_PART.
      RECEIPIENT_TYPE    = WA_PARTNER-PARTNER_TYPE .
    ENDIF.

  ENDIF.

ENDMETHOD.
ENDCLASS.

*&---------------------------------------------------------------------*
*&  Include           LZSD_DL_SORD_TRANSFSUB                           *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  READ_CHARACTERISTIC
*&---------------------------------------------------------------------*
*       Reads the global internal table gt_config for the correct
*   characteristic, formats the value according to the following:
*   1) Left-most string ending in a SPACE is only relevant data
*   2) Commas must be stripped
*   3) Decimals remain where they are
*   4) Oversized strings will be truncated from the right
*----------------------------------------------------------------------*
*      -->LT_CONFIG         Characteristics Table
*      -->P_CHARACTERISTIC  Characteristic name
*      <--P_CHAR_VALUE      Characteristic Value (30 characters)
*----------------------------------------------------------------------*
FORM read_characteristic TABLES lt_config STRUCTURE conf_out
                         USING p_characteristic LIKE conf_out-atnam.

  DATA: l_cha_data    LIKE lt_config-atwrt,
        l_cha_garbage LIKE lt_config-atwrt.

  IF NOT lt_config-atnam = p_characteristic.
    CLEAR: lt_config, l_cha_data, l_cha_garbage.
    READ TABLE lt_config WITH KEY
      atnam = p_characteristic
      BINARY SEARCH.
    IF NOT lt_config IS INITIAL.

* Skipping leading spaces, take the first string, separated by the
*  subsequent string with a space into a new field, throwing out
*  subsequent data. We are only concerned with the first.
      CONDENSE lt_config-atwrt.
      SPLIT lt_config-atwrt AT space INTO l_cha_data l_cha_garbage.

* Remove commas, if applicable
      REPLACE ALL OCCURRENCES OF ',' IN l_cha_data WITH ' '.
      CONDENSE l_cha_data NO-GAPS.

      lt_config-atwrt = l_cha_data.

    ENDIF. " NOT lt_config is initial.

  ENDIF. " NOT lt_config-atnam = p_characteristic.

ENDFORM.                    " READ_CHARACTERISTIC

*&---------------------------------------------------------------------*
*&      Form  get_vbap_data
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_vbap_data TABLES it_zsomtransf STRUCTURE zsomtransf.

  SELECT vbeln posnr arktx cuobj
         FROM vbap
         INTO TABLE gt_vbap
         FOR ALL ENTRIES IN it_zsomtransf
*        Begin BCB01
*         WHERE vbeln EQ it_zsomtransf-vbeln AND
*               posnr EQ it_zsomtransf-posnr.
         WHERE vbeln EQ it_zsomtransf-vbeln_from AND
               posnr EQ it_zsomtransf-posnr_from.
*        End BCB01
ENDFORM.                    " get_vbap_data
*&---------------------------------------------------------------------*
*&      Form  get_cust_info
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IT_ZSOMTRANSF  text
*----------------------------------------------------------------------*
FORM get_cust_info  TABLES it_zsomtransf STRUCTURE zsomtransf.

  CONSTANTS: lc_shipto_partner LIKE vbpa-parvw VALUE 'WE',
             lc_zero_line      LIKE vbpa-posnr VALUE '000000'.

  SELECT vbpa~vbeln
         kna1~kunnr kna1~name1
         INTO TABLE gt_vbpa
         FROM vbpa AS vbpa
         INNER JOIN kna1 AS kna1
         ON vbpa~kunnr = kna1~kunnr
         FOR ALL ENTRIES IN it_zsomtransf
*        Begin BCB01
*         WHERE vbeln EQ it_zsomtransf-vbeln AND
         WHERE vbeln EQ it_zsomtransf-vbeln_from AND
*        End BCB01
               posnr EQ lc_zero_line        AND
               parvw EQ lc_shipto_partner.

ENDFORM.                    "get_cust_info
*&---------------------------------------------------------------------*
*&      Form  get_vc_char
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GS_VBAP_CUOBJ  text
*----------------------------------------------------------------------*
FORM get_vc_char  USING  iv_vbap_cuobj.

  REFRESH gt_config_si.

  CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
    EXPORTING
      instance           = iv_vbap_cuobj
      language           = sy-langu
    TABLES
      configuration      = gt_config_si[]
    EXCEPTIONS
      instance_not_found = 1
      OTHERS             = 2.
  IF sy-subrc EQ 0.
    SORT gt_config_si BY atnam.
    DELETE ADJACENT DUPLICATES FROM gt_config_si COMPARING atnam.
  ENDIF.

ENDFORM.                    " get_vc_char
*&---------------------------------------------------------------------*
*&      Form  get_batch_char
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IT_ZSOMTRANSF_MATNR  text
*      -->P_IT_ZSOMTRANSF_WERKS  text
*      -->P_IT_ZSOMTRANSF_CHARG  text
*----------------------------------------------------------------------*
FORM get_batch_char  USING    iv_matnr
                              iv_werks
                              iv_charg.

  REFRESH gt_config_b.

  CALL FUNCTION 'VB_BATCH_VALUES_FOR_OUTPUT'
    EXPORTING
      material               = iv_matnr
      plant                  = iv_werks
      batch                  = iv_charg
      language               = 'E'
    TABLES
      classification         = gt_config_b
    EXCEPTIONS
      no_classification_data = 1
      OTHERS                 = 2.
  IF sy-subrc = 0.
    SORT gt_config_b BY atnam.
    DELETE ADJACENT DUPLICATES FROM gt_config_b COMPARING atnam.
  ENDIF. " sy-subrc = 0

ENDFORM.                    " get_batch_char
*&---------------------------------------------------------------------*
*&      Form  build_output_file
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_output_file USING is_zsomtransf STRUCTURE zsomtransf
                             iv_label_name
                             iv_bar_file_loc.

* Calculation fields
  DATA: l_int_cast TYPE i,
        l_numerator   LIKE  t006-zaehl,
        l_denominator LIKE  t006-nennr,
        l_fraction TYPE f,
        l_two_char(2). " For 2-character operations

* For splitting VBAP-ARKTX at comma delimiter
  DATA: BEGIN OF lt_split OCCURS 0,
          word(40),
        END OF lt_split,
        l_split_index TYPE i,
        l_desc LIKE gs_output-fieldvalue.

* File header
  CONSTANTS: lc_sentinel(8) VALUE 'SENTINEL'.

  CONSTANTS: lc_bar_file TYPE localfile VALUE 'C:\BAR.BMP',
             lc_equals   VALUE '='.

  CLEAR : gt_output, gs_output.

*** Build label file
* 'SENTINEL' Header
  gs_output-fieldname = lc_sentinel.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*LAB_NAME
  gs_output-fieldname = 'LAB_NAME'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = iv_label_name.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*LABEL_COPY
  gs_output-fieldname = 'LABEL_COPY'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = is_zsomtransf-znumlabels.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*BAR_IMAGE
  gs_output-fieldname = 'BAR_IMAGE'.
  gs_output-equals = lc_equals.
  IF NOT iv_bar_file_loc IS INITIAL.
    gs_output-fieldvalue = iv_bar_file_loc.
  ELSE.
    gs_output-fieldvalue = lc_bar_file.
  ENDIF.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*PACK_NUMBER_ROLLS_IN_PACKAGE
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_rolls_in_package.
  gs_output-fieldname = 'PACK_NUMBER_ROLLS_IN_PACKAGE'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_b-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*PACK_PACKAGE_NET_WT
*PACK_PACKAGE_GROSS_WT
* These two fields will equal each other. If the batch characteristic
*   ROLLS_IN_PACKAGE = 1, then both equal Batch characteristic
*   WEIGHT_OF_ROLL_IN_LBS.
  IF gt_config_b-atwrt+0(30) <= 1. " ROLLS_IN_PACKAGE
    PERFORM read_characteristic TABLES gt_config_b
                                USING zsdc_weight_of_roll_in_lbs.
    gs_output-fieldname = 'PACK_PACKAGE_NET_WT'.
    gs_output-equals = lc_equals.
    l_int_cast = gt_config_b-atwrt+0(10).
    gs_output-fieldvalue = l_int_cast.
    CONDENSE gs_output-fieldvalue.
    APPEND gs_output TO gt_output.
    CLEAR gs_output.
    PERFORM read_characteristic TABLES gt_config_b
                                USING zsdc_weight_of_roll_in_lbs.
    gs_output-fieldname = 'PACK_PACKAGE_GROSS_WT'.
    gs_output-equals = lc_equals.
    l_int_cast = gt_config_b-atwrt+0(10).
    gs_output-fieldvalue = l_int_cast.
    CONDENSE gs_output-fieldvalue.
    APPEND gs_output TO gt_output.
    CLEAR gs_output.
  ELSE.
* Fields will not be sent
    gs_output-fieldname = 'PACK_PACKAGE_NET_WT'.
    gs_output-equals = lc_equals.
    CLEAR gs_output-fieldvalue.
    APPEND gs_output TO gt_output.
    CLEAR gs_output.
    gs_output-fieldname = 'PACK_PACKAGE_GROSS_WT'.
    gs_output-equals = lc_equals.
    CLEAR gs_output-fieldvalue.
    APPEND gs_output TO gt_output.
    CLEAR gs_output.
  ENDIF. " gt_config_b-atwrt+0(30) <= 1. " ROLLS_IN_PACKAGE

*ROLL_BASIS_WEIGHT_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_sales_basis_weight.
  gs_output-fieldname = 'ROLL_BASIS_WEIGHT_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_b-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_CORE_1 (99XXXX format)
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_core_diameter.
  gs_output-fieldname = 'ROLL_CORE_1'.
  gs_output-equals = lc_equals.
  l_int_cast = gt_config_b-atwrt+0(10).

  IF l_int_cast > 99.
    l_two_char = '99'.
  ELSE.
    l_two_char = l_int_cast.
    CONDENSE l_two_char.
    SHIFT l_two_char RIGHT DELETING TRAILING space.
    OVERLAY l_two_char WITH '00'.
  ENDIF.

  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_core_type.
  CONDENSE gt_config_si-atwrt.
  CONCATENATE l_two_char gt_config_si-atwrt+0(4)
         INTO gs_output-fieldvalue.
  CONDENSE gs_output-fieldvalue NO-GAPS.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_CURRENT_DIAMETER_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_roll_diameter.
  gs_output-fieldname = 'ROLL_CURRENT_DIAMETER_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_b-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_CURRENT_WEIGHT_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_weight_of_roll_in_lbs.
  gs_output-fieldname = 'ROLL_CURRENT_WEIGHT_1'.
  gs_output-equals = lc_equals.
  l_int_cast = gt_config_b-atwrt+0(10).
  gs_output-fieldvalue = l_int_cast.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_METRIC_NET_WT_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_roll_weight_metric.
  gs_output-fieldname = 'ROLL_METRIC_NET_WT_1'.
  gs_output-equals = lc_equals.
  l_int_cast = gt_config_b-atwrt+0(10).
  gs_output-fieldvalue = l_int_cast.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_METRIC_GROSS_WT_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_roll_weight_metric.
  gs_output-fieldname = 'ROLL_METRIC_GROSS_WT_1'.
  gs_output-equals = lc_equals.
  l_int_cast = gt_config_b-atwrt+0(10).
  gs_output-fieldvalue = l_int_cast.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_MOISTURE_1 (will not be sent from SAP)
  gs_output-fieldname = 'ROLL_MOISTURE_1'.
  gs_output-equals = lc_equals.
  CLEAR gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_NUMBER_1
  gs_output-fieldname = 'ROLL_NUMBER_1'.
  gs_output-equals = lc_equals.
  CONCATENATE 'XX' is_zsomtransf-charg INTO gs_output-fieldvalue.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_SALES_MATERIAL_NO_1
  gs_output-fieldname = 'ROLL_SALES_MATERIAL_NO_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = is_zsomtransf-matnr.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_SET_POSITION_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_set_position.
  gs_output-fieldname = 'ROLL_SET_POSITION_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_b-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_SIDE_OUT_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_winding_code.
  gs_output-fieldname = 'ROLL_SIDE_OUT_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_b-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_WIDTH_WH_1
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_whole.
  gs_output-fieldname = 'ROLL_WIDTH_WH_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_WIDTH_NUM_1
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_num.
  gs_output-fieldname = 'ROLL_WIDTH_NUM_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_WIDTH_DEN_1
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_den.
  gs_output-fieldname = 'ROLL_WIDTH_DEN_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_WINDER_LINEAL_FOOTAGE_1
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_lineal_footage.
  gs_output-fieldname = 'ROLL_WINDER_LINEAL_FOOTAGE_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_b-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*CUST_ORDER_NUMBER
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_customer_po_number.
  gs_output-fieldname = 'CUST_ORDER_NUMBER'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

  CLEAR gs_vbpa.
* Begin BCB01
*  READ TABLE gt_vbpa INTO gs_vbpa WITH KEY vbeln = is_zsomtransf-vbeln
*                                           BINARY SEARCH.
  READ TABLE gt_vbpa INTO gs_vbpa
    WITH KEY vbeln = is_zsomtransf-vbeln_from
    BINARY SEARCH.
* End BCB01
  IF sy-subrc = 0.
    gs_output-fieldvalue = gs_vbpa-name1.
  ELSE.
    CLEAR gs_output-fieldvalue.
  ENDIF.
  gs_output-fieldname = 'CUST_NAME'.
  gs_output-equals = lc_equals.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OHDR_CUSTOMER_ORDER_NUMBER
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_customer_po_number.
  gs_output-fieldname = 'OHDR_CUSTOMER_ORDER_NUMBER'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OHDR_SHIP_CITY
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_ship_to_city.
  gs_output-fieldname = 'OHDR_SHIP_CITY'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OHDR_ORDER_NUMBER
  gs_output-fieldname = 'OHDR_ORDER_NUMBER'.
  gs_output-equals = lc_equals.
*  gs_output-fieldvalue = is_zsomtransf-vbeln. "BCB01
  gs_output-fieldvalue = is_zsomtransf-vbeln_from.          "BCB01
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_CORE
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_core_diameter.
  gs_output-fieldname = 'OITM_CORE'.
  gs_output-equals = lc_equals.
  l_int_cast = gt_config_si-atwrt+0(10).
  gs_output-fieldvalue = l_int_cast.
  CONDENSE gs_output-fieldvalue.
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_core_type.
  CONCATENATE gs_output-fieldvalue gt_config_si-atwrt+0(10)
         INTO gs_output-fieldvalue SEPARATED BY space.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_CORE_DIAMETER
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_core_diameter.
  gs_output-fieldname = 'OITM_CORE_DIAMETER'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_CUSTOMER_ID
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_sold_to_customer_kunnr.
  gs_output-fieldname = 'OITM_CUSTOMER_ID'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_DIAMETER
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_diameter.
  gs_output-fieldname = 'OITM_DIAMETER'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_DIAMETER_METRIC
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_diameter_metric.
  gs_output-fieldname = 'OITM_DIAMETER_METRIC'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_GRADE_DESC (Derived from VBAP-ARKTX)
  gs_output-fieldname = 'OITM_GRADE_DESC'.
  gs_output-equals = lc_equals.

* Split the description into several fields by comma
* Remove the last two comma delimited fields
* Reassemble description without the trailing two fields
  SPLIT gs_vbap-arktx AT ',' INTO TABLE lt_split.
  DESCRIBE TABLE lt_split LINES l_split_index.
  DELETE lt_split INDEX l_split_index.
  l_split_index = l_split_index - 1.
  DELETE lt_split INDEX l_split_index.
  CLEAR l_desc.
  LOOP AT lt_split.
    IF NOT l_desc IS INITIAL.
      CONCATENATE l_desc lt_split-word INTO l_desc
        SEPARATED BY ', '.
    ELSE.
      l_desc = lt_split-word.
    ENDIF.
  ENDLOOP. " at lt_split.

  gs_output-fieldvalue = l_desc.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_LABEL_BASIS_WEIGHT
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_sales_basis_weight.
  gs_output-fieldname = 'OITM_LABEL_BASIS_WEIGHT'.
  gs_output-equals = lc_equals.
  l_int_cast = gt_config_si-atwrt+0(30).
  gs_output-fieldvalue = l_int_cast.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_MATERIAL_NO
  gs_output-fieldname = 'OITM_MATERIAL_NO'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = is_zsomtransf-matnr.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ORDER_ITEM
  gs_output-fieldname = 'OITM_ORDER_ITEM'.
  gs_output-equals = lc_equals.
* Begin BCB01
*  CONCATENATE is_zsomtransf-vbeln
*              is_zsomtransf-posnr
  CONCATENATE is_zsomtransf-vbeln_from
              is_zsomtransf-posnr_from
* End BCB01
         INTO gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*ROLL_MANUFACTURED_ORDER_ITEM_1
  gs_output-fieldname = 'ROLL_MANUFACTURED_ORDER_ITEM_1'.
  gs_output-equals = lc_equals.
* Begin BCB01
*  CONCATENATE is_zsomtransf-vbeln
*              is_zsomtransf-posnr
  CONCATENATE is_zsomtransf-vbeln_from
              is_zsomtransf-posnr_from
         INTO gs_output-fieldvalue.
* End BCB01
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ORDER_SIDE_OUT
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_winding_code.
  gs_output-fieldname = 'OITM_ORDER_SIDE_OUT'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ROLL_DIAMETER_WH
*OITM_ROLL_DIAMETER_NUM
*OITM_ROLL_DIAMETER_DEN
* Split the original diameter into fractional constituants
  PERFORM read_characteristic TABLES gt_config_b
                              USING zsdc_roll_diameter.

  CLEAR: l_int_cast,
         l_fraction,
         l_numerator,
         l_denominator.
  l_int_cast = TRUNC( gt_config_b-atwrt+0(30) ).
  l_fraction = FRAC( gt_config_b-atwrt+0(30) ).

  IF NOT l_fraction = 0.
    CALL FUNCTION 'CONVERT_TO_FRACTION'
      EXPORTING
        input               = l_fraction
      IMPORTING
        nominator           = l_numerator
        denominator         = l_denominator
      EXCEPTIONS
        conversion_overflow = 1
        OTHERS              = 2.
  ENDIF.

  gs_output-fieldname = 'OITM_ROLL_DIAMETER_WH'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = l_int_cast.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

  gs_output-fieldname = 'OITM_ROLL_DIAMETER_NUM'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = l_numerator.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

  gs_output-fieldname = 'OITM_ROLL_DIAMETER_DEN'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = l_denominator.
  CONDENSE gs_output-fieldvalue.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ROLL_WIDTH_WH
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_whole.
  gs_output-fieldname = 'OITM_ROLL_WIDTH_WH'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ROLL_WIDTH_NUM
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_num.
  gs_output-fieldname = 'OITM_ROLL_WIDTH_NUM'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ROLL_WIDTH_DEN
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_den.
  gs_output-fieldname = 'OITM_ROLL_WIDTH_DEN'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ROLL_WIDTH_METRIC
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_metric.
  gs_output-fieldname = 'OITM_ROLL_WIDTH_METRIC'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_ROLL_WIDTH_CM
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_roll_width_metric.
  gs_output-fieldname = 'OITM_ROLL_WIDTH_CM'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*OITM_SALES_BASIS_WT_METRIC
  PERFORM read_characteristic TABLES gt_config_si
                              USING zsdc_metric_sales_basis_weight.
  gs_output-fieldname = 'OITM_SALES_BASIS_WT_METRIC'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*SPMP_DESC
  gs_output-fieldname = 'SPMP_DESC'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = l_desc.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*SPMP_SALES_PMP
*ROLL_CURRENT_SPMP_1
  PERFORM read_characteristic TABLES gt_config_si
                                USING zsdc_sales_grade.
  gs_output-fieldname = 'SPMP_SALES_PMP'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

  gs_output-fieldname = 'ROLL_CURRENT_SPMP_1'.
  gs_output-equals = lc_equals.
  gs_output-fieldvalue = gt_config_si-atwrt+0(30).
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

*END
  gs_output-fieldname = 'END'.
  APPEND gs_output TO gt_output.
  CLEAR gs_output.

ENDFORM.                    " build_output_file
*&---------------------------------------------------------------------*
*&      Form  download_file
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_FILENAME  text
*----------------------------------------------------------------------*
FORM download_file  USING iv_outfile
                 CHANGING cv_filename.

  CLEAR cv_filename.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = iv_outfile
      filetype                = 'ASC'
    TABLES
      data_tab                = gt_output
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      OTHERS                  = 17.
  IF sy-subrc EQ 0.
    cv_filename = iv_outfile.
  ELSE.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.                    " download_file
*&---------------------------------------------------------------------*
*&      Form  delete_handling_units
*&---------------------------------------------------------------------*
*       Deleting the HU's (and later re-creating) is faster than
*       unpacking them (and later repacking them).
*----------------------------------------------------------------------*
*      -->IT_ZSOMTRANSF  text
*----------------------------------------------------------------------*
FORM delete_handling_units TABLES it_zsomtransf STRUCTURE zsomtransf.

  TYPES: BEGIN OF lts_vekp,
           exidv TYPE exidv,  "External HU Number
         END OF lts_vekp.

  DATA:  lt_vekp TYPE STANDARD TABLE OF lts_vekp,
         ls_vekp TYPE lts_vekp,

         lt_return     TYPE STANDARD TABLE OF bapiret2,
         ls_return     TYPE bapiret2,

         lt_data       TYPE STANDARD TABLE OF zsomtransf,
         ls_data       TYPE zsomtransf.

  DATA : lv_hukey      TYPE exidv,
         lv_text(200)  TYPE c.


* Create work table of data
  lt_data[] = it_zsomtransf[].
  SORT lt_data BY exidv.

* Work table will have unique HU's
  DELETE ADJACENT DUPLICATES FROM lt_data COMPARING exidv.

* Retrieve active HU's based on the work table. For some scenarios, the
* HU may not exist in SAP so we only want to delete the active HU's.
* Whether the HU, form the work table, exists or not we want to add it
* the table of successfully deleted HU's.
  SELECT exidv
         FROM vekp
         INTO TABLE lt_vekp
         FOR ALL ENTRIES IN lt_data
         WHERE exidv  EQ lt_data-exidv AND
               status NE '0060'.     "not deleted
  SORT lt_vekp.

* Process the HU's in the work table
  LOOP AT lt_data INTO ls_data.

*   Determine if the HU exists in SAP
    READ TABLE lt_vekp INTO ls_vekp WITH KEY exidv = ls_data-exidv
                                             BINARY SEARCH.
*   Delete HU if it exists in SAP
    IF sy-subrc EQ 0.

*     Attempt to delete HU
      lv_hukey = ls_data-exidv.
      CLEAR: lt_return.
      CALL FUNCTION 'BAPI_HU_DELETE'
        EXPORTING
          hukey  = lv_hukey
        TABLES
          return = lt_return.

*     A blank return table signifies an issue. Log Error message in main
*     error table if HU Delete failed then continue on with the next HU
*     to delete
      IF lt_return IS INITIAL.
*       HU & was not deleted. BAPI_HU_DELETE return table was blank.
        CLEAR: ls_return.
        ls_return-type = 'E'.
        ls_return-id   = 'ZSD_DL'.
        ls_return-number = '303'.
        ls_return-message_v1 = ls_data-exidv. "HU number
        APPEND ls_return TO gt_return.
        CONTINUE.
      ENDIF.

*     Log Error message(s) in main error table if HU Delete failed then
*     continue on with the next HU to delete. If no error messages
*     occurred then Commit the deletion of the HU.
      LOOP AT lt_return INTO ls_return WHERE type = 'E'.
        APPEND ls_return TO gt_return.
      ENDLOOP.
      IF sy-subrc NE 0.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait   = 'X'
          IMPORTING
            return = ls_return.
        APPEND ls_data TO gt_success_hu.
      ELSE.
        CONTINUE.
      ENDIF.

*   If HU did not exist for some reason then still add it to this table
    ELSE.
      APPEND ls_data TO gt_success_hu.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " delete_hus
*&---------------------------------------------------------------------*
*&      Form  goods_movement
*&---------------------------------------------------------------------*
*       For each Batch, perform the stock goods movement from the "FROM"
*       SO / SO Item to the "TO" SO / SO Item. If an error occurs then:
*       1. log it in the global error return table.
*       2. remove the HU from work table gt_success_hu since we
*          cannot further process that HU or it's associated batches
*----------------------------------------------------------------------*
FORM goods_movement TABLES it_zsomtransf STRUCTURE zsomtransf
                  CHANGING cv_mat_doc    TYPE      mblnr.

  DATA : ls_imkpf TYPE imkpf,
         ls_emkpf TYPE emkpf,
         ls_emseg TYPE emseg,
         lt_emseg TYPE STANDARD TABLE OF emseg,
         ls_imseg TYPE imseg,
         lt_imseg TYPE STANDARD TABLE OF imseg,
         ls_data  TYPE zsomtransf,
         lv_text(255),
         lv_index TYPE sytabix,
         lv_err_flag  TYPE c.

  CLEAR gv_goods_movement_error.

  SORT it_zsomtransf BY exidv charg.
* Build Header
  ls_imkpf-bldat = ls_imkpf-budat = sy-datum.

* Build Details
  LOOP AT gt_success_hu INTO gs_success_hu.
    gv_tabix = sy-tabix.
    CLEAR: ls_emkpf,
           lt_emseg,
           lv_err_flag.
    READ TABLE it_zsomtransf INTO ls_data
                    WITH KEY exidv = gs_success_hu-exidv.
    IF sy-subrc EQ 0.
      lv_index = sy-tabix.
      LOOP AT it_zsomtransf INTO ls_data FROM lv_index.
        IF ls_data-exidv NE gs_success_hu-exidv.
          EXIT.
        ENDIF.
        CLEAR ls_imseg.
        ls_imseg-bwart     = '413'.
        ls_imseg-sobkz     = 'E'.
        ls_imseg-werks     = ls_data-werks_from.
        ls_imseg-lgort     = gc_hu_temploc.                 "HP01
        ls_imseg-matnr     = ls_data-matnr.
        ls_imseg-charg     = ls_data-charg.
        ls_imseg-erfmg     = ls_data-kalab.
        ls_imseg-erfme     = ls_data-erfme.
        ls_imseg-mat_kdauf = ls_data-vbeln_from.
        ls_imseg-mat_kdpos = ls_data-posnr_from.
        ls_imseg-kdauf     = ls_data-vbeln_to.
        ls_imseg-kdpos     = ls_data-posnr_to.
        ls_imseg-umwrk     = ls_data-werks_to.
        ls_imseg-umlgo     = gc_hu_temploc.                 "HP01
        ls_imseg-ummat     = ls_data-matnr.
        APPEND ls_imseg TO lt_imseg.
      ENDLOOP.
    ENDIF.
  ENDLOOP.

  IF lt_imseg[] IS NOT INITIAL.
    CALL FUNCTION 'MESSAGES_INITIALIZE'.
    CALL FUNCTION 'MB_CREATE_GOODS_MOVEMENT'
      EXPORTING
        imkpf = ls_imkpf
        xallp = 'X'
        xallb = 'X'
        xallr = 'X'
        ctcod = 'MB1B'
      IMPORTING
        emkpf = ls_emkpf
      TABLES
        emseg = lt_emseg
        imseg = lt_imseg.
    IF ls_emkpf-mblnr IS NOT INITIAL.
      CLEAR cv_mat_doc.
      cv_mat_doc = ls_emkpf-mblnr.
      CALL FUNCTION 'MB_POST_GOODS_MOVEMENT'.
      COMMIT WORK AND WAIT.
    ELSE.
*     An error occurred during the Goods Movement. Log the error into
*     the global error table
      IF ls_emkpf-msgid IS NOT INITIAL.
        gv_goods_movement_error = 'X'.
        CLEAR: gs_return.
        MOVE: ls_emkpf-msgty TO gs_return-type,
              ls_emkpf-msgid TO gs_return-id,
              ls_emkpf-msgno TO gs_return-number,
              ls_emkpf-msgv1 TO gs_return-message_v1,
              ls_emkpf-msgv2 TO gs_return-message_v2,
              ls_emkpf-msgv3 TO gs_return-message_v3,
              ls_emkpf-msgv4 TO gs_return-message_v4.
        APPEND gs_return TO gt_return.
        lv_err_flag = 'X'.
      ENDIF.

*     If any errors were logged in the return table of the Goods
*     Movement function then log them in the global error table.
      LOOP AT lt_emseg INTO ls_emseg WHERE msgty = 'E'.
        gv_goods_movement_error = 'X'.
        CLEAR: gs_return.
        MOVE: ls_emseg-msgty TO gs_return-type,
              ls_emseg-msgid TO gs_return-id,
              ls_emseg-msgno TO gs_return-number,
              ls_emseg-msgv1 TO gs_return-message_v1,
              ls_emseg-msgv2 TO gs_return-message_v2,
              ls_emseg-msgv3 TO gs_return-message_v3,
              ls_emseg-msgv4 TO gs_return-message_v4.
        APPEND gs_return TO gt_return.
      ENDLOOP.
*      IF sy-subrc = 0.
*        lv_err_flag = 'X'.
*      ENDIF.
*
**     Remove HU from success table if goods movement failed since we
**     cannot continue processing this HU or associated Batches from
**     here on out.
*      IF lv_err_flag = 'X'.
*        DELETE gt_success_hu INDEX gv_tabix.
*      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " goods_movement
*&---------------------------------------------------------------------*
*&      Form  create_hus
*&---------------------------------------------------------------------*
*       Re-Create the HU's that were successfully deleted earlier.
*       They will be recreated with reference to the Sales Order / Sales
*       Order Item "TO" that was specified.
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM create_handling_units TABLES it_zsomtransf STRUCTURE zsomtransf.

  DATA : ls_headerproposal TYPE bapihuhdrproposal,

         lt_itemsproposal  TYPE STANDARD TABLE OF bapihuitmproposal,
         ls_itemsproposal  TYPE bapihuitmproposal,

         lt_return         TYPE STANDARD TABLE OF bapiret2,
         ls_return         TYPE bapiret2,

         lv_sp_stck_no     TYPE lvs_sonum,
         lv_package_mat    TYPE matnr,
         ls_data           TYPE zsomtransf,
         lv_index          TYPE sytabix,
         lv_text(255)      TYPE c.

* Retrieve Packaging Material from SAP system. This is required to
* Re-Create the HU's
  SELECT SINGLE matnr
         FROM   mara
         INTO   lv_package_mat
         WHERE  mtart EQ 'VERP' AND
                vhart EQ 'PKG'.

* Retrieve ISO uom's for all uom's in the work table
  PERFORM get_isocode TABLES it_zsomtransf.

  CLEAR gs_isocode.

* Process all work table records where the corresponding HU's are still
* in good standing (no errors have occurred with the HU or associated
* Batches.
  LOOP AT gt_success_hu INTO gs_success_hu.

    gv_tabix = sy-tabix.

*   Format Header structure
    CLEAR ls_headerproposal.
    ls_headerproposal-hu_status_init = 'C'.
    ls_headerproposal-pack_mat       = lv_package_mat.
    ls_headerproposal-hu_exid        = gs_success_hu-exidv.
    ls_headerproposal-ext_id_hu_2    = gs_success_hu-exidv2.
    ls_headerproposal-plant          = gs_success_hu-werks_from.

    CLEAR: lt_itemsproposal, ls_itemsproposal.
    READ TABLE it_zsomtransf INTO ls_data
                    WITH KEY exidv = gs_success_hu-exidv.
    IF sy-subrc EQ 0.
      lv_index = sy-tabix.
      LOOP AT it_zsomtransf INTO ls_data FROM lv_index.
        IF ls_data-exidv NE gs_success_hu-exidv.
          EXIT.
        ENDIF.

*       Format Item table
        CLEAR ls_itemsproposal.
        IF gv_goods_movement_error EQ 'X'.
          lv_sp_stck_no+0(10) =  ls_data-vbeln_from.
          lv_sp_stck_no+10(6) =  ls_data-posnr_from.
        ELSE.
          lv_sp_stck_no+0(10) =  ls_data-vbeln_to.
          lv_sp_stck_no+10(6) =  ls_data-posnr_to.
        ENDIF.
        ls_itemsproposal-hu_item_type      = '1'.
        ls_itemsproposal-pack_qty          = ls_data-kalab.
        IF gs_isocode-msehi NE ls_data-erfme.
          READ TABLE gt_isocode INTO gs_isocode
                                WITH KEY msehi = ls_data-erfme
                                BINARY SEARCH.
        ENDIF.
        ls_itemsproposal-base_unit_qty_iso = gs_isocode-isocode.
        ls_itemsproposal-base_unit_qty     = ls_data-erfme.
        ls_itemsproposal-material          = ls_data-matnr.
        ls_itemsproposal-batch             = ls_data-charg.
        ls_itemsproposal-plant             = ls_data-werks_from.
*        IF gv_goods_movement_error EQ 'X'.
*          ls_itemsproposal-stge_loc        = ls_data-lgort_from.
*        ELSE.
        ls_itemsproposal-stge_loc        = gc_hu_temploc.   "HP01
*        ENDIF.
        ls_itemsproposal-spec_stock        = 'E'.
        ls_itemsproposal-sp_stck_no        = lv_sp_stck_no.
        ls_itemsproposal-gr_date           = sy-datum.
        APPEND ls_itemsproposal TO lt_itemsproposal.
      ENDLOOP.

*     Re-Create the HU
      CLEAR: lt_return.
      CALL FUNCTION 'BAPI_HU_CREATE'
        EXPORTING
          headerproposal = ls_headerproposal
        TABLES
          itemsproposal  = lt_itemsproposal
          return         = lt_return.
      IF lt_return IS INITIAL.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait   = 'X'      "wait for update
          IMPORTING
            return = ls_return.
      ELSE.
*       Log the HU Create error in the global error log table
        LOOP AT lt_return INTO ls_return WHERE type = 'E'.
          APPEND ls_return TO gt_return.
        ENDLOOP.
*       If any errors occured
*       Remove HU from success table if creation of hu failed since we
*       cannot continue processing this HU or associated Batches from
*       here on out.
        IF sy-subrc = 0.
          DELETE gt_success_hu INDEX gv_tabix.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " create_hus
*&---------------------------------------------------------------------*
*&      Form  move_handling_unit
*&---------------------------------------------------------------------*
*       Move the HU's to the "TO" Plant / Storage Location
*----------------------------------------------------------------------*
*      -->P_GS_DATA_PACKAGE_NUMBER  text
*----------------------------------------------------------------------*
FORM move_handling_unit TABLES it_zsomtransf STRUCTURE zsomtransf.

* Import Structure for HU_CREATE_GOODS_MOVEMENT
  DATA : lt_move_to       TYPE  hum_data_move_to_t, "Table
         ls_move_to       TYPE  hum_data_move_to,   "Structure
         lt_external_id   TYPE  hum_exidv_t,       "Table
         ls_external_id   TYPE  hum_exidv,         "Structure
         ls_messages      TYPE  huitem_messages,
         lt_messages      TYPE  huitem_messages_t,   "Table
         ls_emkpf         TYPE  emkpf,
         lv_rc            TYPE  sysubrc,
         lv_text(255).

  DATA:  ls_zsomtransf    TYPE  zsomtransf.                 "BCB01

  REFRESH: lt_move_to,
           lt_external_id.

* Build table of Plant TO / Storage Location TO
* Only add 1 record since the Plant TO and Sloc TO will always be the
* same.
  READ TABLE it_zsomtransf INTO ls_zsomtransf INDEX 1.
  IF sy-subrc = 0.
    IF gv_goods_movement_error EQ 'X'.
      ls_move_to-werks = ls_zsomtransf-werks_from.    "Plant
      ls_move_to-lgort = ls_zsomtransf-lgort_from.    "Destination SLoc
      APPEND ls_move_to TO lt_move_to.
    ELSE.
      ls_move_to-werks = ls_zsomtransf-werks_to.    "Plant
      ls_move_to-lgort = ls_zsomtransf-lgort_to.    "Destination SLoc
      APPEND ls_move_to TO lt_move_to.
    ENDIF.
  ENDIF.

* Build table of HU's
  LOOP AT gt_success_hu INTO gs_success_hu.
    CLEAR: ls_move_to,
           ls_external_id.

    ls_external_id-exidv = gs_success_hu-exidv.
    APPEND ls_external_id TO lt_external_id.
  ENDLOOP.

  CLEAR : lv_rc, ls_messages, lt_messages, ls_emkpf.
  REFRESH : lt_messages.

  CALL FUNCTION 'HU_CREATE_GOODS_MOVEMENT'
    EXPORTING
      if_event       = '0001'
      if_commit      = 'X'
      it_move_to     = lt_move_to            "Plant/Dest SLoc
      it_external_id = lt_external_id        "Handling Unit ID
    IMPORTING
      ef_posted      = lv_rc
      es_message     = ls_messages
      et_messages    = lt_messages
      es_emkpf       = ls_emkpf.
  IF lv_rc EQ 1 OR lv_rc EQ 3.
    COMMIT WORK AND WAIT.
  ELSE.

*   An error occurred during the HU Goods Movement. Log the error into
*   the global error table
    IF ls_messages-msgid IS NOT INITIAL AND ls_messages-msgty EQ 'E'.
      CLEAR: gs_return.
      MOVE: ls_messages-msgty TO gs_return-type,
            ls_messages-msgid TO gs_return-id,
            ls_messages-msgno TO gs_return-number,
            ls_messages-msgv1 TO gs_return-message_v1,
            ls_messages-msgv2 TO gs_return-message_v2,
            ls_messages-msgv3 TO gs_return-message_v3,
            ls_messages-msgv4 TO gs_return-message_v4.
      APPEND gs_return TO gt_return.
    ENDIF.

*   If any errors were logged in the return table of the HU Goods
*   Movement function then log them in the global error table.
    LOOP AT lt_messages INTO ls_messages WHERE msgty = 'E'.
      CLEAR: gs_return.
      MOVE: ls_messages-msgty TO gs_return-type,
            ls_messages-msgid TO gs_return-id,
            ls_messages-msgno TO gs_return-number,
            ls_messages-msgv1 TO gs_return-message_v1,
            ls_messages-msgv2 TO gs_return-message_v2,
            ls_messages-msgv3 TO gs_return-message_v3,
            ls_messages-msgv4 TO gs_return-message_v4.
      APPEND gs_return TO gt_return.
    ENDLOOP.

  ENDIF.

ENDFORM.                    " move_handling_unit
*&---------------------------------------------------------------------*
*&      Form  get_isocode
*&---------------------------------------------------------------------*
*       Retrieve uom ISO codes for each unique SAP uom in the main
*       work table
*----------------------------------------------------------------------*
*      -->P_IT_ZSOMTRANSF  text
*----------------------------------------------------------------------*
FORM get_isocode  TABLES it_zsomtransf STRUCTURE zsomtransf.

  DATA lt_zsomtransf TYPE STANDARD TABLE OF zsomtransf.

  lt_zsomtransf[] = it_zsomtransf[].
  SORT lt_zsomtransf BY erfme.
  DELETE ADJACENT DUPLICATES FROM lt_zsomtransf COMPARING erfme.
  IF lt_zsomtransf IS NOT INITIAL.
    SELECT msehi isocode
           FROM  t006
           INTO  TABLE gt_isocode
           FOR ALL ENTRIES IN lt_zsomtransf
           WHERE msehi EQ lt_zsomtransf-erfme.
    IF sy-subrc EQ 0.
      SORT gt_isocode BY msehi.
    ENDIF.
  ENDIF.

ENDFORM.                    " get_isocode

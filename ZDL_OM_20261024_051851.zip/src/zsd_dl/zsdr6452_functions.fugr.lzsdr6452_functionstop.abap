FUNCTION-POOL zsdr6452_functions.           "MESSAGE-ID ..

TYPE-POOLS: zsdc.

CONSTANTS: c_carton         TYPE char1 VALUE 'C',
           c_junior_carton  TYPE char1 VALUE 'D',
           c_uom_carton     type vrkme value 'CTN',
           c_uom_karton     type vrkme value 'KAR',
           c_uom_lbs        type vrkme value 'LB'.

* Characteristic fields
DATA: gt_config_m  TYPE conf_out OCCURS 0, " Material
      gt_config_si TYPE conf_out OCCURS 0, " Sales Ord
      gx_config  TYPE conf_out.

DATA: x_lips LIKE lips,
      x_likp like likp.

DATA: g_full_pallets type f,
      g_total_cartons type f,
      g_cartons_per_pallet like conf_out-atwrt,
      g_tot_cartons_on_pallets type i.

FUNCTION-POOL zdl_idoc_output_shpmnt.       "MESSAGE-ID ..


* Work table for Stop data
TYPES:
  BEGIN OF gts_z1edstp.
        INCLUDE STRUCTURE z1edstp.
TYPES   z1edstp_tabix TYPE sy-tabix. "Stop segment index
TYPES: END OF gts_z1edstp.

* Work table for Delivery data
TYPES:
  BEGIN OF gts_z1edstd.
        INCLUDE STRUCTURE z1edstd.
TYPES:  z1edstp_tabix TYPE sy-tabix, "Stop segment index
        z1edstd_tabix TYPE sy-tabix. "Delivery segment index
TYPES: END OF gts_z1edstd.

TYPES:

  BEGIN OF gts_vbpa,
    vbeln  TYPE vbeln, "Sales doc number
    kunnr  TYPE kunnr, "Partner number
  END OF gts_vbpa.


DATA:

  gt_idoc_data      TYPE STANDARD TABLE OF edidd,

  gs_edidc          TYPE edidc,  "control record

  gv_object_type    TYPE wf_asgtyp, "Workflow: Object type of the link

* Segment work structures
  gs_e1edt20_seg    TYPE e1edt20, "Shipment Header segment structure
  gs_z1edstp_seg    TYPE z1edstp, "Stop segment structure
  gs_z1edstd_seg    TYPE z1edstd, "Delivery segment structure
  gs_z1edstc_seg    TYPE z1edstc, "Stop Control Data segment structure

* Stop segment work data
  gt_z1edstp        TYPE STANDARD TABLE OF gts_z1edstp,
  gs_z1edstp        TYPE gts_z1edstp,

* Delivery segment work data
  gt_z1edstd        TYPE STANDARD TABLE OF gts_z1edstd,
  gs_z1edstd        TYPE gts_z1edstd,

* Partner table
  gt_vbpa           TYPE STANDARD TABLE OF gts_vbpa,
  gs_vbpa           TYPE gts_vbpa,

  gv_asn_relevant   TYPE boolean,
  gv_asn_relevant_count TYPE i.

CONSTANTS :

* Idoc segment names used in the interface
  gc_e1edt20        TYPE edipsegtyp  VALUE  'E1EDT20', "Shipment Hdr
  gc_z1edstp        TYPE edipsegtyp  VALUE  'Z1EDSTP', "Stop segment
  gc_z1edstd        TYPE edipsegtyp  VALUE  'Z1EDSTD', "Deliv segment
  gc_z1edstc        TYPE edipsegtyp  VALUE  'Z1EDSTC',"Stop ctrl segment

  gc_asn_relevant   TYPE char1 VALUE 'A',   "ASN Relevant = 'A'

  gc_qualf_esn      TYPE zstcqualf   VALUE 'ESN',

  gc_true           TYPE boolean VALUE 'X',
  gc_false          TYPE boolean VALUE '-'.

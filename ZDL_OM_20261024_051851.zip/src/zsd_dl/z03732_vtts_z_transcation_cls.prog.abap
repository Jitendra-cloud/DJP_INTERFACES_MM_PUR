*&---------------------------------------------------------------------*
*&  Include Z03732_VTTS_Z_TRANSCATION_CLS
*&  Created by Helena Malkowska (HMALKOW)
*&  Madrid Enhancement: Add the ability to print out the existing
*&                      documents EMEA CMR and Delivery Note
*&---------------------------------------------------------------------*

types: begin of t_output,
         kschl type sna_kschl,
       end of t_output.

*----------------------------------------------------------------------*
*       CLASS LCL_NON_US_ENH DEFINITION
*----------------------------------------------------------------------*
class lcl_non_us_enh definition final.

  public section.
    constants: gc_kappl type kappl value 'V7'.

    class-methods:

      read_zdl_fields importing iv_tknum type tknum,

      print_outputs.

    class-data:
      gv_non_us type char1,
      gt_output type standard table of t_output.

  private section.


endclass.


*----------------------------------------------------------------------*
*       CLASS LCL_NON_US_ENH IMPLEMENTATION
*----------------------------------------------------------------------*
class lcl_non_us_enh implementation.

*&---------------------------------------------------------------------*
*&      method  READ_ZDL_FIELDS
*&---------------------------------------------------------------------*
*       Read lants, Oututs for Plant from table ZDL_FIELDS
*----------------------------------------------------------------------*
  method read_zdl_fields.

    select single * from vttk into @data(ls_vttk)
      where tknum = @iv_tknum.

    if gv_non_us is initial.

      "Plants
      select * from zdl_fields into table @data(lt_tplst)
        where category  = 'E03732'
          and fieldname = 'TPLST'
          and lowval    =  @ls_vttk-tplst.

      if sy-subrc = 0.

        "Outputs for Plant
        select
          highval       as kschl
*         substring( highval, 1, 3 )  as msgnr,
*         substring( highval, 4, 17 ) as msgid
        from zdl_fields
          where category  = 'E03732'
            and fieldname = 'KSCHL'
            and lowval = @ls_vttk-tplst
        into table @gt_output.

        gv_non_us = 'Y'.
      else.

        gv_non_us = 'N'.
      endif.

    endif.

  endmethod.


*&---------------------------------------------------------------------*
*&      method  PRINT_OUTPUTS
*&---------------------------------------------------------------------*
*       Print Outputs for Plant
*----------------------------------------------------------------------*
  method print_outputs.
    data: ls_nast type nast.
    data: lv_msg type string.

    sort gt_output by kschl descending.

    loop at gt_output into data(ls_output).

      select * up to 1 rows from nast into ls_nast
        where kappl = gc_kappl
          and objky = vttk-tknum
          and kschl = ls_output-kschl
*         and spras = ls_output-spras
          and vstat = '0'.
      endselect.

      if sy-subrc = 0.
        perform send_output using ls_nast.
      else. "Not Found
        "EI	339	No unprocessed output was found
        message s339(ei) into lv_msg.
        lv_msg = ls_output-kschl && ` - ` && lv_msg.
        message lv_msg type 'I'.
      endif.

    endloop.
  endmethod.

endclass.

************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2019 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: Deliver Inventory Conversion                           *
*                                                                      *
* SAP Name    : ZDL_C10156_INVENTORY_CONV        Create Date: 09/19/19 *
*                                                                      *
* Programmer  : John Leo William                 Last Update: 09/19/19 *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*                                                                      *
*    This program will be used to load the batch, batch                *
*    characteristics, Inventory and HU’s using single file format. The *
*    program design allows to configure the file format based on       *
*    ZZXREFDETAIL table.                                               *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* John Leo William    09/19/19                                         *
* Mallik Aiely        06/26/2020 E0VK9A1F0F CD2000007614:Read MATNR    *
*                                           Char                       *
* Mallik Aiely        01/12/2021 E0VK9A1IVO CD2000007614:Exception for *
*                                           HU/Pack                    *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*     ZDL_C10156_INVENTORY_DEF                                         *
*     ZDL_C10156_INVENTORY_IMP                                         *
*     ZDL_C10156_INVENTORY_PAI                                         *
*     ZDL_C10156_INVENTORY_PBO                                         *
*     ZDL_C10156_INVENTORY_SCREEN                                      *
*     ZDL_C10156_INVENTORY_TOP                                         *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*   Function Modules:                                                  *
*     F4IF_INT_TABLE_VALUE_REQUEST                                     *
*                                                                      *
*   Classes         :                                                  *
*     CL_DD_AREA                                                       *
*     CL_DD_DOCUMENT                                                   *
*     CL_DD_TABLE_ELEMENT                                              *
*     CL_GUI_CFW                                                       *
*     CL_GUI_DOCKING_CONTAINER                                         *
*     CL_GUI_FRONTEND_SERVICES                                         *
*     CL_GUI_SPLITTER_CONTAINER                                        *
*     CL_RSAN_UT_FILES                                                 *
*     CL_SALV_COLUMN                                                   *
*     CL_SALV_COLUMNS                                                  *
*     CL_SALV_COLUMNS_LIST                                             *
*     CL_SALV_DISPLAY_SETTINGS                                         *
*     CL_SALV_FUNCTIONS                                                *
*     CL_SALV_LAYOUT                                                   *
*     CL_SALV_MODEL_LIST                                               *
*     CL_SALV_TABLE                                                    *
*     CX_ROOT                                                          *
*     CX_ROOT\IN:IF_MESSAGE                                            *
*     CX_SALV_ACCESS_ERROR                                             *
*     CX_SALV_DATA_ERROR                                               *
*     CX_SALV_ERROR                                                    *
*     CX_SALV_MSG                                                      *
*     CX_SALV_NOT_FOUND                                                *
*     CX_SALV_STATIC_CHECK                                             *
*     CX_STATIC_CHECK                                                  *
*     IF_MESSAGE                                                       *
*     LCL_INVENTORY_CONV                                               *
*     ZCL_DL_C10156_INVENTORY_CONV                                     *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************

REPORT zdl_c10156_inventory_conv.

* Global declaration
INCLUDE zdl_c10156_inventory_top.

* Selection Screen
INCLUDE zdl_c10156_inventory_screen.

* Local class implementations
INCLUDE zdl_c10156_inventory_imp.

* Screen PBO event
INCLUDE zdl_c10156_inventory_pbo.

* Screen PAI event
INCLUDE zdl_c10156_inventory_pai.

*--------------------------------------------------------------------*
INITIALIZATION.
* Add custom button in the application tool bar
  lcl_inventory_conv=>add_toolbar( ).

*--------------------------------------------------------------------*

*--------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.
* Modify the screen based on the user input
  lcl_inventory_conv=>modify_screen( ).

* Get the default application file path to the parameter.
  lcl_inventory_conv=>default_screen_value(
    IMPORTING
      ev_app_file_path     = p_serv
      ev_translations_file = p_trans
      ev_error_file        = p_error
      ev_success_file      = p_succ ).

*--------------------------------------------------------------------*

*--------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_prod.
* Field Product type
  lcl_inventory_conv=>drop_down( ).
*--------------------------------------------------------------------*

*--------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_loc1.
* F4 help for local file( from the desktop).
  lcl_inventory_conv=>file_f4_help(
    EXPORTING
      iv_path_flag  = abap_false
    CHANGING
      cv_field_name = p_loc1 ).
*--------------------------------------------------------------------*

*--------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_serv.
* F4 help for the application server file
  lcl_inventory_conv=>file_f4_help(
    EXPORTING
      iv_path_flag  = abap_true
    CHANGING
      cv_field_name = p_serv ).
*--------------------------------------------------------------------*

*--------------------------------------------------------------------*
AT SELECTION-SCREEN.
* Create instance
  lcl_inventory_conv=>create_insatance( ).

* Handle cutom menu button event
  lcl_inventory_conv=>button_event( ).

* Create the instance of the class based on the user input
  lcl_inventory_conv=>shcedule_background( ).
*--------------------------------------------------------------------*

*--------------------------------------------------------------------*
START-OF-SELECTION.
  lcl_inventory_conv=>main( ).
*--------------------------------------------------------------------*

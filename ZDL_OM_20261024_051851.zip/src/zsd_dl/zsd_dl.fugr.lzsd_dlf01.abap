*----------------------------------------------------------------------*
***INCLUDE LZSD_DLF01 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  DELIVERY_CHECK
*&---------------------------------------------------------------------*
*       Validations for the delivery
*----------------------------------------------------------------------*
FORM delivery_check .
  DATA : lv_vbeln TYPE vbeln_vl ,
         lv_tknum TYPE tknum ,
         lv_stlbg TYPE stlbg ,
         lv_stlad TYPE stlad ,
         lv_stabf TYPE stabf ,
         lv_sttbg TYPE sttbg .

* move the segnamt details to the header
  MOVE isegm-sdata TO e1vpdlh.

* check for delivery
  SELECT SINGLE vbeln FROM likp
         INTO lv_vbeln
         WHERE vbeln = e1vpdlh-vbeln_vl .
  IF sy-subrc <> 0 .
* delivery not found
    idoc_status-docnum = idoc_contrl-docnum.
    idoc_status-status = c_idoc_status_error.
    idoc_status-msgty =  'E'.
    idoc_status-msgid =  'ZSD_DL'.
    idoc_status-msgno =  '000'.
    CONCATENATE 'Invalid Delivery Number'(001)
                 e1vpdlh-vbeln_vl
    INTO idoc_status-msgv1 .
    APPEND idoc_status.
  ELSE.
* check for shipment
    SELECT SINGLE tknum FROM vttp
           INTO lv_tknum
           WHERE vbeln = e1vpdlh-vbeln_vl .
    IF sy-subrc <> 0 .
* shipment not found
      idoc_status-docnum = idoc_contrl-docnum.
      idoc_status-status = c_idoc_status_error.
      idoc_status-msgty =  'E'.
      idoc_status-msgid =  'ZSD_DL'.
      idoc_status-msgno =  '000'.
      CONCATENATE 'No shipment exists for delivery'(002)
                   e1vpdlh-vbeln_vl
      INTO idoc_status-msgv1 .
      APPEND idoc_status.
      returncode = 4.
      EXIT.
    ELSE.
* check for shipment status
      SELECT SINGLE stlbg
                    stlad
                    stabf
                    sttbg
           INTO (lv_stlbg,lv_stlad,lv_stabf,lv_stabf)
           FROM vttk
           WHERE tknum = lv_tknum .
* shipment loading has not started

      IF lv_stlbg <> 'X' .   " load start
        idoc_status-docnum = idoc_contrl-docnum.
        idoc_status-status = c_idoc_status_error.
        idoc_status-msgty =  'E'.
        idoc_status-msgid =  'ZSD_DL'.
        idoc_status-msgno =  '000'.
        idoc_status-msgv1 = 'Shipment not in Load Start Status'(003).
        idoc_status-msgv2 =  ',delivery can not be Updated'(004).
        APPEND idoc_status.
        returncode = 4.
        EXIT.
* shipment gate exited
      ELSEIF lv_sttbg = 'X' .  " shipment start
        idoc_status-docnum = idoc_contrl-docnum.
        idoc_status-status = c_idoc_status_error.
        idoc_status-msgty =  'E'.
        idoc_status-msgid =  'ZSD_DL'.
        idoc_status-msgno =  '000'.
        idoc_status-msgv1 =  'Shipment Gate Exited'(006) .
        idoc_status-msgv2 = ',delivery can not be Updated'(004).
        APPEND idoc_status.
        returncode = 4.
        EXIT.
* shipment has ended
      ELSEIF lv_stabf = 'X' .  " Shipment end

        idoc_status-docnum = idoc_contrl-docnum.
        idoc_status-status = c_idoc_status_error.
        idoc_status-msgty =  'E'.
        idoc_status-msgid =  'ZSD_DL'.
        idoc_status-msgno =  '000'.
        idoc_status-msgv1 =  'Shipment Completed'(007).
        idoc_status-msgv2 = ',delivery can not be Updated'(004).
        APPEND idoc_status.
        returncode = 4.
        EXIT.
* shipment loading is completed
      ELSEIF lv_stlad = 'X' . " load end
        idoc_status-docnum = idoc_contrl-docnum.
        idoc_status-status = c_idoc_status_error.
        idoc_status-msgty =  'E'.
        idoc_status-msgid =  'ZSD_DL'.
        idoc_status-msgno =  '000'.
        idoc_status-msgv1 =  'Shipment has been loaded'(005).
        idoc_status-msgv2 = ',delivery can not be Updated'(004).
        APPEND idoc_status.
        returncode = 4.
        EXIT.
      ENDIF.
    ENDIF.
  ENDIF .

ENDFORM.                    " DELIVERY_CHECK

*&---------------------------------------------------------------------*
*&      Form  VALIDATIONS_FOR_PALLET
*&---------------------------------------------------------------------*
*       BDC
*----------------------------------------------------------------------*
FORM validations_for_pallet .

  DATA lv_msg(150).

* check whether line item already exists
  SELECT SINGLE posnr FROM lips
         INTO lv_posnr
         WHERE vbeln = e1vpdli-vbeln_vl AND
               pstyv = c_tatx AND
               vrkme = c_pl.
* update if line item is existing
  IF sy-subrc = 0 .
    PERFORM bdc_update .
  ELSE.
* insert in case of new line item
    PERFORM bdc_insert.
  ENDIF .

  CALL TRANSACTION 'VL02N' USING t_bdcdata
                                   MODE lv_mode
                                   UPDATE lv_update
                                   MESSAGES INTO t_trans_msgtab.
* check for any errors during BDC session

  IF t_trans_msgtab[] IS NOT INITIAL .
    READ TABLE t_trans_msgtab WITH KEY msgtyp = 'E' .
    IF sy-subrc = 0 .
      CALL FUNCTION 'FORMAT_MESSAGE'
        EXPORTING
          id        = t_trans_msgtab-msgid
          lang      = '-E'
          no        = t_trans_msgtab-msgnr
          v1        = t_trans_msgtab-msgv1
          v2        = t_trans_msgtab-msgv2
          v3        = t_trans_msgtab-msgv3
          v4        = t_trans_msgtab-msgv4
        IMPORTING
          msg       = lv_msg
        EXCEPTIONS
          not_found = 1
          OTHERS    = 2.

      idoc_status-docnum = idoc_contrl-docnum.
      idoc_status-status = c_idoc_status_error.
      idoc_status-msgty =  'E'.
      idoc_status-msgid =  'ZSD_DL'.
      idoc_status-msgno =  '000'.
      idoc_status-msgv1 = lv_msg.
      APPEND idoc_status.
    ELSE.
      idoc_status-docnum = idoc_contrl-docnum.
      idoc_status-status = c_idoc_status_ok.
      APPEND idoc_status.
    ENDIF.
  ELSE.
    idoc_status-docnum = idoc_contrl-docnum.
    idoc_status-status = c_idoc_status_ok.
    APPEND idoc_status.
  ENDIF.

ENDFORM.                    " VALIDATIONS_FOR_PALLET

*&---------------------------------------------------------------------*
*&      Form  bdc_update
*&---------------------------------------------------------------------*
*      Updating the new line
*----------------------------------------------------------------------*
FORM bdc_update .
  DATA lv_msg(150).
  REFRESH : t_bdcdata,
            t_trans_msgtab.
  CLEAR :   t_bdcdata,
            t_trans_msgtab,lv_msg.

* main screen
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '4004' ,
          ' '    'BDC_CURSOR'                 'LIKP-VBELN' ,
          ' '    'BDC_OKCODE'                 '/00' ,
          ' '    'LIKP-VBELN'                 e1vpdli-vbeln_vl.

* transport tab
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '1000' ,
          ' '    'BDC_OKCODE'                 '=POPO_T'.

* cursor placement
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '0111' ,
          ' '    'BDC_CURSOR'                 'RV50A-POSNR' ,
          ' '    'BDC_OKCODE'                 '=WEIT'       ,
          ' '    'RV50A-POSNR'                lv_posnr.

* populate no of pallets / gross wt /  BUOM / wt unit of measure
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '1000' ,
          ' '    'BDC_OKCODE'                 '=IDET_T' ,
          ' '    'LIPSD-G_LFIMG(01)'          e1vpdli-pikmg ,
          ' '    'LIPS-GEWEI(01)'             e1vpdli-gewei ,
          ' '    'LIPS-VRKME(01)'             c_pl          ,
          ' '    'LIPS-ARKTX(01)'             e1vpdli-matnr_external .

* populate  gross and net Wt

  PERFORM sub_populate_bdc_tab
  USING:
        '1'    'SAPMV50A'                   '3000' ,
        ' '    'BDC_OKCODE'                 '=SICH_T' ,
        ' '    'BDC_CURSOR'                 'LIPS-NTGEW',
        ' '    'LIPS-BRGEW'                 e1vpdli-brgew ,
        ' '    'LIPS-NTGEW'                 e1vpdli-brgew .



ENDFORM.                    " bdc_update

*&---------------------------------------------------------------------*
*&      Form  bdc_insert
*&---------------------------------------------------------------------*
*      Inserting a new line item
*----------------------------------------------------------------------*
FORM bdc_insert .

  REFRESH : t_bdcdata,
            t_trans_msgtab.
  CLEAR :   t_bdcdata,
            t_trans_msgtab.

* main screen
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '4004' ,
          ' '    'BDC_CURSOR'                 'LIKP-VBELN' ,
          ' '    'BDC_OKCODE'                 '/00' ,
          ' '    'LIKP-VBELN'                 e1vpdli-vbeln_vl.

* tab no 4
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '1000' ,
          ' '    'BDC_OKCODE'                 '=T\04'.

* page down
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '1000' ,
          ' '    'BDC_OKCODE'                 '=LPAG_T'.
* new line
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '1000' ,
          ' '    'BDC_OKCODE'                 '=POAN_T'.
* populate the values
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '1000' ,
          ' '    'BDC_OKCODE'                 '=ILOA_T' ,
          ' '    'LIPS-BRGEW(02)'             e1vpdli-brgew,
          ' '    'LIPS-GEWEI(02)'             e1vpdli-gewei,
          ' '    'LIPSD-G_LFIMG(02)'          e1vpdli-pikmg,
          ' '    'LIPS-VRKME(02)'             c_pl         ,
          ' '    'LIPS-ARKTX(02)'             e1vpdli-matnr_external,
          ' '    'LIPS-PSTYV(02)'             c_tatx        ,
          ' '    'RV50A-LIPS_SELKZ(02)'       'X'.
* populate the net wt
  PERFORM sub_populate_bdc_tab
    USING:
          '1'    'SAPMV50A'                   '3000' ,
          ' '    'BDC_OKCODE'                 '=SICH_T' ,
          ' '    'BDC_CURSOR'                 'LIPS-NTGEW' ,
          ' '    'LIPS-NTGEW'                 e1vpdli-brgew.


ENDFORM.                    " bdc_insert
*&---------------------------------------------------------------------*
*&      Form  sub_populate_bdc_tab
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
FORM sub_populate_bdc_tab  USING flag TYPE any
                                 var1 TYPE any
                                 var2 TYPE any .
  CLEAR t_bdcdata.

  IF flag = '1'.
    t_bdcdata-program  = var1.
    t_bdcdata-dynpro   = var2.
    t_bdcdata-dynbegin = 'X'.
  ELSE.
    t_bdcdata-fnam     = var1.
    t_bdcdata-fval     = var2.
  ENDIF.

  APPEND t_bdcdata.

ENDFORM.                    " sub_populate_bdc_tab

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_ORD_DETAILTOP.             " Global Data
  INCLUDE LZSD_DL_ORD_DETAILUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_ORD_DETAILF...             " Subprograms
* INCLUDE LZSD_DL_ORD_DETAILO...             " PBO-Modules
* INCLUDE LZSD_DL_ORD_DETAILI...             " PAI-Modules

INCLUDE LZSD_DL_ORD_DETAILSUB.

INCLUDE LZSD_DL_ORD_DETAILMAC.

process before output.
* Initialize variables
module init_9100.
* Retrieve idoc data
module retrieve_data_9100.
* Set gui status & titlebar
module status_9100.


process after input.
* The Cancel button (red X) will be defined with a
* function type of 'E' on our pf-status.
module cancel at exit-command.
* Handle user interaction
module user_command_9100.

FUNCTION zsd_dl_sord_mat_transf.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(TEST_RUN) TYPE  CHAR1 DEFAULT ' '
*"  EXPORTING
*"     REFERENCE(MATERIAL_DOC) TYPE  MBLNR
*"  TABLES
*"      IT_ZSOMTRANSF STRUCTURE  ZSOMTRANSF
*"      IT_HU_RETURN STRUCTURE  BAPIRET2 OPTIONAL
*"  EXCEPTIONS
*"      GOODS_MOVEMENT_FAILED
*"----------------------------------------------------------------------
***********************************************************************
**                                                                   **
**             C O M P A N Y   C O N F I D E N T I A L               **
**                                                                   **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
**                                                                   **
***********************************************************************
***********************************************************************
**                                                                   **
**                    COPYRIGHT (C) 2005 by                          **
**                     INTERNATIONAL PAPER                           **
**                                                                   **
**                     ALL RIGHTS RESERVED                           **
**                                                                   **
**                   REVISIONS COPYRIGHT (C)                         **
**                            2005                                   **
**                             by                                    **
**                     INTERNATIONAL PAPER                           **
***********************************************************************
*_____________________________________________________________________*
* Function Module: ZSD_DL_SORD_MAT_TRANSF        Date: 10/09/2005     *
*  Function Group: ZSD_DL_SORD_TRANSF                                 *
*                                                                     *
* Programmer  : Randall Wainwright                                    *
*                                                                     *
*_____________________________________________________________________*
* Description : Simple function module which creates the goods        *
*      movement for transfer of materials from one sales order to     *
*      another. Allows for multiple batches to a single sales order   *
*      line item.                                                     *
*  First implemented in program ZSD_DL_E02999_TRANSF_ROLLS:           *
*      Automated tool for transfer of rolls from one sales order to   *
*      another.                                                       *
*---------------------------------------------------------------------*
*_____________________________________________________________________*
* Change History:                                                     *
*     Programmer        Date    Req. #            Action              *
* ==================  ========  ======  ==============================*
* Randall Wainwright  05/30/06  RLW01   Handling Unit Processing      *
*     HUs must be unpacked before the Goods Movement is done,
*      then packed into the destination document, finally
*      performing the BAPI_GOODS_MVT to complete the transaction.
*      The following function modules are required for this change:
*       BAPI_HU_UNPACK
*       BAPI_HU_PACK
*       HU_CREATE_GOODS_MOVEMENT
*       BAPI_TRANSACTION_COMMIT
*----------------------------------------------------------------------*
* External Calls    :                                                  *
*       Function Modules : BAPI_HU_DELETE                              *
*                          BAPI_TRANSACTION_COMMIT                     *
*                          MESSAGES_INITIALIZE                         *
*                          MB_CREATE_GOODS_MOVEMENT                    *
*                          MB_POST_GOODS_MOVEMENT                      *
*                          BAPI_HU_CREATE                              *
*                          HU_CREATE_GOODS_MOVEMENT                    *
*       Transactions     : None                                        *
*       Programs         : None                                        *
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
* Chandra Cherupally  05/20/2008 E0VK939628  CHG89023 - USD4330607     *
* Description of changes - This FM was re-written to improve the       *
* performance.                                                         *
*                                                                      *
* ============  ========  ==========  =================================*
* BBALLEH       06/24/08  EDVK961704  Changes related to background    *
*                                     job processing.                  *
*                         BCB01       The IMPORT parms:                *
*                                     VBELN_TO (sales order to)        *
*                                     POSNR_TO (sales order item to)   *
*                                     WERKS_TO (sales order plant to)  *
*                                     LGORT_TO (sales order sloc to)   *
*                                     were removed and now reside as   *
*                                     fields in the TABLES table       *
*                                     IT_ZSOMTRANSF.                   *
*                                                                      *
*                                     Also, TABLES table IT_ZSOMTRANSF *
*                                     had the following changes made:  *
*                                     - Field VBELN renamed to         *
*                                       VBELN_FROM                     *
*                                     - Field POSNR renamed to         *
*                                       POSNR_FROM                     *
*                                     - Field WERKS renamed to         *
*                                       WERKS_FROM                     *
*                                     - Field LGORT renamed to         *
*                                       LGORT_FROM                     *
*                                                                      *
*                                     At this time, this function is   *
*                                     called by the Break Bulks Sales  *
*                                     Order program:                   *
*                                     ZSD_DL_E02999_TRANSF_ROLLS and   *
*                                     the Container Roll Transfer      *
*                                     program:                         *
*                                     ZSD_DL_E03945_CONT_TNS_ROLL      *
*                                                                      *
*                                     Also, this function is modfied   *
*                                     to pass all error messages back  *
*                                     in return table IT_HU_RETURN     *
*                                     instead of using pop up messages.*
*                                     The calling programs can decide  *
*                                     how the error messages will be   *
*                                     displayed.                       *
*                                                                      *
*                                     Another note: this function will *
*                                     continue to process an HU and    *
*                                     it's batches unless an error     *
*                                     occurs in one of the steps. So,  *
*                                     on HU might error out on the HU  *
*                                     deletion logic but the processing*
*                                     will continue for the other HU's *
*                                     and their batches.  This is NOT  *
*                                     an "all or none" scenario where  *
*                                     ALL processing stops if an error *
*                                     occurs on one of the HU's or it's*
*                                     Batches.                         *
************************************************************************

* Initialize
  CLEAR:  gt_return,
          gs_return,

          gt_success_hu,
          gs_success_hu.


* If no data passed in then log error and exit function.
  IF it_zsomtransf[] IS INITIAL.
    gs_return-type = 'E'.
    gs_return-id   = 'ZSD_DL'.
    gs_return-number = '304'.
    APPEND gs_return TO gt_return.
    it_hu_return[] = gt_return[].
    RETURN. "leave function
  ENDIF.

* Delete all Handling Units passed in
  PERFORM delete_handling_units TABLES it_zsomtransf.

* For all of those successfully deleted HU's, process them and their
* related Batches. The HU's not successfully deleted will be logged
* in the return error table.
  IF gt_success_hu IS NOT INITIAL.
    PERFORM goods_movement TABLES it_zsomtransf
                         CHANGING material_doc.

*   Re-Create the HU's that were previously deleted
    PERFORM create_handling_units TABLES it_zsomtransf.

*   For all of those successfully Re-Created HU's, move them to the
*   "TO" Plant / Storage Location
    IF gt_success_hu IS NOT INITIAL.
      PERFORM move_handling_unit TABLES it_zsomtransf.
    ENDIF.
  ENDIF.

* Format any errors into the return table of errors. If no errors
* occurred, add a success message.
  IF gt_return IS INITIAL.
*   Roll Transfer processed without errors
    CLEAR: gs_return.
    gs_return-type   = 'S'.
    gs_return-id     = 'ZSD_DL'.
    gs_return-number = '305'.
    APPEND gs_return TO gt_return.
  ENDIF.
  it_hu_return[] = gt_return[].

ENDFUNCTION.

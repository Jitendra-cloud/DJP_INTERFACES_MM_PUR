FUNCTION zdl_idoc_output_zsdshipstatus.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(CONTROL_RECORD_IN) TYPE  EDIDC
*"     REFERENCE(OBJECT) TYPE  NAST
*"  EXPORTING
*"     REFERENCE(CONTROL_RECORD_OUT) TYPE  EDIDC
*"     REFERENCE(OBJECT_TYPE) TYPE  WF_ASGTYP
*"  TABLES
*"      INT_EDIDD STRUCTURE  EDIDD
*"  EXCEPTIONS
*"      DATA_NOT_RELEVANT_FOR_SENDING
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT © 2008 by                             **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT ©                            **
**                          2008, 200n                                **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
* Program Name: Outbound FM for                  Create Date: 06/25/08 *
*               Shipment Status (214)                                  *
* SAP Name    : ZDL_IDOC_OUTPUT_ZSDSHIPSTATUS    Version    : V4W2     *
* Programmer  : Chandra Cherupally               Last Update:          *
* Inventory Code : I02554                                              *
************************************************************************
* Description : This function module builds the IDOC data with the     *
* Shipment Status Info. IDOC type - EVMSTA02
************************************************************************
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* Chandra Cherupally  06/17/08  EDVK963368  Initial Version            *
* Chandra Cherupally  07/18/08  EDVK963368  CR 8159 - Populating SO and*
*                                           PO Numbers in E1EVMREF02   *
*                                           Segments                   *
*                                                                      *
************************************************************************

* If the global structure is not populated, meaning this output is
* triggered as part of re-processing the output. In that case, an
* error should be raised. ZSSO is only processed, when EM triggers the
* RFC function module when a specific event get triggered in EM
  IF gs_idoc_info IS INITIAL.
* Output Type ZSSO cannot be re-processed
    MESSAGE e009.
    RETURN.
  ENDIF.

  MOVE control_record_in TO control_record_out.
  object_type = nast-objtype.

  PERFORM build_idoc_data TABLES int_edidd.

ENDFUNCTION.

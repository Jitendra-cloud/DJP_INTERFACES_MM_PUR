FUNCTION ZDL_E04163_NMFC_FREIGHT.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(I_TKNUM) TYPE  TKNUM OPTIONAL
*"  TABLES
*"      T_VTTK STRUCTURE  VTTK OPTIONAL
*"      T_VTTS STRUCTURE  VTTS OPTIONAL
*"      T_VTTP STRUCTURE  VTTP OPTIONAL
*"      T_ZNMFR TYPE  ZNMFR_RETURN_CODE
*"  EXCEPTIONS
*"      INVALID_INPUT
*"      SHIPMENT_REQUIRED
*"      SHIPMENT_NOT_FOUND
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2008 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                         2008, 20xx                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Function Module: NMFC Freight Code & Class for LTL shipments         *
* Create Date: 05/14/08                                                *
* SAP Name    : ZDL_E04163_NMFC_FREIGHT          Version    :          *
*                                                                      *
* Programmer  : Sunil Paleru                     Last Update:          *
*______________________________________________________________________*
* Description :                                                        *
* This Function Module will get either TKNUM as import parameter or
* VTTS, VTTP structures as input. Irrespective of the input, this FM
* will return the NMFC Code and Class for LTL shipments.
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* Sunil Paleru        05/14/08  EDEK912112  Initial creation           *
*                                                                      *
************************************************************************
* Includes          :                                                  *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*______________________________________________________________________*
* Variable Definition Key                                              *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
**** THIS FUNCTION MODULE WILL ONLY PROCESS ONE SHIPMENT PER CALL  *****
************************************************************************
  CLEAR: gt_shipment, gt_delivery, gt_frcode, gt_frclass, gt_frgroup,
         gt_vttk, gt_vttp, gt_vtts, gt_final.
  REFRESH: gt_shipment, gt_delivery, gt_frcode, gt_frclass, gt_frgroup,
         gt_vttk, gt_vttp, gt_vtts, gt_final.
* Check if the tables are INITIAL.
  IF t_vttk[] is INITIAL AND
     t_vtts[] is INITIAL AND
     t_vttp[] is INITIAL.
* Shipment Number is required if tables are not passed.
    IF i_tknum is INITIAL.
      RAISE SHIPMENT_REQUIRED.
    ELSE.
* Check if Shipment Number is valid.
    SELECT SINGLE TKNUM INTO VTTK-TKNUM FROM VTTK WHERE TKNUM = i_tknum.
      IF NOT SY-SUBRC is INITIAL.
        RAISE SHIPMENT_NOT_FOUND.
      ENDIF.
    ENDIF.
* Invalid Input if either one of the tables are not passed.
  ELSEIF t_vttk[] is INITIAL OR
         t_vtts[] is INITIAL OR
         t_vttp[] is INITIAL.
    RAISE INVALID_INPUT.
  ELSE.
    gt_vtts[] = t_vtts[].
    gt_vttp[] = t_vttp[].
    gt_vttk[] = t_vttk[].
  ENDIF.
** Get the Shipment details for Output
  PERFORM get_ltl_shipment_data USING i_tknum .
** Append Data to the Output table.
  T_ZNMFR[] = gt_final[].
ENDFUNCTION.

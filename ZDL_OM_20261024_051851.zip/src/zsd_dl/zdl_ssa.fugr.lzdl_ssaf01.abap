*----------------------------------------------------------------------*
***INCLUDE LZDL_SSAF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_INPUT_DATA
*&---------------------------------------------------------------------*
*       Validate the table of Shipments and/or the table of Deliveries
*       passed into this function module
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_input_data .

  DATA:

    lv_lines_1  TYPE  i,
    lv_lines_2  TYPE  i.

  CLEAR: gt_tknum_vbeln.

* Validate data was passed in
  IF gt_tknum IS INITIAL AND
     gt_vbeln IS INITIAL.
    RAISE no_data_passed.
  ENDIF.

* Validate Shipment numbers passed in
  IF gt_tknum IS NOT INITIAL.

    CLEAR: gt_vbeln.

    SORT gt_tknum.
    DELETE ADJACENT DUPLICATES FROM gt_tknum.

*   Retrieve Deliveries for Shipments passed in
    SELECT DISTINCT tknum
                    vbeln
      INTO TABLE gt_tknum_vbeln
      FROM vttp
      FOR ALL ENTRIES IN gt_tknum
      WHERE tknum = gt_tknum-tknum.
*   If all Shipments are invalid then raise error
    IF sy-subrc NE 0.
      RAISE invalid_input.
    ENDIF.

*   Format table of unique Deliveries
    LOOP AT gt_tknum_vbeln INTO gs_tknum_vbeln.
      gs_vbeln-vbeln = gs_tknum_vbeln-vbeln.
      APPEND gs_vbeln TO gt_vbeln.
    ENDLOOP.

  ELSE.

*   Validate Delivery numbers passed in
    SORT gt_vbeln.
    DELETE ADJACENT DUPLICATES FROM gt_vbeln.

*   Retrieve Shipments for Deliveries passed in
    SELECT DISTINCT tknum
                    vbeln
      INTO TABLE gt_tknum_vbeln
      FROM vttp
      FOR ALL ENTRIES IN gt_vbeln
      WHERE vbeln = gt_vbeln-vbeln.
*   If all Deliveries are invalid then raise error
    IF sy-subrc NE 0.
      RAISE invalid_input.
    ENDIF.

  ENDIF.

  SORT gt_tknum_vbeln BY vbeln.

* Begin BCB01
* Validate the Shipping Point passed in by the user
  IF gv_vstel IS NOT INITIAL.
    SELECT SINGLE werks INTO gv_werks
      FROM tvswz
      WHERE vstel = gv_vstel.
    IF sy-subrc NE 0.
      RAISE invalid_shipping_point.
    ENDIF.
  ELSE.
    CLEAR: gv_vstel.
  ENDIF.
* End BCB01

ENDFORM.                    " VALIDATE_INPUT_DATA
*&---------------------------------------------------------------------*
*&      Form  RETRIEVE_SSA_CONDITIONS
*&---------------------------------------------------------------------*
*       Retrieve all SSA Shipping Conditions from table ZDL_FIELDS into
*       a range
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM retrieve_ssa_conditions .

  TYPES:

    BEGIN OF lts_vsbed,
      vsbed TYPE vsbed,
    END OF lts_vsbed.

  DATA:

    lt_vsbed TYPE STANDARD TABLE OF lts_vsbed,
    ls_vsbed TYPE lts_vsbed.

  CONSTANTS:

    lc_category  TYPE zcatgory   VALUE 'R02740',
    lc_fieldname TYPE fieldname  VALUE 'VSBED',
    lc_sign      TYPE cacsasign  VALUE 'I',
    lc_optn      TYPE cacsoption VALUE 'EQ'.


  CLEAR: gr_vsbed[], gr_vsbed.

* Retrieve SSA Shipping Conditions
  SELECT lowval INTO TABLE lt_vsbed
    FROM zdl_fields
    WHERE category  = lc_category  AND
          fieldname = lc_fieldname.

  IF sy-subrc = 0.

    gr_vsbed-sign   = lc_sign.
    gr_vsbed-option = lc_optn.

    LOOP AT lt_vsbed INTO ls_vsbed.

*     Build Global Range
      gr_vsbed-low = ls_vsbed-vsbed.
      APPEND gr_vsbed.

    ENDLOOP.

    CLEAR: gr_vsbed. "clear range header

  ENDIF.

ENDFORM.                    " RETRIEVE_SSA_CONDITIONS
*&---------------------------------------------------------------------*
*&      Form  RETRIEVE_DATA
*&---------------------------------------------------------------------*
*       Retrieve Delivery item and reference Sales Order / Shipping
*       Condition information
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM retrieve_data .

* Retrieve all Delivery/Delivery items for the Deliveries passed in
  CLEAR: gt_lips, gs_lips.
  SELECT vbeln  "Delivery number
         posnr  "Delivery item
         vgbel  "SO
         vgpos  "SO item
         vgtyp  "reference doc type: C = Sales Order
    INTO TABLE gt_lips
    FROM lips
    FOR ALL ENTRIES IN gt_vbeln
    WHERE vbeln = gt_vbeln-vbeln.

* Sort LIPS work table by Reference Doc / Item
  SORT gt_lips BY vgbel  "Reference doc (ie Sales Order)
                  vgpos. "Ref doc item

* Retrieve Sales Order item shipping condition info that may correspond
* to the retrieved Delivery Item data
  CLEAR: gt_vbap, gs_vbap.
  SELECT vbeln   "SO number
         posnr   "SO item
         zzvsbed "Shipping Condition
    INTO TABLE gt_vbap
    FROM vbap
    FOR ALL ENTRIES IN gt_lips
    WHERE vbeln = gt_lips-vgbel  "So
      AND posnr = gt_lips-vgpos. "SO Item

ENDFORM.                    " RETRIEVE_DATA
*&---------------------------------------------------------------------*
*&      Form  DETERMINE_SHIPPING_CONDITIONS
*&---------------------------------------------------------------------*
*       Determine if Shipping Conditions are SSA
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM determine_shipping_conditions .

* Make sure SSA Shipping Conditions were present in table ZDL_FIELDS
  CHECK gr_vsbed[] IS NOT INITIAL.

* Set SSA Indicators to 'X' if the Shipping Conditions are SSA.
* Otherwise, the default of space indicates is not an SSA
  LOOP AT gt_vbap INTO gs_vbap.

    IF gs_vbap-vsbed IN gr_vsbed.

*     Set detail record SSA indicator
      gs_vbap-ssa_indicator = 'X'.

      MODIFY gt_vbap FROM gs_vbap INDEX sy-tabix
        TRANSPORTING ssa_indicator.

    ENDIF.

  ENDLOOP.

ENDFORM.                    " DETERMINE_SHIPPING_CONDITIONS
*&---------------------------------------------------------------------*
*&      Form  BUILD_RETURN_DATA
*&---------------------------------------------------------------------*
*       Build a return Header and Detail table
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_return_data .

  TYPES:

    BEGIN OF lts_tvsbt,
      vsbed  TYPE  vsbed,     "Shipping condition
      vtext  TYPE  vsbed_bez, "Shipping condition text
    END OF lts_tvsbt,

*   Begin BCB01
    BEGIN OF lts_ssa,
      werks      TYPE werks_d,     "Plant
      zzvsbed    TYPE vsbed,       "Shipping condition
      z_ssa_desc TYPE zz_ssa_desc, "Shipping condition text
    END OF lts_ssa.
*   End BCB01


  DATA:

    lv_ssa_identical  TYPE char1,
    lv_hold_vsbed     TYPE vsbed,

    lt_tvsbt  TYPE STANDARD TABLE OF lts_tvsbt,
    ls_tvsbt  TYPE lts_tvsbt,

*   Begin BCB01
    lt_ssa    TYPE STANDARD TABLE OF lts_ssa,
    ls_ssa    TYPE lts_ssa.
*   End BCB01


  CLEAR: gt_ssa_header,  "header return table
         gt_ssa_detail.  "detail return table

* Begin BCB01
* If user passes in a Shipping Point then they are seeking the
* Plant-specific SSA Descriptions.
  IF gv_vstel IS NOT INITIAL.
*   Retrieve all Plant-Specific Shipping Conditions text
    SELECT werks      "plant
           zzvsbed    "shipping condition
           z_ssa_desc "shipping condition text
      INTO TABLE lt_ssa
      FROM zssa_attribute.
    SORT lt_ssa.
  ELSE.
* End BCB01
*  If Shipping Point is blank then retrieve the "generic" Shipping
*  Condition English text
    SELECT vsbed  "shipping condition
           vtext  "shipping condition text
      INTO TABLE lt_tvsbt
      FROM tvsbt
      WHERE spras = 'E'.
    SORT lt_tvsbt.
  ENDIF.                                                    "BCB01

* Sort LIPS work table
  SORT gt_lips BY vbeln  "Delivery
                  posnr. "Delivery Item

* Process all of the Deliveries
  LOOP AT gt_vbeln INTO gs_vbeln.

*   Retrieve corresponding Shipment number
    READ TABLE gt_tknum_vbeln INTO gs_tknum_vbeln
      WITH KEY vbeln = gs_vbeln-vbeln
      BINARY SEARCH.

*   Retrieve Delivery line item info
    LOOP AT gt_lips INTO gs_lips WHERE vbeln = gs_vbeln-vbeln.

      CLEAR: gs_ssa_detail. "clear detail record

*     Format return table record
      gs_ssa_detail-tknum = gs_tknum_vbeln-tknum. "Shipment number
      gs_ssa_detail-vbeln = gs_lips-vbeln.  "Delivery number
      gs_ssa_detail-posnr = gs_lips-posnr.  "Delivery item
      gs_ssa_detail-vgbel = gs_lips-vgbel.  "Sales Order
      gs_ssa_detail-vgpos = gs_lips-vgpos.  "Sales Order item

*     Retrieve SSA Indicator and Shipping Condition & Text
      READ TABLE gt_vbap INTO gs_vbap
        WITH KEY vbeln = gs_lips-vgbel   "Sales Order
                 posnr = gs_lips-vgpos.  "Sales Order item
      IF sy-subrc = 0.
        gs_ssa_detail-ssa_indicator = gs_vbap-ssa_indicator.
        gs_ssa_detail-vsbed         = gs_vbap-vsbed.

*       Begin BCB01
*       If user passed in a Shipping Point then retrieve the Plant-
*       specific SSA Condition Text. Otherwise, get the standard
*       Shipping Condition text.
        IF gv_vstel IS NOT INITIAL.
          READ TABLE lt_ssa INTO ls_ssa
            WITH KEY werks = gv_werks
                     zzvsbed = gs_ssa_detail-vsbed
            BINARY SEARCH.
          IF sy-subrc = 0.
            gs_ssa_detail-vtext = ls_ssa-z_ssa_desc(75).
          ENDIF.
        ELSE.
*       End BCB01
*         Retrieve Shipping Condition Text
          READ TABLE lt_tvsbt INTO ls_tvsbt
            WITH KEY vsbed = gs_ssa_detail-vsbed
            BINARY SEARCH.
          IF sy-subrc = 0.
            gs_ssa_detail-vtext = ls_tvsbt-vtext.
          ENDIF.
        ENDIF.                                              "BCB01
      ENDIF.

*     Add detail record to return detail table
      APPEND gs_ssa_detail TO gt_ssa_detail.

    ENDLOOP.


*   Build Header record
    CLEAR: gs_ssa_header. "clear header record
    gs_ssa_header-vbeln = gs_vbeln-vbeln.  "Delivery

*   Determine if any Shipping Condition was an SSA Shipping Condition.
*   If so set header SSA Indicator to 'Y'. If not, leave the Header
*   SSA Indicator blank
    LOOP AT gt_ssa_detail INTO gs_ssa_detail
      WHERE vbeln = gs_vbeln-vbeln
        AND ssa_indicator = 'X'.
      gs_ssa_header-ssa_indicator = 'X'.
      EXIT.
    ENDLOOP.

*   Determine if all Shipping Conditions were the same for the Delivery
*   Items that had a Shipping Condition. If so, set the Header Shipping
*   Condition to that value. If not, leave the Header Shipping Condition
*   blank
    CLEAR: lv_hold_vsbed.
    lv_ssa_identical = 'X'. "default to true

    LOOP AT gt_ssa_detail INTO gs_ssa_detail
      WHERE vbeln = gs_vbeln-vbeln
        AND vsbed NE space.

      IF lv_hold_vsbed NE space.
        IF gs_ssa_detail-vsbed NE lv_hold_vsbed.
          lv_ssa_identical = space. "not identical
          EXIT.
        ENDIF.
        lv_hold_vsbed = gs_ssa_detail-vsbed.
      ENDIF.
    ENDLOOP.
    IF lv_ssa_identical = 'X'.
      gs_ssa_header-vsbed = gs_ssa_detail-vsbed.

*     Begin BCB01
*     If user passes in a Shipping Point then they are seeking the
*     Plant-specific SSA Descriptions.
      IF gv_vstel IS NOT INITIAL.
        READ TABLE lt_ssa INTO ls_ssa
          WITH KEY werks = gv_werks
                   zzvsbed = gs_ssa_detail-vsbed
          BINARY SEARCH.
        IF sy-subrc = 0.
          gs_ssa_header-vtext = ls_ssa-z_ssa_desc(75).
        ENDIF.
      ELSE.
*     End BCB01
*       Retrieve "generic" Shipping Condition Text
        READ TABLE lt_tvsbt INTO ls_tvsbt
          WITH KEY vsbed = gs_ssa_header-vsbed
          BINARY SEARCH.
        IF sy-subrc = 0.
          gs_ssa_header-vtext = ls_tvsbt-vtext.
        ENDIF.
      ENDIF.                                                "BCB01
    ENDIF.

*   Add header record to return header table
    APPEND gs_ssa_header TO gt_ssa_header.

  ENDLOOP.

ENDFORM.                    " BUILD_RETURN_DATA

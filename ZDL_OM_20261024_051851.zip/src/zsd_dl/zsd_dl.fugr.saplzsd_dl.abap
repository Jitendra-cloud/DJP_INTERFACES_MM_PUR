*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DLTOP.                        " Global Data
  INCLUDE LZSD_DLUXX.                        " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DLF...                        " Subprograms
* INCLUDE LZSD_DLO...                        " PBO-Modules
* INCLUDE LZSD_DLI...                        " PAI-Modules

INCLUDE LZSD_DLF01.

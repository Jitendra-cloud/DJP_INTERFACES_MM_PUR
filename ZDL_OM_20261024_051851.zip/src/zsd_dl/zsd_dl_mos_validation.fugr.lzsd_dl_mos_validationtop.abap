FUNCTION-POOL zsd_dl_mos_validation.        "MESSAGE-ID ..
TYPE-POOLS : zmos.

CONSTANTS : c_y TYPE char01 VALUE 'Y',
            c_n TYPE char01 VALUE 'N',
            c_s TYPE char01 VALUE 'S',
            c_complete TYPE char01 VALUE 'C',
            c_wm TYPE char10 VALUE 'WM',
            gc_tatx TYPE pstyv_vl      VALUE 'TATX'.        "BCB08


TYPES : BEGIN OF  ts_lips,
          vbeln   TYPE lips-vbeln,
          posnr   TYPE lips-posnr,
          matnr   TYPE lips-matnr,
          charg   TYPE charg_d,
          zzlfimg TYPE lips-zzlfimg,
          lfimg   TYPE lips-lfimg,
          uecha   TYPE uecha,
          pstyv   TYPE pstyv_vl, "Item Category BCB08 insert
          kosta   TYPE vbup-kosta,
          pksta   TYPE vbup-pksta,
       END OF  ts_lips.

TYPES : BEGIN OF ts_stage_deliveries,
          vbeln TYPE  likp-vbeln,
          dstst TYPE  zstopseq,
        END OF ts_stage_deliveries.

TYPES : BEGIN OF ts_total_deliveries,
          vbeln TYPE  likp-vbeln,
          dstst TYPE  zstopseq,
        END OF ts_total_deliveries.

TYPES : BEGIN OF ts_likp,
          vbeln TYPE vbeln_vl,
          vstel TYPE vstel,
          btgew TYPE gsgew,
         lgnum TYPE lgnum,
        END OF ts_likp.

TYPES : BEGIN OF ts_ltap,
          lgnum TYPE lgnum,
          tanum TYPE tanum,
          tapos TYPE tapos,
          vbeln TYPE vbeln_vl,
          posnr TYPE posnr,
          kzdif TYPE lvs_kzdif,
        END OF ts_ltap.

TYPES : BEGIN OF ts_t336t,
         lgnum TYPE lgnum,
         kzdif TYPE lvs_kzdif,
         dtext TYPE t336_dtext,
       END OF ts_t336t.

TYPES:

*  Unique Shipment HU's
  BEGIN OF gts_shiphu,
    exidv TYPE exidv, "ship levle hu as per the TO header
    kquit TYPE ltak_kquit, "TO confirmation indicator
  END OF gts_shiphu,

  tt_gts_shiphu TYPE TABLE OF gts_shiphu, "table type

*   Cross Ref table
  BEGIN OF gts_xref,
    pexidv TYPE exidv,    "ship level hu as per the TO header
    cexidv TYPE exidv,    "delivery level hu that s/b packed into shp
    cvenum TYPE venum,    "delivery level hu that s/b packed into shp
  END OF gts_xref,

  tt_gts_xref TYPE TABLE OF gts_xref. "table type


*-- Internal Tables
DATA : gt_stage_deliveries TYPE STANDARD TABLE OF ts_stage_deliveries,
       gt_total_deliveries  TYPE STANDARD TABLE OF ts_total_deliveries,
       gt_lips TYPE STANDARD TABLE OF ts_lips,
       gs_lips TYPE ts_lips,
       gt_likp TYPE STANDARD TABLE OF ts_likp,
       gt_ltap TYPE STANDARD TABLE OF ts_ltap,
       gt_t336t TYPE STANDARD TABLE OF ts_t336t.

DATA : gv_facility TYPE char10,
       gv_total_weight TYPE gsgew.

DATA : gs_itinerary  TYPE LINE OF zmos_itinerary_s ,
       gt_itinerary TYPE zmos_itinerary_s .

* Begin BCB01 insert
DATA:
  gt_zdlfields TYPE STANDARD TABLE OF zdl_fields,
  gs_zdlfields TYPE zdl_fields,

  gv_sto_deliveries TYPE char1.
* End BCB01 insert

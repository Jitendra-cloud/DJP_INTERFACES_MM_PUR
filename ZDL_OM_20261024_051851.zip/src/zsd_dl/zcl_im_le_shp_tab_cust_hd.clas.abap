class ZCL_IM_LE_SHP_TAB_CUST_HD definition
  public
  final
  create public .

*"* public components of class ZCL_IM_LE_SHP_TAB_CUST_HD
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_LE_SHP_TAB_CUST_HEAD .
protected section.
*"* protected components of class ZCL_IM_LE_SHP_TAB_CUST_HD
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_LE_SHP_TAB_CUST_HD
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_LE_SHP_TAB_CUST_HD IMPLEMENTATION.


METHOD if_ex_le_shp_tab_cust_head~activate_tab_page .
*&**********************************************************************
*&                                                                     *
*&             C O M P A N Y   C O N F I D E N T I A L                 *
*&                                                                     *
*&        This program is the property of International Paper.         *
*&        Care should be taken to prevent its unauthorized use.        *
*&                                                                     *
*&**********************************************************************
*&                                                                     *
*&             COPYRIGHT © 2018 by INTERNATIONAL PAPER                 *
*&                                                                     *
*&                     ALL RIGHTS RESERVED                             *
*&                                                                     *
*&                     REVISIONS COPYRIGHT ©                           *
*&                       20xx, 20yy, 20zz                              *
*&                             by                                      *
*&                     INTERNATIONAL PAPER                             *
*&                                                                     *
*&**********************************************************************
*& Program Name: DL:E11057:Delivery SCAC for RFSCOP                    *
*& SAP Name    : ZDLE11057_RFSCOP_SCAC_SCREEN                          *
*& Written by  : Mallik Aiely                                          *
*& Date written: 16-May-2018                                           *
*& COR ID      : E11057                                                *
*& Description :                                                       *
*&   Subscreen on delivery header to display SCAC data                 *
*&**********************************************************************
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* =====================================================================*
* Mallik Aiely        05/16/18  E0VK9A0XBF   CMS33297:Delivery header  *
*                                            SCAC Subscreen            *
* =====================================================================*
  ef_caption = 'Additional Data A'.
*  ef_program = 'SAPMV50A'.           "CMS33297


  ef_program = 'SAPLZDLE11057_RFSCOP_SCAC'.                 "CMS33297
  ef_dynpro = '9100'.                                       "CMS33297

ENDMETHOD.


method IF_EX_LE_SHP_TAB_CUST_HEAD~PASS_FCODE_TO_SUBSCREEN .
endmethod.


METHOD if_ex_le_shp_tab_cust_head~transfer_data_from_subscreen .

ENDMETHOD.


METHOD if_ex_le_shp_tab_cust_head~transfer_data_to_subscreen .
*&**********************************************************************
*&                                                                     *
*&             C O M P A N Y   C O N F I D E N T I A L                 *
*&                                                                     *
*&        This program is the property of International Paper.         *
*&        Care should be taken to prevent its unauthorized use.        *
*&                                                                     *
*&**********************************************************************
*&                                                                     *
*&             COPYRIGHT © 2018 by INTERNATIONAL PAPER                 *
*&                                                                     *
*&                     ALL RIGHTS RESERVED                             *
*&                                                                     *
*&                     REVISIONS COPYRIGHT ©                           *
*&                       20xx, 20yy, 20zz                              *
*&                             by                                      *
*&                     INTERNATIONAL PAPER                             *
*&                                                                     *
*&**********************************************************************
*& Program Name: DL:E11057:Delivery SCAC for RFSCOP                    *
*& SAP Name    : ZDLE11057_RFSCOP_SCAC_SCREEN                          *
*& Written by  : Mallik Aiely                                          *
*& Date written: 16-May-2018                                           *
*& COR ID      : E11057                                                *
*& Description :                                                       *
*&   Subscreen on delivery header to display SCAC data                 *
*&**********************************************************************
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* =====================================================================*
* Mallik Aiely        05/16/18  E0VK9A0XBF   CMS33297:Delivery header  *
*                                            SCAC Subscreen            *
* =====================================================================*

  CALL FUNCTION 'ZDLE11057_RFSCOP_SET_SCAC_DATA'
    EXPORTING
      is_likp = is_likp.

ENDMETHOD.
ENDCLASS.

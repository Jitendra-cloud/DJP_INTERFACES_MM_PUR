*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSDR1460_SHPMNTS................................*
DATA:  BEGIN OF STATUS_ZSDR1460_SHPMNTS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSDR1460_SHPMNTS              .
CONTROLS: TCTRL_ZSDR1460_SHPMNTS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSDR1460_SHPMNTS              .
TABLES: ZSDR1460_SHPMNTS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*----------------------------------------------------------------------*
***INCLUDE LZSD_U01217F01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  clear_variables
*&---------------------------------------------------------------------*
* This routines clears the variables, structures and internal tables
**----------------------------------------------------------------------
**
FORM clear_variables .
  CLEAR : gt_zppkiwifped[], gt_zppkiwifped_tmp[],gt_zppfped_status[] ,
          gt_postab_temp, gt_fped_loc,gt_zsp_value,

          gs_zppfped_status, gs_lipov,

          gv_rec_count ,gv_status.

ENDFORM.                    " clear_variables

*&---------------------------------------------------------------------*
*&      Form  get_zppfped_status
*&---------------------------------------------------------------------*
* This routine gets records from table  zppfped_status for all entries
* in et_postab
*----------------------------------------------------------------------*
*      -->P_ET_POSTAB  text
*----------------------------------------------------------------------*
FORM get_zppfped_status  TABLES   p_et_postab STRUCTURE lipov.

  SELECT * INTO TABLE gt_zppfped_status
   FROM zppfped_status
   FOR ALL ENTRIES IN p_et_postab
   WHERE vbeln = p_et_postab-vbeln.

  CHECK NOT gt_zppfped_status IS INITIAL.

  SORT gt_zppfped_status BY vbeln_v posnr_v.

  DELETE ADJACENT DUPLICATES FROM gt_zppfped_status COMPARING vbeln_v
  posnr_v.

  SORT gt_zppfped_status BY vbeln  posnr .

ENDFORM.                    " get_zppfped_status
*&---------------------------------------------------------------------*
*&      Form  get_zppkiwifped
*&---------------------------------------------------------------------*
* This routine gets records from table zppkiwifped for all entries in
* gt_zppfped_status
*----------------------------------------------------------------------*
FORM get_zppkiwifped .



  SELECT * INTO TABLE gt_zppkiwifped
    FROM zppkiwifped
    FOR ALL ENTRIES IN gt_zppfped_status
    WHERE vbeln = gt_zppfped_status-vbeln_v
    AND   posnr = gt_zppfped_status-posnr_v.

  CHECK NOT gt_zppkiwifped IS INITIAL.

  SORT gt_zppkiwifped BY vbeln posnr .


ENDFORM.                    " get_zppkiwifped


*&---------------------------------------------------------------------*
*&      Form  get_plant_shipping_point
*&---------------------------------------------------------------------*
* This routine gets records from table zdl_fped_loc and stores in
* gt_fped_loc
*----------------------------------------------------------------------*

FORM get_plant_shipping_point .

  SELECT * INTO TABLE gt_fped_loc FROM zdl_fped_loc.
  SORT gt_fped_loc BY werks vstel.

ENDFORM.                    " get_plant_shipping_point
*&---------------------------------------------------------------------*
*&      Form  get_zsp_value
*&---------------------------------------------------------------------*
* This routine gets records from table zsp_value and stores in
* gt_zsp_value
*----------------------------------------------------------------------*

FORM get_zsp_value .

  SELECT * INTO TABLE gt_zsp_value FROM zsp_value
   WHERE pgrmid = gc_pgrmid.

  SORT gt_zsp_value BY fieldvalue.
ENDFORM.                    " get_zsp_value


*&---------------------------------------------------------------------*
*&      Form  populate_field_Values
*&---------------------------------------------------------------------*
* This routine populates the Delivery Header and Item values
*----------------------------------------------------------------------*
*      -->P_ET_POSTAB  text
*----------------------------------------------------------------------*
FORM populate_field_values  TABLES   p_et_postab STRUCTURE lipov.

*------  Begin EDEK911357  EDEK911462  --------------------------------*
data:  lv_vbeln                       TYPE VBELN_VL,
       lv_count(09)                   TYPE N,
       lv_work14_1(14)                TYPE C,
       lv_work14_2(14)                TYPE C,
       lv_earliest_start_dt           TYPE ZZ_FPED_START_DT_ITM,
       lv_earliest_start_tm           TYPE ZZ_FPED_START_TM_ITM,
       lv_latest_end_dt               TYPE ZZ_FPED_END_DT_ITM,
       lv_latest_end_tm               TYPE ZZ_FPED_END_TM_ITM,
       lv_status_item                 TYPE ZZ_FPED_STATUS_ITM,
       lv_status_chg_flag(01)         TYPE C,
       lv_status_late_flag(01)        TYPE C,
       lv_first_line_flag(01)         TYPE C,
       lv_BESKZ                       TYPE BESKZ, "Procurement Type
       lv_SOBSL                       TYPE SOBSL. "Specl procurmnt type
*------  End   EDEK911357  EDEK911462  --------------------------------*

  DATA: ls_zppkiwifped LIKE zppkiwifped,
        lv_index LIKE sy-tabix.


  SORT p_et_postab BY vbeln ASCENDING posnr DESCENDING.

  LOOP AT p_et_postab INTO gs_lipov.
    CLEAR   : gv_rec_count,gt_zppkiwifped_tmp,ls_zppkiwifped,lv_index,
              gt_zppfped_status_tmp,gs_zppfped_status,gt_postab_temp.
    REFRESH : gt_zppkiwifped_tmp,gt_zppfped_status_tmp,gt_postab_temp.

*Check for plant/shipping point in table ZDL_FPED_LOC
    READ TABLE gt_fped_loc WITH KEY
               werks = gs_lipov-werks
               vstel = gs_lipov-vstel
               BINARY SEARCH.
    IF sy-subrc <> 0.
      READ TABLE gt_fped_loc WITH KEY
                 vstel = gs_lipov-vstel
                 BINARY SEARCH.

      IF sy-subrc <> 0.
        CONTINUE.
      ENDIF.
    ENDIF.

*Check Delivery type in table ZSP_VALUE
    READ TABLE gt_zsp_value WITH KEY
               fieldvalue = gs_lipov-lfart
               BINARY SEARCH.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    READ TABLE gt_zppfped_status INTO gs_zppfped_status
               WITH KEY vbeln = gs_lipov-vbeln
                        posnr = gs_lipov-posnr
                        BINARY SEARCH.

    IF sy-subrc <> 0.
      READ TABLE gt_zppfped_status INTO gs_zppfped_status
                 WITH KEY vbeln = gs_lipov-vbeln
                          BINARY SEARCH.

    ENDIF.

    IF sy-subrc = 0.                                          "1
      READ TABLE gt_zppkiwifped INTO ls_zppkiwifped
               WITH KEY vbeln = gs_zppfped_status-vbeln_v
               BINARY SEARCH.
      IF sy-subrc EQ 0.                                        "2
        lv_index = sy-tabix.
        LOOP AT  gt_zppkiwifped INTO ls_zppkiwifped
                 FROM lv_index
                  WHERE vbeln EQ gs_zppfped_status-vbeln_v.
          gt_zppkiwifped_tmp = ls_zppkiwifped.

*begin of TPR 22705 EDVK960014 PRAGUPA 01/24/2008
          READ TABLE gt_zppfped_status INTO gs_zppfped_status_tmp
                    WITH KEY vbeln_v = ls_zppkiwifped-vbeln
                             posnr_v = ls_zppkiwifped-posnr.


          IF sy-subrc <> 0.
            READ TABLE gt_zppfped_status INTO gs_zppfped_status_tmp
                       WITH KEY vbeln_v = ls_zppkiwifped-vbeln.

          ENDIF.
          gt_zppkiwifped_tmp-dlvry = gs_zppfped_status_tmp-vbeln.
*end of TPR 22705 EDVK960014 PRAGUPA 01/24/2008

          APPEND gt_zppkiwifped_tmp.
          CLEAR : gt_zppkiwifped_tmp,gs_zppfped_status_tmp.
        ENDLOOP.

        SORT gt_zppkiwifped_tmp[] BY vbeln posnr.
      ENDIF.                                                   "2


   READ TABLE p_et_postab WITH KEY vbeln = gs_lipov-vbeln BINARY SEARCH.
      IF sy-subrc EQ 0.                                        "3
        lv_index = sy-tabix.
        LOOP AT p_et_postab FROM lv_index
                   WHERE vbeln EQ gs_lipov-vbeln.
          gt_postab_temp = p_et_postab.
          APPEND gt_postab_temp.
          CLEAR gt_postab_temp.
        ENDLOOP.
      ENDIF.                                                    "3


      CASE gs_lipov-posnr.
************************Populating Header Values
        WHEN gc_posnr_hdr   .

*Delivery Header production order number
          PERFORM update_header_po.
*Delivery Header level Start date/time and End date/time
          PERFORM update_header_date_time.
*Delivery Header level FPED status
          PERFORM update_header_status.

************************Populating Item Values
        WHEN OTHERS.

          DELETE gt_zppkiwifped_tmp[]
                 WHERE vbeln NE gs_zppfped_status-vbeln_v
                 OR    posnr NE gs_zppfped_status-posnr_v.

*Delivery Item production order number
          PERFORM update_item_po.
*Delivery Item level Start date/time and End date/time
          PERFORM update_item_date_time.
*Delivery item level fped status
          PERFORM update_item_status.

      ENDCASE.

      MODIFY p_et_postab FROM gs_lipov.
    ENDIF.                                                    "1

  ENDLOOP.

  SORT p_et_postab.

*----------------------------------------------------------------------*
*------  Begin EDEK911357  EDEK911462  --------------------------------*
*----------------------------------------------------------------------*
*------  Subcontracting Final Production End Date (FPED) logic  -------*
* This logic updates Header and Item information for subcontracting  --*
* delivery data for transaction VL06T.                          -------*
* Delivery types = 'LB' or 'LF'                                 -------*
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
*------  Delivery Type = 'LB' Subcontracting Components         -------*
*------  Plant to Vendor                                        -------*
*----------------------------------------------------------------------*
  LOOP AT p_et_postab INTO gs_lipov
                     where lfart = gc_LB.                    "LB

*   Header Record
    IF gs_lipov-posnr = '000000'.                            "Header Rec
      clear: gs_lipov-ZZ_PROD_ORDER_NO_HDR,
             gs_lipov-ZZ_FPED_START_DT_HDR,
             gs_lipov-ZZ_FPED_START_TM_HDR,
             gs_lipov-ZZ_FPED_END_DT_HDR,
             gs_lipov-ZZ_FPED_END_TM_HDR.
      gs_lipov-ZZ_FPED_STATUS_HDR = gc_SC2V.                 "SC2V
    ENDIF.

*   Line Item Records
    IF gs_lipov-posnr > '000000'.                            "Item Rec
      clear: gs_lipov-ZZ_PROD_ORDER_NO_ITM,
             gs_lipov-ZZ_FPED_START_DT_ITM,
             gs_lipov-ZZ_FPED_START_TM_ITM,
             gs_lipov-ZZ_FPED_END_DT_ITM,
             gs_lipov-ZZ_FPED_END_TM_ITM.
      gs_lipov-ZZ_FPED_STATUS_ITM = gc_SC2V.                 "SC2V
    ENDIF.

*   Save It
    MODIFY p_et_postab FROM gs_lipov.

  ENDLOOP.


*----------------------------------------------------------------------*
*------  Delivery Type = 'LF' Subcontracting Finished Goods Matls  ----*
*------  Plant to Customer                                      -------*
*----------------------------------------------------------------------*
  LOOP AT p_et_postab INTO gs_lipov.                  "PRODUCTION

*------  At New Delivery  ---------------------------------------------*
    AT NEW VBELN.
      lv_count = 0.
      clear: gs_dlv_lf,
             lv_vbeln,
             lv_earliest_start_dt,
             lv_earliest_start_tm,
             lv_latest_end_dt,
             lv_latest_end_tm,
             lv_status_item,
             lv_status_chg_flag,
             lv_status_late_flag,
             lv_first_line_flag.
    ENDAT.

*------  Line Item Records  -------------------------------------------*
    IF gs_lipov-posnr > '000000' and          "Line item
       gs_lipov-lfart = gc_LF.                "LF


*     When this is 1st line item for this delivery-save the item status
      IF lv_first_line_flag is initial.                  "1st line item
        lv_status_item       = gs_lipov-ZZ_FPED_STATUS_ITM.
        lv_first_line_flag   = gc_X.
       ELSE.
*       Check the Status and set status change flag
        IF lv_first_line_flag = gc_X  AND                "2nd,3rd,...,n
           gs_lipov-ZZ_FPED_STATUS_ITM <> lv_status_item. "Got a change?
          lv_status_chg_flag = 'X'.                       "Status chgd
          lv_status_item = gs_lipov-ZZ_FPED_STATUS_ITM.
        ENDIF.
      ENDIF.

      clear: lv_BESKZ,                        "Procurement Type
             lv_SOBSL.                        "Special Procurement Type

      PERFORM GET_MARC_DATA    using     gs_lipov-matnr
                                         gs_lipov-vstel
                               changing  lv_BESKZ
                                         lv_SOBSL.

*     Only use detail lines that are eligible - skip all other lines.
      IF lv_BESKZ = gc_F   AND                               "F
         lv_SOBSL = gc_30.                                   "30
        lv_count = lv_count + 1.              "Got Eligible Line

*       If 1st eligible line - save data values into work variables.
        IF lv_count = 1.
          lv_vbeln             = gs_lipov-vbeln.
          lv_earliest_start_dt = gs_lipov-ZZ_FPED_START_DT_ITM.
          lv_earliest_start_tm = gs_lipov-ZZ_FPED_START_TM_ITM.
          lv_latest_end_dt     = gs_lipov-ZZ_FPED_END_DT_ITM.
          lv_latest_end_tm     = gs_lipov-ZZ_FPED_END_TM_ITM.
          lv_status_chg_flag   = space.
          lv_status_late_flag  = space.

          IF gs_lipov-ZZ_FPED_STATUS_ITM = gc_LATE or        "LATE
             gs_lipov-ZZ_FPED_STATUS_ITM = gc_LITC.          "LITC
            lv_status_late_flag = gc_X.                      "X
          ENDIF.

*        When 2,3,4,…,n line - check for earliest and latest date/time
*        Now, the comparisons to the 1st line can be done
         ELSE.
          concatenate gs_lipov-ZZ_FPED_START_DT_ITM
                      gs_lipov-ZZ_FPED_START_TM_ITM
                 into lv_work14_1.

          concatenate lv_earliest_start_dt lv_earliest_start_tm
                 into lv_work14_2.

*         Save Earliest Start Date and Time
          IF lv_work14_1 <> '00000000000000' AND
             lv_work14_1 <  lv_work14_2.
            lv_earliest_start_dt = gs_lipov-ZZ_FPED_START_DT_ITM.
            lv_earliest_start_tm = gs_lipov-ZZ_FPED_START_TM_ITM.
          ENDIF.


          concatenate gs_lipov-ZZ_FPED_END_DT_ITM
                      gs_lipov-ZZ_FPED_END_TM_ITM
                 into lv_work14_1.

          concatenate lv_latest_end_dt lv_latest_end_tm
                 into lv_work14_2.

*         Save Latest End Date and Time
          IF lv_work14_1 <> '00000000000000' AND
             lv_work14_1 >  lv_work14_2.
            lv_latest_end_dt = gs_lipov-ZZ_FPED_END_DT_ITM.
            lv_latest_end_tm = gs_lipov-ZZ_FPED_END_TM_ITM.
          ENDIF.

          IF gs_lipov-ZZ_FPED_STATUS_ITM = gc_LATE or        "LATE
             gs_lipov-ZZ_FPED_STATUS_ITM = gc_LITC.          "LITC
            lv_status_late_flag = gc_X.                      "X
          ENDIF.

        ENDIF.      "IF lv_count = 1......
      ENDIF.      "IF lv_BESKZ = gc_F   AND......
    ENDIF.      "IF gs_lipov-posnr > '000000' and......

*------  At End of Delivery  ------------------------------------------*
    AT END OF VBELN.
*------  Save Summary Info-When there is 1 or more elig lines found ---*
      IF lv_count > 0.
        gs_dlv_lf-VBELN                   = lv_vbeln.
        gs_dlv_lf-COUNT                   = lv_count.
        gs_dlv_lf-FPED_START_DT_HDR       = lv_earliest_start_dt.
        gs_dlv_lf-FPED_START_TM_HDR       = lv_earliest_start_tm.
        gs_dlv_lf-FPED_END_DT_HDR         = lv_latest_end_dt.
        gs_dlv_lf-FPED_END_TM_HDR         = lv_latest_end_tm.

*       If FPED statuses are the same at line items,use it for header
*       If one of the item statuses is LITC or LATE,use LATE for header
*       If the item statuses are different and not LATE or LITC,use '*'
        IF lv_status_chg_flag = space.
          gs_dlv_lf-FPED_STATUS_HDR       = lv_status_item.
        ENDIF.
        IF lv_status_late_flag = gc_X.                       "X
          gs_dlv_lf-FPED_STATUS_HDR       = gc_LATE.         "LATE
        ENDIF.
        IF lv_status_chg_flag = gc_X and                     "X
           lv_status_late_flag = space.
          gs_dlv_lf-FPED_STATUS_HDR       = gc_*.            "*
        ENDIF.

*       Save Summary Info
        APPEND gs_dlv_lf to gt_dlv_lf.
      ENDIF.      "IF lv_count > 0......
    ENDAT.

  ENDLOOP.

* Sort the Delivery Summary Info Records
  SORT gt_dlv_lf  by  VBELN.               "Delivery Number


*----------------------------------------------------------------------*
* Loop thru the table and find the type 'LF' records.
* Update the table records from the captured data in gt_dlv_lf Summary
*----------------------------------------------------------------------*

  LOOP AT p_et_postab INTO gs_lipov.                       "PRODUCTION

    lv_index = sy-tabix.               "Save the sy-index

*------  Detail Lines  ------------------------------------------------*
    IF gs_lipov-lfart = gc_LF.                               "LF

*     Does this Delivery have a Summary Info Record ?
      READ table gt_dlv_lf into gs_dlv_lf
                           with key vbeln =  gs_lipov-vbeln
                                             binary search.

      IF sy-subrc = 0.
*       When there is only 1 item record for this Delivery
        IF gs_dlv_lf-count = 1.
*         Header Record
          IF gs_lipov-posnr = '000000'.                    "Header Rec
            clear: gs_lipov-ZZ_PROD_ORDER_NO_HDR,
                   gs_lipov-ZZ_FPED_START_DT_HDR,
                   gs_lipov-ZZ_FPED_START_TM_HDR,
                   gs_lipov-ZZ_FPED_END_DT_HDR,
                   gs_lipov-ZZ_FPED_END_TM_HDR.
            gs_lipov-ZZ_FPED_STATUS_HDR = gc_SC2C.         "SC2C
          ENDIF.

*         Line Item Record
          IF gs_lipov-posnr > '000000'.                    "Item Rec
            clear: lv_BESKZ,                  "Procurement Type
                   lv_SOBSL.                  "Special Procurement Type

            PERFORM GET_MARC_DATA    using     gs_lipov-matnr
                                               gs_lipov-vstel
                                     changing  lv_BESKZ
                                               lv_SOBSL.

*           Must be a Subcontracting Finished Goods Matl to be eligible.
            IF lv_BESKZ = gc_F   AND                          "F
               lv_SOBSL = gc_30.                              "30
              clear: gs_lipov-ZZ_PROD_ORDER_NO_ITM,
                     gs_lipov-ZZ_FPED_START_DT_ITM,
                     gs_lipov-ZZ_FPED_START_TM_ITM,
                     gs_lipov-ZZ_FPED_END_DT_ITM,
                     gs_lipov-ZZ_FPED_END_TM_ITM.
              gs_lipov-ZZ_FPED_STATUS_ITM = gc_SC2C.         "SC2C
            ENDIF.

          ENDIF.
        ENDIF.      "IF gs_dlv_lf-count = 1......

*       When there is more that 1 elig item record for this Delivery
        IF gs_dlv_lf-count > 1.

*         Header Record
          IF gs_lipov-posnr = '000000'.                    "Header Rec
            gs_lipov-ZZ_PROD_ORDER_NO_HDR = gc_*.            "*
            gs_lipov-ZZ_FPED_START_DT_HDR =
                                            gs_dlv_lf-FPED_START_DT_HDR.
            gs_lipov-ZZ_FPED_START_TM_HDR =
                                            gs_dlv_lf-FPED_START_TM_HDR.
            gs_lipov-ZZ_FPED_END_DT_HDR   = gs_dlv_lf-FPED_END_DT_HDR.
            gs_lipov-ZZ_FPED_END_TM_HDR   = gs_dlv_lf-FPED_END_TM_HDR.
            gs_lipov-ZZ_FPED_STATUS_HDR   = gs_dlv_lf-FPED_STATUS_HDR.
          ENDIF.

*         Line Item Records
          IF gs_lipov-posnr > '000000'.                    "Item Rec
            clear: lv_BESKZ,                  "Procurement Type
                   lv_SOBSL.                  "Special Procurement Type

            PERFORM GET_MARC_DATA    using     gs_lipov-matnr
                                               gs_lipov-vstel
                                     changing  lv_BESKZ
                                               lv_SOBSL.

*           Must be a Subcontracting Finished Goods Matl to be eligible.
*             When a line is not eligible - do not make any changes
            IF lv_BESKZ = gc_F   AND                          "F
               lv_SOBSL = gc_30.                              "30
              gs_lipov-ZZ_FPED_STATUS_ITM = gc_SC2C.          "SC2C
              gs_lipov-ZZ_PROD_ORDER_NO_ITM = '*'.            "*
            ENDIF.

          ENDIF.      "IF gs_lipov-posnr > '000000'......
        ENDIF.      "IF gs_dlv_lf-count > 1......

*       Save the changed data fields
        MODIFY p_et_postab FROM gs_lipov  index lv_index.

      ENDIF.      "IF sy-subrc = 0......
    ENDIF.      "gs_lipov-lfart = gc_LF......
  ENDLOOP.

*------  End   EDEK911357  EDEK911462  --------------------------------*

ENDFORM.                    " populate_field_Values


*&---------------------------------------------------------------------*
*&      Form  update_header_PO
*&---------------------------------------------------------------------*
* This routine updates Delivery Header production order number
* If multiple delivery items exist, update the delivery header level
* Production Order No. field with ‘*’
* Else update the delivery header level production order no. with the
* corresponding line item value.
*----------------------------------------------------------------------*

FORM update_header_po .

  gt_zppfped_status_tmp[] = gt_zppfped_status[].

  DELETE gt_zppfped_status_tmp WHERE vbeln NE gs_lipov-vbeln.

*Get the number of records
  DESCRIBE TABLE gt_zppfped_status_tmp LINES gv_rec_count.

*If multiple records exists then update with a '*'
  IF gv_rec_count GT 1.
    gs_lipov-zz_prod_order_no_hdr = gc_*.
*If single record exists then update with Production order no.
  ELSE.
    READ TABLE gt_zppkiwifped_tmp
               WITH KEY vbeln = gs_zppfped_status-vbeln_v
                        posnr = gs_zppfped_status-posnr_v.

    IF sy-subrc EQ 0.
      gs_lipov-zz_prod_order_no_hdr = gt_zppkiwifped_tmp-aufnr.
    ENDIF.
  ENDIF.
ENDFORM.                    " update_header_PO




*&---------------------------------------------------------------------*
*&      Form  update_header_date_time
*&---------------------------------------------------------------------*
*  This routine updates Delivery Header Start date/time , End date/time.
*  Select the min start date/time and the max finish date/time for all
*  corresponding delivery items and update at the header level
*----------------------------------------------------------------------*

FORM update_header_date_time .

*begin of TPR 22705 EDVK960014 PRAGUPA 01/24/2008
  DELETE gt_zppkiwifped_tmp WHERE dlvry NE gs_lipov-vbeln.
*end of TPR 22705 EDVK960014 PRAGUPA 01/24/2008

*Header start date/time
  SORT gt_zppkiwifped_tmp  BY zz_fped_start_dt ASCENDING
                        zz_fped_start_tm ASCENDING.

  READ TABLE gt_zppkiwifped_tmp INDEX 1.
  gs_lipov-zz_fped_start_dt_hdr =
  gt_zppkiwifped_tmp-zz_fped_start_dt.
  gs_lipov-zz_fped_start_tm_hdr =
  gt_zppkiwifped_tmp-zz_fped_start_tm.

*Header End date/time
  SORT gt_zppkiwifped_tmp BY fped_date DESCENDING
                             fped_time DESCENDING.
  READ TABLE gt_zppkiwifped_tmp INDEX 1.

  gs_lipov-zz_fped_end_dt_hdr = gt_zppkiwifped_tmp-fped_date.
  gs_lipov-zz_fped_end_tm_hdr = gt_zppkiwifped_tmp-fped_time.


ENDFORM.                    " update_header_date_time


*&---------------------------------------------------------------------*
*&      Form  update_header_status
*&---------------------------------------------------------------------*
* This routine updates Delivery Header status
* If all delivery line items are the same, update the delivery header
* level FPED status field with the value;
* Elseif any of the delivery items are ‘LATE’ or ‘LITC’, then update the
* delivery header level FPED status field with ‘LATE’
* Else update with ‘*’ (which assumes that multiple values exist across
* delivery items
*----------------------------------------------------------------------*

FORM update_header_status .

  CLEAR : gv_status .
*Begin of change 11/28/2007 TPR 13650
  DATA: lv_tabix LIKE sy-tabix.
*End of change 11/28/2007 TPR 13650


  DELETE gt_postab_temp
             WHERE vbeln NE gs_lipov-vbeln
              OR   posnr EQ gc_posnr_hdr.

  LOOP AT gt_postab_temp WHERE posnr NE gc_posnr_hdr .
    lv_tabix = sy-tabix.
    IF gs_lipov-zz_fped_status_hdr <> gt_postab_temp-zz_fped_status_itm.
      gs_lipov-zz_fped_status_hdr = gt_postab_temp-zz_fped_status_itm.
      CLEAR gv_status.
*Begin of change 11/28/2007 TPR 13650
      IF lv_tabix NE 1.
        EXIT.
      ENDIF.
*End of change 11/28/2007 TPR 13650

    ELSE.
      gv_status = 'X'.
    ENDIF.
  ENDLOOP.


  DESCRIBE TABLE gt_postab_temp LINES gv_rec_count.

  IF gv_status <> 'X' AND gv_rec_count GT 1.
    gs_lipov-zz_fped_status_hdr = gc_*.
  ELSE.
    EXIT.
  ENDIF.


  READ TABLE gt_postab_temp WITH KEY
    zz_fped_status_itm = gc_late..
  IF sy-subrc = 0.
    gs_lipov-zz_fped_status_hdr = gc_late.
  ELSE.
    READ TABLE gt_postab_temp WITH KEY
     zz_fped_status_itm = gc_litc.
    IF sy-subrc = 0.
      gs_lipov-zz_fped_status_hdr = gc_late.
    ENDIF.
  ENDIF.





ENDFORM.                    " update_header_status


*&---------------------------------------------------------------------*
*&      Form  update_item_PO
*&---------------------------------------------------------------------*
* This routine updates Delivery Item production order number.
* Select the production order no. from ZPPKIWIFPED for the corresponding
* delivery item sales order and sales order item;  if multiple records
* exist in ZPPKIWIFPED, then update with a ‘*’ to indicate multiple
* production orders exist; else update with corresponding production
* order no.
*----------------------------------------------------------------------*

FORM update_item_po .
*Get the number of records
  DESCRIBE TABLE gt_zppkiwifped_tmp LINES gv_rec_count.

*If multiple records exists then update with a '*'
  IF gv_rec_count GT 1.
    gs_lipov-zz_prod_order_no_itm = gc_*.
*If single record exists then update with Production order no.
  ELSE.
    READ TABLE gt_zppkiwifped_tmp INDEX 1.
    gs_lipov-zz_prod_order_no_itm = gt_zppkiwifped_tmp-aufnr.
  ENDIF.
ENDFORM.                    " update_item_PO


*&---------------------------------------------------------------------*
*&      Form  update_item_date_time
*&---------------------------------------------------------------------*
* This routine updates Delivery Item Start date/time, End date/time.
* select the sales order item “start date and time” and the sales
* order item “finish date and time” for the corresponding delivery from
* ZPPKIWIFPED table and update in the start date/time and finish
* date/time fields respectively.
* (if multiple  records exist for sales order and item, select record
* based on the max change date/time ).
*----------------------------------------------------------------------*

FORM update_item_date_time .

*Item start date/item
  SORT gt_zppkiwifped_tmp BY change_timestam DESCENDING.

  READ TABLE gt_zppkiwifped_tmp INDEX 1.

  gs_lipov-zz_fped_start_dt_itm =
  gt_zppkiwifped_tmp-zz_fped_start_dt.
  gs_lipov-zz_fped_start_tm_itm =
  gt_zppkiwifped_tmp-zz_fped_start_tm.

*Item End date/time
  gs_lipov-zz_fped_end_dt_itm = gt_zppkiwifped_tmp-fped_date.
  gs_lipov-zz_fped_end_tm_itm = gt_zppkiwifped_tmp-fped_time.



ENDFORM.                    " update_item_date_time


*&---------------------------------------------------------------------*
*&      Form  update_item_status
*&---------------------------------------------------------------------*
*   This routine updates Delivery Item status
*----------------------------------------------------------------------*
FORM update_item_status .

*If the status in zppfed_status eq 'N' move 'YSTK'
  IF gs_zppfped_status-prod_status EQ gc_n .       "Item
    gs_lipov-zz_fped_status_itm = gc_ystk.
*If the status in zppfed_status eq ' ' move ' '
  ELSEIF gs_zppfped_status-prod_status EQ gc_space .
    gs_lipov-zz_fped_status_itm = gc_space.
  ELSE.
*Get the max sales order item "finish date and time"
    SORT gt_zppkiwifped_tmp BY fped_date DESCENDING
                               fped_time DESCENDING.
    READ TABLE gt_zppkiwifped_tmp INDEX 1.

*If the max finish date and time from zppkiwifped is greater than
*original MAD date and time
    IF ( gt_zppkiwifped_tmp-fped_date >                  "1
         gs_zppfped_status-mbdat )
    OR ( gt_zppkiwifped_tmp-fped_date =                  "1
         gs_zppfped_status-mbdat
   AND   gt_zppkiwifped_tmp-fped_time >
         gs_zppfped_status-mbuhr ).


*If the status in ZPPFPED_STATUS eq 'I' move 'LITC'
      IF gs_zppfped_status-prod_status EQ gc_i.
        gs_lipov-zz_fped_status_itm = gc_litc.
*If the status in ZPPFPED_STATUS eq 'X' or 'P' move 'LATE'
      ELSEIF ( gs_zppfped_status-prod_status EQ gc_x ) OR
             ( gs_zppfped_status-prod_status EQ gc_p ) .
        gs_lipov-zz_fped_status_itm = gc_late.
      ENDIF.

    ELSE.                                              "1

      IF gs_zppfped_status-prod_status EQ gc_i.
        gs_lipov-zz_fped_status_itm = gc_zitc.

      ELSEIF  gs_zppfped_status-prod_status EQ gc_x   .
        gs_lipov-zz_fped_status_itm = gc_fped.
      ELSE.
        gs_lipov-zz_fped_status_itm = gc_yfpe.
      ENDIF.

    ENDIF.                                              "1


  ENDIF.                                        "Item

ENDFORM.                    " update_item_status

*&---------------------------------------------------------------------*
*&      Form  GET_MARC_DATA
*&---------------------------------------------------------------------*
*----------------------------------------------------------------------*
*------  Begin EDEK911357  EDEK911462  --------------------------------*
*----------------------------------------------------------------------*
*----------------------------------------------------------------------*
*      -->P_GS_LIPOV_MATNR  text
*      -->P_GS_LIPOV_VSTEL  text
*      <--P_LV_BESKZ  text
*      <--P_LV_SOBSL  text
*----------------------------------------------------------------------*
FORM GET_MARC_DATA  USING    P_GS_LIPOV_MATNR  TYPE MATNR
                             P_GS_LIPOV_VSTEL  TYPE VSTEL
                    CHANGING P_LV_BESKZ        TYPE BESKZ
                             P_LV_SOBSL        TYPE SOBSL.

  clear: P_LV_BESKZ,
         P_LV_SOBSL.

*------  Step 1 - When Material Number is Blank - Get Out  ------------*
  check P_GS_LIPOV_MATNR is NOT initial.   "is initial ?  GET OUT !!

*------  Step 2 - Read Internal Table to Find the Material  ----------*
  read table GT_MARC INTO gs_marc
                     with key MATNR = P_GS_LIPOV_MATNR
                              WERKS = P_GS_LIPOV_VSTEL
                                      binary search.
    IF sy-subrc = 0.
      P_LV_BESKZ = gs_marc-BESKZ.
      P_LV_SOBSL = gs_marc-SOBSL.
     ELSE.
*------  Step 3 - Read External Table to Find the Material  ----------*
*------ MARC - Plant Data for Material  -------------------------------*
      SELECT single  BESKZ SOBSL from MARC
                                 into (P_LV_BESKZ, P_LV_SOBSL)
                                where matnr = P_GS_LIPOV_MATNR
                                  and werks = P_GS_LIPOV_VSTEL.

      IF sy-subrc = 0.
        gs_MARC-MATNR = P_GS_LIPOV_MATNR.
        gs_MARC-WERKS = P_GS_LIPOV_VSTEL.
        gs_MARC-BESKZ = P_LV_BESKZ.      "Procurement Type
        gs_MARC-SOBSL = P_LV_SOBSL.      "Special Procurement Type

*------  This inserts it in the proper place in the SORTED TABLE  -----*
*------    and it is kept in the UNIQUE KEY sequence              -----*
        INSERT gs_MARC      INTO  TABLE gt_MARC.
      ENDIF.
    ENDIF.
ENDFORM.                    " GET_MARC_DATA
*----------------------------------------------------------------------*
*------  End   EDEK911357  EDEK911462  --------------------------------*
*----------------------------------------------------------------------*

FUNCTION zsd_dl_e3068_return_leg.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(I_VTTK_TKNUM) LIKE  VTTK-TKNUM
*"     VALUE(I_VTTK_STERM) LIKE  VTTK-STERM
*"     VALUE(I_VTTK_LAUFK) LIKE  VTTK-LAUFK
*"     VALUE(I_VTTK_ABFER) LIKE  VTTK-ABFER
*"     VALUE(I_VTTK_VSART) LIKE  VTTK-VSART
*"     VALUE(I_VTTK_VSAVL) LIKE  VTTK-VSAVL
*"     VALUE(I_VTTK_VSANL) LIKE  VTTK-VSANL
*"     VALUE(I_VTTK_TDLNR) LIKE  VTTK-TDLNR
*"     VALUE(I_DESTINATION) LIKE  VTTSLKZ STRUCTURE  VTTSLKZ OPTIONAL
*"     VALUE(I_DEPARTURE) LIKE  VTTSLKA STRUCTURE  VTTSLKA OPTIONAL
*"     VALUE(OPT_DIALOG) LIKE  RV56A-SELKZ DEFAULT 'X'
*"  TABLES
*"      I_XVTTP STRUCTURE  VTTPVB
*"      C_XVTTS STRUCTURE  VTTSVB
*"      C_YVTTS STRUCTURE  VTTSVB
*"      C_XVTSP STRUCTURE  VTSPVB
*"      C_YVTSP STRUCTURE  VTSPVB
*"      C_XVBPA STRUCTURE  VBPAVB
*"      C_YVBPA STRUCTURE  VBPAVB
*"      C_XVBADR STRUCTURE  SADRVB
*"      I_XTRLK STRUCTURE  VTRLK
*"      I_DEPARTURE_SEQUENCE STRUCTURE  VTTSLKA OPTIONAL
*"      I_SPOPLIST STRUCTURE  SPOPLI OPTIONAL
*"  EXCEPTIONS
*"      ERROR
*"----------------------------------------------------------------------
*  Project Code     :  ZV56SLDT                                        *
*  Enhancement Name :  V56SLDET
*  Include Name     :  ZSD_DL_E3068_RETURN_LEG
* Function Module Nm:  ZSD_DL_E3068_RETURN_LEG.
* User Exit Name    :  EXIT_SAPLV56S_001
************************************************************************
* Change History
* Name                          Date                  Description      *
* Sushila Chauadhary           01/13/2006   Changes made to prevent    *
*                                         short dumps from happening   *
*                                         when no stages are present on*
*                                         shipment. Search term <<<SC01*
* Sushila Chaudhary           02/15/2006   Change made to prevent incon*
*                                         sistency at the time of return
*                                        leg creation.<<< SC02.
************************************************************************
*If SY-SUBRC fails at any point below, we will leave the exit and
*cancel the return leg creation. We will issue a warning to the user
*and send an email that this shipment does not have a valid return
*leg.

*PART 1 - MAKE SURE WE ARE IN THE CORRECT TRANSACTION AND
*         THAT WE HAVE THE CORRECT SHIPMENT TYPE

* Step 1 - Make sure the user has specified Leg Determination
  CASE sy-ucomm.
    WHEN 'SBCK' OR 'MM_ST01'.
*   Here the User has clicked the Leg Deter. icon and has selected the
*   green check to continue. This is OK
    WHEN 'OK'.
*   Here the User has gone in through the Planning Icon and we need to
*   read the table i_spoplist. The table contains the answers to the
*   Popup that is displayed when the user clicks the icon. We want to
*   check that STERM has been checked to be run.
      READ TABLE i_spoplist WITH KEY varoption = 'STERM'.
      CHECK i_spoplist-selflag = c-true.
    WHEN OTHERS.
      EXIT.
  ENDCASE.

* Step 2 - VTTK-SHTYP is NOT PASSED in the User Exit. So instead we will
*          use ROUTE from I_XTRLK. Route should begin with D or P
*<<< SC02 The  return leg logic was behaving inconsistently depending
* upon how the delivery is associated with the shipment. Changes made to
* read the correct delivery information.
  READ TABLE i_xtrlk with key VBELN = I_XVTTP-VBELN.  "<< SC02
* READ TABLE i_xtrlk INDEX 1.                         "<< SC02
*CHECK ( i_xtrlk-route(1) = c-route_ok1 OR i_xtrlk-route(1) =
*c-route_ok2 ).
  CHECK i_xtrlk-route(1) = c-route_ok2.


*PART 2 - VERIFY WE NEED TO CREATE A RETURN LEG

* Step 1 - Check if last leg is a return leg - C-XVTTS-LAUFK = 5
  DESCRIBE TABLE c_xvtts LINES l_counter.
  READ TABLE c_xvtts INDEX l_counter ASSIGNING <z>.
  check l_counter <> 0 .                                 " <<< SC01
  CHECK <z>-laufk NE c-return_leg.

* Step 2 - Check Dest of Last not the same as Origin of First
  READ TABLE c_xvtts INDEX 1 ASSIGNING <a>.
  check sy-subrc = 0 .                                     "<<< SC01
  CHECK <z>-bezkomprz NE <a>-bezkompra.


*PART 3 - CREATE THE RETURN LEG

* Step 1 - Remove Old Return leg
  READ TABLE c_xvtts WITH KEY laufk = c-return_leg ASSIGNING <r>.
  IF sy-subrc = 0.
    CALL FUNCTION 'SD_SHIPMENT_STAGE_DELETE'
      EXPORTING
        i_tknum              = <r>-tknum
        i_tsnum              = <r>-tsnum
      TABLES
        c_xvtts              = c_xvtts
        c_yvtts              = c_yvtts
        c_xvtsp              = c_xvtsp
        c_yvtsp              = c_yvtsp
        c_xvbpa              = c_xvbpa
        c_yvbpa              = c_yvbpa
        c_xvbadr             = c_xvbadr
*   C_YVBADR             =
     EXCEPTIONS
       deletion_error       = 1
       OTHERS               = 2
              .
    IF sy-subrc <> 0.
      PERFORM send_failure_message USING i_vttk_tknum .
      EXIT.
    ENDIF.
  ENDIF.

* Step 2 - Build Return Leg
  l_xvtts_new-updkz = c-update_flag.
  l_xvtts_new-laufk = c-return_leg.
  l_xvtts_new-elupd = <a>-elupd.
  l_xvtts_new-tstyp = <a>-tstyp.
  l_xvtts_new-tdlnr = <a>-tdlnr.
  l_xvtts_new-vsart = <a>-vsart.

  l_xvtts_new-adrnz = <a>-adrna.
  l_xvtts_new-knotz = <a>-knota.
  l_xvtts_new-vstez = <a>-vstel.
  l_xvtts_new-lstez = <a>-lstel.
  l_xvtts_new-werkz = <a>-werka.
  l_xvtts_new-lgortz = <a>-lgorta.
  l_xvtts_new-kunnz = <a>-kunna.
  l_xvtts_new-lifnz = <a>-lifna.
  l_xvtts_new-ablad = <a>-belad.

  l_xvtts_new-adrna = <z>-adrnz.
  l_xvtts_new-knota = <z>-knotz.
  l_xvtts_new-vstel = <z>-vstez.
  l_xvtts_new-lstel = <z>-lstez.
  l_xvtts_new-werka = <z>-werkz.
  l_xvtts_new-lgorta = <z>-lgortz.
  l_xvtts_new-kunna = <z>-kunnz.
  l_xvtts_new-lifna = <z>-lifnz.
  l_xvtts_new-belad = <z>-ablad.


*Step 3 - Check Stage for accuracy
  CALL FUNCTION 'SD_SHIPMENT_STAGE_CHECK'
    EXPORTING
      i_xvtts                          = l_xvtts_new
*   OPT_CHECK_ALL                    = 'X'
*   OPT_STOP_AFTER_FIRST_ERROR       = 'X'
*   OPT_CHECK_STAGE_CATEGORY         = ' '
*   OPT_CHECK_CHANGE_ID              = ' '
*   OPT_CHECK_ROUTE                  = ' '
*   OPT_CHECK_SHIPPING_TYPE          = ' '
*   OPT_CHECK_LEG_INDICATOR          = ' '
*   OPT_CHECK_CARRIER                = ' '
*   OPT_CHECK_DATE_TIME              = ' '
*   OPT_CHECK_DEPARTURE              = ' '
*   OPT_CHECK_DESTINATION            = ' '
   EXCEPTIONS
     one_or_more_errors               = 1
     OTHERS                           = 2
            .
  IF sy-subrc <> 0.
    PERFORM send_failure_message USING i_vttk_tknum .
    EXIT.
  ENDIF.

*Step 4 - Append the new stage
  CALL FUNCTION 'SD_SHIPMENT_STAGE_APPEND'
    EXPORTING
      i_tknum                              = i_vttk_tknum
      i_xvtts_new                          = l_xvtts_new
    TABLES
      c_xvtts                              = c_xvtts
      c_yvtts                              = c_yvtts
      c_xvtsp                              = c_xvtsp
      c_yvtsp                              = c_yvtsp
      c_xvbpa                              = c_xvbpa
      c_yvbpa                              = c_yvbpa
      c_xvbadr                             = c_xvbadr
*   C_YVBADR                             =
      i_xvttp_new                          = i_xvttp
   EXCEPTIONS
     stage_not_successfully_created       = 1
     OTHERS                               = 2
            .
  IF sy-subrc <> 0.
    PERFORM send_failure_message USING i_vttk_tknum.
    EXIT.
  ENDIF.

*PART 4 - Remove reference delivery item. When using the FM above
*         to create a new leg. The system assumes you want to referrence
*         the deliveries in the shipment. We need to remove all
*         references to the deliveries. The assignment of references are
*         stored in table c_xvtsp.

* Step 1 - Read c_xvtts to find the Return Leg TSNUM (Stage No.)
  DESCRIBE TABLE c_xvtts LINES l_counter.
  READ TABLE c_xvtts INDEX l_counter.

* Step 2 - Delete the return leg/stage from c_xvtsp
  DELETE c_xvtsp WHERE tsnum = c_xvtts-tsnum.

ENDFUNCTION.
*&---------------------------------------------------------------------*
*&      Form  send_failure_message
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM send_failure_message USING tknum LIKE vttk-tknum.

  DATA:
    l_subject   LIKE sood1-objdes,
    lt_contents  LIKE soli OCCURS 0 WITH HEADER LINE,
    lt_rec_list  LIKE zrecmail OCCURS 0 WITH HEADER LINE.

*Create Subject.
  CONCATENATE 'Return Leg NOT created for Shipment'(001) tknum
         INTO l_subject SEPARATED BY space.

*Create Body of the Message
  APPEND l_subject TO lt_contents.

*Create Receiver for Message
*Get receivers from ZSP_VALUE. This will allow easy maintenance.
  SELECT fieldvalue FROM zsp_value INTO lt_rec_list-receiver
   WHERE pgrmid    = c-prog_id
     AND fieldname = c-fieldname.
    lt_rec_list-mail_type = c-mailtype.
    APPEND lt_rec_list.
  ENDSELECT.

  CALL FUNCTION 'Z_SEND_ALL_MAIL'
    EXPORTING
      subject                = l_subject
      express                = c-true
*   OWNER                  = SY-UNAME
*   NAME                   = 'MESSAGE  '
*   MODIFIABLE             = ' '
*   FOLDER                 =
*   OBJECT_HD_CHANGE       = ' '
*   OUTBOX_FLAG            = ' '
*   EXPIRE_DAYS            = 0
*   DELIVERED              = ' '
*   MAIL_READ              = ' '
    TABLES
      contents               = lt_contents
      rec_list               = lt_rec_list
*   OBJHEAD                =
*   OBJPARA                =
*   OBJPARB                =
*   PACKING_LIST           =
*   ATT_CONT               =
* EXCEPTIONS
*   SEND_FAILURE           = 1
*   FOLDER_ERROR           = 2
*   OTHERS                 = 3
            .

  MESSAGE w163(zsd_dl).
*   Return Leg NOT created for Shipment

ENDFORM.                    "send_failure_message

*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_CONTAINERF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  fill_idoc_control_rec
*&---------------------------------------------------------------------*

form fill_idoc_control_rec .
   REFRESH: gt_idoc_control[].

  gt_idoc_control-direct = c_out_direct.
  gt_idoc_control-mestyp = gs_partners-MESTYP.
  gt_idoc_control-idoctp = c_idoc_type.
  gt_idoc_control-serial = sy-datum.
  gt_idoc_control-serial+8(8) = sy-uzeit.
  gt_idoc_control-RCVPOR = gs_partners-RCVPOR.
  gt_idoc_control-rcvprn = gs_partners-PARTNER.
  gt_idoc_control-rcvprt = gs_partners-rcvprt.
  gt_idoc_control-RCVPFC = gs_partners-RCVPFC.
  append gt_idoc_control.

endform.                    " fill_idoc_control_rec
*&---------------------------------------------------------------------*
*&      Form  get_logical_system
*&---------------------------------------------------------------------*
*       Get logical system
*----------------------------------------------------------------------*

form get_logical_system .
   CALL FUNCTION 'OWN_LOGICAL_SYSTEM_GET'
    IMPORTING
      own_logical_system             = h_logsys
    EXCEPTIONS
      own_logical_system_not_defined = 1
      OTHERS                         = 2.
  IF sy-subrc = 0.
    gt_idoc_control-sndprt = c_logical_system .
    gt_idoc_control-sndprn = h_logsys.
  ELSE.
    EXIT.
  ENDIF.
endform.                    " get_logical_system
*&---------------------------------------------------------------------*
*&      Form  format_length_width
*&---------------------------------------------------------------------*
*    While passing to IDOC table split Values & UoM from the field
*    and pass only values as UoM is populated in UoM field.
*----------------------------------------------------------------------*
*      -->P_LEN_DIA
*      <--P_LENGTH
*----------------------------------------------------------------------*
form format_length_width  using    p_len_dia
                          changing p_length.
  data : lv_length1(10) type c,
         lv_length2(10) type c.
  SPLIT p_len_dia at space INTO lv_length1 lv_length2.


     p_length =  lv_length1 .
     CONDENSE p_length.


endform.                    " format_length_width

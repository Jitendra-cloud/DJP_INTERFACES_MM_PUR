*&---------------------------------------------------------------------*
*&  Include           ZDL_E04624_O01                                   *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.

  CLEAR: gv_idoc_process_err.

*-- No error text then get error message and IDOC data.
  IF gs_err_text IS INITIAL.
    PERFORM get_zdl_fields.
    PERFORM get_idoc_data.
  ENDIF.

 SET PF-STATUS '9000' EXCLUDING gt_itab_excl.
 SET TITLEBAR  'MAIN'.

ENDMODULE.                 " STATUS_9000  OUTPUT

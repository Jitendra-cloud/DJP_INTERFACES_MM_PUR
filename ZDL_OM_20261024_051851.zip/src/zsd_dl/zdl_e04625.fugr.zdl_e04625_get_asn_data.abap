FUNCTION zdl_e04625_get_asn_data.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_DOCNUM) TYPE  EDI_DOCNUM
*"  EXPORTING
*"     REFERENCE(ES_DATA) TYPE  ZDL_E04625_DATA
*"     REFERENCE(ES_EDIDC) TYPE  EDIDC
*"     REFERENCE(ES_EDIDS) TYPE  EDIDS
*"     REFERENCE(ET_EDIDD) TYPE  EDIDD_TT
*"  EXCEPTIONS
*"      INVALID_IDOC
*"----------------------------------------------------------------------

  DATA :
        lv_vbeln   TYPE vbeln,
        lv_kunnr   TYPE kunnr,
        ls_edidc   TYPE edidc,
        ls_edidd   TYPE edidd,
        ls_edids   TYPE edids,
        ls_e1edl20 TYPE e1edl20,
        ls_data    TYPE zdl_e04625_data,
        lt_edidd   TYPE edidd_tt.

  DATA: BEGIN OF lt_edidc OCCURS 0.
          INCLUDE STRUCTURE edidc.
  DATA: END OF lt_edidc.

  DATA: BEGIN OF lt_edids OCCURS 0.
          INCLUDE STRUCTURE edids.
  DATA: END OF lt_edids.

* Retrieve Idoc Control Record
  CALL FUNCTION 'EDI_DOCUMENT_OPEN_FOR_READ'
    EXPORTING
      document_number         = iv_docnum
      db_read_option          = 'Y'
    IMPORTING
      idoc_control            = ls_edidc
    EXCEPTIONS
      document_foreign_lock   = 1
      document_not_exist      = 2
      document_number_invalid = 3
      OTHERS                  = 4.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ELSE.
    es_edidc = ls_edidc.
  ENDIF.

* Retrieve Idoc Segment Data
  CALL FUNCTION 'EDI_SEGMENTS_GET_ALL'
    EXPORTING
      document_number         = iv_docnum
    TABLES
      idoc_containers         = lt_edidd
    EXCEPTIONS
      document_number_invalid = 1
      end_of_document         = 2
      OTHERS                  = 3.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ELSE.
    et_edidd = lt_edidd.
  ENDIF.

* Close Idoc after usage
  CALL FUNCTION 'EDI_DOCUMENT_CLOSE_READ'
    EXPORTING
      document_number   = iv_docnum
    EXCEPTIONS
      document_not_open = 1
      parameter_error   = 2
      OTHERS            = 3.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ENDIF.

* << TPR 41224 - UPSMW_READ_RECENT_EDIDS' is obsolete in ECC replacing
** with 'EDM01_SELECT_EDIDS' FM

** Retrieve the latest Idoc Status record
*  CALL FUNCTION 'UPSMW_READ_RECENT_EDIDS'
*    EXPORTING
*      flg_multi_select = ''   "space means only get the last rec
*      im_docnum        = iv_docnum
*    IMPORTING
*      ex_edids         = ls_edids
*    EXCEPTIONS
*      not_found        = 1
*      no_docnum        = 2
*      OTHERS           = 3.
*  IF sy-subrc <> 0.
*    RAISE invalid_idoc.
*    RETURN.
*  ELSE.
*    es_edids = ls_edids.
*  ENDIF.

  CLEAR:   lt_edidc, lt_edids.
  REFRESH: lt_edidc, lt_edids.

  ls_edidc-docnum = iv_docnum.
  APPEND ls_edidc TO lt_edidc .


  CALL FUNCTION 'EDM01_SELECT_EDIDS'
    TABLES
      it_edidc  = lt_edidc
      ot_edids  = lt_edids
    EXCEPTIONS
      nodata    = 1
      progerror = 2
      OTHERS    = 3.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ELSE.
*     return recent only
    SORT lt_edids DESCENDING BY docnum countr.

    DELETE ADJACENT DUPLICATES FROM lt_edids COMPARING docnum.

    READ TABLE lt_edids INDEX 1 INTO ls_edids.
    CLEAR lt_edids[].

    es_edids = ls_edids.
  ENDIF.

* >> TPR 41224

* Retrieve specific idoc information
* Retrieve Bill of Lading and Transport Id
  READ TABLE lt_edidd INTO ls_edidd WITH KEY segnam = 'E1EDL20'.
  IF sy-subrc = 0.
    ls_e1edl20 = ls_edidd-sdata.       "format a structure of e1edl20
    ls_data-bolnr = ls_e1edl20-bolnr.  "bol
    ls_data-traid  = ls_e1edl20-traid. "transport id
  ENDIF.

* Retrieve the PO number from the Idoc Status Record if applicable.
*  note, the po number:
* 1) May not exist on the idoc
* 2) May exist on the idoc and be a valid SAP PO number
* 3) May exist on the idoc but NOT be a valid SAP PO number
* If the PO number #did# exist on the idoc for the error in question,
* the vendor asn idoc function module Z_SD_DL_I2301_INPUT_ZVASN
* would have stored the po number

* po number will be stored in the seg field EDIDS-STAPA4
  IF ls_edids-stapa4 IS NOT INITIAL.
    ls_data-ebeln = ls_edids-stapa4. "PO

*   Attempt to retrieve the Vendor number using the PO number
    SELECT SINGLE lifnr INTO ls_data-lifnr FROM ekko
      WHERE ebeln = ls_data-ebeln.
*   Attempt to retrieve the Plant using the PO number
    SELECT SINGLE vbelv INTO lv_vbeln FROM vbfa "get sales order
      WHERE vbeln = ls_data-ebeln.
    IF sy-subrc = 0.
      SELECT SINGLE kunnr INTO lv_kunnr FROM vbak "get customer
        WHERE vbeln = lv_vbeln. "sales order
      IF sy-subrc = 0.
        SELECT SINGLE werks INTO ls_data-werks FROM zplant "get plant
          WHERE kunnr = lv_kunnr. "customer
      ENDIF.
    ENDIF.
  ENDIF.

* Format export structure of data
  es_data = ls_data.

ENDFUNCTION.

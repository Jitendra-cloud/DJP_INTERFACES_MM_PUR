*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDLU01267
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDLU01267           .

  PERFORM TABLEPROC.

ENDFUNCTION.

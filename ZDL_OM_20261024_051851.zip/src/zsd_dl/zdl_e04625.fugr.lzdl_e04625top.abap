FUNCTION-POOL ZDL_E04625.                   "MESSAGE-ID ..


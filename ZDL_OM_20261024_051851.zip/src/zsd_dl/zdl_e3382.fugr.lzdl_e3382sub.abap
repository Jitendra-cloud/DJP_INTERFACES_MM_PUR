*&---------------------------------------------------------------------*
*&  Include           LZDL_E3382SUB                                    *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  POPULATE_HUNITS
*&---------------------------------------------------------------------*
*       Populates the HUNIT field which comes in with arbitrary
*   sequential numbers with 'available' HU number values
*                                                                      *
* Bruce C Ballehr    09/25/08  E0VK943820  / BCB01                     *
*                                                                      *
*                         R12  Fix for E03382 Return Deliveries.       *
*                              ZSD_DL_E03382_RET_DELIV_HUS now calls   *
*                              Function Z_DL_E03126_UNIT_ID_CHECK with *
*                              IMPORT parm IV_GEN_UNIQUE_ID_TAB = 'X'  *
*                              so that we only retrieve a new          *
*                              ZZ<batch> number for each entry of      *
*                              TABLES IT_BATCH into field              *
*                              IT_BATCH-BATCH_NUM. The duplicate       *
*                              checks are bypassed since               *
*                              ZSD_DL_E03382_RET_DELIV_HUS only passes *
*                              in field IT_BATCH-MATNR. The Dup check  *
*                              was processing extremely long since     *
*                              the BOL or PO are not passed in IT_BATCH*
*----------------------------------------------------------------------*
*      -->P_IT_ZRETDELIVHUS  text
*----------------------------------------------------------------------*
FORM populate_hunits TABLES lpt_zretdelivhus STRUCTURE zretdelivhus.

* To track internal table index
  DATA: l_idx TYPE i.

  DATA: lx_zretdelivhus TYPE zretdelivhus,
        lt_zretdelivhus_new TYPE zretdelivhus OCCURS 0.

* For Z_DL_E03126_UNIT_ID_CHECK to retrieve unique HU values
  DATA: x_batch LIKE zdl_uniqueid,
        t_batch LIKE zdl_uniqueid OCCURS 0.

* Begin by creating a list of materials which the custom function
*   module Z_DL_E03126_UNIT_ID_CHECK will create HU's for.
*   Duplicates in this table are almost inevitable, but fine.

* IT_ZRETDELIVHUS-HUNIT should be populated with arbitrary,
*   sequential line numbers for user reference.
  CLEAR: x_batch,
         lx_zretdelivhus.
  REFRESH t_batch.
  SORT lpt_zretdelivhus BY vbeln_dl posnr_dl.
  LOOP AT lpt_zretdelivhus INTO lx_zretdelivhus.
    x_batch-matnr = lx_zretdelivhus-matnr.
    APPEND x_batch TO t_batch.
  ENDLOOP. "AT lt_zretdelivhus_new INTO lx_zretdelivhus.

* The fuction module Z_DL_E03126_UNIT_ID_CHECK populates the table
*   it_batch with a unique HU ID for each LINE with a material in
*   the internal table
  CALL FUNCTION 'Z_DL_E03126_UNIT_ID_CHECK'
    EXPORTING
      iv_gen_unique_id_tab   = 'X'          "BCB01
    TABLES
      it_batch               = t_batch
    EXCEPTIONS
      number_range_not_found = 1
      OTHERS                 = 2.
  IF sy-subrc <> 0.

  ELSE.

* Move the data into a temporary table so that it can be transferred
*   back into the original with the batch values
    REFRESH lt_zretdelivhus_new[].
    lt_zretdelivhus_new[] = lpt_zretdelivhus[].
    REFRESH lpt_zretdelivhus[].

* Overwrite the arbitrary sequentially numbered IT_ZRETDELIVHUS-HUNIT
*   placeholder fields with the legitimate HU's identified by the
*   function module
    CLEAR: l_idx,
           x_batch,
           lx_zretdelivhus.
    LOOP AT lt_zretdelivhus_new INTO lx_zretdelivhus.

      l_idx = sy-tabix.
      CLEAR: x_batch,
             lx_zretdelivhus-hunit.
      READ TABLE t_batch INDEX l_idx INTO x_batch.
      IF sy-subrc = 0.
        lx_zretdelivhus-hunit = x_batch-batch_num.
      ENDIF.

      APPEND lx_zretdelivhus TO lpt_zretdelivhus.
      CLEAR lx_zretdelivhus.

    ENDLOOP. "AT lt_zretdelivhus_new INTO lx_zretdelivhus.

  ENDIF.

ENDFORM.                    " POPULATE_HUNITS

*&---------------------------------------------------------------------*
*&      Form  create_hus
*&---------------------------------------------------------------------*
*       Logic for when the Handling Unit does not exist
*** Adapted from LZSD_DL_PACKINGF01
*----------------------------------------------------------------------*
*      -->P_IT_ZRETDELIVHUS
*----------------------------------------------------------------------*
FORM create_hus TABLES lpt_zretdelivhus STRUCTURE zretdelivhus.

*  Type of Handling-unit Item Content
  CONSTANTS: c_not_in_warehouse TYPE hu_st_init VALUE 'B',
             c_in_warehouse     TYPE hu_st_init VALUE 'C',
             c_material_item    TYPE velin      VALUE '1',
             c_verp             TYPE mtart      VALUE 'VERP',
             c_pkg              TYPE vhart      VALUE 'PKG'.

  CONSTANTS: c_pstyv_consign_pu  LIKE lips-pstyv VALUE 'KAN',
             c_pstyv_consign_cpu LIKE lips-pstyv VALUE 'ZKAN'.

  DATA: lx_zretdelivhus TYPE zretdelivhus,
* Capture Errors
        lt_zretdelivhus_log TYPE zretdelivhus OCCURS 0.

* Delivery line item data
  DATA:  x_lips  LIKE lips,
         l_vhilm TYPE vhilm.

* Default Data for Creating a Handling Unit
  DATA:  ls_headerproposal TYPE bapihuhdrproposal,
         ls_itemsproposal  TYPE bapihuitmproposal,
         lt_itemsproposal  TYPE STANDARD TABLE OF bapihuitmproposal.

** Formatting
*  DATA: l_exidv LIKE ls_headerproposal-hu_exid.

* Return Parameter
  DATA:  ls_return TYPE bapiret2,
         lt_return TYPE STANDARD TABLE OF bapiret2.

* Retrieve VHILM (HU Packaging Material)
  CLEAR l_vhilm.
  SELECT SINGLE matnr
    FROM mara
    INTO l_vhilm
      WHERE mtart = c_verp
      AND   vhart = c_pkg.

  CLEAR: lx_zretdelivhus.
  REFRESH: lt_zretdelivhus_log.
  LOOP AT lpt_zretdelivhus INTO lx_zretdelivhus.

    CLEAR x_lips.
    SELECT SINGLE *
      FROM lips
      INTO x_lips
      WHERE vbeln = lx_zretdelivhus-vbeln_dl
        AND posnr = lx_zretdelivhus-posnr_dl.

** Create the HU Header
    CLEAR: ls_headerproposal.
    CASE x_lips-pstyv.
      WHEN c_pstyv_consign_pu.
        ls_headerproposal-hu_status_init = c_in_warehouse."C
      WHEN c_pstyv_consign_cpu.
        ls_headerproposal-hu_status_init = c_in_warehouse."C
      WHEN OTHERS.
        ls_headerproposal-hu_status_init = c_not_in_warehouse."B
    ENDCASE.

    ls_headerproposal-pack_mat       = l_vhilm.  "HU packing mat
    ls_headerproposal-hu_exid        = lx_zretdelivhus-hunit.
    ls_headerproposal-plant          = x_lips-werks.
*    ls_headerproposal-stge_loc       = x_lips-lgort.

** Create the HU Line Item(s)
    CLEAR: ls_itemsproposal, lt_itemsproposal[].
    ls_itemsproposal-hu_item_type      = c_material_item. "1
    ls_itemsproposal-pack_qty          = lx_zretdelivhus-zqtyunits.
    ls_itemsproposal-base_unit_qty     = lx_zretdelivhus-vrkme.
*    ls_itemsproposal-base_unit_qty     = x_lips-meins.
    ls_itemsproposal-material          = lx_zretdelivhus-matnr.
    CLEAR ls_itemsproposal-batch.
    ls_itemsproposal-plant             = x_lips-werks.
*    ls_itemsproposal-stge_loc          = x_lips-lgort.
    ls_itemsproposal-stock_cat         = x_lips-bestq.
    ls_itemsproposal-spec_stock        = x_lips-sobkz.
    ls_itemsproposal-sp_stck_no        = x_lips-sonum.
    ls_itemsproposal-material_partner  = lx_zretdelivhus-vbeln_sd.
    "production order used to produce this item
*  ls_itemsproposal-gr_date           = x_lips-wdatu.
    "production order goods receipt date if known
    APPEND ls_itemsproposal  TO  lt_itemsproposal.

    CLEAR lt_return[]. "refresh error table

    DATA: lx_huheader TYPE bapihuheader,
          lt_huitem   TYPE bapihuitem OCCURS 0.

    CALL FUNCTION 'BAPI_HU_CREATE'
      EXPORTING
        headerproposal = ls_headerproposal  "Hdr data
      IMPORTING
        huheader       = lx_huheader
      TABLES
        itemsproposal  = lt_itemsproposal   "Itm data
        return         = lt_return
        huitem         = lt_huitem.
    IF NOT lt_return[] IS INITIAL.
      CLEAR ls_return.
      READ TABLE lt_return WITH KEY
        type = 'E' INTO ls_return.
      IF sy-subrc = 0.
        MESSAGE ID ls_return-id
              TYPE ls_return-type
            NUMBER ls_return-number
              WITH ls_return-message_v1
                   ls_return-message_v2
                   ls_return-message_v3
                   ls_return-message_v4
              INTO lx_zretdelivhus-zstatus.
        lx_zretdelivhus-traffic_light = c_red.
        APPEND lx_zretdelivhus TO lt_zretdelivhus_log.
        CONTINUE.
      ENDIF.
    ENDIF.

    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait   = 'X'      "wait for update
      IMPORTING
        return = ls_return.
    IF NOT ls_return IS INITIAL.
      IF ls_return-type = 'E'.
        MESSAGE ID ls_return-id
              TYPE ls_return-type
            NUMBER ls_return-number
              INTO lx_zretdelivhus-zstatus.
        lx_zretdelivhus-traffic_light = c_red.
        APPEND lx_zretdelivhus TO lt_zretdelivhus_log.
        CONTINUE.
      ENDIF.
    ENDIF.

* Keep good records
    CHECK lx_zretdelivhus-traffic_light <> c_red.
    lx_zretdelivhus-traffic_light = c_yellow.
    lx_zretdelivhus-zstatus =
        'HU successfully created, but not assigned.'(s01).
    APPEND lx_zretdelivhus TO lt_zretdelivhus_log.

  ENDLOOP. " AT lpt_zretdelivhus into lx_zretdelivhus.

* Update the delivery with the new HUs. (Calling FM)
  PERFORM assign_hus_to_deliveries TABLES lt_zretdelivhus_log.

* Give the last delivery in the loop time to resolve for reporting
  PERFORM check_delivery_lock    USING lx_zretdelivhus-vbeln_dl
                              CHANGING lx_zretdelivhus-traffic_light
                                       lx_zretdelivhus-zstatus.
  CLEAR lx_zretdelivhus.

  REFRESH lpt_zretdelivhus[].
  lpt_zretdelivhus[] = lt_zretdelivhus_log[].

ENDFORM.                    " create_hus

*&---------------------------------------------------------------------*
*&      Form  assign_hus_to_deliveries
*&---------------------------------------------------------------------*
*       Assign the HU to the Delivery
*         Note: gv_exidv will either contain the Repacking destination
*               HU if in Repack mode or the normal HU for non-repack
*               mode.
*----------------------------------------------------------------------*
FORM assign_hus_to_deliveries TABLES lpt_zretdelivhus_log
                                         STRUCTURE zretdelivhus.

**  Item to Unpack
*  DATA: ls_itemunpack    TYPE bapihuitmunpack.

  DATA: ls_vbkok     TYPE vbkok.   "confirm picking structure

  DATA: lt_prot    TYPE STANDARD TABLE OF prott.

* Copy Handling Unit into Delivery
  DATA:
    lt_handling_units   TYPE STANDARD TABLE OF hum_rehang_hu,
    ls_handling_units   TYPE hum_rehang_hu.

  DATA: lx_delivery_key LIKE LINE OF lpt_zretdelivhus_log,
        lt_delivery_key LIKE lpt_zretdelivhus_log OCCURS 0,
        lx_subset       LIKE LINE OF lpt_zretdelivhus_log,
        lt_subset       LIKE lpt_zretdelivhus_log OCCURS 0.

* Loop at 1 delivery at a time
  SORT lpt_zretdelivhus_log BY vbeln_dl posnr_dl.
  lt_delivery_key[] = lpt_zretdelivhus_log[].
  DELETE ADJACENT DUPLICATES FROM lt_delivery_key COMPARING vbeln_dl.

  CLEAR lx_delivery_key.
  LOOP AT lt_delivery_key INTO lx_delivery_key.

* Separate out the items for this delivery only
    REFRESH lt_subset.
    lt_subset[] = lpt_zretdelivhus_log[].
    DELETE lt_subset WHERE vbeln_dl <> lx_delivery_key-vbeln_dl.

* Loop at this delivery's items
    CLEAR lx_subset.
    REFRESH lt_handling_units.
    LOOP AT lt_subset INTO lx_subset.
* Format HU external id into table by delivery number
      CLEAR: ls_handling_units.
      ls_handling_units-top_hu_external = lx_subset-hunit.
      APPEND ls_handling_units TO lt_handling_units.
    ENDLOOP.

* Format Delivery Number
    CLEAR ls_vbkok.
    ls_vbkok-vbeln_vl = lx_delivery_key-vbeln_dl.

* Need to ensure the Delivery is not locked
    PERFORM check_delivery_lock   USING lx_delivery_key-vbeln_dl
                               CHANGING lx_delivery_key-traffic_light
                                        lx_delivery_key-zstatus.
    IF lx_delivery_key-traffic_light <> c_red.

* Assign HU to the Delivery since not currently assigned
      REFRESH: lt_prot.
      CALL FUNCTION 'WS_DELIVERY_UPDATE'
        EXPORTING
          vbkok_wa                 = ls_vbkok
          commit                   = 'X'
          delivery                 = lx_delivery_key-vbeln_dl
          if_database_update       = '1' "check & save
          if_error_messages_send_0 = 'X'
        TABLES
          prot                     = lt_prot
          it_handling_units        = lt_handling_units.

* Assume delivery has been updated correctly.
      lx_delivery_key-traffic_light = c_green.
      lx_delivery_key-zstatus =
          'HU successfully created and assigned.'(s02).

      REFRESH lt_handling_units.

    ENDIF. " lx_delivery_key-traffic_light <> c_red.

    MODIFY lpt_zretdelivhus_log FROM lx_delivery_key
      TRANSPORTING traffic_light zstatus
      WHERE vbeln_dl = lx_delivery_key-vbeln_dl.

  ENDLOOP. " at lt_delivery_key.

ENDFORM.                    " assign_hus_to_deliveries

*&---------------------------------------------------------------------*
*&      Form  check_delivery_lock
*&---------------------------------------------------------------------*
* Confirms the delivery is unlocked by test-locking it.
*----------------------------------------------------------------------*
*  -->  lp_vbeln        Delivery Number
*  <--  lp_status       Status message
*----------------------------------------------------------------------*
FORM check_delivery_lock USING    lp_vbeln  TYPE likp-vbeln
                         CHANGING lp_light  TYPE char1
                                  lp_status TYPE zzstatus.

  DATA: lv_subrc TYPE sysubrc VALUE 4.

* Attempt to lock the delivery to make sure it is not already locked
  DO 30 TIMES.
    CALL FUNCTION 'ENQUEUE_EVVBLKE'
      EXPORTING
        mode_likp            = 'E'
        mandt                = sy-mandt
        vbeln                = lp_vbeln "delivery num
*       X_VBELN              = ' '
        _scope               = '2'
*       _WAIT                = ' '
*       _COLLECT             = ' '
      EXCEPTIONS
        foreign_lock         = 1
        system_failure       = 2
        OTHERS               = 3.
    IF sy-subrc = 0.
      lv_subrc = sy-subrc.
      EXIT.
    ELSE.
      WAIT UP TO 1 SECONDS.
    ENDIF.
  ENDDO.

  IF lv_subrc = 0.
*   Unlock the delivery
    CALL FUNCTION 'DEQUEUE_EVVBLKE'
      EXPORTING
        mode_likp       = 'E'
        mandt           = sy-mandt
        vbeln           = lp_vbeln "delivery num
*       X_VBELN         = ' '
        _scope          = '3'.
  ELSE.
**   Log an error
**   Unable to lock delivery & for update
    lp_light = c_red.
    CONCATENATE 'Delivery'(m01)
                lp_vbeln
                'is locked and could not be updated.'(m02)
           INTO lp_status SEPARATED BY space.
  ENDIF.

ENDFORM.                    " check_delivery_lock

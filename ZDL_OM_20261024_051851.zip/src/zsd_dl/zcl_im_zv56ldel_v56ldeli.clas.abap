class ZCL_IM_ZV56LDEL_V56LDELI definition
  public
  final
  create public .

*"* public components of class ZCL_IM_ZV56LDEL_V56LDELI
*"* do not include other source files here!!!
public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_SMOD_V56LDELI .
protected section.
*"* protected components of class ZCL_IM_ZV56LDEL_V56LDELI
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_ZV56LDEL_V56LDELI
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_ZV56LDEL_V56LDELI IMPLEMENTATION.


method IF_EX_SMOD_V56LDELI~EXIT_SAPLV56L_002.
call function 'EXIT_SAPLV56L_002'
   EXPORTING
     I_LANGU = I_LANGU
     I_PARTNER_ROLE = I_PARTNER_ROLE
     OPT_MINIMIZED_DELIVERY_VIEW = OPT_MINIMIZED_DELIVERY_VIEW
     OPT_ITEMS = OPT_ITEMS
     OPT_PARTNERS = OPT_PARTNERS
     OPT_CUSTOMER_DATA = OPT_CUSTOMER_DATA
     OPT_CUSTOMIZING_DATA = OPT_CUSTOMIZING_DATA
     OPT_ORDER_DATA = OPT_ORDER_DATA
     OPT_EXPORT_DATA = OPT_EXPORT_DATA
   TABLES
     C_VTRLK = C_VTRLK
     C_VTRLP = C_VTRLP
   EXCEPTIONS
     ERROR =  1.

case sy-subrc.
  when  1.
*    RAISE ERROR.
     raise exception type CX_VTR.
endcase.
endmethod.
ENDCLASS.

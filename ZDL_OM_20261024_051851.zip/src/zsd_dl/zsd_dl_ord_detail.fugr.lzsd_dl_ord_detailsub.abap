*&---------------------------------------------------------------------*
*&  Include           LZSD_DL_ORD_DETAILSUB                            *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  process_trim
*&---------------------------------------------------------------------*
*  Extracting the Trim Units, Trim unit weight and Total Trim
*    for Trim orders
*----------------------------------------------------------------------*
*      -->P_T_RESB_AUFK       Trim orders
*      -->P_LT_SALES_ORD_OUT  Trim Details
*----------------------------------------------------------------------*
FORM process_trim  TABLES  plt_ord_out STRUCTURE zst_trim_details.

  CONSTANTS: c_obj_type      LIKE ibinval_sel_f-objtyp VALUE 'RESB',
             c_good_material LIKE ibinval_sel_f-atwrt  VALUE '0'.

  DATA: BEGIN OF lt_ibinval_values OCCURS 0,
          atinn  LIKE ibinval_sel_f-atinn,
          atwrt  LIKE ibinval_sel_f-atwrt,
          atflv  LIKE ibinval_sel_f-atflv,
          objkey LIKE ibinval_sel_f-objkey,
        END OF lt_ibinval_values.

  DATA: BEGIN OF lt_ibinval_values_tmp OCCURS 0,
          atinn  LIKE ibinval_sel_f-atinn,
          atwrt  LIKE ibinval_sel_f-atwrt,
          atflv  LIKE ibinval_sel_f-atflv,
          objkey LIKE ibinval_sel_f-objkey,
        END OF lt_ibinval_values_tmp.

  DATA: BEGIN OF lt_objkey_key OCCURS 0,
          objkey LIKE ibinval_sel_f-objkey,
        END OF lt_objkey_key.

* Data COLLECT table for trim totals by objkey
  DATA: BEGIN OF lt_trim_totals OCCURS 0,
          kdauf LIKE t_resb_aufk-kdauf,
          kdpos LIKE t_resb_aufk-kdpos,
          node_type       TYPE i,
          ztrimtotl_units LIKE zst_trim_details-ztrimtotl_units,
          erfmg LIKE t_resb_aufk-erfmg,
        END OF lt_trim_totals.

* Used to get machine numbers for orders from function module
* ZSD_DL_CR3694_READ_MACHINE_DET
  DATA: lt_ord_machines LIKE zst_orders_machines
                        OCCURS 0 WITH HEADER LINE.

* Map Characteristic Names to internal ATINN codes
  PERFORM get_atinn_mapping.

  CLEAR lt_objkey_key.
  LOOP AT t_resb_aufk.
    lt_objkey_key-objkey = t_resb_aufk-objnr+2(20).
    APPEND lt_objkey_key.
    CLEAR lt_objkey_key.
  ENDLOOP. " at t_resb_aufk.
  SORT lt_objkey_key BY objkey.
  DELETE ADJACENT DUPLICATES FROM lt_objkey_key COMPARING objkey.

  SELECT atinn
         atwrt
         atflv
         objkey
    FROM ibinval_sel_f
    INTO TABLE lt_ibinval_values
    FOR ALL ENTRIES IN lt_objkey_key
    WHERE atinn IN r_atinn
      AND objtyp = c_obj_type
      AND objkey = lt_objkey_key-objkey.

*** Calculate total trim detials

* Collect/separate trim totals by OBJNR
* schaudh 09/28/2005 changed the sort criteria on t_resb_aufk table else
* the read on this table using the binary search was not working .
  SORT: t_resb_aufk BY objnr+2(20),
*       t_resb_aufk BY kdauf kdpos objnr+2(20),
        lt_ibinval_values BY objkey.

  lt_ibinval_values_tmp[] = lt_ibinval_values[] .
  SORT lt_ibinval_values_tmp BY objkey atinn.

  DATA :  v_aufnr LIKE resb-aufnr .

  LOOP AT lt_ibinval_values.

    CLEAR t_resb_aufk.
    READ TABLE t_resb_aufk WITH KEY
      objnr+2(20) = lt_ibinval_values-objkey
      BINARY SEARCH.
    CHECK sy-subrc = 0.

* Also filter out deleted RESB line items
* This was not done earlier as not to accidentally send this record
*   through NCP processing
*// begin of schaudh 10/19/2005 .
*/  If the production order is marked for close/ delete,  check if
*/  there was any production done against it in the AFRU table .
*   CHECK t_resb_aufk-xloek IS INITIAL.
    IF t_resb_aufk-xloek IS NOT INITIAL.
      IF NOT v_aufnr = t_resb_aufk-aufnr .
        SELECT aufnr satza FROM afru INTO TABLE t_afru
                                WHERE aufnr = t_resb_aufk-aufnr .
        SORT t_afru BY satza .
        v_aufnr = t_resb_aufk-aufnr .
      ENDIF.
      READ TABLE t_afru WITH KEY satza  = c_confirm_l20
                                              BINARY SEARCH.
      IF sy-subrc = 0 .
      ELSE .
        CONTINUE.
      ENDIF.
    ENDIF.
*// end of schaudh 10/19/2005.

    CASE lt_ibinval_values-atinn.
      WHEN g_node_atinn. " NODE_TYPE
        lt_trim_totals-kdauf    = t_resb_aufk-kdauf.
        lt_trim_totals-kdpos    = t_resb_aufk-kdpos.
        lt_trim_totals-node_type = lt_ibinval_values-atwrt.
        COLLECT lt_trim_totals.
        CLEAR lt_trim_totals.
      WHEN g_sets_atinn. " NUMBER_SETS_IN_TRIM_PATTERN
        READ TABLE lt_ibinval_values_tmp WITH KEY
             objkey = lt_ibinval_values-objkey
             atinn  = g_node_atinn BINARY SEARCH .
        IF lt_ibinval_values_tmp-atwrt = 0.
          lt_trim_totals-kdauf    = t_resb_aufk-kdauf.
          lt_trim_totals-kdpos    = t_resb_aufk-kdpos.
          lt_trim_totals-ztrimtotl_units = lt_ibinval_values-atwrt.
          lt_trim_totals-erfmg    = t_resb_aufk-erfmg.
          COLLECT lt_trim_totals.
          CLEAR lt_trim_totals.
        ENDIF.
    ENDCASE. " lt_ibinval_values-atinn.

  ENDLOOP. " at lt_ibinval_values

  CLEAR lt_ord_machines.
  LOOP AT t_resb_aufk.
    lt_ord_machines-aufnr = t_resb_aufk-aufnr.
    APPEND lt_ord_machines.
    CLEAR lt_ord_machines.
  ENDLOOP. "at t_resb_aufk.

* Get Machine Numbers
  CALL FUNCTION 'ZSD_DL_U1165_READ_MACHINE_DET'
    TABLES
      zt_ord_machines           = lt_ord_machines
    EXCEPTIONS
      orders_required           = 1
      machine_number_not_found  = 2
      machine_numbers_not_found = 3.

* Combine totals and build t_sales_ord_out
  SORT: t_resb_aufk     BY kdauf kdpos objnr,
        lt_trim_totals  BY kdauf kdpos,
        lt_ord_machines BY aufnr.
  CLEAR: t_resb_aufk,
         t_sales_ord_out,
         lt_trim_totals,
         lt_ord_machines.
  LOOP AT t_resb_aufk.

    IF NOT ( lt_trim_totals-kdauf = t_resb_aufk-kdauf
       AND   lt_trim_totals-kdpos = t_resb_aufk-kdpos ).
      CLEAR lt_trim_totals.
      READ TABLE lt_trim_totals WITH KEY
        kdauf = t_resb_aufk-kdauf
        kdpos = t_resb_aufk-kdpos
        BINARY SEARCH.
    ENDIF.

*    CHECK lt_trim_totals-node_type = 0.

    IF NOT lt_ord_machines-aufnr = t_resb_aufk-aufnr.
      CLEAR lt_ord_machines.
      READ TABLE lt_ord_machines WITH KEY
        aufnr = t_resb_aufk-aufnr
        BINARY SEARCH.
    ENDIF.

    t_sales_ord_out-kdauf           = t_resb_aufk-kdauf.
    t_sales_ord_out-kdpos           = t_resb_aufk-kdpos.

    t_sales_ord_out-ztrimtotl_units = lt_trim_totals-ztrimtotl_units.

    IF t_sales_ord_out-ztrimtotl_units = 0.
      t_sales_ord_out-ztrimunit_wt = 0.
    ELSE.
      t_sales_ord_out-ztrimunit_wt =
          lt_trim_totals-erfmg / t_sales_ord_out-ztrimtotl_units.
    ENDIF.

    t_sales_ord_out-ztrimtotl_wt =
    lt_trim_totals-ztrimtotl_units * t_sales_ord_out-ztrimunit_wt.

    t_sales_ord_out-erfme = t_resb_aufk-erfme.

    t_sales_ord_out-ztrimmachinenum = lt_ord_machines-arbpl.
    APPEND t_sales_ord_out.
    CLEAR t_sales_ord_out.

  ENDLOOP. " at t_resb_aufk

  SORT t_sales_ord_out.
  DELETE ADJACENT DUPLICATES FROM t_sales_ord_out.

ENDFORM.                    " process_trim

*&---------------------------------------------------------------------*
*&      Form  GET_ATINN_MAPPING
*&---------------------------------------------------------------------*
*       Map Characteristic Names to internal ATINN codes
*----------------------------------------------------------------------*
FORM get_atinn_mapping .

  CONSTANTS: c_sets LIKE cabn-atnam VALUE 'NUMBER_SETS_IN_TRIM_PATTERN',
             c_utwt LIKE cabn-atnam VALUE 'UNIT_WEIGHT',
             c_node LIKE cabn-atnam VALUE 'NODE_TYPE'.

* Populate characteristic range
  r_atinn-sign   = 'I'.
  r_atinn-option = 'EQ'.

  SELECT atinn
    FROM cabn
    UP TO 1 ROWS
    INTO g_sets_atinn
    WHERE atnam = c_sets.
  ENDSELECT.
  IF sy-subrc = 0.
    r_atinn-low    = g_sets_atinn.
    APPEND r_atinn.
    CLEAR r_atinn-low.
  ENDIF.

  SELECT atinn
    FROM cabn
    UP TO 1 ROWS
    INTO g_utwt_atinn
    WHERE atnam = c_utwt.
  ENDSELECT.
  IF sy-subrc = 0.
    r_atinn-low    = g_utwt_atinn.
    APPEND r_atinn.
    CLEAR r_atinn-low.
  ENDIF.

  SELECT atinn
    FROM cabn
    UP TO 1 ROWS
    INTO g_node_atinn
    WHERE atnam = c_node.
  ENDSELECT.
  IF sy-subrc = 0.
    r_atinn-low    = g_node_atinn.
    APPEND r_atinn.
    CLEAR r_atinn-low.
  ENDIF.

ENDFORM.                    " GET_ATINN_MAPPING

*&---------------------------------------------------------------------*
*&      Form  process_ncp
*&---------------------------------------------------------------------*
*  Extracting the Trim Units, Trim unit weight and Total Trim
*    for NCP orders and combining them into Output table
*----------------------------------------------------------------------*
*      -->plt_ncp        NCP Orders (Recieves orders to process, then
*                         exports NCP-specific details.)
*----------------------------------------------------------------------*
FORM process_ncp  TABLES  plt_ncp     STRUCTURE zst_trim_details.

  CONSTANTS: c_afpo_obj_type LIKE ibinval_sel_f-objtyp VALUE 'AFPO',
             c_credit LIKE aufm-shkzg VALUE 'S',
             c_debit  LIKE aufm-shkzg VALUE 'H',
             c_utwt LIKE cabn-atnam VALUE 'UNIT_WEIGHT' .

* Table used to retrieve packaging production order
  DATA: lt_afpo_key LIKE plt_ncp OCCURS 0 WITH HEADER LINE.

  DATA: lt_objkey_key LIKE t_afpo OCCURS 0 WITH HEADER LINE.

* Unit weights retrieved from SAP table view ibinval_sel_f
  DATA: BEGIN OF lt_ibinval_utwt OCCURS 0,
          atinn  LIKE ibinval_sel_f-atinn,
          atwrt  LIKE ibinval_sel_f-atwrt,
          atflv  LIKE ibinval_sel_f-atflv,
          objkey LIKE ibinval_sel_f-objkey,
        END OF lt_ibinval_utwt.

* For retrieval of SAP table AUFM records
  DATA: lt_aufm     LIKE aufm   OCCURS 0 WITH HEADER LINE,
        lt_aufm_key LIKE t_afpo OCCURS 0 WITH HEADER LINE.

* For number of units summation
  DATA: BEGIN OF lt_trim_totals OCCURS 0,
          kdauf             LIKE t_afpo-kdauf,
          kdpos             LIKE t_afpo-kdpos,
          ztrimtotl_units_c LIKE zst_trim_details-ztrimtotl_units,
*          ztrimtotl_units_d LIKE zst_trim_details-ztrimtotl_units,
        END OF lt_trim_totals.

  lt_afpo_key[] = plt_ncp[].
  SORT lt_afpo_key BY kdauf kdpos.
  DELETE ADJACENT DUPLICATES FROM lt_afpo_key COMPARING kdauf kdpos.

  SELECT aufnr " Packaging production order #
         posnr
         kdauf
         kdpos
         psmng
         meins
    FROM afpo
    INTO TABLE t_afpo
    FOR ALL ENTRIES IN lt_afpo_key
    WHERE kdauf = lt_afpo_key-kdauf
      AND kdpos = lt_afpo_key-kdpos.
  IF sy-subrc = 0.
* Ensure t_afpo contains only verified NCP orders.
    PERFORM process_ncp_verify TABLES t_afpo.
  ENDIF.

  CHECK NOT t_afpo[] IS INITIAL.

* Retrieve Unit Weight Characteristics
  CLEAR lt_ibinval_utwt.
  REFRESH lt_ibinval_utwt.
  lt_objkey_key[] = t_afpo[].
  SORT lt_objkey_key BY objkey.
  DELETE ADJACENT DUPLICATES FROM lt_objkey_key COMPARING objkey.

*// begin of  SCHAUDH :  added the select for unit_weight characteristic
*/  else the select below for ibinval_sel_f table, the value was all 0.
  SELECT atinn
    FROM cabn
    UP TO 1 ROWS
    INTO g_utwt_atinn
    WHERE atnam = c_utwt.
  ENDSELECT.

  SELECT atinn
         atwrt
         atflv
         objkey
    FROM ibinval_sel_f
    INTO TABLE lt_ibinval_utwt
    FOR ALL ENTRIES IN lt_objkey_key
    WHERE atinn  = g_utwt_atinn
      AND objtyp = c_afpo_obj_type
      AND objkey = lt_objkey_key-objkey.
  IF sy-subrc = 0.

  ENDIF. " SELECT FROM ibinval_sel_f

*** Removed in favor of using the AFPO-PSMNG field. DO NOT DELETE,
*** MAY BE USED AGAIN
** Retrieve number of units from AUFM production order data
** Note that the only index is on AUFNR
*  lt_aufm_key[] = t_afpo[].
*  SORT lt_aufm_key BY aufnr.
*  DELETE ADJACENT DUPLICATES FROM lt_aufm_key COMPARING aufnr.
*  SELECT *
*    FROM aufm
*    INTO TABLE lt_aufm
*    FOR ALL ENTRIES IN lt_aufm_key
*    WHERE aufnr = lt_aufm_key-aufnr.
*  IF sy-subrc = 0.
*
** COLLECT number of units by looping through all goods movements,
**  identifying valid records by reading plt_ncp-passed
**  Material Number, Plant, Storage Loc., Sales Order and Line Item
*    CLEAR lt_trim_totals.
*    REFRESH lt_trim_totals.
*    SORT plt_ncp BY kdauf kdpos.
*    LOOP AT lt_aufm.
*
*      CLEAR plt_ncp.
*      READ TABLE plt_ncp WITH KEY
*        kdauf = lt_aufm-kdauf
*        kdpos = lt_aufm-kdpos.
*      CHECK sy-subrc = 0.
*
*      lt_trim_totals-kdauf = lt_aufm-kdauf.
*      lt_trim_totals-kdpos = lt_aufm-kdpos.
*
*      CASE lt_aufm-shkzg.
*        WHEN c_credit.
*          lt_trim_totals-ztrimtotl_units_c = lt_aufm-menge.
*        WHEN c_debit.
*          lt_trim_totals-ztrimtotl_units_d = lt_aufm-menge.
*      ENDCASE.
*
*      COLLECT lt_trim_totals.
*      CLEAR lt_trim_totals.
*
*    ENDLOOP. " at lt_aufm.
*
*  ENDIF. " Select from AUFM
* END OF 'DO NOT DELETE MAY BE USED AGAIN' BLOCK

* Sum all production order records by sales order line item
  CLEAR t_afpo.
  SORT t_afpo BY kdauf kdpos.
  LOOP AT t_afpo.
    lt_trim_totals-kdauf = t_afpo-kdauf.
    lt_trim_totals-kdpos = t_afpo-kdpos.
    lt_trim_totals-ztrimtotl_units_c = t_afpo-psmng.
    COLLECT lt_trim_totals.
    CLEAR lt_trim_totals.
  ENDLOOP.

* Combine SELECTed data into output table
  REFRESH plt_ncp.
  SORT: t_afpo BY kdauf kdpos,
        lt_ibinval_utwt BY objkey.
  DELETE ADJACENT DUPLICATES FROM t_afpo COMPARING kdauf kdpos.
  LOOP AT lt_trim_totals.

    CLEAR plt_ncp.

* Read AUFNR and OBJKEY
    CLEAR t_afpo.
    READ TABLE t_afpo WITH KEY
      kdauf = lt_trim_totals-kdauf
      kdpos = lt_trim_totals-kdpos
      BINARY SEARCH.
    CHECK sy-subrc = 0.

* Get unit weight
    CLEAR lt_ibinval_utwt.
    READ TABLE lt_ibinval_utwt WITH KEY
      objkey = t_afpo-objkey
      BINARY SEARCH.
    CHECK sy-subrc = 0.

    plt_ncp-kdauf        = lt_trim_totals-kdauf.
    plt_ncp-kdpos        = lt_trim_totals-kdpos.
    plt_ncp-erfme        = t_afpo-meins.
*// schaudh changed the value from atwrt to atflv.
    plt_ncp-ztrimunit_wt = lt_ibinval_utwt-atflv.

    plt_ncp-ztrimtotl_wt = lt_trim_totals-ztrimtotl_units_c.

*//schaudh  need to check for the value atflv instead of atwrt
*   IF lt_ibinval_utwt-atwrt = 0.
    IF lt_ibinval_utwt-atflv = 0.
      plt_ncp-ztrimtotl_units = 0.
* Don't add records that have quantities of 0.
    ELSE.
      plt_ncp-ztrimtotl_units =
            plt_ncp-ztrimtotl_wt / lt_ibinval_utwt-atflv.
    ENDIF.

    APPEND plt_ncp.
    CLEAR plt_ncp.

  ENDLOOP. " at lt_trim_totals.

ENDFORM.                    " process_ncp

*&---------------------------------------------------------------------*
*&      Form  PROCESS_NCP_VERIFY
*&---------------------------------------------------------------------*
*    Verify orders are NCP orders, and if not, remove from processing
*----------------------------------------------------------------------*
*      -->LT_AFPO  text
*----------------------------------------------------------------------*
FORM process_ncp_verify  TABLES   plt_afpo STRUCTURE t_afpo.

  CONSTANTS: c_trim_num LIKE cabn-atnam VALUE 'TRIM_NUMBER',
             c_invent_atwrt LIKE ibinval_sel_f-atwrt VALUE 'INVENT',
             c_afpo_objtyp  LIKE ibinval_sel_f-objtyp VALUE 'AFPO'.

  DATA: l_trim_num_atinn LIKE ibinval_sel_f-atinn.

* Verified NCP cases
  DATA: lt_resb     LIKE t_resb   OCCURS 0 WITH HEADER LINE,
        lt_afpo_ncp LIKE plt_afpo OCCURS 0 WITH HEADER LINE.

* IBINVAL_SEL_F work area
  DATA: st_ibinval_sel_f LIKE ibinval_sel_f.

* Map the Trim Number Characteristic
  SELECT atinn
    FROM cabn
    UP TO 1 ROWS
    INTO l_trim_num_atinn
    WHERE atnam = c_trim_num.
  ENDSELECT.

* Build OBJKEY
* Select NCP cases from IBINVAL_SEL_F using the objkey mapped from AFPO
*  filtering orders into separate internal table lt_afpo_ncp.
  lt_resb[] = t_resb[].
  CLEAR: lt_afpo_ncp.
  REFRESH: lt_afpo_ncp.
  SORT: plt_afpo BY aufnr posnr,
        lt_resb BY aufnr.
  DELETE ADJACENT DUPLICATES FROM lt_resb COMPARING aufnr.
  LOOP AT plt_afpo.

* AFPO records that have corresponding records in RESB are not NCP and
*  can be skipped.
    CLEAR lt_resb.
    READ TABLE lt_resb WITH KEY
      aufnr = plt_afpo-aufnr
      BINARY SEARCH.
    CHECK sy-subrc <> 0.

    CONCATENATE plt_afpo-aufnr plt_afpo-posnr INTO plt_afpo-objkey.
    CONDENSE plt_afpo-objkey.

    CLEAR st_ibinval_sel_f.
    SELECT *
      FROM ibinval_sel_f
      UP TO 1 ROWS
      INTO st_ibinval_sel_f
      WHERE atinn  = l_trim_num_atinn
        AND atwrt  = c_invent_atwrt
        AND objtyp = c_afpo_objtyp
        AND objkey = plt_afpo-objkey.
    ENDSELECT.
    CHECK sy-subrc = 0.
    APPEND plt_afpo TO lt_afpo_ncp.

  ENDLOOP.

* Update plt_afpo with verified NCP orders
  CLEAR plt_afpo.
  REFRESH plt_afpo.
  plt_afpo[] = lt_afpo_ncp[].

ENDFORM.                    " PROCESS_NCP_VERIFY

*&---------------------------------------------------------------------*
*&      Form  process_combine
*&---------------------------------------------------------------------*
*  Combining the Standard and NCP Trim Units, Trim unit weight and
*   Total Trim into Output table
*----------------------------------------------------------------------*
*      -->plt_ncp        NCP Orders
*      -->plt_ord_out    Exports Combined Trim Details (Standard + NCP)
*----------------------------------------------------------------------*
FORM process_combine TABLES plt_ncp     STRUCTURE zst_trim_details
                            plt_ord_out STRUCTURE zst_trim_details
                            plt_trim_details STRUCTURE zst_trim_details.

* To combine standard trim data with NCP data in output table
  DATA: lt_combined LIKE plt_ord_out OCCURS 0.

* Combine with Standard trim
  SORT: plt_ncp     BY kdauf kdpos,
        plt_ord_out BY kdauf kdpos,
        plt_trim_details BY kdauf kdpos.

  DELETE ADJACENT DUPLICATES FROM plt_trim_details
                       COMPARING  kdauf kdpos.
  LOOP AT plt_trim_details.

    CLEAR plt_ncp.                                          " <<RLW02+
    READ TABLE plt_ncp WITH KEY                             " <<RLW02+
            kdauf = plt_trim_details-kdauf                  " <<RLW02+
            kdpos = plt_trim_details-kdpos                  " <<RLW02+
            BINARY SEARCH.                                  " <<RLW02+

    CLEAR plt_ord_out.
    READ TABLE plt_ord_out WITH KEY
       kdauf = plt_trim_details-kdauf
       kdpos = plt_trim_details-kdpos
       BINARY SEARCH.
    IF sy-subrc = 0.
* If Standard Trim details exist:

*  Do not change the Standard Unit Weight.
*  Add NCP Total Weight directly to Standard Total Weight
*  Do not change the Standard UOM
*  Calculate NCP Total Units, by dividing the NCP Total Weight by the
*     Standard Unit Weight.
*  Then, Add NCP Total Units to Standard Total Units
*  Do not change the Standard Machine Number

* ZTRIMTOTL_WT
      plt_ord_out-ztrimtotl_wt =
          plt_ord_out-ztrimtotl_wt + plt_ncp-ztrimtotl_wt.

* ZTRIMUNIT_WT (Standard Unit Weight)

* ZTRIMTOTL_UNITS
      IF plt_ord_out-ztrimunit_wt = 0.
        plt_ncp-ztrimtotl_units = 0.
      ELSE.
        plt_ncp-ztrimtotl_units =
              plt_ncp-ztrimtotl_wt / plt_ord_out-ztrimunit_wt.
      ENDIF.

      plt_ord_out-ztrimtotl_units =
            plt_ord_out-ztrimtotl_units + plt_ncp-ztrimtotl_units.

      APPEND plt_ord_out TO lt_combined.
    ELSE.
* Rarely, there may be no Standard Trim Data, in which case, the NCP
*  specific data will be returned
*      READ TABLE plt_ncp WITH KEY                           " <<RLW02-
*              kdauf = plt_trim_details-kdauf                " <<RLW02-
*              kdpos = plt_trim_details-kdpos                " <<RLW02-
*              BINARY SEARCH.                                " <<RLW02-
*      IF sy-subrc = 0.                                      " <<RLW02-
      IF NOT plt_ncp-ztrimtotl_wt IS INITIAL.               " <<RLW02+
        APPEND plt_ncp TO lt_combined.
      ENDIF.
    ENDIF.
  ENDLOOP. " at plt_ncp.

* Delete invalid records with zeros" <<RLW02+
  SORT lt_combined BY ztrimtotl_wt.                         " <<RLW02+
  DELETE lt_combined WHERE ztrimtotl_wt = 0.                " <<RLW02+
  SORT lt_combined BY ztrimunit_wt.                         " <<RLW02+
  DELETE lt_combined WHERE ztrimunit_wt = 0.                " <<RLW02+
  SORT lt_combined BY ztrimtotl_units.                      " <<RLW02+
  DELETE lt_combined WHERE ztrimtotl_units = 0.             " <<RLW02+

  CLEAR plt_trim_details.
  REFRESH plt_trim_details.
  plt_trim_details[] = lt_combined[].
  SORT plt_trim_details BY kdauf kdpos.                     " <<RLW02+

ENDFORM.                    "process_combine


*&---------------------------------------------------------------------*
*&      Form  get_orders_for_pkg
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_orders_for_pkg .

  TYPE-POOLS : ibco2.
  TYPES: BEGIN OF tt_resb,
          rsnum TYPE resb-rsnum,
          rspos TYPE resb-rspos,
          cuobj TYPE resb-cuobj,
          aufnr TYPE resb-aufnr,
          kdauf TYPE resb-kdauf,
          kdpos TYPE resb-kdpos,
          END OF tt_resb.
*---extract data from IBINVAL_SEL_F Table
  TYPES: BEGIN OF tt_node_link,
         rsnum TYPE resb-rsnum,
         rspos TYPE resb-rspos,
         aufnr TYPE resb-aufnr,
         objkey TYPE ibinval_sel_f-objkey,
         atflv  TYPE ibinval_sel_f-atflv,
        kdauf TYPE resb-kdauf,
        kdpos TYPE resb-kdpos,
         END OF tt_node_link.

*---Collecting the objkey and node link value
  TYPES: BEGIN OF tt_ibinval_sel,
         objkey TYPE ibinval_sel_f-objkey,
         atflv  TYPE ibinval_sel_f-atflv,
         END OF tt_ibinval_sel.

*---collecting all reservation to extract operation number
  TYPES: BEGIN OF tt_collection,
          rsnum TYPE resb-rsnum,
          rspos TYPE resb-rspos,
          atflv TYPE ibinval_sel_f-atflv,
          prsnum TYPE resb-rsnum,
          prspos TYPE resb-rspos,
          aufnr TYPE resb-aufnr,
        kdauf TYPE resb-kdauf,
        kdpos TYPE resb-kdpos,
          END OF tt_collection.

   TYPES: BEGIN OF ty_aufnr,
            rsnum TYPE rsnum,
            rspos TYPE rspos,
            aufnr TYPE aufnr,
          END OF ty_aufnr.
    DATA int_aufnr TYPE STANDARD TABLE OF ty_aufnr WITH HEADER LINE INITIAL SIZE 0.



  DATA:   ls_resb TYPE tt_resb,
          lt_resb TYPE STANDARD TABLE OF tt_resb,
          ls_node_link  TYPE tt_node_link,
          lt_node_link  TYPE STANDARD TABLE OF tt_node_link,
          ls_characters  TYPE atinn,
          lt_characters  TYPE  clib_characteristics_t,
          ls_values      TYPE ibco2_value_rec,
          lt_values      TYPE ibco2_value_tab,
          ls_collection    TYPE tt_collection,
          lt_collection    TYPE STANDARD TABLE OF tt_collection,
          ls_ibinval_sel   TYPE tt_ibinval_sel,
          lt_ibinval_sel   TYPE STANDARD TABLE OF tt_ibinval_sel,
          lv_cuib_cuobj TYPE cuib_cuobj.

  CONSTANTS : gc_node_link(10) VALUE 'NODE_LINK',
              gc_objtyp TYPE ibinval_sel_f-objtyp VALUE 'RESB'.


  IF NOT t_aufk_pkg[] IS INITIAL.
    SELECT rsnum rspos cuobj aufnr kdauf kdpos
          INTO TABLE lt_resb
          FROM resb
          FOR ALL ENTRIES IN t_aufk_pkg
          WHERE  aufnr = t_aufk_pkg-aufnr.
  ENDIF.
*---To convert the NODE_LINK characteristic
  CALL FUNCTION 'CONVERSION_EXIT_ATINN_INPUT'
    EXPORTING
      input  = gc_node_link
    IMPORTING
      output = ls_characters.
  INSERT ls_characters INTO TABLE lt_characters.


*---loop and extract the node_link values
  LOOP AT lt_resb INTO ls_resb.
    CLEAR: lv_cuib_cuobj,ls_node_link,ls_values.
    REFRESH: lt_values.

    MOVE ls_resb-cuobj TO lv_cuib_cuobj.
*---extract the node link value
    CALL FUNCTION 'CUCB_GET_SINGLE_VALUES_OF_INST'
      EXPORTING
        iv_cuobj           = lv_cuib_cuobj
        it_characteristic  = lt_characters
      IMPORTING
        et_values          = lt_values
      EXCEPTIONS
        instance_not_found = 1
        OTHERS             = 2.
    IF lt_values IS INITIAL.
      CONTINUE.
    ELSE.
*---As it always contain 1 values so read the first
      READ TABLE lt_values INTO ls_values INDEX 1.
      IF NOT ls_values-atflv IS INITIAL.
        CONCATENATE ls_resb-rsnum ls_resb-rspos
                            INTO ls_node_link-objkey.
        ls_node_link-atflv = ls_values-atflv.
        ls_node_link-rsnum = ls_resb-rsnum.
        ls_node_link-rspos = ls_resb-rspos.
        ls_node_link-aufnr = ls_resb-aufnr.
        ls_node_link-kdauf = ls_resb-kdauf.
        ls_node_link-kdpos = ls_resb-kdpos.
        APPEND ls_node_link TO lt_node_link.
      ENDIF.
    ENDIF.
  ENDLOOP.

*---All the node_links are collected adn these need
*---to be queried to IBINVAL_SEL_F Table
*---to get all the ZTRM order reservation numbers
  IF lt_node_link[] IS NOT INITIAL.

    SELECT objkey atflv FROM ibinval_sel_f
     INTO TABLE lt_ibinval_sel
     FOR ALL ENTRIES IN lt_node_link
     WHERE atinn  = ls_characters
       AND atflv  = lt_node_link-atflv
       AND objkey <> lt_node_link-objkey
       AND objtyp = gc_objtyp.
  ENDIF.


*   loop at lt_node_link into ls_node_link.
*     loop at lt_ibinval_sel into ls_ibinval_sel where atflv = ls_node_link-atflv.
*      ls_collection-rsnum  = ls_ibinval_sel-objkey+0(10).
*      ls_collection-rspos  = ls_ibinval_sel-objkey+10(4).
*      ls_collection-atflv  = ls_ibinval_sel-atflv.
*      ls_collection-prsnum = ls_node_link-rsnum.
*      ls_collection-prspos = ls_node_link-rspos.
*      ls_collection-aufnr = ls_node_link-aufnr.
*      ls_collection-kdauf = ls_node_link-kdauf.
*      ls_collection-kdpos = ls_node_link-kdpos.
*      append ls_collection to lt_collection.
*     endloop.
*   endloop.

*---The Object Key need to be splited for rsnum & rspos
  LOOP AT lt_ibinval_sel INTO ls_ibinval_sel.
*--- store the node link value and his link reservation number
    LOOP AT lt_node_link INTO ls_node_link
               WHERE atflv = ls_ibinval_sel-atflv.
      ls_collection-rsnum  = ls_ibinval_sel-objkey+0(10).
      ls_collection-rspos  = ls_ibinval_sel-objkey+10(4).
      ls_collection-atflv  = ls_ibinval_sel-atflv.
      ls_collection-prsnum = ls_node_link-rsnum.
      ls_collection-prspos = ls_node_link-rspos.
      ls_collection-aufnr = ls_node_link-aufnr.
      ls_collection-kdauf = ls_node_link-kdauf.
      ls_collection-kdpos = ls_node_link-kdpos.
      APPEND ls_collection TO lt_collection.
    ENDLOOP.
  ENDLOOP.

  IF NOT lt_collection[] IS INITIAL.

    SELECT rsnum rspos aufnr FROM resb INTO TABLE int_aufnr
        FOR ALL ENTRIES IN lt_collection
      WHERE rsnum = lt_collection-rsnum AND
            rspos = lt_collection-rspos.
    IF sy-subrc = 0.
      DELETE int_aufnr WHERE aufnr IS INITIAL.

      SELECT aufnr dauat krsnr krsps FROM afpo INTO TABLE int_afpo_temp
        FOR ALL ENTRIES IN int_aufnr
        WHERE aufnr = int_aufnr-aufnr.
      IF sy-subrc = 0.
        SORT int_afpo_temp BY krsnr krsps.
        SORT lt_collection BY rsnum rspos.
        LOOP AT lt_collection INTO ls_collection.
          READ TABLE int_afpo_temp WITH KEY krsnr = ls_collection-rsnum
                                            krsps = ls_collection-rspos BINARY SEARCH.
          IF sy-subrc = 0.
            int_afpo-aufnr = int_afpo_temp-aufnr.
            int_afpo-dauat = int_afpo_temp-dauat.
            int_afpo-krsnr = int_afpo_temp-krsnr.
            int_afpo-krsps = int_afpo_temp-krsps.
            APPEND int_afpo.
            CLEAR int_afpo.
          ENDIF.
          CLEAR ls_collection.
        ENDLOOP.
      ENDIF.
*      SELECT aufnr dauat krsnr krsps FROM afpo INTO TABLE int_afpo
*        FOR ALL ENTRIES IN lt_collection
*        WHERE krsnr = lt_collection-rsnum AND
*              krsps = lt_collection-rspos.
    ENDIF.
  ENDIF.

  LOOP AT int_afpo.
    READ TABLE lt_collection INTO ls_collection WITH KEY rsnum = int_afpo-krsnr
                                      rspos = int_afpo-krsps.
    IF sy-subrc = 0.
      READ TABLE lt_node_link INTO ls_node_link  WITH KEY atflv = ls_collection-atflv.
      IF sy-subrc = 0.
        READ TABLE t_aufk_pkg WITH KEY aufnr = ls_node_link-aufnr.
        IF sy-subrc = 0.
          int_afpo-vbeln = t_aufk_pkg-kdauf.
          int_afpo-posnr = t_aufk_pkg-kdpos.
          MODIFY int_afpo.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.

  DELETE int_afpo WHERE dauat <> 'ZTRM'.

*  if lt_collection[] is not initial.
**---Get the Trim Operations from RESB Table
*    select rsnum rspos rsart xloek erfmg
*           erfme aufnr kdauf kdpos objnr afpos
*          from RESB
*          into table t_resb
*      for all entries in lt_collection
*      where rsnum = lt_collection-rsnum
*        and rspos = lt_collection-rspos.
*  ENDIF.
*
*  loop at t_resb.
*    read table lt_collection into ls_collection
*                with key rsnum = t_resb-rsnum
*                         rspos = t_resb-rspos.
*    if sy-subrc = 0.
*       t_resb-kdauf = ls_collection-kdauf.
*       t_resb-kdpos = ls_collection-kdpos.
*       modify t_resb.
*    endif.
*
*  endloop.

ENDFORM.                    " get_orders_for_pkg

*"**********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005, 20nn                                 **
**                   by INTERNATIONAL PAPER                           **
*______________________________________________________________________*
* Include Name: ZDL_BATCH_STATUS_CHNG_CONSIG         Date: 05/09/2005  *
* Programmer  : Sushila Chaudhary                                      *
*______________________________________________________________________*
* Description : This include is called whenever a export consignment   *
* order related delivery is pgi'd. The movement type 631 will be used  *
* for export consignment orders only. This logic should get called only*
* at the time of pgi and not otherwise.                                *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
************************************************************************
*
*types:  begin of t_batch_data ,
*          matnr type  mchb-matnr,
*          charg type  mchb-charg,
*          werks type mchb-werks,
*        end of t_batch_data.
*
*constants : c_export_consignment_mvt type mseg-bwart value '631',
*            c_complete  type c value 'C',
*            c_shipment_start type sttrg value 5.
*
*data : lt_vtrlk type standard table of vtrlk initial size 0,
*       t_vtrlk type vtrlk,
*       lt_vtrlp type standard table of vtrlp initial size 0,
*       t_vtrlp type vtrlp,
*       lt_vttk type standard table of vttk initial size 0,
*       t_vttk type vttk,
*       lt_batch_data type standard table of t_batch_data initial size 0,
*       s_batch_data type t_batch_data,
*       t_mseg type standard table of mseg initial size 0,
*       t_mcha type standard table of mcha initial size 0,
*       s_mcha type mcha ,
*       t_mch1 type standard table of mch1 initial size 0,
*       s_mch1 type mch1,
*       t_mchb type standard table of mchb initial size 0,
*       update_key_a type c,            " track if change needs to be made
*       update_key_1 type c,            " track if change needs to be made
*       update_key type c.            " track if change needs to be made
*
*break macarte.
*
*************************************************************************
** check that 'shipment start' status is being set
*************************************************************************
*lt_vttk[] = im_shipments_before_update-new_vttk[].
*loop at lt_vttk into t_vttk where sttrg = c_shipment_start.
*  exit.
*endloop.
*if sy-subrc = 0.
*  lt_vtrlk[] = im_shipments_before_update-new_vtrlk[].
*  lt_vtrlp[] = im_shipments_before_update-new_vtrlp[].
*
*************************************************************************
** Check if the movement type is complete. If yes then do nothing .
** Check if the movement type is for export consignment orders only, i.e
** movement type = 631. If yes then change the batch status to restricted
** mode else not.
*************************************************************************
*  loop at lt_vtrlk into t_vtrlk .
*    if t_vtrlk-wbstk_tr = c_complete.
*      exit .
*    endif.
*  endloop .
*
*  if not t_vtrlk-gbstk_tr = c_complete.
*    loop at lt_vtrlp into t_vtrlp.
*      if t_vtrlp-bwart = c_export_consignment_mvt.
*        if t_vtrlp-charg <> space .
*          s_batch_data-matnr = t_vtrlp-matnr .
*          s_batch_data-charg = t_vtrlp-charg.
*          s_batch_data-werks = t_vtrlp-werks.
*          append s_batch_data to lt_batch_data.
*        endif.
*      endif.
*    endloop .
*
*    delete adjacent duplicates from lt_batch_data comparing matnr charg
*    werks.
*
*    if not lt_batch_data[] is initial .
*
**     select * from mchb into table  t_mchb for all entries in lt_batch_data
**                                           where matnr = lt_batch_data-matnr
**                                        and charg = lt_batch_data-charg
**                                        and  werks = lt_batch_data-werks.
**
*      select * from mcha into table  t_mcha for all entries in lt_batch_data
*                                      where matnr = lt_batch_data-matnr
*                                        and charg = lt_batch_data-charg
*                                        and  werks = lt_batch_data-werks.
*
*      select * from mch1 into table  t_mch1 for all entries in lt_batch_data
*                                           where matnr = lt_batch_data-matnr
*                                        and charg = lt_batch_data-charg.
*
*      break macarte.
*
*      loop at t_mch1 into s_mch1.
*        clear update_key_1.
*        if not s_mch1-zusch = 'X'.        " batch status key
*          s_mch1-zusch = 'X'.
*          update_key_1 = 'X'.
*        endif.
*        if not  s_mch1-zustd = 'X'.       "  batch restricted status
*          s_mch1-zustd = 'X'.
*          update_key_1 = 'X'.
*        endif.
*        if update_key_1 = 'X'.
*          s_mch1-aenam = sy-uname.
*          s_mch1-laeda = sy-datum.
*          modify t_mch1 from s_mch1 index sy-tabix.
*          update_key = 'X'.
*        else.
*          delete t_mch1 index sy-tabix.
*        endif.
*      endloop.
*
*      loop at t_mcha into s_mcha.
*        clear update_key_a.
*        if not s_mcha-zusch = 'X'.
*          s_mcha-zusch = 'X'.
*          update_key_a = 'X'.
*        endif.
*        if not  s_mcha-zustd = 'X'.
*          s_mcha-zustd = 'X'.
*          update_key_a = 'X'.
*        endif.
*        if update_key_a = 'X'.
*          s_mcha-aenam = sy-uname.
*          s_mcha-laeda = sy-datum.
*          modify t_mcha from s_mcha index sy-tabix.
*          update_key = 'X'.
*        else.
*          delete t_mcha index sy-tabix.
*        endif.
*      endloop.
*
*      if update_key = 'X'.
*        call function 'VB_UPDATE_BATCH' in update task
*          tables
*            zmcha = t_mcha
*            zmch1 = t_mch1.
**            zmchb = t_mchb.
*      endif.
*    endif.
*  endif.
*endif.

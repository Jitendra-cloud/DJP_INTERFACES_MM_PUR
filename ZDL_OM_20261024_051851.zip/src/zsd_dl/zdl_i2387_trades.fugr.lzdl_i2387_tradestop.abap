FUNCTION-POOL ZDL_I2387_TRADES           MESSAGE-ID SV.

* INCLUDE LZDL_I2387_TRADESD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDL_I2387_TRADEST00                    . "view rel. data dcl.

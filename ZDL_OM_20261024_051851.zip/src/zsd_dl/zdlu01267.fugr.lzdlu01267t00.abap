*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDLU01267_VEKP..................................*
DATA:  BEGIN OF STATUS_ZDLU01267_VEKP                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDLU01267_VEKP                .
CONTROLS: TCTRL_ZDLU01267_VEKP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDLU01267_VEKP                .
TABLES: ZDLU01267_VEKP                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

FUNCTION zsdi02529_vttk_export .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(I_VTTK) TYPE  VTTK
*"----------------------------------------------------------------------

* To export vttk data to global memory

  gs_vttk = i_vttk.

ENDFUNCTION.

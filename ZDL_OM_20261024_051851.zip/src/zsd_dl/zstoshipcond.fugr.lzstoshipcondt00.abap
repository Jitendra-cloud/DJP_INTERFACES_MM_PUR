*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSTOSHIPCOND....................................*
DATA:  BEGIN OF STATUS_ZSTOSHIPCOND                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSTOSHIPCOND                  .
CONTROLS: TCTRL_ZSTOSHIPCOND
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSTOSHIPCOND                  .
TABLES: ZSTOSHIPCOND                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

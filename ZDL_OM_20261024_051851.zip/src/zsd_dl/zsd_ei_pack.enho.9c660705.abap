"Name: \PR:SAPLV51P\EX:V51P_ADD_HU_TO_OBJEKT_04\EN:AUTO_VHU_PO_V51P_ADD_HU_TO_000\SE:END\EI
ENHANCEMENT 0 ZSD_EI_PACK.

  DATA: ls_xvepo like line of lt_xvepo,
        ls_xvekp2 like line of lt_xvekp,
        ls_hu2    like line of lt_hu.

   clear: lv_shtyp, lv_stmshpline, lv_bb_ind.
   READ table gt_objects into ls_objects with key object = '04'. "shpmt
   IF sy-subrc = 0.

    " check that it is an export shpmt or return delivery
    SELECT single shtyp
      Into lv_shtyp
      From VTTK
      Where tknum = ls_objects-objkey.

    IF lv_shtyp <> 'ZEXP'.
        lv_exit = 'X'.
    ENDIF.

      READ table lt_delivery into ls_delivery with key vbeln = gs_header51-objkey
                                                       binary search.
      "check if delivery is breakbulk
      IF sy-subrc = 0.
       SELECT single stmshpline
       Into lv_stmshpline
       From zsd_book_hdr
       Where bookdoc = ls_delivery-bookdoc.

       If lv_stmshpline is not initial.
        SELECT single bb_ind
        Into lv_bb_ind
        From zsd_book_shp_cfg
        Where stmshpline = lv_stmshpline.
       endif.
        If lv_bb_ind = 'X'.
          lv_exit = 'X'.          "do not process breakbulk
        endif.
      endif.

     " check that we’re processing container handling unit in a port
    READ table lt_xvekp into ls_xvekp with key vhart = 'CONT'.
    IF sy-subrc = 0.
       SELECT single type
      Into lv_type
      From ZPLANT
      Where werks = ls_xvekp-werks.

      If lv_type <> 'PORT'.
        lv_exit = 'X'.
      Endif.
    else.
      lv_exit = 'X'.
    ENDIF.

   IF lv_exit is initial.  "process remaining enhanc. code
    LOOP at lt_xvekp into ls_xvekp where vhart = 'CONT'.
    Lv_tabix = sy-tabix.
    refresh lt_items.
    Read table lt_hu into ls_hu2 with key venum = ls_xvekp-venum binary search.
    if sy-subrc = 0.
     Loop at lt_xvepo into ls_xvepo where venum = ls_xvekp-venum.
*    IF sy-subrc = 0.
*     Ls_items-brgew = ls_xvepo-brgew.
       Ls_items-venum = ls_xvepo-venum.
       Ls_items-unvel = ls_xvepo-unvel.
       Append ls_items to lt_items.
       Clear ls_items.
     endloop.
*   Endif.
*   Endloop.
      Sort lt_items by unvel.

   Clear lv_sums.
   Loop at lt_items into ls_items.
    READ table lt_xvekp into ls_xvekp2 with key venum = ls_items-unvel binary search.
    IF sy-subrc = 0.
      Lv_sums = lv_sums + ls_xvekp2-brgew.
*    Else.
*     READ table lt_huwt into ls_huwt with key venum = ls_items-unvel binary search.
*     IF sy-subrc = 0.
*      Lv_sums = lv_sums + ls_huwt-brgew.
*     Endif.
    Endif.
   Endloop.
      "add huwt weight to total of weights of batch level HU's
   Loop at lt_huwt into ls_huwt where venum = ls_xvekp-venum.
    if sy-subrc = 0.
      lv_sums = lv_sums + ls_huwt-brgew.
    endif.
   endloop.
    IF lv_sums = ls_xvekp-brgew.
*    Delete lt_hu_items where venum = ls_xvekp-venum.
    Else.
     DELETE lt_xvekp index lv_tabix.
*     DELETE lt_xvepo where venum = ls_xvekp-venum.
*     DELETE lt_hu_items where venum = ls_xvekp-venum.
     DELETE lt_hu where venum = ls_xvekp-venum.
    Endif.
   Endif.  "if sy-subrc read on lt_hu
    Endloop.



*  DATA LS_OBJECTS LIKE LINE OF GT_OBJECTS.
  FIELD-SYMBOLS: <FS_HU> LIKE LINE OF LT_HU.

  READ TABLE GT_OBJECTS INTO LS_OBJECTS WITH KEY OBJECT  = '04'.

  IF SY-SUBRC EQ 0.

    LOOP AT LT_HU ASSIGNING <FS_HU>.

      IF <FS_HU>-VHART = 'PKG'.
        <FS_HU>-UEVEL = ' '.
      ELSEIF <FS_HU>-VHART = 'CONT'.
        <FS_HU>-VPOBJ = LS_OBJECTS-OBJECT.
        <FS_HU>-VPOBJKEY = LS_OBJECTS-OBJKEY.
      ENDIF.

    ENDLOOP.

  ENDIF.
 Endif.
Endif.   "lv_exit

ENDENHANCEMENT.

FUNCTION ZSDR6453_PRIME_MAT_CHARS .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IP_MATNR) LIKE  LIPS-MATNR
*"     REFERENCE(IP_WERKS) LIKE  LIPS-WERKS
*"  TABLES
*"      PT_CONFIG_M STRUCTURE  CONF_OUT
*"----------------------------------------------------------------------

* Get Material Characteristics for Material on Delivery
*****************************************************************
  PERFORM get_material_chars TABLES pt_config_m
                              USING ip_matnr
                                    ip_werks.

ENDFUNCTION.

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDLR10512TOP.                     " Global Declarations
  INCLUDE LZDLR10512UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDLR10512F...                     " Subroutines
* INCLUDE LZDLR10512O...                     " PBO-Modules
* INCLUDE LZDLR10512I...                     " PAI-Modules
* INCLUDE LZDLR10512E...                     " Events
* INCLUDE LZDLR10512P...                     " Local class implement.
* INCLUDE LZDLR10512T99.                     " ABAP Unit tests

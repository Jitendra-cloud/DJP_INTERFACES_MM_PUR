*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_ADVERSE_LOADINGTOP.           " Global Declarations
  INCLUDE LZDL_ADVERSE_LOADINGUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_ADVERSE_LOADINGF...           " Subroutines
* INCLUDE LZDL_ADVERSE_LOADINGO...           " PBO-Modules
* INCLUDE LZDL_ADVERSE_LOADINGI...           " PAI-Modules
* INCLUDE LZDL_ADVERSE_LOADINGE...           " Events
* INCLUDE LZDL_ADVERSE_LOADINGP...           " Local class implement.
* INCLUDE LZDL_ADVERSE_LOADINGT99.           " ABAP Unit tests

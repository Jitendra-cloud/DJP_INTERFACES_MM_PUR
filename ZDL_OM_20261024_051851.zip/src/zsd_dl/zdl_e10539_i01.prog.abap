*&---------------------------------------------------------------------*
*&  Include           ZSDE10539_I01
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Module  EXIT_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
module exit_command_0100 input.
  perform unlock_delivery.
  set screen 0 .
  leave screen.
endmodule.

*&---------------------------------------------------------------------*
*&      Module  SET_UCOMM  INPUT
*&---------------------------------------------------------------------*
module set_ucomm input.
  g_ucomm = okcode.
  clear okcode.
endmodule.

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module user_command_0100 input.

  gr_ba->check_changed_data( ).

  if g_ucomm = 'ISSUE' or g_ucomm = 'CHECK'.
    read table gt_li with key err-error = 'X'.
    if sy-subrc = 0.
      message 'Errors found. See Line Items for details.' type 'S'
             DISPLAY LIKE 'E'.
      return.
    else.
      message 'No errors found.' type 'S'.
    endif.
  endif.

  case g_ucomm.
    when 'ISSUE'.
      perform issue_to_odb.
    when 'PICK'.
      perform pick.
  endcase.

endmodule.

FUNCTION zdl_e3382_ret_deliv_hus.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(TEST_RUN) TYPE  CHAR1 DEFAULT ' '
*"  TABLES
*"      IT_ZRETDELIVHUS STRUCTURE  ZRETDELIVHUS
*"----------------------------------------------------------------------
***********************************************************************
**                                                                   **
**             C O M P A N Y   C O N F I D E N T I A L               **
**                                                                   **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
**                                                                   **
***********************************************************************
***********************************************************************
**                                                                   **
**                    COPYRIGHT (C) 2005 by                          **
**                     INTERNATIONAL PAPER                           **
**                                                                   **
**                     ALL RIGHTS RESERVED                           **
**                                                                   **
**                   REVISIONS COPYRIGHT (C)                         **
**                            2006                                   **
**                             by                                    **
**                     INTERNATIONAL PAPER                           **
***********************************************************************
*_____________________________________________________________________*
* Report Name: ZDL_E3382_RET_DELIV_HUS               Date: 03/27/2006 *
*                                                                     *
* SAP Name    :                                                       *
*                                                                     *
* Programmer  : Randall Wainwright                                    *
*                                                                     *
*_____________________________________________________________________*
* Description : Breaks the handling units apart in a delivery line
*    item, assigning unique HU numbers using calls to custom
*    function modules:
*      Z_DL_E03126_UNIT_ID_CHECK
*      BAPI_HU_CREATE
*      WS_DELIVERY_UPDATE
*
*---------------------------------------------------------------------*
*_____________________________________________________________________*
* Change History:                                                     *
*     Programmer        Date    Req. #            Action              *
* ==================  ========  ======  ==============================*
*                                                                     *
***********************************************************************

* Populate HUNIT with 'valid/available' EXIDV values
  PERFORM populate_hunits TABLES it_zretdelivhus.

* Create the Handling Units (Calling BAPI)
  PERFORM create_hus TABLES it_zretdelivhus.

ENDFUNCTION.
**********************************************************************
* END OF PROGRAM                                                     *
**********************************************************************

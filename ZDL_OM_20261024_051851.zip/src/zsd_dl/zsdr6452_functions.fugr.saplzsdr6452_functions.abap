*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSDR6452_FUNCTIONSTOP.            " Global Data
  INCLUDE LZSDR6452_FUNCTIONSUXX.            " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSDR6452_FUNCTIONSF...            " Subprograms
* INCLUDE LZSDR6452_FUNCTIONSO...            " PBO-Modules
* INCLUDE LZSDR6452_FUNCTIONSI...            " PAI-Modules

INCLUDE LZSDR6452_FUNCTIONSUBS.

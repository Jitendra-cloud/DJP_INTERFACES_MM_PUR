FUNCTION zdl_create_container01.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     REFERENCE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     REFERENCE(WORKFLOW_RESULT) LIKE  BDWFAP_PAR-RESULT
*"     REFERENCE(APPLICATION_VARIABLE) LIKE  BDWFAP_PAR-APPL_VAR
*"     REFERENCE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     REFERENCE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"     REFERENCE(DOCUMENT_NUMBER) LIKE  VBAK-VBELN
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"      EDI_TEXT STRUCTURE  EDIORDTXT1 OPTIONAL
*"      EDI_TEXT_LINES STRUCTURE  EDIORDTXT2 OPTIONAL
*"----------------------------------------------------------------------
************************************************************************
* Function Module:ZDL_CREATE_CONTAINER01                        *
* Create Date: 12/04/2007                                              *
* Inventory   : E05641                Version:  V4                     *
*                                                                      *
* Programmer  : Naveen Parchuri
*
*______________________________________________________________________*
* Description : Function Module to create Handling Unit via EDI        *
*               EDI Message fron Third Party
*______________________________________________________________________*
* Includes  :  LZDL_CONTAINERU01,                                      *
*              LZDL_CONTAINERTOP                                       *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: ZDL_CREATE_CONTAINER                             *
*______________________________________________________________________*
*   Partner Number : 504943    Partner Type   : LI                     *
*   Process Code   : ZDL_CONT                                          *
*   Message Type   : ZDL_CONTAINER                                     *
*   IDOC Type      : ZDL_CONTAINER01                                   *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer      Date     Req. #            Action                *
* ================  ========  =========    ============================*
* Naveen Parchuri    12/04/2007  EDEK910437    Initial Version         *
************************************************************************

*--- Clearing the variables
  PERFORM initialize_variables.

*--- Read the control data
  READ TABLE idoc_contrl INTO gs_control INDEX 1.

* passing the variables from the idoc to
* the structure
  LOOP AT idoc_data WHERE docnum = idoc_contrl-docnum.
    MOVE idoc_data TO gs_segm.
    PERFORM zcontainer01_segment_modify.
  ENDLOOP.

*--- Check whether there was any error
  IF gt_idoc_status[] IS INITIAL.

* Check for booking document number
    PERFORM check_document.
  ENDIF.

*--- Check whether there was any error
  IF gt_idoc_status[] IS INITIAL.
* get details of handling unit
    PERFORM get_vepo .
  ENDIF.

*--- Check whether there was any error
  IF gt_idoc_status[] IS INITIAL.
* validate the products sent from the idoc
    PERFORM validate_products.
  ENDIF.

*--- Check whether there was any error
  IF gt_idoc_status[] IS INITIAL.
* get hus .
    PERFORM get_hus_to_pack.
  ENDIF.

*--- Check whether there was any error
  IF gt_idoc_status[] IS INITIAL.
    PERFORM create_container.
  ENDIF.

* Trigger the workflow.
  PERFORM trigger_workflow TABLES return_variables
                           CHANGING workflow_result.
*---Move the Complete Collected status to idoc_status internal table
  idoc_status[] = gt_idoc_status[].


ENDFUNCTION.

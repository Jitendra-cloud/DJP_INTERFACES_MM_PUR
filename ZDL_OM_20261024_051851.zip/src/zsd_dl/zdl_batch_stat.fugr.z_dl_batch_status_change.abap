function z_dl_batch_status_change.
*"----------------------------------------------------------------------
*"*"Update function module:
*"
*"*"Local interface:
*"  IMPORTING
*"     VALUE(STATUS) TYPE  BAPIBATCHSTATUS
*"  TABLES
*"      BATCH STRUCTURE  ZDL_BATCH
*"      RETURN STRUCTURE  BAPIRET2
*"----------------------------------------------------------------------
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005, 20nn                                 **
**                   by INTERNATIONAL PAPER                           **
*______________________________________________________________________*
* Function Name: ZDL_BATCH_STATUS_CHANGE             Date: 06/03/2005  *
* Programmer  :  Maureen Carter                                        *
* COR # E03074
*______________________________________________________________________*
* Description : This function can be used to set the batch status from *
* unrestricted to restricted and vice versa                            *
*______________________________________________________________________*
* Change History:                                                      *
*
* 06/28/05  This code was not used because changing the batch status
* creates a material movement document.  The material movement document
* caused a problem with the posting of the shipment status idoc.  It
* caused the BDC session to unexpectedly exit before processing was
* complete.  I did not delete everything because we may need to use this
* in the future.  (Maureen)                                            *
************************************************************************
*  constants: c_update_field type c value 'X'.
*
*  data:
*    batchattributes like bapibatchatt,
*    batchstatus like bapibatchstatus.
*
*  data: w_mcha_i                   like mcha.
*  data: w_mcha_e                   like mcha.
*  data: w_updmcha                  like updmcha.
*  data: f_subrc                    like sy-subrc.
*
*  sort batch.
*
*  if not batch[] is initial.
*    loop at batch.
**   get current status
*      call function 'BAPI_BATCH_GET_DETAIL'
*        exporting
*          material        = batch-matnr
*          batch           = batch-charg
*          plant           = batch-werks
*        importing
*          batchattributes = batchattributes
*          batchstatus     = batchstatus
*        tables
*          return          = return.
*
**  change the MCHA1 status ZUSCH & ZUSTD but only if necessary
*      if status <> batchstatus or status <> batchattributes-statuskey.
*
** copied from BAPI_BATCH_SAVE_REPLICA
**---- Call function module for change
*        w_mcha_i-mandt = sy-mandt.
*        w_mcha_i-matnr = batch-matnr.
*        w_mcha_i-werks = batch-werks.
*        w_mcha_i-charg = batch-charg.
*        w_mcha_i-zusch = status.
*        w_mcha_i-zustd = status.
*        w_updmcha-zusch = c_update_field.
*        w_updmcha-zustd = c_update_field.
*        call function 'VB_CHANGE_BATCH'
*          exporting
*            ymcha              = w_mcha_i
*            yupdmcha           = w_updmcha
*            buffer_refresh     = 'X'
*          importing
*            ymcha              = w_mcha_e
*          exceptions
*            no_material        = 1
*            no_batch           = 2
*            no_plant           = 3
*            material_not_found = 4
*            plant_not_found    = 5
*            lock_on_material   = 6
*            lock_on_plant      = 7
*            lock_on_batch      = 8
*            lock_system_error  = 9
*            no_authority       = 10
*            batch_not_exist    = 11
*            others             = 12.
*
**---- Error by changing
*        if sy-subrc <> 0.
*          f_subrc = sy-subrc.
*          call function 'BALW_BAPIRETURN_GET2'
*            exporting
*              type   = sy-msgty
*              cl     = sy-msgid
*              number = sy-msgno
*              par1   = sy-msgv1
*              par2   = sy-msgv2
*              par3   = sy-msgv3
*              par4   = sy-msgv4
*            importing
*              return = return.
*          loop at return.
*          endloop.
*          clear return.
*        endif.
*      endif.
*
**------ Change Status ZUSTD but only if necessary
*      if status <> batchstatus.
*        call function 'VB_CHANGE_BATCH_STATUS'
*          exporting
*            matnr                   = batch-matnr
*            charg                   = batch-charg
*            werks                   = batch-werks
*            zustd                   = status
*            authority_check         = ' '
*            calltcode               = 'MSC2'
*          exceptions
*            no_material             = 1
*            no_batch                = 2
*            no_plant                = 3
*            no_unit                 = 4
*            no_status_handling      = 5
*            no_batch_handling       = 6
*            no_status_to_change     = 7
*            no_status_handled_plant = 8
*            material_not_found      = 9
*            batch_not_found         = 10
*            plant_not_found         = 11
*            error_in_goods_movement = 12
*            lock_on_material        = 13
*            lock_on_plant           = 14
*            lock_system_error       = 15
*            function_not_supported  = 16
*            no_authority            = 17
*            others                  = 18.
*        if sy-subrc <> 0.
*          f_subrc = sy-subrc.
*          call function 'BALW_BAPIRETURN_GET2'
*            exporting
*              type   = sy-msgty
*              cl     = sy-msgid
*              number = sy-msgno
*              par1   = sy-msgv1
*              par2   = sy-msgv2
*              par3   = sy-msgv3
*              par4   = sy-msgv4
*            importing
*              return = return.
*          loop at return.
*          endloop.
*          clear return.
*        endif.
*      endif.
*
*      if f_subrc is initial.
*        commit work.
*      endif.
*
*    endloop.
*
*  endif.

endfunction.

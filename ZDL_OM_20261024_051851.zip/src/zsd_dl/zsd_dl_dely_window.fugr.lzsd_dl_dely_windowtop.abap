FUNCTION-POOL ZSD_DL_DELY_WINDOW.           "MESSAGE-ID ..

data: it_vbbe like vbbe occurs 0,
      it_vbep like vbep occurs 0.

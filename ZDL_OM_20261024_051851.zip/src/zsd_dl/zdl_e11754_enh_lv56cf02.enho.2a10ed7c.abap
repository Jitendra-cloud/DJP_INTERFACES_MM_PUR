"Name: \PR:SAPLV56C\FO:TRANSPORTART\SE:END\EI
ENHANCEMENT 0 ZDL_E11754_ENH_LV56CF02.
*----------------------------------------------------------------------------------------
* If the Transportation planning point submitted for Shipment created is maintained
* in ZDL_FIELDS then the logic will override the number range interval with the ZDL_FIELD
* value else it will bypass this logic and continue to use the standard number range.
* Created by: Helena Malkowska                                              Date: 06/2021
*----------------------------------------------------------------------------------------
  if sy-cprog = 'ZDL_E11734_SYLVAMO_3PP'.

    select * from zdl_fields into table @data(lt_fields)
      where category = 'E11754'.

    "---Range for VIRTUAL PLANTS
    data(lr_tplst) = value /bofu/t_fbi_value_range( for ls_fields in lt_fields
                                            where ( fieldname = 'TPLST' )
                                                  ( sign = 'I'
                                                    option = 'EQ'
                                                    low = ls_fields-lowval ) ).

    "---IP Shipment Number range
    data(lv_numke) = value #( lt_fields[ fieldname = 'NUMKE' ]-lowval optional ).

    if lr_tplst[] is not initial and i_vttk_tplst in lr_tplst[].

      if lv_numke is not initial.
        "---Override the number range
        ta_tvtk-numke = condense( lv_numke ).
      endif.

    endif.
  endif.

ENDENHANCEMENT.

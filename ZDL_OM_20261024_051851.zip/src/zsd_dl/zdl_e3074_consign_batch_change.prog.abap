*"*********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER              **
**                      ALL RIGHTS RESERVED                          **
**            REVISIONS COPYRIGHT (C) 2005, 2006, 20nn               **
**                     by INTERNATIONAL PAPER                        **
*_____________________________________________________________________*
* Include Name: ZDL_E3074_CONSIGN_BATCH_CHANGE       Date: 06/10/2005 *
* Programmer  : Sushila Chaudhary / Maureen Carter                    *
*_____________________________________________________________________*
* Description : This program can be used to set the batch status from *
* unrestricted to restricted or vice versa depending on selection     *
*                                                                     *
*_____________________________________________________________________*
* Change History:                                                     *
* M Carter    02/2006  CO60191 change selection date                  *
* M Carter    09.2006  tpr14894 check receipt status   MC001          *
*       (an issue when shipment complete date = shipment end date)    *
* M Carter    09.2006  R8 CR5164 add selection options & processing   *
*       for VMC 3rd party deliveries                                  *
* FADEEB     24/2009   CHG 107256  Change the Shippment Completion
*                                  date into a Range                  *
* JLeake   1/7/11  CHG 120375 - bug in check for receipts before      *
*                  setting batch to restricted.  Added sort for binary*
***********************************************************************

REPORT (sy-repid) NO STANDARD PAGE HEADING
                  LINE-COUNT 55
                  MESSAGE-ID 00.

***********************************************************************
*  Tables
***********************************************************************
TABLES: mcha, vttk, lips.

***********************************************************************
*  Types
***********************************************************************
TYPE-POOLS sscr.

***********************************************************************
*  Constants
***********************************************************************
CONSTANTS: c_nobatch TYPE charg_d VALUE '          ',
           c_xflag(1)    VALUE 'X',
           c_xlude(1)    VALUE 'Z'.

***********************************************************************
*  Data variables
***********************************************************************
TYPES:  BEGIN OF gl_batch,
       werks     TYPE werks_d,
       matnr     TYPE matnr_d,
       charg     TYPE charg_d,
       vgbel     TYPE vgbel,  "sales order
       vgpos     TYPE vgpos,  "sales order line item
       kunnr     TYPE kunnr,  "sold-to
       kunag     TYPE kunnr,  "ship-to
       tknum     TYPE tknum,  "shipment number
       vbeln     TYPE vbeln,  "delivery
       posnr     TYPE posnr,  "delivery item
       status(1) TYPE c,
       result(220) TYPE c,
       END OF gl_batch.

DATA:  t_batch TYPE gl_batch OCCURS 0 WITH HEADER LINE.

* Fields for selection screen - limit selection options
DATA: restrict     TYPE sscr_restrict,
      opt_list     TYPE sscr_opt_list,
      assoc        TYPE sscr_ass.

* Internal tables for error messages.
DATA: BEGIN OF error_tab OCCURS 0.
        INCLUDE STRUCTURE soli.
DATA: END OF error_tab.

***********************************************************************
*  Screen
***********************************************************************
* select fields to use and batch status
SELECTION-SCREEN BEGIN OF BLOCK ps0 WITH FRAME TITLE text-t00.

SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN COMMENT (43) text-t11.
SELECTION-SCREEN COMMENT 47(29) text-t16.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN BEGIN OF LINE.
PARAMETERS:      ra_shpdt RADIOBUTTON GROUP a DEFAULT 'X'.
SELECTION-SCREEN COMMENT 3(43) text-t01.
PARAMETERS:      rb_unrst RADIOBUTTON GROUP b DEFAULT 'X'.
SELECTION-SCREEN COMMENT 50(29) text-t06.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN BEGIN OF LINE.
PARAMETERS:      ra_mtrlb RADIOBUTTON GROUP a.
SELECTION-SCREEN COMMENT 3(43) text-t02.
PARAMETERS:      rb_rstct RADIOBUTTON GROUP b.
SELECTION-SCREEN COMMENT 50(29) text-t05.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN BEGIN OF LINE.
PARAMETERS:      ra_dlvr RADIOBUTTON GROUP a.
SELECTION-SCREEN COMMENT 3(43) text-t12.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF LINE.                             "<<MC001
PARAMETERS:  p_rcpt AS CHECKBOX DEFAULT 'X'.                "<<MC001
SELECTION-SCREEN COMMENT 3(43) text-t08.                    "<<MC001
SELECTION-SCREEN END OF LINE.                               "<<MC001


SELECTION-SCREEN END OF BLOCK ps0.

* enter shipment selection options
SELECTION-SCREEN BEGIN OF BLOCK ps1 WITH FRAME TITLE text-t03.

SELECT-OPTIONS: s_shpmnt FOR vttk-tknum       " Shipment Number
                MODIF ID ps1
                NO INTERVALS.

* Begin of  changes.. fadeeb CHG 107256
SELECT-OPTIONS: so_date FOR vttk-dtabf
                MODIF ID ps1.
* End of  changes.. fadeeb CHG 107256

SELECT-OPTIONS: s_time FOR vttk-uatbg
                MODIF ID ps1.

SELECTION-SCREEN END OF BLOCK ps1.

* enter specific material / batch info
SELECTION-SCREEN BEGIN OF BLOCK ps2
                WITH FRAME TITLE text-t04.
PARAMETERS:     p_werks LIKE mcha-werks
                MODIF ID ps2,
                p_matrl LIKE mcha-matnr
                MODIF ID ps2.
SELECT-OPTIONS: s_charg FOR mcha-charg
                MODIF ID ps2
                NO INTERVALS.
SELECTION-SCREEN END OF BLOCK ps2.

* enter specific plant / delivery info for VMC 3rd party deliveries R8
SELECTION-SCREEN BEGIN OF BLOCK ps3 WITH FRAME TITLE text-t13.
PARAMETERS:     p_werks3 LIKE lips-werks
                MODIF ID ps3,
                p_pstyv3 LIKE lips-pstyv
                MODIF ID ps3.
SELECT-OPTIONS: s_dlvry3 FOR lips-vbeln
                MODIF ID ps3
                NO INTERVALS.
SELECT-OPTIONS: s_charg3 FOR mcha-charg
                MODIF ID ps3
                NO INTERVALS.
PARAMETERS:     p_gi_dt LIKE likp-wadat_ist
                DEFAULT sy-datum
                MODIF ID ps3.
SELECTION-SCREEN END OF BLOCK ps3.

* Report and update options
SELECTION-SCREEN BEGIN OF BLOCK ps4 WITH FRAME TITLE text-t07.
SELECTION-SCREEN: BEGIN OF LINE.
PARAMETERS:       r1_noupd RADIOBUTTON GROUP c DEFAULT 'X'.
SELECTION-SCREEN: COMMENT 3(79) text-s22,
                  END OF LINE.

SELECTION-SCREEN: BEGIN OF LINE.
PARAMETERS:       r1_all RADIOBUTTON GROUP c.
SELECTION-SCREEN: COMMENT 3(79) text-s23,
                  END OF LINE.

SELECTION-SCREEN: BEGIN OF LINE.
PARAMETERS:       r1_chg RADIOBUTTON GROUP c.
SELECTION-SCREEN: COMMENT 3(79) text-s24,
                  END OF LINE.

SELECTION-SCREEN: BEGIN OF LINE.
PARAMETERS:       r1_err RADIOBUTTON GROUP c.
SELECTION-SCREEN: COMMENT 3(79) text-s25,
                  END OF LINE.

SELECTION-SCREEN BEGIN OF LINE.                      "R8
PARAMETERS:  p_rptex AS CHECKBOX DEFAULT 'X'.
SELECTION-SCREEN COMMENT 3(57) text-t09.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN END OF BLOCK ps4.

RANGES: zsdom_e3074_werks FOR zsdomfld-fieldname,
        zsdom_e3074_pstyv FOR zsdomfld-fieldname.
CONSTANTS : c_i(01)  TYPE c VALUE 'I',
            c_eq(02) TYPE c VALUE 'EQ'.

INCLUDE zsdomfld.                                 "R8

*---------------------------------------------------------------------*
* INITIALIZATION.
*---------------------------------------------------------------------*
INITIALIZATION.

* get values from ZSDOMFLDS
  PERFORM get_values_from_zsdomflds.              "R8

  PERFORM restrict_multi_selection.

*---------------------------------------------------------------------*
* TOP-OF-PAGE                                                         *
*---------------------------------------------------------------------*
TOP-OF-PAGE.
*---------------------------------------------------------------------*
  PERFORM top_of_page.

*---------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.                    "R8
*---------------------------------------------------------------------*
* disable some fields based on the option selected
  IF ra_shpdt = c_xflag.
    LOOP AT SCREEN.
      IF screen-group1 = 'PS2' OR screen-group1 = 'PS3'.
        screen-input = '0'.
      ELSEIF screen-name = 'S_SHPMNT'
           OR screen-name = 'SO_DATE'
           OR screen-name = 'S_TIME'.
        screen-input = '1'.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ELSEIF ra_mtrlb = c_xflag.
    LOOP AT SCREEN.
      IF screen-group1 = 'PS1' OR screen-group1 = 'PS3'.
        screen-input = '0'.
      ELSEIF screen-name = 'P_WERKS'
           OR screen-name = 'P_MATRL'
           OR screen-name = 'S_CHARG'.
        screen-input = '1'.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ELSEIF ra_dlvr = c_xflag.
    LOOP AT SCREEN.
      IF screen-group1 = 'PS1' OR screen-group1 = 'PS2'.
        screen-input = '0'.
      ELSEIF screen-name = 'P_WERKS3'
           OR screen-name = 'P_PSTYV3'
           OR screen-name = 'S_DLVRY3'
           OR screen-name = 'S_CHARG3'
           OR screen-name = 'P_GI_ST'.
        screen-input = '1'.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.

  ENDIF.
*---------------------------------------------------------------------*
* AT SELECTION-SCREEN                                                 *
*---------------------------------------------------------------------*
AT SELECTION-SCREEN.


*---------------------------------------------------------------------*
* START-OF-SELECTION                                                   *
*---------------------------------------------------------------------*
START-OF-SELECTION.

* Validate data entered by the user on the selection screen.
  PERFORM validate_parameters.

  PERFORM get_batches.

  PERFORM check_for_batch_receipt.

*---------------------------------------------------------------------*
* END-OF-SELECTION.
*---------------------------------------------------------------------*
END-OF-SELECTION.

  PERFORM update_batches.

  PERFORM report_output.

*---------------------------------------------------------------------*
*---------------------------------------------------------------------*

*&--------------------------------------------------------------------*
*&      Form  restrict_multi_option
*&--------------------------------------------------------------------*
FORM restrict_multi_selection.

  CLEAR opt_list.
  opt_list-name = 'OPT_LIST'.
  opt_list-options-eq = 'X'.
*  opt_list-options-cp = 'X'.
  APPEND opt_list TO restrict-opt_list_tab.
* restict shipment number
  CLEAR assoc.
  assoc-kind = 'S'.
  assoc-name = 'S_SHPMNT'.
  assoc-sg_main = 'I'.
  assoc-op_main = 'OPT_LIST'.
  APPEND assoc TO restrict-ass_tab.
* restrict batch number
  CLEAR assoc.
  assoc-kind = 'S'.
  assoc-name = 'S_CHARG'.
  assoc-sg_main = 'I'.
  assoc-op_main = 'OPT_LIST'.
  APPEND assoc TO restrict-ass_tab.
* restrict batch number
  CLEAR assoc.
  assoc-kind = 'S'.
  assoc-name = 'S_CHARG3'.
  assoc-sg_main = 'I'.
  assoc-op_main = 'OPT_LIST'.
  APPEND assoc TO restrict-ass_tab.


  CALL FUNCTION 'SELECT_OPTIONS_RESTRICT'
    EXPORTING
      restriction            = restrict
    EXCEPTIONS
      too_late               = 1
      repeated               = 2
      selopt_without_options = 3
      selopt_without_signs   = 4
      invalid_sign           = 5
      empty_option_list      = 6
      invalid_kind           = 7
      repeated_kind_a        = 8
      OTHERS                 = 9.

  IF sy-subrc <> 0.
    MESSAGE e398(00) WITH text-022 text-023 sy-subrc.
  ENDIF.

ENDFORM.                    " restrict_multi_selection

*--------------------------------------------------------------------*
*       FORM TOP_OF_PAGE                                             *
*--------------------------------------------------------------------*
FORM top_of_page.
  DATA: l_head TYPE zrptheader OCCURS 0 WITH HEADER LINE,
        l_action(30) TYPE c.

  IF r1_noupd = c_xflag.
    l_action = 'Report Only'(r01).
  ELSEIF r1_all = c_xflag.
    l_action = 'Update Batches and Report All'(r02).
  ELSEIF r1_chg = c_xflag.
    l_action = 'Update Batches and Report Changes'(r03).
  ELSEIF r1_err = c_xflag.
    l_action = 'Update Batches and Report Errors'(r04).
  ENDIF.

  CALL FUNCTION 'Z_RPT_HEADER'
    EXPORTING
      primary      = 'Consignment Batch Status Report'(r00)
      line3_center = l_action
    TABLES
      header_lines = l_head
    EXCEPTIONS
      OTHERS       = 1.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
  WRITE:
    /001 l_head-line1,
    /001 l_head-line2,
    /001 l_head-line3.

* column headings
  ULINE .
  WRITE : /
              'Status'(h01),
            8 'Plant'(h02),
           14 'Material'(h03),
           24 'Batch'(h04),
           36 'Shipment'(h05),
           48 'Delivery'(h06),
           58 'Sales Order'(h07),
           78 'Ship-to'(h08),
           87 'Sold-to'(h09).
  ULINE.


ENDFORM.                    "TOP_OF_PAGE

*&--------------------------------------------------------------------*
*&      Form  validate_parameters
*&--------------------------------------------------------------------*
FORM validate_parameters.
  CONSTANTS: c_asterisk(10) TYPE c VALUE '*#**',
             c_plus(10) TYPE c VALUE '*#+*'.

  IF ra_shpdt = c_xflag.
* selecting based on shipment info - date or shipment is required
    IF SO_date IS INITIAL                    "FADEEB..CHG107256
         AND s_shpmnt IS INITIAL.
      error_tab-line = 'Shipment or Date is required'(001).
      APPEND error_tab.
      CLEAR  error_tab.
      PERFORM send_errors.
    ENDIF.
*   asterisk / wildcard not allowed for shipment
    LOOP AT s_shpmnt.
      IF s_shpmnt-low CP c_asterisk    "asterisk anywhere in the field
         OR s_shpmnt-low CP c_plus.    "wildcard anywhere in the field
        error_tab-line = 'Wildcard is not allowed'(004).
        APPEND error_tab.
        CLEAR  error_tab.
        PERFORM send_errors.
      ENDIF.
    ENDLOOP.
    CLEAR:  p_werks,
            p_matrl.
    REFRESH s_charg[].

  ELSEIF ra_mtrlb = c_xflag.
* selecting based on material / batch - all 3 fields are required
    IF p_werks IS INITIAL OR p_matrl IS INITIAL OR s_charg IS INITIAL.
      error_tab-line =
              'Plant / Material / Batch are required fields'(003).
      APPEND error_tab.
      CLEAR  error_tab.
      PERFORM send_errors.
    ENDIF.
*   asterisk / wildcard not allowed for batch
    LOOP AT s_charg.
      IF s_charg-low CP c_asterisk   "asterisk anywhere in the field
         OR s_charg-low CP c_plus.   "wildcard anywhere in the field
        error_tab-line = 'Wildcard is not allowed'(004).
        APPEND error_tab.
        CLEAR  error_tab.
        PERFORM send_errors.
      ENDIF.
    ENDLOOP.

    CLEAR    SO_date.                "FADEEB..CHG107256

    REFRESH: s_shpmnt[],
             s_time[].

  ELSEIF ra_dlvr = c_xflag.                        "R8
* selecting based on plant / lips-pstyv / material
*  - first 2 fields are required
    IF p_werks3 IS INITIAL OR p_pstyv3 IS INITIAL.
      error_tab-line =
              'Plant / Document item category are required fields'(005).
      APPEND error_tab.
      CLEAR  error_tab.
      PERFORM send_errors.
    ENDIF.
*   asterisk / wildcard not allowed for batch
    LOOP AT s_charg3.
      IF s_charg3-low CP c_asterisk   "asterisk anywhere in the field
         OR s_charg3-low CP c_plus.   "wildcard anywhere in the field
        error_tab-line = 'Wildcard is not allowed'(004).
        APPEND error_tab.
        CLEAR  error_tab.
        PERFORM send_errors.
      ENDIF.
    ENDLOOP.

  ENDIF.

ENDFORM.                    " validate_parameters

*&--------------------------------------------------------------------*
*&      Form  get_batches
*&--------------------------------------------------------------------*
* get a list of the batches to be processed
*---------------------------------------------------------------------*
FORM get_batches.
  CONSTANTS: c_auart_zkb TYPE auart VALUE 'ZKB'.
  DATA: lt_batch TYPE gl_batch OCCURS 0.

  REFRESH t_batch.
* shipment selection options
***********************************************************************
  IF ra_shpdt = c_xflag.
* Pick all shipments/deliveries currently in 'shipment start' status
*        and with gate exit on the given date and time
    SELECT
        lips~werks         "ship-from plant
        lips~matnr         "material
        lips~charg         "batch / roll nbr
        lips~vgbel         "reference doc for sales order#
        lips~vgpos         "reference doc for sales order line item
        likp~kunnr         "ship-to
        likp~kunag         "sold-to
        vttk~tknum         "shipment nbr
        likp~vbeln         "delivery
        INTO CORRESPONDING FIELDS OF TABLE t_batch
          FROM vttk JOIN vttp
               ON ( vttk~tknum  = vttp~tknum )
          INNER JOIN likp
               ON ( vttp~vbeln  = likp~vbeln )
          INNER JOIN lips
               ON ( likp~vbeln  = lips~vbeln )
          INNER JOIN vbak
               ON ( lips~vgbel   = vbak~vbeln )
          WHERE
               vttk~tknum IN s_shpmnt  AND
*               vttk~datbg = p_date  AND    "shipment start date
               vttk~dtabf IN SO_date  AND
"shipment completion date "FADEEB..CHG107256
*               vttk~sttrg = '006' AND
*               vttk~uatbg IN s_time AND    "shipment start time
               vttk~uzabf IN s_time AND    "shipment completion time
               lips~charg > c_nobatch AND  "batch nbr on delvry line
               lips~vgbel IS NOT NULL AND  "only delvrys for sales ords
               vbak~auart = c_auart_zkb AND "only for consignment orders
               likp~wadat_ist <> 0.   "R8 actual GI date
  ENDIF.

* plant / material / batch option selected
***********************************************************************
  IF ra_mtrlb = c_xflag.
    SELECT
        lips~werks         "ship-from plant
        lips~matnr         "material
        lips~charg         "batch / roll nbr
        lips~vgbel         "reference doc for sales order#
        lips~vgpos         "reference doc for sales order line item
        likp~kunnr         "ship-to
        likp~kunag         "sold-to
        vttk~tknum         "shipment nbr
        likp~vbeln         "delivery
        INTO CORRESPONDING FIELDS OF TABLE t_batch
          FROM vttk JOIN vttp
               ON ( vttk~tknum  = vttp~tknum )
          INNER JOIN likp
               ON ( vttp~vbeln  = likp~vbeln )
          INNER JOIN lips
               ON ( likp~vbeln  = lips~vbeln )
          INNER JOIN vbak
               ON ( lips~vgbel   = vbak~vbeln )
          WHERE
               lips~werks = p_werks AND
               lips~matnr = p_matrl AND
               lips~charg IN s_charg AND
               lips~charg > c_nobatch AND
               lips~vgbel IS NOT NULL AND  "only delvrys for sales ords
               vbak~auart = c_auart_zkb AND "only for consignment orders
               likp~wadat_ist <> 0.   "R8 actual GI date
  ENDIF.

* VMC 3rd party deliveries option selected (R8)
***********************************************************************
  IF ra_dlvr = c_xflag.
*   get delivery items for delivery item category and then go back
*      and get the batch split records for the same delivery line items
    REFRESH lt_batch.
    SELECT
        lips~werks         "ship-from plant
        lips~matnr         "material
        lips~charg         "batch / roll nbr
        lips~vgbel         "reference doc for sales order#
        lips~vgpos         "reference doc for sales order line item
        lips~vbeln         "delivery
        lips~posnr         "delivery item
        likp~kunnr         "ship-to
        likp~kunag         "sold-to
        INTO CORRESPONDING FIELDS OF TABLE lt_batch
          FROM likp INNER JOIN lips
               ON ( likp~vbeln  = lips~vbeln )
          WHERE
               lips~werks = p_werks3 AND
               lips~pstyv = p_pstyv3 AND
               lips~vbeln IN s_dlvry3 AND
               likp~wadat_ist = p_gi_dt.
    IF NOT lt_batch[] IS INITIAL.
      SORT lt_batch BY vbeln posnr.
      SELECT
          lips~werks         "ship-from plant
          lips~matnr         "material
          lips~charg         "batch / roll nbr
          lips~vgbel         "reference doc for sales order#
          lips~vgpos         "reference doc for sales order line item
          lips~vbeln         "delivery
          lips~posnr         "delivery item
          likp~kunnr         "ship-to
          likp~kunag         "sold-to
          INTO CORRESPONDING FIELDS OF TABLE t_batch
          FROM likp INNER JOIN lips
                 ON ( likp~vbeln  = lips~vbeln )
          FOR ALL entries IN lt_batch
            WHERE
                 lips~vbeln = lt_batch-vbeln AND
                 lips~matnr = lt_batch-matnr AND
                 lips~charg IN s_charg3.
      DELETE t_batch WHERE charg IS INITIAL.
    ENDIF.
  ENDIF.

ENDFORM.                    " get_batches

*&--------------------------------------------------------------------*
*&      Form  update_batches
*&--------------------------------------------------------------------*
*---------------------------------------------------------------------*
FORM update_batches.
  DATA:
      batchattributes  LIKE bapibatchatt,
      batchattributesx LIKE bapibatchattx,
      batchstatus      LIKE bapibatchstatus,
      batchstatusx     LIKE bapibatchstatusx,
      l_status         LIKE bapibatchstatus.
  DATA: t_return	    LIKE	bapiret2 OCCURS 0 WITH HEADER LINE
.

  IF rb_unrst = c_xflag.
    CLEAR l_status.
  ELSE.
    l_status = c_xflag.
  ENDIF.

* for each batch - get current status and change if needed
  LOOP AT t_batch WHERE status <> c_xlude.

* get current status
    CALL FUNCTION 'BAPI_BATCH_GET_DETAIL'
      EXPORTING
        material        = t_batch-matnr
        batch           = t_batch-charg
        plant           = t_batch-werks
      IMPORTING
        batchattributes = batchattributes
        batchstatus     = batchstatus
      TABLES
        return          = t_return.

    t_batch-status = batchstatus.

*  if 'report only' requested - capture current status and continue
    IF NOT r1_noupd IS INITIAL.
      MODIFY t_batch.
      CONTINUE.
    ENDIF.

*  update was requested - call BAPI to do the update and report errors
    IF t_batch-status <> l_status.
      batchattributes-statuskey = l_status.
      batchattributesx-statuskey = c_xflag.
      batchstatus = l_status.
      batchstatusx = c_xflag.
      CALL FUNCTION 'BAPI_BATCH_SAVE_REPLICA'
        EXPORTING
          material         = t_batch-matnr
          batch            = t_batch-charg
          plant            = t_batch-werks
          batchattributes  = batchattributes
          batchattributesx = batchattributesx
          batchstatus      = batchstatus
          batchstatusx     = batchstatusx
        TABLES
          return           = t_return.

*  update result for report
      LOOP AT t_return WHERE type = 'E' OR type = 'A'.
        CONCATENATE 'Error:'(err) space
                  t_return-message INTO t_batch-result.
        EXIT.
      ENDLOOP.
      IF sy-subrc <> 0.
        t_batch-result = 'Changed'(m20).
        t_batch-status = l_status.
      ENDIF.
      REFRESH t_return[].
    ENDIF.

    MODIFY t_batch.

  ENDLOOP.

ENDFORM.                    " update_batches

*&--------------------------------------------------------------------*
*&      Form  report_output
*&--------------------------------------------------------------------*
*---------------------------------------------------------------------*
FORM report_output.
  CONSTANTS: c_restricted(1) TYPE c VALUE 'R',
             c_unrestricted(1) TYPE c VALUE 'U',
             c_excluded(1) TYPE c VALUE 'X'.
  DATA: l_status(1) TYPE c,
        l_matnr(18) TYPE c,
        l_sales_order(18) TYPE c,
        error_flag(1) TYPE c.

* send last record in error_tab to screen
* or all messages to the batch job log
  DATA: lines LIKE sy-tabix.

  IF sy-batch IS INITIAL.
    DESCRIBE TABLE error_tab LINES lines.
    IF lines > 0.
      READ TABLE error_tab INDEX lines.
      MESSAGE s001 WITH error_tab.
      EXIT.
    ENDIF.
  ELSE.
    LOOP AT error_tab.
      MESSAGE s001 WITH error_tab.
    ENDLOOP.
  ENDIF.

* 'no data' message
  IF t_batch[] IS INITIAL.
    MESSAGE s001 WITH 'No data selected'(m00).
    EXIT.
  ENDIF.

* sort
  SORT t_batch BY werks tknum matnr charg.

* report based on selection criteria
  LOOP AT t_batch.
    IF  ( r1_noupd = c_xflag )
        OR
      ( r1_all = c_xflag )
        OR
      ( r1_chg = c_xflag AND NOT t_batch-result(6) IS INITIAL )
        OR
      ( r1_err = c_xflag AND t_batch-result(6) = text-err ).

      CASE t_batch-status.                                  "<<MC001
        WHEN c_xflag.                                       "<<MC001
          l_status = c_restricted.                          "<<MC001
        WHEN c_xlude.                                       "<<MC001
          l_status = c_excluded.                            "<<MC001
          t_batch-result = text-m01.    "Excluded"  "<<MC001
        WHEN OTHERS.                                        "<<MC001
          l_status = c_unrestricted.                        "<<MC001
      ENDCASE.                                              "<<MC001
*      if t_batch-status = c_xflag.               ">>MC001
*        l_status = c_restricted.                 ">>MC001
*      else.                                      ">>MC001
*        l_status = c_unrestricted.               ">>MC001
*      endif.                                     ">>MC001

      WRITE t_batch-matnr TO l_matnr.
      CONCATENATE t_batch-vgbel '/' t_batch-vgpos
               INTO l_sales_order.
      WRITE:
           /3 l_status,                              "'Status'
             t_batch-werks UNDER text-h02,            "'Plant'
             l_matnr(8) UNDER text-h03,            "'Material'
             t_batch-charg UNDER text-h04,            "'Batch'
             t_batch-tknum UNDER  text-h05,        "'Shipment'
             t_batch-vbeln UNDER  text-h06,        "'Delivery'
             l_sales_order UNDER  text-h07,     "'Sales Order'
             t_batch-kunnr UNDER  text-h08,         "'Ship-to'
             t_batch-kunag UNDER  text-h09.         "'Sold-to'
      IF t_batch-result(6) = text-err.
        WRITE: /26  t_batch-result.                  "'Result'
      ELSE.
        WRITE: 96   t_batch-result.                  "'Result'
      ENDIF.

      IF t_batch-result(6) = text-err.
        error_flag = c_xflag.
      ENDIF.
    ENDIF.

  ENDLOOP.

* anything written?
  IF l_matnr IS INITIAL.
    WRITE: / 'Nothing to report'(m23).
  ENDIF.

* if any update errored out and this is a batch job
*            - create an AHD ticket
* ZZPD documentation must be created for the COR#
* ZZPD text should include PRIORITY n and SEVERITY n
*   where n = 1, 2 or 3
*   otherwise priority 1 is assumed
* message will say 'Idoc not created  (text-1.. from function call)'
  IF ( NOT error_flag IS INITIAL )
         AND ( NOT sy-batch IS INITIAL ).
    CALL FUNCTION 'Z_INTERFACE_GEN_AHD_TICKET'
      EXPORTING
        inventory_code = 'E3074'
        text_1         = 'Program ZDL_E3074_CONSIGN_BATCH_CHANGE'(e10)
        text_2         = ' had serious errors.'(e11)
        text_3         = 'Please review the report in the spool.'(e12)
*        text_4         =
*        text_5         =
*        text_6         =
      EXCEPTIONS
        invalid_inv_code       = 1
        ahdgrp_not_found       = 2
        invalid_idoc_number    = 3
        webmd_connection_error = 4
        OTHERS                 = 5.

    IF sy-subrc <> 0.
*// start of schaudh 10/06/2005 .
*/  changes made to catch the sy-subrc error. The case statement should
*/  help prevent the short dumps .
*        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      CASE sy-subrc .
        WHEN '1' .
          MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '86' .
        WHEN '2' .
          MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '87' .
        WHEN '3'.
          MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '88' .
        WHEN '4'.
          MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '89' .
        WHEN OTHERS.
          MESSAGE ID 'ZSD_DL' TYPE 'I' NUMBER '90' .
      ENDCASE .
    ENDIF. " sy-subrc <> 0.

  ENDIF.

ENDFORM.                    " report_output

*&--------------------------------------------------------------------*
*&      Form  send_errors
*&--------------------------------------------------------------------*
*---------------------------------------------------------------------*
FORM send_errors .
* send last record in error_tab to screen or log
  DATA: lines LIKE sy-tabix.

  IF sy-batch IS INITIAL.
    DESCRIBE TABLE error_tab LINES lines.
    IF lines > 0.
      READ TABLE error_tab INDEX lines.
      MESSAGE s001 WITH error_tab.
    ENDIF.
  ELSE.
    LOOP AT error_tab.
      MESSAGE s001 WITH error_tab.
    ENDLOOP.
  ENDIF.
  STOP.

ENDFORM.                    " send_errors

*&---------------------------------------------------------------------*
*&      Form  check_for_batch_receipt
*&---------------------------------------------------------------------*
*  MC001     added 09/2006 for R7 November 2006 VMC consignment
* if the parameter is selected to do this check -
*    and if the batch is found in ZSD_OM_CONS_REC
*   then the batch status should not be changed - set a flag
*----------------------------------------------------------------------*
FORM check_for_batch_receipt .
  DATA: l_tabix TYPE sytabix.
  DATA:  BEGIN OF t_receipts OCCURS 0,
         matnr     TYPE matnr_d,
         werks     TYPE werks_d,
         charg     TYPE charg_d,
         END OF t_receipts.

  CHECK p_rcpt = c_xflag.

  CHECK NOT t_batch[] IS INITIAL.

  SORT t_batch BY matnr werks charg.
  SELECT * FROM zsd_om_cons_rec
      INTO CORRESPONDING FIELDS OF TABLE t_receipts
      FOR ALL ENTRIES IN t_batch
      WHERE
         matnr = t_batch-matnr AND
         werks = t_batch-werks AND
         charg = t_batch-charg.

** chg 120375 **  jrl  **  1/7/11 **
   sort t_receipts.
   delete adjacent duplicates from t_receipts comparing all fields.
   sort t_receipts.
** chg 120375 **  jrl  **  1/7/11 **

  IF NOT t_receipts[] IS INITIAL.
    LOOP AT t_batch.
      l_tabix = sy-tabix.
      READ TABLE t_receipts
        WITH KEY matnr = t_batch-matnr
                 werks = t_batch-werks
                 charg = t_batch-charg
        BINARY SEARCH.
      IF sy-subrc = 0.
        t_batch-status = c_xlude.
        MODIFY t_batch INDEX l_tabix.
      ENDIF.
    ENDLOOP.
  ENDIF.

* delete batches where receipt is complete  R8
  IF p_rptex = c_xflag.
    DELETE t_batch WHERE status = c_xlude.
  ENDIF.

  SORT t_batch BY werks matnr charg.

ENDFORM.                    " check_batch_receipt

*&---------------------------------------------------------------------*
*&      Form  get_values_from_ZSDOMFLDS                     R8
*&---------------------------------------------------------------------*
*----------------------------------------------------------------------*
FORM get_values_from_zsdomflds .
  DATA l_lines LIKE sy-tabix.

* Read Plant Value from ZSDOMFLDS and store in a parameter
  get-value-range 'E3074_WERKS' 'VALUE' zsdom_e3074_werks.
  IF NOT zsdom_e3074_werks[] IS INITIAL.
    DESCRIBE TABLE zsdom_e3074_werks LINES l_lines.
    IF l_lines EQ 1.
      CLEAR zsdom_e3074_werks.
      READ TABLE zsdom_e3074_werks INDEX 1.
      p_werks3 = zsdom_e3074_werks-low.
    ENDIF.
  ENDIF.

** Read Delivery item category from ZSDOMFLDS; store in a parameter
  get-value-range 'E3074_PSTYV' 'VALUE' zsdom_e3074_pstyv.
  IF NOT zsdom_e3074_pstyv[] IS INITIAL.
    DESCRIBE TABLE zsdom_e3074_pstyv LINES l_lines.
    IF l_lines EQ 1.
      CLEAR zsdom_e3074_pstyv.
      READ TABLE zsdom_e3074_pstyv INDEX 1.
      p_pstyv3 = zsdom_e3074_pstyv-low.
*      move c_i to s_pstyv3-sign.
*      move c_eq to s_pstyv3-option.
*      move zsdom_e3074_pstyv-low to s_pstyv3-low.
*      append s_pstyv3.
    ENDIF.
  ENDIF.

ENDFORM.                    " get_values_from_ZSDOMFLDS

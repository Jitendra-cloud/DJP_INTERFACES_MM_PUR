*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z_ZDL_UNI_EQI_TM
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z_ZDL_UNI_EQI_TM    .

  PERFORM TABLEPROC.

ENDFUNCTION.

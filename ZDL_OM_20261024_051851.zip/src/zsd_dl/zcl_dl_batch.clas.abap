class ZCL_DL_BATCH definition
  public
  final
  create public .

*"* public components of class ZCL_DL_BATCH
*"* do not include other source files here!!!
public section.

  data GV_LGNUM type LGNUM read-only .
  data GV_MATNR type MATNR read-only .
  data GV_WERKS type WERKS_D read-only .
  data GV_LGORT type LGORT_D read-only .
  data GV_CHARG type CHARG_D read-only .
  data GV_LGTYP type LGTYP read-only .
  data GV_LGBER type LGBER read-only .
  data GV_LGPLA type LGPLA read-only .

  methods CONSTRUCTOR
    importing
      !IV_LGNUM type LGNUM
      !IV_MATNR type MATNR
      !IV_WERKS type WERKS_D
      !IV_LGORT type LGORT_D
      !IV_CHARG type CHARG_D
      !IV_LGTYP type LGTYP
      !IV_LGBER type LGBER
      !IV_LGPLA type LGPLA
      !IV_GET_CHARS type CHAR1 optional .
  methods MOVE_BIN_TO_BIN
    importing
      !IV_BWLVS type BWLVS
      !IV_ANFME type RL03TANFME
      !IV_ALTME type LRMEI
      !IV_NLTYP type LTAP_NLTYP
      !IV_NLBER type LTAP_NLBER
      !IV_NLPLA type LTAP_NLPLA
      !IV_NLENR type CHAR20 optional
    exceptions
      ERROR_CREATING_TRANSF_ORD .
  methods GET_CHAR_DATA .
  methods UPDATE_CHAR_DATA .
protected section.
*"* protected components of class ZCL_DL_BATCH
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_DL_BATCH
*"* do not include other source files here!!!

  methods CREATE_BATCH .
ENDCLASS.



CLASS ZCL_DL_BATCH IMPLEMENTATION.


METHOD constructor .

* Populate the Batch Attributes
  gv_lgnum = iv_lgnum.
  gv_matnr = iv_matnr.
  gv_werks = iv_werks.
  gv_lgort = iv_lgort.
  gv_charg = iv_charg.
  gv_lgtyp = iv_lgtyp.
  gv_lgber = iv_lgber.
  gv_lgpla = iv_lgpla.

IF not IV_GET_CHARS is initial.
* Get Characteristics

endif.

ENDMETHOD.


method CREATE_BATCH .
endmethod.


method GET_CHAR_DATA .
endmethod.


METHOD MOVE_BIN_TO_BIN .

* Create a transfer order for this batch
  CALL FUNCTION 'L_TO_CREATE_SINGLE'
    EXPORTING
      i_lgnum               = gv_lgnum " Warehouse Number
      i_bwlvs               = iv_bwlvs " Movement Type
      i_matnr               = gv_matnr " Material
      i_werks               = gv_werks " Plant
      i_lgort               = gv_lgort " Storage Location
      i_charg               = gv_charg " Batch Number
      i_anfme               = iv_anfme " Quantity
      i_altme               = iv_altme   " Alt UOM
      i_vltyp               = gv_lgtyp " Source Storage Type
      i_vlber               = gv_lgber " Source Storage Section
      i_vlpla               = gv_lgpla " Source Storage Bin
      i_nltyp               = iv_nltyp " Destination Storage Type
      i_nlber               = iv_nlber " Destination Storage Section
      i_nlpla               = iv_nlpla " Destination Storage Bin
      i_nlenr               = iv_nlenr " Destination Storage Unit Number
    EXCEPTIONS
      no_to_created         = 1
      bwlvs_wrong           = 2
      betyp_wrong           = 3
      benum_missing         = 4
      betyp_missing         = 5
      foreign_lock          = 6
      vltyp_wrong           = 7
      vlpla_wrong           = 8
      vltyp_missing         = 9
      nltyp_wrong           = 10
      nlpla_wrong           = 11
      nltyp_missing         = 12
      rltyp_wrong           = 13
      rlpla_wrong           = 14
      rltyp_missing         = 15
      squit_forbidden       = 16
      manual_to_forbidden   = 17
      letyp_wrong           = 18
      vlpla_missing         = 19
      nlpla_missing         = 20
      sobkz_wrong           = 21
      sobkz_missing         = 22
      sonum_missing         = 23
      bestq_wrong           = 24
      lgber_wrong           = 25
      xfeld_wrong           = 26
      date_wrong            = 27
      drukz_wrong           = 28
      ldest_wrong           = 29
      update_without_commit = 30
      no_authority          = 31
      material_not_found    = 32
      lenum_wrong           = 33
      OTHERS                = 34.
  IF sy-subrc <> 0.
    RAISE error_creating_transf_ord.
  ENDIF.

ENDMETHOD.


method UPDATE_CHAR_DATA .
endmethod.
ENDCLASS.

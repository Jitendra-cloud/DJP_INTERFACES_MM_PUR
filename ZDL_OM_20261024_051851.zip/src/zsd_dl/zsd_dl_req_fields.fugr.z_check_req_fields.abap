FUNCTION z_check_req_fields.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IDOC_CONTROL) LIKE  EDIDC STRUCTURE  EDIDC
*"     REFERENCE(AUX_KEY1) LIKE  ZREQ_FIELDS-ZAUX_KEY1 OPTIONAL
*"     REFERENCE(INVENTORY_CODE) TYPE  ZZINV
*"     REFERENCE(AHD_TKT_SKIP_FLAG) TYPE  CHAR1 DEFAULT ' '
*"     REFERENCE(AHD_TEXT4) TYPE  CHAR50 OPTIONAL
*"     REFERENCE(AHD_TEXT5) TYPE  CHAR50 OPTIONAL
*"     REFERENCE(AHD_TEXT6) TYPE  CHAR50 OPTIONAL
*"     REFERENCE(APP_LOG_SKIP_FLAG) TYPE  CHAR1 DEFAULT ' '
*"     REFERENCE(APP_LOG_OBJECT) TYPE  BALOBJ_D DEFAULT 'ZDS_INTERFACE'
*"     REFERENCE(APP_LOG_SUBOBJECT) TYPE  BALSUBOBJ DEFAULT
*"       'I2143_REQFIELDS_AHD'
*"  TABLES
*"      IDOC_DATA STRUCTURE  EDIDD
*"      APPLOG_OUTPUT STRUCTURE  ZRET_TEXT OPTIONAL
*"  EXCEPTIONS
*"      CONTROL_RECORD_MISSING
*"      DATA_RECORD_MISSING
*"      NO_REQUIRED_VALUES
*"      UNIDENTIFIABLE_IDOC_STRUCTURE
*"      EMPTY_FIELDS_IDENTIFIED
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**           COPYRIGHT (C) 2004 by INTERNATIONAL PAPER                **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**           2005, 20yy, 20zz by INTERNATIONAL PAPER                  **
************************************************************************
* Program Name: I02143                           Create Date: 08/10/04 *
* SAP Name    : Z_CHECK_REQ_FIELDS               Version    : 1.0      *
* Programmer  : Randall Wainwright               Last Update: 05/03/06 *
*______________________________________________________________________*
* Description : This function module accepts the control record and    *
*   corresponding data records of any generic IDoc, then queries       *
*   custom table ZREQ_FIELDS for a list of required fields specific to *
*   the RICE ID of the calling program, generating application log     *
*   entries and an AHD ticket if such logging is necessary.            *
*______________________________________________________________________*
* Change History:                                                      *
*  DEVELOPER NOTE: This function module/Top Include is and should      *
*   always be exactly identical to the corresponding copy in R/3       *
*   Enterprise or APO, as the case may be.                             *
*______________________________________________________________________*
* Programmer    Date      Req. #     Action                            *
* ============  ========  =========  ==================================*
* SCHAUDH       10/06/05             <<< SC01 Changes made to catch    *
*                                    the sy-subrc error at the time    *
*                                    of AHD create. This is required to*
*                                    prevent short dumps               *
* SCHAUDH      12/08/2005            <<< SC02 Changes made to replace  *
*                                    the error messages issued after the
*                                    ahd ticket create FM into appl.log*
*                                                                      *
* SRENGAN      05/03/2006           <<<SR01 Send E-mail when a field   *
*                                   is missing or invalid if there is  *
*                                   a corresponding entry(ies) in the  *
*                                   table ZZMAILTAB.                   *
*                                                                      *
*______________________________________________________________________*
* Includes          : ZCA_APLOG_LOG_STANDARD - App Log Standards       *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: Z_INTERFACE_GEN_AHD_TICKET                       *
*______________________________________________________________________*
* Program Variable Naming Standards:                                   *
*                                                                      *
*  Variable usage can be identifed by the first character of the name  *
*                                                                      *
*  C - Constants                       CB - Checkbox                   *
*  G - Global data definitions         I  - Internal tables            *
*  L - Local data definitions          P  - Parameters                 *
*  R - Range tables                    RB - Radio buttons              *
*  S - Select options                  ST - Structure                  *
*  T - Types                           O  - Object Reference           *
*______________________________________________________________________*

*** DATA DECLARATIONS

  DATA: st_idoc_control LIKE edidc,
        st_idoc_data    LIKE edidd,
         i_idoc_data    LIKE edidd OCCURS 0.

  DATA: BEGIN OF i_req_fields OCCURS 0.
          INCLUDE STRUCTURE zreq_fields.
  DATA:   first(1)         TYPE c,
          all_populated(1) TYPE c,
        END OF i_req_fields.

  DATA: st_edsappl           LIKE edsappl,
         i_edsappl           LIKE edsappl OCCURS 0,
         i_edsappl_by_segnam LIKE edsappl OCCURS 0.

  DATA: g_offset TYPE i, " Placeholder for IDoc DATA field
        g_length TYPE i, " Placeholder for IDoc DATA field
        g_check_var(255) TYPE c,
        g_aux_key1       LIKE zreq_fields-zaux_key1.

  DATA: l_hold_tabix  LIKE sy-tabix,
        l_text2       TYPE char50,
        l_text3       TYPE char50,
        l_logical_sys LIKE tbdls-logsys,
*<<<SR01 - start
* Receivers for email
        i_mailkey  LIKE TABLE OF zzmailtab WITH HEADER LINE.
*<<<SR02 - End

*"----------------------------------------------------------------------
*** Initial Passed-Data Validations

* If there is no control record, raise an exception noting that
*  the control record is missing.
  IF idoc_control IS INITIAL.
    RAISE control_record_missing.
  ENDIF. " idoc_control IS INITIAL.

* If there is no data records, raise an exception noting that
*  the data records are missing.
  IF idoc_data[] IS INITIAL.
    RAISE data_record_missing.
  ENDIF. " idoc_data[] IS INITIAL.

*"----------------------------------------------------------------------
*** Transfer passed parameter data to temporary work areas
  CLEAR st_idoc_control.
  st_idoc_control = idoc_control.
  g_idoc_number  = st_idoc_control-docnum.
  g_message_type = st_idoc_control-mestyp.
  g_receiver_num = st_idoc_control-rcvprn.
  g_sender_num   = st_idoc_control-sndprn.

  g_inventory_code = inventory_code.
  g_aux_key1       = aux_key1.

  i_idoc_data[]    = idoc_data[].

* Perform SELECT queries to populate i_req_fields and i_edsappl,
*  using segnam from i_idoc_data and message type.
  PERFORM req_fields_get_data TABLES i_req_fields
                                     i_edsappl
                                     i_idoc_data
                               USING g_message_type
                                     g_aux_key1.

*"----------------------------------------------------------------------
*** Loop through and validate IDoc data fields
  SORT: i_edsappl    BY segtyp,
        i_req_fields BY zmsg_type zseg_name zfieldname,
        i_idoc_data  BY segnam.
  CLEAR: st_edsappl,
         st_idoc_data.

*** Loop through the IDoc Data (EDIDD/i_idoc_data), using data from
*  table EDSAPPL to target and validate fields listed in I_REQFIELD
*  by segment type
  LOOP AT i_idoc_data INTO st_idoc_data.

* Build a filtered table of only the current segment type's fields
* to loop through for each segment of the IDoc
    REFRESH i_edsappl_by_segnam.
    i_edsappl_by_segnam[] = i_edsappl[].
    DELETE i_edsappl_by_segnam WHERE segtyp <> st_idoc_data-segnam.

    SORT i_edsappl_by_segnam BY segtyp pos.
    CLEAR st_edsappl.

* Loop through the subset of field lengths specific to the
* current segment type in order of position
    CLEAR: g_offset, g_length.
    LOOP AT i_edsappl_by_segnam INTO st_edsappl.

      g_offset = g_offset + g_length.
      g_length = st_edsappl-expleng.

* Read I_REQ_FIELDS to determine if current field is a required field
      CLEAR i_req_fields.

      g_check_var = st_idoc_data-sdata+g_offset(g_length).

      READ TABLE i_req_fields WITH KEY
        zmsg_type  = g_message_type
        zseg_name  = st_edsappl-segtyp
        zfieldname = st_edsappl-fieldname
        zvalue     = g_check_var.
      IF NOT sy-subrc = 0.
        READ TABLE i_req_fields WITH KEY
            zmsg_type  = g_message_type
            zseg_name  = st_edsappl-segtyp
            zfieldname = st_edsappl-fieldname.
      ENDIF.
      CHECK sy-subrc = 0.
* This field is a required field
      l_hold_tabix = sy-tabix.

* DELETE to ignore i_req_fields records with valid values:
* 1) No alternate value in ZVALUE, this field is only required to be
*     not blank, and the field is populated, ignore.
* 2) There is an alternate value in ZVALUE. Compare it to
*     the contents of the current data field and if they match, ignore
      IF ( i_req_fields-zvalue IS INITIAL
         AND NOT g_check_var IS INITIAL )
       OR ( NOT i_req_fields-zvalue IS INITIAL
         AND g_check_var EQ i_req_fields-zvalue ).

        IF i_req_fields-zrequired_all IS INITIAL.
          DELETE i_req_fields INDEX l_hold_tabix.
        ELSE.
          IF i_req_fields-first IS INITIAL.
            i_req_fields-first         = 'X'.
            i_req_fields-all_populated = 'X'.
            MODIFY i_req_fields INDEX l_hold_tabix.
          ENDIF.
        ENDIF.
      ELSE.
        IF i_req_fields-first IS INITIAL.
          i_req_fields-first         = 'X'.
        ENDIF.
        CLEAR i_req_fields-all_populated.
        MODIFY i_req_fields INDEX l_hold_tabix.
      ENDIF.

    ENDLOOP. " AT i_edsappl_by_segnam INTO st_edsappl.

  ENDLOOP. " AT i_idoc_data INTO st_idoc_data.

  REFRESH: i_mailkey.                                       "<<<SR01

  SORT i_req_fields BY all_populated DESCENDING
                    zmsg_type zseg_name zfieldname.
  LOOP AT i_req_fields.
    IF NOT i_req_fields-all_populated IS INITIAL.
      DELETE i_req_fields INDEX sy-tabix.
*<<<SR01 - For Email Notification - Start
    ELSE.
* Frame mail key as MessageType_SegmentName
      CONCATENATE i_req_fields-zmsg_type
                  i_req_fields-zseg_name
             INTO i_mailkey-mailkey
        SEPARATED BY ':'.
* Remove any spaces
      CONDENSE i_mailkey-mailkey NO-GAPS.

      APPEND i_mailkey.
      CLEAR  i_mailkey.
*<<<SR01 - End
    ENDIF.
  ENDLOOP.

* If records were left in i_req_fields, they signify failed field
*  validations. Write an application log record for each failure
  IF NOT i_req_fields[] IS INITIAL.
    CLEAR l_text2.
    CLEAR l_text3.

*<<<SR01 - Email notification logic - start
    PERFORM sub_mail  TABLES i_req_fields
                             i_mailkey
                      using  ahd_text4.
*<<<SR01 - End

* Write out an Application Log entry for each missing/invalid required
*  field if the calling program provided an app log object and subobject
*  and did not set APP LOG skip flag
    IF NOT app_log_object    IS INITIAL
        AND NOT app_log_subobject IS INITIAL
        AND     app_log_skip_flag IS INITIAL.

      PERFORM req_fields_app_log TABLES i_req_fields
                                 USING  g_idoc_number
                                        app_log_object
                                        app_log_subobject
                                        ahd_text4
                                        ahd_text5
                                        ahd_text6
                                        ahd_tkt_skip_flag   "<<< SC02
                                        g_app_log_ext_id
                                        g_app_log_nbr.

*** Prepare texts for AHD Ticket:

      CONCATENATE 'Object:'
                  app_log_object
                  'SubObject:'
                  app_log_subobject INTO l_text2 SEPARATED BY space.

      CONCATENATE 'EXT ID: '
                  g_app_log_ext_id
                  'LOG#: '
                  g_app_log_nbr INTO l_text3 SEPARATED BY space.

      applog_output[] = gt_return[].

    ENDIF. " app_log_skip_flag IS INITIAL.

* Generate AHD Ticket linking back to Application Log if the calling
*  program did not set the AHD ticket skip flag
    IF ahd_tkt_skip_flag IS INITIAL.

* Identify current logical system:
      CALL FUNCTION 'PARTNER_LOGICAL_SYSTEM_GET'
        IMPORTING
          p_logsys                       = l_logical_sys
        EXCEPTIONS
          own_logical_system_not_defined = 1
          OTHERS                         = 2.
      IF sy-subrc <> 0.
        l_logical_sys = 'UNKNOWN'.
      ENDIF.

* Add logical system data to l_text2, regardless of if an application
*  log was generated:
      CONCATENATE 'Logical System:'
                  l_logical_sys
                  l_text2 INTO l_text2 SEPARATED BY space.
      FREE l_logical_sys.

      PERFORM req_fields_ahd_tkt TABLES applog_output       "<<< SC02
                                 USING l_text2
                                       l_text3
                                       ahd_text4
                                       ahd_text5
                                       ahd_text6
                                       app_log_skip_flag    "<<< SC02
                                       app_log_object       "<<< SC02
                                       app_log_subobject    "<<< SC02
                                       g_app_log_ext_id
                                       g_app_log_nbr.

    ENDIF. " ahd_log_skip_flag IS INITIAL.

    RAISE empty_fields_identified.

  ENDIF. " NOT i_req_fields[] IS INITIAL.

ENDFUNCTION.

function zdl_rail_rate.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_REQUNR) TYPE  SRSC_S_IF_SIMPLE-REQUNR
*"     VALUE(I_DSOURCE) TYPE  SRSC_S_IF_SIMPLE-DSOURCE OPTIONAL
*"     VALUE(I_MAXSIZE) TYPE  SRSC_S_IF_SIMPLE-MAXSIZE OPTIONAL
*"     VALUE(I_INITFLAG) TYPE  SRSC_S_IF_SIMPLE-INITFLAG OPTIONAL
*"     VALUE(I_READ_ONLY) TYPE  SRSC_S_IF_SIMPLE-READONLY OPTIONAL
*"  TABLES
*"      I_T_SELECT TYPE  SRSC_S_IF_SIMPLE-T_SELECT OPTIONAL
*"      I_T_FIELDS TYPE  SRSC_S_IF_SIMPLE-T_FIELDS OPTIONAL
*"      E_T_DATA STRUCTURE  ZDLE11459_LT_RAIL_RATE OPTIONAL
*"  EXCEPTIONS
*"      NO_MORE_DATA
*"      ERROR_PASSED_TO_MESS_HANDLER
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2019 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
************************************************************************
* Program Name: E11459 - Rail Rate Function Module                     *
*                                                Create Date: 24/04/19 *
*                                                                      *
* SAP Name    : ZDL_RAIL_RATE                    Version    : final    *
*                                                                      *
* Programmer  : Helena Malkowska                 Last Update: mm/dd/yy *
*______________________________________________________________________*
* Description : Function Module for Extracting Rail Rate               *
*______________________________________________________________________*
* Change History:                                                      *
* Programmer       Date      CD#        Action                         *
* ================ ========= ========== ===============================*
* Helena Malkowska 05/2019   2000001291 Initial transport              *
*                                                                      *
************************************************************************

  types: begin of t_cond.
      include type komg.
  types: knumh type knumh,
         kappl type kappl,
         kschl type kschl,
         datbi type kodatbi,
         datab type kodatab,
        end of t_cond.

  types: begin of t_rail_rate.
      include type zdle11459_lt_rail_rate.
  types: knumh type knumh,
         end of t_rail_rate.

  statics: g_if type srsc_s_if_simple.

  types: t_kappl type range of kappl.
  types: t_kschl type range of kschl.
  types: t_tplst type range of tplst.
  types: t_knota type range of knota.
  types: t_knotz type range of knotz.
  types: t_route type range of route.
  types: t_tdlnr type range of tdlnr.
  types: t_vsart type range of vsart.
  types: t_vsbed type range of vsbed.
  types: t_zstcc type range of zzstcc.
  types: t_kunnr type range of kunnr.
  types: t_cstvnd_city type range of /saprgx/cstvnd_city.
  types: t_regioz type range of regioz.
  types: t_land1z type range of land1z.
  types: t_datum type range of sy-datum.

  data: lr_kappl  type t_kappl.
  data: lr_kschl  type t_kschl.
  data: lr_tplst  type t_tplst.
  data: lr_knota  type t_knota.
  data: lr_knotz  type t_knotz.
  data: lr_route  type t_route.
  data: lr_tdlnr  type t_tdlnr.
  data: lr_vsart  type t_vsart.
  data: lr_vsbed  type t_vsbed.
  data: lr_zstcc  type t_zstcc.
  data: lr_kunnr  type t_kunnr.
  data: lr_cstvnd_city type t_cstvnd_city.
  data: lr_regioz type t_regioz.
  data: lr_land1z type t_land1z.
  data: lr_valid_to   type t_datum.
  data: lr_valid_from type t_datum.
  data: lr_valid_date type range of sy-datum.

  data: ls_kappl type line of t_kappl.
  data: ls_kschl type line of t_kschl.
  data: ls_tplst type line of t_tplst.
  data: ls_knota type line of t_knota.
  data: ls_knotz type line of t_knotz.
  data: ls_route  type line of t_route.
  data: ls_tdlnr  type line of t_tdlnr.
  data: ls_vsart  type line of t_vsart.
  data: ls_vsbed  type line of t_vsbed.
  data: ls_zstcc  type line of t_zstcc.
  data: ls_kunnr  type line of t_kunnr.
  data: ls_cstvnd_city type line of t_cstvnd_city.
  data: ls_regioz type line of t_regioz.
  data: ls_land1z type line of t_land1z.
  data: ls_valid_to   type line of t_datum.
  data: ls_valid_from type line of t_datum.

  data: lt_cond type sorted table of t_cond
        with non-unique key knumh.
  data: lt_rail_rate type standard table of t_rail_rate.
  data: ls_cond type t_cond.
  data: lv_valid_from type sy-datum.
  data: lv_valid_to   type sy-datum.
  DATA: ls_valid_date LIKE LINE OF lr_valid_date.


  refresh lt_rail_rate[].

* Initialization mode (first call by SAPI) or data transfer mode
* (following calls) ?
  if i_initflag = sbiwa_c_flag_on.

* Check DataSource validity
    case i_dsource.

      when 'ZDL_RAIL_RATE'.

      when others.
        if 1 = 2.
          message e009(r3) with ''.
        endif.
        log_write 'E'
                  'R3'
                  '009'
                  i_dsource
                  ' '.
        raise error_passed_to_mess_handler.

    endcase.

    append lines of i_t_select to g_if-t_select.

* Fill parameter buffer for data extraction calls
    g_if-requnr    = i_requnr.
    g_if-dsource   = i_dsource.
    g_if-maxsize   = i_maxsize.

  else.
* Only process extraction once.
    if g_counter_datapakid = 0.
      g_counter_datapakid = g_counter_datapakid + 1.

* Fill the ranges
      loop at i_t_select into data(ls_select).

        case ls_select-fieldnm.
          when 'KAPPL'.
            ls_kappl = corresponding #( ls_select ).
            append ls_kappl to lr_kappl.

          when 'KSCHL'.
            ls_kschl    = corresponding #( ls_select ).
            append ls_kschl to lr_kschl.
*
*          when 'TPLST'.
*            ls_tplst = corresponding #( ls_select ).
*            append ls_tplst to lr_tplst.
*
*          when 'KNOTA'.
*            ls_knota = corresponding #( ls_select ).
*            append ls_knota to lr_knota.
*
*          when 'KNOTZ'.
*            ls_knotz = corresponding #( ls_select ).
*            append ls_knotz to lr_knotz.

*          when 'ROUTE'.
*            ls_route = corresponding #( ls_select ).
*            append ls_route to lr_route.
*
*          when 'TDLNR'.
*            ls_tdlnr    = corresponding #( ls_select ).
*            append ls_tdlnr to lr_tdlnr.
*
*          when 'VSART'.
*            ls_vsart = corresponding #( ls_select ).
*            append ls_vsart to lr_vsart.
*
*          when 'VSBED'.
*            ls_vsbed = corresponding #( ls_select ).
*            append ls_vsbed to lr_vsbed.
*
*          when 'ZSTCC'.
*            ls_zstcc = corresponding #( ls_select ).
*            append ls_zstcc to lr_zstcc.
*
*          when 'KUNNR'.
*            ls_kunnr = corresponding #( ls_select ).
*            append ls_kunnr to lr_kunnr.
*
*          when 'CSTVND_CITY'.
*            ls_cstvnd_city  = corresponding #( ls_select ).
*            append ls_cstvnd_city to lr_cstvnd_city.
*
*          when 'REGIOZ'.
*            ls_regioz = corresponding #( ls_select ).
*            append ls_regioz to lr_regioz.
*
*          when 'LAND1Z'.
*            ls_land1z = corresponding #( ls_select ).
*            append ls_land1z to lr_land1z.
*
*          when 'VALID_TO'.
*            ls_valid_to = corresponding #( ls_select ).
*            append ls_valid_to to lr_valid_to.
*
*          when 'VALID_FROM'.
*            ls_valid_from  = corresponding #( ls_select  ).
*            append ls_valid_from  to lr_valid_from.
        endcase.

      endloop.

      "VALID_FROM & VALID_TO should be a single value
      if lines( lr_valid_from ) = 0.
        lv_valid_from = '00010101'.
        lv_valid_to   = '99991231'.
      else.
        lv_valid_from = value #( lr_valid_from[ 1 ]-low optional ).
        lv_valid_to   = value #( lr_valid_to[ 1 ]-low optional ).
      endif.

      if not lv_valid_to is initial and lv_valid_to < lv_valid_from.
        lv_valid_to = lv_valid_from.
      endif.

      ls_valid_date-option = 'BT'.
      ls_valid_date-sign = 'I'.
      ls_valid_date-low = lv_valid_from.
      ls_valid_date-high = lv_valid_to.
      APPEND ls_valid_date TO lr_valid_date.

      select
        kvewe,
        kappl,
        kschl
      from t685
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
      into table @data(lt_t685).

* Select Data
      loop at lt_t685 into data(ls_t685).

        case ls_t685-kschl.

          when 'ZRBW'.

*            select * from a958
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and route  in lr_route[]
*                and tdlnr  in lr_tdlnr[]
*                and vsbed  in lr_vsbed[]
*                and zstcc  in lr_zstcc[]
*                and cstvnd_city in lr_cstvnd_city[]
*                and regioz in lr_regioz[]
*                and land1z in lr_land1z[].
*
*            select * from a946
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and route  in lr_route[]
*                and tdlnr  in lr_tdlnr[]
*                and vsbed  in lr_vsbed[]
*                and cstvnd_city in lr_cstvnd_city[]
*                and regioz in lr_regioz[]
*                and land1z in lr_land1z[].

            select * from a958
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a946
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a936
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a929
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a933
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a967
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a944
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a959
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a922
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a965
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a947
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a966
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a942
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a934
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a919
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a906
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.

          when 'ZRRW'.

            select * from a983
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a712
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a969
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a920
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a981
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a990
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a707
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a992
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a995
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a906
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.

*          when 'ZTFM'.

*            select * from a900
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and route  in lr_route[]
*                and tdlnr  in lr_tdlnr[].
*
*            select * from a933
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and route  in lr_route[]
*                and vsart  in lr_vsart[]
*                and kunnr  in lr_kunnr[].
*
*            select * from a943
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and route  in lr_route[]
*                and vsart  in lr_vsart[].
*
*            select * from a937
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and tdlnr  in lr_tdlnr[]
*                and cstvnd_city in lr_cstvnd_city[]
*                and regioz in lr_regioz[]
*                and land1z in lr_land1z[].
*
*            select * from a906
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tdlnr  in lr_tdlnr[]
*                and vsart  in lr_vsart[].
*
*            select * from a930
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and vsart  in lr_vsart[].

          when 'ZTFM' or 'ZTFS'.

*            select * from a919
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and route  in lr_route[]
*                and vsart  in lr_vsart[].
*
*            select * from a943
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and route  in lr_route[]
*                and vsart  in lr_vsart[].
*
*            select * from a929
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and tdlnr  in lr_tdlnr[]
*                and vsbed  in lr_vsbed[]
*                and cstvnd_city in lr_cstvnd_city[]
*                and regioz in lr_regioz[].
*
*            select * from a937
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and tdlnr  in lr_tdlnr[]
*                and cstvnd_city in lr_cstvnd_city[]
*                and regioz in lr_regioz[]
*                and land1z in lr_land1z[].
*
*            select * from a925
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tplst  in lr_tplst[]
*                and tdlnr  in lr_tdlnr[].
*
*            select * from a906
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and tdlnr  in lr_tdlnr[]
*                and vsart  in lr_vsart[].
*
*            select * from a930
*              appending corresponding fields of table lt_cond
*              where kappl = ls_t685-kappl
*                and kschl = ls_t685-kschl
*                and vsart  in lr_vsart[].

            select * from a900
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a933
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a971
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a919
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a897
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a943
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a936
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a929
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a937
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a923
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a940
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a938
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a917
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a928
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a927
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a925
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a926
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a941
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a906
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.
            select * from a930
              appending corresponding fields of table lt_cond
              where kappl = ls_t685-kappl
                and kschl = ls_t685-kschl
                and datab in lr_valid_date
                and datbi in lr_valid_date.

        endcase.
      endloop.

      "Valid From/To
*      loop at lt_cond assigning field-symbol(<ls_cond>).
*        if lv_valid_to  is initial.
*          if not ( <ls_cond>-datbi >= lv_valid_from and
*                   <ls_cond>-datab <= lv_valid_from ).
*            delete table lt_cond from <ls_cond>.
*          endif.
*        else.
*          if not ( <ls_cond>-datbi >= lv_valid_from and
*                   <ls_cond>-datab <= lv_valid_from
*                   or
*                   <ls_cond>-datab >= lv_valid_from and
*                   <ls_cond>-datab <= lv_valid_to  ).
*            delete table lt_cond from <ls_cond>.
*          endif.
*        endif.
*      endloop.


      "Get Condition Record Header/Items
      if lt_cond[] is not initial.

        select
          konh~knumh,
          konp~kopos,
          konh~kotabnr,
          konh~kappl,
          konh~kschl,
          konp~kbetr,
          konp~konwa,
          konp~kmein,
          konp~loevm_ko
        from konh
          join konp on konh~knumh = konp~knumh
        into corresponding fields of table @lt_rail_rate
          for all entries in @lt_cond
        where konh~knumh = @lt_cond-knumh.

      endif.

      loop at lt_rail_rate assigning field-symbol(<ls_rail_rate>).

        ls_cond =
         value #( lt_cond[ knumh = <ls_rail_rate>-knumh ] optional ).

        "Transportation planning point
        <ls_rail_rate>-tplst = ls_cond-tplst.
        "Departure Point
        <ls_rail_rate>-knota = ls_cond-knota.
        "Destination point
        <ls_rail_rate>-knotz = ls_cond-knotz.
        "Route
        <ls_rail_rate>-route = ls_cond-route.
        "Number of forwarding agent
        <ls_rail_rate>-tdlnr = ls_cond-tdlnr.
        "Insurance type
        <ls_rail_rate>-vsart = ls_cond-vsart.
        "Insurance type
        <ls_rail_rate>-shtyp = ls_cond-shtyp.
        "Shipping Conditions
        <ls_rail_rate>-vsbed = ls_cond-vsbed.
        "STCC CODE
        <ls_rail_rate>-zstcc = ls_cond-zstcc.
        "Rail carrier region name
        <ls_rail_rate>-zzrail_region = ls_cond-zzrail_region.
        "Customer Number
        <ls_rail_rate>-kunnr = ls_cond-kunnr.
        "Ship-to-party
        <ls_rail_rate>-kunwe = ls_cond-kunwe.
        "Customer/Vendor City
        TRANSLATE ls_cond-cstvnd_city TO UPPER CASE.
        <ls_rail_rate>-cstvnd_city = ls_cond-cstvnd_city.
        "Destination region (federal state, county, province duchy)
        <ls_rail_rate>-regioz = ls_cond-regioz.
        "Destination zone.
        <ls_rail_rate>-lzonez = ls_cond-lzonez.
        "Tariff zone of point of departure.
        <ls_rail_rate>-trfzna = ls_cond-trfzna.
        "Tariff zone of point of destination.
        <ls_rail_rate>-trfznz = ls_cond-trfznz.
        "Country key.
        <ls_rail_rate>-land1z = ls_cond-land1z.
        "Valid From
        <ls_rail_rate>-datab = ls_cond-datab.
        "Valid to
        <ls_rail_rate>-datbi = ls_cond-datbi.

        if <ls_rail_rate>-konwa = '%'. "percent
          <ls_rail_rate>-kbetr = <ls_rail_rate>-kbetr / 10.
        endif.

      endloop.

      sort lt_rail_rate by kotabnr datab knumh.

      e_t_data[] = corresponding #( lt_rail_rate ).

    else.
* Stop after processing data.
      raise no_more_data.
    endif.
  endif.

endfunction.

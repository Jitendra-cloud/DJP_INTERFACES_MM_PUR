class ZCL_IM_DL_E03979_FLEX definition
  public
  final
  create public .

*"* public components of class ZCL_IM_DL_E03979_FLEX
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_BADI_LE_SHIPMENT .
protected section.
*"* protected components of class ZCL_IM_DL_E03979_FLEX
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_DL_E03979_FLEX
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_DL_E03979_FLEX IMPLEMENTATION.


method if_ex_badi_le_shipment~at_save .
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2008 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2008, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Badi Implementation Name : ZDL_E03979_FLEX                01/08/2008 *
* Programmer  : Padma Sunkara                                          *
* Inventory Code :  E04019 - V2- Trigger when Pre-planned Shipment is  *
* deleted or delivery add/removed                                      *
*______________________________________________________________________*
* Description :                                                        *
*  This implementation is for V2-Custom trigger for STO based on       *
*  Shiment Change and is implemented in this BADI                      *
*  BADI: BADI_LE_SHIPMENT and METHOD : AT_SAVE .                       *
*_____________________________________________________________________ *
* Change History:                                                      *
*                                                                      *
*                                                                      *
************************************************************************
* External Calls  ZDL_E04010_FLEX_STO_TRIG_CHECK,

*                 ZDL_I02539_FLEX_STO_TRIGGER
*
*______________________________________________________________________*
************************************************************************
* This Process will be triggered at Save event in  Shipment Create/    *
* Change (Vt01n/vt02n). These validations  are applicable to V2 Mills  *
* Plants only when Pre-Planned Shipment is deleted or Delivery is      *
* Added/Deleted. These validations are for  non FlEX shipments         *
* (Shipment Indicator <> FLEX).                                        *
*                                                                      *
*----------------------------------------------------------------------*
*  field-symbols: <gt_old_vttp> type vttpvb,
*                 <gt_new_vttp> type vttpvb.
*
*  data: gt_tvarvc type table of tvarvc,
*        gs_tvarvc type tvarvc,
*        gs_vttk   type vttkvb,
*        gt_vtrlp  type table of vtrlp,
*        gs_vtrlp  type vtrlp,
*        gs_vtrlk  type vtrlk,
*        gs_zd_fped_loc type zdl_fped_loc,
*        gs_zsp_value  type zsp_value,
*        gt_vttp type table of vttpvb,
*        gs_vttp type vttpvb,
*        gv_ebeln type  ebeln,
*        gv_ebelp type  ebelp,
*        gv_status type  flag,
*        gt_sto_results type zdl_fpedstat.
*
*
*  constants :
*   gc_tvarvc_name         type tvarvc-name value 'Z_V2_TPP',
*   gc_updkz_d             type updkz_d value 'D',
*   gc_updkz_i             type updkz_d value 'I',
*   gc_prog_id             type programm value 'ZDL_E03167',
*   gc_lfart               type zsp_fieldname value 'LFART_2',
*   gc_f                   type zdl_fped_loc-z_flex_ind
*                                           value 'F',
*   gc_b                   type zdl_fped_loc-z_flex_ind
*                                           value 'B',
*  gc_fsh                  type  zdl_ref_type value 'FSH'.
*  break psunkar.
*  refresh gt_vttp.
*  loop at im_shipments_at_save-old_vttp into gs_vttp
*    where updkz = gc_updkz_d.
*    append gs_vttp to gt_vttp.
*  endloop.
*  loop at im_shipments_at_save-new_vttp into gs_vttp
*    where updkz = gc_updkz_i.
*    append gs_vttp to gt_vttp.
*  endloop.
*  if gt_vttp[] is initial." We are not assiging/Deleting any Deliveries
*    exit.
*  endif.
** Select the V2 Transportation Planning points.
*  select  *
*    into  table gt_tvarvc
*    from  tvarvc
*    where name = gc_tvarvc_name.
*
*  loop at gt_vttp into gs_vttp.
*    clear gs_vttk.
*    read table im_shipments_at_save-new_vttk into gs_vttk
*         with key tknum = gs_vttp-tknum.
*    if sy-subrc <> 0.
*      read table im_shipments_at_save-old_vttk into gs_vttk
*           with key tknum = gs_vttp-tknum.
*    endif.
*    if gs_vttk-tknum is initial.
*     continue.
*    endif.
*    if gs_vttk-sdabw = 'FLEX'.
*      continue.
*    endif.
*    clear gs_tvarvc.
*    read table gt_tvarvc into gs_tvarvc
*         with key low = gs_vttk-tplst.
*    if sy-subrc <> 0." Not a V2 shipment
*      continue.
*    endif.
** Validate that the Delivery belongs to STO
*    clear gs_vtrlk.
*    read table im_shipments_at_save-new_vtrlk into gs_vtrlk
*    with key vbeln = gs_vttp-vbeln.
*    clear gs_zsp_value.
*    select single *
*      into gs_zsp_value
*      from zsp_value
*      where pgrmid = gc_prog_id
*      and fieldname like gc_lfart
*      and fieldvalue = gs_vtrlk-lfart.
*    if sy-subrc <> 0. "Delivery Not equal 'NL', then Do not Poke
*      continue.
*    endif.
*
** Validate the Shipping Point
*
*    loop at im_shipments_at_save-new_vtrlp into gs_vtrlp where vbeln =
*
*gs_vtrlk-vbeln.
*      clear gs_zd_fped_loc.
*      select single *
*        into gs_zd_fped_loc
*        from zdl_fped_loc
*        where werks = gs_vtrlp-werks
*        and vstel = gs_vtrlk-vstel
*        and z_flex_ind in (gc_f, gc_b).
*      if sy-subrc = 0.
*        gv_ebeln = gs_vtrlp-vgbel.
*        gv_ebelp = gs_vtrlp-vgpos.
*        call function 'ZDL_E04010_FLEX_STO_TRIG_CHECK'
*          exporting
*            sto_header                       = gv_ebeln
*            sto_item                         = gv_ebelp
*            delv_docu                        = gs_vttp-vbeln
*            ref_type                         = gc_fsh
*            ref_docu                         = gs_vttk-tknum
**       IMPORTING
**         STATUS                             = gv_status
**         TABLES                             = gt_sto_results
**         STO_RESULTS                        =
*       exceptions
*         delivery_not_found_for_sto        = 1
*         fped_status_not_found             = 2
*       others                              = 3
*                  .
*        if sy-subrc = 0.
*          call function 'ZDL_I02539_FLEX_STO_TRIGGER'
*            exporting
*              iv_dlvry_doc         = gs_vttp-vbeln
*              iv_ref_type          = gc_fsh
*              iv_sto_no            = gv_ebeln
*              iv_sto_line          = gv_ebelp
**             IV_FPED_CURR        =
**             IV_FPED_PREV        =
**             IV_FPED_DATE        =
**             IV_FPED_TIME        =
**             IV_PROD_ORDER       =
*              iv_shpmnt           = gs_vttk-tknum
*                    .
*        endif.
*      else.   " Not Valid Shipping Point
*        continue.
*      endif.
*    endloop. " End of Validating the Shipping Point
*  endloop.  " End of loop when Deliveries are deleted/added.
endmethod.                    "


method if_ex_badi_le_shipment~before_update .
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2007, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Badi Implementation Name : ZDL_E03979_FLEX                12/03/2007 *
*                                                                      *
* Programmer  : Padma Sunkara                                          *
*______________________________________________________________________*
* Description :                                                        *
*  This implementation is for Flexible Shipment Shell Validations and  *
*  Shipment Change STO POKE trigger.
*  It is implemented during Shipment SAVE(Before Saving) in this BADI  *
*  BADI: BADI_LE_SHIPMENT and METHOD : BEFORE_UPDATE .                 *
*_____________________________________________________________________ *
* Change History:                                                      *
* PRAGUPA        06/18/2008   V2 Rollback  EDEK912215                  *
*                                                                      *
*______________________________________________________________________*

*----------------------------------------------------------------------*
*  include ZDL_E03979_FLEX. " Shipment Shell Validation
* Begin of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
*  include ZDL_E04019_PREPLAN_SHPMNT_TRIG. " Shipment Change STO Trigger
* End of V2 Rollback By PRAGUPA 06/18/2008 EDEK912215
endmethod.


method IF_EX_BADI_LE_SHIPMENT~IN_UPDATE .
endmethod.
ENDCLASS.

*&---------------------------------------------------------------------*
*&  Include           ZDL_E04625_TOP                                   *
*&---------------------------------------------------------------------*

PROGRAM zdl_e04625_wf_asn MESSAGE-ID zsd_dl.

*>> Start Mpathek
  DATA : gt_edidd_temp TYPE TABLE OF edidd.
*<< End Mpathek

DATA :
gv_ok_9000   TYPE char20,
gv_ok_9100   TYPE char20,
gv_ok_9200   TYPE char20,
gv_docnum    TYPE edi_docnum, "Idoc number
gv_new_ebeln TYPE ebeln.    "New PO number


DATA:
gs_9100       TYPE zdl_e04625_9100,  "structure of screen 9100 fields
"table of exluded application toolbar buttons
gt_itab_excl  TYPE STANDARD TABLE OF sy-ucomm,
gt_zdl_fields TYPE STANDARD TABLE OF zdl_fields,
gs_zdl_fields TYPE zdl_fields,
gs_edids      TYPE edids,
gs_data       TYPE zdl_e04625_data.

DATA : gv_error.

CONSTANTS :
gc_true     TYPE boolean    VALUE 'X',
gc_false    TYPE boolean    VALUE '-', "hyphen = false
gc_x        TYPE char1      VALUE 'X',
gc_v        TYPE char1      VALUE 'V',
gc_e1edl43  TYPE edilsegtyp VALUE 'E1EDL43',
gc_e1edl24  TYPE edilsegtyp VALUE 'E1EDL24',
gc_zsd_dl   TYPE symsgid    VALUE 'ZSD_DL',
gc_b1       TYPE symsgid    VALUE 'B1',
gc_e        TYPE c          VALUE 'E',
gc_i        TYPE c          VALUE 'I',
gc_zdl_vasn TYPE edi_mestyp VALUE 'ZDL_VASN',
gc_changepo TYPE syucomm    VALUE 'CHANGEPO',
gc_reprocess TYPE syucomm   VALUE 'REPROCESS'.

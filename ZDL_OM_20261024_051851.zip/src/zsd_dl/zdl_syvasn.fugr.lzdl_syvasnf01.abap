*----------------------------------------------------------------------*
***INCLUDE LZDL_SYVASNF01.
*----------------------------------------------------------------------*
* @@@@@@@@@@@@ MAINTAIN HISTORY OF CHANGES AT THE START OF @@@@@@@@@@@@*
* @@@@@@@@@@@@@ FUNCTION MODULE Z_DL_I10580_INPUT_SYVASN @@@@@@@@@@@@@@*
*&---------------------------------------------------------------------*
*&      Form  INITIALIZATION
*&---------------------------------------------------------------------*
FORM initialization .

* Clear all global variables and tables
  CLEAR: gs_idoc_ctrl,
         gt_idoc_data[],
         gs_idoc_data,
         gs_memory,
         gt_idoc_status[],
         gs_idoc_status,
         gv_inb_vbeln,
         gt_mbpsv[],
         gt_mbh[],
         gt_po_details,gt_bat_char[],gt_l37,gt_l44,
         gt_delivery_exists,gt_delivery_created,
         gt_mbhp_tab,
         gt_hu,
         gt_mbpsv_chars[].

  gv_usd_created = gc_false.

  CLEAR gv_chk_multiple_usd.

  REFRESH: gt_hu,
           gt_mbpsv,
           gt_mbh,
           gt_po_details,gt_bat_char,gt_l37,gt_l44,
           gt_mbhp_tab.

  gv_idoc_error       =  gc_false.
  gv_inb_vbeln_exists = gc_false.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SUB_IDOC_STATUS_FILL
*----------------------------------------------------------------------*
FORM sub_idoc_status_fill  USING p_status "idoc status
                                 p_docnum "idoc nmber
                                 p_msgty  "mssage type
                                 p_msgid  "message class
                                 p_msgno  "message number
                                 p_msgv1  "message variable 1
                                 p_msgv2  "message variable 2
                                 p_msgv3  "message variable 3
                                 p_msgv4  "message variable 4
                                 p_routid "subroutine or func mod name
                                 p_segnum "segment number
                                 p_segfld."segment field name

  CLEAR: gs_idoc_status.
  gs_idoc_status-status = p_status.
  gs_idoc_status-docnum = p_docnum.
  gs_idoc_status-msgty  = p_msgty.
  gs_idoc_status-msgid  = p_msgid.
  gs_idoc_status-msgno  = p_msgno.
  gs_idoc_status-msgv1  = p_msgv1.
  gs_idoc_status-msgv2  = p_msgv2.
  gs_idoc_status-msgv3  = p_msgv3.
  gs_idoc_status-msgv4  = p_msgv4.
  gs_idoc_status-routid = p_routid.
  gs_idoc_status-segnum = p_segnum.
  gs_idoc_status-segfld = p_segfld.

  gs_idoc_status-uname  = sy-uname.
  gs_idoc_status-repid  = sy-repid.
  APPEND gs_idoc_status TO gt_idoc_status.

  "Set Error flag for errors and warnings
  IF p_msgty EQ c_error OR p_msgty EQ c_info.
    gv_idoc_error = gc_true.
  ENDIF.

  "Create a USD ticket in case of an error
  IF p_msgty EQ c_error AND gv_usd_created = gc_false.
    gv_usd_created = gc_true.
    PERFORM generate_usd_ticket USING gs_idoc_status.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PROCESS_IDOC
*&---------------------------------------------------------------------*
FORM process_idoc .

  DATA lv_weight TYPE lfimg.
  DATA lv_truck  TYPE days.
  DATA lv_rail   TYPE days.
  DATA lt_batches TYPE STANDARD TABLE OF ty_batch.
  DATA lv_skip_scac_check TYPE abap_bool.

*&-------------------------------E1EDL24-------------------------------*
  DATA lv_lfimg  TYPE char15.
  DATA lv_lfimg1 TYPE lfimg.
  DATA lv_matnr TYPE matnr.

  DELETE gt_idoc_data
         WHERE segnam =  gc_e1edl12 OR
               segnam =  gc_e1edl39 OR
             ( segnam =  gc_e1edl44 AND sdata+0(1) EQ 'Z' ).
*              OR segnam =  gc_e1edl18 AND sdata+0(3) EQ 'ORI' ).

  PERFORM remove_e1edl20_segment.

  LOOP AT gt_idoc_data INTO gs_idoc_data
       WHERE docnum  =  gs_idoc_ctrl-docnum
       AND ( segnam  =  gc_e1edl24
          OR segnam  =  gc_e1edl44 ).

    gv_tabix = sy-tabix.

*&-------------------------------E1EDL24-------------------------------*
    IF gs_idoc_data-segnam EQ gc_e1edl24.

      gs_e1edl24 = gs_idoc_data-sdata.

      gs_e1edl24-lfimg = gs_e1edl24-ntgew.

      IF gs_e1edl24-lfimg IS NOT INITIAL.
        lv_lfimg = lv_lfimg + gs_e1edl24-lfimg.
      ENDIF.

      "Sales Unit = ISO Code Base Unit
      gs_e1edl24-vrkme = gs_e1edl24-meins.

      CLEAR: gs_e1edl24-kdmat, gs_e1edl24-kdmat35.

      IF gs_e1edl24-matnr_external IS NOT INITIAL.

        lv_matnr = gs_e1edl24-matnr_external.
        lv_matnr = |{ lv_matnr ALPHA = IN }|.

        gs_e1edl24-matnr = lv_matnr.

      ELSE.
        gs_e1edl24-matnr = |{ gs_e1edl24-matnr ALPHA = IN }|.

      ENDIF.

      IF gs_e1edl24-charg IS NOT INITIAL.
        APPEND VALUE #( matnr = lv_matnr
                        charg = gs_e1edl24-charg )
                        TO lt_batches.
      ENDIF.


      gs_idoc_data-sdata = gs_e1edl24.

*&-------------------------------E1EDL44-------------------------------*
    ELSEIF gs_idoc_data-segnam EQ gc_e1edl44.

      gs_e1edl44 = gs_idoc_data-sdata.

      gs_e1edl44-matnr = |{ gs_e1edl44-matnr ALPHA = IN }|.
      gs_idoc_data-sdata = gs_e1edl44.

    ENDIF.

    MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                                      TRANSPORTING sdata.
  ENDLOOP.

  lv_lfimg1 = lv_lfimg.


*&-------------------------------E1EDT13-------------------------------*
  PERFORM get_zdl_fields1 CHANGING lv_weight lv_truck lv_rail.

  "Goods Issue Date & Goods Issue Time
  IF gs_memory-wadat IS INITIAL.
    CLEAR gs_idoc_data.
    gs_idoc_data = VALUE #( gt_idoc_data[
                               docnum  =  gs_idoc_ctrl-docnum
                               segnam  =  gc_e1edt13
                               sdata+0(3) = '499' ] OPTIONAL ).
    IF gs_idoc_data IS NOT INITIAL.
      gs_e1edt13 = gs_idoc_data-sdata.

      IF gs_e1edt13-ntanf IS NOT INITIAL.
        gs_memory-wadat = gs_e1edt13-ntanf.
        gs_memory-wauhr = gs_e1edt13-ntanz.
      ENDIF.
    ENDIF.
  ENDIF.

  IF gs_memory-wadat IS INITIAL.
    CLEAR gs_idoc_data.
    gs_idoc_data = VALUE #( gt_idoc_data[
                               docnum  =  gs_idoc_ctrl-docnum
                               segnam  =  gc_e1edt13
                               sdata+0(3) = '006' ] OPTIONAL ).
    IF gs_idoc_data IS NOT INITIAL.
      gs_e1edt13 = gs_idoc_data-sdata.

      IF gs_e1edt13-ntanf IS NOT INITIAL.
        gs_memory-wadat = gs_e1edt13-ntanf.
        gs_memory-wauhr = gs_e1edt13-ntanz.
      ENDIF.
    ENDIF.
  ENDIF.

  "Get Delivery Date for segment E1EDT13-QUALF = '007'
  DATA lv_delivery_date TYPE likp-lfdat.
  PERFORM get_delivery_date CHANGING lv_delivery_date.

  DATA lv_dldate TYPE lfdat.
  LOOP AT gt_idoc_data INTO gs_idoc_data
           WHERE docnum  =  gs_idoc_ctrl-docnum
             AND segnam  =  gc_e1edt13.

    gv_tabix   =  sy-tabix.
    gs_e1edt13 = gs_idoc_data-sdata.

    "Update Delivery Date
    IF gs_e1edt13-qualf = '007'.

      gs_e1edt13-ntanf = lv_delivery_date.
      gs_idoc_data-sdata = gs_e1edt13.
      MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                                        TRANSPORTING sdata.
    ENDIF.


    IF gs_e1edt13-ntanf IS NOT INITIAL AND
       lv_weight IS NOT INITIAL.

      lv_dldate = gs_e1edt13-ntanf.

      IF lv_lfimg1 LT lv_weight AND lv_truck IS NOT INITIAL.
        lv_dldate = lv_dldate + lv_truck.
        gs_e1edt13-ntanf = lv_dldate.
        gs_idoc_data-sdata = gs_e1edt13.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                                          TRANSPORTING sdata.
      ELSEIF lv_lfimg1 GE lv_weight AND lv_rail IS NOT INITIAL.
        lv_dldate = lv_dldate + lv_rail.
        gs_e1edt13-ntanf = lv_dldate.
        gs_idoc_data-sdata = gs_e1edt13.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                                          TRANSPORTING sdata.
      ENDIF.

    ENDIF.

  ENDLOOP.



  "Check if SDM Ticket already created
  DATA lv_docnum  TYPE edi_docnum.
  CLEAR gv_chk_multiple_usd.
  SELECT SINGLE docnum
         FROM edids
         INTO lv_docnum
         WHERE docnum = gs_idoc_ctrl-docnum
         AND status = c_idoc_status_error.

  IF lv_docnum IS NOT INITIAL.
    gv_chk_multiple_usd = 'X'.
  ENDIF.

  DATA lv_41tabix TYPE sytabix.
  DATA lv_24count TYPE i.

  DATA lv_bolnr TYPE likp-bolnr.
  DATA lv_error TYPE boolean.

  LOOP AT gt_idoc_data
        INTO gs_idoc_data
        WHERE   docnum  =  gs_idoc_ctrl-docnum
          AND ( segnam  =  gc_e1edl20 OR"Shipping Condition, BOL
                segnam  =  gc_e1edl24 OR"Material, batch
                segnam  =  gc_e1edl28 OR"ShippingType
                segnam  =  gc_e1edl18 OR"ShipmentType,SCAC,Export Values,Skip SCAC
                segnam  =  gc_e1adrm1 OR"SCAC
                segnam  =  gc_e1edl41 OR"PO, PO Item
                segnam  =  gc_e1edl15 )."Characteristics

    gv_tabix      =  sy-tabix.
    lv_41tabix    =  sy-tabix.

    CASE gs_idoc_data-segnam.

*&-------------------------------E1EDL20-------------------------------*
      WHEN gc_e1edl20.
        CLEAR lv_skip_scac_check.

        PERFORM process_e1edl20 CHANGING lv_bolnr
                                         lv_error.
        IF lv_error IS NOT INITIAL.
          CONTINUE.
        ENDIF.

*&-------------------------------E1EDL24-------------------------------*
      WHEN gc_e1edl24.

        gs_e1edl24    = gs_idoc_data-sdata.

        "Disregard E1EDL24 segment with no batch, this means item is a
        "Batch Split Item
        IF gs_e1edl24-hipos IS INITIAL AND gs_e1edl24-charg IS INITIAL.
          DATA(lv_skip_e1edl41) = abap_true.
          CONTINUE.
        ENDIF.


        lv_24count = lv_24count + 1.

        IF gt_mbhp_tab IS NOT INITIAL.
          APPEND gt_mbhp_tab.
          CLEAR  gt_mbhp_tab.

          gt_bat_char-chars[] = gt_mbpsv_chars[].
          APPEND gt_bat_char.
          CLEAR  gt_bat_char.

          REFRESH gt_mbpsv_chars.

          APPEND gt_po_details.
          CLEAR  gt_po_details.
        ENDIF.


        IF gs_e1edl24-matnr IS NOT INITIAL.
          gt_mbhp_tab-matnr     = gs_e1edl24-matnr.
          gt_mbhp_tab-charg     = gs_e1edl24-charg.

          "Update Batch characteristics table also
          gt_bat_char-matnr    = gs_e1edl24-matnr.
          gt_bat_char-charg    = gs_e1edl24-charg.
          gt_bat_char-vendrbatch = gs_e1edl24-charg.

        ELSE.
          "Validation:No Material found in ASN &
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZDL'                   "message class
              '001'                   "err msg
              lv_24count              "msgv1
              ' '                     "msgv2
              ' '                     "msgv3
              ' '                     "msgv4
              'PROCESS_IDOC'          "routid
              gc_e1edl24              "seg num
              ' '.                    "seg field
          CONTINUE.
        ENDIF.


        DATA lv_flag1 TYPE char1.
        PERFORM update_weight_e1edl24 USING gs_e1edl24 lv_flag1.

        IF lv_flag1 = 'Y'.
          gs_idoc_data-sdata   = gs_e1edl24.

          MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
                 TRANSPORTING sdata.
        ENDIF.


        gt_mbhp_tab-24tabix   = gv_tabix.

        CLEAR gv_tabix.

*&-------------------------------E1EDL41-------------------------------*
      WHEN gc_e1edl41.

        CLEAR  gs_e1edl41.
        "Fetch all PO numbers. - this is required only for Vendor ASN
        gs_e1edl41 = gs_idoc_data-sdata.

        IF gs_e1edl41-quali = '001'.
          CLEAR: gv_ebeln.
          IF NOT gs_e1edl41-ihrez IS INITIAL.

            gv_ebeln = |{ gs_e1edl41-ihrez(10) ALPHA = IN }|.

            "Update gt_idoc_data with this PO number.
            gs_e1edl41-ihrez     = gv_ebeln.
            gs_e1edl41-bstnr     = gv_ebeln.

            gs_e1edl41-posex = CONV ebelp( gs_e1edl41-posex ).

            gs_idoc_data-sdata   = gs_e1edl41.
            MODIFY gt_idoc_data FROM gs_idoc_data
                      INDEX gv_tabix
                      TRANSPORTING sdata.


            "Disregard E1EDL41 if the parent E1EDL24 has been diregarded
            IF lv_skip_e1edl41 IS NOT INITIAL.
              CLEAR lv_skip_e1edl41.
              CONTINUE.
            ENDIF.

            gt_mbhp_tab-ebeln    = gv_ebeln.
            gt_mbhp_tab-41tabix  = gv_tabix.

            "Used to check for existence of PO line item in SAP
            gt_po_details-ebeln    = gv_ebeln.
            gt_po_details-41tabix  = lv_41tabix.


          ELSE.
            "Validation:No Purchase Order on ASN for &
            PERFORM sub_idoc_status_fill USING
                c_idoc_status_error     "status 51
                gs_idoc_ctrl-docnum     "idoc number
                c_error                 "status msg type
                'ZDL'                   "message class
                '002'                   "err msg
                lv_bolnr                "msgv1
                ' '                     "msgv2
                ' '                     "msgv3
                ' '                     "msgv4
                'PROCESS_IDOC'          "routid
                gc_e1edl41              "seg num
                ' '.                    "seg field
            CONTINUE.
          ENDIF.


        ENDIF.

        SELECT SINGLE FROM ekpo
          FIELDS ebelp,matnr,loekz
          WHERE ebeln EQ @gv_ebeln AND
                ebelp EQ @gs_e1edl41-posex
          INTO @DATA(ls_ekpo).
        IF ls_ekpo IS INITIAL.

          "Validation:PO &, PO Item & does not exist
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZDL'                   "message class
              '033'                   "err msg
              gv_ebeln                "msgv1
              gs_e1edl41-posex        "msgv2
              ' '                     "msgv3
              ' '                     "msgv4
              'PROCESS_IDOC'          "routid
              gc_e1edl41              "seg num
              ' '.                    "seg field
          CONTINUE.

        ELSEIF ls_ekpo-matnr NE gs_e1edl24-matnr.

          "Validation:Material & not on PO &, PO Item
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZDL'                   "message class
              '027'                   "err msg
              gs_e1edl24-matnr        "msgv1
              gv_ebeln                "msgv2
              gs_e1edl41-posex        "msgv3
              ' '                     "msgv4
              'PROCESS_IDOC'          "routid
              gc_e1edl41              "seg num
              ' '.                    "seg field
          CONTINUE.

        ELSEIF ls_ekpo-loekz IS NOT INITIAL.

          "Validation:PO &, PO Item &, Material & deleted
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZDL'                   "message class
              '026'                   "err msg
              gv_ebeln                "msgv1
              ls_ekpo-ebelp           "msgv2
              gs_e1edl24-matnr        "msgv3
              ' '                     "msgv4
              'PROCESS_IDOC'          "routid
              gc_e1edl41              "seg num
              ' '.                    "seg field
          CONTINUE.

        ELSE.
          gt_mbhp_tab-ebelp = ls_ekpo-ebelp.

          gs_e1edl41-posex = ls_ekpo-ebelp.

          gs_idoc_data-sdata   = gs_e1edl41.
          MODIFY gt_idoc_data FROM gs_idoc_data
                    INDEX gv_tabix
                    TRANSPORTING sdata.

        ENDIF.

*&-------------------------------E1EDL15-------------------------------*
      WHEN gc_e1edl15.
        CLEAR  gs_e1edl15.
        "Fetch Batch characteristics value
        gs_e1edl15                = gs_idoc_data-sdata.

        PERFORM format_e1edl15 USING gs_e1edl15-atbez
                            CHANGING gs_e1edl15-atwrt.

        gt_mbpsv_chars-atnam      = gs_e1edl15-atbez.
        gt_mbpsv_chars-atwrt      = gs_e1edl15-atwrt.

        CONDENSE gt_mbpsv_chars-atwrt NO-GAPS.
        APPEND gt_mbpsv_chars.
        CLEAR  gt_mbpsv_chars.

*&-------------------------------E1EDL28-------------------------------*
      WHEN gc_e1edl28.
        CLEAR  gs_e1edl28.

        gs_e1edl28 = gs_idoc_data-sdata.


        IF gs_e1edl28-vsart IS INITIAL.

          "Validation:No Shipping Type on the ASN
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZDL'                   "message class
              '024'                   "err msg
              ' '                     "msgv1
              ' '                     "msgv2
              ' '                     "msgv3
              ' '                     "msgv4
              'PROCESS_IDOC'          "routid
              gc_e1edl28              "seg num
              ' '.                    "seg field
          CONTINUE.

        ELSE.
          "EXPORT: Shipping Type
          gs_memory-vsart = gs_e1edl28-vsart.
        ENDIF.

*&-------------------------------E1EDL18-------------------------------*
      WHEN gc_e1edl18.
        CLEAR  gs_e1edl18.

        gs_e1edl18 = gs_idoc_data-sdata.


        IF gs_e1edl18-qualf = 'SEA'.
          "EXPORT: Seal Number
          gs_memory-zz_seal = gs_e1edl18-param.

        ELSEIF gs_e1edl18-qualf = 'SHT'.
          "EXPORT: Shipment Type
          gs_memory-zz_shtyp = gs_e1edl18-param.

          "If the ShipmentType is 'ZCPC' then skip SCAC error check
          "in segment E1ADRM1
          IF gs_e1edl18-param EQ 'ZCPC'.
            lv_skip_scac_check = 'X'.
          ENDIF.

        ENDIF.

*&-------------------------------E1ADRM1-------------------------------*
      WHEN gc_e1adrm1.
        IF lv_skip_scac_check EQ 'X'.
          CLEAR lv_skip_scac_check.
          CONTINUE.
        ENDIF.

        CLEAR  gs_e1adrm1.

        gs_e1adrm1 = gs_idoc_data-sdata.

        IF gs_e1adrm1-partner_q EQ 'SP' AND
           gs_e1adrm1-partner_id IS INITIAL.

          "Validation:No SCAC on ASN
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZDL'                   "message class
              '021'                   "err msg
              ' '                     "msgv1
              ' '                     "msgv2
              ' '                     "msgv3
              ' '                     "msgv4
              'PROCESS_IDOC'          "routid
              gc_e1adrm1              "seg num
              ' '.                    "seg field
          CONTINUE.

        ELSEIF gs_e1adrm1-partner_q EQ 'SP'.
          "EXPORT: SCAC
          gs_memory-zz_scac = gs_e1adrm1-partner_id.

        ENDIF.

    ENDCASE.

  ENDLOOP.

  "If no E1EDL24 segments exist then generate an error
  IF lv_24count < 1.

    "Validation:Vendor ASN missing lines
    PERFORM sub_idoc_status_fill USING
        c_idoc_status_error     "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZDL'                   "message class
        '003'                   "err msg
        ' '                     "msgv1
        ' '                     "msgv2
        ' '                     "msgv3
        ' '                     "msgv4
        'PROCESS_IDOC'          "routid
        gc_e1edl24              "seg num
        ' '.                    "seg field
    RETURN.
  ENDIF.


  IF gs_memory-zz_shtyp EQ 'ZINP' AND gs_memory-zz_seal IS INITIAL.
    DATA(lv_messsage) = |'Seal'|.

    "Validation:Missing On ASN: 'Seal'
    PERFORM sub_idoc_status_fill USING
            c_idoc_status_error     "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZDL'                   "message class
            '025'                   "err msg
            lv_messsage             "msgv1
            ' '                     "msgv2
            ' '                     "msgv3
            ' '                     "msgv4
            'PROCESS_IDOC'          "routid
            gc_e1edl18              "seg num
            ' '.                    "seg field
    RETURN.

  ENDIF.

  "Append the last record in the internal table
  CHECK gv_idoc_error = gc_false.

  APPEND gt_mbhp_tab.
  CLEAR  gt_mbhp_tab.

  gt_bat_char-chars[] = gt_mbpsv_chars[].
  APPEND gt_bat_char.
  CLEAR  gt_bat_char.

  REFRESH gt_mbpsv_chars.

  APPEND gt_po_details.
  CLEAR  gt_po_details.


  CHECK gv_idoc_error = gc_false.

  "Check if PO exists/ is locked
  PERFORM validate_po.

  CHECK gv_idoc_error = gc_false.    "PO exist.
  CLEAR lv_24count.

  "Second loop - update HU details
  DATA lv_37tabix TYPE i.
  DATA lv_e1edl37_exidv TYPE exidv.

  LOOP AT gt_idoc_data
         INTO gs_idoc_data
         WHERE   docnum  =  gs_idoc_ctrl-docnum
           AND ( segnam  =  gc_e1edl37 OR
                 segnam  =  gc_e1edl44 ).

    gv_tabix      =  sy-tabix.

    CASE gs_idoc_data-segnam.

*&-------------------------------E1EDL37-------------------------------*
      WHEN gc_e1edl37.

        gs_e1edl37            = gs_idoc_data-sdata.
        gs_hu_xref-orig_exidv = gs_e1edl37-exidv. "Original HU
        lv_37tabix            =  gv_tabix.        "store E1EDL37 index

        lv_e1edl37_exidv = gs_e1edl37-exidv.

*&-------------------------------E1EDL44-------------------------------*
      WHEN gc_e1edl44.

        CLEAR  gs_e1edl44.
        gs_e1edl44 = gs_idoc_data-sdata.

        IF gs_e1edl44-charg IS INITIAL.
          "Validation:Batch & not in HU
          PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error     "status 51
                  gs_idoc_ctrl-docnum     "idoc number
                  c_error                 "status msg type
                  'ZDL'                   "message class
                  '028'                   "err msg
                  ' '                     "msgv1
                  ' '                     "msgv2
                  ' '                     "msgv3
                  ' '                     "msgv4
                  'PROCESS_IDOC'          "routid
                  gc_e1edl44              "seg num
                  ' '.                    "seg field
          CONTINUE.
        ENDIF.


        "Associate batches with HUs
        READ TABLE gt_mbhp_tab WITH KEY charg = gs_e1edl44-charg.
        IF sy-subrc EQ 0.
          gt_mbhp_tab-exidv   = lv_e1edl37_exidv.  "HU
          gt_mbhp_tab-37tabix = lv_37tabix.  "store L37 tabix
          gt_mbhp_tab-44tabix  = gv_tabix.

          MODIFY gt_mbhp_tab
             INDEX sy-tabix
             TRANSPORTING exidv 37tabix 44tabix.

        ENDIF.

        "Get batches from E1EDL24 segment
        lv_matnr = VALUE #( lt_batches[ charg = gs_e1edl44-charg
                                            ]-matnr OPTIONAL ).
        IF lv_matnr IS NOT INITIAL.
          gs_e1edl44-matnr = lv_matnr.
        ENDIF.

*         Store the Xref between HU and Vendor Batch. This will be used
*         later to help assign the PACKAGE_NUMBER characteristic when
*         generating new Batches in a Bundled Roll scenario. Example of
*         data would look something like this:
*         Original HU          Vendor Batch
*         -----------          ------------
*         BT1                  BT1
*         BT1                  BT2
*         BT3                  BT3
*         BT3                  BT4
*         BT3                  BT5
*
*         Batches BT1 & BT2 are bundled within HU BT1
*         Batches BT3, BT4, BT5 are bundled within HU BT3
        gs_hu_xref-kdmat      = gt_bat_char-vendrbatch.  "Vendor Batch
        APPEND gs_hu_xref TO gt_hu_xref.


        CLEAR  gv_tabix.
    ENDCASE.
  ENDLOOP.

  CHECK gv_idoc_error = gc_false.

  "Export Shipment level information, used by delivery creation
  "Common info for multiple deliveries
  EXPORT gs_memory = gs_memory TO MEMORY ID 'ZDL_SYVASN'.


  "Get PO related info (PO Item, plant, Storgae Location, etc.)
  "Update table GT_PO_DETAILS
  PERFORM get_po_item_details.
  CHECK gv_idoc_error = gc_false.

  "Get PO or Material related characteristic info
  "Update tables GT_PO_DETAILS, GT_MBHP_TAB
  PERFORM get_characteristics.
  CHECK gv_idoc_error = gc_false.

  "Check validity for material, storage location
  "from table GT_MBHP_TAB
  PERFORM validate_data.
  CHECK gv_idoc_error = gc_false.

  "Consolidate Batch Characteristics
  "Update tables GT_MBPSV & GT_MBH
  PERFORM consolidate_batch_char.
  CHECK gv_idoc_error = gc_false.

  "Creates Batches (BATMAS03 IDoc); uses table GT_MBPSV
  PERFORM create_batches.
  CHECK gv_idoc_error = gc_false.

  "Modify GT_IDOC_DATA & build HU tables GT_L37 & GT_L44
  "Update table GT_HU, used later for HU assignment
  PERFORM build_hu_tables.
  CHECK gv_idoc_error = gc_false.

  "Create Handling Units using table GT_L37 & GT_L44
  PERFORM create_hu.

  "Delete HU Segments E1EDL37 and E1EDL44 because we don't need this
  "for Inbound delivery creation by the FM '/SPE/IDOC_INPUT_DESADV1'
  "It might fail with these segments due to the core mod made on Domain EXIDV
  "Also delete E1EDL18 segments for certain qualifiers
  DELETE gt_idoc_data WHERE segnam =  gc_e1edl37 OR
                            segnam =  gc_e1edl44.

  PERFORM remove_e1edl18_segment.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  validate_po
*&---------------------------------------------------------------------*
* Check the existence of PO in SAP and get corresponding material
*----------------------------------------------------------------------*
FORM validate_po .

  DATA: BEGIN OF lt_po OCCURS 0,
          ebeln LIKE  ekpo-ebeln,
          ebelp LIKE  ekpo-ebelp,
        END OF lt_po.

  DATA: lv_subrc LIKE sy-subrc.

  CLEAR:  lt_po, lt_po[].

  DATA ls_zdl_fields TYPE zdl_fields.

  CLEAR : gv_do_loop, gv_wait_sec.

  READ TABLE gt_zdl_fields
        INTO ls_zdl_fields
    WITH KEY fieldname = 'WAIT_SECONDS'.
  IF sy-subrc = 0.
*   Set global variable
    gv_wait_sec = ls_zdl_fields-lowval.
  ENDIF.

  READ TABLE gt_zdl_fields
        INTO ls_zdl_fields
    WITH KEY fieldname = 'WAIT_LOOPS'.
  IF sy-subrc = 0.
*   Set global variable
    gv_do_loop = ls_zdl_fields-lowval.
  ENDIF.

  IF NOT gt_po_details[] IS INITIAL.
* Select all PO details from EKPO table for the given PO
* ensuring whether it does exist in SAP
    SELECT ebeln
          INTO CORRESPONDING FIELDS OF TABLE lt_po
          FROM ekko
          FOR ALL ENTRIES IN gt_po_details
          WHERE ebeln = gt_po_details-ebeln.
  ENDIF.

  SORT gt_po_details BY ebeln.
  SORT lt_po       BY ebeln.

  gv_fail  = gc_false.    "Initialize to sucess status
  REFRESH: gt_locked_pos.
  CLEAR: gt_locked_pos.

  LOOP AT gt_po_details.
    READ TABLE lt_po WITH KEY
                      ebeln = gt_po_details-ebeln
                      BINARY SEARCH.
    IF sy-subrc = 0.
      gv_idoc_error = gc_false.
* Lock PO
      READ TABLE gt_locked_pos WITH KEY
                 ebeln = gt_po_details-ebeln.
      IF sy-subrc = 0.
        "Validation:PO is locked by other processes/user & &
        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error     "status 51
                gs_idoc_ctrl-docnum     "idoc number
                c_error                 "status msg type
                'ZDL'                   "message class
                '004'                   "err msg
                gt_po_details-ebeln       "msgv1
                gt_po_details-ebelp       "msgv2
                ' '                     "msgv3
                ' '                     "msgv4
                'VALIDATE_PO'           "routid
                gc_e1edl41              "seg num
                ' '.                    "seg field
        gv_fail  = gc_true.
        EXIT.
      ELSE.
        PERFORM lock_po CHANGING lv_subrc.

        IF lv_subrc <> 0.
          gt_locked_pos-ebeln = gt_po_details-ebeln.
          APPEND gt_locked_pos.

          "Validation:PO is locked by other processes/user & &
          PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error     "status 51
                  gs_idoc_ctrl-docnum     "idoc number
                  c_error                 "status msg type
                  'ZDL'                   "message class
                  '004'                   "err msg
                  gt_po_details-ebeln       "msgv1
                  gt_po_details-ebelp       "msgv2
                  ' '                     "msgv3
                  ' '                     "msgv4
                  'VALIDATE_PO'           "routid
                  gc_e1edl41              "seg num
                  ' '.                    "seg field
          gv_fail  = gc_true.
          EXIT.
        ENDIF.

      ENDIF.
    ELSE.
      "Validation:PO does not exist in SAP for the given PO: & &
      PERFORM sub_idoc_status_fill USING
      c_idoc_status_error         "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZDL'                   "message class
          '005'                   "err msg
          gt_po_details-ebeln       "msgv1
          gt_po_details-ebelp       "msgv2
          ' '                     "msgv3
          ' '                     "msgv4
          'VALIDATE_PO'           "routid
          gc_e1edl41              "seg num
          ' '.                    "seg field

    ENDIF.
    IF gv_idoc_error = gc_true.  "At any point of time failed?
      gv_fail  = gc_true.
    ENDIF.
  ENDLOOP.
  IF gv_fail = gc_true.
    gv_idoc_error = gc_true.
  ELSE.
    gv_idoc_error = gc_false.
  ENDIF.

ENDFORM.                    " validate_po

*&---------------------------------------------------------------------*
*&      Form  LOCK_PO
*&---------------------------------------------------------------------*
FORM lock_po  CHANGING p_subrc.

  p_subrc = 4.

  DO gv_do_loop TIMES.
    CALL FUNCTION 'ENQUEUE_EMEKKOE'
      EXPORTING
        mode_ekko      = 'E'
        mode_ekpo      = 'E'
        mandt          = sy-mandt
        ebeln          = gt_po_details-ebeln
        ebelp          = gt_po_details-ebelp
*       X_EBELN        = ' '
*       X_EBELP        = ' '
*       _SCOPE         = '2'
*       _WAIT          = ' '
*       _COLLECT       = ' '
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.

    IF sy-subrc = 0.
      p_subrc = sy-subrc.
      CALL FUNCTION 'DEQUEUE_EMEKKOE'
        EXPORTING
          mode_ekko = 'E'
          mode_ekpo = 'E'
          mandt     = sy-mandt
          ebeln     = gt_po_details-ebeln
          ebelp     = gt_po_details-ebelp
          _scope    = '3'.
      EXIT.
    ELSE.
      WAIT UP TO gv_wait_sec SECONDS.
    ENDIF.
  ENDDO.


ENDFORM.                    " LOCK_PO

*&---------------------------------------------------------------------*
*&      Form  GET_ZDL_FIELDS1
*&---------------------------------------------------------------------*
FORM get_zdl_fields1 CHANGING pv_weight TYPE lfimg
                              pv_truck TYPE days
                              pv_rail TYPE days.

  CLEAR:pv_weight,pv_truck,pv_rail.

  READ TABLE gt_zdl_fields INTO DATA(lw_zdl_fields)
                           WITH KEY fieldname = 'WEIGHT'.

  IF sy-subrc = 0.
    pv_weight = lw_zdl_fields-lowval.
  ENDIF.

  CLEAR lw_zdl_fields.
  READ TABLE gt_zdl_fields INTO lw_zdl_fields
                           WITH KEY fieldname = 'TRUCK'.

  IF sy-subrc = 0.
    pv_truck = lw_zdl_fields-lowval.
  ENDIF.

  CLEAR lw_zdl_fields.
  READ TABLE gt_zdl_fields INTO lw_zdl_fields
                           WITH KEY fieldname = 'RAIL'.

  IF sy-subrc = 0.
    pv_rail = lw_zdl_fields-lowval.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPDATE_WEIGHT_E1EDL24
*&---------------------------------------------------------------------*

FORM update_weight_e1edl24 USING cs_e1edl24 TYPE e1edl24
                                 cv_flag TYPE char1.

  CLEAR cv_flag.

  SELECT SINGLE mtart INTO @DATA(lv_mtart) FROM mara
    WHERE matnr = @cs_e1edl24-matnr.

  DATA(lv_lowval) = VALUE #( gt_zdl_fields[ fieldname = 'MTART'
                                            lowval    = lv_mtart ]
                                            OPTIONAL ).
  IF lv_lowval IS NOT INITIAL.
    IF gs_e1edl24-ntgew IS INITIAL.
      gs_e1edl24-ntgew = gs_e1edl24-lfimg.
    ENDIF.

    IF gs_e1edl24-brgew IS INITIAL.
      gs_e1edl24-brgew = gs_e1edl24-lfimg.
    ENDIF.

    IF gs_e1edl24-lgmng IS INITIAL.
      gs_e1edl24-lgmng = gs_e1edl24-lfimg.
    ENDIF.

    cv_flag = 'Y'.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  get_po_item_details
*&---------------------------------------------------------------------*
FORM get_po_item_details.

  CHECK gt_mbhp_tab[] IS NOT INITIAL.

  DATA lv_ebeln  TYPE ebeln.

  CONSTANTS:
    lc_matkl_dpr LIKE ekpo-matkl VALUE 'DPR',
    lc_matkl_xdp LIKE ekpo-matkl VALUE 'XDP'.

  "Check whether the material number exists in MARA table. Retrieve info
  "for each PO line item material (multiple PO's may exist)
  CLEAR:  gt_po_details, gt_po_details[].
  SELECT ep~matnr
         m~cuobf
         m~xchpf
         m~mtart
         ep~ebeln
         ep~ebelp
         ep~werks
         ep~lgort
         ep~matkl
         ep~knttp   "Account Assignment Indicator
         ep~cuobj   "Config object for PO Item Char
         ep~meins
         zp~omd_ind "Plant OMD Indicator
        INTO CORRESPONDING FIELDS OF TABLE gt_po_details
        FROM mara AS m INNER JOIN ekpo AS ep
            ON ep~matnr  =  m~matnr
        INNER JOIN zplant AS zp
            ON zp~werks    = ep~werks
        FOR ALL ENTRIES IN gt_mbhp_tab
        WHERE ep~ebeln = gt_mbhp_tab-ebeln
          AND ep~loekz = space. "make sure not locked

  "Remove any entries if the Plant is OMD and the Account Assignment
  "Indicator is 'L' (Non-Valuated PO Item)
  IF sy-subrc = 0.
    DELETE gt_po_details WHERE omd_ind = 'Y'  "plant is OMD
                         AND knttp   = 'L'. "non valuated PO item
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  get_characteristics
*&---------------------------------------------------------------------*
FORM get_characteristics.

  DATA lv_cuobj LIKE inob-cuobj.

  "Determine each PO Item Material's Roll Width and store in a work table
  LOOP AT gt_po_details.

    gv_tabix = sy-tabix.

    CLEAR: gt_conf_out[], gs_conf_out.

    "Reading the characteristics from Batch is only an interim process
    READ TABLE gt_zdl_fields INTO DATA(ls_matkl) WITH KEY
                             fieldname = 'MATKL'
                             lowval = gt_po_details-matkl.
    IF sy-subrc = 0.
      lv_cuobj = gt_po_details-cuobj.
    ELSE.
      lv_cuobj = gt_po_details-cuobf.
    ENDIF.

    "Check the Material Type if found use cuobj = ekpo-cuobj
    READ TABLE gt_zdl_fields TRANSPORTING NO FIELDS WITH KEY
                             fieldname = 'MTART'
                             lowval = gt_po_details-mtart.
    IF sy-subrc EQ 0.
      "MTO: Get characteristics From PO
      lv_cuobj = gt_po_details-cuobj.
    ELSE.
      "MTS: Get characteristics from Material Master
      lv_cuobj = gt_po_details-cuobf.
    ENDIF.


    "Retrieve SAP Characteristic Values
    CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
      EXPORTING
        instance           = lv_cuobj
        language           = sy-langu
      TABLES
        configuration      = gt_conf_out
      EXCEPTIONS
        instance_not_found = 1
        OTHERS             = 2.

    IF sy-subrc EQ 0.
      SORT gt_conf_out BY atnam atwrt.
      "Reformat the decimal value to implied decimal, leading 0 format
      "in gt_conf_out
      PERFORM reformat_char_value USING ls_matkl.

      MODIFY gt_po_details INDEX gv_tabix
        TRANSPORTING atwrt unit_code order_link.

    ENDIF.

  ENDLOOP.

  SORT gt_po_details BY ebeln atwrt.
  SORT gt_bat_char BY matnr vendrbatch.


  LOOP AT gt_mbhp_tab.

    gv_tabix = sy-tabix.

*   Get the correct Batch deep structure record based on material and
*   Batch. We need to include Batch on this READ because the same material
*   can be on multiple ASN line items and the Batch gets us the unique
*   match we need.  gt_bat_char was built from the E1EDL15 batch
*   characteristic segments for each ASN line item.
    READ TABLE gt_bat_char
      WITH KEY matnr      = gt_mbhp_tab-matnr
               vendrbatch = gt_mbhp_tab-charg
               BINARY SEARCH. "Batch
    IF sy-subrc NE 0.
      "Validation:Assoc Batch not found for Mat & Bat & in gt_bat_char
      PERFORM sub_idoc_status_fill USING
              c_idoc_status_error      "status 51
              gs_idoc_ctrl-docnum      "idoc number
              c_error                  "status msg type
              'ZDL'                    "message class
              '010'                    "err msg
              gt_mbhp_tab-matnr        "msgv1
              gt_mbhp_tab-charg        "msgv2
              ' '                      "msgv3
              ' '                      "msgv4
              'GET_CHARACTERISTICS'    "routid
              ' '                      "seg num
              ' '.                     "seg field
      gv_idoc_error = gc_true.
      RETURN.

    ELSE.

      "Move the table portion of the deep structure (containing
      "characteristic name and characteristic value) to a work table.
      gt_mbpsv_chars[] = gt_bat_char-chars[].
      SORT gt_mbpsv_chars BY atnam.

      DATA(gs_temp_mat) = VALUE #( gt_po_details[ ebeln = gt_mbhp_tab-ebeln
                                   ebelp = gt_mbhp_tab-ebelp ] OPTIONAL ).
*                                   matnr = gt_mbhp_tab-matnr ] OPTIONAL ).
      IF gs_temp_mat-unit_code IS INITIAL.
        "Validation:Missing Unit Code for &, &
        PERFORM sub_idoc_status_fill USING
                          c_idoc_status_error      "status 51
                          gs_idoc_ctrl-docnum      "idoc number
                          c_error                  "status msg type
                          'ZDL'                    "message class
                          '008'                    "err msg
                          gt_mbhp_tab-ebeln        "msgv1
                          gt_mbhp_tab-matnr        "msgv2
                          ' '                      "msgv3
                          ' '                      "msgv4
                          'GET_CHARACTERISTICS'    "routid
                          ' '                      "seg num
                          ' '.                     "seg field
        RETURN.

      ELSEIF gs_temp_mat-unit_code EQ 'R'.
        "Check if the IDoc has ROLL_WIDTH characteristic
        DATA(ls_mbpsv_chars) = VALUE #( gt_mbpsv_chars[
                                   atnam = zsdc_roll_width ] OPTIONAL ).
        IF ls_mbpsv_chars IS INITIAL.

          "Validation:ROLL_WIDTH characteristic does not exist for Material &, Batch &
          PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error      "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZDL'                    "message class
                  '009'                    "err msg
                  gt_mbhp_tab-matnr        "msgv1
                  gt_mbhp_tab-charg        "msgv2
                  ' '                      "msgv3
                  ' '                      "msgv4
                  'GET_CHARACTERISTICS'    "routid
                  ' '                      "seg num
                  ' '.                     "seg field

          RETURN.

        ELSE.

          "Update main work table with SAP Material, PO line item, PO Plant
          "and PO storage location
          gt_mbhp_tab-nmatnr       = gs_temp_mat-matnr.
          gt_mbhp_tab-ebelp        = gs_temp_mat-ebelp.
          gt_mbhp_tab-werks        = gs_temp_mat-werks.
          gt_mbhp_tab-lgort        = gs_temp_mat-lgort.
          MODIFY gt_mbhp_tab INDEX gv_tabix
                TRANSPORTING nmatnr ebelp werks lgort.

        ENDIF.

      ELSEIF gs_temp_mat-unit_code EQ 'C' OR
             gs_temp_mat-unit_code EQ 'D' OR
             gs_temp_mat-unit_code EQ 'S'.

        "Update main work table with SAP Material, PO line item, PO Plant
        "and PO storage location
        gt_mbhp_tab-nmatnr       = gs_temp_mat-matnr.
        gt_mbhp_tab-ebelp        = gs_temp_mat-ebelp.
        gt_mbhp_tab-werks        = gs_temp_mat-werks.
        gt_mbhp_tab-lgort        = gs_temp_mat-lgort.
        MODIFY gt_mbhp_tab INDEX gv_tabix
              TRANSPORTING nmatnr ebelp werks lgort.

      ENDIF.

    ENDIF.

  ENDLOOP.

ENDFORM.      "get_characteristics

*&---------------------------------------------------------------------*
*&      Form  REFORMAT_CHAR_VALUE
*&---------------------------------------------------------------------*
* Reformat batch characteistics values into char value
*----------------------------------------------------------------------*
FORM reformat_char_value USING ls_matkl TYPE zdl_fields.

  DATA:
    lv_index   TYPE sytabix,
    lv_atwrt1  LIKE conf_out-atwrt,
    lv_rolldia TYPE cawn-atwrt,
    lv_rollwid TYPE cawn-atwrt.


  CLEAR: gs_conf_out,lv_rolldia,lv_rollwid.
  READ TABLE gt_conf_out INTO gs_conf_out WITH KEY
             atnam = zsdc_unit_code BINARY SEARCH.
  IF sy-subrc = 0.
    gt_po_details-unit_code = gs_conf_out-atwrt.
    IF gs_conf_out-atwrt = 'R'.   "Roll
      CLEAR gs_conf_out.
      IF gt_po_details-matkl = ls_matkl-lowval.
        READ TABLE gt_conf_out INTO gs_conf_out WITH KEY
                   atnam = zsdc_roll_width_whole
                   BINARY SEARCH.
        IF sy-subrc = 0.
          PERFORM format_value CHANGING gs_conf_out-atwrt.
          MODIFY gt_conf_out FROM gs_conf_out
                 TRANSPORTING atwrt
                 WHERE atnam = zsdc_roll_width.
        ENDIF.
      ELSE.

        CLEAR:lv_rolldia, lv_rollwid.
        READ TABLE gt_conf_out INTO gs_conf_out WITH KEY
                   atnam = zsdc_roll_diameter BINARY SEARCH.
        IF sy-subrc = 0.
*          SPLIT gs_conf_out-atwrt AT ' ' INTO lv_rolldia.
          SPLIT gs_conf_out-atwrt AT ' ' INTO lv_rolldia lv_rollwid.
          gt_po_details-rolldia = lv_rolldia.
        ENDIF.

        READ TABLE gt_conf_out INTO gs_conf_out WITH KEY
                   atnam = zsdc_roll_width BINARY SEARCH.
        IF sy-subrc = 0.
          CLEAR:lv_rolldia, lv_rollwid.
          SPLIT gs_conf_out-atwrt AT ' ' INTO lv_rollwid  lv_rolldia.
          gt_po_details-rollwid = lv_rollwid.
          PERFORM format_value CHANGING gs_conf_out-atwrt.
          MODIFY gt_conf_out FROM gs_conf_out
                 TRANSPORTING atwrt
                 WHERE atnam = zsdc_roll_width.

          gt_po_details-atwrt = gs_conf_out-atwrt.
          MODIFY gt_po_details FROM gt_po_details
                TRANSPORTING atwrt rolldia rollwid.
*                 WHERE atnam = zsdc_roll_width.

        ENDIF.


        LOOP AT gt_zdl_fields INTO DATA(ls_3ps) WHERE fieldname = '3PS' .

          IF ls_3ps-lowval EQ gt_po_details-werks AND
             ls_3ps-highval EQ gt_po_details-meins.

            READ TABLE gt_conf_out INTO gs_conf_out WITH KEY
             atnam = zsdc_roll_width_metric BINARY SEARCH.
            IF sy-subrc = 0.
              gt_po_details-atwrt1 = gs_conf_out-atwrt.
              PERFORM format_value CHANGING gt_po_details-atwrt1.
              MODIFY gt_po_details FROM gt_po_details
              TRANSPORTING atwrt1.
              EXIT.
            ENDIF.
          ENDIF.
        ENDLOOP.

      ENDIF.
    ELSEIF gs_conf_out-atwrt = 'C' OR
           gs_conf_out-atwrt = 'D' OR
           gs_conf_out-atwrt = 'S'.

      "???? - Do What
    ENDIF.
  ELSE.
    "???? -  Do What

  ENDIF.

ENDFORM.                    " reformat_char_value
*&---------------------------------------------------------------------*
*&      Form  FORMAT_NUM_VALUE
*&---------------------------------------------------------------------*
* Convert the ROLL_WIDTH characteristics in the IDoc into SAP std.
* format i.e., 3.5 char format
*----------------------------------------------------------------------*
*      -->uv_atnam  characteristics name
*      <->cv_atwrt  characteristics value
*----------------------------------------------------------------------*
FORM format_num_value     USING    uv_atnam
                          CHANGING cv_atwrt.

  DATA:
    lv_anzst  TYPE i,
    lv_anzdz  TYPE i,
    lv_atwrt1 TYPE atwrt,
    lv_atwrt2 TYPE atwrt.

  SELECT anzst  anzdz
         INTO (lv_anzst,  lv_anzdz)
         FROM cabn
         UP TO 1 ROWS
         WHERE atnam = uv_atnam.
  ENDSELECT.

  "Remove unit of measure if exists ( ie 4.00 IN )
  SPLIT cv_atwrt AT ' ' INTO lv_atwrt1 lv_atwrt2.

  CLEAR lv_atwrt2.

  "Remove all commas from numeric values being fed back in since
  "this will cause an error.
  REPLACE ALL OCCURRENCES OF ',' IN
    lv_atwrt1 WITH space.
  CONDENSE lv_atwrt1 NO-GAPS.


  "Split integer and decimal part
  SPLIT lv_atwrt1 AT '.' INTO lv_atwrt1 lv_atwrt2.

  "Fill up trailing zeros if it is less than ANZDZ (no. of decimal char)
  "in the decimal part. 0's need to be added to the END of the decimal
  "portion.
  WHILE strlen( lv_atwrt2 ) LT lv_anzdz.
    CONCATENATE lv_atwrt2 '0' INTO lv_atwrt2.
  ENDWHILE.

  "Find only integer part
  lv_anzst = lv_anzst - lv_anzdz.

  "Fill up leading zeros in the integer part if it is less than ANZST
  "(No. of characters)
  WHILE strlen( lv_atwrt1 ) LT lv_anzst.
    CONCATENATE '0' lv_atwrt1 INTO lv_atwrt1.
  ENDWHILE.

  IF NOT lv_anzst IS INITIAL.
    "Fix the numeric format by concatenating integer and decimal part
    CONCATENATE lv_atwrt1 lv_atwrt2 INTO cv_atwrt SEPARATED BY '.'.
  ELSE.
    "Just fill the integer part
    cv_atwrt = lv_atwrt1.
  ENDIF.

  CONDENSE cv_atwrt NO-GAPS.
ENDFORM.                    " format_num_value
*&---------------------------------------------------------------------*
*&      Form  FORMAT_VALUE
*&---------------------------------------------------------------------*
*      <-> cv_ATWRT  characteristic value
*----------------------------------------------------------------------*
FORM format_value  CHANGING cv_atwrt LIKE conf_out-atwrt.

  DATA: lv_atwrt1 TYPE atwrt,
        lv_atwrt2 TYPE atwrt,
        lv_atwrt3 TYPE atwrt.

  CLEAR:  lv_atwrt1,  lv_atwrt2.

  "Remove unit of measure if exists ( ie 4.00 IN )
  SPLIT cv_atwrt AT ' ' INTO lv_atwrt1 lv_atwrt2.

  "Remove commas if exist
  IF lv_atwrt1 CA ','.
    CLEAR: lv_atwrt2, lv_atwrt3.
    SPLIT lv_atwrt1 AT ',' INTO lv_atwrt2 lv_atwrt3.
    CLEAR lv_atwrt1.
    CONCATENATE lv_atwrt2 lv_atwrt3 INTO lv_atwrt1.
  ENDIF.

  "Remove decimal point
  IF lv_atwrt1 CA '.'.
    CLEAR: lv_atwrt2, lv_atwrt3.
    SPLIT lv_atwrt1 AT '.' INTO lv_atwrt2 lv_atwrt3.

    CLEAR lv_atwrt1.
    WHILE strlen( lv_atwrt3 ) LT 5.
      CONCATENATE lv_atwrt3 '0' INTO lv_atwrt3.
    ENDWHILE.

    CONCATENATE lv_atwrt2 lv_atwrt3 INTO lv_atwrt1.
  ENDIF.

  "Right justify value and pad left with 0's
  "if gs_conf_out-atnam = 'ROLL_WIDTH'.
  WHILE strlen( lv_atwrt1 ) LT 8.
    CONCATENATE '0' lv_atwrt1 INTO lv_atwrt1.
  ENDWHILE.

  cv_atwrt = lv_atwrt1.

ENDFORM.                    " format_value

*&---------------------------------------------------------------------*
*&      Form  validate_data
*&---------------------------------------------------------------------*
FORM validate_data .

* Internal table to store Portal ASN info
  DATA: int_asn TYPE STANDARD TABLE OF zdl_asninfo INITIAL SIZE 0
                                                 WITH HEADER LINE.

  DATA  lv_flag TYPE flag.                " Local flag

  DATA: lv_ebeln TYPE ebeln,
        lv_lgort TYPE lgort_d.

  gv_fail = gc_false.

  LOOP AT gt_mbhp_tab.
    DATA(gs_mbhp_tab) = gt_mbhp_tab.

    AT NEW matnr.

      IF gs_mbhp_tab-nmatnr IS INITIAL.
        "If no corresponding SAP Material was derived then update error log
        "sap_material_not_determined for the given PO line item
        "Validation:No SAP material for the PO line item: & &
        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error     "status 51
                gs_idoc_ctrl-docnum     "idoc number
                c_error                 "status msg type
                'ZDL'                  "message class
                '012'                   "err msg
                gs_mbhp_tab-ebeln       "msgv1
                gs_mbhp_tab-ebelp       "msgv2
                ' '                     "msgv3
                ' '                     "msgv4
                'VALIDATE_DATA'         "routid
                gc_e1edl24              "seg num
                ' '.                    "seg field

        RETURN.
      ENDIF.


      SORT gt_po_details BY matnr.
      READ TABLE gt_po_details
           WITH KEY matnr = gs_mbhp_tab-nmatnr
           BINARY SEARCH.
      IF sy-subrc = 0.
*        Check for Storage location in PO, if the PO does not have
*        Stor.Locaion don't create inbound idoc, since storage location
*        is mandatory for packaging.
        IF gt_po_details-lgort IS INITIAL.
          "Validation:Storage Location does not exist on Purchase Order & &
          PERFORM sub_idoc_status_fill USING
                  c_idoc_status_error      "status 51
                  gs_idoc_ctrl-docnum      "idoc number
                  c_error                  "status msg type
                  'ZDL'                    "message class
                  '013'                    "err msg
                  gs_mbhp_tab-ebeln        "msgv1
                  gs_mbhp_tab-ebelp        "msgv2
                  ' '                      "msgv3
                  ' '                      "msgv4
                  'VALIDATE_DATA'          "routid
                  gc_e1edl41               "seg num
                  ' '.                     "seg field
*
          RETURN.

        ENDIF.
      ENDIF.

      IF gv_idoc_error = gc_true.
        gv_fail  = gc_true.
      ENDIF.

    ENDAT.
  ENDLOOP.


*  CHECK gv_idoc_error = gc_false.
*
*  CLEAR int_asn.
*  REFRESH int_asn.
*
*  "Validate duplicate bill of lading against delivery, PO, Material and
*  "Vendor id.
*  LOOP AT gt_mbhp_tab.
*    int_asn-vgbel = gt_mbhp_tab-ebeln.
*    int_asn-bolnr = gs_e1edl20-bolnr.
**    int_asn-matnr = gt_mbhp_tab-matnr.
*    int_asn-matnr = gt_mbhp_tab-nmatnr.  "SAP Material
*    int_asn-inhalt = gt_mbhp_tab-charg.
*    APPEND int_asn.
*  ENDLOOP.
*
*  "Call Funtion Module 'Z_SD_DL_I2301_CHECK_DUPLI_ASN' to check duplicate
*  "delivery numbers against bill of lading, purchase order and unit id
*  CLEAR lv_flag.
*  IF int_asn[] IS INITIAL.
*    RETURN.
*  ENDIF.
*
*  CALL FUNCTION 'Z_SD_DL_I2301_CHECK_DUPLI_ASN'
*    IMPORTING
*      ex_flag               = lv_flag
*    TABLES
*      it_asninfo            = int_asn
*    EXCEPTIONS
*      wrong_function_called = 1
*      OTHERS                = 2.
*  IF sy-subrc = 0 AND lv_flag = gc_true.
*    LOOP AT int_asn.
*      IF int_asn-flag = gc_true.
*        "For all ZDL_SYVASN idocs, if this is a duplicate ASN then archive
*        "the idoc (status 68) instead of setting it to a 51.
*
*        "Update Error log, the idoc should not be processed if BOL already exist.
*        SHIFT int_asn-vgbel LEFT DELETING LEADING '0'.
*
*        "Validation:& exists for BOL & Vendor Batch & PO &
*        PERFORM sub_idoc_status_fill USING
*                c_idoc_status_delete              "status 68
*                gs_idoc_ctrl-docnum               "idoc number
*                c_info                            "status msg type
*                'ZDL'                             "message class
*                '014'                             "err msg
*                int_asn-vbeln                     "msgv1
*                int_asn-bolnr                     "msgv2
*                int_asn-inhalt                    "msgv3
*                int_asn-vgbel                     "msgv4
*                'VALIDATE_DATA'                   "routid
*                ' '                               "seg num
*                ' '.                              "seg field
*
*
*        gv_idoc_error = gc_true.
*        RETURN.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.


ENDFORM.              "VALIDATE_DATA
*&---------------------------------------------------------------------*
*&      Form  consolidate_batch_char
*&---------------------------------------------------------------------*
FORM consolidate_batch_char.

  DATA lv_tabix  LIKE  syst-tabix.

  CLEAR: gt_mbh, gt_mbh[].

  IF NOT gt_mbhp_tab[] IS INITIAL.

    LOOP AT gt_mbhp_tab.

      gt_mbh-matnr = gt_mbhp_tab-nmatnr. "SAP Material number
      gt_mbh-exidv = gt_mbhp_tab-charg.  "Vend Batch
      gt_mbh-bolnr = gs_e1edl20-bolnr.
      gt_mbh-vgbel = gt_mbhp_tab-ebeln.
      gt_mbh-old_batch_no = gt_mbhp_tab-charg.
      gt_mbh-batch_num = gt_mbhp_tab-charg.

      APPEND: gt_mbh.
      CLEAR:  gt_mbh.
    ENDLOOP.
  ENDIF.

  IF NOT gt_mbh[] IS INITIAL.

    gv_idoc_error = gc_false.

    SORT gt_mbh      BY matnr  exidv.
    SORT gt_mbhp_tab BY nmatnr exidv.
    SORT gt_bat_char BY matnr  vendrbatch.
    CLEAR:  gt_mbpsv, gt_mbpsv[].

    LOOP AT gt_mbhp_tab.
      lv_tabix = sy-tabix.

      READ TABLE gt_mbh WITH KEY
                  matnr    = gt_mbhp_tab-nmatnr  "SAP Material
                  exidv    = gt_mbhp_tab-charg   "Vendor Batch
                  BINARY SEARCH.
      IF sy-subrc = 0.

        "Determine if Material is Batch Managed
        SORT gt_po_details BY matnr.
        READ TABLE gt_po_details
             WITH KEY matnr = gt_mbhp_tab-nmatnr
             BINARY SEARCH.
        IF sy-subrc = 0.  "Batch managed material

          IF gt_mbh-old_batch_flag IS INITIAL.  "New unique-id created
*             Fetch Plant and Storage Location from GT_PO_DETAILS
            SORT gt_po_details BY ebeln ebelp.
            READ TABLE gt_po_details
                      WITH KEY ebeln = gt_mbhp_tab-ebeln
                               ebelp = gt_mbhp_tab-ebelp.
            IF sy-subrc = 0.

              gt_mbpsv-matnr       = gt_mbh-matnr.
              gt_mbpsv-charg       = gt_mbh-batch_num.
*               Plant and Str. Loc - take from PO line item
              gt_mbpsv-werks       = gt_po_details-werks.
              gt_mbpsv-lgort       = gt_po_details-lgort.

*               Set the Vendor Batch to GT_MBH-EXIDV as it will contain
*               the Vendor Batch in a BM scenario
              gt_mbpsv-vendrbatch  = gt_mbh-exidv.
            ENDIF.
            APPEND  gt_mbpsv.
            CLEAR   gt_mbpsv.
          ENDIF.  "Only for new batches

*           Modify gt_mbhp_tab & gt_bat_char with newly generated
*           matnr and unique batch id.
          gt_mbhp_tab-ncharg      = gt_mbh-batch_num.

*           Does it make sense to populate a New HU value from the new
*           Batch number in Batch Material mode? We may not be in a
*           Break Bulk scenario so this would be wrong in a Bundled
*           Roll scenario
*            gt_mbhp_tab-nexidv      = gt_mbh-batch_num.
          gt_mbhp_tab-nexidv      = space.
        ELSE.
*           Make sure charg field is empty
          CLEAR:  gt_mbhp_tab-charg, gt_mbhp_tab-ncharg.
*           For non-batch managed material, update only handling units
          gt_mbhp_tab-nexidv    = gt_mbh-batch_num.
        ENDIF.  "Endif Batch Managed

*         Modify gt_bat_char with new material and batch
        READ TABLE gt_bat_char WITH KEY
                            matnr      = gt_mbhp_tab-matnr
                            vendrbatch = gt_mbhp_tab-charg.
        IF sy-subrc = 0.
          gv_tabix = sy-tabix.
          gt_bat_char-matnr = gt_mbhp_tab-nmatnr.
*          gt_bat_char-charg = gt_mbhp_tab-ncharg.
          gt_bat_char-charg = gt_mbhp_tab-ncharg.

          MODIFY gt_bat_char
                      INDEX gv_tabix
                      TRANSPORTING matnr charg.
          CLEAR: gt_bat_char.
        ENDIF.

        MODIFY gt_mbhp_tab
                      INDEX lv_tabix
                      TRANSPORTING charg ncharg nexidv.
      ENDIF.  "gt_mbh entry check
    ENDLOOP.
  ENDIF.  "for all materials

  "Get rest of the batch characteristics from MARA table
  "Update table GT_BAT_CHAR
  CHECK gv_idoc_error = gc_false.

  PERFORM get_characteristics_material.

  "Update table GT_MBPSV with characteristics from GT_BAT_CHAR
  PERFORM update_table_gt_mbpsv.


  "Add aditional batch chars: roll width in meters,roll weight in KG's
  "and Package Number
  "Update table GT_MBPSV
*  PERFORM add_batch_chars. " CD 2000000569
*  PERFORM add_additional_batch_chars. " CD 2000000569

ENDFORM.                    " consolidate_batch_char
*&---------------------------------------------------------------------*
*&      Form  ADD_ADDITIONAL_BATCH_CHARS
*&---------------------------------------------------------------------*
*       New Logic to Assign PACKAGE_NUMBER will now work for a
*       Bundled Roll Scenario, as well as Break Bulk, for the Manual
*       ASN. EDI Logic has been changed in subroutine add_batch_chars so
*       I didn't want to chance breaking that code. This logic will only
*       be executed for Batch Managed materials.
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
* Commented the below code by ALANKAP on 2/28/2022 CD# 2000000569 ->03
*FORM add_additional_batch_chars .
*
*  DATA: wa_head       TYPE zfm_chars,
*        lv_roll_metr  TYPE zzroll_weight_metric,
*        lv_rollwidth  TYPE zzlinear_footage_metric,
*        lv_roll_feet  TYPE zzweight_of_roll_in_lbs,
*        lv_roll_width TYPE zzweight_of_roll_in_lbs.
*
*  CLEAR: gt_mbpsv,
*         gt_mbpsv-chars,
*         wa_head.
*
*  LOOP AT gt_mbpsv.
*    CLEAR wa_head.
*    LOOP AT gt_mbpsv-chars INTO wa_head.
*
*      CASE wa_head-atnam.
*
*        WHEN 'WEIGHT_OF_ROLL_IN_LBS'.
*          IF NOT wa_head-atwrt IS INITIAL.
*            CLEAR: lv_roll_width,
*                   lv_roll_metr.
*            lv_roll_width = wa_head-atwrt.
*            CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
*              EXPORTING
*                input                = lv_roll_width
*                kzmeinh              = ' '
*                matnr                = gt_mbpsv-matnr
*                meinh                = 'KG'
*                meins                = 'LB'
*              IMPORTING
*                output               = lv_roll_metr
*              EXCEPTIONS
*                conversion_not_found = 1
*                input_invalid        = 2
*                material_not_found   = 3
*                meinh_not_found      = 4
*                meins_missing        = 5
*                no_meinh             = 6
*                output_invalid       = 7
*                overflow             = 8
*                OTHERS               = 9.
*            IF sy-subrc = 0.
*              wa_head-atnam = 'ROLL_WEIGHT_METRIC'.
*              wa_head-atwrt = lv_roll_metr.
*              CONDENSE  wa_head-atwrt NO-GAPS.
*              APPEND wa_head TO gt_mbpsv-chars.
*
*              CLEAR wa_head.
*              wa_head-atnam = 'PACKAGE_NUMBER'.
*
*              "Retrieve Original HU by matching up the Vendor Batch
*              READ TABLE gt_hu_xref INTO gs_hu_xref
*                WITH KEY kdmat = gt_mbpsv-vendrbatch.
*              IF sy-subrc = 0.
**               Retrieve the newly-created SAP Batch Number (or the
**               value could be the original Vendor Batch if it had
**               passed all of the batch validations (ie 10 bytes, etc))
**               by matching the Original HU to the Vendor Batch in itab
**               gt_mbh (vendor batch is formatted into field
**               gt_mbh-exidv). Keep in mind that the Original HU MUST BE
**               identical to the lowest sorted Vendor Batch in a bundled
**               roll scenario.
*                READ TABLE gt_mbh
*                  WITH KEY exidv = gs_hu_xref-orig_exidv.
*                IF sy-subrc = 0.
*                  wa_head-atwrt = gt_mbh-batch_num.
*                  CONDENSE wa_head-atwrt NO-GAPS.
*                  APPEND wa_head TO gt_mbpsv-chars.
*                ENDIF.
*              ENDIF.
*
*            ENDIF.
*          ENDIF.
*        WHEN 'LINEAL_FOOTAGE'.
*          IF NOT wa_head-atwrt IS INITIAL.
*            CLEAR: lv_roll_feet,
*                   lv_rollwidth.
*            lv_roll_feet  = wa_head-atwrt.
*            CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*              EXPORTING
*                input                = lv_roll_feet
*                unit_in              = 'LF'
*                unit_out             = 'M'
*              IMPORTING
*                output               = lv_rollwidth
*              EXCEPTIONS
*                conversion_not_found = 1
*                division_by_zero     = 2
*                input_invalid        = 3
*                output_invalid       = 4
*                overflow             = 5
*                type_invalid         = 6
*                units_missing        = 7
*                unit_in_not_found    = 8
*                unit_out_not_found   = 9
*                OTHERS               = 10.
*            IF sy-subrc = 0.
*              wa_head-atnam = 'LINEAR_FOOTAGE_METRIC'.
*              wa_head-atwrt = lv_rollwidth.
*              CONDENSE  wa_head-atwrt NO-GAPS.
*              APPEND wa_head TO gt_mbpsv-chars.
*              CLEAR wa_head.
*            ENDIF.
*          ENDIF.
*      ENDCASE.
*    ENDLOOP.
*    MODIFY gt_mbpsv TRANSPORTING chars.
*    CLEAR gt_mbpsv.
*  ENDLOOP.
*
*ENDFORM.                    " ADD_ADDITIONAL_BATCH_CHARS
*&---------------------------------------------------------------------*
*&      Form  ADD_BATCH_CHARS
*&---------------------------------------------------------------------*
* Commented the below code by ALANKAP on 2/28/2022 CD# 2000000569 ->04
*FORM add_batch_chars.
*
*  DATA: wa_head       TYPE zfm_chars,
*        lv_roll_metr  TYPE zzroll_weight_metric,
*        lv_rollwidth  TYPE zzlinear_footage_metric,
*        lv_roll_feet  TYPE zzweight_of_roll_in_lbs,
*        lv_roll_width TYPE zzweight_of_roll_in_lbs.
*
*  CLEAR: gt_mbpsv,
*         gt_mbpsv-chars,
*         wa_head.
*
*  LOOP AT gt_mbpsv.
*    CLEAR wa_head.
*    LOOP AT gt_mbpsv-chars INTO wa_head.
*
*      CASE wa_head-atnam.
*
*        WHEN 'WEIGHT_OF_ROLL_IN_LBS'.
*          IF NOT wa_head-atwrt IS INITIAL.
*            CLEAR: lv_roll_width,
*                   lv_roll_metr.
*            lv_roll_width = wa_head-atwrt.
*            CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
*              EXPORTING
*                input                = lv_roll_width
*                kzmeinh              = ' '
*                matnr                = gt_mbpsv-matnr
*                meinh                = 'KG'
*                meins                = 'LB'
*              IMPORTING
*                output               = lv_roll_metr
*              EXCEPTIONS
*                conversion_not_found = 1
*                input_invalid        = 2
*                material_not_found   = 3
*                meinh_not_found      = 4
*                meins_missing        = 5
*                no_meinh             = 6
*                output_invalid       = 7
*                overflow             = 8
*                OTHERS               = 9.
*            IF sy-subrc = 0.
*              wa_head-atnam = 'ROLL_WEIGHT_METRIC'.
*              wa_head-atwrt = lv_roll_metr.
*              CONDENSE  wa_head-atwrt NO-GAPS.
*              APPEND wa_head TO gt_mbpsv-chars.
*
*              CLEAR wa_head.
*              wa_head-atnam = 'PACKAGE_NUMBER'.
*              wa_head-atwrt = gt_mbpsv-charg.
*
*              CONDENSE wa_head-atwrt NO-GAPS.
*              APPEND wa_head TO gt_mbpsv-chars.
*            ENDIF.
*          ENDIF.
*        WHEN 'LINEAL_FOOTAGE'.
*          IF NOT wa_head-atwrt IS INITIAL.
*            CLEAR: lv_roll_feet,
*                   lv_rollwidth.
*            lv_roll_feet  = wa_head-atwrt.
*            CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*              EXPORTING
*                input                = lv_roll_feet
*                unit_in              = 'LF'
*                unit_out             = 'M'
*              IMPORTING
*                output               = lv_rollwidth
*              EXCEPTIONS
*                conversion_not_found = 1
*                division_by_zero     = 2
*                input_invalid        = 3
*                output_invalid       = 4
*                overflow             = 5
*                type_invalid         = 6
*                units_missing        = 7
*                unit_in_not_found    = 8
*                unit_out_not_found   = 9
*                OTHERS               = 10.
*            IF sy-subrc = 0.
*              wa_head-atnam = 'LINEAR_FOOTAGE_METRIC'.
*              wa_head-atwrt = lv_rollwidth.
*              CONDENSE  wa_head-atwrt NO-GAPS.
*              APPEND wa_head TO gt_mbpsv-chars.
*              CLEAR wa_head.
*            ENDIF.
*          ENDIF.
*      ENDCASE.
*    ENDLOOP.
*    MODIFY gt_mbpsv TRANSPORTING chars.
*    CLEAR gt_mbpsv.
*  ENDLOOP.
*
*ENDFORM.                    " add_batch_chars
*&---------------------------------------------------------------------*
*&      Form  get_characteristics_material
*&---------------------------------------------------------------------*
* Get batch characteristics other than in segment E1EDL15 from MARA
*----------------------------------------------------------------------*
FORM get_characteristics_material.
  DATA:
    BEGIN OF lt_bat_char OCCURS 0,
      matnr   LIKE mara-matnr,
      cuobf   LIKE mara-cuobf,
      zzslgrd LIKE mara-zzslgrd,
      zzslbwt LIKE mara-zzslbwt,
      zzslclr LIKE mara-zzslclr,
      zzslsur LIKE mara-zzslsur,
    END OF lt_bat_char.
**
  IF NOT gt_bat_char[]  IS INITIAL.
    SELECT matnr
           cuobf
           zzslgrd
           zzslbwt
           zzslclr
           zzslsur
           INTO TABLE lt_bat_char
           FROM mara
           FOR ALL ENTRIES IN gt_bat_char
           WHERE matnr = gt_bat_char-matnr.
  ENDIF.
*
  SORT lt_bat_char BY matnr.

  IF NOT lt_bat_char[] IS INITIAL.
    LOOP AT gt_bat_char.
      gv_tabix = sy-tabix.
      READ TABLE lt_bat_char WITH KEY matnr = gt_bat_char-matnr.
      IF sy-subrc = 0.
        CLEAR:  gt_mbpsv_chars, gt_mbpsv_chars[].
* Commented the below code by ALANKAP on 2/28/2022 CD# 2000000569 ->01
*        gt_mbpsv_chars-atnam   = zsdc_sales_grade.
*        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslgrd.
*        APPEND gt_mbpsv_chars.
*        CLEAR  gt_mbpsv_chars.
*
*        gt_mbpsv_chars-atnam   = zsdc_sales_basis_weight.
*        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslbwt.
*        APPEND gt_mbpsv_chars.
*        CLEAR  gt_mbpsv_chars.
*
*        gt_mbpsv_chars-atnam   = zsdc_sales_color.
*        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslclr.
*        APPEND gt_mbpsv_chars.
*        CLEAR  gt_mbpsv_chars.
*
*        gt_mbpsv_chars-atnam   = zsdc_sales_surface.
*        gt_mbpsv_chars-atwrt   = lt_bat_char-zzslsur.
*        APPEND gt_mbpsv_chars.
*        CLEAR  gt_mbpsv_chars.
*
*        "Idoc will not contain these characteristics
*        "Retrieve SAP Characteristic Values
        REFRESH gt_conf_out.
        CLEAR   gs_conf_out.
        CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
          EXPORTING
            instance           = lt_bat_char-cuobf
            language           = sy-langu
          TABLES
            configuration      = gt_conf_out
          EXCEPTIONS
            instance_not_found = 1
            OTHERS             = 2.

        CHECK sy-subrc = 0.
        SORT gt_conf_out BY atnam.
*
        "Characteristic 'MFG_MATERIAL_NUMBER' wont be send in the IDoc
        "Controlled by a ZDL_FIELDS entry in the IP system
        DATA(ls_conf_out) = VALUE #( gt_conf_out[
                               atnam = zsdc_mfg_material_number ]
                               OPTIONAL ).
        IF ls_conf_out-atwrt IS NOT INITIAL.
          gt_mbpsv_chars-atnam   = zsdc_mfg_material_number.
          gt_mbpsv_chars-atwrt   = ls_conf_out-atwrt.
          APPEND gt_mbpsv_chars.
          CLEAR  gt_mbpsv_chars.
        ENDIF.
*
* Commented the below code by ALANKAP on 2/28/2022 CD# 2000000569 ->02
*        "Add '# of Rolls in Pack' characteristics
*        READ TABLE gt_conf_out INTO gs_conf_out
*                    WITH KEY atnam = 'ROLLS_IN_PACKAGE'
*                    BINARY SEARCH.
*        IF sy-subrc = 0.
*          gt_mbpsv_chars-atnam   = gs_conf_out-atnam.
*          "Format characteristics value to suit batch creation function module
*          PERFORM format_num_value USING    gs_conf_out-atnam
*                                   CHANGING gs_conf_out-atwrt.
*
*          gt_mbpsv_chars-atwrt   = gs_conf_out-atwrt.
*          APPEND gt_mbpsv_chars.
*          CLEAR  gt_mbpsv_chars.
*        ELSE.
*          "Set to default '1.000'
*          gt_mbpsv_chars-atnam   = 'ROLLS_IN_PACKAGE'.
*          gt_mbpsv_chars-atwrt   = '1.000'.
*          APPEND gt_mbpsv_chars.
*          CLEAR  gt_mbpsv_chars.
*        ENDIF.
*
      ENDIF.
      APPEND LINES OF gt_mbpsv_chars FROM 1 TO gt_bat_char-chars.
      MODIFY gt_bat_char INDEX gv_tabix TRANSPORTING chars.
      CLEAR: gt_bat_char.
    ENDLOOP.
  ENDIF.
ENDFORM.                    " get_characteristics_material
*&---------------------------------------------------------------------*
*&      Form  update_table_gt_mbpsv
*&---------------------------------------------------------------------*
* Update bat_char internal table with all batch characteristics
* Few taken from IDoc E1EDL15 segments and rest from MARA table
*----------------------------------------------------------------------*
FORM update_table_gt_mbpsv .

  SORT gt_bat_char BY matnr charg.
  SORT gt_mbpsv    BY matnr charg.
  IF NOT gt_bat_char[] IS INITIAL.
    LOOP AT gt_bat_char.
      READ TABLE gt_mbpsv WITH KEY
                  matnr = gt_bat_char-matnr
                  charg = gt_bat_char-charg.
      IF sy-subrc = 0.
        gv_tabix = sy-tabix.
        gt_mbpsv-chars[] = gt_bat_char-chars[].
        MODIFY  gt_mbpsv
                INDEX gv_tabix
                TRANSPORTING chars.
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " update_table_gt_mbpsv
*&---------------------------------------------------------------------*
*&      Form  create_batches
*&---------------------------------------------------------------------*
* This subroutine calls function module ZFM_CREATE_BATMAS03 in order to
* create batch and batch charateristics in SAP
*----------------------------------------------------------------------*
FORM create_batches.
  DATA:
    ls_idoc_ctrl TYPE  edi_dc40,
    lc_batmas    TYPE  edilsegtyp VALUE 'BATMAS',
    lc_batmas03  TYPE  edilsegtyp VALUE 'BATMAS03',
    lc_mescod    TYPE  edi4mescod VALUE 'VSN',
    lc_rcvprt    TYPE  edi4rcvprt VALUE 'US',
    lc_sndpor    TYPE  edi4sndpor VALUE 'TRFC'.

  "Convert gs_idoc_ctrl (type edidc) into ls_idoc_control (type edi_dc40)
  "Set partner profile for the BATMAS03 for this message type
  "Change MESTYP = BATMAS and IDOCTYPE = BATMAS03.
  "Set MESCODE = this object's message type; ie., ZDL_VASN
  IF NOT gs_idoc_ctrl IS INITIAL.
    MOVE-CORRESPONDING gs_idoc_ctrl TO ls_idoc_ctrl.
    CLEAR: ls_idoc_ctrl-docnum.
    ls_idoc_ctrl-idoctyp  = lc_batmas03.
    ls_idoc_ctrl-mestyp   = lc_batmas.
    ls_idoc_ctrl-mescod   = lc_mescod.
    ls_idoc_ctrl-rcvprt   = lc_rcvprt.
    CONCATENATE sy-sysid 'CLNT' sy-mandt INTO ls_idoc_ctrl-rcvprn.

    ls_idoc_ctrl-sndpor   = lc_sndpor.
    ls_idoc_ctrl-sndprt   = lc_rcvprt.
    ls_idoc_ctrl-sndprn   = ls_idoc_ctrl-rcvprn.
    CLEAR ls_idoc_ctrl-mesfct.
  ENDIF.

  SELECT SINGLE FROM zdl_fields
    FIELDS lowval
    WHERE category EQ 'I10580'
      AND fieldname EQ 'LGORT'
      AND lowval EQ 'X'
      INTO @DATA(lv_clear_lgort).


  LOOP AT gt_mbpsv ASSIGNING FIELD-SYMBOL(<fs_mbpsv>).

    IF lv_clear_lgort EQ 'X'.
      CLEAR <fs_mbpsv>-lgort.
    ENDIF.

    "Change plant using cross reference data from table ZDL_FIELDS
    DATA(ls_plants) = VALUE #( gt_zdl_fields[ fieldname = 'WERKS'
                                              lowval = <fs_mbpsv>-werks ]
                                             OPTIONAL ).
    IF ls_plants IS NOT INITIAL.
      <fs_mbpsv>-werks = ls_plants-highval.
    ENDIF.
  ENDLOOP.


  REFRESH:  gt_bapi, gt_mbis.
  IF NOT gt_mbpsv[] IS INITIAL.  "New Batches need to be created
    CALL FUNCTION 'ZFM_CREATE_BATMAS03'
      EXPORTING
        i_idoc_control  = ls_idoc_ctrl
        it_batch        = gt_mbpsv[]
      TABLES
        et_batch_status = gt_mbis[]
        et_return       = gt_bapi[].
    "Generate an Idoc Status error message if any occurred creating a batch
    LOOP AT gt_bapi.
      IF gt_bapi-id  IS NOT INITIAL.
        "When there is a message ID available

        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error     "status 51
                gs_idoc_ctrl-docnum     "idoc number
                gt_bapi-type            "status msg type
                gt_bapi-id              "message class
                gt_bapi-number          "err msg
                gt_bapi-message_v1      "msgv1
                gt_bapi-message_v2      "msgv2
                gt_bapi-message_v3      "msgv3
                gt_bapi-message_v4      "msgv4
                'CREATE_BATCHES'        "routid
                ' '                     "seg num
                ' '.                    "seg field

      ELSE.
        "When there is no message ID, just message in the 'MESSAGE' field (Length 220)
        DATA(lv_msgv1) = gt_bapi-message+0(50).
        DATA(lv_msgv2) = gt_bapi-message+50(50).
        DATA(lv_msgv3) = gt_bapi-message+100(50).
        DATA(lv_msgv4) = gt_bapi-message+150(50).

        PERFORM sub_idoc_status_fill USING
                     c_idoc_status_error     "status 51
                     gs_idoc_ctrl-docnum     "idoc number
                     c_error                 "status msg type
                     'ZDL'                   "message class
                     '015'                   "err msg
                     lv_msgv1                "msgv1
                     lv_msgv2                "msgv2
                     lv_msgv3                "msgv3
                     lv_msgv4                "msgv4
                     'CREATE_BATCHES'        "routid
                     ' '                     "seg num
                     ' '.                    "seg field
      ENDIF.
    ENDLOOP.

  ENDIF.
ENDFORM.                    "create_batches
*&---------------------------------------------------------------------*
*&      Form  build_hu_tables
*&---------------------------------------------------------------------*
FORM build_hu_tables.

  DATA lv_matnr LIKE mara-matnr.  "For packing material

  DATA:
    lv_tabix   TYPE sytabix,          " Internal table index
    lv_44count TYPE i.                " Local counter

* For Packing material identification
  CONSTANTS:
    lc_verp      LIKE mara-mtart  VALUE 'VERP',
    lc_pkg       LIKE mara-vhart  VALUE 'PKG',
    lc_hu_status LIKE vekp-status VALUE '0060'.

  DATA:
    lv_exidv   TYPE exidv,  "HU
    lv_counter TYPE i.

  gv_idoc_error = gc_false.

  REFRESH gt_hu.
  CLEAR   gs_hu.

  CHECK gt_mbhp_tab[] IS NOT INITIAL.

  "Get Packing Materials details and populate that into VHILM and
  "VHILM_KU field.
  SELECT SINGLE matnr
        INTO lv_matnr
        FROM mara
        WHERE  mtart = lc_verp
          AND  vhart = lc_pkg.
  IF sy-subrc NE 0.
    "Validation:Packing Material does not exist in SAP
    PERFORM sub_idoc_status_fill USING
            c_idoc_status_error     "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZDL'                   "message class
            '016'                   "err msg
            ' '                     "msgv1
            ' '                     "msgv2
            ' '                     "msgv3
            ' '                     "msgv4
            'BUILD_HU_TABLES'       "routid
            gc_e1edl37              "seg num
            ' '.                    "seg field
  ENDIF.

  CHECK gv_idoc_error = gc_false.


  "Update HU Header and HU Item data with the new SAP HU
  "Number if applicable.
  CLEAR: lv_44count,
         gs_l37,
         gt_l37,
         gs_l44,
         gt_l44.

  DATA lv_e1edl37_exidv TYPE exidv.
  DATA(lt_idoc_data) = gt_idoc_data[].

  LOOP AT gt_idoc_data
       INTO gs_idoc_data
       WHERE   docnum  =  gs_idoc_ctrl-docnum
         AND ( segnam  =  gc_e1edl20 OR
               segnam  =  gc_e1edl37 OR
               segnam  =  gc_e1edl44 ).

    lv_tabix  =  sy-tabix.

    CASE gs_idoc_data-segnam.
      WHEN gc_e1edl20.
        gs_e1edl20 = gs_idoc_data-sdata.

        DATA(lv_delivery_external) =  CONV vbeln_vl( gs_e1edl20-vbeln ).
        DATA(lv_bolnr) =  gs_e1edl20-bolnr.

      WHEN gc_e1edl37.

        gs_e1edl37 = gs_idoc_data-sdata.

        gs_e1edl37-vhilm_ku = gs_e1edl37-exidv. "store original HU
        gs_e1edl37-vhilm    = lv_matnr.        "store packaging material

        lv_e1edl37_exidv = gs_e1edl37-exidv.


        "Update segment data
        gs_idoc_data-sdata = gs_e1edl37.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX lv_tabix
          TRANSPORTING sdata.
        "Build table of HU's relevant to this ASN whether the HU exists or not.
        gs_hu-lifex = lv_delivery_external.
        gs_hu-bolnr = lv_bolnr.
        gs_hu-exidv = gs_e1edl37-exidv.
        APPEND gs_hu TO gt_hu.

        "Build HU Header data table for use when generating HU's
        MOVE-CORRESPONDING gs_e1edl37 TO gs_l37.
        APPEND gs_l37 TO gt_l37.


      WHEN gc_e1edl44.

        lv_44count  = lv_44count + 1."ctr relates to oth work tables

        gs_e1edl44 = gs_idoc_data-sdata.


*       Determine the new SAP Batch Number if applicable.
*       gt_mbhp_tab-charg is a 20-byte field containing the Vendor
*       Batch.  gt_mbhp_tab-ncharg is the new SAP Batch (or the same
*       one passed in on the idoc if it meets the necessary criteria).
*       Retrieve other SAP values and overlay existing junk

        READ TABLE gt_mbhp_tab WITH KEY 44tabix = lv_tabix.
        IF sy-subrc = 0.
          gs_e1edl44-matnr = gt_mbhp_tab-nmatnr. "SAP Material
          gs_e1edl44-werks = gt_mbhp_tab-werks.  "SAP Plant
          gs_e1edl44-charg = gt_mbhp_tab-ncharg. "SAP Batch

*         If quantity and UOM in the E1EDL44 segment is empty,
*         please get from corresponding E1EDL24 segment and populate
          IF gs_e1edl44-vemng IS INITIAL.

            READ TABLE gt_idoc_data INTO gs_idoc_data
                  INDEX gt_mbhp_tab-24tabix.
            IF sy-subrc = 0.
              CLEAR:  gs_e1edl24.
              gs_e1edl24       = gs_idoc_data-sdata.
              gs_e1edl44-vemng = gs_e1edl24-lfimg.
              gs_e1edl44-vemeh = gs_e1edl24-meins.
            ENDIF.
          ENDIF.

          gs_e1edl44-exidv = lv_e1edl37_exidv.

        ENDIF.

*       Update segment data
        gs_idoc_data-sdata = gs_e1edl44.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX lv_tabix
          TRANSPORTING sdata.

*       Build HU Item data table for use when generating HU's
        MOVE-CORRESPONDING gs_e1edl44 TO gs_l44.
        APPEND gs_l44 TO gt_l44.

    ENDCASE.
  ENDLOOP.

ENDFORM.                    " build_hu_tables
*&---------------------------------------------------------------------*
*&      Form  create_hu
*&---------------------------------------------------------------------*
*       Generate HU's if they don't exist. This logic works for both
*       Bundled and Non-Bundled Rolls
*----------------------------------------------------------------------*
FORM create_hu.

  DATA lv_exidv TYPE exidv.

  CONSTANTS:
*   Type of Handling-unit Item Content
    lc_material_item    TYPE  velin        VALUE '1',

*   HU Status
    lc_in_warehouse     TYPE  hu_st_init   VALUE 'C',
    lc_unassign         TYPE  hu_st_init   VALUE 'A', "Brazil ASN
    lc_not_in_warehouse TYPE hu_st_init VALUE 'B'.

  "Process HU Header data
  LOOP AT gt_l37 INTO gs_l37.

    "Determine if HU exists. If not then create it
    SELECT SINGLE exidv INTO lv_exidv FROM vekp
        WHERE exidv = gs_l37-exidv
          AND status <> gc_hu_status.   " HU status '0060'
    IF sy-subrc = 0.
      CONTINUE.
    ENDIF.

    "Retrieve Plant from 1st E1EDL44 record
    READ TABLE gt_l44 INTO gs_l44
      WITH KEY exidv = gs_l37-exidv.

    "Populate Header structure
    CLEAR: gs_headerproposal.

    gs_headerproposal-hu_status_init = lc_not_in_warehouse.  "'B'

    gs_headerproposal-pack_mat       = gs_l37-vhilm. "HU packng matl
    gs_headerproposal-content        = gs_l37-vhilm_ku. "Vendor ID
    gs_headerproposal-hu_exid        = gs_l37-exidv. "HU

    "HU's 2nd External Identification(UCC Code)
    gs_headerproposal-ext_id_hu_2    = gs_l37-exidv2.
    gs_headerproposal-plant          = gs_l44-werks. "HU plant

    "Process HU Item data
    CLEAR: gs_itemsproposal, gt_itemsproposal[].
    LOOP AT gt_l44 INTO gs_l44
      WHERE exidv = gs_l37-exidv.

      "Populate item table
      gs_itemsproposal-hu_item_type      = lc_material_item.
      gs_itemsproposal-pack_qty          = gs_l44-vemng.

      "Retrieve SAP uom using ISO Code uom stored in L44 from current HU
      CLEAR: gs_itemsproposal-base_unit_qty.
      SELECT SINGLE msehi INTO gs_itemsproposal-base_unit_qty FROM t006
        WHERE isocode = gs_l44-vemeh.
      IF sy-subrc <> 0.
        gs_itemsproposal-base_unit_qty = gs_l44-vemeh.
      ENDIF.

      gs_itemsproposal-material          = gs_l44-matnr.
      gs_itemsproposal-batch             = gs_l44-charg.
      gs_itemsproposal-plant             = gs_l44-werks.
      APPEND gs_itemsproposal  TO  gt_itemsproposal.
    ENDLOOP.                                                "gt_l44


    "Create the new Handling Unit
    CLEAR gt_return[]. "refresh error table
    CALL FUNCTION 'BAPI_HU_CREATE'
      EXPORTING
        headerproposal = gs_headerproposal  "Hdr data
      TABLES
        itemsproposal  = gt_itemsproposal   "Itm data
        return         = gt_return.
    IF NOT gt_return[] IS INITIAL.

      LOOP AT gt_return INTO gs_return.

        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error     "status 51
                gs_idoc_ctrl-docnum     "idoc number
                c_error                 "status msg type
                gs_return-id            "message class
                gs_return-number        "err msg
                gs_return-message_v1    "msgv1
                gs_return-message_v2    "msgv2
                gs_return-message_v3    "msgv3
                gs_return-message_v4    "msgv4
                'CREATE_HU'             "routid
                gs_idoc_data-segnum     "seg num
                ' '.                    "seg field
      ENDLOOP.
      RETURN.
    ENDIF.

    CLEAR: gs_return.
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait   = 'X'             "wait for update
      IMPORTING
        return = gs_return.
    IF NOT gs_return IS INITIAL.
      PERFORM sub_idoc_status_fill USING
              c_idoc_status_error     "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              gs_return-id            "message class
              gs_return-number        "err msg
              gs_return-message_v1    "msgv1
              gs_return-message_v2    "msgv2
              gs_return-message_v3    "msgv3
              gs_return-message_v4    "msgv4
              'CREATE_HU'             "routid
              gs_idoc_data-segnum     "seg num
              ' '.                    "seg field
      RETURN.
    ENDIF.

  ENDLOOP.                                                  "gt_l37

ENDFORM.                    " create_hu
*&---------------------------------------------------------------------*
*&      Form  GENERATE_USD_TICKET
*&---------------------------------------------------------------------*
*** NOTE: ANY time and idoc 51 error is generated, this subroutine
*     should only be executed once so we should not run the risk of
*     generating multiple USD tickets
*----------------------------------------------------------------------*
*Generate AHD tickets with a priority based  on values populated in the*
*ZSP_VALUE table where the PRGMID='ZDL_I02301_USD_PRIORITY' for        *
*specific plants. The AHD ticket must be configured with inventory code*
*'I10580' in a system where USD tickets may be generated (connected to *
*WebMethods) for this code to work. This change is located in          *
*INCLUDE - LZDL_SYVASNF01 & FORM GENERATE_USD_TICKET                   *
*----------------------------------------------------------------------*
FORM generate_usd_ticket USING lpx_idoc_status LIKE bdidocstat. " CR5297

  CONSTANTS: c_i10580_pgrmid LIKE zsp_value-pgrmid
                  VALUE 'ZDL_I10580_USD_PRIORITY',
             c_ahd_invcode   TYPE  zzinv6 VALUE 'I10580'.

  DATA: lt_zsp          TYPE STANDARD TABLE OF zsp_value,
        ls_zsp          TYPE zsp_value,
        lv_priority     TYPE c,
        lv_omd_ind      TYPE c,
        l_sys_mess(200),
        l_ahd_text      TYPE zchar400, " AHD ticket body
        l_plant         TYPE werks_d.

  CHECK gv_chk_multiple_usd IS INITIAL.

  CLEAR lv_priority.

  CLEAR l_plant.

  SORT gt_tr_po_i BY werks DESCENDING.
  CLEAR gs_tr_po_i.
  READ TABLE gt_tr_po_i
        INTO gs_tr_po_i INDEX 1.
  IF   NOT gs_tr_po_i-werks IS INITIAL.
    l_plant = gs_tr_po_i-werks.
  ENDIF.

  "If the plant is missing, use the Purch org for PO1 instead
  IF l_plant IS INITIAL.
    SORT gt_tr_po_i BY ekorg DESCENDING.
    CLEAR gs_tr_po_i.
    READ TABLE gt_tr_po_i
          INTO gs_tr_po_i INDEX 1.
    IF NOT gs_tr_po_i-ekorg IS INITIAL.
      l_plant = gs_tr_po_i-ekorg.
    ENDIF.
  ENDIF.

  "If a plant was identified...
  IF NOT l_plant IS INITIAL.

    "Retrieve all relevant, populated priority records
    SELECT *
      FROM zsp_value
      INTO TABLE lt_zsp
      WHERE pgrmid = c_i10580_pgrmid.
    IF sy-subrc = 0.
      SORT lt_zsp BY fieldvalue.
      DELETE lt_zsp WHERE fieldvalue IS INITIAL.
    ENDIF.

    "Determine if there is a plant-specific record
    CLEAR ls_zsp.
    SORT lt_zsp BY fieldname.
    READ TABLE lt_zsp
          INTO ls_zsp
      WITH KEY fieldname = l_plant.
    IF sy-subrc = 0.
      lv_priority = ls_zsp-fieldvalue.
    ELSE.
      "Retrieve omd plant record to determine the priority indicator
      CLEAR lv_omd_ind.
      SELECT SINGLE omd_ind
        INTO lv_omd_ind
        FROM zplant
       WHERE werks = l_plant.
      IF sy-subrc = 0.
        "Retrieve Priority from ZSP_VALUE
        CLEAR ls_zsp.
        READ TABLE lt_zsp
              INTO ls_zsp
          WITH KEY fieldname = lv_omd_ind.
        IF sy-subrc = 0.
          lv_priority = ls_zsp-fieldvalue.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.


*SOC by PBOMMIR on 26.Apr.2024
"commented by PBOMMIR on 25.Apr.2024 S0VK906981
  "If the priority is still blank...
*  IF lv_priority IS INITIAL.
*    "Default to priority 2
*    lv_priority = '2'.
*  ENDIF.

  SELECT SINGLE * FROM zsdomfld INTO @DATA(ls_zsdomfld) WHERE category = 'ZDL_SYVASN'
                                                         AND   fieldname = 'PRIORITY'
                                                         AND   sign = 'I'
                                                         AND   optn = 'EQ'.
  IF sy-subrc = 0 AND  lv_priority IS INITIAL.
    lv_priority = ls_zsdomfld-lowval.
  ELSE.
    lv_priority = '2'.
  ENDIF.
*SOC by PBOMMIR on 26.Apr.2024

  "Write the IDoc Message into a 400 char. AHD ticket format:
  CLEAR l_sys_mess.
  MESSAGE ID lpx_idoc_status-msgid
        TYPE lpx_idoc_status-msgty
      NUMBER lpx_idoc_status-msgno
        WITH lpx_idoc_status-msgv1
             lpx_idoc_status-msgv2
             lpx_idoc_status-msgv3
             lpx_idoc_status-msgv4
        INTO l_sys_mess.
  CLEAR l_ahd_text.
  CONCATENATE gs_idoc_ctrl-mestyp
              ' IDoc #:'(007)
              lpx_idoc_status-docnum
              ' returned the following error: '(008)
              l_sys_mess
         INTO l_ahd_text.

  "Generate the AHD Ticket
  CALL FUNCTION 'Z_GEN_AHD_TICKET_ZZINV6'
    EXPORTING
      if_inventory_code      = c_ahd_invcode
      if_priority            = lv_priority
      if_severity            = '2'
      if_text                = l_ahd_text
*     IF_USD_GROUP           = IF_USD_GROUP
    EXCEPTIONS
      invalid_inv_code       = 1
      ahdgrp_not_found       = 2
      webmd_connection_error = 3
      OTHERS                 = 4.
  IF sy-subrc <> 0.
    CASE sy-subrc.
      WHEN 1."Inventory code doesn't exist in table ZZPRODDOC - &
        MESSAGE s165(zdl_wm) WITH c_ahd_invcode.

      WHEN 2."AHD group name was not found
        MESSAGE s166(zdl_wm).

      WHEN 3."Connection to WEBMETHODS is down
        MESSAGE s167(zdl_wm).

      WHEN OTHERS.
        "Unknown exception in function module Z_GEN_AHD_TICKET_ZZINV6
        MESSAGE s168(zdl_wm).
    ENDCASE.
  ENDIF.

ENDFORM. "GENERATE_USD_TICKET

*&---------------------------------------------------------------------*
*&      Form  CHECK_HU_EXIST
*&---------------------------------------------------------------------*
*       Check if HU's exist for inbound delivery.
*----------------------------------------------------------------------*
FORM check_hu_exist .

  CONSTANTS lc_inb_del LIKE vekp-vpobj   VALUE '03'.

  DATA lv_exidv  LIKE vekp-exidv.

  "If inbound delivery already exists, ie., we are doing reprocessing of IDocs
  IF NOT gv_out_vbeln IS INITIAL.
    "Read Handling Unit number from VEKP
    SELECT  exidv
       FROM vekp
       INTO lv_exidv UP TO 1 ROWS
        WHERE vpobj    = lc_inb_del
          AND vpobjkey = gv_inb_vbeln.
    ENDSELECT.
    IF sy-subrc <> 0.
      "Message:Inbound delivery created
      PERFORM sub_idoc_status_fill USING
              c_idoc_status_ok_incomplete  "status 52
              gs_idoc_ctrl-docnum          "idoc number
              c_error                      "status msg type
              'ZDL'                        "message class
              '020'                        "err msg
              TEXT-009                     "msgv1
              gv_inb_vbeln                 "msgv2
              ' '                          "msgv3
              ' '                          "msgv4
              'CHECK_HU_EXIST'             "routid
              ' '                          "seg num
              ' '.                         "seg field
      gv_idoc_error = gc_true.
    ELSE.
      gv_idoc_error = gc_false.
    ENDIF.
  ENDIF.
ENDFORM.                    " check_hu_exist
*&---------------------------------------------------------------------*
*&      Form  CHECK_DELIVERY_LOCK
*&---------------------------------------------------------------------*
* Ensure that the inbound is locked by anybody, because we are going to
* change inbound delivery with HU details
*----------------------------------------------------------------------*
FORM check_delivery_lock .

  DATA: lv_subrc TYPE sysubrc VALUE 4.

  "Attempt to lock the delivery to make sure it is not already locked
  DO 30 TIMES.
    CALL FUNCTION 'ENQUEUE_EVVBLKE'
      EXPORTING
        mode_likp      = 'E'
        mandt          = sy-mandt
        vbeln          = gv_inb_vbeln  "inb delivery nu
        _scope         = '2'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc = 0.
      lv_subrc = sy-subrc.
      EXIT.
    ELSE.
      WAIT UP TO 3 SECONDS.
    ENDIF.
  ENDDO.

  IF lv_subrc = 0.
    "Unlock the delivery
    CALL FUNCTION 'DEQUEUE_EVVBLKE'
      EXPORTING
        mode_likp = 'E'
        mandt     = sy-mandt
        vbeln     = gv_inb_vbeln "inbound delivery num
        _scope    = '3'.
  ELSE.
    "Validation:Unable to lock delivery & for update
    PERFORM sub_idoc_status_fill USING
            c_idoc_status_error     "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZDL'                   "message class
            '017'                   "err msg
            gv_inb_vbeln            "msgv1
            ' '                     "msgv2
            ' '                     "msgv3
            ' '                     "msgv4
            'CHECK_DELIVERY_LOCK'   "routid
            ' '                     "seg num
            ' '.                    "seg field
  ENDIF.

ENDFORM.                    " check_delivery_lock
*&---------------------------------------------------------------------*
*&      Form  ASSIGN_HU_TO_DELIVERY
*&---------------------------------------------------------------------*
* Update Inbound delivery with HU details
*----------------------------------------------------------------------*
FORM assign_hu_to_delivery.

  DATA(lt_assign_hu) = gt_assign.

  DELETE lt_assign_hu WHERE vbeln NE gv_inb_vbeln.

  "If all HU's were already assigned then generate an error that this is a duplicate ASN
  IF lt_assign_hu IS INITIAL.

    "If there this is a duplicate ASN then archive
    "Set the idoc (status 68) instead of setting it to a 51.
    "Validation:Duplicate ASN sent. Inbound Delivery not created.
    PERFORM sub_idoc_status_fill USING
                  c_idoc_status_delete   "status 68
                  gs_idoc_ctrl-docnum    "idoc number
                  c_info                 "status msg type
                  'ZDL'                  "message class
                  '019'                  "msgno
                  ' '                    "msgv1
                  ' '                    "msgv2
                  ' '                    "msgv3
                  ' '                    "msgv4
                  'ASSIGN_HU_TO_DELIVERY'"routid
                  ' '                    "seg num
                  ' '.                   "seg field

    RETURN.

  ENDIF.

  DATA lv_error_any.

  CLEAR: gt_handling_units[].

  LOOP AT lt_assign_hu INTO gs_assign WHERE vpobjkey NE gv_inb_vbeln.
    CLEAR: gs_handling_units.
    gs_handling_units-top_hu_external = gs_assign-exidv.
    APPEND gs_handling_units TO gt_handling_units.
  ENDLOOP.


  "Format header structure with Inbound Delivery Number
  CLEAR: gs_vbkok.
  gs_vbkok-vbeln_vl = gv_inb_vbeln.

  CLEAR: lv_error_any.

  "Assign HU to the Delivery since not currently assigned
  CLEAR: gs_prot, gt_prot[].
  CALL FUNCTION 'WS_DELIVERY_UPDATE'
    EXPORTING
      vbkok_wa                 = gs_vbkok
      commit                   = 'X'
      delivery                 = gv_inb_vbeln
      if_database_update       = '1' "check & save
      if_error_messages_send_0 = space "'X'
    IMPORTING
      ef_error_any_0           = lv_error_any
    TABLES
      prot                     = gt_prot
      it_handling_units        = gt_handling_units.

  "Check if any of the Flags are set to "X" then Error out that HU is
  "not assigned Inbound Delivery. So that when re-processing is done
  "there will be no new Inbound Delivery will be created.
  IF lv_error_any  IS NOT INITIAL .

    IF NOT gt_prot[] IS INITIAL.
      "Write error messages from function
      LOOP AT gt_prot INTO gs_prot WHERE msgty = c_error.
        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error    "status 51
                gs_idoc_ctrl-docnum    "idoc number
                gs_prot-msgty          "status msg type
                gs_prot-msgid          "message id
                gs_prot-msgno          "msgno
                gs_prot-msgv1          "msgv1
                gs_prot-msgv2          "msgv2
                gs_prot-msgv3          "msgv3
                gs_prot-msgv4          "msgv4
                'ASSIGN_HU_TO_DELIVERY'"routid
                ' '                    "seg num
                ' '.                   "seg field

        "Validation:HU Assignment Failed for IB DLV &
        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error      "status 51
                gs_idoc_ctrl-docnum      "idoc number
                c_error                  "status msg type
                'ZDL'                    "message class
                '018'                    "err msg
                gv_inb_vbeln             "msgv1
                ' '                      "msgv2
                ' '                      "msgv3
                ' '                      "msgv4
                'ASSIGN_HU_TO_DELIVERY' "routid
                ' '                      "seg num
                ' '.                     "seg field

      ENDLOOP.
      "If any errors occurred on the HU assignment then error
      IF gv_idoc_error = gc_true.
        RETURN.
      ENDIF.
    ENDIF.
  ENDIF.
ENDFORM.                    " assign_hu_to_delivery

*&---------------------------------------------------------------------*
*&      Form  REMOVE_E1EDL18_SEGMENT
*&---------------------------------------------------------------------*
FORM remove_e1edl18_segment .

  LOOP AT gt_idoc_data INTO gs_idoc_data
       WHERE docnum  =  gs_idoc_ctrl-docnum
         AND segnam  =  gc_e1edl18.

    gs_e1edl18    = gs_idoc_data-sdata.

    DATA(lv_qualf) = VALUE #( gt_zdl_fields[ fieldname = 'E1EDL18'
                                             lowval = gs_e1edl18-qualf ]
                                             OPTIONAL ).
    IF lv_qualf IS NOT INITIAL.
      DELETE gt_idoc_data INDEX sy-tabix.
    ENDIF.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_ZDL_FIELDS
*&---------------------------------------------------------------------*
FORM get_zdl_fields .

  SELECT * INTO TABLE gt_zdl_fields FROM zdl_fields
         WHERE category = 'I10580'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FORMAT_E1EDL15
*&---------------------------------------------------------------------*
FORM format_e1edl15 USING p_atnam
                 CHANGING p_atwrt.

  IF p_atnam EQ 'ROLL_DIAMETER' OR
     p_atnam EQ 'ROLL_WIDTH' OR
     p_atnam EQ 'LINEAL_FOOTAGE' OR
     p_atnam EQ 'SCALED_WEIGHT_KG' OR
     p_atnam EQ 'SCALED_WEIGHT_LBS' OR
     p_atnam EQ 'WEIGHT_OF_ROLL_IN_LBS' OR
     p_atnam EQ 'CORE_TARE' OR
     p_atnam EQ 'CORE_DIAMETER' OR
     p_atnam EQ 'ORDERED_DIAMETER'.

    PERFORM format_num_value USING p_atnam
                          CHANGING p_atwrt.

  ENDIF.

ENDFORM.

FORM process_e1edl20 CHANGING p_bolnr TYPE likp-bolnr
                              p_error TYPE boolean.

  CLEAR:  gs_e1edl20,p_error.
  gs_e1edl20    = gs_idoc_data-sdata.

  "Validate the Shipping Condition(vsbed)- to table TVSB.
  "If Idoc-vsbed is valid then append or else clear the value
  IF gs_e1edl20-vsbed IS NOT INITIAL.

    DATA : lv_vsbed TYPE vsbed.

    SELECT SINGLE vsbed INTO lv_vsbed FROM tvsb
       WHERE vsbed = gs_e1edl20-vsbed. "Value From IDOC
    IF sy-subrc EQ 0.
      "EXPORT: Shipping Condition
      gs_memory-vsbed    = gs_e1edl20-vsbed.
    ENDIF.

  ELSE.

    "Validation:No Shipping Condition on the ASN
    PERFORM sub_idoc_status_fill USING
        c_idoc_status_error     "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZDL'                   "message class
        '023'                   "err msg
        ' '                     "msgv1
        ' '                     "msgv2
        ' '                     "msgv3
        ' '                     "msgv4
        'PROCESS_E1EDL20'       "routid
        gc_e1edl20              "seg num
        ' '.                    "seg field

    p_error = abap_true.

  ENDIF.

  "Check whether BOL is in IDoc.
  IF NOT gs_e1edl20-bolnr IS INITIAL.

    "Check if the submitted BOLNR has already been created
    SELECT SINGLE FROM vttk
      FIELDS tknum
      WHERE tknum = @gs_e1edl20-bolnr
      INTO @DATA(lv_tknum).
    IF sy-subrc EQ 0.

      "Validation:BOL/Shipment & already exists
      PERFORM sub_idoc_status_fill USING
               c_idoc_status_delete    "status 68
               gs_idoc_ctrl-docnum     "idoc number
               c_info                  "status msg type
               'ZDL'                   "message class
               '006'                   "err msg
               lv_tknum                "msgv1
               ' '                     "msgv2
               ' '                     "msgv3
               ' '                     "msgv4
               'PROCESS_E1EDL20'       "routid
               gc_e1edl20              "seg num
               ' '.                    "seg field

      p_error = abap_true.


    ELSE.
      "Map this BOLNR into External Identification of
      "Delviery Note LIFEX field
      gs_e1edl20-lifex   = gs_e1edl20-bolnr.
      gs_idoc_data-sdata = gs_e1edl20.
      MODIFY gt_idoc_data FROM gs_idoc_data
                INDEX gv_tabix
                TRANSPORTING sdata.

      p_bolnr = CONV bolnr( gs_e1edl20-bolnr ).
    ENDIF.

  ELSE.
    "Validation:No BOL on ASN
    PERFORM sub_idoc_status_fill USING
             c_idoc_status_error     "status 51
             gs_idoc_ctrl-docnum     "idoc number
             c_error                 "status msg type
             'ZDL'                   "message class
             '000'                   "err msg
             ' '                     "msgv1
             ' '                     "msgv2
             ' '                     "msgv3
             ' '                     "msgv4
             'PROCESS_E1EDL20'       "routid
             gc_e1edl20              "seg num
             ' '.                    "seg field

    p_error = abap_true.

  ENDIF.


  IF gs_e1edl20-traid IS INITIAL.

    "Validation:No Vehicle ID on ASN
    PERFORM sub_idoc_status_fill USING
        c_idoc_status_error     "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZDL'                   "message class
        '022'                   "err msg
        ' '                     "msgv1
        ' '                     "msgv2
        ' '                     "msgv3
        ' '                     "msgv4
        'PROCESS_E1EDL20'       "routid
        gc_e1edl20              "seg num
        ' '.                    "seg field


    p_error = abap_true.

  ELSE.
    "EXPORT: Container ID
    gs_memory-zz_signi = gs_e1edl20-traid.

  ENDIF.

  IF gs_e1edl20-vbeln IS INITIAL.

    "Validation:Missing delivery #
    PERFORM sub_idoc_status_fill USING
        c_idoc_status_error     "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZDL'                   "message class
        '011'                   "err msg
        ' '                     "msgv1
        ' '                     "msgv2
        ' '                     "msgv3
        ' '                     "msgv4
        'PROCESS_E1EDL20'       "routid
        gc_e1edl20              "seg num
        ' '.                    "seg field

    p_error = abap_true.

  ENDIF.

ENDFORM.

*FORM check_delivery_exists.
*
*  SELECT a~vbeln
*         a~lifex "External Delivery ID = E1EDL20-VBELN
*         b~charg
*         b~lichn
*   INTO TABLE gt_delivery_exists
*   FROM likp AS a
*   INNER JOIN lips AS b ON a~vbeln = b~vbeln
*   INNER JOIN vbuk AS c ON c~vbeln = a~vbeln
*   FOR ALL ENTRIES IN gt_hu
*   WHERE a~bolnr = gt_hu-bolnr "Bol Number
*     AND b~lichn = gt_hu-exidv "Vendor batch
*     AND wbstk  NE 'C'.        "Total goods movement status
*
*ENDFORM.

FORM check_delivery_exists.

  SELECT a~vbeln
         a~btgew "Total Weight
         a~lifex "External Delivery ID = E1EDL20-VBELN
   INTO TABLE gt_delivery_exists
   FROM likp AS a
   INNER JOIN vbuk AS b ON b~vbeln = a~vbeln
   FOR ALL ENTRIES IN gt_hu
   WHERE a~lifex = gt_hu-lifex "External Delivery ID
     AND a~bolnr = gt_hu-bolnr "BOL
     AND wbstk  NE 'C'.        "Total goods movement status

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  CHECK_HU_ASSIGNED
*&---------------------------------------------------------------------*
FORM check_hu_assigned .

  "Get HUs
  SELECT exidv
         vpobj
         vpobjkey
      INTO TABLE gt_assign
      FROM vekp
      FOR ALL ENTRIES IN gt_hu
      WHERE exidv = gt_hu-exidv
      AND status NE '0060'.    "deleted
  IF sy-subrc = 0.
    SORT gt_assign BY vpobjkey.
  ENDIF.

  LOOP AT gt_assign ASSIGNING FIELD-SYMBOL(<fs_assign>).

    "Get Outbound Delivery # - External Delivery ID(E1EDL20-VBELN)
    DATA(lv_lifex) = VALUE #( gt_hu[ exidv = <fs_assign>-exidv ]-lifex OPTIONAL ).
    IF lv_lifex IS INITIAL.
      CONTINUE.
    ENDIF.

    "Get Inbound Delivery #
    DATA(lv_vbeln) = VALUE #( gt_delivery_exists[ lifex = lv_lifex ]-vbeln OPTIONAL ).

    IF lv_vbeln IS NOT INITIAL.
      <fs_assign>-vbeln = lv_vbeln.
      <fs_assign>-lifex = lv_lifex.
    ENDIF.

    "Check if HU is assigned
    IF <fs_assign>-vpobjkey EQ lv_vbeln AND <fs_assign>-vpobj EQ '03'.

      "Validiation:HU & already assigned to delivery &
      PERFORM sub_idoc_status_fill USING
        c_idoc_status_error               "status 51
        gs_idoc_ctrl-docnum               "idoc number
        c_error                           "status msg type
        'ZDL'                             "message class
        '030'                             "err msg
        <fs_assign>-exidv                 "msgv1
        lv_vbeln                          "msgv2
        ' '                               "msgv3
        ' '                               "msgv4
        'CHECK_HU_ASSIGNED'               "routid
        ' '                               "seg num
        ' '.                              "seg field

      gv_idoc_error = gc_true.

    ENDIF.


  ENDLOOP.

ENDFORM.


FORM success_message.

  CHECK gv_idoc_error NE abap_true.

  DATA lv_message TYPE char200.

*     if this is a reprocess of the idoc (already existed) then the
*     Assignment of the HU's probably failed on the previous run for
*     some reason. If that happened we had issued a '51' message but
*     NOW need to generate a successful '53' message, like the one
*     BORES_IDOC_INPUT_DESADV1 generates when the inbound delivery is
*     initially created, now that the rest of the HU's were successfully
*     assigned to the inbound delivery.
*     If this is NOT a reprocess of the idoc (gv_inb_vbeln = false) then
*     this is the first time the idoc is executed and there is no need
*     to generate the '53' message since we'll have done it when
*     BORES_IDOC_INPUT_DESADV1 runs prior to this subroutine.

  LOOP AT  gt_delivery_created INTO DATA(ls_delivery).
    IF sy-tabix EQ 1.
      lv_message = ls_delivery-vbeln.
    ELSE.
      lv_message = |{ lv_message },{ ls_delivery-vbeln }|.
    ENDIF.
  ENDLOOP.

  IF lv_message IS NOT INITIAL.
    DATA(lv_messsage1) = lv_message+0(50).
    DATA(lv_messsage2) = lv_message+050(50).
    DATA(lv_messsage3) = lv_message+100(50).
    DATA(lv_messsage4) = lv_message+150(50).

    "Message:Delivery created, HUs assigned- &&&&
    PERFORM sub_idoc_status_fill USING
            c_idoc_status_ok       "status 53
            gs_idoc_ctrl-docnum    "idoc number
            c_smsg                 "status msg type
            'ZDL'                  "message class
            '032'                  "success msg
            lv_messsage1           "msgv1
            lv_messsage2           "msgv2
            lv_messsage3           "msgv3
            lv_messsage4           "msgv4
            'SUCCESS_MESSAGE'      "routid
            ' '                    "seg num
            ' '.                   "seg field

  ENDIF.

  "No delivery created, only HU assigned sucessfully
  "If there is an error with HU assignment, this part of the
  "program will not get executed
  IF gt_delivery_created IS INITIAL.

    "Message:HUs assigned to delivery(s)
    PERFORM sub_idoc_status_fill USING
            c_idoc_status_ok       "status 53
            gs_idoc_ctrl-docnum    "idoc number
            c_smsg                 "status msg type
            'ZDL'                  "message class
            '031'                  "success msg
            ' '                    "msgv1
            ' '                    "msgv2
            ' '                    "msgv3
            ' '                    "msgv4
            'SUCCESS_MESSAGE'      "routid
            ' '                    "seg num
            ' '.                   "seg field
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_DELIVERY_DATE
*&---------------------------------------------------------------------*
FORM get_delivery_date CHANGING cv_delivery_date TYPE likp-lfdat.

  DATA lv_date_007 TYPE likp-lfdat.
  DATA lv_date_006 TYPE likp-lfdat.
  DATA lv_date_499 TYPE likp-lfdat.
  DATA lv_time_499 TYPE likp-zz_rcpt_time_fm.
  DATA lv_date_x TYPE likp-lfdat.

  "Get Date from Segment '007'
  gs_idoc_data = VALUE #( gt_idoc_data[
                               docnum  =  gs_idoc_ctrl-docnum
                               segnam  =  gc_e1edt13
                               sdata+0(3) = '007' ] OPTIONAL ).
  IF gs_idoc_data IS NOT INITIAL.
    gs_e1edt13 = gs_idoc_data-sdata.

    IF gs_e1edt13-ntanf IS NOT INITIAL.
      lv_date_007 = gs_e1edt13-ntanf.
    ENDIF.
  ENDIF.

  "Get Date from Segment '006'
  gs_idoc_data = VALUE #( gt_idoc_data[
                               docnum  =  gs_idoc_ctrl-docnum
                               segnam  =  gc_e1edt13
                               sdata+0(3) = '006' ] OPTIONAL ).
  IF gs_idoc_data IS NOT INITIAL.
    gs_e1edt13 = gs_idoc_data-sdata.

    IF gs_e1edt13-ntanf IS NOT INITIAL.
      lv_date_006 = gs_e1edt13-ntanf.
    ENDIF.
  ENDIF.

  "Get Date from Segment '499'
  gs_idoc_data = VALUE #( gt_idoc_data[
                               docnum  =  gs_idoc_ctrl-docnum
                               segnam  =  gc_e1edt13
                               sdata+0(3) = '499' ] OPTIONAL ).
  IF gs_idoc_data IS NOT INITIAL.
    gs_e1edt13 = gs_idoc_data-sdata.

    IF gs_e1edt13-ntanf IS NOT INITIAL.
      lv_date_499 = gs_e1edt13-ntanf.

      IF gs_memory-zz_rcpt_date_fm IS INITIAL.
        gs_memory-zz_rcpt_date_fm = gs_e1edt13-ntanf.
        gs_memory-zz_rcpt_time_fm = gs_e1edt13-ntanz.
      ENDIF.
    ENDIF.
  ENDIF.

  "Delivery Date Calculation
  "-------------------------
  "lv_date_diff = lv_date_007 - lv_date_006
  "cv_delivery_date = lv_date_499 + lv_date_diff

  DATA(lv_date_diff) = lv_date_007 - lv_date_006.

  cv_delivery_date = lv_date_499 + lv_date_diff.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  REMOVE_E1EDL20_SEGMENT
*&---------------------------------------------------------------------*
FORM remove_e1edl20_segment.

  "If no Product was picked for that delivery(s) then
  "Remove that E1EDL20 and it’s child segments

  DATA lv_skip TYPE char1.

  LOOP AT gt_idoc_data INTO gs_idoc_data
       WHERE docnum  =  gs_idoc_ctrl-docnum.

    gv_tabix = sy-tabix.

    IF gs_idoc_data-segnam EQ gc_e1edl20.

      CLEAR lv_skip.

      gs_e1edl20 = gs_idoc_data-sdata.

      IF gs_e1edl20-btgew IS INITIAL AND
         gs_e1edl20-anzpk IS INITIAL.

        lv_skip = 'X'.
        DELETE gt_idoc_data INDEX gv_tabix.

      ELSEIF gs_e1edl20-btgew EQ '0.000' AND
       gs_e1edl20-anzpk EQ '00000'.

        lv_skip = 'X'.
        DELETE gt_idoc_data INDEX gv_tabix.

      ENDIF.
    ELSE.

      IF lv_skip EQ 'X'.
        DELETE gt_idoc_data INDEX gv_tabix.
      ENDIF.

    ENDIF.
  ENDLOOP.

ENDFORM.

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_I02554_SHIPSTATUSTOP.     " Global Data
  INCLUDE LZSD_DL_I02554_SHIPSTATUSUXX.     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_I02554_STAPLES_214F...     " Subprograms
* INCLUDE LZSD_DL_I02554_STAPLES_214O...     " PBO-Modules
* INCLUDE LZSD_DL_I02554_STAPLES_214I...     " PAI-Modules

INCLUDE LZSD_DL_I02554_SHIPSTATUSF01.

INCLUDE LZSD_DL_I02554_SHIPSTATUSF02.

INCLUDE LZSD_DL_I02554_SHIPSTATUSF03.

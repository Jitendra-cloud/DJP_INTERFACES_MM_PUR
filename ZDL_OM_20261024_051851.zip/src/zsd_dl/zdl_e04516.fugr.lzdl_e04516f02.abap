*----------------------------------------------------------------------*
***INCLUDE LZDL_E04516F02 .
*----------------------------------------------------------------------*


***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2009 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
************************************************************************
**Include Name:      LZDL_E04516_F02              Create Date: 10/28/09
*
* Supports Function: ZDL_E04516_WEIGHT_DIMEN_CAL
*
**Programmer  : Mark Tomazin                      Last Update: 10/28/09
*
************************************************************************
*
*eject.
*
************************************************************************
*
**Change History:
*
**  Description:                         EDVK         User-Id  Date:
*
*     1) Created by Satish Reddy         EDVK973728   SREDDY  06/04/09
*
*     2) Changed by Mark Tomazin:        EDVK974096   MTOMAZ1 10/28/09
*        a) Fixed Volume Calculations
*
*     3) Changed by Mark Tomazin:        EDVK974096   MTOMAZ1 11/24/09
*         a.  Stop returning the error message when unrestricted stock
*             for a single batch totals 0.  Right now we are returning
*             that error even if 1 batch stock record is 0 and another
*             is non 0.
*         b.  When total batch stock weight = 0, do not create the
*             weights for gross weight raw (GR) or net weight raw (NR).
*         c.  When total batch stock weight = 0, continue to create the
*             other (non GR / NR) weights and dimensions.
*
************************************************************************

*eject.

*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

  DATA: lv_tabix     LIKE sy-tabix,  "CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
        lv_broken(1).            "CMS30690 E0VK9A0LMV SMITHAI 08/04/2016

  IF gt_mch1[] IS NOT INITIAL.
    REFRESH : gt_mska,gt_msku,gt_mara.

    IF NOT gv_plant_exists IS INITIAL.
* Getting batch data from table MSKA based on material, batch and
* plant number
      SELECT matnr werks lgort charg kalab vbeln posnr
        FROM mska
        INTO TABLE gt_mska
         FOR ALL ENTRIES IN gt_mch1
           WHERE matnr = gt_mch1-matnr
             AND charg = gt_mch1-charg.

* Start of  USD 5501162 / CHG 114951
      CLEAR lv_tabix.
      LOOP AT gt_mska INTO gs_mska.
        lv_tabix = sy-tabix.
        READ TABLE gt_mch1 INTO gs_mch1 WITH KEY matnr = gs_mska-matnr
                                                 charg = gs_mska-charg
                                                 werks = gs_mska-werks.
        IF sy-subrc NE 0.
          DELETE gt_mska INDEX lv_tabix.
        ENDIF.
      ENDLOOP.
* End of  USD 5501162 / CHG 114951
*eject.
      gt_mska_with_order_info[] = gt_mska.
      DELETE gt_mska_with_order_info WHERE kalab IS INITIAL.

* Getting batch data from table MSKU based on material, plant and
* batch number
      SELECT matnr werks charg kulab
        FROM msku
        INTO TABLE gt_msku
         FOR ALL ENTRIES IN gt_mch1
           WHERE matnr = gt_mch1-matnr
             AND charg = gt_mch1-charg
             AND werks = gt_mch1-werks   " USD 5501162 / CHG 114951
             AND sobkz = 'W'.

* Getting batch data from table MCHB based on material, plant and
* batch number
      SELECT matnr werks lgort charg clabs
        FROM mchb
        INTO TABLE gt_mchb
         FOR ALL ENTRIES IN gt_mch1
           WHERE matnr = gt_mch1-matnr
             AND werks = gt_mch1-werks    " USD 5501162 / CHG 114951
             AND charg = gt_mch1-charg.
    ELSE.
* Getting batch data from table MSKA based on material and batch
      SELECT matnr werks lgort charg kalab vbeln posnr
        FROM mska
        INTO TABLE gt_mska
         FOR ALL ENTRIES IN gt_mch1
           WHERE matnr = gt_mch1-matnr
             AND charg = gt_mch1-charg.

      gt_mska_with_order_info[] = gt_mska[].
      DELETE gt_mska_with_order_info WHERE kalab IS INITIAL.
*eject.
* Getting batch data from table MSKU based on material, plant and
* batch number
      SELECT matnr werks charg kulab
        FROM msku
        INTO TABLE gt_msku
         FOR ALL ENTRIES IN gt_mch1
           WHERE matnr = gt_mch1-matnr
             AND charg = gt_mch1-charg.
* Getting batch data from table MCHB based on material and
* batch number
      SELECT matnr werks lgort charg clabs
        FROM mchb
        INTO TABLE gt_mchb
         FOR ALL ENTRIES IN gt_mch1
           WHERE matnr = gt_mch1-matnr
             AND charg = gt_mch1-charg.
    ENDIF.
*-->CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
    REFRESH : gt_sddomfld[], gt_part[].
    SELECT * FROM zsdomfld INTO TABLE gt_sddomfld WHERE category  = 'E04516_UNIT'.

*---If the Batch is not in MSKA, MSKU, MCHB but exists as a batch in MCH1, retrieve
*   batch characteristics for it and use the unit weight for further processing.
    LOOP AT gt_mch1 INTO gs_mch1.
      CLEAR lv_broken.
      READ TABLE gt_mska WITH KEY charg = gs_mch1-charg TRANSPORTING NO FIELDS.
      IF sy-subrc = 0.
        CONTINUE.
      ENDIF.
      READ TABLE gt_msku WITH KEY charg = gs_mch1-charg TRANSPORTING NO FIELDS.
      IF sy-subrc = 0.
        CONTINUE.
      ENDIF.
      READ TABLE gt_mchb WITH KEY charg = gs_mch1-charg TRANSPORTING NO FIELDS.
      IF sy-subrc = 0.
        CONTINUE.
      ELSE.
        lv_broken = 'X'.
      ENDIF.

      IF NOT lv_broken IS INITIAL.
        CALL METHOD zcl_u01339_pick_pallet=>read_batch_characteristic
          EXPORTING
            iv_batch                 = gs_mch1-charg
            iv_material              = gs_mch1-matnr
            iv_plant                 = gs_mch1-werks
          IMPORTING
            et_batch_characteristics = gt_batch_char
            et_batch_char_values     = gt_batch_val
            et_messages              = gt_messages.

        LOOP AT gt_batch_val INTO DATA(gs_batch_val) WHERE charact = 'UNIT_CODE'.
          READ TABLE gt_sddomfld INTO DATA(gs_sddomfld) WITH KEY fieldname = 'UNIT_CODE'
                                                                    lowval = gs_batch_val-value_neutral.
          IF sy-subrc = 0.
            MOVE gs_mch1-matnr TO gs_part-matnr.
            MOVE gs_mch1-charg TO gs_part-charg.
            MOVE gs_mch1-werks TO gs_part-werks.
            READ TABLE gt_batch_char INTO DATA(gs_batch_char) WITH KEY charact = gs_sddomfld-comments.
            IF sy-subrc = 0.
              MOVE gs_batch_char-value_from TO gs_part-kalab.
            ENDIF.
            COLLECT gs_part INTO gt_part.
            CLEAR gs_part.
          ENDIF.
        ENDLOOP.
      ENDIF.

    ENDLOOP.
*<--CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
* Getting Material Group from table mara based on material number
    SELECT matnr matkl cuobf FROM mara
      INTO TABLE gt_mara
       FOR ALL ENTRIES IN gt_mch1
         WHERE matnr = gt_mch1-matnr.
*  Added logic for CR#9831
*     Get Units of Measure for Material
    SELECT matnr meinh umrez umren FROM marm
      INTO TABLE gt_marm
       FOR ALL ENTRIES IN gt_mch1
        WHERE matnr = gt_mch1-matnr
        AND   meinh = 'PAL'.

  ENDIF.
ENDFORM.                    " GET_DATA

*eject.

*&---------------------------------------------------------------------*
*&      Form  COLLECT_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM collect_data TABLES batch_in STRUCTURE zcharg
                        batch_err STRUCTURE zberror.

  CLEAR batch_err.

*** Sorting material,batch and plant.
  SORT gt_mska BY matnr charg werks.
  SORT gt_msku BY matnr charg werks.
  SORT gt_mchb BY matnr charg werks.
  SORT gt_part BY matnr charg werks. "CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
**** Collect total stock into final batch internal table
  LOOP AT gt_mska INTO gs_mska.
    MOVE gs_mska-matnr TO gs_batch-matnr.
    MOVE gs_mska-charg TO gs_batch-charg.
    MOVE gs_mska-werks TO gs_batch-werks.
    MOVE gs_mska-kalab TO gs_batch-kalab.

    COLLECT gs_batch INTO gt_batch.
  ENDLOOP.
  LOOP AT gt_msku INTO gs_msku.
    MOVE gs_msku-matnr TO gs_batch-matnr.
    MOVE gs_msku-charg TO gs_batch-charg.
    MOVE gs_msku-werks TO gs_batch-werks.
    MOVE gs_msku-kulab TO gs_batch-kalab.
    COLLECT gs_batch INTO gt_batch.
  ENDLOOP.
  LOOP AT gt_mchb INTO gs_mchb.
    MOVE gs_mchb-matnr TO gs_batch-matnr.
    MOVE gs_mchb-charg TO gs_batch-charg.
    MOVE gs_mchb-werks TO gs_batch-werks.
    MOVE gs_mchb-clabs TO gs_batch-kalab.

    COLLECT gs_batch INTO gt_batch.
  ENDLOOP.
*-->CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
  LOOP AT gt_part INTO DATA(gs_part).
    MOVE gs_part-matnr TO gs_batch-matnr.
    MOVE gs_part-charg TO gs_batch-charg.
    MOVE gs_part-werks TO gs_batch-werks.
    MOVE gs_part-kalab TO gs_batch-kalab.

    COLLECT gs_batch INTO gt_batch.
  ENDLOOP.
*<--CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
*eject.

  IF NOT gt_batch[] IS INITIAL.

    REFRESH gt_matnr_in.

***  Getting Material number and CUOBF
    LOOP AT gt_mara INTO gs_mara.
      MOVE gs_mara-matnr TO gs_matnr_in-matnr.
      MOVE gs_mara-cuobf TO gs_matnr_in-cuobf.
      APPEND gs_matnr_in TO gt_matnr_in.
    ENDLOOP.

** deleting duplicate records
    SORT gt_matnr_in BY matnr cuobf.
    DELETE ADJACENT DUPLICATES FROM gt_matnr_in.

****  Getting Unit code.
    CALL FUNCTION 'ZDL_E04516_GET_MATNR_UNIT_CODE'
      TABLES
        matnr_in  = gt_matnr_in
        matnr_out = gt_matnr_out
        matnr_err = gt_matnr_err.

    SORT gt_matnr_out BY matnr unit_code.
    SORT gt_matnr_err BY matnr.
  ELSE.
    LOOP AT batch_in INTO gs_batch_in.

      MOVE gs_batch_in-matnr TO gs_batch_error-matnr.
      MOVE gs_batch_in-charg TO gs_batch_error-charg.
      MOVE TEXT-021          TO gs_batch_error-error.
      " No entries exist for the selection criteria.
      APPEND gs_batch_error TO batch_err.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " COLLECT_DATA

*eject.

*&---------------------------------------------------------------------*
*&      Form  TYPE_VALUE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->FOR_TYP    text
*      -->EXPORTING  text
*      -->VAL_TYPE   text
*----------------------------------------------------------------------*
FORM type_value

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin 10/28/09
*-----------------------------------------------------------------------

*     TABLES   batch_err STRUCTURE zberror
*     USING    for_typ   TYPE ztyp_1
*              value     TYPE z_char_1
*     CHANGING val_type  TYPE labst.     "Rounding Issue see below

      TABLES   batch_err STRUCTURE zberror
      USING    for_typ   TYPE      ztyp_1
               value     TYPE      z_char_1
      CHANGING val_type  LIKE      gv_packed_with_6_decimals.

*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin 10/28/09
*-----------------------------------------------------------------------

*eject.
  DATA: lv_result      TYPE f,
        lv_wrp_tar_wgt TYPE brgew,
        lv_car_per_pal TYPE i.

  CASE for_typ.

    WHEN TEXT-006. "STOCK

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*-----------------------------------------------------------------------

      IF gs_process-kalab IS INITIAL.
        gv_char_err = 'X'.
      ELSE.
        MOVE gs_process-kalab TO val_type.
      ENDIF.

*     MOVE gs_process-kalab TO val_type. "replaced by above

*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*-----------------------------------------------------------------------

    WHEN TEXT-007. "CHARACTERISTIC
      READ TABLE gs_process-charval INTO gs_charval
      WITH KEY charact = value.
      IF sy-subrc = 0.
        MOVE gs_charval-value_from TO val_type.
      ELSE.
        MOVE gs_process-matnr  TO gs_batch_error-matnr.
        MOVE gs_process-charg  TO gs_batch_error-charg.
        CONCATENATE value TEXT-012 INTO gs_batch_error-error SEPARATED
        BY space.
        APPEND gs_batch_error TO batch_err.
        gv_char_err = 'X'.
      ENDIF.

    WHEN TEXT-008. "CONSTANT
      MOVE value TO val_type.

*eject.

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
    WHEN TEXT-013. "VCHR - Get VC Characteristic Values
*     check not gs_process-vc_charval[] is INITIAL.
      READ TABLE gs_process-vc_charval INTO gs_vc_charval
      WITH KEY characteristic_name = value
      BINARY SEARCH.                        "Table is Sorted


      IF sy-subrc = 0.
        MOVE gs_vc_charval-value_in_float_format TO val_type.
      ELSE.
        MOVE gs_process-matnr  TO gs_batch_error-matnr.
        MOVE gs_process-charg  TO gs_batch_error-charg.

        "Characteristic value is not maintained
        CONCATENATE value TEXT-012 INTO gs_batch_error-error SEPARATED
        BY space.
        APPEND gs_batch_error TO batch_err.
        gv_char_err = 'X'.
      ENDIF.
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
*-----------------------------------------------------------------------
* Start  of Changes by RMYNEED CR9831 02/08/10
*-----------------------------------------------------------------------

    WHEN TEXT-019. "PALT  Pallet conversion factor
      READ TABLE gt_marm INTO gs_marm WITH KEY matnr = gs_process-matnr.
      IF NOT gs_marm-umrez IS INITIAL.
        lv_result = gs_marm-umrez / gs_marm-umren.
        MOVE lv_result TO val_type.
      ENDIF.
    WHEN TEXT-020. "WTAR  Wrapper Tare
      READ TABLE gs_process-charval INTO gs_charval
      WITH KEY charact = 'CARTONS_PER_PALLET'.
      IF sy-subrc = 0.
        MOVE gs_charval-value_from TO lv_car_per_pal.
      ELSE.
        MOVE gs_process-matnr  TO gs_batch_error-matnr.
        MOVE gs_process-charg  TO gs_batch_error-charg.
        CONCATENATE value TEXT-012 INTO gs_batch_error-error SEPARATED
        BY space.
        APPEND gs_batch_error TO batch_err.
        gv_char_err = 'X'.
      ENDIF.

      READ TABLE gs_process-charval INTO gs_charval
      WITH KEY charact = 'WRAPPER_TARE_WEIGHT'.
      IF sy-subrc = 0.
        MOVE gs_charval-value_from TO lv_wrp_tar_wgt.
      ELSE.
        MOVE gs_process-matnr  TO gs_batch_error-matnr.
        MOVE gs_process-charg  TO gs_batch_error-charg.
        CONCATENATE value TEXT-012 INTO gs_batch_error-error SEPARATED
        BY space.
        APPEND gs_batch_error TO batch_err.
        gv_char_err = 'X'.
      ENDIF.

      val_type = lv_wrp_tar_wgt * lv_car_per_pal.

*-----------------------------------------------------------------------
* End  of Changes by RMYNEED CR9831 02/08/10
*-----------------------------------------------------------------------


  ENDCASE.

ENDFORM.                    "TYPE_VALUE

*eject.

*&---------------------------------------------------------------------*
*&      Form  FUNC_VALUE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->FOR_TYP    text
*      -->VAL_TYPE1  text
*      -->VAL_TYPE2  text
*      -->EXPORTING  text
*      -->VAL_TYPE3  text
*----------------------------------------------------------------------*
FORM func_value

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

*  USING    func      TYPE z_func_1
*           val_type1 TYPE labst
*           val_type2 TYPE labst
*  CHANGING val_type3 TYPE labst.  "Rounding Issue Replaced with Below

   USING    func      TYPE z_func_1
            val_type1 LIKE gv_packed_with_6_decimals
            val_type2 LIKE gv_packed_with_6_decimals
   CHANGING val_type3 LIKE gv_packed_with_6_decimals.

*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------


  DATA : lo_ref TYPE REF TO cx_sy_zerodivide.

*eject.

  CASE func.
    WHEN '*'.
      val_type3 = val_type1 * val_type2.
    WHEN '-'.
      val_type3 = val_type1 - val_type2.
    WHEN '+'.
      val_type3 = val_type1 + val_type2.
    WHEN '/'.
      TRY.
          val_type3 = val_type1 / val_type2.
        CATCH cx_sy_zerodivide INTO lo_ref.
          CALL METHOD lo_ref->get_text
            RECEIVING
              result = gv_descrip.
      ENDTRY.
  ENDCASE.

  IF gv_descrip IS NOT INITIAL.
    gv_char_err = 'X'.
  ENDIF.

ENDFORM.                    "FUNC_VALUE

*eject.

*&---------------------------------------------------------------------*
*&      Form  BATCH_VALIDATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->BATCH_IN     text
*      -->BATCH_ERROR  text
*----------------------------------------------------------------------*
FORM batch_validation TABLES batch_in STRUCTURE zcharg
                            batch_err STRUCTURE zberror.

  CLEAR batch_err.

  IF batch_in[] IS NOT INITIAL.
    REFRESH : gt_mch1.
**** Getting Batch data from table MCH1
    SELECT matnr charg FROM mch1
      INTO TABLE gt_mch1
       FOR ALL ENTRIES IN batch_in
         WHERE matnr = batch_in-matnr
           AND charg = batch_in-charg.
  ENDIF.

  REFRESH : batch_err,gt_matnr_in.

**** Vaildate the batch and material
  LOOP AT batch_in INTO gs_batch_in.
    READ TABLE gt_mch1 INTO gs_mch1 WITH KEY matnr = gs_batch_in-matnr
                                             charg = gs_batch_in-charg.
    IF sy-subrc <> 0.
      MOVE gs_batch_in-matnr TO gs_batch_error-matnr.
      MOVE gs_batch_in-charg TO gs_batch_error-charg.
      MOVE TEXT-001          TO gs_batch_error-error.
      "Material & Batch doesn't exists in the table MCH1
      APPEND gs_batch_error TO batch_err.
    ELSE.
      IF NOT gv_plant_exists IS INITIAL.
        MOVE gs_batch_in-werks TO gs_mch1-werks.
        MODIFY gt_mch1 FROM gs_mch1 INDEX sy-tabix TRANSPORTING werks.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    "BATCH_VALIDATION

*eject.

*&---------------------------------------------------------------------*
*&      Form  get_formula_data
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_formula_data.

  REFRESH gt_formula.

  IF gt_process[] IS NOT INITIAL.

* CMS******|ChangedBy:APUNJAA|ChangedOn:06232017|START
* verify is the plant related to Madrid or not based on ZDL_FIELDS tabel entries
    DATA : lv_dlfields TYPE zdl_fields.
    CLEAR lv_dlfields.

    SELECT SINGLE * FROM zdl_fields INTO lv_dlfields
     WHERE category = 'METRIC_CHAR'
       AND fieldname = 'FACILITYID'
       AND lowval = gs_batch_in-werks.

    IF sy-subrc EQ 0.
*  Plant is Madrid releated, then read relevant characterstics from
*  formula table with a prod_ind flag set as 'M'.
      SELECT * FROM zdl_char_formula
      INTO TABLE gt_formula
       FOR ALL ENTRIES IN gt_process
         WHERE unit_code = gt_process-unit_code
           AND matkl     = gt_process-matkl
           AND prod_ind  = 'M'.
    ELSE. " Continue with existing logic
* CMS******|ChangedBy:APUNJAA|ChangedOn:06232017|END

*** getting formula data from table zdl_char_formula
****  based on Unit code and Material group
      SELECT * FROM zdl_char_formula
        INTO TABLE gt_formula
         FOR ALL ENTRIES IN gt_process
           WHERE unit_code = gt_process-unit_code
             AND matkl     = gt_process-matkl.

* CMS******|ChangedBy:APUNJAA|ChangedOn:06232017|START
    ENDIF.
* CMS******|ChangedBy:APUNJAA|ChangedOn:06232017|END

*CMS***** E04516 APUNJAA Weight Dimension Det for Madrid

  ENDIF.

  REFRESH gt_wgtdim.

  IF gt_formula[] IS NOT INITIAL.

**** Get data from Weight Dimension Table
    SELECT type uom FROM zdl_wgtdimension
      INTO TABLE gt_wgtdim
      FOR ALL ENTRIES IN gt_formula
      WHERE type = gt_formula-m_type.
    SORT gt_wgtdim BY type.

  ENDIF.


ENDFORM.                    "get_formula_data

*eject.

*&---------------------------------------------------------------------*
*&      Form  PROCESS_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->BATCH_ERR  text
*----------------------------------------------------------------------*
FORM process_data TABLES batch_err STRUCTURE zberror.

  CLEAR : batch_err.

* Begin of CHG135212

  DATA: BEGIN OF lt_get_these_characteristics OCCURS 0.
          INCLUDE STRUCTURE zsd_characteristic_name.
        DATA: END   OF lt_get_these_characteristics.

  CLEAR lt_get_these_characteristics.
  REFRESH lt_get_these_characteristics.

  get-value-range
       gc_zsdomfld_e04516_vc        " ('E04516_VC')
       gc_zsdomfld_e04516_blank
       gr_atnam.     "   RANGE TABLE

  LOOP AT gr_atnam.
    MOVE gr_atnam-low TO lt_get_these_characteristics-atnam.
    APPEND lt_get_these_characteristics.
  ENDLOOP.

  CLEAR gv_cuobj.

* End of CHG135212

*** Formatting Process internal table with material code
**** Unit code and Characteristics Values.
  REFRESH gt_process.

  LOOP AT gt_batch INTO gs_batch.
    MOVE gs_batch-matnr TO gs_process-matnr.
    MOVE gs_batch-charg TO gs_process-charg.
    MOVE gs_batch-kalab TO gs_process-kalab.

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
* Removed If & Else error handling
*-----------------------------------------------------------------------

*    IF gs_batch-kalab IS NOT INITIAL.  "Removed Check Mark Tomazin

*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*-----------------------------------------------------------------------

*** Getting material group based on material
    READ TABLE gt_mara INTO gs_mara WITH KEY matnr = gs_batch-matnr.
    IF sy-subrc = 0.
      MOVE gs_mara-matkl TO gs_process-matkl.
    ENDIF.

    REFRESH : gt_batch_char,gt_messages.

*eject.

*** Getting Unit code,Characteristics and thier values
    CALL METHOD zcl_u01339_pick_pallet=>read_batch_characteristic
      EXPORTING
        iv_batch                 = gs_batch-charg
        iv_material              = gs_batch-matnr
        iv_plant                 = gs_batch-werks
      IMPORTING
        et_batch_characteristics = gt_batch_char
        et_messages              = gt_messages.

    READ TABLE gt_messages INTO gs_messages WITH KEY msgty ='E'.

    IF sy-subrc = 0.

      CLEAR : gs_batch_error.
*** If error from function module
****  then populate data into error table.
      MOVE gs_batch_in-matnr  TO gs_batch_error-matnr.
      MOVE gs_batch_in-charg  TO gs_batch_error-charg.
      MOVE gs_messages-msgv1  TO gs_batch_error-error.
      APPEND gs_batch_error TO batch_err.

    ELSE.

*** Getting Unit code based on Material.
      READ TABLE gt_matnr_out INTO gs_matnr_out WITH KEY matnr =
      gs_batch-matnr BINARY SEARCH.

      IF sy-subrc = 0.
        gs_process-unit_code = gs_matnr_out-unit_code.

*** Passing Characteristics Values from table
        IF gt_batch_char[] IS NOT INITIAL.
          MOVE gt_batch_char[] TO gs_process-charval.

*-----------------------------------------------------------------------
* Start of the Changes by Mark Tomazin  EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
          PERFORM ck_4_mult_sales_ords_in_batch
                                   TABLES   gt_mska_with_order_info
                                   USING    gs_batch
                                   CHANGING gw_validation_fg.

          IF gw_validation_fg IS NOT INITIAL.

            CLEAR : gs_batch_error.

*** If Multiple Sales Orders Exist in MKSA for the Same Batch key
****  then populate data into error table.
            MOVE gs_batch_in-matnr  TO gs_batch_error-matnr.
            MOVE gs_batch_in-charg  TO gs_batch_error-charg.
            MOVE TEXT-014           TO gs_batch_error-error.
            "Multiple Sales Orders Exist in MSKA for: Material, Plant, Loc,
            "Batch Key Values
            APPEND gs_batch_error TO batch_err.

            CONTINUE.

          ENDIF.


          PERFORM get_vc_characteristics
                                   TABLES   gt_vc_char
                                            gt_mska_with_order_info
                                            lt_get_these_characteristics
                                   USING    gs_batch
                                   CHANGING gv_error_message
                                            gw_validation_fg.

          IF gw_validation_fg IS NOT INITIAL.

*** If we're Unable to Obtain the VC Characteristics Values
****  then populate data into error table.
            MOVE gs_batch_in-matnr  TO gs_batch_error-matnr.
            MOVE gs_batch_in-charg  TO gs_batch_error-charg.
            MOVE gv_error_message   TO gs_batch_error-error.
            "Unable to Obtain the VC Characteristics Values
            APPEND gs_batch_error TO batch_err.
            CONTINUE.
          ENDIF.

          MOVE gt_vc_char[] TO gs_process-vc_charval.
*----------------------------------------------------------------------
* End   of the Changes by Mark Tomazin  EDVK974096   MTOMAZ1 10/28/09
*----------------------------------------------------------------------

        ENDIF.
        APPEND gs_process TO gt_process.

      ELSE.

        CLEAR : gs_batch_error.
*** If Material doesn't have unit code
****  then populate data into error table.
        READ TABLE gt_matnr_err INTO gs_matnr_err WITH KEY matnr =
        gs_batch-matnr BINARY SEARCH.
        MOVE gs_batch_in-matnr  TO gs_batch_error-matnr.
        MOVE gs_batch_in-charg  TO gs_batch_error-charg.
        MOVE gs_matnr_err-error TO gs_batch_error-error.
        APPEND gs_batch_error TO batch_err.
      ENDIF.

    ENDIF.

*----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
* Removed If & Else error handling
*----------------------------------------------------------------------
*
*    ELSE.
*
*      CLEAR : gs_batch_error.
*
**** If Total Batch Value is Zero for Batch and material
*****  then populate data into error table.
*      MOVE gs_batch-matnr  TO gs_batch_error-matnr.
*      MOVE gs_batch-charg  TO gs_batch_error-charg.
*      MOVE text-004           TO gs_batch_error-error.
*      "Batch total value is Zero
*      APPEND gs_batch_error TO batch_err.
*    ENDIF.
*
*----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*----------------------------------------------------------------------



  ENDLOOP.

ENDFORM.                    "PROCESS_DATA

*eject.

*&--------------------------------------------------------------------*
*&      Form  CALCULATE_BATCH_DATA
*&--------------------------------------------------------------------*
*       text
*---------------------------------------------------------------------*
*      -->BATCH_OUT    text
*      -->BATCH_ERROR  text
*---------------------------------------------------------------------*
FORM calculate_batch_data TABLES    batch_out
                          TYPE      zbatch_out_tab batch_err
                          STRUCTURE zberror.

  DATA : ls_zbatch_val TYPE zbatch_val.
  DATA : lv_zvalue TYPE zvalue,
         lv_tabix  TYPE sy-tabix.     " ADHUMBA
  DATA : lt_zbatch_val TYPE zbatch_val_tab.

  REFRESH : batch_out.

  CLEAR : batch_out,batch_err.
  CLEAR : gv_tot_val_type1,gv_tot_val_type2,gv_tot_val_type3.
  CLEAR : gv_tot_val_total.

*----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*----------------------------------------------------------------------

  DATA: gs_process_for_at_command   TYPE ts_process.

  DATA: lv_num_recs_with_same_key TYPE i.
  DATA: ls_process      TYPE ts_process,
        ls_process_hold TYPE ts_process,
        lt_process      TYPE TABLE OF ts_process.

*----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*----------------------------------------------------------------------

*** Sorting the Process and formula internal tables
  SORT gt_process BY matnr charg unit_code matkl.
** consolidate all of the batches into 1 summing the qty.
  CLEAR: ls_process_hold,
         lt_process.
  LOOP AT gt_process INTO ls_process.
    lv_tabix = sy-tabix.
    IF ls_process_hold-charg IS INITIAL.
      ls_process_hold = ls_process.
      ls_process_hold-kalab = 0.
    ENDIF.
    IF ls_process-charg = ls_process_hold-charg.
      ADD ls_process-kalab TO ls_process_hold-kalab.
      DELETE gt_process INDEX lv_tabix.
    ELSE.
      APPEND ls_process_hold TO lt_process.
      ls_process_hold = ls_process.
      DELETE gt_process INDEX lv_tabix.
    ENDIF.
  ENDLOOP.

  IF NOT ls_process_hold IS INITIAL.
    APPEND ls_process_hold TO lt_process.

    gt_process = lt_process.

* DELETE ADJACENT DUPLICATES FROM gt_process
*   COMPARING matnr charg unit_code matkl.
    SORT gt_formula BY unit_code matkl m_type znumber.
  ENDIF.

*eject.


*----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*----------------------------------------------------------------------

*  LOOP AT gt_process INTO gs_process.
*
*    gs_process_for_at_command = gs_process.
*
*    ADD 1 TO lv_num_recs_with_same_key.
*
*    AT END OF   matnr.
*      AT END OF   charg.
*        AT END OF   unit_code.
*          AT END OF   matkl.
*
*            CHECK lv_num_recs_with_same_key > 1.
*
*            CLEAR lv_num_recs_with_same_key.
*
*            DELETE gt_process
*            WHERE
*                   matnr      = gs_process_for_at_command-matnr
*            AND    charg      = gs_process_for_at_command-charg
*            AND    unit_code  = gs_process_for_at_command-unit_code
*            AND    matkl      = gs_process_for_at_command-matkl
*            AND    kalab      IS INITIAL.
*
*          ENDAT.
*        ENDAT.
*      ENDAT.
*    ENDAT.
*  ENDLOOP.

*----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 11/24/09
*----------------------------------------------------------------------

*eject.

* Start of change JWILL68 CD#1172 7/19/2019
* Get all the data before loop so that the table can be read inside
* the loop.
  IF gt_process IS NOT INITIAL.
    SELECT matnr,
           mstae
      FROM mara
      INTO TABLE @DATA(lt_mstae)
      FOR ALL ENTRIES IN @gt_process
      WHERE matnr = @gt_process-matnr.
    IF sy-subrc <> 0.
      CLEAR lt_mstae.
    ENDIF.
  ENDIF.
* End of change JWILL68 CD#1172 7/19/2019
*** Processing final Calculation based on formula table
  LOOP AT gt_process INTO gs_process.

    LOOP AT gt_formula INTO gs_formula
         WHERE unit_code = gs_process-unit_code
           AND matkl     = gs_process-matkl.

      lv_tabix = sy-tabix.       " ADHUMBA

*** IF TYPE1 and FUNC1 has value
      IF  gs_formula-typ_1 IS NOT INITIAL
      AND gs_formula-func_1 IS NOT INITIAL.
* Start of change JWILL68 CD#1172 7/19/2019
* Find out the material if it is coming from class SALES_BALE_1
* Or SALES_BALE_5. To find out this, if MARA-MSTAE = LM, then it
* is coming from SALES_BALE_1 else if it is empty then SALES_BALE_5.

* This logic should trigger only for BSK material group.
        IF gs_process-matkl = 'BSK' AND gs_formula-m_type = 'NM'.
* Read the table LT_MASTE
          DATA(ls_mstae) = VALUE #( lt_mstae[ matnr = gs_process-matnr ] OPTIONAL ).
          CASE ls_mstae-mstae.
            WHEN 'LM'.
              CLEAR: gs_formula-func_2,
                     gs_formula-val_2,
                     gs_formula-typ_2.

            WHEN space.
              gs_formula-func_1 = gs_formula-func_2.
              gs_formula-val_1 = gs_formula-val_2.
              gs_formula-typ_1 = gs_formula-typ_2.

              CLEAR: gs_formula-func_2,
                     gs_formula-val_2,
                     gs_formula-typ_2.

            WHEN OTHERS.
          ENDCASE.
        ENDIF.
        CLEAR ls_mstae.
* End of change JWILL68 CD#1172 7/19/2019

*** Getting Values for Calculation
        PERFORM type_value TABLES batch_err
                USING gs_formula-typ_1
                      gs_formula-val_1
                CHANGING gv_tot_val_type1.
**** ADHUMBA
**** The following was commented to handle the func_1 at end of each
*** ROW Calculation for formula 1
*        PERFORM func_value
**        USING gs_formula-func_1 gv_tot_val_total gv_tot_val_type1
*                CHANGING gv_tot_val_type1.
      ENDIF.

*** IF TYPE2 and FUNC2 has value

      IF  gs_formula-typ_2 IS NOT INITIAL
      AND gs_formula-func_2 IS NOT INITIAL.
*** Getting Values for Calculation
        PERFORM type_value TABLES batch_err
                USING gs_formula-typ_2
                      gs_formula-val_2
                CHANGING gv_tot_val_type2.
*** Calculation for formula 2
        PERFORM func_value
                USING gs_formula-func_2
                      gv_tot_val_type1
                      gv_tot_val_type2
                CHANGING gv_tot_val_type2.
        gv_flag_calc2 = 'X'.
      ENDIF.

*** IF TYPE3 and FUNC3 has value
      IF  gs_formula-typ_3 IS NOT INITIAL
      AND gs_formula-func_3 IS NOT INITIAL.
*** Getting Values for Calculation
        PERFORM type_value TABLES batch_err
                USING gs_formula-typ_3
                      gs_formula-val_3
                CHANGING gv_tot_val_type3.
*** Calculation for formula 3
        PERFORM func_value
                USING gs_formula-func_3
                      gv_tot_val_type2
                      gv_tot_val_type3
                CHANGING gv_tot_val_total.
        gv_flag_calc3 = 'X'.
      ENDIF.

      IF gv_flag_calc3 IS INITIAL.
        IF gv_flag_calc2 IS INITIAL.
          MOVE gv_tot_val_type1 TO gv_row_tot_val.   " ADHUMBA
        ELSE.
          MOVE gv_tot_val_type2 TO gv_row_tot_val.   " ADHUMBA
        ENDIF.
      ENDIF.

**** Start of changes by ADHUMBA
*** Calculation for formula 1
      AT END OF znumber.
        READ TABLE gt_formula INTO gs_formula INDEX lv_tabix.
        PERFORM func_value
                USING gs_formula-func_1
                    gv_row_tot_val
                    gv_tot_val_total
                CHANGING gv_tot_val_total.
      ENDAT.
**** End of changes by ADHUMBA

      CLEAR *gs_formula.
      MOVE-CORRESPONDING gs_formula TO *gs_formula.

      AT END OF m_type.                                     "#EC *
        CLEAR : gs_batch_error,gs_batch_out.
** If FORMULA is Division by zero in the formula table
        IF gv_descrip IS NOT INITIAL.
*** If FORMULA is Division by zero in the formula table for Unit code
****  and material group then populate data into error table.
          MOVE gs_process-matnr  TO gs_batch_error-matnr.
          MOVE gs_process-charg  TO gs_batch_error-charg.
          MOVE TEXT-011          TO gs_batch_error-error.
          "formula cannot be allow divided by zero
          APPEND gs_batch_error TO batch_err.
        ENDIF.

        MOVE *gs_formula-m_type TO ls_zbatch_val-val_type.

*** Populate Weight & Dimension units
        READ TABLE gt_wgtdim INTO gs_wgtdim
        WITH KEY type = ls_zbatch_val-val_type.
        IF sy-subrc = 0.
          MOVE gs_wgtdim-uom TO ls_zbatch_val-unit.
        ENDIF.
*----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*----------------------------------------------------------------------
        MOVE gv_tot_val_total TO gv_tot_val_total_3_decimals.
*       MOVE gv_tot_val_total TO ls_zbatch_val-value. "replaced below
        MOVE gv_tot_val_total_3_decimals TO ls_zbatch_val-value.
*----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*----------------------------------------------------------------------
*** If Conversion is Checked.
        IF *gs_formula-conversion IS NOT INITIAL.
*** Converting the Value
          PERFORM unit_conversion TABLES   batch_err
                                  USING    ls_zbatch_val-val_type
                                  CHANGING ls_zbatch_val-value.
        ENDIF.
*** If Round field has a value
        IF *gs_formula-round IS NOT INITIAL.
*** Roundoff to the next whole number
          MOVE ls_zbatch_val-value   TO gv_rounding_val1.
          MOVE gv_rounding_val1     TO ls_zbatch_val-value.
        ENDIF.
** If FORMULA is not Division by zero in the formula table OR
** If Characteristic value is maintained
        IF gv_char_err IS INITIAL.
**** Moving final Calculated values into BATCH_OUT table.
          SHIFT ls_zbatch_val-value LEFT DELETING LEADING space.
          APPEND ls_zbatch_val TO lt_zbatch_val.
        ENDIF.

        CLEAR : gv_tot_val_total,gv_descrip,
                gv_char_err,ls_zbatch_val.
      ENDAT.

      CLEAR : gv_tot_val_type1,gv_tot_val_type2,
              gv_tot_val_type3,gv_flag_calc3,
              gv_flag_calc2, gv_row_tot_val.   " ADHUMBA

    ENDLOOP.

    IF sy-subrc <> 0.
      CLEAR : gs_batch_error.
*** If FORMULA does not in the formula table for Unit code
****  and material group then populate data into error table.
      MOVE gs_process-matnr  TO gs_batch_error-matnr.
      MOVE gs_process-charg  TO gs_batch_error-charg.
      MOVE TEXT-005          TO gs_batch_error-error.
      "Formula doesn't exist in the formula table for the Unit code and
      "Material group
      APPEND gs_batch_error TO batch_err.

    ELSEIF lt_zbatch_val[] IS NOT INITIAL.
      MOVE gs_process-matnr   TO gs_batch_out-matnr.
      MOVE gs_process-charg   TO gs_batch_out-charg.
      MOVE lt_zbatch_val[]    TO gs_batch_out-batch_val.
      APPEND gs_batch_out TO batch_out.
    ENDIF.

    REFRESH : lt_zbatch_val.

  ENDLOOP.
* Need to delete multiple messages from error table.
  SORT batch_err BY matnr charg error.
  DELETE ADJACENT DUPLICATES FROM batch_err
     COMPARING matnr charg error.
ENDFORM.                    "CALCULATE_BATCH_DATA

*eject.

*&---------------------------------------------------------------------*
*&      Form  UNIT_CONVERSION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM unit_conversion TABLES batch_err STRUCTURE zberror
                     USING val_type TYPE zval_type
                     CHANGING value TYPE zvalue.

  DATA : lv_unit_in  TYPE meins,
         lv_unit_out TYPE meins,
         lv_input    TYPE cgpl_duration.

  CASE val_type.
    WHEN 'GM' OR 'NM'.
      lv_unit_in    = 'LB'.
      lv_unit_out   = 'KG'.
    WHEN 'LM'.
      lv_unit_in    = 'FT'.
      lv_unit_out   = 'M'.
  ENDCASE.
  lv_input = value.

*eject.

** Unit Convertion of final value
  CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
    EXPORTING
      input                = lv_input
      unit_in              = lv_unit_in
      unit_out             = lv_unit_out
    IMPORTING
      output               = lv_input
    EXCEPTIONS
      conversion_not_found = 1
      division_by_zero     = 2
      input_invalid        = 3
      output_invalid       = 4
      overflow             = 5
      type_invalid         = 6
      units_missing        = 7
      unit_in_not_found    = 8
      unit_out_not_found   = 9
      OTHERS               = 10.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    CLEAR : gs_batch_error.
*** Catch EXCEPTION from UNIT_CONVERSION_SIMPLE FM
****  then populate data into error table.
    MOVE gs_process-matnr  TO gs_batch_error-matnr.
    MOVE gs_process-charg  TO gs_batch_error-charg.
    MOVE sy-msgv1          TO gs_batch_error-error.
    APPEND gs_batch_error TO batch_err.
  ELSE.
    value  = lv_input.
  ENDIF.

ENDFORM.                    "UNIT_CONVERSION

*eject.

*&---------------------------------------------------------------------*
*&      Form  REFRESH_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->BATCH_OUT  text
*      -->BATCH_ERR  text
*----------------------------------------------------------------------*
FORM refresh_data
TABLES batch_out TYPE zbatch_out_tab batch_err STRUCTURE zberror.

**** Refreshing the internal table **********************************
  REFRESH : batch_out,batch_err,gt_mch1,gt_mska,gt_msku,gt_mchb,
            gt_mara, gt_batch,gt_process,gt_formula,gt_batch_char,
            gt_messages, gt_matnr_in,gt_matnr_out,gt_matnr_err,
            gt_wgtdim,gt_batch_in, gr_configurable_material.

**** Clearing Variable   ********************************************
  CLEAR :  gv_tot_val_type1,gv_tot_val_type2,gv_tot_val_type3,
           gv_tot_val_total,gv_rounding_val1,gv_flag_calc2,
           gv_descrip,gv_flag_calc3.

ENDFORM.                    "REFRESH_DATA

*End-of-Include

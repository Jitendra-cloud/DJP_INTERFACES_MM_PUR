
PROCESS BEFORE OUTPUT.
  MODULE status_0302.
*
PROCESS AFTER INPUT.
  CHAIN.
    FIELD : vtts-zz_f_see_dt,
            vtts-zz_f_see_ti,
            vtts-zz_f_sel_dt,
            vtts-zz_f_sel_ti,
*           vtts-zz_eta_dt,
*           vtts-zz_eta_ti,
            vtts-dpten,
            vtts-upten,
            vtts-daten,
            vtts-uaten.
    MODULE user_command_0302." ON CHAIN-INPUT.
  ENDCHAIN.

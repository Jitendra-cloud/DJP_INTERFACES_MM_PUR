*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z_ZREQ_FIELDS_TM
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z_ZREQ_FIELDS_TM    .

  PERFORM TABLEPROC.

ENDFUNCTION.

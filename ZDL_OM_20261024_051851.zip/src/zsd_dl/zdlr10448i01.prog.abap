*&---------------------------------------------------------------------*
*&  Include           ZDLR10448I01
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
module status_0100 output.

  refresh lcl_rpt=>gt_excl_ucomm[].

  lcl_rpt=>create_grid( ).


  set pf-status 'STATUS_0100' excluding lcl_rpt=>gt_excl_ucomm.
  set titlebar '0100'.

endmodule.

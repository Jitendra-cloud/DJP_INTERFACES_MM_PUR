*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_CHAR_FORMULA................................*
DATA:  BEGIN OF STATUS_ZDL_CHAR_FORMULA              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_CHAR_FORMULA              .
CONTROLS: TCTRL_ZDL_CHAR_FORMULA
            TYPE TABLEVIEW USING SCREEN '0100'.
*...processing: ZDL_WGTDIMENSION................................*
DATA:  BEGIN OF STATUS_ZDL_WGTDIMENSION              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_WGTDIMENSION              .
CONTROLS: TCTRL_ZDL_WGTDIMENSION
            TYPE TABLEVIEW USING SCREEN '0300'.
*.........table declarations:.................................*
TABLES: *ZDL_CHAR_FORMULA              .
TABLES: *ZDL_WGTDIMENSION              .
TABLES: ZDL_CHAR_FORMULA               .
TABLES: ZDL_WGTDIMENSION               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*"* use this source file for any type declarations (class
*"* definitions, interfaces or data types) you need for method
*"* implementation or private method's signature


TYPES : BEGIN OF tt_matnr,
          matnr     TYPE matnr,
          werks     TYPE werks_d,
          lgnum     TYPE lgnum,
          ucode     TYPE char1,
          wmunit    TYPE meins,
          so_vbeln  TYPE vbeln,
          so_posnr  TYPE posnr,
          fixed_bin TYPE lgpla,
          destn_typ TYPE lgtyp,
          destn_bin TYPE lgpla,
        END OF tt_matnr,

        gs_matnr_data TYPE tt_matnr.

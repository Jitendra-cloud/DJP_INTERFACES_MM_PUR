"Name: \PR:SDBONT06\EX:BONUS_ERMITTELN_01\EI
ENHANCEMENT 0 ZSD_E10754_CHANGE_VBRK.

**    if vbrk-vkorg = '0100'.
**
**      LOOP AT xvbrk.
**        xvbrk-ZZ_VATLOCAL = xvbrk-ZZ_VATLOCAL + 1.
**        MODIFY xvbrk TRANSPORTING ZZ_VATLOCAL.
**      ENDLOOP.
**
**    IF item_prc IS INITIAL.
**      CALL FUNCTION 'RV_INVOICE_DOCUMENT_UPDATE'
**        EXPORTING
**          vbsk_i       = vbsk
**          pricing_type = pricing_type
**        IMPORTING
**          vbsk_e       = vbsk
**        TABLES
**          xkomfk       = xkomfk
**          xkomk        = tkomk
**          xkomp        = tkomp
**          xkomv        = xkomv
**          xthead       = xthead
**          xvbfs        = xvbfs
**          xvbpa        = xvbpa
**          xvbrk        = xvbrk
**          xvbrp        = xvbrp
**          xvbss        = xvbss
**        EXCEPTIONS
**          OTHERS       = 1.
**    ELSE.
***   Collect all relevant condition types for a certain document
**      LOOP AT gt_ip_vbeln_knuma INTO ls_vbeln_knuma
**           WHERE vbeln = vbeln_tab-vbeln.
**        COLLECT ls_vbeln_knuma-knuma INTO lt_knuma.
**      ENDLOOP.
***   Collect all condition types used in involved agreements
**      LOOP AT lt_knuma INTO lv_knuma.
**        LOOP AT gt_ip_knuma_kschl INTO ls_knuma_kschl
**             WHERE knuma = lv_knuma.
**          COLLECT ls_knuma_kschl-kschl INTO lt_kschl.
**        ENDLOOP.
**      ENDLOOP.
***   Collect all relevant items
**      LOOP AT gt_ip_vbeln_posnr INTO ls_vbeln_posnr
**              WHERE vbeln EQ vbeln_tab-vbeln.
**        APPEND ls_vbeln_posnr TO lt_items_to_update.
**      ENDLOOP.
***   Copy all condition types to standard table
**      APPEND LINES OF lt_kschl TO lt_kschl_std.
**      CALL FUNCTION 'RV_INVOICE_DOCUMENT_UPDATE'
**        EXPORTING
**          vbsk_i       = vbsk
**          pricing_type = pricing_type
**        IMPORTING
**          vbsk_e       = vbsk
**        TABLES
**          xkomfk       = xkomfk
**          xkomk        = tkomk
**          xkomp        = tkomp
**          xkomv        = xkomv
**          xthead       = xthead
**          xvbfs        = xvbfs
**          xvbpa        = xvbpa
**          xvbrk        = xvbrk
**          xvbrp        = xvbrp
**          xvbss        = xvbss
**          cond_types   = lt_kschl_std
**          items_to_update = lt_items_to_update
**        EXCEPTIONS
**          OTHERS       = 1.
**      ENDIF.
**
**    endif.

ENDENHANCEMENT.

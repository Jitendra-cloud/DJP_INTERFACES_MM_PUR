*&---------------------------------------------------------------------*
*&  Include           ZDL_C10156_INVENTORY_DEF
*&---------------------------------------------------------------------*
CLASS lcl_inventory_conv DEFINITION FINAL.

  PUBLIC SECTION.

    CLASS-DATA: go_inventory_conversion TYPE REF TO zcl_dl_c10156_inventory_conv,
                go_docking_container    TYPE REF TO cl_gui_docking_container, "custom container
                go_splitter_container   TYPE REF TO cl_gui_splitter_container, "splitter container
                go_top_container        TYPE REF TO cl_gui_container, "top container
                go_bottom_container     TYPE REF TO cl_gui_container, "bottom container
                go_left_container       TYPE REF TO cl_gui_container, "right container
                go_right_container      TYPE REF TO cl_gui_container, "left container
                go_splitter_con_vert    TYPE REF TO cl_gui_splitter_container,
                go_dd_doc_hdr           TYPE REF TO cl_dd_document.

    CLASS-METHODS: main,
      modify_screen,
      download_excel_template,
      button_event,
      drop_down,
      create_insatance,
      file_f4_help
        IMPORTING
          iv_path_flag  TYPE as4flag
        CHANGING
          cv_field_name TYPE string,
      create_container,
      create_header_area_layout,
      display_translation_data,
      display_success_error_data,
      add_toolbar,
      set_title_bar,
      default_screen_value
        EXPORTING
          ev_app_file_path     TYPE string
          ev_translations_file TYPE string
          ev_error_file        TYPE string
          ev_success_file      TYPE string,
      pai_event,
      shcedule_background.

  PRIVATE SECTION.
    CLASS-METHODS :
      get_desktop_location
        EXPORTING
          ev_desktop_loc TYPE string,
      set_column
        CHANGING co_alv                TYPE REF TO cl_salv_table
                 ct_success_error_data TYPE ANY TABLE,
      set_column_optimize
        EXPORTING
          eo_columns TYPE REF TO cl_salv_columns_table
        CHANGING
          co_col_opt TYPE REF TO cl_salv_table,
      hide_coloumn
        CHANGING
          co_columns TYPE REF TO cl_salv_columns_table,
      set_colors
        CHANGING
          co_columns            TYPE REF TO cl_salv_columns_table
          ct_success_error_data TYPE ANY TABLE,
      set_layout
        CHANGING
          co_alv TYPE REF TO cl_salv_table,
      set_functions
        CHANGING
          co_alv TYPE REF TO cl_salv_table,
      set_header
        IMPORTING
          iv_header_text TYPE lvc_title
        CHANGING
          co_alv         TYPE REF TO cl_salv_table,
      add_sort
        CHANGING
          co_alv TYPE REF TO cl_salv_table,
      set_coloumn_text
        CHANGING
          co_columns TYPE REF TO cl_salv_columns_table,
      get_fields_text
        IMPORTING
          it_fields_in_order TYPE zz_tt_zzxrefdetail
        EXPORTING
          et_fields          TYPE zz_tt_zzxrefdetail,
      set_trans_coloumn_text
        CHANGING
          co_columns TYPE REF TO cl_salv_columns_table,
      full_doc_container,
      horizontal_splitter_for_header,
      vertical_splitter_for_alv,
      add_header_text,
      add_text_input
        IMPORTING
          iv_field_text TYPE sdydo_text_element
          io_form_area  TYPE REF TO cl_dd_form_area
          iv_value      TYPE sdydo_text_element,
      display.
ENDCLASS.

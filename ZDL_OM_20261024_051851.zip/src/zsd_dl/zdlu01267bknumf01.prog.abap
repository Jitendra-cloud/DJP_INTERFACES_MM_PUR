*----------------------------------------------------------------------*
***INCLUDE ZDLU01267F01 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  retrieve_data
*&---------------------------------------------------------------------*
*       Retrieve data from container handling unit table via
*       the Container ID and Seal Number.  If not found then an error
*       is raised.
*
*       Also retrieves plant description.  If the plant is not found,
*       then an error is raised.
*----------------------------------------------------------------------*
form retrieve_data .

  data: ls_bookhdr type ts_book_hdr.

* Select booking record based upon the Container Id and Seal Number
  select single * into gs_zvekp from zdlu01267_vekp
    where signi = zdlu01267_0100-signi
      and seal  = zdlu01267_0100-seal.
  if sy-subrc <> 0.
    set cursor field zdlu01267_0100-signi.
*     Container and seal not found on table zdlu01267_vekp
    message e025.
  endif.

* Get the plant from booking header table
  select single bookdoc plant_code into  ls_bookhdr
         from zsd_book_hdr
         where bookdoc    = gs_zvekp-bookdoc.

* Check authority based upon plant
  perform auth_check using ls_bookhdr-werks.

* Get the plant description
  clear gs_t001w.
  select single werks name1 into gs_t001w from t001w
    where werks = ls_bookhdr-werks.


endform.                    " retrieve_data

*&---------------------------------------------------------------------*
*&      Form  validate_confirmation
*&---------------------------------------------------------------------*
*       The confirmation is valid if it exits on the booking header
*       table (ZSD_BOOK_HDR) for the plant entered on the selection
*       screen.
*
*       Since the booking confirmation #s are reused, it is possible
*       for a booking confirmation # to be associated
*       with more than one booking document #.  In this case the
*       greatest booking document # is used.
*
*       If the new booking document # is different than the existing
*       number, then the new number will be used.
*----------------------------------------------------------------------*
form validate_confirmation.

  data: lt_bookhdr type tt_book_hdr,
        ls_bookhdr type ts_book_hdr,
        ls_zsd_book_csz_cfg type zsd_book_csz_cfg,
        ls_zvekp   type zdlu01267_vekp,
        lv_vgm     type zsd_vgm.

* Validate the container size
  select single * into ls_zsd_book_csz_cfg
         from zsd_book_csz_cfg
         where con_size = gs_zvekp-con_size.
  if sy-subrc <> 0.
    "Invalid container size
    message e034.
  endif.

* Validate that Container ID and Seal do not exist on another HU in
* ZDLU01267_VEKP
  select single * into ls_zvekp
         from zdlu01267_vekp
         where venum <> gs_zvekp-venum
           and signi = gs_zvekp-signi
           and seal  = gs_zvekp-seal.
  if sy-subrc = 0.
    "Container ID and Seal already exist on HU & Book Doc &
    message e033 with ls_zvekp-venum ls_zvekp-bookdoc.
  endif.

* Get plant code from booking header table.  This also validates
* that the confirmation # exists.
  select bookdoc plant_code into table lt_bookhdr
         from zsd_book_hdr
         where booknum    = gs_zvekp-booknum.

  if sy-subrc <> 0.
    "Invalid Booking Confirmation Number
    message e027.
  endif.

* Take the greatest book doc
  sort lt_bookhdr descending.
  read table lt_bookhdr into ls_bookhdr index 1.

* Check authority based upon plant
  perform auth_check using ls_bookhdr-werks.

* Update the bookdoc if it has changed.
  if ls_bookhdr-bookdoc <> gs_zvekp-bookdoc.
    gs_zvekp-bookdoc = ls_bookhdr-bookdoc.
  endif.

* Update the plant and description if it has changed.
  if ls_bookhdr-werks <> gs_t001w-werks.
    clear gs_t001w.
    select single werks name1 into gs_t001w from t001w
      where werks = ls_bookhdr-werks.
  endif.

* Update tare  if it has changed
 IF gs_zvekp-tare is not initial and sy-ucomm = 'SAVE'.
  if gs_old_zvekp-tare <> gs_zvekp-tare.

    "recalculate VGM
    lv_vgm = ( gs_zvekp-vgm - gs_old_zvekp-tare ).
    lv_vgm = ( lv_vgm +  gs_zvekp-tare ).
    gs_zvekp-vgm = lv_vgm.
  else.
    "issue warning if size has changed but tare didn't
     if gs_zvekp-con_size <> gs_old_zvekp-con_size.
       "verify container tare weight
        message s024.
     endif.
  endif.
 endif.

endform.                    " validate_confirmation
*&---------------------------------------------------------------------*
*&      Form  save_confirmation
*&---------------------------------------------------------------------*
*       If the confirmation # has changed, then update the change
*       date and update the DB table.
*----------------------------------------------------------------------*
form save_confirmation .

  if gs_old_zvekp-booknum <> gs_zvekp-booknum
    or gs_old_zvekp-seal <> gs_zvekp-seal
    or gs_old_zvekp-con_size <> gs_zvekp-con_size
    or gs_old_zvekp-tare <> gs_zvekp-tare.
    gs_zvekp-aedat = sy-datum.   "change date
    update zdlu01267_vekp from gs_zvekp.
    if sy-subrc <> 0.
      rollback work.
      "Error updating record in zdlu01267_vekp. SY-SUBRC = &
      message e028 with sy-subrc.
    else.
      commit work.
      "Booking Confirmation Number updated successfully.
      message s029.
    endif.
  else.
    "No data was changed.
    message s030.
  endif.

endform.                    " save_confirmation

*eject
*&---------------------------------------------------------------------*
*&      Form  lock_confirmation
*&---------------------------------------------------------------------*
*       Lock the confirmation.  Raise an error if it is locked.
*       The lock is maintained on the HU table VEKP and not the custom
*       table.  This is so that an HU cannot be deleted if someone
*       is in this custom transaction.
*----------------------------------------------------------------------*
form lock_confirmation .

  data: lv_locker type sy-msgv1.

* Attempt to lock the HU
  call function 'ENQUEUE_EVVEKPE'
    exporting
      mode_vekp      = 'E'
      mandt          = sy-mandt
      venum          = gs_zvekp-venum
    exceptions
      foreign_lock   = 1
      system_failure = 2
      others         = 3.

* Raise an informational message if the lock could not be set
  if sy-subrc <> 0.
    lv_locker = sy-msgv1.
    "Booking confirmation is locked by user &.
    message e031 with lv_locker.
  endif.
endform.                    " lock_confirmation
*eject
*&---------------------------------------------------------------------*
*&      Form  auth_check
*&---------------------------------------------------------------------*
*       Checks the users authorization to create or change.
*----------------------------------------------------------------------*
form auth_check  using    us_werks.

* Ensure user has authority to the Plant entered on the selection screen
  authority-check object 'M_MSEG_WWA'
           id 'ACTVT' field '02'           "create OR change mode
           id 'WERKS' field us_werks.         "plant

  if sy-subrc ne 0.
*   No authority for plant &.
    message e032 with us_werks.
  endif.

endform.                    " auth_check

*&---------------------------------------------------------------------*
*&  Include  ZDL_E11555_FREIGHT_COST
*&---------------------------------------------------------------------*
* REQUIREMENT: SAP standard configuration only allows an item category to
* be automatically or manually proposed.  However, based on business
* requirement we need to have SCD item category automatically proposed
* based on the shipping plant. For example, for GCF sales shipment, if
* the shipping plant is from Grande Prairie (ZSDOMFLD entry), we need
* change the default automatically determined item category to ZSCG. The
* item category will be used in ZCO table to determine G/L account.  This
* needs to add include program in SAP function module SD_SCD_ITEMS_CREATE
* and form SCD_ITEM_CREATE.

CHECK sy-tcode NE 'VI02'.

FIELD-SYMBOLS <c_tvftk> TYPE tvftk.

SELECT *
 FROM zsdomfld
  INTO TABLE @DATA(lt_zsdomfld)
   WHERE category = 'E11555_SCD_I'.

"Check Shipment Cost Type
DATA(ls_zsdomfld) = VALUE #( lt_zsdomfld[
*    ls_zsdomfld = VALUE #( lt_zsdomfld[
             fieldname = 'CHECK_SCD_TYPE'
             lowval = i_refobj-tvtk-fkart ] OPTIONAL ).
IF ls_zsdomfld IS INITIAL.
  RETURN.
ENDIF.

"Check Delivery Type
ls_zsdomfld = VALUE #( lt_zsdomfld[
      fieldname = 'CHECK_DELIVERY_TYPE'
      lowval = i_refobj-vtrlk[ 1 ]-lfart ] DEFAULT space ).
IF ls_zsdomfld IS INITIAL.
  RETURN.
ENDIF.

"Check Shipping Plant
DATA(lv_vttp_werks) = VALUE #( i_refobj-vttp[ 1 ]-werks DEFAULT space ).

ls_zsdomfld = VALUE #( lt_zsdomfld[
         fieldname = 'CHECK_SHIPPING_PLANT'
         lowval = lv_vttp_werks ] DEFAULT space ).
IF ls_zsdomfld IS INITIAL.
  RETURN.
ENDIF.

"Check Partner Type
DATA(lv_parvw) = VALUE #( i_refobj-vbpa[ 1 ]-parvw DEFAULT space ).

ls_zsdomfld = VALUE #( lt_zsdomfld[
         fieldname = 'CHECK_PARTNER_TYPE'
         lowval = lv_parvw ] DEFAULT space ).
IF ls_zsdomfld IS INITIAL.
  RETURN.
ENDIF.

LOOP AT c_tvftk ASSIGNING <c_tvftk> WHERE mankz = 'B'.
  IF <c_tvftk> IS ASSIGNED.

    CLEAR ls_zsdomfld.
    ls_zsdomfld = VALUE #( lt_zsdomfld[
             fieldname = 'SET_SHIPMENT_COST_ITEM'
             lowval = <c_tvftk>-fkpty ] DEFAULT space ).

    IF ls_zsdomfld-lowval = <c_tvftk>-fkpty
      AND ls_zsdomfld-highval IS NOT INITIAL.
      <c_tvftk>-fkpty = ls_zsdomfld-highval.
    ENDIF.

  ENDIF.
ENDLOOP.

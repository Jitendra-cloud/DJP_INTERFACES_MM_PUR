************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2007                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: VTTS Z TRANSCATION              Create Date: 05/14/07  *
*                                                                      *
* SAP Name    : Z03732_VTTS_Z_TRANSCATION_I01        Version    :      *
*                                                                      *
* Programmer  : Naveen Parchuri                                        *
*______________________________________________________________________*
* Kishore Thakur      08/12/08  CR-8022  - Implemented gate Exit       *
*                               Reversal logic for external and Z03732 *
*                               Added a Reverse button in screen 303   *
*                               for gate-exit reversal.                *
*                               Transport# EDEK912945                  *
*                               Transport# EDEK913754                  *
* Kishore Thakur/Padma Sunkara  11/05/08  pricef  -E07126, E07127      *
*                               Added functionality for updating dock  *
*                               and trailer id(container id) in        *
*                               screen 303 and in screen 304 added     *
*                               the functionality to capture the intent*
*                               if the user is requested or confirmed  *
*                               and set the code for qualifier         *
*                               accordingly(i.e.IDOC for behalf of     *
*                               distribution center in pickup          *
*                               appointment date/time window.          *
*                               Transport# ESBK9A07VO                  *
* Kishor Thakur     01/21/2009  Unlock shipment and deliveries before
*                               calling
*                               transaction  'ZSDE3999'/'ZSDE1558'
*                               TPR # 02737
*                               TR# EDVK967878
* Kishor Thakur                 Transport EDVK969175
*                               nast-pfld1 = vtts-vstel.
*                               TPR # 30092  Transport# EDVK969175
*                               CH#8887
* Kishor Thakur                 CHG102464 TR#E0VK952755
*                               Allow user to gate exit multiple time
*                               so the gate exit date and time can be
*                               changed
*Take user to first screen after gate exit
*                               is done.
* Kishor Thakur                 CHG#            TR#E0VK965740
*                               Allow only authorized users to execute
*                               picking transaction
* Kishor Thakur/Padma Sunkara  Begin of R16I Big Button Update Staging *
*                              Area changes 10/13/09                   *
* Mallik Aiely                 CMS29557:CHG179961:E03732:Big button    *
*                              export validation - 2/1/2016            *
* Sukanya                      CMS 32822 Heuristic checkbox addition   *
*                              03/16/2018                              *
* Helena Malkowska  11/2018    E0V34502: Add validation to Container ID*
* Helena Malkowska  02/2020    2000006956: Enhancement for Madrid      *
*                              Add the ability to print out the existing
*                              documents EMEA CMR and Delivery Note    *
*&---------------------------------------------------------------------*
*&      Module  tknum_values  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module tknum_values input.
* call transaction 'VT13'.

  call function 'SD_F4_EXTENDED'
    exporting
      mode   = 'HELP'
    exceptions
      others = 0.

  get parameter id 'TNR' field vttk-tknum.


endmodule.                 " tknum_values  INPUT
*&---------------------------------------------------------------------*
*&      Module  exit_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module exit_0100 input.
* exit the transcation
  case sy-ucomm.
    when c_back or
         c_cancel or
         c_exit.
      leave program .
  endcase.
endmodule.                 " exit_0100  INPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module status_0100 input.
  case sy-ucomm.
    when 'CHNLOG'.
* get change history
      perform get_changes_history.
    when 'ENTER' or
         'ENTR'.
      perform validations.
  endcase.

endmodule.                 " STATUS_0100  INPUT
*&---------------------------------------------------------------------*
*&      Module  exit_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module exit_0200 input.

  case sy-ucomm.
    when c_back or
         c_cancel.
      leave to screen 0.
    when c_exit.
      leave program.
  endcase.

endmodule.                 " exit_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module user_command_0200 input.

  clear gv_save.
  case sy-ucomm.
* display the address details
    when 'ADR'.
      perform get_addr_details.
* get change history
    when 'CHNLOG'.
      perform get_changes_history.
* get the details of the record selected.
    when 'CHNG' or
         'DISP'.
      perform get_data_change.

*CMS 33491 Big button Production issue fix-
*enable lock/unlock button instead of save button to do the heuristic protection in screen 200
    when 'LOCK' or 'UNLOCK'.
      perform update_heuristic_field.
*CMS#32822 heuristic protection field updation.
*CMS 33491 BIG BACK CHANGES
*CMS 33491 Big button Production issue fix-
  endcase.
endmodule.                 " USER_COMMAND_0200  INPUT

data : ls_stages_final like gt_stages_final.
*----------------------------------------------------------------------*
*       CLASS lcl_event_receiver IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
class lcl_event_receiver implementation.
  method handle_double_click.
    clear gv_index.

    read table gt_stages_final into ls_stages_final
          index e_row-index.

    if ls_stages_final-tsnum is not initial.
      append ls_stages_final to gt_stages_valid .
    endif.

    clear ls_stages_final.

    if gt_stages_valid[] is not initial.
      gv_index = 1 .
      gv_display = 'X'.
      call screen 0300.
    endif.
  endmethod.                           "handle_double_click
endclass.                    "lcl_event_receiver IMPLEMENTATION
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0300  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module user_command_0300 input.

* incrementing / decreaing  the counter for next or prev buttons
  case sy-ucomm.
    when 'NEXT'.
      gv_index = gv_index + 1 .
      if gv_index gt gv_lines.
        gv_index = gv_lines.
      endif.

    when 'PREV'.
      gv_index = gv_index - 1 .
      if gv_index lt 1 .
        gv_index = 1 .
      endif.

    when 'PREVF'.
      clear  gv_index.
      gv_index = 1.

    when 'NEXTE'.
      clear gv_index.
      describe table gt_stages_valid lines gv_index.
  endcase.

endmodule.                 " USER_COMMAND_0300  INPUT
*&---------------------------------------------------------------------*
*&      Module  exit_0300  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module exit_0300 input.
* unlock shipment
  if gv_change = 'X'.
    perform save_entries.
    perform unlock_shipment.
  endif.
  clear gt_stages_valid.
  refresh gt_stages_valid.
  clear gv_change.
  clear gv_display.
  clear gv_index .

  case sy-ucomm.
    when c_back.
      if gv_tsnum is initial.                               "BCB01
        leave to screen 0.
      else.                                                 "BCB01
        leave program.                                      "BCB01
      endif.                                                "BCB01
    when c_cancel.
      if gv_tsnum is initial.                               "BCB01
        leave to screen 100.
      else.                                                 "BCB01
        leave program.                                      "BCB01
      endif.                                                "BCB01
    when c_exit .
      leave program.
  endcase.

endmodule.                 " exit_0300  INPUT
*&---------------------------------------------------------------------*
*&      Module  TC_CHG1_MASTER_ACTIVE_TAB_GET  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module tc_chg1_master_active_tab_get input.
  case sy-ucomm.
    when c_tc_chg1_master-tab1.
      g_tc_chg1_master-pressed_tab = c_tc_chg1_master-tab1.
    when c_tc_chg1_master-tab2.
      g_tc_chg1_master-pressed_tab = c_tc_chg1_master-tab2.
    when c_tc_chg1_master-tab3.
      g_tc_chg1_master-pressed_tab = c_tc_chg1_master-tab3.
    when c_tc_chg1_master-tab4.
      g_tc_chg1_master-pressed_tab = c_tc_chg1_master-tab4.

  endcase.

endmodule.                 " TC_CHG1_MASTER_ACTIVE_TAB_GET  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0302  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module user_command_0302 input.

* Begin BCB03
* Validate no times in are format 24:00:00
  if vtts-zz_f_see_ti = '240000' or
     vtts-zz_f_sel_ti = '240000' or
     vtts-upten = '240000' or
     vtts-zz_eta_ti = '240000' or
     vtts-uaten      = '240000'.
*   Invalid time - 24:00:00
    message e551(zsd_dl).
  endif.
* End BCB03

* when hitting a different tab or hitting the
* previous or next button
  case sy-ucomm.
    when 'TC_CHG1_MASTER_FC1' or
         'TC_CHG1_MASTER_FC3' or
         'TC_CHG1_MASTER_FC4' or
         'NEXT'               or
         'PREV'               or
         'PREVF'              or
         'NEXTE'.


      perform popup_to_confirm.

* when save button is pressed

    when 'ARRS'.

      if vtts-zz_f_see_dt      <> gt_vtts_old-zz_f_see_dt or
         vtts-zz_f_see_ti+0(4) <> gt_vtts_old-zz_f_see_ti+0(4) or
         vtts-zz_f_sel_dt      <> gt_vtts_old-zz_f_sel_dt or
         vtts-zz_f_sel_ti+0(4) <> gt_vtts_old-zz_f_sel_ti+0(4) or
         vtts-daten            <> gt_vtts_old-daten            or
         vtts-uaten+0(4)       <> gt_vtts_old-uaten+0(4)       or
         vtts-dpten            <> gt_vtts_old-dpten            or
         vtts-upten+0(4)       <> gt_vtts_old-upten+0(4).
        gv_commit = 'X'.
        perform save_changes using gv_commit.
      else.
*  Message changed from 'No changes made' to 'No changes made to
* shipment Transport # ESBK9A07VO  R13W  E07126,E07127 (WM) Z03732
* transaction.
        message s000(zsd_dl) with 'No changes made to Shipment'(043).
      endif.
    when  'CHK1'.
* when validate button is choosen
      gv_commit = ' '.
      perform save_changes using gv_commit.
  endcase.

endmodule.                 " USER_COMMAND_0302  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0303  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module user_command_0303 input.

  data:lt_delivery_header    type standard table of
                                             zdl_delivery_header_status,
  lt_delivery_item      type standard table of zdl_delivery_item_status,
*       ls_shipment_weight TYPE zdl_shipment_weight_validate, "BCB03
*       ls_message TYPE zdl_shipment_weight_message. "BCB03
  lt_shipment_hu_status type standard table of         "BCB03
   zdl_shipment_hu_status,                             "BCB03
  ls_ship_header_status type zdl_ship_header_status.   "BCB03

* Begin BCB03
  data:
    lv_pd_error     type char1,    "error indicator
    lv_pd_vbeln     type vbeln_vl, "delivery
    lv_pd_posnr     type posnr_vl, "delivery item

    lv_cursor_field type char20.
* End BCB03
  data:lv_expkz type likp-expkz,                            "CMS29557
       lv_exnum type likp-exnum,                            "CMS29557
       lr_expvz type ltr_expvz,                             "CMS29557
       lv_expvz type eikp-expvz.                            "CMS29557

  clear: gv_enter_pressed.  "BCB05 insert

* Begin BCB03
* Validate no times in are format 24:00:00
  if vtts-zz_p_ls_ti = '240000' or
     vtts-zz_a_ls_ti = '240000' or
     vtts-zz_p_le_ti = '240000' or
     vtts-zz_a_le_ti = '240000' or
     vtts-uptbg      = '240000' or
     vtts-uatbg      = '240000'.
*   Invalid time - 24:00:00
    message e551(zsd_dl).
  endif.
* End BCB03

* Begin BCB05 insert
* If user changed the Staging Area then make sure Open TO's don't
* exist.
  if t30c-lgbzo ne gv_lgbzo_prev.
*   Validate that open TO's don't exist
    perform validate_if_open_to_exist.
  endif.

* If user tried to clear out the Dock Door and no Staging Area exists
* then make sure Open TO's don't exist.
  if t30b-lgtor is initial and t30c-lgbzo is initial. "blank StagingArea
*   Validate that open TO's don't exist
    perform validate_if_open_to_exist.
  endif.
* End BCB05 insert

  case sy-ucomm.
* when hitting a different tab or hitting the
* previous or next button
    when 'TC_CHG1_MASTER_FC1' or
         'TC_CHG1_MASTER_FC2' or
         'TC_CHG1_MASTER_FC4' or
         'NEXT'               or
         'PREV'               or
         'PREVF'              or
         'NEXTE'.
      perform popup_to_confirm_303.
* when save button is pressed
    when'DISPS'.


* Begin change kthakur CHG102464  TR# E0VK952755
* Give hard error if container id is blank and exit is pressed
* or save button is pressed while in gate exit or load end is complete.

      if ( vtts-zz_a_le_dt is not initial )
            and
         ( vttk-signi is initial ) .

        message e000(zsd_dl) with 'Container ID is blank'.
      endif.
* End change  kthakur CHG102464  TR# E0VK952755 8/12/09

* Begin of changes 11/06/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
* If the actual load end date/time has a value and previously
* didn't have any value, and the trailer-id is blank then give a
* hard error to user and not process any changes
      if  ( gt_vtts_old-zz_a_le_dt is initial and
                  vtts-zz_a_le_dt is not initial and
                  vttk-signi is initial )
        or
          ( ( gt_vtts_old-zz_a_le_ti+0(4) is initial and
             vtts-zz_a_le_ti+0(4) is not initial )
                  and  vttk-signi is initial ).
        message e000(zsd_dl) with 'Container ID is blank'.
        clear: vtts-zz_a_le_dt,
                vtts-zz_a_le_ti.
        gv_commit = ' '.
      endif.

* If the actual load start date/time has a value and previously
* didn't have any value, and the trailer-id is blank then give a
* soft error to user and post the changes
      if ( ( gt_vtts_old-zz_a_ls_dt is initial )
*            AND                         "TR# E0VK952755 kthakur -
*( gt_vtts_old-zz_a_ls_ti+0(4) IS INITIAL ) "TR# E0VK952755 kthakur -
            and
           ( vttk-signi is initial ) )
            or
           ( ( vtts-zz_a_ls_dt is not initial or
              vtts-zz_a_ls_ti+0(4) is not  initial ) and
                           vttk-signi is initial ) .

        message i000(zsd_dl) with 'Container ID is blank'.
        gv_commit = 'X'.
      endif.


* End of changes 11/06/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
      if      vtts-zz_load_ind      <> gt_vtts_old-zz_load_ind      or
              vtts-zz_seal_no      <> gt_vtts_old-zz_seal_no       or
              vtts-zz_load_q1      <> gt_vtts_old-zz_load_q1       or
              vtts-zz_load_u1      <> gt_vtts_old-zz_load_u1       or
              vtts-zz_load_q2      <> gt_vtts_old-zz_load_q2       or
              vtts-zz_load_u2      <> gt_vtts_old-zz_load_u2       or
              vtts-zz_a_ls_dt      <> gt_vtts_old-zz_a_ls_dt       or
              vtts-zz_a_ls_ti+0(4) <> gt_vtts_old-zz_a_ls_ti+0(4)  or
              vtts-zz_a_le_dt      <> gt_vtts_old-zz_a_le_dt       or
              vtts-zz_a_le_ti+0(4) <> gt_vtts_old-zz_a_le_ti+0(4)  or
              vtts-datbg           <> gt_vtts_old-datbg            or
              vtts-uatbg+0(4)      <> gt_vtts_old-uatbg+0(4)       or
* BEGIN of CHANGE / nparchu / v4w3
              vtts-zz_p_ls_dt       <> gt_vtts_old-zz_p_ls_dt      or
              vtts-zz_p_ls_ti+0(4)  <> gt_vtts_old-zz_p_ls_ti+0(4) or
              vtts-zz_p_le_dt       <> gt_vtts_old-zz_p_le_dt      or
              vtts-zz_p_le_ti+0(4)  <> gt_vtts_old-zz_p_le_ti+0(4) or
              vtts-dptbg            <> gt_vtts_old-dptbg           or
              vtts-uptbg+0(4)       <> gt_vtts_old-uptbg+0(4)      or
* end of change / nparchu / v4W3
* Begin of changes 11/06/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
              t30b-lgtor           <>  scr_dock_door               or
              vttk-signi           <>  gv_signi_old                or

* End of changes 11/06/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
*//Begin of R16I Big Button Update Staging Area changes 10/13/09
             t30c-lgbzo           <>  scr_staging_area             or
             vttk-exti2           <>  gv_exti2_old.
*//End of R16I Big Button Update Staging Area changes 10/13/09
        gv_commit = 'X'.
        perform save_changes_303 using gv_commit.
      else.
*  Message changed from 'No changes made' to 'No changes made to
* shipment  11/04/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
        message s000(zsd_dl) with 'No changes made to Shipment'(043).
      endif.

    when 'CHK2'.

* when validate button is choosen
      gv_commit = ' '.
      perform save_changes_303 using gv_commit.

    when 'REVS' or
         'REVE'.
* Begin of changes on /03/18/09 CR# 8887 Transport# EDVK969540
     " Validating the user's security for making changes to the shipment
      " and this stage.
      clear gv_stage_authority.
      perform authority_check_stage using vtts-vstel
                                changing gv_stage_authority .
      if gv_stage_authority = 'T'."Authorization exists.
        " End of chg03/18/09
        gv_commit = 'R'.
        perform rev_date .
      endif. "//end of change 03/18/09 CR# 8887 Transport# EDVK969540
    when 'GE_REV'.
* Begin of changes on /03/18/09 Transport# EDVK969540
     " Validating the user's security for making changes to the shipment
      " and this stage.
      clear gv_gate_exit_rev_auth.
      perform authority_check_gate_exit  .
      if gv_gate_exit_rev_auth = 'T'.
        perform gate_exit_rev_303 using gv_commit.
      endif.  "//end of change 03/18/09 CR# 8887 Transport# EDVK969540

* Begin of change / psunkar /03/26/08 Transport# EDEK911301
* When User presses PICK/PACK button
* validate the user's security for making changes to the shipment
* and this stage .
    when 'PICK'.
* Begin of changes 11/06/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
* If previous value of actual load start date/time is blank and
* container id is blank then give soft error message to user and allow
* changes.
*      IF ( ( gt_vtts_old-zz_a_ls_dt IS INITIAL AND         "Kthakur -
*            gt_vtts_old-zz_a_ls_ti+0(4) IS INITIAL ) AND   "Kthakur -
*                            vttk-signi IS INITIAL ).       "Kthakur -
*        MESSAGE i000(zsd_dl) WITH 'Container ID is blank'. "Kthakur -
*      ENDIF.                                               "Kthakur -
* End of changes 11/06/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
      gv_commit = 'X'.
      "Validating zzboknum from likp
      refresh: gt_likp_zzbooknum.
      if gt_vttp[] is not initial.
        select  vbeln zzbooknum
          into table gt_likp_zzbooknum
          from likp
          for all entries in gt_vttp
          where vbeln = gt_vttp-vbeln
          and zzbooknum <> ''.

*->Begin Of Change/MAIELY/CMS29557
*        IF gt_likp_zzbooknum[] IS NOT INITIAL.
*          MESSAGE e112(zdl_shpstat).
*        ENDIF.

        perform get_export_ind using gt_vttp-vbeln
                               changing lv_expkz
                                        lv_exnum.

        if lv_expkz eq 'X'.

          perform get_mode_transport using lv_exnum
                                     changing lr_expvz
                                              lv_expvz.

          if not lv_expvz in lr_expvz and lr_expvz is not initial.
            message e112(zdl_shpstat).
          endif.
        endif.
*-<End Of Change/MAIELY/CMS29557

     " Validating the user's security for making changes to the shipment
        " and this stage.
        clear gv_stage_authority.
        perform authority_check_stage using vtts-vstel
                                  changing gv_stage_authority .
        if gv_stage_authority = 'T'. " Authorization exists
      " If the status of current stage is not load start then Initiating
   " load-start for the current stage using the current system date/time

          if vtts-zz_sttrg < 3.
            perform load_start_stage_303 using gv_commit.
          endif.
      " After initiating load-start check whether user has authorization
        " for  RF Picking transaction if user has display the RF picking
          " transaction else manual picking portal .
          gv_tknum = vttk-tknum.
          gv_vstel = vtts-vstel.
          set parameter id 'TNR' field gv_tknum.
          set parameter id 'VST' field gv_vstel.
* Unlock shipment and deliveries before calling
* transaction  'ZSDE3999'/'ZSDE1558'   TPR # 02737
* TR# EDVK967878
          perform unlock_shipment.


          call function 'AUTHORITY_CHECK_TCODE'
            exporting
              tcode  = 'ZSDE3999'
            exceptions
              ok     = 0
              not_ok = 2
              others = 3.
          if sy-subrc = 0. " Authorization exists
            call transaction 'ZSDE3999'.  " Domestic Picking Portal
            exit.      "  TR#E0VK965740                 kthakur+
          else. " No authorization
* Begin insert CHG#            TR#E0VK965740    kthakur
* Do not allow user to execute picking without proper authorization.
            call function 'AUTHORITY_CHECK_TCODE'
              exporting
                tcode  = 'ZSDE1558'
              exceptions
                ok     = 0
                not_ok = 2
                others = 3.
            if sy-subrc = 0. " Authorization exists
* End insert CHG#            TR#E0VK965740       kthakur
              call transaction 'ZSDE1558'.  " Domestic Picking
            endif.

          endif.
        endif.
*  Lock Shipment and deliveries after call transaction.
*  TPR # 02737
        perform lock_shipment.    "TR# EDVK967878 TPR # 02737
      endif.


* When User presses Bill of lading button
* validate the user's security for making changes to the shipment
* and this stage .
    when 'BOL'.

*Begin of changes 11/06/08 transport# ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
* If previous value of actual load end date/time is blank and
* container id is blank then give hard error message to user and don't
* allow changes.
      if ( ( gt_vtts_old-zz_a_le_dt is initial and
         gt_vtts_old-zz_a_le_ti+0(4) is initial ) and
                 "vtts-zz_a_le_dt is not initial and
                 vttk-signi is initial ).
        message e000(zsd_dl) with 'Container ID is blank'.
        clear: vtts-zz_a_le_dt,
                vtts-zz_a_le_ti.
        gv_commit = ' '.
      endif.
*//End of changes 11/06/08 transport# ESBK9A07VO  13W  E07126,
* E07127 (WM) Z03732  transaction.
      clear gv_stage_authority.
      perform authority_check_stage using vtts-vstel
                                changing gv_stage_authority .
      if gv_stage_authority = 'T'. " Authorization exists
* begin of change / nparchu / E07780
* comment out the below three performs as the functionality will
* be met by new functional module

        " If the status of current stage is not load end then Initiating
     " load-end for the current stage using the current system date/time
*  perform get_delv_header_itm_status .                "10/01/09
*  perform wm_status. " WM Changes on 03/23/09 transport#
**EDVK969540
** Begin of changes CHG# 104595 09/18/2009
*        " Commented the code to bring the code for Big Button into
*        " alignment across the environment
*        perform dc_validations.                             "10/03/09
* End of changes CHG# 104595 09/18/2009

        refresh : lt_delivery_header,
                  lt_shipment_hu_status,                    "BCB03
                  lt_delivery_item.
        clear  :  ls_ship_header_status.                    "BCB03
*                  ls_shipment_weight,   "BCB03
*                  ls_message.           "BCB03
        call function 'ZSD_DL_MOS_QUALITY_CHECK'
          exporting
            is_vtts                   = vtts
          importing
            es_ship_header_status     = ls_ship_header_status   "BCB03
*           es_shipment_weight_status = ls_shipment_weight "BCB03
*           es_shipment_weight_message = ls_message      "BCB03
          tables
            it_itinerary              = gt_itinerary
            et_shipment_hu_status     = lt_shipment_hu_status "BCB03
            et_delivery_header_status = lt_delivery_header
            et_delivery_item_status   = lt_delivery_item
          exceptions
            facility_not_found        = 1
            others                    = 3.
* raise status message when exceptions
        case sy-subrc.
          when 1.
            message s000(zsd_dl) with 'Facility not found'.
          when 3.
            message s000(zsd_dl)
                 with 'Error populating FM Quality Check' .
        endcase.

* raise status message when veichle overweight
        if ls_ship_header_status-overall_shipment_message_type = 'S'.
          message s000(zsd_dl) with
            ls_ship_header_status-overall_shipment_message.
        elseif ls_ship_header_status-overall_shipment_message_type
          = 'E'.
          message e000(zsd_dl) with
            ls_ship_header_status-overall_shipment_message.
        endif.
* end of change / nparchu

*       Begin BCB03
*       Validate, for all the Deliveries on this Stage, that the Pick
*       and Delivery quantities are the same. If not, generate an error
        perform validate_pick_delivery_qtys changing lv_pd_error
                                                     lv_pd_vbeln
                                                     lv_pd_posnr.
        if lv_pd_error = gc_x. "Error exists
*         Pick qty does not equal Delivery qty for Delivery & &
          message e550(zsd_dl) with lv_pd_vbeln  "delivery
                                    lv_pd_posnr. "delivery item
        endif.
*       End BCB03

        if vtts-zz_sttrg < 4.
          gv_commit = 'X'.
          perform load_end_stage_303 using gv_commit.
        endif.
* >> Begin of Change - CC01 & TPR 31166
        clear sy-batch. "nparchu  " TPR 31165
***** 2000006956 - start
        if lcl_non_us_enh=>gv_non_us = 'N'.
***** 2000006956 - end
          perform print_bill_of_lading_output.
          perform print_packing_list_output.
* << End of Change - CC01
          perform print_canadian_cust_inv_output. "BCB03 insert
          if vtts-zz_sttrg ge 4.
            "Add print Pro Form
            perform print_proforma_zpfm. "SKUMA16 07/10/2019
          endif.
          "Add print Pro Form
          perform print_proforma_zpfd. "CD#366 JWILL68 2/21/2020
***** 2000006956 - start
        elseif lcl_non_us_enh=>gv_non_us = 'Y'.
          lcl_non_us_enh=>print_outputs( ).
        endif.
***** 2000006956 - end
      endif.

* When User presses Gate-Exit button
* validate the user's security for making changes to the shipment
* and this stage .
    when 'GATE'.
      clear gv_stage_authority.
      perform authority_check_stage using vtts-vstel
                                changing gv_stage_authority .
      if gv_stage_authority = 'T'. "Authorization exists
        if  vttk-signi is initial .                    "kthakur +
          message e000(zsd_dl) with 'Container ID is blank'. "kthakur +
        endif.                                "kthakur +
*        IF vtts-zz_sttrg < 6.              "E0VK952755    kthakur-
        gv_commit = 'X'.
        perform gate_exit_stage_303 using gv_commit.
*       BEGIN BCB03
*       If gv_tsnum has a value then the Big Button was called by an
*       external program (ie Daily Shipment Dashboard) so do the leave
*       program to go back to the calling program instead of leave to
*       transaction.
        if gv_tsnum is initial.
          leave to transaction 'Z03732'.    "E0VK952755    kthakur+
        else.
          leave program.
        endif.
*        LEAVE TO TRANSACTION 'Z03732'.    "E0VK952755    kthakur+
*       END BCB03

*        ELSE.                              "E0VK952755    kthakur-
*           MESSAGE i114(zdl_shpstat).      "E0VK952755    kthakur-
*        ENDIF.                             "E0VK952755    kthakur-
      endif.

* End of change / psunkar /03/26/08  Transport# EDEK911301

*   Begin BCB05 insert
*   When the Enter key is pressed, we should use the Screen values of
*   the Dock Door and Staging Area
    when 'ENTR'.
      gv_enter_pressed = gc_x.

  endcase.

endmodule.                 " USER_COMMAND_0303  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0304  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module user_command_0304 input.

* Begin BCB03
* Validate no times in are format 24:00:00
  if vtts-zz_f_pa_ti = '240000' or
     vtts-zz_e_pa_ti = '240000' or
     vtts-zz_l_pa_ti = '240000' or
     vtts-zz_a_ge_ti = '240000'.
*   Invalid time - 24:00:00
    message e551(zsd_dl).
  endif.
* End BCB03

  case sy-ucomm.
* when hitting a different tab or hitting the
* previous or next button
    when 'TC_CHG1_MASTER_FC1'  or
         'TC_CHG1_MASTER_FC2'  or
         'TC_CHG1_MASTER_FC3'  or
         'NEXT'                or
         'PREV'                or
         'PREVF'               or
         'NEXTE'.
* popup to confirm
      perform popup_to_confirm_304.

* when save button is pressed
    when 'GATES'.
      if  vtts-zz_a_ge_dt      <> gt_vtts_old-zz_a_ge_dt      or
          vtts-zz_a_ge_ti+0(4) <> gt_vtts_old-zz_a_ge_ti+0(4) or
          vtts-zz_e_pa_dt      <> gt_vtts_old-zz_e_pa_dt      or
          vtts-zz_e_pa_ti+0(4) <> gt_vtts_old-zz_e_pa_ti+0(4) or
          vtts-zz_l_pa_dt      <> gt_vtts_old-zz_l_pa_dt      or
          vtts-zz_l_pa_ti+0(4) <> gt_vtts_old-zz_l_pa_ti+0(4).
        gv_commit = 'X'.
        perform save_changes_304 using gv_commit.
* Begin of changes 11/04/08 Transport # ESBK9A07VO  R13W  E07126,
* E07127 (WM) Z03732  transaction.
* If pickup appointment date/time have not changed, and if pick-up
*confirmation is requested by carrier or requested by MES then
* confirm it and post the change otherwise set the user-flag to
* requested and post it.
      elseif vtts-zz_e_pa_dt      = gt_vtts_old-zz_e_pa_dt      and
             vtts-zz_e_pa_ti+0(4) = gt_vtts_old-zz_e_pa_ti+0(4) and
             vtts-zz_l_pa_dt      = gt_vtts_old-zz_l_pa_dt      and
             vtts-zz_l_pa_ti+0(4) = gt_vtts_old-zz_l_pa_ti+0(4).
        if ( vtts-zz_pa_conf = 'D' or vtts-zz_pa_conf = 'E' )  and
           rdb_confirmed = 'X'.
          gv_commit = 'X'.
          perform save_changes_304 using gv_commit.
        elseif ( vtts-zz_pa_conf <> 'E' )  and
           rdb_requested = 'X'.
          gv_commit = 'X'.
          perform save_changes_304 using gv_commit.
        else.
          message s000(zsd_dl) with 'No changes made to Shipment'(043).

        endif.
      endif.

    when  'CHK3'.
* when validate button is choosen
      gv_commit = ' '.
      perform save_changes_304 using gv_commit.
  endcase.

endmodule.                 " USER_COMMAND_0304  INPUT
* Begin of changes 11/04/08 Transport # ESBK9A07VO    R13W  E07126,
* E07127 (WM) Z03732  transaction.
*&---------------------------------------------------------------------*
*&      Module  CHECK_DOCK_DOOR  INPUT
*&---------------------------------------------------------------------*
*       Validation for Dock Door
*----------------------------------------------------------------------*
module check_dock_door input.
  data: lv_lgtor like t30b-lgtor,
        lv_lgnum like t320-lgnum,
        lv_werks like lips-werks,
        lv_vbeln like likp-vbeln,
        lv_lgort like lips-lgort,
        lv_ltort like t30bt-ltort.


* Begin BCB05 insert
* User may blank out Dock Door or change the value
* User may blank out the Staging Area or change the value
* End BCB05 insert


  if t30b-lgtor is not initial.
*   select the Plant & Storage Location of any Line Item
    clear lv_werks.
    select single werks lgort
      into (lv_werks, lv_lgort)
      from lips
      where vbeln = gv_vbeln
        and pstyv ne gc_tatx. "BCB08 insert
    if lv_werks is initial.
      message e000(zsd_dl) with
           'No Plant and Storage Location of any line item'(058).
    else.
*     Select the Warehouse
      clear lv_lgnum.
      select single lgnum
        into lv_lgnum
        from t320
        where werks = lv_werks
        and   lgort = lv_lgort.
      if lv_lgnum is initial.
        message e000(zsd_dl) with 'Warehouse not found'(059).
      else.
*       Validate the Door if it is valid against the warehouse delivery
        clear lv_lgtor.
        select single lgtor
          into lv_lgtor
          from t30b
          where lgnum = lv_lgnum
          and   lgtor = t30b-lgtor.
        if sy-subrc = 0.
*         Validate the Door if it is valid against the warehouse of
*         delivery
          clear lv_ltort.
          select single
                 ltort
            into lv_ltort
            from t30bt
            where spras = sy-langu
            and   lgnum = lv_lgnum
            and   lgtor = lv_lgtor.
          if sy-subrc = 0.
            scr_dock_desc = lv_ltort.
          endif.

*         Begin BCB04 insert
*         If this is a Staging Area load (a Staging Area exists) then
*         we can allow the user to change the Dock Door regardless of
*         whether Open TO's exist or not. So, only check for Open TO's
*         if the Staging Area is blank.
          if t30c-lgbzo is initial. "Staging Area screen field
*         End BCB04 insert.

*           Begin BCB03
*           Do not allow the user to change the Dock Door if Open TO's
*           exist
            perform validate_if_open_to_exist.
*           End BCB03

*         Begin BCB04 insert.
          endif. "If t30c-lgbzo is initial
*         End BCB04 insert.

        else.
          "Error message that the door is not valid at the warehouse
          message e000(zsd_dl) with
                     'Door is not valid at the Warehouse'(060).
        endif.
      endif.
    endif.
* Begin BCB05 insert
  else.
*   User may have also spaced out the Dock Door so need to check for
*   Unconfirmed TO's here too

*   Begin BCB04 insert
*   If this is a Staging Area load (a Staging Area exists) then
*   we can allow the user to change the Dock Door regardless of
*   whether Open TO's exist or not. So, only check for Open TO's
*   if the Staging Area is blank.
    if t30c-lgbzo is initial. "Staging Area screen field
*   End BCB04 insert.

*     Begin BCB03
*     Do not allow the user to change the Dock Door if Open TO's
*     exist
      perform validate_if_open_to_exist.
*     End BCB03

*   Begin BCB04 insert.
    endif. "If t30c-lgbzo is initial
*   End BCB04 insert.

* End BCB05 insert
  endif.

endmodule.                 " CHECK_DOCK_DOOR  INPUT
* End of changes 11/04/08 Transport # ESBK9A07VO    R13W  E07126,
* E07127 (WM) Z03732  transaction.
*&---------------------------------------------------------------------*
*&      Module  CREATE_DROPDOWN_BOX  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module create_dropdown_box input.

  data: p_value             type dynpread-fieldvalue,
        lv_dynfld           type help_info-dynprofld,
        lv_fieldname        type dfies-fieldname,
        lv_window_title(30) type c.
  data: begin of lt_lgtor occurs 0,
          lgnum type lgnum,
          lgtor type lgtor,
          ltort type lvs_ltort,
        end of lt_lgtor.
  data: return_values like ddshretval occurs 0 with header line.
  lv_dynfld         = 'T30B-LGTOR'.
  lv_fieldname      =  'LGTOR'.
  lv_window_title   =  'Dock Doors'.
* select the Plant & Storage Location of any Line Item
  clear lv_werks.
  select single werks lgort
    into (lv_werks, lv_lgort)
    from lips
    where vbeln = gv_vbeln
      and pstyv ne gc_tatx. "BCB08 insert
  if lv_werks is initial.

  else.
* Select the Warehouse
    clear lv_lgnum.
    select single lgnum
      into lv_lgnum
      from t320
      where werks = lv_werks
      and   lgort = lv_lgort.
    if lv_lgnum is initial.

    else.
* Validate the Door if it is valid against the warehouse of delivery
      refresh lt_lgtor .
      select lgnum
             lgtor
             ltort
        into table lt_lgtor
        from t30bt
        where spras = sy-langu
        and   lgnum = lv_lgnum.
    endif.
  endif.
*  clear : lv_fieldname,lv_dynfld,lv_window_title,t30b-lgtor.
*  refresh : lt_lgtor,return_values.
  call function 'F4IF_INT_TABLE_VALUE_REQUEST'
    exporting
      retfield        = lv_fieldname
      dynpprog        = sy-cprog
      dynpnr          = sy-dynnr
      dynprofield     = lv_dynfld
      window_title    = lv_window_title
      value_org       = 'S'
    tables
      value_tab       = lt_lgtor
      return_tab      = return_values
    exceptions
      parameter_error = 1
      no_values_found = 2
      others          = 3.
  if sy-subrc <> 0.
    message id sy-msgid type sy-msgty number sy-msgno
            with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  endif.
  read table return_values with key retfield = lv_dynfld.

  if sy-subrc = 0.
    t30b-lgtor = return_values-fieldval.
    clear:  scr_dock_desc, p_value.
    read table lt_lgtor with key lgtor = t30b-lgtor.
    p_value = lt_lgtor-ltort.
    call function 'SET_DYNP_VALUE'
      exporting
        i_field = 'SCR_DOCK_DESC'
        i_repid = sy-repid
        i_dynnr = sy-dynnr
        i_value = p_value.

  endif.

endmodule.                 " CREATE_DROPDOWN_BOX  INPUT

* End of changes 11/04/08 Transport # EDEK913821   R13W  E07126,
* E07127 (WM) Z03732  transaction.
*&---------------------------------------------------------------------*
*&      Module  CHECK_STAGING_AREA  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module check_staging_area input.

  data: lv_lgbzo like t30c-lgbzo.


* select the Plant & Storage Location of any Line Item
  clear lv_werks.
  select single werks lgort
    into (lv_werks, lv_lgort)
    from lips
    where vbeln = gv_vbeln
      and pstyv ne gc_tatx. "BCB08 insert
  if lv_werks is initial.

  else.
* Select the Warehouse
    clear lv_lgnum.
    select single lgnum
      into lv_lgnum
      from t320
      where werks = lv_werks
      and   lgort = lv_lgort.
  endif.

  if t30c-lgbzo = gv_lgbzo.
    exit.
  endif.

  if gv_lgnum is initial.
    "Message here that they can not chnage Staging area
    " for non WM facilities.
  endif.


* Begin BCB05 insert
* Validate that open TO's don't exist if user attempts to change the
* value of the Staging Area (this MODULE is not executed if user spaces
* out the Staging Area
  perform validate_if_open_to_exist.
* End BCB05 insert


* Validate the Staging Area if it is valid against the warehouse
* of delivery
  clear lv_lgbzo.
  if t30b-lgtor is initial.
    select single lgbzo
      into lv_lgbzo
      from t30c
*        WHERE lgnum = gv_lgnum "BCB03 delete
      where lgnum = lv_lgnum "BCB03 insert
      and   lgbzo = t30c-lgbzo.
    if sy-subrc <> 0.
      "Error message that the Staging Area is not valid at the warehouse
      message e000(zsd_dl) with
         'Staging Area is not valid at the Warehouse'(061).
    endif.
  else.
    select single lgbzo
      into lv_lgbzo
      from t30c
*        WHERE lgnum = gv_lgnum "BCB03 delete
      where lgnum = lv_lgnum "BCB03 insert
*        AND   lgtor = t30b-lgtor
      and   lgbzo = t30c-lgbzo.
    if sy-subrc <> 0.
      "Error message that the Staging Area is not valid at the
      "warehouse
      message e000(zsd_dl) with
      'Staging Area is not valid for dock door and Warehouse'(062).
    endif.

  endif.


* Begin BCB05 insert
* Retrieve Staging Area Description if it is not blank
  if t30c-lgbzo is not initial.
    select single lbzot
      from t30ct
      into gv_lbzot
      where lgbzo = t30c-lgbzo.
    if sy-subrc = 0.
      scr_stagearea_desc = gv_lbzot.
    endif.
  endif.
* End BCB05 insert

endmodule.                 " CHECK_STAGING_AREA  INPUT
*&---------------------------------------------------------------------*
*&      Module  CREATE_F4_HELP  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
module create_f4_help input.

  data: p_value_lgbzo             type dynpread-fieldvalue,
        lv_dynfld_lgbzo           type help_info-dynprofld,
        lv_fieldname_lgbzo        type dfies-fieldname,
        lv_window_title_lgbzo(30) type c.

  data: begin of lt_lgbzo occurs 0,
          lgnum type lgnum,
          lgtor type lgtor,
          lgbzo type lgbzo,
          lbzot type lvs_lbzot,
        end of lt_lgbzo.
  data: lt_return_values like ddshretval occurs 0 with header line.
  lv_dynfld_lgbzo         = 'T30C-LGBZO'.
  lv_fieldname_lgbzo      =  'LGBZO'.
  lv_window_title_lgbzo   =  'Staging Area'.

* select the Plant & Storage Location of any Line Item
  if gv_lgnum is initial.
    clear lv_werks.
    select single werks lgort
      into (lv_werks, lv_lgort)
      from lips
      where vbeln = gv_vbeln
        and pstyv ne gc_tatx. "BCB08 insert
    if lv_werks is initial.

    else.
* Select the Warehouse
      clear lv_lgnum.
      select single lgnum
        into lv_lgnum
        from t320
        where werks = lv_werks
        and   lgort = lv_lgort.
    endif.
  else.
    lv_lgnum = gv_lgnum.
  endif.
  if lv_lgnum is initial.
    message s000(zsd_dl) with
     'You can not assign dock door for non-WM locations'(063).
  else.
* Validate the Staging Area it is valid against the warehouse of
* delivery and dock door
    refresh lt_lgbzo .

    select a~lgnum
           a~lgtor
           a~lgbzo
           b~lbzot
      into table lt_lgbzo
      from t30c as a inner join t30ct as b
      on   a~lgnum = b~lgnum
      and  a~lgbzo = b~lgbzo
      where spras = sy-langu
      and   a~lgnum = lv_lgnum.

    call function 'F4IF_INT_TABLE_VALUE_REQUEST'
      exporting
        retfield        = lv_fieldname_lgbzo
        dynpprog        = sy-cprog
        dynpnr          = sy-dynnr
        dynprofield     = lv_dynfld_lgbzo
        window_title    = lv_window_title_lgbzo
        value_org       = 'S'
      tables
        value_tab       = lt_lgbzo
        return_tab      = lt_return_values
      exceptions
        parameter_error = 1
        no_values_found = 2
        others          = 3.
    if sy-subrc <> 0.
      message id sy-msgid type sy-msgty number sy-msgno
              with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    endif.
    read table lt_return_values with key retfield = lv_dynfld_lgbzo.
    if sy-subrc = 0.
      t30c-lgbzo = lt_return_values-fieldval.
      clear:  scr_stagearea_desc, p_value_lgbzo.
      read table lt_lgbzo with key lgbzo = t30c-lgbzo.
      p_value_lgbzo = lt_lgbzo-lbzot.
      call function 'SET_DYNP_VALUE'
        exporting
          i_field = 'SCR_STAGEAREA_DESC'
          i_repid = sy-repid
          i_dynnr = sy-dynnr
          i_value = p_value_lgbzo.
    endif.
  endif.

endmodule.                 " CREATE_F4_HELP  INPUT

* CMS31525|ChangedBy:AMAOLE1|ChangedOn:02212017|START3
module user_command_0301 input.                             "CMS31525

  case sy-ucomm.
    when 'PAH'. "Pickup Appointment History button is pressed

      call function 'Z_EM_EVM_SHIPSTOP_DETAIL'
        exporting
          i_ship_no         = vttk-tknum
          i_loc_code        = vtts-zz_itin_o
          i_stop_type       = '1'
          i_calling_proc    = 'D'
        exceptions
          invalid_stoptype  = 1
          invalid_callproc  = 2
          connection_failed = 3
          others            = 4.
      if sy-subrc <> 0.
* Implement suitable error handling here
      endif.

    when 'DAH'. "Delivery Appointment History button is pressed

      call function 'Z_EM_EVM_SHIPSTOP_DETAIL'
        exporting
          i_ship_no         = vttk-tknum
          i_loc_code        = vtts-zz_itin_d
          i_stop_type       = '2'
          i_calling_proc    = 'D'
        exceptions
          invalid_stoptype  = 1
          invalid_callproc  = 2
          connection_failed = 3
          others            = 4.
      if sy-subrc <> 0.
* Implement suitable error handling here
      endif.

  endcase.

endmodule.
* CMS31525|ChangedBy:AMAOLE1|ChangedOn:02212017|END3

*&---------------------------------------------------------------------*
*&      Module  CHECK_SIGNI  INPUT
*&---------------------------------------------------------------------*
*       Container ID Validation
*       CMS 34502
*----------------------------------------------------------------------*
module check_signi input.

  data: lv_str type string.

  data(lv_chars) =
    ' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789''.-/_`:#' && '‘’'.

  if to_upper( vttk-signi ) cn lv_chars
     or vttk-signi = '#'.

    set cursor field 'VTTK-SIGNI'.

    if vttk-signi = '#'.
      lv_str = 'single character #'.
    else.
      perform get_str_diff using lv_chars vttk-signi lv_str.
    endif.

    gv_commit = ' '.

    message e000(zsd_dl) with
    'Container ID Contains Invalid Character(s):' lv_str.

  endif.

endmodule.

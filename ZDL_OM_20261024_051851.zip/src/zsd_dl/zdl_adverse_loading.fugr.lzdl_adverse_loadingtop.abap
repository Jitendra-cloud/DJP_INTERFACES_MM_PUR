FUNCTION-POOL ZDL_ADVERSE_LOADING.          "MESSAGE-ID ..

* INCLUDE LZDL_ADVERSE_LOADINGD...           " Local class definition

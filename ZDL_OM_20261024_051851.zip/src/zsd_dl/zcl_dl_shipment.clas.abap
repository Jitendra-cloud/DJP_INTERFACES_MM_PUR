class ZCL_DL_SHIPMENT definition
  public
  create public .

*"* public components of class ZCL_DL_SHIPMENT
*"* do not include other source files here!!!
public section.
  type-pools ZMOS .
  type-pools ZWMPP .

  data GT_APPLOG type ZCA_BAL_MSG_TAB .

  methods CONSTRUCTOR
    importing
      !IV_TKNUM type TKNUM
      !IV_ITEN_VIEW type FLAG optional
      !IV_PACK_DATA type FLAG optional
    exceptions
      INVALID_DATA .
  class-methods PACK_PICK_PALLET
    importing
      !IV_TKNUM type TKNUM
      !IV_CREATE_HU_FLAG type CHAR1 optional
      !IV_UPD_SHIP_HISTORY type CHAR1 optional
      !IT_PARENT_CHILD_HU type ZDL_WM_PCEXIDV_TT
    exporting
      !ET_RETURN type BAPIRET2_T
      !ET_APPLOG type ZCA_BAL_MSG_TAB
    exceptions
      INVALID_DATA
      SHIPMENT_HIST_UPD_FAIL .
  class-methods ASSIGN_HU_TO_SHIPMENT
    importing
      !IV_EXIDV type EXIDV
      !IV_SHIPMENT_NUMBER type VTTK-TKNUM
      !IV_HU_OBJ type ref to ZCL_DL_HU optional
    exporting
      !ET_APPLOG type ZCA_BAL_MSG_TAB
      !ET_RETURN type BAPIRET2_T
    exceptions
      INVALID_DATA
      HU_ASSIGNMENT_FAIL .
  class-methods UPDATE_SHIPMENT_HUDATA
    importing
      !IS_VEKP type VEKP optional
      !IT_VEPO type TAB_VEPO optional
      !IV_UPDATE_FLAG type UPDKZ_D
      !IV_SHIPMENT_NUMBER type VTTK-TKNUM
      !IS_EXIDV type VEKP-EXIDV
    exporting
      !ET_APPLOG type ZCA_BAL_MSG_TAB
    exceptions
      SHIPMENT_HIST_UPD_FAIL .
  class-methods PACK_NESTED_HU
    importing
      !IS_PARENT_HU type VEKP
      !IT_SUB_HU type ZWMPP_TT_SUB_HU
      !IV_LGPLA type LEIN-LGPLA optional
      !IV_LGTYP type LEIN-LGTYP optional
    exporting
      !ET_RETURN type BAPIRET2_T
      !ET_APPLOG type ZCA_BAL_MSG_TAB
    exceptions
      PACK_HU_FAIL .
  methods PACK_SHIPMENT_STOP
    importing
      !IV_SEQNM type ZSTOPSEQ
    exporting
      value(ET_APPLOG) type ZCA_BAL_MSG_TAB
      value(ET_RETURN) type BAPIRET2_T
    exceptions
      INVALID_DATA .
  methods GET_STOP_DELIVERIES
    importing
      !IV_SEQNM type ZSTOPSEQ
    returning
      value(RT_VBELN) type TT_VBELN .
  methods GET_STAGE_DELIVERIES
    importing
      !IV_TSNUM type TSNUM
    returning
      value(RT_VBELN) type TT_VBELN .
  methods GET_ITINERARY_DATA
    returning
      value(RT_ITINERARY) type ZMOS_ITINERARY_S .
  methods GET_SHIPMENT_DATA
    returning
      value(RS_DATA) type ZDL_SHIPMENT_DATA .
  class-methods SET_MESSAGE_BUFFER
    returning
      value(RS_APPLOG) type BAL_S_MSG .
  class-methods HANDLE_MESSAGE .
protected section.
*"* protected components of class ZCL_DL_SHIPMENT
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_DL_SHIPMENT
*"* do not include other source files here!!!

  data GS_DATA type ZDL_SHIPMENT_DATA .
  data GT_ITINERARY type ZMOS_ITINERARY_S .
  data GV_MOS_IND type ZSD_DL_MULTI_ORIGIN_SHPMNT_IND .
  data GV_MESSAGE type STRING .
  class-data GT_RETURN type BAPIRET2_T .
  constants GC_ZSD_DL_SHIPMENT type SYMSGID
 value 'ZSD_DL_SHIPMENT'. "#EC NOTEXT
  constants GC_000 type SYMSGNO value '000'. "#EC NOTEXT
  constants GC_MSGTYP_E type SYMSGTY value 'E'. "#EC NOTEXT
  constants GC_MSGTYP_S type SYMSGTY value 'S'. "#EC NOTEXT

  methods READ_SHIPMENT_DATA
    importing
      !IV_TKNUM type TKNUM
    exceptions
      INVALID_DATA .
  methods READ_SHIPMENT_PACK
    importing
      !IV_TKNUM type TKNUM
    exceptions
      INVALID_DATA .
ENDCLASS.



CLASS ZCL_DL_SHIPMENT IMPLEMENTATION.


METHOD assign_hu_to_shipment .
  DATA : ls_huchanged TYPE bapihuheader,
         ls_huheader1    TYPE bapihuheader,
         lv_vpobj  TYPE vpobj,
         lt_return   TYPE STANDARD TABLE OF bapiret2,
         lo_exidv    TYPE REF TO zcl_dl_hu,
         lt_hu_hdr TYPE hum_hu_header_t,
         ls_hu_hdr TYPE LINE OF hum_hu_header_t,
         lv_msg TYPE symsgv,
         ls_applog TYPE bal_s_msg.

  CONSTANTS: lc_status     TYPE vekp-status VALUE '0060'."Delete Status

* VEKP-VPOBJ will have '04' for Shipment once HU is assinged.
  ls_huchanged-hu_exid = iv_exidv.
  ls_huchanged-pack_mat_object = '04'.
  ls_huchanged-pack_mat_obj_key = iv_shipment_number.

** HU object is not passed then create HU object for details
  IF iv_hu_obj IS INITIAL.

    CREATE OBJECT lo_exidv
      EXPORTING
        iv_exidv     = iv_exidv
      EXCEPTIONS
        invalid_data = 1
        hu_not_found = 2
        OTHERS       = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                 RAISING invalid_data.
    ENDIF.
  ELSE.
** HU passed the use that Object reference
    lo_exidv = iv_hu_obj.
  ENDIF.

  CALL METHOD lo_exidv->get_hu_details
    IMPORTING
      et_hu_hdr = lt_hu_hdr[].

** Delete HUs having status DELETE
  DELETE lt_hu_hdr WHERE status EQ lc_status.
* Reading the HU header table with parent HU.
  READ TABLE lt_hu_hdr INTO ls_hu_hdr WITH KEY exidv = iv_exidv.
  IF sy-subrc = 0.
    lv_vpobj = ls_hu_hdr-vpobj.
  ENDIF.

* IF HU is already assigned to the shipment.
* Need to make sure HU assigned to the same shipment or else error.
  IF lv_vpobj = '04' and ls_hu_hdr-vpobjkey NE iv_shipment_number.
** Assigning HU to shipment
    MESSAGE e229 WITH ls_hu_hdr-exidv ls_hu_hdr-vpobjkey INTO lv_msg.
    CALL METHOD zcl_dl_shipment=>handle_message.
    APPEND LINES OF gt_return TO et_return.

    CALL METHOD set_message_buffer
      RECEIVING
        rs_applog = ls_applog.
    APPEND ls_applog TO et_applog.
  ENDIF.

** Check for HU is already assigned to Shipment
  CHECK lv_vpobj NE '04'.

** Assigning HU to shipment
  MESSAGE s222 INTO lv_msg.
  CALL METHOD set_message_buffer
    RECEIVING
      rs_applog = ls_applog.
  APPEND ls_applog TO et_applog.

* Call the FM to assign HU to shipment
  CALL FUNCTION 'BAPI_HU_CHANGE_HEADER'
    EXPORTING
      hukey     = iv_exidv
      huchanged = ls_huchanged
    IMPORTING
      huheader  = ls_huheader1
    TABLES
      return    = lt_return.
  IF lt_return[] IS INITIAL.
* Commit the transaction
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait = 'X'.
**HU assigned to Shipment successfully
    MESSAGE s227 INTO lv_msg.
    CALL METHOD set_message_buffer
      RECEIVING
        rs_applog = ls_applog.
    APPEND ls_applog TO et_applog.
  ELSE.
    APPEND LINES OF lt_return TO et_return.
    ROLLBACK WORK.
** Assign HU to shipment failed
    MESSAGE e219 INTO lv_msg.
    CALL METHOD set_message_buffer
      RECEIVING
        rs_applog = ls_applog.
    APPEND ls_applog TO et_applog.
    MESSAGE e219 RAISING hu_assignment_fail.
  ENDIF.

ENDMETHOD.


METHOD constructor .

  gs_data-tknum = iv_tknum.

  IF iv_pack_data IS INITIAL.
** Read shipment data
    CALL METHOD read_shipment_data
      EXPORTING
        iv_tknum     = iv_tknum
      EXCEPTIONS
        invalid_data = 1
        OTHERS       = 2.
    IF sy-subrc <> 0.
      MESSAGE e201 WITH iv_tknum RAISING invalid_data.
    ENDIF.

  ELSE.
** Pack view data is selected
    CALL METHOD read_shipment_pack
      EXPORTING
        iv_tknum     = iv_tknum
      EXCEPTIONS
        invalid_data = 1
        OTHERS       = 2.
    IF sy-subrc <> 0.
      MESSAGE e201 WITH iv_tknum RAISING invalid_data.
    ENDIF.
  ENDIF.

  IF iv_iten_view IS NOT INITIAL.
** Itinerary view data
    CALL FUNCTION 'ZSD_DL_MOS_ITINERARY_VIEW'
      IMPORTING
        e_mos_ind                      = gv_mos_ind
      TABLES
        t_vtts                         = gs_data-vtts[]
        t_vttp                         = gs_data-vttp[]
        t_vtsp                         = gs_data-vtsp[]
        t_itinerary                    = gt_itinerary[]
      EXCEPTIONS
        invalid_input                  = 1
        shipment_not_found             = 2
        no_deliveries_found            = 3
        no_stages_on_shipment          = 4
        no_authority                   = 5
        deliveries_unassigned_to_stage = 6
        flex_multi_origin_not_allowed  = 7
        OTHERS                         = 8.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              RAISING invalid_data.
    ENDIF.
  ENDIF.
ENDMETHOD.


METHOD get_itinerary_data .
** Itinerary data

  REFRESH rt_itinerary.

  rt_itinerary[] = gt_itinerary[].

ENDMETHOD.


METHOD get_shipment_data .
  rs_data = gs_data.
ENDMETHOD.


METHOD get_stage_deliveries .

  DATA : ls_itinerary  TYPE zmos_itinerary,
         ls_deliveries TYPE zmos_deliveries,
         lv_vbeln      TYPE vbeln.

  REFRESH rt_vbeln.
** Read deliveries for the stage
  LOOP AT gt_itinerary INTO ls_itinerary WHERE tsnum = iv_tsnum.
    LOOP AT ls_itinerary-deliveries INTO ls_deliveries.
      lv_vbeln = ls_deliveries-vbeln.
      COLLECT lv_vbeln INTO rt_vbeln.
    ENDLOOP.
  ENDLOOP.

ENDMETHOD.


METHOD get_stop_deliveries .

  DATA : ls_itinerary  TYPE zmos_itinerary,
         ls_deliveries TYPE zmos_deliveries,
         lv_vbeln      TYPE vbeln.

  REFRESH rt_vbeln.

** Read deliveries for stop passed
  READ TABLE gt_itinerary INTO ls_itinerary WITH KEY seqnm = iv_seqnm.
  IF sy-subrc EQ 0.
    LOOP AT ls_itinerary-deliveries INTO ls_deliveries.
      lv_vbeln = ls_deliveries-vbeln.
      COLLECT lv_vbeln INTO rt_vbeln.
    ENDLOOP.
  ENDIF.

ENDMETHOD.


METHOD handle_message .
  DATA ls_message  TYPE bapiret2.
  FIELD-SYMBOLS : <lt_return> TYPE bapiret2_t.
  ls_message-type   = sy-msgty.
  ls_message-id     = sy-msgid.
  ls_message-number = sy-msgno.
  WRITE sy-msgv1 TO ls_message-message_v1 USING EDIT MASK '==ALPHA'.
  WRITE sy-msgv2 TO ls_message-message_v2 USING EDIT MASK '==ALPHA'.
  WRITE sy-msgv3 TO ls_message-message_v3 USING EDIT MASK '==ALPHA'.
  WRITE sy-msgv4 TO ls_message-message_v4 USING EDIT MASK '==ALPHA'.
  MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
          WITH ls_message-message_v1 ls_message-message_v2
               ls_message-message_v3 ls_message-message_v4
          INTO ls_message-message.
*  ASSIGN gt_return->* TO <lt_return>.
   ASSIGN gt_return TO <lt_return>.
  APPEND ls_message TO <lt_return>.
ENDMETHOD.


METHOD pack_nested_hu .
  DATA:  ls_hu_ref_id                TYPE vpobjkey,
         ls_hu_header_main           TYPE huhdr_proposal,
         ls_hu_items_proposal        TYPE huitm_proposal,
         ls_mm_data                  TYPE hum_plant_stloc,
         ls_hu_messages              TYPE huitem_messages,
         lv_mblnr                    TYPE mblnr,
         lt_hu_header_main           TYPE huhdr_prop,
         lt_hu_header_capacity       TYPE huhdr_cap,
         lt_hu_header_additional     TYPE huhdr_add,
         lt_hu_header_transport      TYPE huhdr_tra,
         lt_hu_items_proposal        TYPE huitm_prop,
         lt_hu_serial_nr_list        TYPE huitem_sernr,
         lt_unpack_hu_ext            TYPE hum_exidv_t,
         ls_unpack_hu_ext            TYPE hum_exidv,
         lt_unpack_hu_int            TYPE hum_venum_t,
         ls_unpack_hu_int            TYPE hum_venum,
         lt_hu_messages              TYPE huitem_messages_t,
         lt_return                   TYPE STANDARD TABLE OF bapiret2,
         lv_hu_id                    TYPE rlmob-clenum,
         lv_new_hu                   TYPE c,
         lv_update_db                TYPE c,
         lv_create_hu                TYPE c,
         ls_hu_ref_doc               TYPE hum_object,
         lv_save_step(4)             TYPE c,
         lv_pack_type(3)             TYPE c,
         lv_msgtyp                   TYPE symsgty,
         ls_vekp                     TYPE vekp,
         lv_repack                   TYPE c,
         lv_message                  TYPE symsgv,
         ls_applog                  TYPE bal_s_msg.

  FIELD-SYMBOLS <ls_hu_item> TYPE zwmpp_typ_sub_hu.

  CONSTANTS: lc_package(2) TYPE c  VALUE '12',
             lc_item(4)    TYPE c  VALUE 'ITEM',
             lc_hu(2)      TYPE c  VALUE 'HU'.

** If Parent Handling unit passed then repack Parent and child handling
** units, If Parent HU is not passed then create new Parent HU with
** child HUs details passed to Items proposal.
  IF NOT is_parent_hu IS INITIAL.
    ls_vekp = is_parent_hu.
    lv_repack = zwmpp_gc_x.
  ENDIF.

  LOOP AT it_sub_hu ASSIGNING  <ls_hu_item>.
    ls_hu_items_proposal-exidv      = is_parent_hu-exidv.  "New ext HU
    ls_hu_items_proposal-venum      = ls_vekp-venum.
    ls_hu_items_proposal-velin      = '3'.       "Record 1 for creation
    ls_hu_items_proposal-p_material = ls_vekp-vhilm.  "Package material
    ls_hu_items_proposal-quantity   = '1'.
    ls_hu_items_proposal-veanz      = '1'.
    ls_hu_items_proposal-lgtyp      = iv_lgtyp.
    ls_hu_items_proposal-lgpla      = iv_lgpla.            "Storage Bin
    ls_hu_items_proposal-sub_hu_venum = <ls_hu_item>-venum.
    ls_hu_items_proposal-sub_hu_exidv = <ls_hu_item>-exidv.
    APPEND ls_hu_items_proposal TO lt_hu_items_proposal.

    IF NOT lv_repack IS INITIAL.
      ls_unpack_hu_ext-exidv = <ls_hu_item>-exidv.
      APPEND ls_unpack_hu_ext TO lt_unpack_hu_ext.
      CLEAR ls_unpack_hu_ext.

      ls_unpack_hu_int-venum = <ls_hu_item>-venum.
      APPEND ls_unpack_hu_int TO lt_unpack_hu_int.
      CLEAR ls_unpack_hu_int.
    ENDIF.

* One HU can have multiple batches . The Function Module will be
* invoked at the end of each new HU.
    AT LAST.
* Need to update the gv_hu_id with some value.
      lv_hu_id =   ls_vekp-exidv.
* Save step will be for ITEM since HU will be created with ITEMS.
* Also, Pack type will be 'HU' and the gv_create_hu flag will be set
*because we are going to create new HU's. Also, update flag gv_update_db
* will be set.
      lv_save_step = lc_item. " 'ITEM'
      lv_pack_type = lc_hu.      "'HU'
      IF lv_repack IS INITIAL.
        lv_new_hu    = 'Y'.
      ELSE.
        lv_new_hu    = ''.
        ls_unpack_hu_ext-exidv = ls_vekp-exidv.
        APPEND ls_unpack_hu_ext TO lt_unpack_hu_ext.
        CLEAR ls_unpack_hu_ext.

        ls_unpack_hu_int-venum = ls_vekp-venum.
        APPEND ls_unpack_hu_int TO lt_unpack_hu_int.
        CLEAR ls_unpack_hu_int.
      ENDIF.

      lv_update_db = 'X'.

*Update the Header structure with new external HU  entered on the second
*screen against the batch.Also, the package material will be added to
*the field VHILM.
      ls_hu_header_main-exidv  = ls_vekp-exidv.     "New External HU
      ls_hu_header_main-vhilm  = ls_vekp-vhilm.     "Package Material
      CLEAR ls_hu_header_main-status.
      APPEND ls_hu_header_main TO lt_hu_header_main.

      IF NOT lv_repack IS INITIAL.
        ls_hu_ref_doc-objkey = ls_vekp-exidv.
      ENDIF.
      ls_hu_ref_doc-object = lc_package.                    "'12'.

*Update the ls_mm_data with Plant and Warehouse Number from VEKP.The
* MOVE storage location will be the new HU managed storage location .
* for eg HU01

      ls_mm_data-plant                 =  ls_vekp-werks.        "Plant
      ls_mm_data-whse_no               =  ls_vekp-lgnum. "Warehouse Num
      ls_mm_data-stge_type             =  iv_lgpla.      "Storage Type
      ls_mm_data-stge_bin              =  iv_lgtyp.      "Storage Bin

      CALL FUNCTION 'HU_PACKING_REFRESH'.
      CALL FUNCTION 'SERIAL_INTTAB_REFRESH' .

      MESSAGE s223 INTO lv_message.
      CALL METHOD set_message_buffer
        RECEIVING
          rs_applog = ls_applog.
      APPEND ls_applog TO et_applog.

* Call the function module to pack the new HU's
      CALL FUNCTION 'PACK_HANDLING_UNIT'
        EXPORTING
          i_hu_id                = lv_hu_id
          i_new_hu               = lv_new_hu
          i_update_db            = lv_update_db
          i_create_hu            = lv_create_hu
          i_reference_object     = ls_hu_ref_doc
          i_mm_data              = ls_mm_data
          i_hu_header_main       = lt_hu_header_main[]
          i_hu_header_capacity   = lt_hu_header_capacity[]
          i_hu_header_additional = lt_hu_header_additional[]
          i_hu_header_transport  = lt_hu_header_transport[]
          i_hu_items             = lt_hu_items_proposal[]
          i_hu_serial_nr         = lt_hu_serial_nr_list[]
          i_save_step            = lv_save_step
          i_pack_activity        = lv_pack_type
          i_hu_external          = lt_unpack_hu_ext[]
          i_hu_internal          = lt_unpack_hu_int[]
        IMPORTING
          o_hu_ref_id            = ls_hu_ref_id
          o_hu_messages          = lt_hu_messages[]
        EXCEPTIONS
          input_missing          = 01
          not_possible           = 02
          fatal_error            = 03
          operation_failed       = 04
          error_message          = 99.

      IF sy-subrc = 0.
        COMMIT WORK AND WAIT.
        CLEAR lv_mblnr.
        LOOP AT lt_hu_messages INTO ls_hu_messages
                       WHERE msgid = 'HUGENERAL'
                         AND msgty = zwmpp_gc_s
                         AND msgno = '309'.
          IF NOT ls_hu_messages-msgv1 IS INITIAL.
            lv_mblnr = ls_hu_messages-msgv1.
            EXIT.
          ENDIF.
        ENDLOOP.
        IF lv_mblnr IS NOT INITIAL.
** Packed successfully Material document
          MESSAGE s216 WITH lv_mblnr INTO lv_message.
          CALL METHOD set_message_buffer
            RECEIVING
              rs_applog = ls_applog.
          APPEND ls_applog TO et_applog.

        ELSE.
** Packed Handling unit successfully
          MESSAGE s224 INTO lv_message.
          CALL METHOD set_message_buffer
            RECEIVING
              rs_applog = ls_applog.
          APPEND ls_applog TO et_applog.
        ENDIF.
        lv_msgtyp = zwmpp_gc_s.     "'S'.

      ELSE.
        ROLLBACK WORK.
** Packing Nested HU fail
        MESSAGE e225 INTO lv_message.
        CALL METHOD set_message_buffer
          RECEIVING
            rs_applog = ls_applog.
        APPEND ls_applog TO et_applog.

        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               RAISING pack_hu_fail.
      ENDIF.

    APPEND LINES OF lt_return TO et_return.
* Clear data
    REFRESH : lt_hu_items_proposal,
              lt_unpack_hu_ext,
              lt_unpack_hu_int,
              lt_hu_header_main.
    CLEAR ls_mm_data.
  ENDAT.
ENDLOOP.
ENDMETHOD.


METHOD pack_pick_pallet .

  TYPES:  BEGIN OF tt_vekp,
            exidv    TYPE exidv,
            venum    TYPE venum,
            vhilm    TYPE vhilm,
            werks    TYPE werks_d,
            lgort    TYPE lgort_d,
            matnr    TYPE matnr,
            charg    TYPE charg,
            bestq    TYPE bestq,
            sobkz    TYPE sobkz,
            sonum    TYPE lvs_sonum,
            vemeh    TYPE vemeh,
            vemng    TYPE vemng,
          END OF tt_vekp.

  DATA: lt_sub_hu          TYPE zwmpp_tt_sub_hu,
        ls_cexidv          TYPE zdl_cexidv,
        ls_sub_hu          TYPE zwmpp_typ_sub_hu,
        ls_parent_hu       TYPE exidv,
        ls_parent_hu_vekp  TYPE vekp,
        lt_vekp_child      TYPE STANDARD TABLE OF tt_vekp,
        ls_vekp_child      TYPE tt_vekp,
        lt_return          TYPE bapiret2_t,
        ls_return          TYPE bapiret2,
        ls_huhdr           TYPE zdl_hu_hdr,
        ls_parent_child_hu TYPE zdl_wm_pcexidv,
        lt_child_objs      TYPE zdl_wm_hu_obj_t,
        ls_child_objs      TYPE zdl_wm_hu_obj_s,
        lt_child_exidv     TYPE hum_exidv_t,
        lt_child_head      TYPE hum_hu_header_t,
        ls_child_head      TYPE vekpvb,
        lt_child_item      TYPE hum_hu_item_t,
        ls_child_item      TYPE vepovb,
        lt_parent_hu       TYPE hum_hu_header_t,
        ls_parent          TYPE LINE OF hum_hu_header_t,
        lo_parent_hu       TYPE REF TO zcl_dl_hu,
        ls_applog          TYPE bal_s_msg,
        lt_applog          TYPE zca_bal_msg_tab,
        lv_message         TYPE symsgv,
        ls_t001l           TYPE t001l,
        lv_exidv      TYPE bapihukey-hu_exid,
        ls_head       TYPE bapihuhdrproposal,
        lt_hu_item    TYPE zdl_hu_item_t,
        ls_hu_item    TYPE bapihurepack.

  CONSTANTS: lc_status     TYPE vekp-status VALUE '0060',"Delete Status
             lc_insert     TYPE c           VALUE 'I',    "Insert Flag
             lc_c          TYPE c VALUE 'C'.     " In the warehouse

** Group the Child HUs by Parent HU.
  LOOP AT it_parent_child_hu INTO ls_parent_child_hu.
    CLEAR: lt_sub_hu, lt_vekp_child.

* Parent HU.
    ls_parent_hu = ls_parent_child_hu-pexidv.

* Get the child HU's.
    LOOP AT ls_parent_child_hu-cexidv INTO ls_cexidv.
      APPEND ls_cexidv TO lt_sub_hu.
    ENDLOOP.

    lt_child_exidv[] = ls_parent_child_hu-cexidv[].

** Creae HU objects for Child HUs
    CALL METHOD zcl_dl_hu=>get_hu_objects
      EXPORTING
        it_exidv      = lt_child_exidv
      RECEIVING
        rt_hu_objects = lt_child_objs
      EXCEPTIONS
        invalid_data  = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*   Need to continue with next parent HU.
      CONTINUE.
    ENDIF.

    LOOP AT lt_child_objs INTO ls_child_objs.
** Get details of HU
      CALL METHOD ls_child_objs-hu_obj->get_hu_details
        IMPORTING
          et_hu_hdr = lt_child_head[]
          et_hu_itm = lt_child_item[].

** Populate internal table with the Header and Item details
      LOOP AT lt_child_head INTO ls_child_head.
        ls_vekp_child-exidv = ls_child_head-exidv.
        ls_vekp_child-venum = ls_child_head-venum.
        ls_vekp_child-vhilm = ls_child_head-vhilm.

        LOOP AT lt_child_item INTO ls_child_item
             WHERE venum = ls_child_head-venum.
          ls_vekp_child-werks = ls_child_item-werks.
          ls_vekp_child-lgort = ls_child_item-lgort.
          ls_vekp_child-matnr = ls_child_item-matnr.
          ls_vekp_child-charg = ls_child_item-charg.
          ls_vekp_child-bestq = ls_child_item-bestq.
          ls_vekp_child-sobkz = ls_child_item-sobkz.
          ls_vekp_child-sonum = ls_child_item-sonum.
          ls_vekp_child-vemeh = ls_child_item-vemeh.
          ls_vekp_child-vemng = ls_child_item-vemng.
          APPEND ls_vekp_child TO lt_vekp_child.
        ENDLOOP.
      ENDLOOP.
    ENDLOOP.

    SORT lt_vekp_child BY exidv.

* If create Parent HU flag is set, then create Parent HU , else use
* the the one provided by the calling program.
    IF iv_create_hu_flag = 'X'.
      LOOP AT lt_vekp_child INTO ls_vekp_child WHERE werks IS NOT INITIAL.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0.

        CALL METHOD zcl_dl_hu=>get_pack_mat
          EXPORTING
            iv_werks         = ls_vekp_child-werks
          IMPORTING
            ev_matnr         = ls_huhdr-pack_mat
          EXCEPTIONS
            no_packmat_found = 1
            OTHERS           = 2.
        IF sy-subrc <> 0.
** No Pack material found
          MESSAGE e203  RAISING invalid_data.
        ENDIF.
      ENDIF.

** Create HU with the status 'C' (in the warehouse)
      ls_huhdr-hu_status_init = lc_c.
      ls_huhdr-hu_exid = ls_parent_hu.

      CALL METHOD zcl_dl_hu=>create_hu
        EXPORTING
          is_hu_hdr    = ls_huhdr
        IMPORTING
          et_return    = lt_return[]
        EXCEPTIONS
          invalid_data = 1
          OTHERS       = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                   WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                   RAISING invalid_data.
      ENDIF.
      APPEND LINES OF lt_return TO et_return.
    ENDIF.

** Get the internal HU number for the parent HU from VEKP.
    CREATE OBJECT lo_parent_hu
      EXPORTING
        iv_exidv     = ls_parent_hu
      EXCEPTIONS
        invalid_data = 1
        hu_not_found = 2
        OTHERS       = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      CONTINUE.
    ENDIF.

* Assign the Parent HU to shipment.
    IF NOT iv_tknum IS INITIAL.

      CALL METHOD assign_hu_to_shipment
        EXPORTING
          iv_exidv           = ls_parent_hu
          iv_shipment_number = iv_tknum
          iv_hu_obj          = lo_parent_hu
        IMPORTING
          et_applog          = lt_applog[]
          et_return          = lt_return[]
        EXCEPTIONS
          invalid_data       = 1
          hu_assignment_fail = 2
          OTHERS             = 3.
      APPEND LINES OF lt_return TO et_return.
      APPEND LINES OF lt_applog TO et_applog.
      REFRESH lt_applog[].
      IF sy-subrc NE 0.
** Assign HU to shipment failed
        MESSAGE e219 INTO lv_message.
        CALL METHOD set_message_buffer
          RECEIVING
            rs_applog = ls_applog.
        APPEND ls_applog TO et_applog.
* Continue with next parent HU ,
* If current one is already packed at the shipment.
        CONTINUE.
      ENDIF.
    ENDIF.

* Get the packaging material, plant, storage location from table
* lt_vekp_child by reading the first record.
    READ TABLE lt_vekp_child INTO ls_vekp_child INDEX 1.
    ls_parent_hu_vekp-vhilm = ls_vekp_child-vhilm.
    ls_parent_hu_vekp-werks = ls_vekp_child-werks.
    ls_parent_hu_vekp-lgort = ls_vekp_child-lgort.
    ls_parent_hu_vekp-exidv = ls_parent_hu.

** Get Parent HU details for VENUM
    CALL METHOD lo_parent_hu->get_hu_details
      IMPORTING
        et_hu_hdr = lt_parent_hu[].

    READ TABLE lt_parent_hu INTO ls_parent INDEX 1.
    IF sy-subrc = 0.
      ls_parent_hu_vekp-venum = ls_parent-venum.
    ENDIF.

* Get the internal HU number for the child HU from lt_vekp_child.
    LOOP AT lt_sub_hu INTO ls_sub_hu.

      READ TABLE lt_vekp_child INTO ls_vekp_child
                               WITH KEY exidv = ls_sub_hu-exidv
                               BINARY SEARCH.

      IF sy-subrc = 0.
        ls_sub_hu-venum = ls_vekp_child-venum.
        MODIFY lt_sub_hu FROM ls_sub_hu.
      ENDIF.
    ENDLOOP.

** Pack the Child HUs in Parent HU.
    CALL METHOD pack_nested_hu
      EXPORTING
        is_parent_hu = ls_parent_hu_vekp
        it_sub_hu    = lt_sub_hu
      IMPORTING
        et_return    = lt_return[]
        et_applog    = lt_applog[]
      EXCEPTIONS
        pack_hu_fail = 1
        OTHERS       = 2.

    APPEND LINES OF lt_return TO et_return.
    APPEND LINES OF lt_applog TO et_applog.

    IF sy-subrc NE 0.
** Packing Nested HU fail
      MESSAGE e226 INTO lv_message.
      CALL METHOD set_message_buffer
        RECEIVING
          rs_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ELSE.

* Update Shipment History. The update flag = 'I' for HU creation.
      CALL METHOD zcl_dl_shipment=>update_shipment_hudata
        EXPORTING
          iv_update_flag         = lc_insert
          iv_shipment_number     = iv_tknum
          is_exidv               = ls_parent_hu
        IMPORTING
          et_applog              = lt_applog[]
        EXCEPTIONS
          shipment_hist_upd_fail = 1
          OTHERS                 = 2.
      IF lt_applog[] IS NOT INITIAL.
        APPEND LINES OF lt_applog TO et_applog.
        READ TABLE lt_applog INTO ls_applog WITH KEY msgty = 'E'.
        IF sy-subrc = 0.
** Error in updating shipment history
          MESSAGE e212 RAISING shipment_hist_upd_fail.
        ELSE.
** Shipment History updated successfully.
          MESSAGE s211 INTO lv_message.
          CALL METHOD set_message_buffer
            RECEIVING
              rs_applog = ls_applog.
          APPEND ls_applog TO et_applog.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDMETHOD.


METHOD pack_shipment_stop .
*______________________________________________________________________*
* Change History:                                                      *
*   Programmer       Date      Action                                  *
* ===============  ==========  ========================================*
* Bruce Ballehr    05/03/2010  R16I July 2010 --> TPR37401 EDVK976802  *
*                                                                      *
*                              From within the DSD (Daily Shipping     *
*                              Dashboard), if the user clicked the     *
*                              'Pack' button multiple times for a      *
*                              Shipment, this code would pack the same *
*                              Child HU's to their respective Shipment *
*                              Level HU multiple times. This fix will  *
*                              filter out duplicate Child HU's from    *
*                              Packing the Child HU's onto the Parent  *
*                              HU's.                                   *
*                                                                      *
*                              Search BCB01 for these changes          *
************************************************************************
  TYPES: BEGIN OF ty_vepo,
         venum TYPE venum,
         matnr TYPE matnr,
         charg TYPE charg,
         werks TYPE werks_d,
         lgort TYPE lgort,
         END OF ty_vepo,

         BEGIN OF ty_vekp,
         venum TYPE venum,
         exidv TYPE exidv,
         END OF ty_vekp.

  DATA: lt_vbeln        TYPE tt_vbeln,
        ls_vbeln        TYPE vbeln,
        lo_delivery_obj TYPE REF TO zcl_dl_delivery,
        lt_tanum        TYPE tt_tanum,
        lv_lgnum        TYPE lgnum,
        ls_ltak         TYPE ltak,
        lt_return       TYPE bapiret2_t,
        ls_return       TYPE bapiret2,
        lt_to_objects   TYPE zdl_wm_to_obj_t,
        ls_to_object    TYPE LINE OF zdl_wm_to_obj_t,
        lt_vbplk        TYPE zdl_vbplk_tt,
        lt_vbplp        TYPE zdl_vbplp_tt,
        ls_vbplk        TYPE LINE OF zdl_vbplk_tt,
        ls_exidv        TYPE exidv,
        ls_exidv_temp   TYPE exidv,
        lt_wm_pcexidv   TYPE zdl_wm_pcexidv_tt,
        ls_wm_pcexidv   TYPE zdl_wm_pcexidv,
        lv_tabix        TYPE sy-tabix,
        lt_applog       TYPE zca_bal_msg_tab,
        lv_message      TYPE symsgv,
        ls_applog       TYPE bal_s_msg.

* Begin BCB01 insert
  DATA:

    lt_child_objs      TYPE zdl_wm_hu_obj_t,
    ls_child_objs      TYPE zdl_wm_hu_obj_s,

    lt_child_exidv     TYPE hum_exidv_t,
    ls_child_exidv     TYPE hum_exidv,

    lt_child_head      TYPE hum_hu_header_t,
    ls_child_head      TYPE vekpvb,
    lt_child_item      TYPE hum_hu_item_t,
    ls_child_item      TYPE vepovb.
* End BCB01 insert

  CLEAR : gt_return[], et_return.

** Reading Deliveries for the stop
  MESSAGE s206  INTO lv_message.
  CALL METHOD set_message_buffer
    RECEIVING
      rs_applog = ls_applog.
  APPEND ls_applog TO et_applog.

** Get delivery data for the stop
  CALL METHOD get_stop_deliveries
    EXPORTING
      iv_seqnm = iv_seqnm
    RECEIVING
      rt_vbeln = lt_vbeln[].

  LOOP AT lt_vbeln INTO ls_vbeln.

    CREATE OBJECT lo_delivery_obj
      EXPORTING
        iv_vbeln           = ls_vbeln
        iv_pack_view       =  'X'
      EXCEPTIONS
        invalid_data       = 1
        delivery_not_found = 2
        OTHERS             = 3 .

** Reading HU data
    MESSAGE s207  INTO lv_message.
    CALL METHOD set_message_buffer
      RECEIVING
        rs_applog = ls_applog.
    APPEND ls_applog TO et_applog.

** HU data
    lt_vbplk[] = lo_delivery_obj->gs_delv_data-vbplk[].
    lt_vbplp[] = lo_delivery_obj->gs_delv_data-vbplp[].

** Reading Confirmed TO data
    MESSAGE s208 INTO lv_message.
    CALL METHOD set_message_buffer
      RECEIVING
        rs_applog = ls_applog.
    APPEND ls_applog TO et_applog.

** Confirmed TOs
    CALL METHOD lo_delivery_obj->get_conf_tanum
      RECEIVING
        rt_conf_tanum = lt_tanum[].

** Warehouse
    CALL METHOD lo_delivery_obj->get_lgnum
      RECEIVING
        rv_lgnum = lv_lgnum.

** Create TO objects for multiple TOs
    MESSAGE s209 INTO lv_message.
    CALL METHOD set_message_buffer
      RECEIVING
        rs_applog = ls_applog.
    APPEND ls_applog TO et_applog.

    CHECK NOT lt_tanum[] IS INITIAL.

** Get TO objects
    CALL METHOD zcl_wm_to=>get_to_objects
      EXPORTING
        iv_lgnum      = lv_lgnum
        it_tanum      = lt_tanum[]
      RECEIVING
        rt_to_objects = lt_to_objects[].

    LOOP AT lt_to_objects INTO ls_to_object.

      CALL METHOD ls_to_object-to_obj->get_ltak_data
        RECEIVING
          rs_ltak = ls_ltak.

** Only pick pallet will have Parent child HU relationships
** Shipment level packing is done for Pick pallets only
      CHECK ls_ltak-lznum IS NOT INITIAL.
      REFRESH ls_wm_pcexidv-cexidv[].

*     Begin BCB01 insert
*     Retrieve details about this Shipment Level HU such as which Child
*     HU's are already packed onto it

      CLEAR: lt_child_exidv,
             lt_child_objs,
             lt_child_head,
             lt_child_item.

      ls_child_exidv-exidv = ls_ltak-lznum.
      APPEND ls_child_exidv TO lt_child_exidv.

*     Create HU object Shipment Level HU
      CALL METHOD zcl_dl_hu=>get_hu_objects
        EXPORTING
          it_exidv      = lt_child_exidv
        RECEIVING
          rt_hu_objects = lt_child_objs
        EXCEPTIONS
          invalid_data  = 1
          OTHERS        = 2.
      IF sy-subrc = 0.
*       Retrieve the Shipment Level HU details
        READ TABLE lt_child_objs INTO ls_child_objs INDEX 1.
        IF sy-subrc = 0.
          CALL METHOD ls_child_objs-hu_obj->get_hu_details
            IMPORTING
              et_hu_hdr = lt_child_head[]
              et_hu_itm = lt_child_item[].
        ENDIF.
      ENDIF.
*     End BCB01 insert

      LOOP AT lt_vbplk INTO ls_vbplk WHERE exidv+0(10) = ls_ltak-lznum.

*       Begin BCB01 insert
*       If this Child HU is already packed onto the Shipment Level HU
*       then ignore the processing of the Child HU (do NOT try to pack
*       it AGAIN onto the Shipment Level HU)
        READ TABLE lt_child_item INTO ls_child_item
          WITH KEY unvel = ls_vbplk-venum. "Internal HU num of Child HU
        IF sy-subrc = 0.
          CONTINUE. "ignore this Child HU as it's already on Shipment HU
        ENDIF.
*       End BCB01 insert

** Pass first 10 chars of HU (exidv) as Parent HU to the internal table
** lt_wm_pcexidv. Group all the child HUs by Parent HU
        READ TABLE lt_wm_pcexidv INTO ls_wm_pcexidv
                              WITH KEY pexidv = ls_vbplk-exidv+0(10).
        IF sy-subrc = 0.
          lv_tabix = sy-tabix.
          ls_exidv = ls_vbplk-exidv.
          READ TABLE ls_wm_pcexidv-cexidv[] INTO ls_exidv_temp
            WITH KEY table_line = ls_exidv.
          IF sy-subrc NE 0.
            APPEND ls_exidv TO ls_wm_pcexidv-cexidv[].
            ls_wm_pcexidv-pexidv = ls_vbplk-exidv+0(10).
            MODIFY lt_wm_pcexidv FROM ls_wm_pcexidv INDEX lv_tabix.
          ENDIF.
        ELSE.
          ls_wm_pcexidv-pexidv = ls_vbplk-exidv+0(10).
          ls_exidv = ls_vbplk-exidv.
          READ TABLE ls_wm_pcexidv-cexidv[] INTO ls_exidv_temp
          WITH KEY table_line = ls_exidv.
          IF sy-subrc NE 0.
            APPEND ls_exidv TO ls_wm_pcexidv-cexidv[].
            APPEND ls_wm_pcexidv TO lt_wm_pcexidv.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
  ENDLOOP.

** Packing Pick pallet
  MESSAGE s213 INTO gv_message.
  CALL METHOD set_message_buffer
    RECEIVING
      rs_applog = ls_applog.
  APPEND ls_applog TO et_applog.

  IF NOT lt_wm_pcexidv[] IS INITIAL.
** Pack Pick pallet
    CALL METHOD zcl_dl_shipment=>pack_pick_pallet
      EXPORTING
        iv_tknum               = gs_data-tknum
        iv_create_hu_flag      = 'X'
        iv_upd_ship_history    = 'X'
        it_parent_child_hu     = lt_wm_pcexidv[]
      IMPORTING
        et_return              = lt_return[]
        et_applog              = lt_applog[]
      EXCEPTIONS
        invalid_data           = 1
        shipment_hist_upd_fail = 2
        OTHERS                 = 3.
    IF sy-subrc <> 0.

** Error in Packing Pick pallet
      MESSAGE e215 INTO lv_message.
      CALL METHOD set_message_buffer
        RECEIVING
          rs_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ELSE.

** Packing Pick pallet is successful
      MESSAGE s214 INTO lv_message.
      CALL METHOD set_message_buffer
        RECEIVING
          rs_applog = ls_applog.
      APPEND ls_applog TO et_applog.
    ENDIF.
  ELSE.
    ls_return-type      = 'E'.
    ls_return-message   = text-001.
    APPEND ls_return TO lt_return.
  ENDIF.
  SORT lt_return BY type id number.
  DELETE ADJACENT DUPLICATES FROM lt_return COMPARING type id number.

  APPEND LINES OF lt_return TO et_return.
  APPEND LINES OF lt_applog TO et_applog.
ENDMETHOD.


METHOD read_shipment_data .

** Reading Shipment data
  CALL FUNCTION 'RV_SHIPMENT_VIEW'
    EXPORTING
      shipment_number             = iv_tknum
      option_tvtk                 = 'X'
      option_ttds                 = 'X'
      language                    = sy-langu
      option_items                = 'X'
      option_stawn_read           = 'X'
      option_segments             = 'X'
      option_partners             = 'X'
      option_messages             = 'X'
      option_packages             = ' '
      option_flow                 = ' '
      activity                    = 'A'
      option_no_refresh           = ' '
      option_ignore_missing_deliv = 'X'
    IMPORTING
      f_vttkvb                    = gs_data-vttk
      f_tvtk                      = gs_data-tvtk
      f_tvtkt                     = gs_data-tvtkt
      f_ttds                      = gs_data-ttds
      f_ttdst                     = gs_data-ttdst
      f_vbpla                     = gs_data-vbpla
    TABLES
      f_vttp                      = gs_data-vttp[]
      f_trlk                      = gs_data-vtrlk[]
      f_trlp                      = gs_data-vtrlp[]
      f_vtts                      = gs_data-vtts[]
      f_vtsp                      = gs_data-vtsp[]
      f_vbpa                      = gs_data-vbpa[]
      f_vbadr                     = gs_data-vbadr[]
      f_vtfa                      = gs_data-vtfa[]
      f_vbplk                     = gs_data-vbplk[]
      f_vbplp                     = gs_data-vbplp[]
      f_vbpls                     = gs_data-vbpls[]
      f_yvtfa                     = gs_data-yvtfa[]
    EXCEPTIONS
      not_found                   = 1
      no_authority                = 2
      delivery_missing            = 3
      delivery_lock               = 4
      OTHERS                      = 5.
  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
            RAISING invalid_data.
  ENDIF.

ENDMETHOD.


METHOD read_shipment_pack .

  CALL FUNCTION 'RV_SHIPMENT_PRINT_VIEW'
    EXPORTING
      shipment_number                  = iv_tknum
      option_tvtk                      = 'X'
      option_ttds                      = 'X'
      language                         = sy-langu
      option_items                     = 'X'
     option_minimized_item_data       = ' '
     option_sales_orders              = ' '
     option_export_data               = ' '
     option_segments                  = 'X'
     option_partners                  = 'X'
     option_packages                  = ' '
     option_flow                      = ' '
   IMPORTING
     f_vttkvb                         = gs_data-vttk
     f_tvtk                           = gs_data-tvtk
     f_tvtkt                          = gs_data-tvtkt
     f_ttds                           = gs_data-ttds
     f_ttdst                          = gs_data-ttdst
     f_vbpla                          = gs_data-vbpla
   TABLES
     f_vttp                           = gs_data-vttp[]
     f_trlk                           = gs_data-vtrlk[]
     f_trlp                           = gs_data-vtrlp[]
     f_vtts                           = gs_data-vtts[]
     f_vtsp                           = gs_data-vtsp[]
     f_vbpa                           = gs_data-vbpa[]
     f_vbadr                          = gs_data-vbadr[]
     f_vtfa                           = gs_data-vtfa[]
     f_vbplk                          = gs_data-vbplk[]
     f_vbplp                          = gs_data-vbplp[]
     f_vbpls                          = gs_data-vbpls[]
   EXCEPTIONS
     not_found                        = 1
     OTHERS                           = 2 .

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
        WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
        RAISING invalid_data.
  ENDIF.

ENDMETHOD.


METHOD set_message_buffer .

  CLEAR rs_applog.
  rs_applog-msgty = sy-msgty.
  rs_applog-msgid = sy-msgid.
  rs_applog-msgno = sy-msgno.
  rs_applog-msgv1 = sy-msgv1.
  rs_applog-msgv2 = sy-msgv2.
  rs_applog-msgv3 = sy-msgv3.
  rs_applog-msgv4 = sy-msgv4.
ENDMETHOD.


METHOD update_shipment_hudata .
* Internal tables

  DATA:   lt_xvttk        TYPE  vttkvb_tab,
          lt_yvttk        TYPE  vttkvb_tab,
          lt_xvttp        TYPE  vttpvb_tab,
          lt_yvttp        TYPE  vttpvb_tab,
          lt_xvtts        TYPE  vttsvb_tab,
          lt_yvtts        TYPE  vttsvb_tab,
          lt_xvekp        TYPE  vekpvb_tab,
          lt_yvekp        TYPE  vekpvb_tab,
          lt_xvepo        TYPE  vepovb_tab,
          lt_yvepo        TYPE  vepovb_tab,
          lt_vtrlk        TYPE  vtrlk_tab,
          lt_vtrlp        TYPE  vtrlp_tab,
          lt_vtsp         TYPE  vtspvb_tab,
          lt_xvtsp        TYPE  vtspvb_tab,
          lt_yvtsp        TYPE  vtspvb_tab,
          lt_vbpa         TYPE  vbpavb_tab,
          lt_yvbpa        TYPE  vbpavb_tab,
          lt_vbadr        TYPE  sadrvb_tab,
          lt_yvbadr       TYPE  sadrvb_tab,
          lt_vepo         TYPE  tab_vepo,
          ls_vepo         TYPE  vepo,
          ls_xvttp        TYPE vttpvb,
          ls_yvttp        TYPE vttpvb,
          lv_tknum        TYPE vttk-tknum,
          ls_vekp         TYPE vekp,
          ls_xvekp        TYPE vekpvb,
          ls_xvepo        TYPE vepovb,
          lv_msg          TYPE symsgv,
          ls_applog      TYPE bal_s_msg,
          lo_tknum        TYPE REF TO zcl_dl_shipment,
          ls_data         TYPE zdl_shipment_data,
          ls_vbplk        TYPE vbplk,
          ls_vbplp        TYPE vbplp.

  CONSTANTS: lc_delete    TYPE c VALUE 'D',
             lc_insert    TYPE c VALUE 'I',
             lc_update    TYPE c VALUE 'U'.

  lv_tknum = iv_shipment_number.

* Get the Shipment No from the calling program
  CREATE OBJECT lo_tknum
    EXPORTING
      iv_tknum     = lv_tknum
      iv_iten_view = 'X'
      iv_pack_data = 'X'
    EXCEPTIONS
      invalid_data = 1
      OTHERS       = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              RAISING shipment_hist_upd_fail.
  ENDIF.

  CALL METHOD lo_tknum->get_shipment_data
    RECEIVING
      rs_data = ls_data.

** Shipment & data selected
  MESSAGE s205 WITH lv_tknum INTO lv_msg.
  CALL METHOD set_message_buffer
    RECEIVING
      rs_applog = ls_applog.
  APPEND ls_applog TO et_applog.

* Set the Update Indicators
  ls_data-vttk-aenderung = 'X'.
  ls_data-vttk-updve = 'X'.
  APPEND ls_data-vttk TO lt_xvttk.

* Move values obtained from the above FM to the internal tables.
  lt_yvtts[] = ls_data-vtts[].
  lt_yvttp[] = ls_data-vttp[].
  lt_xvttp[] = ls_data-vttp[].
  lt_xvtsp[] = ls_data-vtsp[].
  lt_yvbpa[] = ls_data-vbpa[].
  lt_vbadr[] = ls_data-vbadr[].

* Set the Update Indicators
  LOOP AT lt_xvttp INTO ls_xvttp.
    ls_xvttp-pksta = 'X'.
    ls_xvttp-updkz = lc_update.
    MODIFY lt_xvttp FROM ls_xvttp.
  ENDLOOP.

  LOOP AT lt_yvttp INTO ls_yvttp.
    ls_yvttp-updkz = lc_update.    "Update Flag
    MODIFY lt_yvttp FROM ls_yvttp.
  ENDLOOP.

* If HU information is initial , then select from VEKP/VEPO.
  IF is_vekp IS INITIAL.
    SELECT SINGLE * FROM vekp INTO  ls_vekp
      WHERE exidv = is_exidv.
    IF sy-subrc = 0.
      SELECT * FROM vepo INTO TABLE lt_vepo
        WHERE venum = ls_vekp-venum.
    ENDIF.
  ELSE.
    ls_vekp = is_vekp.
    lt_vepo[] = it_vepo[].
  ENDIF.

* For Pack Handling Units , update_flag will be sent as 'I'.
  CASE iv_update_flag.

    WHEN lc_insert.
      MOVE-CORRESPONDING ls_vekp  TO ls_xvekp.

      ls_xvekp-updkz = lc_update.
      APPEND ls_xvekp TO lt_xvekp .

      CLEAR: ls_vekp-brgew,
             ls_vekp-ntgew,
             ls_vekp-magew,
             ls_vekp-tarag,
             ls_vekp-gewei,
             ls_vekp-btvol,
             ls_vekp-ntvol,
             ls_vekp.

      MOVE-CORRESPONDING ls_vekp  TO ls_xvekp.
      APPEND ls_xvekp TO lt_yvekp .

      LOOP AT lt_vepo INTO ls_vepo.
        MOVE-CORRESPONDING ls_vepo TO ls_xvepo.
        ls_xvepo-updkz = lc_insert.

        APPEND ls_xvepo TO lt_xvepo.
      ENDLOOP.

*   For Deleting HU's , only lt_yvekp will be populated with update
*   indicator 'D'.
    WHEN lc_delete.

      CLEAR: ls_vekp-brgew,
             ls_vekp-ntgew,
             ls_vekp-magew,
             ls_vekp-tarag,
             ls_vekp-gewei,
             ls_vekp-btvol,
             ls_vekp-ntvol.
*             ls_vekp.

      MOVE-CORRESPONDING ls_vekp  TO ls_xvekp.
      ls_xvekp-updkz = lc_delete.
      APPEND ls_xvekp TO lt_yvekp .

      LOOP AT lt_vepo INTO ls_vepo.
        MOVE-CORRESPONDING ls_vepo TO ls_xvepo.
        ls_xvepo-updkz = lc_delete.
        APPEND ls_xvepo TO lt_yvepo.
      ENDLOOP.
  ENDCASE.

* set highest detail level
  CALL FUNCTION 'SD_SHIPMENT_PROTOCOL_START'
    EXPORTING
      i_protocol_detail_level = '9'
      i_severity_transfer     = 'X'.

** Saving Shipment history
  MESSAGE s221 WITH lv_tknum INTO lv_msg.
  CALL METHOD set_message_buffer
    RECEIVING
      rs_applog = ls_applog.
  APPEND ls_applog TO et_applog.

* Save the Shipment History
  CALL FUNCTION 'SD_SHIPMENTS_SAVE'
    EXPORTING
      i_transaktionstyp     = 'V'  "Change Shipment History
      i_opt_read_ship_units = ' '  "Set it to blank to prevent SAP from
      i_flag_tra_complete   = 'C'                 "resetting UPDKZ flag.
      i_tra_save_caller     = 'DIA'
    TABLES
      i_xvttk               = lt_xvttk
      i_yvttk               = lt_yvttk
      i_xvttp               = lt_xvttp
      i_yvttp               = lt_yvttp
      i_vtrlk               = lt_vtrlk
      i_vtrlp               = lt_vtrlp
      i_xvtts               = lt_xvtts
      i_yvtts               = lt_yvtts
      i_xvtsp               = lt_vtsp
      i_yvtsp               = lt_yvtsp
      i_xvbpa               = lt_vbpa
      i_yvbpa               = lt_yvbpa
      i_xsadr               = lt_vbadr
      i_ysadr               = lt_yvbadr
      i_xvekp               = lt_xvekp
      i_yvekp               = lt_yvekp
      i_xvepo               = lt_xvepo
      i_yvepo               = lt_yvepo
    EXCEPTIONS
      no_change             = 1
      delivery_split_error  = 2
      OTHERS                = 3.
  IF sy-subrc = 0.
    COMMIT WORK AND WAIT.
** Shipment & History updated successfully.
    MESSAGE s217 WITH iv_shipment_number INTO lv_msg.
  ELSE.
** Update Shipment history failed
    MESSAGE e218 INTO lv_msg.
  ENDIF.

*   Set the Message
  CALL METHOD set_message_buffer
    RECEIVING
      rs_applog = ls_applog.
  APPEND ls_applog TO et_applog.

** If error in shipment history update raise exception
  IF sy-msgty = 'E'.
    RAISE shipment_hist_upd_fail.
  ENDIF.
ENDMETHOD.
ENDCLASS.

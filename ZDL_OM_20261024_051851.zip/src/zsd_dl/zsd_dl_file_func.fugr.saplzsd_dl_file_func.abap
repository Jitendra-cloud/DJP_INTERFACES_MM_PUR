*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_FILE_FUNCTOP.              " Global Data
  INCLUDE LZSD_DL_FILE_FUNCUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_FILE_FUNCF...              " Subprograms
* INCLUDE LZSD_DL_FILE_FUNCO...              " PBO-Modules
* INCLUDE LZSD_DL_FILE_FUNCI...              " PAI-Modules

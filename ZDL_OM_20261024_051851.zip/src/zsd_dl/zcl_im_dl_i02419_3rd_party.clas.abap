class ZCL_IM_DL_I02419_3RD_PARTY definition
  public
  final
  create public .

*"* public components of class ZCL_IM_DL_I02419_3RD_PARTY
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_BADI_V56N .
protected section.
*"* protected components of class ZCL_IM_DL_I02419_3RD_PARTY
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_DL_I02419_3RD_PARTY
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_DL_I02419_3RD_PARTY IMPLEMENTATION.


METHOD if_ex_badi_v56n~own_determination .
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2006, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*  Description :
*To support the requirement where an ASN is to be triggered based on a *
*combination of criteria in the underlying delivery documents.         *
*                                                                      *
*Note: Standard SAP Shipment output is done on the basis of the data   *
*present on a shipment stage. This includes the ship-topartner         *
*that is derived from the underlying deliveries in the planning process*
*                                                                      *
*The enhancement is to programmatically "dig" through the data on the  *
*delivery documents associated with the shipments and compare them     *
*to condition tables maintained.                                       *
*                                                                      *
*                                                                      *
************************************************************************
*  Logic :                                                             *
*The logic should make comparisons between the partners listed below   *
*and those found on each delivery.                                     *
* plant and storage location from the corresponding STO                *
*Assumptions:                                                          *
* Only shipments with STO#s are relevant for output.                   *
**
**
*  The solution is to insert logic in the BADI_V56N enhancement that   *
*  verifies all of the conditions where an ASN (or ASN Cancellation) is*
*  required. These checks are only those that are not possible through *
*  standard R/3 output determination.                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
* 11/16/2009  Bala Mandla    EDVK974367    Initial Version             *
* 02/19/2010  Bala Mandla    E0VK970641    Adding the B512 Logic       *
*______________________________________________________________________*
************************************************************************


*.... Internal tables/Variables/
  DATA: BEGIN OF ls_ff_vendor,
          lifnr       TYPE vbpa-lifnr ,
      END OF ls_ff_vendor,
        ls_vttp       TYPE vttpvb,
        ls_vbpa       TYPE vbpavb,
        lv_knumh      TYPE knumh,
        lv_objky      TYPE nast-objky,
        lt_ff_vendor  LIKE TABLE OF ls_ff_vendor,
        lt_nast       TYPE TABLE OF nast,
        ls_nast       LIKE LINE OF lt_nast,
        lt_vbpa       TYPE STANDARD TABLE OF vbpa,
        l_vbpa        TYPE vbpa.
*....History per Purchasing Document
  DATA: lt_ekbe       TYPE STANDARD TABLE OF ekbe,
        lt_ekpo       TYPE STANDARD TABLE OF ekpo,
        lt_lips       TYPE STANDARD TABLE OF lips,
        ls_lips       TYPE lips,
        lt_b511       TYPE STANDARD TABLE OF b511,
        lt_b512       TYPE STANDARD TABLE OF b512,
        ls_b511       TYPE b511,
        ls_b512       TYPE b512.

*.... Constants
  CONSTANTS: lc_ff_parvw    TYPE vbpa-parvw
                                 VALUE 'ZF',   "Partner Function
             lc_yf_parvw    TYPE vbpa-parvw
                                 VALUE 'YF',
             lc_kschl_zas2  TYPE kschl
                                 VALUE 'ZAS2', "Condition type
             lc_status_0    TYPE na_vstat
                                 VALUE '0' ,
             lc_kappl       TYPE nast-kappl
                                 VALUE 'V7' ,  "Application
             lc_vgtyp       TYPE vbtyp
                                 VALUE 'V'.    "SD document category
  REFRESH: lt_ff_vendor, lt_nast, lt_ekbe[], lt_ekpo[],
           lt_vbpa[], lt_b511[], lt_b512[], lt_lips[].
  CLEAR:   ls_ff_vendor.


  IF NOT i_xvttp[] IS INITIAL.

*...Get the Records From LIPS (Delivery: Item data)
    SELECT * FROM lips INTO TABLE lt_lips
       FOR ALL ENTRIES IN i_xvttp
       WHERE vbeln  = i_xvttp-vbeln
         AND vgtyp  = lc_vgtyp.


**....Get the Records from - History per Purchasing Document
*    SELECT * FROM ekbe INTO TABLE lt_ekbe
*               FOR ALL ENTRIES IN i_xvttp
*               WHERE belnr = i_xvttp-vbeln.
*   IF NOT lt_ekbe[] IS INITIAL.

    IF NOT lt_lips[] IS INITIAL.

*....Get the Records from - Purchasing Document Item
*      SELECT * FROM ekpo INTO TABLE lt_ekpo
*                FOR ALL ENTRIES IN lt_ekbe
*                WHERE  ebeln  = lt_ekbe-ebeln.

      SELECT * FROM ekpo INTO TABLE lt_ekpo
         FOR ALL ENTRIES IN lt_lips
         WHERE  ebeln  = lt_lips-vgbel.

    ENDIF.

    IF NOT lt_ekpo[] IS INITIAL.
*....Get the Records from - Config Table B511 (Plant/St Lo)
      SELECT * FROM b511 INTO TABLE lt_b511
         FOR ALL ENTRIES IN lt_ekpo
         WHERE  werks    = lt_ekpo-werks
           AND  zz_lgort = lt_ekpo-lgort.
      IF NOT lt_b511[] IS INITIAL.
*.... Sort and delete duplicates
        SORT lt_b511.
        DELETE ADJACENT DUPLICATES FROM lt_b511.

*.... Get data from table NACH
        LOOP AT lt_b511 INTO ls_b511.
          CLEAR ls_nast.
          SELECT SINGLE parvw parnr nacha vsztp spras
             FROM nach
             INTO CORRESPONDING FIELDS OF ls_nast
             WHERE knumh EQ ls_b511-knumh .
          IF sy-subrc EQ 0.
*.... Populate the rest of NAST
            ls_nast-mandt = sy-mandt.
            ls_nast-kappl = lc_kappl.
            ls_nast-objky = i_xvttk-tknum.
            ls_nast-kschl = lc_kschl_zas2.
            ls_nast-erdat = sy-datum.
            ls_nast-eruhr = sy-uzeit.
            ls_nast-usnam = sy-uname.
            ls_nast-manue = 'X' .
            ls_nast-vstat = lc_status_0.
            APPEND ls_nast TO lt_nast.
          ENDIF.
        ENDLOOP.


      ENDIF.
    ENDIF.

*...get the partners for all deliveries from VBPA
    SELECT * FROM vbpa INTO TABLE lt_vbpa
       FOR ALL ENTRIES IN i_xvttp
       WHERE vbeln = i_xvttp-vbeln
         AND parvw   = lc_yf_parvw.

    IF NOT lt_vbpa[] IS INITIAL.
*...Get the Records form - Config Table B512 (Third Party Service
*Provider)
      SELECT * FROM b512 INTO TABLE lt_b512
         FOR ALL ENTRIES IN lt_vbpa
         WHERE   zz_yflifnr = lt_vbpa-lifnr.
      IF NOT lt_b512[] IS INITIAL.
*.... Sort and delete duplicates
        SORT lt_b512.
        DELETE ADJACENT DUPLICATES FROM lt_b512.

        LOOP AT lt_b512 INTO ls_b512.
          CLEAR ls_nast.
          SELECT SINGLE parvw parnr nacha vsztp spras
             FROM   nach
             INTO CORRESPONDING FIELDS OF ls_nast
             WHERE knumh EQ ls_b512-knumh .
          IF sy-subrc EQ 0.
*.... Populate the rest of NAST
            ls_nast-mandt = sy-mandt.
            ls_nast-kappl = lc_kappl.
            ls_nast-objky = i_xvttk-tknum.
            ls_nast-kschl = lc_kschl_zas2.
            ls_nast-erdat = sy-datum.
            ls_nast-eruhr = sy-uzeit.
            ls_nast-usnam = sy-uname.
            ls_nast-manue = 'X' .
            ls_nast-vstat = lc_status_0.
            APPEND ls_nast TO lt_nast.
          ENDIF.
        ENDLOOP.
      ENDIF.

    ENDIF.
  ENDIF.




  IF lt_nast[] IS NOT INITIAL.
*....Insert messages into xnast internal table
    CALL FUNCTION 'RV_MESSAGES_INSERT'
      TABLES
        tab_xnast = lt_nast.
  ENDIF.


ENDMETHOD.
ENDCLASS.

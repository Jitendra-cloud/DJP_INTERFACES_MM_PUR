*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_VENASNTOP.                 " Global Data
  INCLUDE LZSD_DL_VENASNUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_VENASNF...                 " Subprograms
* INCLUDE LZSD_DL_VENASNO...                 " PBO-Modules
* INCLUDE LZSD_DL_VENASNI...                 " PAI-Modules

INCLUDE LZSD_DL_VENASNF01.

INCLUDE LZSD_DL_VENASNF02.

*INCLUDE LZSD_DL_VENASNF03.

INCLUDE LZSD_DL_VENASNF05.

*INCLUDE LZSD_DL_VENASNF06.
*{   INSERT         EDVK972584                                        1
*
INCLUDE LZSD_DL_VENASN_CL.
*}   INSERT

*&---------------------------------------------------------------------*
*&  Include           ZDL_E04625_O01                                   *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  INIT_9100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_9100 OUTPUT.

* Clear screen 9100 field values
  CLEAR: gs_9100.

* Clear table of Application Toolbar buttons to exclude
*  from the pf-status
  CLEAR: gt_itab_excl.
  REFRESH: gt_itab_excl.

ENDMODULE.                 " INIT_9100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  RETRIEVE_DATA_9100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE retrieve_data_9100 OUTPUT.

* Retrieve all ZDL_FIELDS entries and populate global variables
  PERFORM get_zdl_fields.
* Retrieve data to populate screen fields
  PERFORM retrieve_data_9100.

ENDMODULE.                 " RETRIEVE_DATA_9100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_9100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9100 OUTPUT.

  CONSTANTS : lc_changepo   TYPE fieldname VALUE 'CHANGEPO',
              lc_reprocess  TYPE fieldname VALUE 'REPROCESS'.

* If the error message number, in the retrieved Idoc Status record,
* is NOT found in the message number(s) retrieved from zdl_fields,
* then Exclude the "Change PO" application toolbar button from being
* active on the Gui Status
  READ TABLE gt_zdl_fields INTO gs_zdl_fields
    WITH KEY fieldname = lc_changepo
             lowval = gs_9100-stamno. "Idoc status record's msg number
  IF sy-subrc <> 0.
    APPEND gc_changepo TO gt_itab_excl.
  ENDIF.

* If the error message number, in the retrieved Idoc Status record,
* is NOT found in the message number(s) retrieved from zdl_fields,
* then Exclude the "Reprocess Idoc" application toolbar button from
* being active on the Gui Status
  READ TABLE gt_zdl_fields INTO gs_zdl_fields
    WITH KEY fieldname = lc_reprocess
             lowval = gs_9100-stamno. "Idoc status record's msg number
  IF sy-subrc <> 0.
    APPEND gc_reprocess TO gt_itab_excl.
  ENDIF.

  SET PF-STATUS '9100' EXCLUDING gt_itab_excl.
  SET TITLEBAR  'MAIN'.

ENDMODULE.                 " STATUS_9100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.

  SET PF-STATUS '9000'.
  SET TITLEBAR 'MAIN'.

ENDMODULE.                 " STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_9200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_9200 OUTPUT.
** Intializing the variables
  CLEAR gv_new_ebeln.
ENDMODULE.                 " INIT_9200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_9200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9200 OUTPUT.

  SET PF-STATUS '9200'.
  SET TITLEBAR '9200'.


ENDMODULE.                 " STATUS_9200  OUTPUT

FUNCTION zsd_dl_calc_num_packages .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(VBELN) LIKE  LIKP-VBELN
*"  EXPORTING
*"     VALUE(TOTAL_DISTINCT_PACKAGES) TYPE  I
*"  EXCEPTIONS
*"      INVALID_VBELN
*"      NO_DELIVERY_ITEMS_EXIST
*"      ZERO_PACKAGES_FOUND
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name:                                  Create Date: 09/13/04 *
*                                                                      *
* SAP Name    : Z_SD_DL_CALC_NUM_PACKAGES        Version    : 1.0      *
*                                                                      *
* Programmer  : Randall Wainwright               Last Update: 09/13/04 *
*                                                                      *
*______________________________________________________________________*
* Description : This function module calculates the number of distinct *
*      packages attached to a delivery. This function is RFC-enabled   *
*      for use among external clients as well.                         *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
*                     mm/dd/yy                                         *
*                                                                      *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          : N/A                                              *
*                                                                      *
*______________________________________________________________________*
* Logical Databases :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: N/A                                              *
*                                                                      *
*   Transactions    : N/A                                              *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs : N/A                                              *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   : N/A                                              *
*                                                                      *
*______________________________________________________________________*
* Program Variable Naming Standards:                                   *
*                                                                      *
*  Variable usage can be identifed by the first character of the name  *
*                                                                      *
*  C - Constants                       CB - Checkbox                   *
*  G - Global data definitions         I  - Internal tables            *
*  L - Local data definitions          P  - Parameters                 *
*  R - Range tables                    RB - Radio buttons              *
*  S - Select options                  ST - Structure                  *
*  T - Types                           O  - Object Reference           *
*______________________________________________________________________*
************************************************************************

* Type Pools:
  TYPE-POOLS: zsdc.

* SELECT Delivery data
  DATA: st_likp LIKE likp,
        st_lips LIKE lips,
         i_lips LIKE st_lips OCCURS 0.

* Function Module returned Classification data
  DATA: st_classification LIKE conf_out,
         i_classification LIKE st_classification OCCURS 0.

* Package count summary table
  DATA: BEGIN OF st_pkg_cnt,
          count   TYPE i,
          package LIKE st_classification-atwrt,
        END OF st_pkg_cnt.
  DATA: i_pkg_cnt LIKE st_pkg_cnt OCCURS 0.

* Total distinct package count
  DATA: g_cnt_pkg_total TYPE i.

* Validate the delivery number
  CLEAR st_likp.
  SELECT SINGLE *
    FROM likp INTO st_likp
    WHERE vbeln = vbeln.
  IF sy-subrc <> 0.
    RAISE invalid_vbeln.
  ENDIF.

* Select all records from SAP table LIPS that correspond to the passed
*   Delivery number, and have a batch number (CHARG).
  SELECT *
    FROM lips
    INTO TABLE i_lips
    WHERE vbeln = st_likp-vbeln.
  IF sy-subrc = 0.
    SORT i_lips BY charg.
    DELETE i_lips WHERE charg IS INITIAL.
  ENDIF.
  IF i_lips[] IS INITIAL.
    RAISE no_delivery_items_exist.
  ENDIF.

* Loop thru this table calling the function VB_BATCH_VALUES_FOR_OUTPUT
*   passing in the material number (MATNR), the plant (WERKS) and the
*   Batch number (CHARG)
  SORT i_lips BY matnr werks charg.
  LOOP AT i_lips INTO st_lips.

    CLEAR st_classification.
    REFRESH i_classification.
    CALL FUNCTION 'VB_BATCH_VALUES_FOR_OUTPUT'
      EXPORTING
        material               = st_lips-matnr
        plant                  = st_lips-werks
        batch                  = st_lips-charg
        language               = sy-langu
      TABLES
        classification         = i_classification
      EXCEPTIONS
        no_classification_data = 1
        OTHERS                 = 2.
    IF sy-subrc = 0.

* Read the relevant package information, using package number key from
*  type-pool zsdc
      SORT i_classification BY atnam.
      CLEAR st_classification.
      READ TABLE i_classification WITH KEY
            atnam = zsdc_package_number
           INTO st_classification.
      IF NOT st_classification-atwrt IS INITIAL.

* Add each record summarized into the working table. The final count
*  will reflect how many times each package type has come up. We are
*  interested in how many DISTINCT packages were found.
        CLEAR st_pkg_cnt.
        st_pkg_cnt-count = 1.
        st_pkg_cnt-package = st_classification-atwrt.
        COLLECT st_pkg_cnt INTO i_pkg_cnt.

      ENDIF. " NOT st_classification-atwrt IS INITIAL.

    ENDIF. " sy-subrc = 0.

  ENDLOOP. " AT i_lips INTO st_lips

* Count the distinct number of packages in the summarized (COLLECTed)
*  table
  DESCRIBE TABLE i_pkg_cnt LINES g_cnt_pkg_total.
  total_distinct_packages = g_cnt_pkg_total.

* If no packages were found, set sy-subrc accordingly.
  IF g_cnt_pkg_total = 0.
    RAISE zero_packages_found.
  ENDIF. " g_cnt_pkg_total = 0.

ENDFUNCTION.

FUNCTION zsdr6453_carton_count .
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IP_VBELN) LIKE  LIPS-VBELN
*"     REFERENCE(IP_POSNR) LIKE  LIPS-POSNR
*"     REFERENCE(IF_EXCLUDE_FULL_PALLETS) TYPE  CHAR1 DEFAULT 'X'
*"  EXPORTING
*"     REFERENCE(OP_CARTONS) TYPE  I
*"  TABLES
*"      PT_CONFIG_M STRUCTURE  CONF_OUT OPTIONAL
*"      PT_CONFIG_SI STRUCTURE  CONF_OUT OPTIONAL
*"  CHANGING
*"     REFERENCE(IS_LIPS) LIKE  LIPS STRUCTURE  LIPS OPTIONAL
*"     REFERENCE(I_PALLETS_EXCL) TYPE  I OPTIONAL
*"     REFERENCE(I_CTN_PER_PAL) TYPE  I OPTIONAL
*"  EXCEPTIONS
*"      BAD_DELIVERY
*"      UNKNOWN_CTN_PER_PAL
*"      UNKNOWN_CARTON_WEIGHT
*"      ITEM_NOT_CARTONS
*"----------------------------------------------------------------------

  CLEAR: g_full_pallets,
         g_total_cartons,
         g_cartons_per_pallet,
         g_tot_cartons_on_pallets.

* Populate Delivery Item Line
*****************************************************************
  PERFORM populate_delivery_item USING ip_vbeln
                                       ip_posnr
                              CHANGING is_lips
                                       x_lips.

* Get Sales Characteristics for Sales Order or PO associated with
*  Delivery Item if not already provided
*****************************************************************
  CLEAR gt_config_si.
  REFRESH gt_config_si.
  IF pt_config_si[] IS INITIAL.
    PERFORM get_sales_chars TABLES gt_config_si
                             USING x_lips-vgbel
                                   x_lips-vgpos
                                   x_lips-vgtyp.
  ELSE.
    gt_config_si[] = pt_config_si[].
  ENDIF.

* Get Material Characteristics for Material on Delivery if not
*  already provided
*****************************************************************
  CLEAR gt_config_m.
  REFRESH gt_config_m.
  IF pt_config_m[] IS INITIAL.
    PERFORM get_material_chars TABLES gt_config_m
                                USING x_lips-matnr
                                      x_lips-werks.
  ELSE.
    gt_config_m[] = pt_config_m[].
  ENDIF.

* Check if Carton Labels are required for this Delivery Item
* (UNIT_CODE = 'C' or 'D')
*****************************************************************
  CLEAR gx_config.
  READ TABLE gt_config_m INTO gx_config WITH KEY
      atnam = zsdc_unit_code
      BINARY SEARCH.
  IF NOT ( gx_config-atwrt = c_carton
        OR gx_config-atwrt = c_junior_carton ).
    CLEAR op_cartons.
    RAISE item_not_cartons.
  ENDIF.

* Determine "Cartons per Pallet" if full pallets will be excluded
*****************************************************************
  IF NOT if_exclude_full_pallets IS INITIAL.

    PERFORM get_cartons_per_pallet USING x_lips-matnr
                                CHANGING g_cartons_per_pallet.

* Cannot exclude Full Pallets without the Cartons/Pallet ratio
    IF g_cartons_per_pallet IS INITIAL.
      RAISE unknown_ctn_per_pal.
    ELSE.
      i_ctn_per_pal = g_cartons_per_pallet.
    ENDIF. " g_cartons_per_pallet IS INITIAL.

  ENDIF. " NOT ip_flg_exclude_full IS INITIAL.

* Determine Number of Cartons (CTN)
*****************************************************************
  PERFORM get_total_cartons USING x_lips-lfimg
                                  x_lips-vrkme
                                  x_lips-matnr
                         CHANGING g_total_cartons.

  CLEAR: g_full_pallets,
         g_tot_cartons_on_pallets.

  IF if_exclude_full_pallets IS INITIAL.

* If printing a label for every carton:
* Number of labels = Delivery quantity in CTN
    op_cartons = g_total_cartons .

  ELSE.

* If excluding the printing of labels of full pallets:
* Get the integer portion of the pallets
* Calculate total cartons in full pallets
* Number of labels = Subtract all full pallets from total cartons
    IF NOT g_cartons_per_pallet = 0.
      g_full_pallets = g_total_cartons / g_cartons_per_pallet.
    ELSE.
      g_full_pallets = 0.
    ENDIF.

    COMPUTE g_full_pallets = TRUNC( g_full_pallets ).

    g_tot_cartons_on_pallets =
        g_full_pallets * g_cartons_per_pallet.

    i_pallets_excl = g_tot_cartons_on_pallets.

    op_cartons =
        g_total_cartons - g_tot_cartons_on_pallets.

  ENDIF.

ENDFUNCTION.

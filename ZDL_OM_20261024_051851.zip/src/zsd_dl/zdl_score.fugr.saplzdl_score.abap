*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_SCORETOP.                     " Global Declarations
  INCLUDE LZDL_SCOREUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_SCOREF...                     " Subroutines
* INCLUDE LZDL_SCOREO...                     " PBO-Modules
* INCLUDE LZDL_SCOREI...                     " PAI-Modules
* INCLUDE LZDL_SCOREE...                     " Events
* INCLUDE LZDL_SCOREP...                     " Local class implement.
* INCLUDE LZDL_SCORET99.                     " ABAP Unit tests

*----------------------------------------------------------------------*
***INCLUDE LZDL_PROACTF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  get_data_XFER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data_xfer.
  SELECT * FROM zdl_roll_xfer INTO TABLE gt_zdl_roll_xfer
   WHERE erdat = gv_objky-erdat  "date record created
*     AND erzet = gv_objky-erzet  "time record created
     AND ernam = gv_objky-ernam  "record created by
     AND cont_venum = gv_venum.  " CONTAINER.
  IF sy-subrc NE 0.
* No records retrieved from table ZDL_ROLL_XFER
    MESSAGE ID 'zsd_dl' TYPE 'e' NUMBER '320'
                 WITH gv_objky-erdat  "date
                      gv_objky-erzet  "time
                      gv_objky-ernam  "userid
                      gv_venum       "CONTAINER
    RAISING error_message_received.
  ENDIF.

  IF NOT gt_zdl_roll_xfer[] IS INITIAL.
    READ TABLE gt_zdl_roll_xfer INTO gs_zdl_roll_xfer
       INDEX 1.
  ENDIF.
ENDFORM.                    "get_data_xfer

*&---------------------------------------------------------------------*
*&      Form  build_control
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_control USING   object STRUCTURE nast
                           control_record_in STRUCTURE edidc
                           control_record_out STRUCTURE edidc.
  sy-subrc = 0.
******************************
  DATA: h_logsys LIKE t000-logsys.

  CHECK     object-nacha = '6' OR                           "EDI
            object-nacha = 'A'.                             "ALE
  CLEAR control_record_out.
  MOVE control_record_in TO control_record_out.

  CALL FUNCTION 'OWN_LOGICAL_SYSTEM_GET'
    IMPORTING
      own_logical_system             = h_logsys
    EXCEPTIONS
      own_logical_system_not_defined = 1
      OTHERS                         = 2.
  IF ( sy-subrc IS INITIAL ).
    control_record_out-sndprt = 'LS'.
    control_record_out-sndprn = h_logsys.
  ELSE.
    MESSAGE ID 'B2' TYPE 'E' NUMBER '001'
            RAISING error_message_received.                 "#EC *
  ENDIF.

  control_record_out-serial   = sy-datum.
  control_record_out-serial+8 = sy-uzeit.

ENDFORM.                    " build_control
*&---------------------------------------------------------------------*
*&      Form  get_mseg
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_mseg .

  DATA : lv_lines TYPE i.
* get the material document number
  SELECT mblnr
         mjahr
         zeile
         matnr
         werks
         lgort
         charg
         menge
         umwrk
         umlgo
         mat_kdauf
         mat_kdpos
         kdauf
         kdpos
    FROM mseg
    INTO TABLE gt_mseg_initial
    WHERE matnr = gt_mska-matnr AND
          bwart = '413' AND
          werks = gt_mska-werks AND
          lgort = 'HP01' AND
          charg = gt_mska-charg AND
          parent_id <> 0.

  IF sy-subrc = 0 .
    DESCRIBE TABLE gt_mseg_initial LINES lv_lines.
* check if multiple material documents are returned
    IF lv_lines > 1.
* get the date and time of the material documents
      SELECT mblnr
             mjahr
             bldat
             cputm
         FROM mkpf
         INTO TABLE gt_mkpf
        FOR ALL ENTRIES IN gt_mseg_initial
        WHERE mblnr = gt_mseg_initial-mblnr .
*              bldat = gt_mska-ersda.
* get the latest material document.
      SORT  gt_mkpf DESCENDING BY mjahr bldat cputm .
* get the number of records
      DELETE gt_mkpf FROM 2 .
* pass the values to internal table
      READ TABLE gt_mkpf INDEX 1.
      DELETE gt_mseg_initial WHERE mblnr <> gt_mkpf-mblnr .
    ENDIF.

    LOOP AT gt_mseg_initial.

      gt_mseg-mblnr     = gt_mseg_initial-mblnr.
      gt_mseg-mjahr     = gt_mseg_initial-mjahr.
      gt_mseg-zeile     = gt_mseg_initial-zeile.
      gt_mseg-matnr     = gt_mseg_initial-matnr.
      gt_mseg-werks     = gt_mseg_initial-werks.
      gt_mseg-lgort     = gt_mseg_initial-lgort.
      gt_mseg-charg     = gt_mseg_initial-charg.
      gt_mseg-menge     = gt_mseg_initial-menge.
      gt_mseg-umwrk     = gt_mseg_initial-umwrk.
      gt_mseg-mat_kdauf = gt_mseg_initial-mat_kdauf.
      gt_mseg-mat_kdpos = gt_mseg_initial-mat_kdpos.
      gt_mseg-kdauf     = gt_mseg_initial-kdauf.
      gt_mseg-kdpos     = gt_mseg_initial-kdpos.

      APPEND gt_mseg.
      CLEAR gt_mseg.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " get_mseg
*&---------------------------------------------------------------------*
*&      Form  FILL_IDOC
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM fill_idoc .
* Build header segment
  PERFORM process_e1edk34.
  PERFORM idoc_data_append USING c_segnam_e1edk34 e1edk34.

  IF gs_object-repid = 'E0299'.
    PERFORM process_e1edk02_matdoc.
    PERFORM process_e1adrm1_matdoc.
    PERFORM process_e1edp31_matdoc.
  ELSE.
    PERFORM process_e1edk02.
    PERFORM process_e1adrm1.
    PERFORM process_e1edp31.
  ENDIF.

* total number of segments
  PERFORM e1eds02_fill.

ENDFORM.                    " FILL_IDOC
*&---------------------------------------------------------------------*
*&      Form  PROCESS_E1EDK34
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_e1edk34 .
  CLEAR e1edk34.
  e1edk34-action = '001'.
  e1edk34-datum = sy-datum.
  e1edk34-uzeit = sy-uzeit.

ENDFORM.                    " PROCESS_E1EDK34
*&---------------------------------------------------------------------*
*&      Form  IDOC_DATA_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_C_SEGNAM_E1EDK34  text
*      -->P_E1EDK34  text
*----------------------------------------------------------------------*
FORM idoc_data_append  USING   VALUE(va_segnam) LIKE edidd-segnam
                               us_segdata.

  DATA: idoc_data LIKE edidd.

  CHECK NOT us_segdata IS INITIAL.

  idoc_data-segnam = va_segnam.
  idoc_data-sdata  = us_segdata.
  APPEND idoc_data TO gt_edidd.
ENDFORM.                    " IDOC_DATA_APPEND
*&---------------------------------------------------------------------*
*&      Form  PROCESS_E1EDK02
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_e1edk02 .

  DATA : lv_seal  TYPE zdl_seal_no,
         lv_signi TYPE zdl_signi,
         lv_erdat TYPE erdat,
         lv_eruhr TYPE erzet.
  DATA : lv_bookdoc TYPE zsd_book_bookdoc.

  CLEAR e1edk02.
* reference document number
  IF NOT gv_venum IS INITIAL.
    e1edk02-qualf = '011'.
    e1edk02-belnr = gv_venum.
    e1edk02-datum = gs_zdl_roll_xfer-erdat.
    e1edk02-uzeit = gs_zdl_roll_xfer-erzet.
    PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.
  ENDIF.

* From Booking
  CLEAR e1edk02.
  e1edk02-qualf = 'Z01'.
  SELECT SINGLE  zzbookdoc
         INTO    lv_bookdoc
         FROM vbap
        WHERE vbeln = gs_zdl_roll_xfer-vbeln_from
          AND posnr = gs_zdl_roll_xfer-posnr_from.
  e1edk02-belnr = lv_bookdoc.
  PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.

* Start changes by KM 7/14/20 EH# 58593 E0VK9A1F6N
  CLEAR e1edk02.
  e1edk02-qualf = 'Z07'.
  SELECT SINGLE booknum
        FROM zsd_book_hdr
        INTO @DATA(lv_booknum) " BOOKNUM.
        WHERE bookdoc = @lv_bookdoc.

  e1edk02-belnr = lv_booknum.  " BOOKNUM.

  PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.
* End changes by KM on 7/14/20 EH# 58593 E0VK9A1F6N

* To Booking
  CLEAR e1edk02.
  CLEAR lv_bookdoc.
  e1edk02-qualf = 'Z03'.
  SELECT SINGLE  zzbookdoc
         INTO   lv_bookdoc
         FROM vbap
        WHERE vbeln = gs_zdl_roll_xfer-vbeln_to
          AND posnr = gs_zdl_roll_xfer-posnr_to.
  e1edk02-belnr = lv_bookdoc.
  PERFORM idoc_data_append  USING c_segnam_e1edk02 e1edk02.

* Start changes by KM on 7/14/20 EH# 58593 E0VK9A1F6N
  CLEAR e1edk02.
  e1edk02-qualf = 'Z08'.

  SELECT SINGLE booknum
         FROM zsd_book_hdr
         INTO @DATA(lv_booknum_to) " BOOKNUM_TO
         WHERE bookdoc = @lv_bookdoc.

  e1edk02-belnr =  lv_booknum_to.
  PERFORM idoc_data_append  USING c_segnam_e1edk02 e1edk02.
* End changes by KM on 7/14/20 EH# 58593 E0VK9A1F6N
  SELECT SINGLE  signi
                 seal
         INTO  (lv_signi,lv_seal)
         FROM zdlu01267_vekp
        WHERE venum = gv_venum.
  IF sy-subrc IS INITIAL.
*Container Id
    CLEAR e1edk02.
    e1edk02-belnr = lv_signi.
    e1edk02-qualf = 'Z05'.
    PERFORM idoc_data_append  USING c_segnam_e1edk02 e1edk02.
* Seal No
    CLEAR e1edk02.
    e1edk02-qualf = 'Z06'.
    e1edk02-belnr = lv_seal.
    PERFORM idoc_data_append  USING c_segnam_e1edk02 e1edk02.
  ENDIF.
ENDFORM.                    " PROCESS_E1EDK02

*&---------------------------------------------------------------------*
*&      Form  e1adrm1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  Build From and To address segments
*----------------------------------------------------------------------*
FORM process_e1adrm1 .
  e1adrm1-partner_q = 'SLS'.
  e1adrm1-name1 = gs_zdl_roll_xfer-werks_to.
  e1adrm1-name2 = gs_zdl_roll_xfer-lgort_to.
  PERFORM idoc_data_append USING c_segnam_e1adrm1 e1adrm1.

ENDFORM.                                                    " e1adrm1
*&---------------------------------------------------------------------*
*&      Form  e1edp31_fill
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_e1edp31_matdoc.

  DATA : lv_maktx    TYPE maktx,
         ls_z1edp02  LIKE z1edp02,
         ls_zsdomfld LIKE zsdomfld,                         " CR# 11871
         ls_vbap     LIKE vbap,                             " CR# 11871
         lv_spart    TYPE spart,                            " CR# 11871
         lv_licha    TYPE lichn,                            " CR# 11871
         lv_pstyv    TYPE pstyv.                            " CR# 11871

* Begin CR# 11871 08/30/2012
  SELECT SINGLE * INTO ls_zsdomfld FROM zsdomfld
          WHERE category  EQ 'VENDOR_BATCH' AND
                fieldname EQ 'PROACT'.

  IF sy-subrc IS INITIAL.
    SHIFT ls_zsdomfld-lowval LEFT DELETING LEADING space.
    SHIFT ls_zsdomfld-highval LEFT DELETING LEADING space.
    MOVE ls_zsdomfld-lowval+0(2)  TO lv_spart.
    MOVE ls_zsdomfld-highval+0(4) TO lv_pstyv.
  ENDIF.
* End CR# 11871 08/30/2012

  LOOP AT gt_mseg.
    CLEAR e1edp31.
    gv_posex = gv_posex + 1 .
    e1edp31-action = '001'.
    e1edp31-posex  = gv_posex.
    PERFORM idoc_data_append USING c_segnam_e1edp31 e1edp31.

* >> Begin of CC01
* Adding Z1EDP02 segments for From & To Sales Order & Items
* From sales order
    CLEAR ls_z1edp02.
    ls_z1edp02-qualf = 'Z02'.
    ls_z1edp02-belnr = gt_mseg-kdauf.
    ls_z1edp02-zeile = gt_mseg-kdpos.
    PERFORM idoc_data_append USING c_segnam_z1edp02 ls_z1edp02.
* To sales order
    CLEAR ls_z1edp02.
    ls_z1edp02-qualf = 'Z04'.
    ls_z1edp02-belnr = gt_mseg-mat_kdauf.
    ls_z1edp02-zeile = gt_mseg-mat_kdpos.
    PERFORM idoc_data_append USING c_segnam_z1edp02 ls_z1edp02.
* << End of CC01

    CLEAR e1edp19.
    e1edp19-qualf = '002'.
    e1edp19-idtnr = gt_mseg-matnr.
    SELECT SINGLE maktx INTO
            lv_maktx
            FROM makt
            WHERE matnr = gt_mseg-matnr
            AND   spras = sy-langu.
    e1edp19-ktext = lv_maktx.

* Begin CR# 11871 08/30/2012
    IF lv_spart IS NOT INITIAL AND lv_pstyv IS NOT INITIAL.
      SELECT SINGLE * INTO ls_vbap FROM vbap
            WHERE vbeln EQ gt_mseg-kdauf AND
                  posnr EQ gt_mseg-kdpos.
      IF sy-subrc IS INITIAL.
        IF ls_vbap-spart EQ lv_spart AND ls_vbap-pstyv EQ lv_pstyv.
          SELECT SINGLE licha INTO lv_licha FROM mch1
            WHERE matnr EQ gt_mseg-matnr AND
                  charg EQ gt_mseg-charg AND
                  lvorm EQ ' '.
          IF sy-subrc IS INITIAL.
            e1edp19-idtnr_external = lv_licha.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
* End CR# 11871 08/30/2012

    IF e1edp19-idtnr_external IS INITIAL.  " CR# 11871 08/30/2012
      e1edp19-idtnr_external = gt_mseg-charg.
    ENDIF.                                 " CR# 11871 08/30/2012

    PERFORM idoc_data_append USING c_segnam_e1edp19 e1edp19.
    e1edp32-qualf = '003'.
    e1edp32-quantity = gt_mseg-menge.
    SHIFT e1edp32-quantity LEFT DELETING LEADING space.     " CC01
    e1edp32-unit = 'LB'.
    PERFORM idoc_data_append USING c_segnam_e1edp32 e1edp32.
  ENDLOOP.

ENDFORM.                    " PROCESS_E1EDP31_MATDOC
*&---------------------------------------------------------------------*
*&      Form  process_e1edp31
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM process_e1edp31.
  DATA : lv_maktx    TYPE maktx,
         ls_z1edp02  LIKE z1edp02,
         ls_zsdomfld LIKE zsdomfld,                         " CR# 11871
         ls_vbap     LIKE vbap,                             " CR# 11871
         lv_spart    TYPE spart,                            " CR# 11871
         lv_licha    TYPE lichn,                            " CR# 11871
         lv_pstyv    TYPE pstyv.                            " CR# 11871

* Begin CR# 11871 08/30/2012
  SELECT SINGLE * INTO ls_zsdomfld FROM zsdomfld
          WHERE category  EQ 'VENDOR_BATCH' AND
                fieldname EQ 'PROACT'.

  IF sy-subrc IS INITIAL.
    SHIFT ls_zsdomfld-lowval LEFT DELETING LEADING space.
    SHIFT ls_zsdomfld-highval LEFT DELETING LEADING space.
    MOVE ls_zsdomfld-lowval+0(2)  TO lv_spart.
    MOVE ls_zsdomfld-highval+0(4) TO lv_pstyv.
  ENDIF.
* End CR# 11871 08/30/2012

  LOOP AT gt_zdl_roll_xfer INTO gs_zdl_roll_xfer.
    CLEAR e1edp31.
    gv_posex = gv_posex + 1 .
    e1edp31-action = '001'.
    e1edp31-posex  = gv_posex.
    PERFORM idoc_data_append USING c_segnam_e1edp31 e1edp31.

* Adding Z1EDP02 segments for From & To Sales Order & Items
* From sales order
    CLEAR ls_z1edp02.
    ls_z1edp02-qualf = 'Z02'.
    ls_z1edp02-belnr = gs_zdl_roll_xfer-vbeln_from.
    ls_z1edp02-zeile = gs_zdl_roll_xfer-posnr_from.
    PERFORM idoc_data_append USING c_segnam_z1edp02 ls_z1edp02.
* To sales order
    CLEAR ls_z1edp02.
    ls_z1edp02-qualf = 'Z04'.
    ls_z1edp02-belnr = gs_zdl_roll_xfer-vbeln_to.
    ls_z1edp02-zeile = gs_zdl_roll_xfer-posnr_to.
    PERFORM idoc_data_append USING c_segnam_z1edp02 ls_z1edp02.
* << End of CC01

    CLEAR e1edp19.
    e1edp19-qualf = '002'.
    e1edp19-idtnr = gs_zdl_roll_xfer-matnr.
    SELECT SINGLE maktx INTO
            lv_maktx
            FROM makt
            WHERE matnr = gs_zdl_roll_xfer-matnr
            AND   spras = sy-langu.
    e1edp19-ktext = lv_maktx.
* Begin CR# 11871 08/30/2012
    IF lv_spart IS NOT INITIAL AND lv_pstyv IS NOT INITIAL.
      SELECT SINGLE * INTO ls_vbap FROM vbap
            WHERE vbeln EQ gs_zdl_roll_xfer-vbeln_from AND
                  posnr EQ gs_zdl_roll_xfer-posnr_from.
      IF sy-subrc IS INITIAL.
        IF ls_vbap-spart EQ lv_spart AND ls_vbap-pstyv EQ lv_pstyv.
          SELECT SINGLE licha INTO lv_licha FROM mch1
            WHERE matnr EQ gs_zdl_roll_xfer-matnr AND
                  charg EQ gs_zdl_roll_xfer-charg AND
                  lvorm EQ ' '.
          IF sy-subrc IS INITIAL.
            e1edp19-idtnr_external = lv_licha.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
* End CR# 11871 08/30/2012

    IF e1edp19-idtnr_external IS INITIAL.   " CR# 11871 08/30/2012
      e1edp19-idtnr_external = gs_zdl_roll_xfer-charg.
    ENDIF.                                  " CR# 11871 08/30/2012

    PERFORM idoc_data_append USING c_segnam_e1edp19 e1edp19.

    e1edp32-qualf = '003'.
    e1edp32-quantity = gs_zdl_roll_xfer-kalab.
    SHIFT e1edp32-quantity LEFT DELETING LEADING space.     " CC01
    e1edp32-unit = 'LB'.
    PERFORM idoc_data_append USING c_segnam_e1edp32 e1edp32.
  ENDLOOP.
ENDFORM.                    "process_e1edp31

*&---------------------------------------------------------------------*
*&      Form  e1eds02_fill
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM e1eds02_fill .
  e1eds02-sumid = '001'.
  e1eds02-summe = gv_posex.
  CONDENSE  e1eds02-summe.
  PERFORM idoc_data_append USING c_segnam_e1eds02 e1eds02.

ENDFORM.                    " e1eds02_fill
*&---------------------------------------------------------------------*
*&      Form  refresh_data
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM refresh_data .

  CLEAR:    gt_vepo,
            gt_mska,
            gt_mseg,
            gt_mkpf,
            gv_venum,
            gv_matdoc,
            gt_edidd,
            gv_posex.

  REFRESH:  gt_vepo,
            gt_mska,
            gt_mseg,
            gt_mkpf,
            gt_edidd.

ENDFORM.                    " refresh_data
*&---------------------------------------------------------------------*
*&      Form  get_data_matdoc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM
get_data_matdoc .

  SELECT mblnr
         mjahr
         zeile
         matnr
         werks
         lgort
         charg
         menge
         umwrk
         umlgo
         mat_kdauf
         mat_kdpos
         kdauf
         kdpos
    FROM mseg
    INTO TABLE gt_mseg
    WHERE mblnr = gv_matdoc.

  IF sy-subrc = 0 .
    SORT gt_mseg  DESCENDING BY mblnr mjahr zeile .
    DELETE ADJACENT DUPLICATES FROM gt_mseg COMPARING mblnr mjahr zeile.
    SORT gt_mseg BY mblnr mjahr zeile.
  ENDIF.

ENDFORM.                    " get_data_matdoc
*&---------------------------------------------------------------------*
*&      Form  process_e1edk02_matdoc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM process_e1edk02_matdoc .

  DATA : lv_bldat   TYPE bldat,
         lv_cputm   TYPE cputm,
         lv_bookdoc TYPE zsd_book_bookdoc.

  CLEAR e1edk02.

* reference document number
  e1edk02-qualf = '011'.
  e1edk02-belnr = gv_matdoc.
  SELECT SINGLE bldat
                cputm
        INTO (lv_bldat, lv_cputm)
       FROM mkpf
       WHERE mblnr = gv_matdoc.

  e1edk02-datum = lv_bldat.
  e1edk02-uzeit = lv_cputm.

  PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.
  READ TABLE gt_mseg INDEX 1 .

* from booking
  CLEAR e1edk02.
  e1edk02-qualf = 'Z01'.
  SELECT SINGLE  zzbookdoc
         INTO    lv_bookdoc
         FROM vbap
        WHERE vbeln = gt_mseg-kdauf AND
              posnr = gt_mseg-kdpos.
  e1edk02-belnr = lv_bookdoc.
  PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.
*From Sales order
  CLEAR e1edk02.
  e1edk02-qualf = 'Z02'.
  e1edk02-belnr = gt_mseg-kdauf.
  e1edk02-posnr = gt_mseg-kdpos.
  PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.
* To Booking
  CLEAR e1edk02.
  CLEAR lv_bookdoc.
  e1edk02-qualf = 'Z03'.
  SELECT SINGLE  zzbookdoc
         INTO   lv_bookdoc
         FROM vbap
        WHERE vbeln = gt_mseg-mat_kdauf AND
              posnr = gt_mseg-mat_kdpos.
  e1edk02-belnr = lv_bookdoc.
  PERFORM idoc_data_append  USING c_segnam_e1edk02 e1edk02.
* TO sale order
  CLEAR e1edk02.
  e1edk02-qualf = 'Z04'.
  e1edk02-belnr = gt_mseg-mat_kdauf.
  e1edk02-posnr = gt_mseg-mat_kdpos.
  PERFORM idoc_data_append USING c_segnam_e1edk02 e1edk02.

ENDFORM.                    " process_e1edk02_matdoc
*&---------------------------------------------------------------------*
*&      Form  e1adrm1_matdoc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_e1adrm1_matdoc .

  e1adrm1-partner_q = 'FROM'.
  e1adrm1-name1 = gt_mseg-werks.
  e1adrm1-name2 = gt_mseg-lgort.
  PERFORM idoc_data_append USING c_segnam_e1adrm1 e1adrm1.

  e1adrm1-partner_q = 'TO'.
  e1adrm1-name1 = gt_mseg-umwrk.
  e1adrm1-name2 = gt_mseg-umlgo.
  PERFORM idoc_data_append USING c_segnam_e1adrm1 e1adrm1.

ENDFORM.                    " e1adrm1_matdoc

*&---------------------------------------------------------------------*
*&      Form  delete_roll_xfer
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM delete_roll_xfer.

  DATA: lt_zdl_roll_xfer TYPE STANDARD TABLE OF zdl_roll_xfer,
        ls_zdl_roll_xfer TYPE zdl_roll_xfer.

  CALL FUNCTION 'ENQUEUE_EZDL_ROLL_XFER'
    EXPORTING
      mode_zdl_roll_xfer = 'X'
      mandt              = sy-mandt
      erdat              = gv_objky-erdat
*     erzet              = gv_objky-erzet " CR# 129037
      ernam              = gv_objky-ernam
    EXCEPTIONS
      foreign_lock       = 1
      system_failure     = 2
      OTHERS             = 3.
  IF sy-subrc IS INITIAL.
* Retrieve the data from Roll Transfer Log table
    SELECT * FROM zdl_roll_xfer INTO TABLE lt_zdl_roll_xfer
      WHERE erdat = gv_objky-erdat
*        AND erzet = gv_objky-erzet " CR# 129037
        AND erzet <= gv_objky-erzet " CR# 129037
        AND ernam = gv_objky-ernam
        AND cont_venum = gv_venum.
    IF sy-subrc IS INITIAL.
* Delete the data from the Roll Transfer Log table
      DELETE zdl_roll_xfer FROM TABLE lt_zdl_roll_xfer.
      IF sy-subrc IS INITIAL.
        COMMIT WORK AND WAIT.
      ELSE.
* Records not be deleted from table ZDL_ROLL_XFER date time user
        MESSAGE ID 'zsd_dl' TYPE 'e' NUMBER '302'
                     WITH gv_objky-erdat
                          gv_objky-erzet
                          gv_objky-ernam
                          gv_venum.
      ENDIF.
    ENDIF.
* Unable to lock table ZDL_ROLL_XFER entries for date time user
*    MESSAGE ID 'zsd_dl' TYPE 'e' NUMBER '300'
*                 WITH gv_objky-erdat
*                      gv_objky-erzet
*                      gv_objky-ernam.
  ENDIF.

ENDFORM.                    "delete_roll_xfer

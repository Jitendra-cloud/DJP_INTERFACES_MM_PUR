*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZREQ_FIELDS.....................................*
DATA:  BEGIN OF STATUS_ZREQ_FIELDS                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZREQ_FIELDS                   .
CONTROLS: TCTRL_ZREQ_FIELDS
            TYPE TABLEVIEW USING SCREEN '0004'.
*.........table declarations:.................................*
TABLES: *ZREQ_FIELDS                   .
TABLES: ZREQ_FIELDS                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

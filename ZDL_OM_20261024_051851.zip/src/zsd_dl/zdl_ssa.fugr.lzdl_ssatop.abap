FUNCTION-POOL zdl_ssa.                      "MESSAGE-ID ..

************************************************************************
* TYPE DECLARATIONS
************************************************************************
TYPES:

  BEGIN OF gts_tknum_vbeln,
    tknum  TYPE  tknum,  "Shipment number
    vbeln  TYPE  vbeln_vl, "Delivery number
  END OF gts_tknum_vbeln,

  BEGIN OF gts_lips,
    vbeln  TYPE  vbeln_vl, "Delivery number
    posnr  TYPE  posnr_vl, "Delivery Item
    vgbel  TYPE  vgbel,    "Sales order
    vgpos  TYPE  vgpos,    "Sales order item
    vgtyp  TYPE  vbtyp,    "Reference document type: 'C' = Sales Order
  END OF gts_lips,

  BEGIN OF gts_vbap,
    vbeln         TYPE  vbeln_va,          "SO number
    posnr         TYPE  posnr_va,          "SO Item
    vsbed         TYPE  vsbed,             "Shipping Condition
    ssa_indicator TYPE  zdl_ssa_indicator, "SSA Indicator
  END OF gts_vbap.


************************************************************************
* DATA DECLARATIONS - TABLES & STRUCTURES
************************************************************************
DATA:

  gt_ssa_header  TYPE zdl_ssa_header_t, "Return detail data table
  gs_ssa_header  TYPE zdl_ssa_header_s, "Return detail data structure

  gt_ssa_detail  TYPE zdl_ssa_detail_t, "Return detail data table
  gs_ssa_detail  TYPE zdl_ssa_detail_s, "Return detail data structure

  gt_tknum       TYPE zdl_tknum_t,

  gt_vbeln       TYPE zdl_vbeln_t,
  gs_vbeln       TYPE zdl_vbeln_s,

  gt_tknum_vbeln TYPE STANDARD TABLE OF gts_tknum_vbeln,
  gs_tknum_vbeln TYPE gts_tknum_vbeln,

  gt_lips        TYPE STANDARD TABLE OF gts_lips,
  gs_lips        TYPE gts_lips,

  gt_vbap        TYPE STANDARD TABLE OF gts_vbap,
  gs_vbap        TYPE gts_vbap.


************************************************************************
* DATA DECLARATIONS - VARIABLES
************************************************************************
DATA:

  gv_tabix  TYPE  sytabix,

  gv_vstel  TYPE  vstela,                                   "BCB01
  gv_werks  TYPE  werks_d.                                  "BCB01


***********************************************************************
* RANGES
***********************************************************************
RANGES:

  gr_vsbed    FOR tvsb-vsbed.   "Shipping Conditions

FUNCTION-POOL zsd_dl_sord_transf MESSAGE-ID zsd_dl.

TYPE-POOLS: zsdc.

* Temporary storage location for HU managed stock
CONSTANTS: gc_hu_temploc TYPE lgort_d VALUE 'HP01'.         " <<RLW01+

* Characteristic fields
DATA: g_config_obj TYPE cuobj,
      gt_config_b  TYPE conf_out OCCURS 0 WITH HEADER LINE,
      gt_config_si TYPE conf_out OCCURS 0 WITH HEADER LINE.

* For POPUP_TO_CONFIRM
DATA: g_textline1(200).

* >> Begin of changes - ccherup - USD 4330607 - CHG 86902
TYPES: BEGIN OF gts_vbap,
         vbeln TYPE vbeln,
         posnr TYPE posnr,
         arktx TYPE arktx,
         cuobj TYPE cuobj_va,
       END OF gts_vbap,

       BEGIN OF gts_vbpa,
         vbeln TYPE vbeln,
         kunnr TYPE kunnr,
         name1 TYPE name1_gp,
       END OF gts_vbpa,

       BEGIN OF gts_isocode,
         msehi   TYPE msehi,
         isocode TYPE isocd_unit,
       END OF gts_isocode,

       BEGIN OF gts_output_s,
        fieldname(30),
        space1,
        equals(1),
        space2,
        fieldvalue(222),
       END OF gts_output_s,

       BEGIN OF gts_output,
        line(255),
       END OF gts_output.


DATA : gt_vbap TYPE SORTED TABLE OF gts_vbap WITH NON-UNIQUE KEY
                                            vbeln posnr,
       gs_vbap TYPE gts_vbap,

       gt_vbpa TYPE SORTED TABLE OF gts_vbpa WITH NON-UNIQUE KEY
                                            vbeln,
       gs_vbpa TYPE gts_vbpa.
* << End of changes - ccherup - USD 4330607 - CHG 86902

* Begin BCB01
DATA: gt_return     TYPE STANDARD TABLE OF bapiret2,
      gs_return     TYPE bapiret2,

*     Table to contain HU's that have been process successfully each
*     step in the process
      gt_success_hu TYPE STANDARD TABLE OF zsomtransf,
      gs_success_hu TYPE zsomtransf,

      gt_isocode    TYPE STANDARD TABLE OF gts_isocode,
      gs_isocode    TYPE gts_isocode,

      gt_output     TYPE STANDARD TABLE OF gts_output,
      gs_output     TYPE gts_output_s.

DATA: gv_tabix      TYPE sytabix,
      gv_goods_movement_error,
      gv_goods_movement_sim_error.
* End BCB01

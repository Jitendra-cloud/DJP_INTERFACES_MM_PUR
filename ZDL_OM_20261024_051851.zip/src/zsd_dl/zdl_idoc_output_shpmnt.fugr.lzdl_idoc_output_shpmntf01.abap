*----------------------------------------------------------------------*
***INCLUDE LZDL_IDOC_OUTPUT_SHPMNTF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SEND_IDOC
*&---------------------------------------------------------------------*
*       Send idoc to ALE Layer. Append NAST processing log messages for
*       each new IDoc created. NOTE: Function MASTER_IDOC_DISTRIBUTE
*       generates a new Serial number. In this case it's by Date/Time.
*----------------------------------------------------------------------*
*      -->P_INT_EDIDD  text
*----------------------------------------------------------------------*
FORM send_idoc  TABLES  lt_edidd STRUCTURE edidd.

  DATA:

    lt_comm_idoc_control TYPE STANDARD TABLE OF edidc,
    ls_comm_idoc_control TYPE edidc.

  DATA:

    lv_msgv1 TYPE symsgv.


* Send idoc to ALE Layer
  CALL FUNCTION 'MASTER_IDOC_DISTRIBUTE'
    EXPORTING
      master_idoc_control                  = gs_edidc
*     OBJ_TYPE                             = ''
*     CHNUM                                = ''
    TABLES
      communication_idoc_control           = lt_comm_idoc_control
      master_idoc_data                     = lt_edidd
    EXCEPTIONS
      error_in_idoc_control                = 1
      error_writing_idoc_status            = 2
      error_in_idoc_data                   = 3
      sending_logical_system_unknown       = 4
      OTHERS                               = 5.

* Generate error msg if error
  IF sy-subrc IS NOT INITIAL.
    MESSAGE ID     sy-msgid
            TYPE   sy-msgty
            NUMBER sy-msgno
            WITH   sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.
*   Occasionally idoc can becomed locked - this will unlock it.
    LOOP AT lt_comm_idoc_control INTO ls_comm_idoc_control.
      CALL FUNCTION 'EDI_DOCUMENT_DEQUEUE_LATER'
        EXPORTING
          docnum                 = ls_comm_idoc_control-docnum
        EXCEPTIONS
          idoc_is_not_to_dequeue = 1
          OTHERS                 = 2.
      CHECK sy-subrc IS INITIAL.
    ENDLOOP.

*   Store new idoc number in a character variable
    lv_msgv1 = ls_comm_idoc_control-docnum.

*   Add NAST Processing Log Message 1 for this new idoc. It will be
*   identical to the normal one SAP generates. Looks like this:
*   IDoc '0000000011226465' sent to R/3 System
    CALL FUNCTION 'NAST_PROTOCOL_UPDATE'
      EXPORTING
        msg_arbgb              = 'EA'
        msg_nr                 = '082'
        msg_ty                 = 'I'
        msg_v1                 = lv_msgv1
      EXCEPTIONS
        message_type_not_valid = 1
        no_sy_message          = 2
        OTHERS                 = 3.
    IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
    ENDIF.

*   Add NAST Processing Log Message 2 for this new idoc. It will be
*   identical to the normal one SAP generates. Looks like this:
*   IDoc '0000000011226465' was created and forwarded for transmission
    CALL FUNCTION 'NAST_PROTOCOL_UPDATE'
      EXPORTING
        msg_arbgb              = 'E0'
        msg_nr                 = '045'
        msg_ty                 = 'I'
        msg_v1                 = lv_msgv1
      EXCEPTIONS
        message_type_not_valid = 1
        no_sy_message          = 2
        OTHERS                 = 3.
    IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
    ENDIF.

  ENDIF.

ENDFORM.                    " SEND_IDOC
*&---------------------------------------------------------------------*
*&      Form  INIT_IDOC_WORK_TABLE
*&---------------------------------------------------------------------*
*       Gather pertinent information and store in work tables.
*       Set the Load Indicator, Z1EDSTP-LDIND to space if it's an 'A'
*       in the idoc data work table.
*----------------------------------------------------------------------*
*      <--P_GT_IDOC_DATA  text
*----------------------------------------------------------------------*
FORM init_idoc_work_table  CHANGING lt_idoc_data TYPE edidd_tt.

  DATA:

    ls_idoc_data  TYPE edidd,

    lv_tabix      TYPE sytabix.


  LOOP AT lt_idoc_data INTO ls_idoc_data
    WHERE segnam = gc_e1edt20 OR  "Shipment Header segment
          segnam = gc_z1edstp OR  "STOP segment
          segnam = gc_z1edstd.    "Delivery segment

    lv_tabix = sy-tabix. "save index

*   Shipment Header segment processing
    IF ls_idoc_data-segnam = gc_e1edt20.
      gs_e1edt20_seg = ls_idoc_data-sdata. "store Ship Hdr info

*   STOP segment processing
    ELSEIF ls_idoc_data-segnam = gc_z1edstp.
      gs_z1edstp_seg = ls_idoc_data-sdata. "store STOP info

*     Reset any ASN Relevant load indicators from 'A' to space
      IF gs_z1edstp_seg-ldind = gc_asn_relevant. " 'A'
        gs_z1edstp_seg-ldind = space.
        ls_idoc_data-sdata = gs_z1edstp_seg.
        MODIFY lt_idoc_data FROM ls_idoc_data INDEX lv_tabix
          TRANSPORTING sdata.
      ENDIF.

*     Store data
      gs_z1edstp = gs_z1edstp_seg.         "segment data
      gs_z1edstp-z1edstp_tabix = lv_tabix. "index of Stop segment
      APPEND gs_z1edstp TO gt_z1edstp.

    ELSE.
*     Delivery Segment processing
      gs_z1edstd_seg = ls_idoc_data-sdata. "store Delivery info

*     Store data
      gs_z1edstd = gs_z1edstd_seg.         "segment data
      gs_z1edstd-z1edstp_tabix = gs_z1edstp-z1edstp_tabix. "Stop seg idx
      gs_z1edstd-z1edstd_tabix = lv_tabix. "Delivery index
      APPEND gs_z1edstd TO gt_z1edstd.

    ENDIF.

  ENDLOOP.

ENDFORM.                    " INIT_IDOC_WORK_TABLE
*&---------------------------------------------------------------------*
*&      Form  GET_PARTNER_DATA
*&---------------------------------------------------------------------*
*       Retrieve partner info for all Deliveries on the Shipment
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_partner_data .

  CLEAR: gt_vbpa,
         gs_vbpa.

* Get all Partners for each Delivery
  SELECT vbeln  "Delivery
         kunnr  "Customer
    FROM vbpa INTO TABLE gt_vbpa
    FOR ALL ENTRIES IN gt_z1edstd
    WHERE vbeln = gt_z1edstd-vbeln.
  SORT gt_vbpa.

ENDFORM.                    " GET_PARTNER_DATA
*&---------------------------------------------------------------------*
*&      Form  DETERMINE_ASN_RELEVANCE
*&---------------------------------------------------------------------*
*       For Partial Unload or Complete Unload Stops ONLY:
*         If any of the Deliveries for the Stop has the SAME
*         Recipient Partner as the Idoc Control Recipient Partner,
*         then is Stop is considered ASN Relevant and an outbound idoc
*         must be generated.
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM determine_asn_relevance.

  DATA:
    lv_tabix  TYPE sytabix.


  CLEAR: gv_asn_relevant_count.

  LOOP AT gt_z1edstp INTO gs_z1edstp WHERE stpty = 'PU' OR
                                           stpty = 'CU'.

    lv_tabix = sy-tabix. "save index of record

*   Process all of the Deliveries related to this Stop
    LOOP AT gt_z1edstd INTO gs_z1edstd
      WHERE z1edstp_tabix = gs_z1edstp-z1edstp_tabix.

*     Check if any of these Delivery's Partners match the Control
*     Record's recipient partner number
      READ TABLE gt_vbpa INTO gs_vbpa
        WITH KEY vbeln = gs_z1edstd-vbeln  "Delivery
                 kunnr = gs_edidc-rcvprn   "Recipient partner number
        BINARY SEARCH.
      IF sy-subrc = 0.

*       One of this Stop's Delivery's partners matches. Update the
*       Stop's Load Indicator to ASN Relevant
        gs_z1edstp-ldind = gc_asn_relevant. " 'A'
        MODIFY gt_z1edstp FROM gs_z1edstp INDEX lv_tabix
          TRANSPORTING ldind.

        gv_asn_relevant = gc_true. "set flag
        gv_asn_relevant_count = gv_asn_relevant_count + 1.

        EXIT. "no need to process this Stop anymore; go to next

      ENDIF. "subrc check on READ of gt_vbpa

    ENDLOOP.                                                "gt_z1edstd

  ENDLOOP.                                                  "gt_z1edstp

ENDFORM.                    " DETERMINE_ASN_RELEVANCE
*&---------------------------------------------------------------------*
*&      Form  PROCESS_ASN_RELEVANT_IDOCS
*&---------------------------------------------------------------------*
*       Based on internal work tables, trigger the sending of idocs for
*       each ASN Relevant Stop. Note that the R/3 EDI system will always
*       send the LAST idoc so we will only trigger idocs manually for
*       n - 1 ASN Relevant Stops. For example, if 3 idocs need to be
*       issued, we will manually trigger 2 in the program (via fm
*       MASTER_IDOC_DISTRIBUTE) and let the system trigger the last
*       one).
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM process_asn_relevant_idocs CHANGING pt_idoc_data TYPE edidd_tt.

  DATA:
    lt_idoc_data      TYPE STANDARD TABLE OF edidd,
    ls_idoc_data      TYPE edidd,

*   Delivery segment local work data
    lt_z1edstd        TYPE STANDARD TABLE OF gts_z1edstd,
    ls_z1edstd        TYPE gts_z1edstd.


  LOOP AT gt_z1edstp INTO gs_z1edstp WHERE ldind = gc_asn_relevant.

*   Space out the creation of the idocs so that we do NOT get duplicate
*   Serial numbers which is the concatenation of the Date and Time. In
*   test mode we found some scenarios where the idocs were created so
*   quickly together that the Serial numbers were identical since, for
*   example, two idocs were created within the SAME second.
    WAIT UP TO 1 SECONDS.

*   Format a "fresh" local copy of idoc data from the work copy where
*   all Load Indicators of 'A' were reset to space
    lt_idoc_data[] = gt_idoc_data[].

*   Retrieve the correct Stop segment within the idoc data table
    READ TABLE lt_idoc_data INTO ls_idoc_data
      INDEX gs_z1edstp-z1edstp_tabix.
    gs_z1edstp_seg = ls_idoc_data-sdata.

*   Format the Stop segment's Load Indicator to 'A' (ASN Relevant) and
*   update the idoc segment
    gs_z1edstp_seg-ldind = gc_asn_relevant.
    ls_idoc_data-sdata = gs_z1edstp_seg.
    MODIFY lt_idoc_data FROM ls_idoc_data
      INDEX gs_z1edstp-z1edstp_tabix
      TRANSPORTING sdata.

*   Never send the last Idoc as the system will send the last Idoc
*   automatically
    IF gv_asn_relevant_count > 1.

*     Send the idoc to the ALE Layer
      PERFORM send_idoc TABLES lt_idoc_data.

    ELSE.
*     This is the last Idoc that will be issued and it will be issued
*     by the system. Replace the idoc data with the modified data so
*     that the proper Stop segments are sent out as ASN Relevant.
      pt_idoc_data = lt_idoc_data.
    ENDIF.

*   Decrement the ASN Relevant idoc counter
    gv_asn_relevant_count = gv_asn_relevant_count - 1.

  ENDLOOP.

ENDFORM.                    " PROCESS_ASN_RELEVANT_IDOCS

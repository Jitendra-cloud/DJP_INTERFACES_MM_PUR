class ZCL_IM_DL_I02419_LS_ASN definition
  public
  final
  create public .

*"* public components of class ZCL_IM_DL_I02419_LS_ASN
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_BADI_V56N .
protected section.
*"* protected components of class ZCL_IM_DL_I02419_LS_ASN
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_DL_I02419_LS_ASN
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_DL_I02419_LS_ASN IMPLEMENTATION.


METHOD if_ex_badi_v56n~own_determination .
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2006, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*  Description :                                                       *
*  To support the v0 requirement where an ASN is required to be sent to*
*  Inventory Pro (Consignment management system) there is additional   *
*  functionality required.                                             *
*                                                                      *
*  This functionality described here stems from the work to support the*
*  Inventory Pro requirements. There is a need to determine whether    *
*  ASNs are required for transmission to the Inventory Pro system.     *
*                                                                      *
*  And lastly, in the case of a shipment having it's shipment status   *
*  revert from shipment start(ed) to something earlier, then a         *
*  cancellation ASN maybe required.                                    *
************************************************************************
*  Logic :                                                             *
*  The solution is to insert logic in the BADI_V56N enhancement that   *
*  verifies all of the conditions where an ASN (or ASN Cancellation) is*
*  required. These checks are only those that are not possible through *
*  standard R/3 output determination.                                  *
*                                                                      *
*  In the case of the Inventory Pro system requirement, the logic is   *
*  based on the condition record existing. Then reference the          *
*  pre-identified condition records to determine if output is proposed.*
*
*  BF CH93212 :  Deactivate original implementaion ZDL_I02419_INVEN_PRO*
*                and implement ZDL_I02419_LS_ASN
*                Purpose of this change is to add 2 new coditions
*                to generate the output.
*       Existing condition 1: sales order doc type and plant in B501   *
*            New condition 2: sales order doc type and plant and       *
*                             SHIP TO in B508 table
*                          3: Plant and SHIP TO in table B509
*______________________________________________________________________*

* Change History:                                                      *
*                                                                      *
* 12/19/2006  Chandra Cherupally    Initial Version                    *
* 10/01/2008  Kishor Thakur         BF CH93212  TR#  E0VK944023
* 8/28/2009   Bala Mandla           ASN Triggered for the Summit CFOS  *
*                                   Scenarios        EDVK973273        *
* 12/04/2009  Removed the code from ZDL_I02419_LS_ASN  and copied the  *
*             desired logic ASN Triggered for the summit CFOS in the   *
*             BADI ZDL_I02419_ASN_OUTPT as per TPR 35597  EDVK974634   *
*______________________________________________________________________*
************************************************************************


* >> Variables
  DATA : lv_vbeln      TYPE vbeln,
         lv_auart      TYPE auart,
         lv_objky      TYPE na_objkey,
         lv_nast_objky TYPE na_objkey,
         lv_auart1     TYPE auart.

* >> Internal Tables
  DATA : lt_b501   TYPE TABLE OF b501,
         lt_b508   TYPE TABLE OF b508,                      "BF CH93212
         lt_b509   TYPE TABLE OF b509,                      "BF CH93212
         lt_b510   TYPE TABLE OF b510,

         BEGIN OF  ls_lips,
           vbeln   TYPE vbeln,
           posnr   TYPE posnr,
           werks   TYPE werks_d,
           vgbel   TYPE vgbel,
           vgpos   TYPE vgpos,
           vgtyp   TYPE vbtyp,
           uecha   TYPE uecha,
         END OF    ls_lips,
         lt_lips   LIKE TABLE OF ls_lips,
         BEGIN OF  ls_output,
*          auart   TYPE auart,     "BF CH93212
*          werks   TYPE werks_d,   "BF CH93212
           knumh   TYPE nnumh,
         END OF    ls_output,

         BEGIN OF ls_vbpa_st,
           vbeln TYPE vbeln_vl,
           posnr TYPE posnr,
           parvw TYPE parvw,
           kunnr TYPE kunnr,
         END OF ls_vbpa_st,

         BEGIN OF ls_vbpa,                                  "BF CH93212
           vbeln TYPE vbeln_vl,                             "BF CH93212
           posnr TYPE posnr,                                "BF CH93212
           parvw TYPE parvw,                                "BF CH93212
           kunnr TYPE kunnr,                                "BF CH93212
         END OF ls_vbpa,                                    "BF CH93212
        lt_vbpa   LIKE TABLE OF ls_vbpa,                    "BF CH93212
        lt_vbpa_st LIKE TABLE OF ls_vbpa_st,

         lt_output LIKE TABLE OF ls_output,
         lr_vbeln  LIKE RANGE OF lv_vbeln,
         lt_nast   TYPE TABLE OF nast,
         lt_xnast  TYPE TABLE OF vnast,
         lt_ynast  TYPE TABLE OF nast,
         lt_del_zasx_nast TYPE TABLE OF nast,
         lt_t683s TYPE TABLE OF t683s .

* >> Structures
  DATA : ls_b501              LIKE LINE OF lt_b501,
         ls_b508              LIKE LINE OF lt_b508,         "BF CH93212
         ls_b509              LIKE LINE OF lt_b509,         "BF CH93212
         ls_b510              LIKE LINE OF lt_b510,
         ls_vbeln             LIKE LINE OF lr_vbeln,
         ls_vttp              TYPE         vttpvb,
         ls_t683s             LIKE LINE OF lt_t683s,
         ls_nast              LIKE LINE OF lt_nast,
         ls_success_zas2_nast LIKE LINE OF lt_nast,
         ls_success_zasx_nast LIKE LINE OF lt_nast,
         ls_del_zasx_nast     LIKE LINE OF lt_nast,
         ls_xnast             LIKE LINE OF lt_xnast,
         ls_ynast             LIKE LINE OF lt_ynast,
         lv_kalsm             TYPE kalsmb.                  "BF CH93212


* >> Constants
  CONSTANTS : lc_kappl          TYPE sna_kappl
                                     VALUE 'V7', "Application
              lc_kschl_zas2     TYPE kschl
                                     VALUE 'ZAS2',
              lc_kschl_zasx     TYPE kschl
                                     VALUE 'ZASX',
              lc_status_0       TYPE na_vstat
                                     VALUE '0',
              lc_status_1       TYPE na_vstat
                                     VALUE '1',
              lc_parvw_ls       TYPE parvw
                                     VALUE 'LS',
              lc_parnr_invpro   TYPE na_parnr
                                     VALUE 'INV_PRO'.
data:    lt_xnast2  TYPE TABLE OF vnast,
         lt_ynast2  TYPE TABLE OF nast.
* Begin of changes CHG # 114550, Avoid duplicate outputs due to packing
        CALL FUNCTION 'RV_MESSAGES_GET'
          TABLES
            tab_xnast = lt_xnast2
            tab_ynast = lt_ynast2.
        if lt_xnast2[] is initial.
          lv_objky = i_xvttk-tknum.
          CALL FUNCTION 'RV_MESSAGES_READ'
            EXPORTING
              msg_kappl          = lc_kappl
              msg_objky          = lv_objky
*             MSG_OBJKY_TO       = ' '
                    .
        endif.
* End of changes CHG # 114550, Avoid duplicate outputs due to packing

* Guarding logic to check if  KSCHL = ZAS2.
* Determine of output is to be evaluated for this shipment type.
  SELECT SINGLE kalsm INTO lv_kalsm FROM tvtk WHERE shtyp =
  i_xvttk-shtyp.
  IF sy-subrc = 0.
    SELECT SINGLE * FROM t683s INTO ls_t683s
              WHERE  kschl = lc_kschl_zas2       " match condition type
              AND    kalsm = lv_kalsm
              " determination procedure
              AND    kappl = lc_kappl.           " shipping

    IF sy-subrc = 0.
* Go ahead.
    ELSE.
      EXIT.
    ENDIF.
  ELSE.
    EXIT.
  ENDIF.

  ls_vbeln-sign = 'I'.
  ls_vbeln-option = 'EQ'.
* >> Getting all the deliveries associated to the shipment
  LOOP AT i_xvttp INTO ls_vttp WHERE tknum = i_xvttk-tknum.
    ls_vbeln-low = ls_vttp-vbeln.
    APPEND ls_vbeln TO lr_vbeln.
  ENDLOOP.
  DESCRIBE TABLE lr_vbeln LINES sy-tabix.
  IF sy-tabix IS INITIAL.
    EXIT.
  ENDIF.
* Getting SHIP_TO for all the deliveris. "BF CH93212 TR#  E0VK944023
  SELECT vbeln posnr parvw kunnr                            "BF CH93212
        FROM vbpa                                           "BF CH93212
        INTO TABLE lt_vbpa                                  "BF CH93212
        WHERE vbeln IN lr_vbeln                             "BF CH93212
        AND   posnr = '000000'                              "BF CH93212
        AND parvw = 'WE'.                                   "BF CH93212
  IF sy-subrc EQ 0.                                         "BF CH93212
    SORT lt_vbpa.                                           "BF CH93212

  ENDIF.                                                    "BF CH93212



* >> Getting data from B501 condition table
  SELECT *
         FROM b501
         INTO TABLE lt_b501
         WHERE kappl EQ 'V7'
         AND   kschl IN ('ZAS2', 'ZASX').
* As per Matthew following condition not required.
*the select will fail if  one more document type is added to config and
*this table.

*         AND   auart EQ 'ZKB'.   Deleted
  IF sy-subrc EQ 0.
    SORT lt_b501 BY auart werks.
  ENDIF.

* Start of insert by KTHAKUR  BF CH93212  TR#  E0VK944023
  SELECT *
        FROM b508
        INTO TABLE lt_b508
        WHERE kappl EQ 'V7'
        AND   kschl IN ('ZAS2', 'ZASX').
  IF sy-subrc EQ 0.
    SORT lt_b508 BY auart werks kunwe .
  ENDIF.

  SELECT *
          FROM b509
          INTO TABLE lt_b509
          WHERE kappl EQ 'V7'
          AND   kschl IN ('ZAS2', 'ZASX').
  IF sy-subrc EQ 0.
    SORT lt_b509 BY werks kunwe.
  ENDIF.
* End insert by KTHAKUR  BF CH93212  TR#  E0VK944023


* >> Getting LIPS data for all the deliveries
  SELECT vbeln posnr werks vgbel vgpos vgtyp uecha
         FROM lips
         INTO TABLE lt_lips
         WHERE vbeln IN lr_vbeln.
  IF sy-subrc EQ 0.
    SORT lt_lips BY vbeln posnr.
    DELETE lt_lips WHERE uecha IS NOT INITIAL.
  ENDIF.

* >> Processing Delivery Items while matching the B501 condition
*    table entries in order to identify output proposals
  LOOP AT lt_lips INTO ls_lips WHERE vgtyp EQ 'C'.
    CLEAR lv_auart.
    SELECT SINGLE auart
           INTO   lv_auart
           FROM   vbak
           WHERE  vbeln EQ ls_lips-vgbel.
    IF sy-subrc EQ 0.
* Condition 1  Sales order Doc type and plant
      LOOP AT lt_b501 INTO ls_b501 WHERE auart EQ lv_auart AND
                                         werks EQ ls_lips-werks.
        CLEAR ls_output.
*        ls_output-auart = lv_auart.               "BF CH93212
*        ls_output-werks = ls_lips-werks.          "BF CH93212
        ls_output-knumh = ls_b501-knumh.
        APPEND ls_output TO lt_output.
        CLEAR ls_output.
      ENDLOOP.
*    ENDIF.                                         "BF CH93212

* Start of insert by KTHAKUR  BF CH93212  TR#  E0VK944023
      READ TABLE lt_vbpa INTO ls_vbpa WITH KEY vbeln = ls_lips-vbeln.

      IF sy-subrc = 0.
* Condition 2  Sales order Doc type and plant and SHIP TO
        LOOP AT lt_b508 INTO ls_b508 WHERE  auart = lv_auart
                                      AND   werks = ls_lips-werks
                                      AND   kunwe = ls_vbpa-kunnr.

          ls_output-knumh = ls_b508-knumh.
          APPEND ls_output TO lt_output.
          CLEAR ls_output.
        ENDLOOP.

      ENDIF.

    ENDIF.

  ENDLOOP.
  LOOP AT lt_lips INTO ls_lips .
    READ TABLE lt_vbpa INTO ls_vbpa WITH KEY vbeln = ls_lips-vbeln.

* Condition 3  plant and SHIP TO
    LOOP AT lt_b509 INTO ls_b509 WHERE  werks = ls_lips-werks
                                  AND   kunwe = ls_vbpa-kunnr.

      ls_output-knumh = ls_b509-knumh.
      APPEND ls_output TO lt_output.
      CLEAR ls_output.
    ENDLOOP.



  ENDLOOP.

  IF lt_output[] IS NOT INITIAL.
    SORT lt_output.
    DELETE ADJACENT DUPLICATES FROM lt_output
*                               COMPARING auart werks knumh. "BF CH93212
                                COMPARING knumh.            "BF CH93212

    REFRESH : lt_nast.
    CLEAR   : lt_nast, ls_output, lv_nast_objky.
    lv_nast_objky = i_xvttk-tknum.

    LOOP AT lt_output INTO ls_output.
* >> Get data from NACH
      CLEAR ls_nast.
      SELECT SINGLE *
             FROM   nach
             INTO CORRESPONDING FIELDS OF ls_nast
               WHERE knumh EQ ls_output-knumh AND
                     kappl EQ lc_kappl        AND
                     kschl EQ lc_kschl_zas2.
      IF sy-subrc EQ 0.
        CLEAR lv_objky.
* >> Checking for an entry in NAST
        SELECT SINGLE objky
               FROM   nast
               INTO   lv_objky
               WHERE  kappl EQ lc_kappl      AND
                      objky EQ i_xvttk-tknum AND
                      kschl EQ lc_kschl_zas2 AND
                      parnr EQ ls_nast-parnr AND
                      parvw EQ ls_nast-parvw AND
                      vstat EQ lc_status_0   AND
                      aktiv EQ space.
* >> Check whether to send ZAS2 or not
        IF sy-subrc NE 0.
* >> Populating the rest of the NAST information
          ls_nast-mandt = sy-mandt.
          ls_nast-kappl = lc_kappl.
          ls_nast-objky = i_xvttk-tknum.
          ls_nast-kschl = lc_kschl_zas2.
          ls_nast-erdat = sy-datum.
          ls_nast-eruhr = sy-uzeit.
          ls_nast-usnam = sy-uname.
          ls_nast-manue = 'X'.     " Indicates Manual Processing
          ls_nast-vstat = lc_status_0.
          APPEND ls_nast TO lt_nast.
        ENDIF.
      ENDIF.

* >> When there is no change in the shipment status
      IF i_xvttk-sttrg EQ i_yvttk-sttrg.
* >> Reading the XNAST & YNAST in the memory
        CALL FUNCTION 'RV_MESSAGES_GET'
          TABLES
            tab_xnast = lt_xnast
            tab_ynast = lt_ynast.

* >> Logic to delete ZASX with status '0'

* >> Checking to see whether there are any ZAS2 with status '0'
*    (indicating that ZAS2 has already been proposed before)
        SORT lt_ynast BY kschl vstat.
        READ TABLE lt_ynast INTO ls_ynast WITH KEY kschl = 'ZAS2'
                                                vstat = lc_status_0
                                                   BINARY SEARCH.
* >> Deleting only ZASX with status '0'
        IF sy-subrc NE 0.
          CALL FUNCTION 'RV_MESSAGES_DELETE_PARTNER'
            EXPORTING
              msg_objky = lv_nast_objky
              msg_parnr = ls_nast-parnr
              msg_parvw = ls_nast-parvw.
        ENDIF.
      ENDIF.


* >> Check if the status has changed from Shipment end or Ship start
*    to any status below ship status and if so, we have to propose
*    ZASX (ASN cancellations) based on existence of a succesfully
*    completed ZAS2
      IF i_yvttk-sttrg GE '6' AND i_xvttk-sttrg < '6'.

        CALL FUNCTION 'RV_MESSAGES_DELETE_PARTNER'
          EXPORTING
            msg_objky = lv_nast_objky
            msg_parnr = ls_nast-parnr
            msg_parvw = ls_nast-parvw.

        CLEAR : ls_success_zas2_nast, ls_success_zasx_nast, ls_nast.
        SELECT SINGLE *
               FROM   nach
               INTO CORRESPONDING FIELDS OF ls_nast
               WHERE knumh EQ ls_output-knumh AND
                     kappl EQ lc_kappl        AND
                     kschl EQ lc_kschl_zasx.
        IF sy-subrc EQ 0.
* >> Pulling the last success ZAS2
          SELECT *
                FROM  nast
                INTO  ls_success_zas2_nast
                WHERE kappl EQ lc_kappl      AND
                      objky EQ i_xvttk-tknum AND
                      kschl EQ lc_kschl_zas2 AND
                      parnr EQ ls_nast-parnr AND
                      parvw EQ ls_nast-parvw AND
                      vstat EQ lc_status_1   AND
                      aktiv EQ space
            ORDER BY  datvr DESCENDING
                      uhrvr DESCENDING.
            EXIT.
          ENDSELECT.
          IF ls_success_zas2_nast IS NOT INITIAL.
* >> Checking to see if there is any last success ZASX, after the
*    last success ZAS2
            SELECT * UP TO 1 ROWS
                 FROM  nast
                 INTO  ls_success_zasx_nast
                 WHERE kappl EQ lc_kappl                   AND
                       objky EQ i_xvttk-tknum              AND
                       kschl EQ lc_kschl_zasx              AND
                       parnr EQ ls_nast-parnr              AND
                       parvw EQ ls_nast-parvw              AND
                       vstat EQ lc_status_1                AND
                       aktiv EQ space                      AND
                       datvr GE ls_success_zas2_nast-datvr AND
                       uhrvr GE ls_success_zas2_nast-uhrvr.
            ENDSELECT.
            IF ls_success_zasx_nast IS INITIAL.
* >> If there is no success ZASX, after the last success ZAS2, checking
*    to see whether there are any proposed (status 0) ZASX
              REFRESH lt_del_zasx_nast.
              SELECT *
                    FROM nast
                    INTO TABLE lt_del_zasx_nast
                    WHERE kappl EQ lc_kappl      AND
                          objky EQ i_xvttk-tknum AND
                          kschl EQ lc_kschl_zasx AND
                          parnr EQ ls_nast-parnr AND
                          parvw EQ ls_nast-parvw AND
                          vstat EQ lc_status_0   AND
                          aktiv EQ space.
              IF sy-subrc EQ 0.
                CLEAR ls_del_zasx_nast.
* >> If there are any proposed ZASX, delete them from NAST table
                LOOP AT lt_del_zasx_nast INTO ls_del_zasx_nast.
                  DELETE nast FROM ls_del_zasx_nast.
                ENDLOOP.
              ENDIF.
* >> Populating the rest of the NAST information
              ls_nast-mandt = sy-mandt.
              ls_nast-kappl = lc_kappl.
              ls_nast-objky = i_xvttk-tknum.
              ls_nast-kschl = lc_kschl_zasx.
              ls_nast-erdat = sy-datum.
              ls_nast-eruhr = sy-uzeit.
              ls_nast-usnam = sy-uname.
              ls_nast-manue = 'X'.     " Indicates Manual Processing
              ls_nast-vstat = lc_status_0.
              APPEND ls_nast TO lt_nast.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.

* >> Manually proposing the output either ZAS2 or ZASX
  IF lt_nast[] IS NOT INITIAL.
    SORT lt_nast.
    DELETE ADJACENT DUPLICATES FROM lt_nast.
    READ TABLE lt_nast INTO ls_nast WITH KEY kschl = 'ZASX'.
    IF sy-subrc EQ 0.
      DELETE lt_nast WHERE kschl EQ 'ZAS2'.
    ENDIF.
* >> Inserting messages into xnast internal table
    CALL FUNCTION 'RV_MESSAGES_INSERT'
      TABLES
        tab_xnast = lt_nast.
  ENDIF.

ENDMETHOD.
ENDCLASS.

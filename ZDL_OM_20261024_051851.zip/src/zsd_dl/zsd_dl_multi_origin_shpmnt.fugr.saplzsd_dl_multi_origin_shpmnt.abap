*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTTOP.    " Global Data
  INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTUXX.    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTF...    " Subprograms
* INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTO...    " PBO-Modules
* INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTI...    " PAI-Modules

INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTF01.

INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTF02.

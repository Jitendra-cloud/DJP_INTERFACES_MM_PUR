FUNCTION-POOL zsd_dl MESSAGE-ID lk  .                       "MESSAGE-ID

TABLES:   e1vppih,   "IDOC-Segment Kommissioniermeldung Subsystem Kopf
          e1vppii,   "IDOC-Segment Kommissioniermeldung Subsystem Pos.
          e1vpdlh,   "IDOC-Segment Kommissionierrückm. Kopf
          e1vpdli,   "IDOC-Segment Kommissionierrückm. Pos.
          e1vpacd,   "IDOC-Segment Versandelementrückm. Lieferung
          e1vpach,   "IDOC-Segment Versandelementrückm. Versandelement
          e1vpaci,   "IDOC-Segment Versandelementrückm. Versandel.Inhalt
          t331,
          edidd,
          edidc,
          linv,
          lmess ,
          vbfa,
          mska,
          lips .


*-----------------------------------------------------------------------
*       Teil 1 :  Interne Tabellen  ( BEGIN OF ... OCCURS )
*-----------------------------------------------------------------------


*-----------------------------------------------------------------------
*       Teil 1 :  Interne Tabellen  ( BEGIN OF ... OCCURS )
*-----------------------------------------------------------------------

DATA:   BEGIN  OF comm_idoc_control OCCURS 10.
        INCLUDE STRUCTURE edidc.
DATA:   END    OF comm_idoc_control.

DATA: BEGIN OF bdc_daten OCCURS 50.
        INCLUDE STRUCTURE bdcdata.
DATA: END OF bdc_daten.

*........Tabelle der verarbeiteten IDOCs................................

DATA: BEGIN OF tidoc_ok  OCCURS 100,
        docnum  LIKE edidd-docnum,
        mestyp  LIKE edidc-mestyp,
        nvolls(1)                ,
      END   OF tidoc_ok.

*........Tabelle der fehlerhaften IDOCs.................................

DATA: BEGIN OF tidoc_error OCCURS 100,
        docnum  LIKE edidc-docnum,
        mestyp  LIKE edidc-mestyp,
        lmess   LIKE lmess,
        categ   LIKE bdwfretvar-wf_param,
        result  LIKE bdwfap_par-result,
      END   OF tidoc_error.

*........Tabelle der IDOCs mit Folgeaktion..............................

DATA: BEGIN OF tidoc_continue OCCURS 100,
        docnum  LIKE edidd-docnum,
        mestyp  LIKE edidc-mestyp,
        param   LIKE bdwfretvar-wf_param,
        object  LIKE bdwfretvar-doc_number,
      END   OF tidoc_continue.

*........Tabelle der IDOCs mit erzeugten Belegen........................

DATA: BEGIN OF tidoc_beleg OCCURS 100,
        docnum  LIKE edidd-docnum,
        mestyp  LIKE edidc-mestyp,
        beleg   LIKE bdwfretvar-doc_number,
      END   OF tidoc_beleg.

*........Tabelle als Ergebnis der IDOC-Verarbeitung für Workflow........

DATA: BEGIN OF xreturn OCCURS 100.
        INCLUDE STRUCTURE bdwfretvar.
DATA: END   OF xreturn.

DATA: doctyp_piod01       LIKE edidc-doctyp VALUE 'SDPIOD01'.

*........Strukturen für Kommissionierdatenrückmeldung...................

DATA: BEGIN OF i_vbkok.
        INCLUDE STRUCTURE vbkok.
DATA: END OF i_vbkok.

DATA: BEGIN OF i_vbpok OCCURS 100.
        INCLUDE STRUCTURE vbpok.
DATA: END OF i_vbpok.

*........Strukturen für Versandelementdatenrückmeldung..................

DATA: BEGIN OF i_vbeln,
        vbeln LIKE likp-vbeln,
      END OF i_vbeln.

DATA: BEGIN OF i_verko OCCURS 100.
        INCLUDE STRUCTURE verko.
DATA: END OF i_verko.

DATA: BEGIN OF i_verpo OCCURS 100.
        INCLUDE STRUCTURE verpo.
DATA: END OF i_verpo.

*-----------------------------------------------------------------------
*        Strukturen IDOC-Verarbeitung allgemein
*-----------------------------------------------------------------------

*........Kopfsatz des IDOCs............................................

DATA:    BEGIN OF ikopf.
        INCLUDE STRUCTURE edidc.
DATA:    END   OF ikopf.

*........Segmentsatz des IDOCS.........................................

DATA:    BEGIN OF isegm.
        INCLUDE STRUCTURE edidd.
DATA:    END   OF isegm.

*........Kopfsatz des abgebrochenen IDOCS (Roolback)...................

DATA: BEGIN OF ikopf_rollback.
        INCLUDE STRUCTURE edidc.
DATA: END   OF ikopf_rollback.
*........IDOC-Typen ( Zwischenstrukturen ).............................


*........Segmentnamen..................................................

DATA: seg_to_header          LIKE edidd-segnam VALUE 'E1VPPIH',
      seg_to_item            LIKE edidd-segnam VALUE 'E1VPPII'.

*-----------------------------------------------------------------------
*       Teil 3 :  Einzelfelder
*-----------------------------------------------------------------------



DATA: mestyp_pi           LIKE edidc-mestyp VALUE 'ZSDPICK',
      mestyp_pa           LIKE edidc-mestyp VALUE 'SDPACK'.

*........Felder für die IDOC-Verarbeitung..............................
DATA: idoc_nummer            LIKE edidd-docnum.

*........Felder für die Fehlerauswertung...............................
DATA: fehler_kategorie       LIKE bdwfretvar-wf_param,
      resultat               LIKE bdwfap_par-result.


*........Flags.........................................................
DATA: flg_error_rollback,
      flg_fehler.

DATA: seg_pi_header          LIKE edidd-segnam VALUE 'E1VPDLH',
      seg_pi_item            LIKE edidd-segnam VALUE 'E1VPDLI',
      seg_pa_delivery        LIKE edidd-segnam VALUE 'E1VPACD',
      seg_pa_header          LIKE edidd-segnam VALUE 'E1VPACH',
      seg_pa_item            LIKE edidd-segnam VALUE 'E1VPACI'.

*........Partnerart für den Sender und Empfänger.......................

DATA: con_rcvprt             LIKE edidc-rcvprt VALUE 'LS',
      con_sndprt             LIKE edidc-sndprt VALUE 'LS'.


*........Returncodes...................................................
DATA:    returncode            LIKE          sy-subrc           .

DATA: r_ok                            LIKE sy-subrc     VALUE '0000',
      r_no_ok                         LIKE sy-subrc     VALUE '0001'.
DATA: charx VALUE 'X'.

DATA: xprott LIKE prott  OCCURS 09 WITH HEADER LINE,
      idocc  LIKE edi_dc OCCURS 01 WITH HEADER LINE,
      idocd  LIKE edi_dd OCCURS 99 WITH HEADER LINE.

DATA: sflag TYPE c,
      selix TYPE i.

CONSTANTS: c_wf_result_error LIKE bdwf_param-result VALUE '99999',
      c_wf_result_delete_idoc LIKE bdwf_param-result VALUE '99998',
      c_wf_result_wi_complete   LIKE bdwf_param-result VALUE '99997',
      c_wf_result_ok    LIKE bdwf_param-result VALUE '0    ',
      c_wf_result_retry_idoc LIKE bdwf_param-result VALUE '1    ',
      c_wf_result_continue_idoc LIKE bdwf_param-result VALUE '2    ',
      c_wf_result_appl1 LIKE bdwf_param-result VALUE '1    ',
      c_wf_result_appl2 LIKE bdwf_param-result VALUE '2    ',
      c_wf_result_appl3 LIKE bdwf_param-result VALUE '3    ',
      c_wf_result_appl4 LIKE bdwf_param-result VALUE '4    ',
      c_wf_result_appl5 LIKE bdwf_param-result VALUE '5    '.

* IDOC-Status values.
CONSTANTS: c_idoc_status_ok    LIKE edi_ds-status VALUE '53',
      c_idoc_status_ok_incomplete LIKE edi_ds-status VALUE '52',
      c_idoc_status_error LIKE edi_ds-status VALUE '51',
      c_idoc_status_appl_in LIKE edi_ds-status VALUE '62',
      c_idoc_status_err_idoc_to_appl LIKE edidc-status VALUE '63',
      c_idoc_status_ready_post LIKE edidc-status VALUE '64',
      c_idoc_status_postponed LIKE edidc-status VALUE '66',
      c_idoc_status_delete  LIKE edi_ds-status VALUE '68',
      c_idoc_status_edited  LIKE edi_ds-status VALUE '69',
      c_wf_par_error_idocs LIKE bdwfretvar-wf_param
                     VALUE 'Error_IDOCs',                   "#EC NOTEXT
      c_wf_par_appl_obj_type LIKE bdwfretvar-wf_param
                     VALUE 'Appl_Object_Type'.              "#EC NOTEXT


* Message-ID
CONSTANTS: c_message_id LIKE sy-msgid VALUE 'B1'.

* Message types
CONSTANTS: c_error LIKE sy-msgty VALUE 'E',
      c_abend LIKE sy-msgty VALUE 'A',
      c_warning LIKE sy-msgty VALUE 'W',
      c_info LIKE sy-msgty VALUE 'I',
      c_smsg  LIKE sy-msgty VALUE 'S',
      con_x                 TYPE c   VALUE 'X'.

DATA  BEGIN OF t_bdcdata OCCURS 0.
        INCLUDE STRUCTURE bdcdata.
DATA  END OF t_bdcdata.

* structure to hold messages during bdc
DATA  BEGIN OF t_trans_msgtab OCCURS 0.
        INCLUDE STRUCTURE bdcmsgcoll.
DATA  END OF t_trans_msgtab.

DATA : lv_posnr TYPE posnr_vl.
CONSTANTS: c_sap LIKE edids-stamqu VALUE 'SAP'.
* Constants For PALLET
CONSTANTS: c_tatx TYPE pstyv VALUE 'TATX',
           c_pl   TYPE gewei VALUE 'PL' ,
           c_mode TYPE char1 VALUE 'N'  ,
           c_update TYPE char1 VALUE 'S'.
DATA :  lv_mode TYPE char1 VALUE 'N'  ,
        lv_update TYPE char1 VALUE 'S'.

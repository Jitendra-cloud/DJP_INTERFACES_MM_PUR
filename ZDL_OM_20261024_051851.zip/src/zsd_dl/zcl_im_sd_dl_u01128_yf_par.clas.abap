class ZCL_IM_SD_DL_U01128_YF_PAR definition
  public
  final
  create public .

*"* public components of class ZCL_IM_SD_DL_U01128_YF_PAR
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_LE_SHP_DELIVERY_PROC .
protected section.
*"* protected components of class ZCL_IM_SD_DL_U01128_YF_PAR
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_SD_DL_U01128_YF_PAR
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_SD_DL_U01128_YF_PAR IMPLEMENTATION.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_HEADER .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_ITEM .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FCODE_ATTRIBUTES .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FIELD_ATTRIBUTES .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~CHECK_ITEM_DELETION .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_DELETION .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_FINAL_CHECK .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~DOCUMENT_NUMBER_PUBLISH .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_HEADER .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_ITEM .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~INITIALIZE_DELIVERY .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~ITEM_DELETION .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~PUBLISH_DELIVERY_ITEM .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~READ_DELIVERY .
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_BEFORE_OUTPUT.
endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_DOCUMENT .
endmethod.


METHOD if_ex_le_shp_delivery_proc~save_document_prepare .
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2007, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Method Name : IF_EX_LE_SHP_DELIVERY_PROC~SAVE_DOCUMENT_PREPARE       *
* Programmer  : Bala Mandla                                            *
*______________________________________________________________________*
* Description :                                                        *
*   Task SHPSTAT-D-006 Actual Load Start at Location                   *
*______________________________________________________________________*
* Change History:                                                      *
* 03/03/2010  Bala Mandla    Initial Version   E0VK971274              *
*______________________________________________________________________*
************************************************************************
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
************************************************************************
*                                                                      *
*3rd party stuffers are vendors located at the ports.  Their job is to *
*receive truck or rail breakbulk material from IP and stuff intermodal *
*containers with that material for ocean shipping and transport to     *
*customers.  These vendors need visibility to deliveries that are      *
*coming to them in the same way that freight forwarders do.            *
*To provide this information, an EDI 856 ASN message will be sent to   *
*select vendors.                                                       *
*Determining which 3rd party stuffers should receive an ASN is done    *
*using a combination of plant(port), storage location (terminal), and  *
*IP division (version).  A Z-table will be maintained so that specific *
*3rd party stuffing situations can be targeted.                        *
* This method describes the logic required to read this Z-table,       *
* determine the 3rd party stuffers to add to a delivery, and how to    *
* add to the delivery at the point of #delivery save#.                 *
*----------------------------------------------------------------------*




**********************************************************************
** execute all of this code only for outbound deliveries vbtyp J     *
**********************************************************************
  CONSTANTS: c_ob_dlvry  TYPE vbtyp VALUE 'J',
             c_ro_dlvry  TYPE vbtyp VALUE 'T',
             c_true(1)   TYPE c VALUE 'X',
             c_false(1)  TYPE c VALUE ' ',
             lc_lfart_nl TYPE lfart VALUE 'NL  ', "replenishment dlvry
             lc_updkz_i  TYPE updkz_d VALUE 'I',  "insert
             lc_parvw_yf TYPE parvw VALUE 'YF',   "freight forwarder prtnr type
             lc_adrda_d  TYPE adrda VALUE 'D'.    "address indicator (ADRC mstr)

  DATA: lv_ob_dlvry_flg(1)   TYPE c,
        lv_add_partner(1)    TYPE c,
        lc_werks             TYPE werks_d,
        lc_lgort             TYPE lgort_d,
        lv_partner           TYPE lifnr,
        lv_lifn2             TYPE lifnr,
        lv_purchorg          TYPE ekorg,
        lv_land1             TYPE land1,
        lv_adrnr             TYPE adrnr,
        ls_xvbpa             TYPE vbpavb,
        ls_xlikp             TYPE likpvb,
        ls_xlips             TYPE lipsvb,
        lt_zsd_asn_3rdparty  TYPE STANDARD TABLE OF zsd_asn_3rdparty,
        ls_zsd_asn_3rdparty  TYPE zsd_asn_3rdparty.

  lv_ob_dlvry_flg = c_false.
  lv_add_partner  = c_false.

  LOOP AT ct_xlikp INTO ls_xlikp.
    IF ls_xlikp-vbtyp = c_ob_dlvry.
*    OR xlikp-vbtyp = c_ro_dlvry.
      lv_ob_dlvry_flg = c_true.
      EXIT.
    ENDIF.
  ENDLOOP.

  IF lv_ob_dlvry_flg = c_true.

    REFRESH lt_zsd_asn_3rdparty[].
    SELECT * FROM zsd_asn_3rdparty INTO TABLE lt_zsd_asn_3rdparty.

**********************************************************************
*--- copy the Third Party Stuffing from the STO to the delivery
**********************************************************************
*----is the delivery for replenishment (STO) and for a new delivery?
    LOOP AT ct_xlikp INTO ls_xlikp WHERE lfart = lc_lfart_nl
               AND updkz = lc_updkz_i.
*--- does the freight fwrdr partner already exist in the XVBPA structure?
*     (this could happen on a delivery split)
      READ TABLE ct_xvbpa INTO ls_xvbpa WITH KEY vbeln = ls_xlikp-vbeln
                                                 parvw = lc_parvw_yf.
      CHECK sy-subrc <> 0.
** get the STO number from the delivery line item
*      READ TABLE ct_xlips into ls_xlips WITH KEY vbeln = ls_xlikp-vbeln.
*      CHECK sy-subrc = 0.
** read for STO 3rd Party Stuffer  partner from the PO partner data
*      SELECT SINGLE lifn2 ekorg FROM ekpa INTO (lv_partner, lv_purchorg)
*         WHERE ebeln = ls_xlips-vgbel
*           AND parvw = lc_parvw_yf.
*      CHECK sy-subrc = 0.
** is the freight forwarder defined for the purchorg?
*      SELECT SINGLE lifnr FROM lfm1 INTO lv_lifn2
*         WHERE lifnr = lv_partner
*           AND ekorg = lv_purchorg.
*      CHECK sy-subrc = 0.
      LOOP AT ct_xlips INTO ls_xlips WHERE vbeln = ls_xlikp-vbeln.
*---get the  destination plant and storage location
        CLEAR : lc_werks, lc_lgort.
        SELECT SINGLE werks lgort FROM ekpo INTO (lc_werks, lc_lgort)
                                     WHERE  ebeln  = ls_xlips-vgbel
                                     AND    ebelp  = ls_xlips-vgpos.
        CHECK sy-subrc EQ 0.
        CLEAR ls_zsd_asn_3rdparty.
*----Check the Z table entries
        READ TABLE lt_zsd_asn_3rdparty INTO ls_zsd_asn_3rdparty
                                   WITH KEY werks = lc_werks
                                            lgort = lc_lgort
                                            spart = ls_xlips-spart.
        CHECK sy-subrc = 0.
        lv_add_partner = c_true.
        EXIT.

      ENDLOOP.

      IF lv_add_partner = c_true.
*--- get additional data from the vendor master for the freight forwarder
        SELECT SINGLE land1 adrnr FROM lfa1 INTO (lv_land1, lv_adrnr)
           WHERE lifnr = ls_zsd_asn_3rdparty-lifnr.
        CHECK sy-subrc = 0.
*---- build partner record and add to table
        CLEAR ls_xvbpa.
        ls_xvbpa-mandt = sy-mandt.
        ls_xvbpa-vbeln = ls_xlips-vbeln.
        ls_xvbpa-parvw = lc_parvw_yf.
        ls_xvbpa-lifnr = ls_zsd_asn_3rdparty-lifnr.
        ls_xvbpa-adrnr = lv_adrnr.
        ls_xvbpa-land1 = lv_land1.
        ls_xvbpa-adrda = lc_adrda_d.
        ls_xvbpa-updkz = lc_updkz_i.
        APPEND ls_xvbpa TO ct_xvbpa.
      ENDIF.
    ENDLOOP.



  ENDIF.
ENDMETHOD.
ENDCLASS.

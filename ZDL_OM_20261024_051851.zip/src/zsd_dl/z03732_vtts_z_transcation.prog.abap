************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2007                                    **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: VTTS Z TRANSCATION              Create Date: 05/14/07  *
*                                                                      *
* SAP Name    : Z03732_VTTS_Z_TRANSCATION        Version    :          *
*                                                                      *
* Programmer  : Naveen Parchuri                                        *
*______________________________________________________________________*
* Description : This custom transcation is to maintain custom's field  *
*               information in shipment stages  The Multi-Origin       *
*               requirements for IP manifest themselves on the storage *
*               of the Shipment information by requiring additional    *
*               dates/times and values that are stored in relationship *
*               to a shipment stage
*               TPR # 30092  Transport# EDVK969175
*______________________________________________________________________*
* Change History:                                                      *
* Programmer| Date |CMS/CHG #| Action                                  *
*======================================================================*
* AMAOLE1| 02212017| CMS31525| Add logic to display appointment history*
* HMALKOW| 02252020|2000006956|Enhancement for Madrid:                 *
*                              Add the ability to print out the existing
*                              documents EMEA CMR and Delivery Note    *
*======================================================================*
 include z03732_vtts_z_transcation_top           .  " global Data
 include z03732_vtts_z_transcation_f01           .  " FORM-Routines
***** 2000006956 - start
 include z03732_vtts_z_transcation_cls.          "Enhancement for Madrid
***** 2000006956 - end
 include z03732_vtts_z_transcation_o01           .  " PBO-Modules
 include z03732_vtts_z_transcation_i01           .  " PAI-Modules

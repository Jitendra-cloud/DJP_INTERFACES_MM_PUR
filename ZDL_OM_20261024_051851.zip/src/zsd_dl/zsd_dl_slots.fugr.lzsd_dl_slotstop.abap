FUNCTION-POOL zsd_dl_slots.                 "MESSAGE-ID .

DATA: g_roll_diam       TYPE p DECIMALS 3,
      g_roll_width      TYPE p DECIMALS 3,
      g_rolls_in_pkg    TYPE i,
      g_unit_weight     TYPE p DECIMALS 3,
      g_num_rolls       TYPE i.

DATA: g_slot_mode TYPE /gcds04/os_mode_d.

DATA: g_max_stack_height TYPE /gcds04/os_max_stacking_height,
      g_car_height       TYPE /gcds04/os_car_height,
      g_car_unit         TYPE meabm,
      g_return           TYPE sy-subrc,
      g_footprint_factor TYPE /gcds04/os_footprint_factor.

DATA: gc_xflag(1)   VALUE 'X' ,
      gc_round_up   VALUE '+',
      gc_round_down VALUE '-',
      gc_round_comm VALUE 'X'.

DATA: g_config_obj TYPE cuobj,
      gt_config TYPE conf_out OCCURS 0 WITH HEADER LINE.

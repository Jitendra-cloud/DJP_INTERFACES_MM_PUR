FUNCTION zsd_dl_e03578_ret_rcn.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IF_TKNUM) LIKE  VTTK-TKNUM
*"     REFERENCE(IF_OVRIDE_VSTEL) LIKE  VTTS-VSTEL OPTIONAL
*"     REFERENCE(IF_OVRIDE_KUNNZ) LIKE  VTTS-KUNNZ OPTIONAL
*"     REFERENCE(IF_OVRIDE_EDPSTLZ) LIKE  VTTS-EDPSTLZ OPTIONAL
*"     REFERENCE(IF_OVRIDE_VSBED) LIKE  VTTK-VSBED OPTIONAL
*"     REFERENCE(IF_OVRIDE_ROUTE) LIKE  VTTK-ROUTE OPTIONAL
*"  EXPORTING
*"     REFERENCE(OF_CONTRACT_NBR) TYPE  /SAPRGX/CONTRACT_NBR
*"  EXCEPTIONS
*"      INVALID_SHIPMENT
*"      MISSING_STAGES
*"      NO_CONTRACT_NUMBER_FOUND
*"----------------------------------------------------------------------

************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                            2006                                    **
**                             by                                     **
**                    INTERNATIONAL PAPER                             **
************************************************************************
*______________________________________________________________________*
* Program Name: ZSD_DL_E03578_RET_RCN           Create Date: 11/14/2006*
*                                                                      *
* SAP Name    : ZSD_DL_E03578_RET_RCN           Version    : Final     *
*                                                                      *
* Programmer  : Randall Wainwright              Last Update: 11/14/2006*
*______________________________________________________________________*
*                                                                      *
*  Title      :  Retrieve Rail Contract #                              *
*                                                                      *
* Description :  Retrieve Rail Contract # for a shipment.              *
*                                                                      *
*"----------------------------------------------------------------------
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======      ========================   *
* Randall Wainwright  11/16/06  ESBK9A03JP  Initial                    *
*______________________________________________________________________*

* Shipment Data
  DATA: BEGIN OF x_vttk,          " Shipment Header
          tknum LIKE vttk-tknum,
          vsbed LIKE vttk-vsbed,
          route LIKE vttk-route,
        END OF x_vttk.

  DATA: BEGIN OF x_vtts,          " Stage of Shipment
          tknum LIKE vtts-tknum,
          tsnum LIKE vtts-tsnum,
          laufk LIKE vtts-laufk,
          vstel LIKE vtts-vstel,
          werka LIKE vtts-werka,
          kunnz LIKE vtts-kunnz,
          sdabw LIKE vtts-sdabw,
          edpstlz LIKE vtts-edpstlz,
        END OF x_vtts,
        t_vtts LIKE x_vtts OCCURS 0.

  DATA: l_shippoint(4).

  CLEAR of_contract_nbr.

* Assume that each shipment will have only one rail contract, use the
*  shipment header and 1st stage data
  SELECT SINGLE tknum
                vsbed
                route
           FROM vttk
           INTO x_vttk
           WHERE tknum = if_tknum.
  IF sy-subrc <> 0.
* Report this shipment invalid if there are no optional overrides to
*   use as a backup
    IF     if_ovride_vstel IS INITIAL
       AND if_ovride_kunnz IS INITIAL
       AND if_ovride_edpstlz IS INITIAL
       AND if_ovride_vsbed IS INITIAL
       AND if_ovride_route IS INITIAL.
      RAISE invalid_shipment.
    ENDIF.
  ELSE.

    SELECT tknum
           tsnum
           laufk
           vstel
           werka
           kunnz
           sdabw
           edpstlz
      FROM vtts
      INTO TABLE t_vtts
      WHERE tknum = if_tknum.
    IF sy-subrc = 0.
* Delete the return leg out of t_vtts. It will only cause problems.
      SORT t_vtts BY laufk.
      DELETE t_vtts WHERE laufk = '5'. " Return Leg
* Delete Special processing indicated legs
      SORT t_vtts BY sdabw.
      DELETE t_vtts WHERE sdabw NE space.
      SORT t_vtts.
    ENDIF.

    IF t_vtts[] IS INITIAL.
      RAISE missing_stages.
    ELSE.
      CLEAR x_vtts.
      READ TABLE t_vtts INTO x_vtts INDEX 1.
    ENDIF.

  ENDIF.

* If any of the override fields are populated, overwrite values
*  selected with override values
*"     REFERENCE(IF_OVRIDE_vstel)   LIKE  VTTS-vstel OPTIONAL
*"     REFERENCE(IF_OVRIDE_KUNNZ)   LIKE  VTTS-KUNNZ OPTIONAL
*"     REFERENCE(IF_OVRIDE_EDPSTLZ) LIKE  VTTS-EDPSTLZ OPTIONAL
*"     REFERENCE(IF_OVRIDE_VSBED)   LIKE  VTTK-VSBED OPTIONAL
*"     REFERENCE(IF_OVRIDE_ROUTE)   LIKE  VTTK-ROUTE OPTIONAL
  IF NOT if_ovride_vstel IS INITIAL.
    x_vtts-vstel = if_ovride_vstel. " Shipping Point
  ENDIF.

  IF NOT if_ovride_kunnz IS INITIAL.
    x_vtts-kunnz = if_ovride_kunnz. " Ship-to Point
  ENDIF.

  IF NOT if_ovride_edpstlz IS INITIAL.
    x_vtts-edpstlz = if_ovride_edpstlz. " Ship-to 5 Digit Zip Code
  ENDIF.

  IF NOT if_ovride_vsbed IS INITIAL.
    x_vttk-vsbed = if_ovride_vsbed. " Shipping Condition
  ENDIF.

  IF NOT if_ovride_route IS INITIAL.
    x_vttk-route = if_ovride_route. " Shipment Route
  ENDIF.

* Use VSTEL as the Ship Point, or if it's blank, default to WERKA
  CLEAR l_shippoint.
  IF NOT x_vtts-vstel IS INITIAL.
    l_shippoint = x_vtts-vstel.
  ELSE.
    l_shippoint = x_vtts-werka.
  ENDIF.

* Try to retrieve the condition record from the condition tables in the
*  following order:
* kot2902 => kot2909 => kot2907 => kot2908

* Try condition table KOT2902...
  PERFORM query_kot2902 USING l_shippoint
                              x_vtts-kunnz
                              x_vttk-vsbed
                              x_vttk-route
                     CHANGING of_contract_nbr.
  CHECK of_contract_nbr IS INITIAL.

* Try condition table KOT2909...
  SHIFT x_vtts-edpstlz LEFT DELETING LEADING space.
  PERFORM query_kot2909 USING l_shippoint
                              x_vtts-kunnz
                              x_vtts-edpstlz+0(5)
                              x_vttk-route
                     CHANGING of_contract_nbr.
  CHECK of_contract_nbr IS INITIAL.

* Try condition table KOT2907...
  PERFORM query_kot2907 USING l_shippoint
                              x_vtts-kunnz
                              x_vttk-route
                     CHANGING of_contract_nbr.
  CHECK of_contract_nbr IS INITIAL.

* Try condition table KOT2908...
  PERFORM query_kot2908 USING x_vttk-vsbed
                              x_vttk-route
                     CHANGING of_contract_nbr.
  CHECK of_contract_nbr IS INITIAL.

* If none of the conditional tables returned a contract number:
  IF of_contract_nbr IS INITIAL.
    RAISE no_contract_number_found.
  ENDIF.

ENDFUNCTION.

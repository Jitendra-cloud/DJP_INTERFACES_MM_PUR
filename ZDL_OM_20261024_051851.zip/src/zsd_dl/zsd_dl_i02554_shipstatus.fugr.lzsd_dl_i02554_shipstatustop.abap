FUNCTION-POOL zsd_dl_i02554_shipstatus MESSAGE-ID zdl_shipstatus.

TABLES     : nast.

TYPE-POOLS : zmos.

CONSTANTS  : gc_kappl_v7      TYPE kappl VALUE 'V7',
             gc_kschl_zsso    TYPE kschl VALUE 'ZSSO',
             gc_parvw_ag      TYPE parvw VALUE 'AG',
             gc_parvw_we      TYPE parvw VALUE 'WE'.

DATA       : gs_vttk          TYPE vttk.

DATA       : gt_itinerary     TYPE zmos_itinerary_s.
************************************************************************
* Data Declaration for Outbound 214 Relevancy Function Module
************************************************************************

*--> Structure declaration
DATA       : gs_result        TYPE zdl_i02554_rev_result.


************************************************************************
* Data Declaration for Outbound IDoc Function Module
************************************************************************

* >> Types
TYPES      : BEGIN OF tt_condition_record,
               kappl          TYPE kappl,
               kschl          TYPE na_kschl,
               zz_zssoa       TYPE zdl_zssoa,
               zz_kunag       TYPE zdl_kunag,
               kunwe          TYPE kunwe,
               knumh          TYPE knumh,
             END OF tt_condition_record,

             BEGIN OF tt_idoc_sent,
               parnr          TYPE parnr,
             END   OF tt_idoc_sent,

             BEGIN OF tt_vtts,
               tknum          TYPE tknum,
               tsnum          TYPE tsnum,
               tsrfo          TYPE tsrfo,
               vstel          TYPE vstel,
               zz_itin_o      TYPE zdl_itnum_o,
               zz_itin_d      TYPE zdl_itnum_d,
               zz_stoptype_o  TYPE zdl_stpty_o,
             END OF tt_vtts,

             BEGIN OF tt_vbfa,
               vbelv          TYPE vbeln_von,
               posnv          TYPE posnr_von,
               vbeln          TYPE vbeln_nach,
               posnn          TYPE posnr_nach,
               vbtyp_n        TYPE vbtyp_n,
               vbtyp_v        TYPE vbtyp_v,
             END OF tt_vbfa,

             BEGIN OF tt_vbak,
               vbeln          TYPE vbeln_va,
               bstnk          TYPE bstnk,
             END OF tt_vbak,
* TPR 27352 requested we go to VBKD instead of VBAK for PO
             BEGIN OF tt_vbkd,
               vbeln          TYPE vbeln_va,
               bstkd          TYPE bstkd,
             END OF tt_vbkd.


* >> Structures
DATA       : BEGIN OF gs_idoc_info.
        INCLUDE STRUCTURE zdl_i02554_em_event_info.
DATA       : ship_from        TYPE vstel,
             ship_from_adrnr  TYPE adrnr,
             ship_to          TYPE kunwe,
             ship_to_adrnr    TYPE adrnr,
             END OF gs_idoc_info.

DATA       : gs_em_data       TYPE zdl_i02554_em_event_info.

* >> Variables
DATA       : gv_ship_from        TYPE vstel,
             gv_ship_from_adrnr  TYPE adrnr,
             gv_ship_to          TYPE kunwe,
             gv_ship_to_adrnr    TYPE adrnr.

* >> Internal Tables
DATA       : gt_stop_delvs       TYPE zmos_deliveries_s,
             gt_vbpa             TYPE STANDARD TABLE OF vbpa,
             gt_vbfa             TYPE STANDARD TABLE OF tt_vbfa,
             gt_vbak             TYPE STANDARD TABLE OF tt_vbak,
             gt_vbkd             type standard table of tt_vbkd,
             gt_nach             TYPE STANDARD TABLE OF nach,
             gt_vtts             TYPE STANDARD TABLE OF tt_vtts,
             gt_idoc_sent        TYPE STANDARD TABLE OF tt_idoc_sent,
             gt_condition_record TYPE STANDARD TABLE OF
                                                tt_condition_record.

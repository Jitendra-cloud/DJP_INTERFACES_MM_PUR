*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_U01440_STAT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_U01440_STAT     .

  PERFORM TABLEPROC.

ENDFUNCTION.

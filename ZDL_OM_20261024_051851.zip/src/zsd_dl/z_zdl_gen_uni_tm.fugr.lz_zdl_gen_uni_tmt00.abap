*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_GEN_UNIT_ID.................................*
DATA:  BEGIN OF STATUS_ZDL_GEN_UNIT_ID               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_GEN_UNIT_ID               .
*.........table declarations:.................................*
TABLES: *ZDL_GEN_UNIT_ID               .
TABLES: ZDL_GEN_UNIT_ID                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

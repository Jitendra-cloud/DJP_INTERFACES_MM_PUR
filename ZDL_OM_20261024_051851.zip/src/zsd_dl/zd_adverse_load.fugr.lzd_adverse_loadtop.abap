FUNCTION-POOL ZD_ADVERSE_LOAD            MESSAGE-ID SV.

* INCLUDE LZD_ADVERSE_LOADD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZD_ADVERSE_LOADT00                     . "view rel. data dcl.

FUNCTION-POOL ZDL_E11734                 MESSAGE-ID SV.

* INCLUDE LZDL_E11734D...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDL_E11734T00                          . "view rel. data dcl.

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_I2387_TRADESTOP.              " Global Data
  INCLUDE LZDL_I2387_TRADESUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_I2387_TRADESF...              " Subroutines
* INCLUDE LZDL_I2387_TRADESO...              " PBO-Modules
* INCLUDE LZDL_I2387_TRADESI...              " PAI-Modules
* INCLUDE LZDL_I2387_TRADESE...              " Events
* INCLUDE LZDL_I2387_TRADESP...              " Local class implement.
* INCLUDE LZDL_I2387_TRADEST99.              " ABAP Unit tests
  INCLUDE LZDL_I2387_TRADESF00                    . " subprograms
  INCLUDE LZDL_I2387_TRADESI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

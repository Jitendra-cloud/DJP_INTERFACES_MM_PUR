FUNCTION ZSD_DL_U1165_READ_MACHINE_DET.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  TABLES
*"      ZT_ORD_MACHINES STRUCTURE  ZST_ORDERS_MACHINES
*"  EXCEPTIONS
*"      ORDERS_REQUIRED
*"      MACHINE_NUMBER_NOT_FOUND
*"      MACHINE_NUMBERS_NOT_FOUND
*"----------------------------------------------------------------------
*&--------------------------------------------------------------------*
*& FUNCTION ZSD_DL_U1165_READ_MACHINE_DET.                            *
***********************************************************************
**                                                                   **
**             C O M P A N Y   C O N F I D E N T I A L               **
**                                                                   **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
**                                                                   **
***********************************************************************
***********************************************************************
**                                                                   **
**                    COPYRIGHT (C) 2003 by                          **
**                     INTERNATIONAL PAPER                           **
**                                                                   **
**                     ALL RIGHTS RESERVED                           **
**                                                                   **
**                   REVISIONS COPYRIGHT (C)                         **
**                         2003, 20nn                                **
**                             by                                    **
**                     INTERNATIONAL PAPER                           **
***********************************************************************
*_____________________________________________________________________*
* FUNCTION ZSD_DL_U1165_READ_MACHINE_DET             Date: 10/05/2005 *
*                                                                     *
* SAP Name    :                                                       *
*                                                                     *
* Programmer  : Randall Wainwright                                    *
*                                                                     *
*_____________________________________________________________________*
* Description : Retrieves machine numbers for a list of orders
*---------------------------------------------------------------------*
*_____________________________________________________________________*
* Change History:                                                     *
*     Programmer        Date    Req. #            Action              *
* ==================  ========  ======  ==============================*
*
***********************************************************************

  DATA: st_ord_machines LIKE ZST_ORDERS_MACHINES,
        l_lines TYPE i.

* For multiple record selection
  DATA: BEGIN OF lt_aufpl OCCURS 0,
          aufnr LIKE afko-aufnr,
          aufpl LIKE afko-aufpl,
        END OF lt_aufpl.

  DATA: BEGIN OF lt_arbid OCCURS 0,
          aufpl LIKE afvc-aufpl,
          aplzl LIKE afvc-aplzl,
          arbid LIKE afvc-arbid,
        END OF lt_arbid.

  DATA: BEGIN OF lt_arbpl OCCURS 0,
          objty LIKE crhd-objty,
          objid LIKE crhd-objid,
          arbpl LIKE crhd-arbpl,
        END OF lt_arbpl.

  IF zt_ord_machines[] IS INITIAL.
    RAISE orders_required.
  ENDIF.

  CLEAR: st_ord_machines, l_lines.
  DESCRIBE TABLE zt_ord_machines[] LINES l_lines.
  IF l_lines = 1.
    READ TABLE zt_ord_machines INDEX 1 INTO st_ord_machines.
  ENDIF.

* Process for either one or many records
  IF NOT st_ord_machines-aufnr IS INITIAL.
    PERFORM ord_machine_single CHANGING st_ord_machines.
    CLEAR zt_ord_machines.
    REFRESH zt_ord_machines.
    zt_ord_machines = st_ord_machines.
    APPEND zt_ord_machines.
  ELSE.

    SORT zt_ord_machines BY aufnr.
    DELETE ADJACENT DUPLICATES FROM zt_ord_machines COMPARING aufnr.

    SELECT aufnr aufpl
      FROM afko
      INTO TABLE lt_aufpl
      FOR ALL ENTRIES IN zt_ord_machines
     WHERE aufnr = zt_ord_machines-aufnr.
    IF sy-subrc = 0.

      SORT lt_aufpl BY aufpl.
      SELECT aufpl aplzl arbid
        FROM afvc
        INTO TABLE lt_arbid
       FOR ALL ENTRIES IN lt_aufpl
       WHERE aufpl = lt_aufpl-aufpl
         AND aplzl = c_aplzl.
      IF sy-subrc = 0.

        SORT lt_arbid BY arbid.
        SELECT objty objid arbpl
          FROM crhd
          INTO TABLE lt_arbpl
       FOR ALL ENTRIES IN lt_arbid
         WHERE objty = c_objty
           AND objid = lt_arbid-arbid.

      ENDIF."SELECT SINGLE arbid success
    ENDIF."SELECT SINGLE aufpl success

* Build table from selected data
    SORT: lt_aufpl BY aufnr,
          lt_arbid BY aufpl,
          lt_arbpl BY objid.

    CLEAR zt_ord_machines.
    REFRESH zt_ord_machines.
    LOOP AT lt_aufpl.

      CLEAR lt_arbid.
      READ TABLE lt_arbid WITH KEY
         aufpl = lt_aufpl-aufpl
         BINARY SEARCH.
      CHECK sy-subrc = 0.

      CLEAR lt_arbpl.
      READ TABLE lt_arbpl WITH KEY
         objid = lt_arbid-arbid
         BINARY SEARCH.
      CHECK sy-subrc = 0.

      zt_ord_machines-aufnr = lt_aufpl-aufnr.
      zt_ord_machines-arbpl = lt_arbpl-arbpl.
      APPEND zt_ord_machines.
      CLEAR zt_ord_machines.

    ENDLOOP. " at zt_ord_machines.

    IF zt_ord_machines[] IS INITIAL.
      RAISE machine_numbers_not_found.
    ENDIF.

  ENDIF.

ENDFUNCTION.

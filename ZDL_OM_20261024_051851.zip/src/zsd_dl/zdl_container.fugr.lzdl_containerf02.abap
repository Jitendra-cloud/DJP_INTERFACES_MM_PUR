*----------------------------------------------------------------------*
***INCLUDE LZDL_CONTAINERF02 .
*----------------------------------------------------------------------*
* Change History:                                                      *
*     Programmer      Date     Req. #            Action                *
* ================  ========  =========    ============================*
* Padma Sunkara    07/07/2008 EDVK963900   Change in IDOC input        *
*                              CR# 8008    Getting Bookdoc instead of  *
*                                          Booknum                     *
* Maureen Carter     06/2016               SOLAS container tare logic  *
* David S Butler    01/05/17  EN#48563 - Correct the Tare weight       *
*                                        validation.                   *
* David S Butler   02/08/17   CHG195092  Add logic to add CHARG2       *
*                                        element to be able to handle  *
*                                        more than 10 characters for a *
*                                        batch number from Freight     *
*                                        Forwarder.                    *
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  zcontainer01_segment_modify
*&---------------------------------------------------------------------*
FORM zcontainer01_segment_modify .

  DATA : lv_charg      TYPE charg_d,
         lv_matnr      TYPE matnr,
         lv_ticount    TYPE i,  "temple inland ZSDOMFLD count    "CR11871
         lv_ticharg    TYPE charg_d,  "temple inland batch       "CR11871
         lv_stmshpline TYPE zsd_book_stmshpline.            "EN#4856

  CONSTANTS : lc_venbatch TYPE zcatgory VALUE 'VENDOR_BATCH', "CR11871
              lc_fldname  TYPE fieldname VALUE 'IB_846'.    "CR11871


  CASE gs_segm-segnam.

*get the container ID
    WHEN gs_e1edk01.
      CLEAR e1edk01.
*     check booking number is not blank
      MOVE gs_segm-sdata TO e1edk01.
      IF e1edk01-belnr IS INITIAL.
        PERFORM update_idoc_status USING  gc_e     "E
                                          '046'
                                          gc_error "51
                                          space
                                          space
                                          space.
      ELSE.
        gv_signi = e1edk01-belnr.
      ENDIF.

* 08/2015 EOP2 - get container size
      "      required field must be validated against ZSD_BOOK_CSZ_CFG
      IF e1edk01-bsart IS INITIAL.
        PERFORM update_idoc_status USING  gc_e     "E
                                          '800'
                                          gc_error "51
                                          space
                                          space
                                          space.
      ELSE.
        SELECT SINGLE con_size FROM zsd_book_csz_cfg INTO gv_cont_size
          WHERE con_size = e1edk01-bsart.
        IF sy-subrc > 0.
          PERFORM update_idoc_status USING  gc_e     "E
                                '801'
                                gc_error "51
                                space
                                space
                                space.
        ENDIF.
      ENDIF.

* 6/2016 SOLAS - validate container tare weight and UOM
* EN#48563 Begin - Move the tare weight validation to the e1edk02 segment validation because
*                  the BELNR is needed.
*      IF e1edk01-ntgew IS INITIAL.   "tare weight
      IF e1edk01-ntgew IS NOT INITIAL.   "tare weight
*        "Missing Container Tare - E1EDIK01-NTGEW
*        PERFORM update_idoc_status USING  gc_e     "E
*                             '805'
*                             gc_error "51
*                             space
*                             space
*                             space.
*      ELSE.
        "weight uom
        SELECT COUNT(*) FROM zsdomfld INTO lv_ticount
           WHERE category = 'E05641'
             AND fieldname = 'VALID_CONT_TARE_UOM'
             AND lowval = e1edk01-gewei.
        IF sy-subrc <> 0.
          "Missing or Invalid Container Tare UOM - E1EDIK01-GEWEI
          PERFORM update_idoc_status USING  gc_e     "E
                                '806'
                                gc_error "51
                                space
                                space
                                space.
        ENDIF.
        gv_tare = e1edk01-ntgew.
        gv_uom = e1edk01-gewei.
      ENDIF.
*      gv_tare = e1edk01-ntgew.
*      gv_uom = e1edk01-gewei.
* EN#48563 End

* get  signi and seal
    WHEN gs_e1edk02.
      CLEAR e1edk02.
      MOVE gs_segm-sdata TO e1edk02.

      IF e1edk02-qualf = 'SEA'.
        gv_seal = e1edk02-belnr.

      ELSEIF e1edk02-qualf = 'BKN'.
* Begin change CR# 8008  Transport EDVK963900
*        gv_booknum = e1edk02-belnr. "//psunkar 06/24/08
        gv_bookdoc_i = e1edk02-belnr.  " \\psunkar
* End change CR# 8008  Transport : EDVK963900

* EN#48563 Begin - Added the tare weight validation here because
*                  the BELNR is needed from the e1edk02 segment

        "Validate no tare weight value
        IF gv_tare IS INITIAL.

          "Select Steamship Line
          SELECT SINGLE stmshpline FROM zsd_book_hdr INTO lv_stmshpline
            WHERE bookdoc EQ e1edk02-belnr.

          "Validate record was found
          IF sy-subrc NE 0.

            PERFORM update_idoc_status USING  gc_e     "E
                                  '072'
                                  gc_error "51
                                  e1edk02-belnr
                                  space
                                  space.
            "Validate for data
          ELSEIF lv_stmshpline IS INITIAL.

            "Missing or Invalid Steamship Line
            PERFORM update_idoc_status USING  gc_e     "E
                                  '807'
                                  gc_error "51
                                  e1edk02-belnr
                                  space
                                  space.
          ELSE.

            "Select Tare weight and UOM
            SELECT SINGLE cont_tare
                          uom
              FROM zsd_book_con_tar
              INTO ( gv_tare, gv_uom )
              WHERE stmshpline EQ lv_stmshpline
              AND   con_size   EQ gv_cont_size.

            "Validate record was found
            IF sy-subrc NE 0.
              "Missing or Invalid Container tare and UOM
              PERFORM update_idoc_status USING  gc_e     "E
                                    '808'
                                    gc_error "51
                                    lv_stmshpline
                                    gv_cont_size
                                    space.
            ENDIF.
          ENDIF.
        ENDIF.
* EN#48563 End
      ENDIF.

* get the matnr
    WHEN gs_e1edp01.
      MOVE gs_segm-sdata TO e1edp01.
      CLEAR gv_matnr .
      gv_matnr = e1edp01-matnr.
      CONDENSE gv_matnr.

* get the batches
    WHEN gs_z1subitm.
      CLEAR z1subitm.
      MOVE gs_segm-sdata TO z1subitm.
      IF z1subitm-charg IS INITIAL.
        PERFORM update_idoc_status USING  gc_e     "E
                                          '047'
                                          gc_error "51
                                          gv_signi
                                          space
                                          space.

      ELSE.
* check whether the batch is valid for the material
*Convert the material
        CALL FUNCTION 'CONVERSION_EXIT_MATN2_INPUT'
          EXPORTING
            input            = gv_matnr
          IMPORTING
            output           = lv_matnr
          EXCEPTIONS
            number_not_found = 1
            length_error     = 2
            OTHERS           = 3.

*CHG195092 Begin - Add validation of the CHARG2 value
        IF strlen( z1subitm-charg2 ) < 11.

          SELECT SINGLE charg
              FROM  mcha
              INTO lv_charg
            WHERE matnr = lv_matnr AND
                  charg = z1subitm-charg.
        ENDIF.

        IF lv_charg IS INITIAL.
*        IF sy-subrc <> 0 .
*CHG195092 End - Add validation of the CHARG2 value


* CR11871: I02516 - Temple Inland C terms - Begin
* If there is no bach in MCHA (batch table)
* Check there is a entry in ZSDOMFLD table for Temple Inland C Terms
          CLEAR lv_ticount.
          SELECT COUNT(*) INTO lv_ticount
          FROM  zsdomfld
          WHERE category = lc_venbatch AND
                fieldname = lc_fldname.
          IF lv_ticount > 0.
* Get Batch number from batch table(MCH1) by matching vendor batch number
            CLEAR lv_ticharg.

*CHG195092 - Added the CHARG2 field for selection and errors

            SELECT SINGLE charg
            FROM  mch1
            INTO lv_ticharg
            WHERE matnr = lv_matnr AND
                  licha = z1subitm-charg2.  "CHG195092
            IF sy-subrc <> 0.
              PERFORM update_idoc_status USING  gc_e     "E
                                            '074'
                                            gc_error "51
                                            z1subitm-charg2  "CHG195092
                                            gv_matnr
                                            space.
            ENDIF.
          ELSE.
*       CR11871: I02516 - Temple Inland C terms - End

            PERFORM update_idoc_status USING  gc_e     "E
                                              '074'
                                              gc_error "51
                                              z1subitm-charg2   "CHG195092
                                              gv_matnr
                                              space.

          ENDIF.

        ENDIF.

        gt_charg-charg = z1subitm-charg .

* CR11871: I02516 - Temple Inland C terms - Begin
        IF NOT lv_ticharg IS INITIAL.
          gt_charg-charg = lv_ticharg.
          CLEAR lv_ticharg.
        ENDIF.
*  CR11871: I02516 - Temple Inland C terms - End

        CONDENSE gt_charg-charg.
        APPEND gt_charg.
        CLEAR gt_charg.
      ENDIF.
  ENDCASE.

ENDFORM.                    " zcontainer01_segment_modify

*&---------------------------------------------------------------------*
*&      Form  update_idoc_status
*&---------------------------------------------------------------------*
FORM update_idoc_status USING pi_msgtyp TYPE bdidocstat-msgty
                              pi_msgno  TYPE bdidocstat-msgno
                              pi_status TYPE bdidocstat-status
                              pi_msgv1  TYPE any
                              pi_msgv2  TYPE any
                              pi_msgv3  TYPE any.

  DATA: ls_status TYPE bdidocstat.
*--- Insert the record to IDOC Status structure
  ls_status-docnum = gs_control-docnum.
  ls_status-status = pi_status.
  ls_status-msgty =  pi_msgtyp.
  ls_status-msgid =  gc_msgid.
  ls_status-msgno =  pi_msgno.
  ls_status-msgv1 =  pi_msgv1.
  ls_status-msgv2 =  pi_msgv2.
  ls_status-msgv3 =  pi_msgv3.

  APPEND ls_status TO  gt_idoc_status.

ENDFORM.                    " update_idoc_status

*&---------------------------------------------------------------------*
*&      Form  initialize_variables
*&---------------------------------------------------------------------*
FORM initialize_variables .

  CLEAR : gt_charg ,
          gt_book_itm,
          gv_signi,
          gv_seal,
          gv_booknum,
          gv_bookdoc,
          gv_bookdoc_i, "psunkar 06/24/08
          gt_idoc_status.

  REFRESH : gt_charg,
            gt_book_itm,
            gt_vepo,
            gt_ekko,
            gt_ekes,
            gt_hus_to_pack,
            gt_idoc_status.
ENDFORM.                    " initialize_variables

*&---------------------------------------------------------------------*
*&      Form  get_vepo
*&---------------------------------------------------------------------*
FORM get_vepo .

  IF gt_charg[] IS NOT INITIAL.
    SELECT venum
           matnr
           vbeln
           werks
           charg
           lgort
        INTO TABLE gt_vepo
        FROM vepo
        FOR ALL ENTRIES IN  gt_charg
        WHERE charg = gt_charg-charg.

    IF sy-subrc =  0 .
* check all the entries for the batches have been retreived.
      LOOP AT gt_charg.
        READ TABLE gt_vepo WITH KEY charg = gt_charg-charg.
        IF sy-subrc <> 0.
          PERFORM update_idoc_status USING  gc_e     "E
                                            '048'
                                            gc_error "51
                                            gt_charg-charg
                                            space
                                            space.
        ENDIF.
      ENDLOOP.
      SORT gt_vepo BY venum.
      DELETE ADJACENT DUPLICATES FROM  gt_vepo COMPARING venum.
    ELSE.
* if no entries have been retreived
      LOOP AT gt_charg.
        PERFORM update_idoc_status USING  gc_e     "E
                                          '048'
                                          gc_error "51
                                          gt_charg-charg
                                          space
                                          space.
      ENDLOOP.

    ENDIF.
  ENDIF.

ENDFORM.                    " get_vepo

*&---------------------------------------------------------------------*
*&      Form  validate_products
*&---------------------------------------------------------------------*
FORM validate_products .

  DATA : BEGIN OF lt_mara OCCURS 0 ,
           matnr TYPE matnr,
           matkl TYPE matkl,
         END OF lt_mara.

  DATA : lt_vepo_matnr LIKE gt_vepo OCCURS 0 WITH HEADER LINE.


* move gt_vepo to a local internal table
  lt_vepo_matnr[] = gt_vepo[].
  SORT lt_vepo_matnr BY matnr.
  DELETE ADJACENT DUPLICATES FROM lt_vepo_matnr COMPARING matnr.

  IF NOT lt_vepo_matnr[] IS INITIAL.
* get the material group
    SELECT matnr
           matkl
        FROM mara
        INTO TABLE lt_mara
        FOR ALL ENTRIES IN lt_vepo_matnr
        WHERE matnr =  lt_vepo_matnr-matnr.

  ENDIF.

* CLEAR  gv_sord.        "  EDVK964855    TPR 01756
  LOOP AT gt_vepo.

    READ TABLE lt_mara WITH KEY matnr = gt_vepo-matnr .

    IF sy-subrc = 0 .
* if material group is make to order
      IF lt_mara-matkl = 'BSK'.
        CONTINUE.
      ELSEIF lt_mara-matkl = 'SMT' OR
             lt_mara-matkl = 'SMC' OR
             lt_mara-matkl = 'SMD' OR
             lt_mara-matkl = 'SMS' OR
             lt_mara-matkl = 'FPL'.
* check whether it a MTO OR MTS
        PERFORM check_mto .
*      ELSE. "psunkar 06/24/08
*        PERFORM check_mts.   "//psunkar 06/24/08
      ENDIF.
    ELSE.
      PERFORM update_idoc_status USING  gc_e     "E
                                        '049'
                                        gc_error "51
                                        gt_vepo-matnr
                                        gt_vepo-charg
                                        space.

    ENDIF.
  ENDLOOP.

ENDFORM.                    " validate_products

*&---------------------------------------------------------------------*
*&      Form  check_mto
*&---------------------------------------------------------------------*
FORM check_mto .
  " 08/2015 EOP2 multiple sales orders are allowed in a container
  DATA :  lt_mska LIKE mska OCCURS 0 WITH HEADER LINE .
  REFRESH : lt_mska .
  CLEAR : lt_mska  .
  IF gt_book_itm[] IS NOT INITIAL.
    SELECT * FROM mska INTO TABLE lt_mska
         FOR ALL ENTRIES IN gt_book_itm
        WHERE matnr = gt_vepo-matnr AND
              charg = gt_vepo-charg AND
              werks = gt_vepo-werks AND
              lgort = gt_vepo-lgort AND
              vbeln = gt_book_itm-vbeln AND
              posnr = gt_book_itm-posnr AND
              kalab > 0 .

    IF sy-subrc = 0.       "  EDVK964855    TPR 01756
      CLEAR lt_mska.
      READ TABLE lt_mska INDEX 1.

    ELSE.
      READ TABLE gt_book_itm INDEX 1.
      PERFORM update_idoc_status USING  gc_e     "E
                                        '050'
                                        gc_error "51
                                        gt_vepo-matnr
                                        gt_book_itm-vbeln
                                        space.
    ENDIF.
  ENDIF.
ENDFORM.                    " check_mto

*&---------------------------------------------------------------------*
*&      Form  check_mts
*&---------------------------------------------------------------------*
FORM check_mts .

  IF gv_check = space.
    PERFORM get_ekko_ekes.
    gv_check = 'X'.
    READ TABLE gt_ekes WITH KEY  charg = gt_vepo-charg.
    IF sy-subrc <> 0.
      PERFORM update_idoc_status USING  gc_e     "E
                                        '051'   "001
                                        gc_error "51
                                        gt_vepo-charg
                                        space
                                        space.

    ENDIF.
  ENDIF.

ENDFORM.                    " check_mts

*&---------------------------------------------------------------------*
*&      Form  get_ekko_ekes
*&---------------------------------------------------------------------*
FORM get_ekko_ekes .
  IF gt_book_itm[] IS NOT INITIAL.
    SELECT  ebeln FROM  ekko
     INTO TABLE gt_ekko
    FOR ALL ENTRIES IN gt_book_itm
     WHERE zzvbeln = gt_book_itm-vbeln AND
           zzposnr = gt_book_itm-posnr.
    IF sy-subrc <> 0 .
      READ TABLE gt_book_itm INDEX 1.
      PERFORM update_idoc_status USING  gc_e     "E
                                        '052'
                                        gc_error "51
                                        gt_book_itm-vbeln
                                        gt_book_itm-posnr
                                        space.
    ELSE.
      SELECT ebeln
             charg
        FROM ekes
        INTO TABLE gt_ekes
        FOR ALL ENTRIES IN gt_ekko
        WHERE ebeln = gt_ekko-ebeln.
      IF sy-subrc <> 0.
        READ TABLE gt_ekko INDEX 1.
        PERFORM update_idoc_status USING  gc_e     "E
                                          '053'
                                          gc_error "51
                                          gt_ekko-ebeln
                                          space
                                          space.

      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " get_ekko_ekes

*&---------------------------------------------------------------------*
*&      Form  get_hus_to_pack
*&---------------------------------------------------------------------*
FORM get_hus_to_pack .

  IF NOT gt_vepo[] IS INITIAL.
    SELECT exidv FROM vekp
     INTO TABLE gt_hus_to_pack_cont
     FOR ALL ENTRIES IN gt_vepo
     WHERE venum = gt_vepo-venum.
  ENDIF.
  IF sy-subrc <> 0 .
    READ TABLE gt_vepo INDEX 1.
    PERFORM update_idoc_status USING  gc_e     "E
                                      '054'
                                      gc_error "51
                                      gt_vepo-venum
                                      space
                                      space.
  ENDIF.

ENDFORM.                    " get_hus_to_pack

*&---------------------------------------------------------------------*
*&      Form  create_container
*&---------------------------------------------------------------------*
*       creates container HU and updates ZDLU01267_VEKP
*----------------------------------------------------------------------*
FORM create_container .
  DATA : lv_bapi_message TYPE bapi_msg . "work field for bapi message
  DATA : lv_success(1) TYPE c.                              "CR11962
  CLEAR : gt_vepo , gv_container_exidv , gv_container_venum ,
  lv_bapi_message .
  READ TABLE gt_vepo INDEX 1 .
  CLEAR gt_book_itm.
  READ TABLE gt_book_itm INDEX 1.
  CALL FUNCTION 'ZDL_CREATE_CONTAINER'
    EXPORTING
      iv_signi                       = gv_signi
      iv_seal                        = gv_seal
      iv_size                        = gv_cont_size
      iv_booknum                     = gv_booknum
      iv_bookdoc                     = gv_bookdoc
      iv_werks                       = gt_vepo-werks
      iv_vbeln                       = gt_book_itm-vbeln
      iv_tare                        = gv_tare
      "IV_VGM      defaults to blank so the function will calc VGM based on VEKP values
      iv_uom                         = gv_uom
    IMPORTING
      ev_container_exidv             = gv_container_exidv
      ev_container_venum             = gv_container_venum
      ev_bapi_error_msg              = lv_bapi_message
    TABLES
      it_hus_to_pack                 = gt_hus_to_pack_cont
      et_return                      = gt_return
    EXCEPTIONS
      error_retrieving_unique_exidv  = 1
      error_calling_unique_exidv     = 2
      no_container_packing_material  = 3
      bapi_hu_create_failed          = 4
      bapi_transaction_commit_failed = 5
      bapi_hu_pack_failed            = 6
      error_inserting_zdlu01267_vekp = 7
      error_retrieving_container     = 8
      handling_unit_locked           = 9
      invalid_hu_passed              = 10
      containerid_seal_already_exist = 11
      invalid_booking_number         = 12
      invalid_booking_document       = 13
      OTHERS                         = 14.
  IF sy-subrc <> 0.
    CLEAR gs_return.
*    READ TABLE gt_return INTO gs_return WITH KEY type = 'E'.
    CASE sy-subrc .
      WHEN 1 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '055'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 2 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '056'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 3 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '057'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 4 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '058'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 5 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '059'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 6 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '060'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 7 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '061'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 8 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '062'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 9 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '063'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 10 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '064'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 11 .
        PERFORM vekp_lookup.

      WHEN 12 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '066'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 13 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '067'
                                          gc_error "51
                                          space
                                          space
                                          space.
      WHEN 14 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '068'
                                          gc_error "51
                                          sy-subrc
                                          space
                                          space.
    ENDCASE.

  ELSE.
    READ TABLE gt_return INTO gs_return WITH KEY type = 'E'.
    IF sy-subrc = 0 .
      PERFORM update_idoc_status USING  gc_e     "E
                                       '069'
                                        gc_error "51
                                        gs_return-message
                                        space
                                        space.
    ELSE.
* Success
*--- Update the Success Status of the IDOC
      PERFORM update_idoc_status USING  gc_s     "E
                                        '070'
                                        gc_success "53
                                        gv_container_exidv
                                        space
                                        space.
    ENDIF.
  ENDIF.

ENDFORM.                    " create_container

*&---------------------------------------------------------------------*
*&      Form  check_document
*&---------------------------------------------------------------------*
FORM check_document .
  TYPES: BEGIN OF tt_vbak,
           vbeln         TYPE vbeln_va,             "2nd field in table
           kunnr         TYPE kunag,                "48
           zz_metric_ind TYPE zz_metric_indicator,  "275
         END OF tt_vbak.
  DATA: ls_vbak   TYPE tt_vbak,
        lt_vbak   TYPE TABLE OF tt_vbak,
        lt_vbak_w TYPE TABLE OF tt_vbak.

  TYPES: BEGIN OF tt_vbpa,
           vbeln TYPE vbeln,    "sales order
           posnr TYPE posnr,    "line item
           kunnr TYPE kunnr,    "ship-to customer
         END OF tt_vbpa.
  DATA: ls_vbpa TYPE tt_vbpa,
        lt_vbpa TYPE TABLE OF tt_vbpa.

  DATA: lv_count1    TYPE i.

  IF gv_bookdoc_i IS INITIAL. " psunkar 06/24/08
    PERFORM update_idoc_status USING  gc_e     "E
                                      '071'
                                      gc_error "51
                                      space
                                      space
                                      space.


  ELSE.
    SELECT SINGLE bookdoc booknum
              FROM zsd_book_hdr
           INTO  (gv_bookdoc, gv_booknum )                  "CR# 8008
                                           "Transport EDVK963900
           WHERE bookdoc = gv_bookdoc_i.  " psunkar 06/24/08
    IF sy-subrc <> 0 .
      PERFORM update_idoc_status USING  gc_e     "E
                                        '072'
                                        gc_error "51
                                        gv_bookdoc_i "//psunkar06/24/08
                                        space
                                        space.

    ELSE.

      SELECT bookdoc
             bookitm
             vbeln
             posnr
        INTO TABLE gt_book_itm
        FROM zsd_book_itm
        WHERE bookdoc = gv_bookdoc.
      IF sy-subrc <> 0 .
        PERFORM update_idoc_status USING  gc_e     "E
                                          '073'
                                          gc_error "51
                                          gv_bookdoc
                                          space
                                          space.
      ENDIF.
    ENDIF.
  ENDIF.

* 08/2015 EOP2 - check booking for multiple sold-to, ship-to and metric indicator
  CHECK NOT gt_book_itm[] IS INITIAL.

* get sold-to partner(s) and metric indicator(s) for the sales orders on the booking
  SELECT * FROM vbak INTO CORRESPONDING FIELDS OF TABLE lt_vbak
        FOR ALL ENTRIES IN gt_book_itm
        WHERE vbeln = gt_book_itm-vbeln.
  IF sy-subrc = 0.
    lt_vbak_w[] = lt_vbak[].
    SORT lt_vbak_w BY kunnr.
    DELETE ADJACENT DUPLICATES FROM lt_vbak_w COMPARING kunnr.
    CLEAR lv_count1.
    DESCRIBE TABLE lt_vbak_w LINES lv_count1.
    IF lv_count1 > 1.
      "Multiple SOLD_TOs for booking &
      PERFORM update_idoc_status USING  gc_e     "E
                                        '802'
                                        gc_error "51
                                        gv_bookdoc
                                        space
                                        space.
    ELSE.
      CLEAR lt_vbak_w[].
      lt_vbak_w[] = lt_vbak[].
      SORT lt_vbak_w BY zz_metric_ind.
      DELETE ADJACENT DUPLICATES FROM lt_vbak_w COMPARING zz_metric_ind.
      CLEAR lv_count1.
      DESCRIBE TABLE lt_vbak_w LINES lv_count1.
      IF lv_count1 > 1.
        "Multiple METRICINDs for booking &
        PERFORM update_idoc_status USING  gc_e     "E
                                          '804'
                                          gc_error "51
                                          gv_bookdoc
                                          space
                                          space.
      ENDIF.
    ENDIF.
  ENDIF.

* get ship-to partner(s) for the sales orders on the booking
  SELECT * FROM vbpa INTO CORRESPONDING FIELDS OF TABLE lt_vbpa
        FOR ALL ENTRIES IN gt_book_itm
        WHERE vbeln = gt_book_itm-vbeln
          AND parvw = 'WE'.       "ship-to partner type
  SORT lt_vbpa BY kunnr.
  DELETE ADJACENT DUPLICATES FROM lt_vbpa COMPARING kunnr.
  CLEAR lv_count1.
  DESCRIBE TABLE lt_vbpa LINES lv_count1.
  IF lv_count1 > 1.
    "Multiple SHIP_TOs for booking &
    PERFORM update_idoc_status USING  gc_e     "E
                                      '803'
                                      gc_error "51
                                      gv_bookdoc
                                      space
                                      space.
  ENDIF.

ENDFORM.                    " check_document

*&---------------------------------------------------------------------*
*&      Form  trigger_workflow
*&---------------------------------------------------------------------*
* Trigger the workflow if the idoc status table have a 51 status
*----------------------------------------------------------------------*
FORM trigger_workflow TABLES pt_return_variables STRUCTURE bdwfretvar
                    CHANGING pc_workflow_result  TYPE bdwfap_par-result.

  DATA:lc_wf_result_error LIKE bdwfap_par-result VALUE '99999',
       lc_wf_result_ok    LIKE bdwfap_par-result VALUE '0'.

*---check whether the IDOC got any error message, if error found
*---don't process the IDOC
  READ TABLE gt_idoc_status TRANSPORTING NO FIELDS
                              WITH KEY status = '51'.

  IF sy-subrc EQ 0.

*---trigger workflow if found error in the IDOC
    pt_return_variables-wf_param = text-e12.
    pt_return_variables-doc_number = gs_control-docnum.
    APPEND pt_return_variables.CLEAR pt_return_variables.
    pc_workflow_result = lc_wf_result_error.

  ELSE.

*---if there is no error on the IDOC then
    pc_workflow_result =  lc_wf_result_ok.

  ENDIF.

ENDFORM.                    " trigger_workflow

*&---------------------------------------------------------------------*
*&      Form  VEKP_LOOKUP
*&---------------------------------------------------------------------*
FORM vekp_lookup.
  DATA : lv_venum      TYPE venum,
         lv_success(1) TYPE c,
         ls_vekp       TYPE vekp.
  ""        gs_temp_vepo type gt_vepo.
  DATA : BEGIN OF gs_temp_vepo.
          INCLUDE STRUCTURE gt_vepo.
  DATA END OF gs_temp_vepo.


  CLEAR: lv_venum, lv_success.

  SELECT SINGLE venum INTO lv_venum FROM zdlu01267_vekp
    WHERE signi = gv_signi
      AND seal  = gv_seal.

  LOOP AT gt_vepo INTO gs_temp_vepo.
    SELECT * INTO ls_vekp FROM vekp
      WHERE venum = gs_temp_vepo-venum
        AND uevel = lv_venum.
      IF sy-subrc NE 0.
        lv_success = 'N'.
        EXIT.
      ENDIF.
    ENDSELECT.
    CLEAR gs_temp_vepo.
  ENDLOOP.

  "if we find all batches, then use gc_success, else continue with error
  IF lv_success NE 'N'.
    PERFORM update_idoc_status USING  gc_s     "S
                                      '065'
                                      gc_success "53
                                      gv_container_exidv
                                      space
                                      space.
  ELSE.
    PERFORM update_idoc_status USING  gc_e     "E
                                      '065'
                                      gc_error "51
                                      space
                                      space
                                      space.
  ENDIF.

ENDFORM.                    " VEKP_LOOKUP

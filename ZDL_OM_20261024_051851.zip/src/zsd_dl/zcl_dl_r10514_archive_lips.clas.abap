class ZCL_DL_R10514_ARCHIVE_LIPS definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ty_s_archive,
        arch_key TYPE arkey,
        date     TYPE char4,
      END OF ty_s_archive .
  types:
    ty_t_archive_key TYPE STANDARD TABLE OF admi_file_davlnk WITH DEFAULT KEY .
  types:
    ty_t_archive     TYPE STANDARD TABLE OF ty_s_archive WITH DEFAULT KEY .

  class-data MV_MESSAGE type STRING .

  class-methods GET_ARCHIVE_DATA
    importing
      !IV_ARCHIVE_OBJECT type ARCH_OBJ-OBJECT
      !IV_FILTER_KEY type BOOLEAN optional
      !IR_DATE type RANGE_T_DATS optional
      !IT_ARCH_KEY type TY_T_ARCHIVE_KEY optional
      !IV_TABLE_1 type RKZ_DBNA
      !IV_TABLE_2 type RKZ_DBNA optional
      !IV_TABLE_3 type RKZ_DBNA optional
      !IV_TABLE_4 type RKZ_DBNA optional
      !IV_TABLE_5 type RKZ_DBNA optional
      !IV_TABLE_6 type RKZ_DBNA optional
      !IV_TABLE_7 type RKZ_DBNA optional
      !IV_TABLE_8 type RKZ_DBNA optional
      !IV_TABLE_9 type RKZ_DBNA optional
      !IV_TABLE_10 type RKZ_DBNA optional
      !IV_TABLE_11 type RKZ_DBNA optional
      !IV_TABLE_12 type RKZ_DBNA optional
      !IV_TABLE_13 type RKZ_DBNA optional
      !IV_TABLE_14 type RKZ_DBNA optional
      !IV_TABLE_15 type RKZ_DBNA optional
      !CO_RECORD_REF_11 type ref to DATA optional
      !CO_RECORD_REF_12 type ref to DATA optional
      !CO_RECORD_REF_13 type ref to DATA optional
      !CO_RECORD_REF_14 type ref to DATA optional
      !CO_RECORD_REF_15 type ref to DATA optional
      !CO_RECORD_REF_4 type ref to DATA optional
      !CO_RECORD_REF_5 type ref to DATA optional
      !CO_RECORD_REF_6 type ref to DATA optional
      !CO_RECORD_REF_7 type ref to DATA optional
      !CO_RECORD_REF_8 type ref to DATA optional
      !CO_RECORD_REF_9 type ref to DATA optional
      !CO_RECORD_REF_10 type ref to DATA optional
      !CO_RECORD_REF_1 type ref to DATA
      !CO_RECORD_REF_2 type ref to DATA optional
      !CO_RECORD_REF_3 type ref to DATA optional
    exporting
      !EV_ERROR type STRING .
protected section.
private section.

  class-methods GET_ARCHIVE_KEY
    importing
      !IV_OBJECT type ARCH_OBJ-OBJECT
    exporting
      !ET_ARCH_KEY type TY_T_ARCHIVE_KEY .
  class-methods FILTER_ARCHIVE_KEY
    importing
      !IR_DATE type RANGE_T_DATS optional
      !IT_ARCH_KEY type TY_T_ARCHIVE_KEY optional
    exporting
      !ET_ARCH_KEY type TY_T_ARCHIVE .
  class-methods ARCHIVE_READ
    importing
      !IV_ARCHIV_KEY type ARKEY
      !IV_OBJECT type ARCH_OBJ-OBJECT
    exporting
      !EV_ARCHIVE_HANDLE type SY-TABIX .
  class-methods GET_ARCHIVE_NEXT_OBJECT
    importing
      !IV_ARCHIVE_HANDLE type SY-TABIX
    exporting
      !EV_EXIT type BOOLEAN .
  class-methods GET_ARCHIVE_NEXT_RECORD
    importing
      !IV_ARCHIVE_HANDLE type SY-TABIX
    exporting
      !EV_EXIT type BOOLEAN
      !EO_RECORD_REF type ref to DATA
      !EV_OBJECT_NAME type RKZ_DBNA .
ENDCLASS.



CLASS ZCL_DL_R10514_ARCHIVE_LIPS IMPLEMENTATION.


  METHOD archive_read.
    CLEAR ev_archive_handle.
    CALL FUNCTION 'ARCHIVE_OPEN_FOR_READ'
      EXPORTING
        archive_name                 = iv_archiv_key
        object                       = iv_object
      IMPORTING
        archive_handle               = ev_archive_handle
      EXCEPTIONS
        file_already_open            = 1
        file_io_error                = 2
        internal_error               = 3
        no_files_available           = 4
        object_not_found             = 5
        open_error                   = 6
        not_authorized               = 7
        archiving_standard_violation = 8
        OTHERS                       = 9.
    IF sy-subrc <> 0.
      CLEAR ev_archive_handle.
    ENDIF.
  ENDMETHOD.


  METHOD filter_archive_key.
    DATA lr_filter_year TYPE RANGE OF char4.
    CLEAR et_arch_key.
    et_arch_key = VALUE #( FOR ls_arch_key IN it_arch_key
                           ( arch_key   = ls_arch_key-archiv_key
                             date       = |{ ls_arch_key-start_retention }| ) ).
    lr_filter_year = VALUE #( FOR ls_date IN ir_date
                       ( sign   = ls_date-sign
                         option = ls_date-option
                         low    = ls_date-low
                         high   = ls_date-high ) ).
    DELETE et_arch_key WHERE date NOT IN lr_filter_year.
  ENDMETHOD.


  METHOD get_archive_data.
    DATA:lo_record_ref TYPE REF TO data.
    FIELD-SYMBOLS: <table1>        TYPE STANDARD TABLE,
                   <table2>        TYPE STANDARD TABLE,
                   <table3>        TYPE STANDARD TABLE,
                   <table4>        TYPE STANDARD TABLE,
                   <table5>        TYPE STANDARD TABLE,
                   <table6>        TYPE STANDARD TABLE,
                   <table7>        TYPE STANDARD TABLE,
                   <table8>        TYPE STANDARD TABLE,
                   <table9>        TYPE STANDARD TABLE,
                   <table10>       TYPE STANDARD TABLE,
                   <table11>       TYPE STANDARD TABLE,
                   <table12>       TYPE STANDARD TABLE,
                   <table13>       TYPE STANDARD TABLE,
                   <table14>       TYPE STANDARD TABLE,
                   <table15>       TYPE STANDARD TABLE,
                   <ls_table>      TYPE any,
                   <lt_table_data> TYPE STANDARD TABLE.
    CHECK iv_archive_object IS NOT INITIAL.
    SELECT SINGLE object
      FROM arch_obj
      INTO @DATA(lv_object)
      WHERE object = @iv_archive_object.
    IF sy-subrc <> 0.
      MESSAGE e000(zdl_r10514) WITH TEXT-001 INTO ev_error.
      RETURN.
    ENDIF.

    IF it_arch_key IS INITIAL.
      get_archive_key(
        EXPORTING
          iv_object   = iv_archive_object                 " Archiving Object
        IMPORTING
          et_arch_key = DATA(lt_arch_key) ).
    ENDIF.

    IF ir_date IS INITIAL AND
       it_arch_key IS INITIAL.
      MESSAGE e000(zdl_r10514) WITH TEXT-002 INTO ev_error.
      RETURN.
    ENDIF.

    IF ir_date IS NOT INITIAL AND
       it_arch_key IS INITIAL AND
       iv_filter_key = abap_true.
      filter_archive_key(
        EXPORTING
          ir_date     = ir_date                 " Range Table for Data Element SYDATUM
          it_arch_key = lt_arch_key
        IMPORTING
          et_arch_key = DATA(lt_archive_key) ).
    ELSE.
      lt_archive_key = VALUE #( FOR ls_arch_key IN lt_arch_key
                                ( arch_key = ls_arch_key-archiv_key ) ).
    ENDIF.

    IF it_arch_key IS NOT INITIAL.
      lt_archive_key = it_arch_key.
    ENDIF.

    LOOP AT lt_archive_key INTO DATA(ls_archiv_key).
      archive_read(
        EXPORTING
          iv_archiv_key     = ls_archiv_key-arch_key
          iv_object         = iv_archive_object
        IMPORTING
          ev_archive_handle = DATA(lv_archive_handle) ).

      DO.
        get_archive_next_object(
          EXPORTING
            iv_archive_handle = lv_archive_handle
          IMPORTING
            ev_exit           = DATA(lv_exit) ).
        IF lv_exit = abap_true.
          EXIT.
        ENDIF.
        DO.
          get_archive_next_record(
            EXPORTING
              iv_archive_handle = lv_archive_handle                 " ABAP System Field: Row Index of Internal Tables
            IMPORTING
              ev_exit           = lv_exit                 " Boolean Variable (X=true, -=false, space=unknown)
              eo_record_ref     = lo_record_ref
              ev_object_name    = DATA(lv_object_name) ).                 " Table Name
          IF lv_exit = abap_true.
            EXIT.
          ENDIF.
          ASSIGN lo_record_ref->* TO FIELD-SYMBOL(<ls_record>).
          CASE lv_object_name.
            WHEN iv_table_1.
              ASSIGN co_record_ref_1->* TO <table1>.
              APPEND INITIAL LINE TO <table1> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_2.
              ASSIGN co_record_ref_2->* TO <table2>.
              APPEND INITIAL LINE TO <table2> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_3.
              ASSIGN co_record_ref_3->* TO <table3>.
              APPEND INITIAL LINE TO <table3> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_4.
              ASSIGN co_record_ref_4->* TO <table4>.
              APPEND INITIAL LINE TO <table4> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_5.
              ASSIGN co_record_ref_5->* TO <table5>.
              APPEND INITIAL LINE TO <table5> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_6.
              ASSIGN co_record_ref_6->* TO <table6>.
              APPEND INITIAL LINE TO <table6> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_7.
              ASSIGN co_record_ref_7->* TO <table7>.
              APPEND INITIAL LINE TO <table7> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_8.
              ASSIGN co_record_ref_8->* TO <table8>.
              APPEND INITIAL LINE TO <table8> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_9.
              ASSIGN co_record_ref_9->* TO <table9>.
              APPEND INITIAL LINE TO <table9> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_10.
              ASSIGN co_record_ref_10->* TO <table10>.
              APPEND INITIAL LINE TO <table10> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_11.
              ASSIGN co_record_ref_11->* TO <table11>.
              APPEND INITIAL LINE TO <table11> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_12.
              ASSIGN co_record_ref_12->* TO <table12>.
              APPEND INITIAL LINE TO <table12> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_13.
              ASSIGN co_record_ref_13->* TO <table13>.
              APPEND INITIAL LINE TO <table13> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_14.
              ASSIGN co_record_ref_14->* TO <table14>.
              APPEND INITIAL LINE TO <table14> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN iv_table_15.
              ASSIGN co_record_ref_15->* TO <table15>.
              APPEND INITIAL LINE TO <table15> ASSIGNING <ls_table>.
              <ls_table> =  CORRESPONDING #( <ls_record> ).
            WHEN OTHERS.
          ENDCASE.
        ENDDO.
      ENDDO.
      IF <table1> IS ASSIGNED.
        MODIFY zlips_archive FROM TABLE <table1>.
        MESSAGE 'File data updated' TYPE 'S'.
        CLEAR <table1>.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


  METHOD get_archive_key.
    DATA: lt_runs  TYPE TABLE OF admi_run,
          lt_files TYPE TABLE OF admi_files,
          lt_varia TYPE arch_t_varia.
    CLEAR et_arch_key.
    CALL FUNCTION 'ARCHIVE_REMOTE_SELECT_ADMIN'
      EXPORTING
        iv_object  = iv_object
      TABLES
        et_runs    = lt_runs
        et_files   = lt_files
        et_varia   = lt_varia
        et_davlnk  = et_arch_key
      EXCEPTIONS
        open_error = 1
        OTHERS     = 2.
    IF sy-subrc = 0.
      SORT et_arch_key BY start_retention ASCENDING.
    ENDIF.
  ENDMETHOD.


  METHOD get_archive_next_object.
* Local variable declaration
    DATA: lv_arch_name     TYPE arkey,
          lv_object_offset TYPE admi_offst.
    CLEAR ev_exit.
    CALL FUNCTION 'ARCHIVE_GET_NEXT_OBJECT'
      EXPORTING
        archive_handle          = iv_archive_handle
      IMPORTING
        object_offset           = lv_object_offset
        archive_name            = lv_arch_name
      EXCEPTIONS
        end_of_file             = 1
        file_io_error           = 2
        internal_error          = 3
        open_error              = 4
        wrong_access_to_archive = 5
        OTHERS                  = 6.
    IF sy-subrc <> 0.
      ev_exit = abap_true.
    ENDIF.
  ENDMETHOD.


  METHOD get_archive_next_record.
    CLEAR: ev_exit,
       eo_record_ref.
    CALL FUNCTION 'ARCHIVE_GET_NEXT_RECORD'
      EXPORTING
        archive_handle          = iv_archive_handle
        get_real_structure_name = abap_true
      IMPORTING
        record_structure        = ev_object_name
        record_ref              = eo_record_ref
      EXCEPTIONS
        end_of_object           = 1
        internal_error          = 2
        wrong_access_to_archive = 3
        OTHERS                  = 4.
    IF sy-subrc <> 0.
      ev_exit = abap_true.
    ENDIF.
  ENDMETHOD.
ENDCLASS.

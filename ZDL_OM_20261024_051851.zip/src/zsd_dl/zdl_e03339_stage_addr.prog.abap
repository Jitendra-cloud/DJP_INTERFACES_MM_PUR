*&---------------------------------------------------------------------*
*&  Include           ZDL_E03339_STAGE_ADDR                            *
*&---------------------------------------------------------------------*
* Copyright: July 2006 by International Paper Company
* Author  : Maureen Carter
* Description: break/fix after R6 August 2006 go-live CO58962
*        E03339 copy address from delivery to stage and
*        make Milemaker call to recalculate distance on the stage
*&---------------------------------------------------------------------*
* called from Include ZXV56U15
*   CMOD ZV56FCOP,  Enhancement V56FCOPY
*   from EXIT_SAPLV56F_010 in SD_SHIPMENT_COPY_DELIVERY_DATA.
*   when shipment 'PLANNED'
*----------------------------------------------------------------------*
* This exit is only processed when the shipment goes from unplanned to
*   planned status, before shipment save.
* All *_X* tables have complete data (not just changed data).
* Called before leg determination, distance/duration calculation and
*   EXIT_SAPLV56U_004 shipment save processing where IDOCs are created
*----------------------------------------------------------------------*
**      !!! Do not re-sort any of these tables!!!
** See SAP function documentation for user exit sort order.
*"----------------------------------------------------------------------
**  IMPORTING
*"       VALUE(I_TVTK) LIKE  TVTK STRUCTURE  TVTK
*"  TABLES
*"        I_XVTTP STRUCTURE  VTTPVB  "shipment items
*"        C_XVTTS STRUCTURE  VTTSVB  "shipment stages
*"        C_YVTTS STRUCTURE  VTTSVB
*"        C_XVTSP STRUCTURE  VTSPVB  "stages/items
*"        C_YVTSP STRUCTURE  VTSPVB
*"        C_XVBPA STRUCTURE  VBPAVB  "shipment partners
*"        C_YVBPA STRUCTURE  VBPAVB
*"        C_XVBADR STRUCTURE  SADRVB "addresses
*"        I_XTRLK STRUCTURE  VTRLK   "deliveries in shipment header
*"        I_XTRLP STRUCTURE  VTRLP   "delivery items
*"  CHANGING
*"     REFERENCE(C_XVTTK) LIKE  VTTKVB STRUCTURE  VTTKVB "shpmnt hdr
*----------------------------------------------------------------------*
* Change History:
* 04/01/08 PSUNKAR CHG86898
* Transport# E0VK937874
* Change the code to allow change/add address kunnr for muliple stages shipment.
*----------------------------------------------------------------------*
 CONSTANTS: c_ship_to type   parvw VALUE 'WE'.
 DATA: l_vtts_start_tabix    LIKE sy-tabix,
       l_tabix               LIKE sy-tabix,
       l_recalc_distance(1) VALUE space.
 DATA: l_xvtts               LIKE vttsvb,
       l_xvtsp               TYPE vtspvb,
       l_xvbpa               TYPE vbpavb,
       l_xvttk               TYPE vttkvb,
       i_dep_address         TYPE addr1_val,
       i_dest_address        TYPE addr1_val,
       e_distance            TYPE distz,
       e_distance_unit       TYPE medst,
       e_distance_determined TYPE selkz,
       l_measurements  LIKE vtmeas OCCURS 0 WITH HEADER LINE.
 DATA: BEGIN OF lt_delivery OCCURS 0,
       vbeln TYPE vbeln,
       END OF lt_delivery.
 DATA: BEGIN OF lt_E03339_adrnr OCCURS 0,
      kunnr TYPE kunnr,
      adrnr TYPE adrnr,
      END OF lt_E03339_adrnr.


 DO 1 TIMES.
   "DO allows use of CHECK statement in a user exit INCLUDE

* get the position of shipment item in the internal table
   READ TABLE i_xvttp INTO l_xvttp
        WITH KEY mandt = sy-mandt
                 tknum = c_xvttk-tknum
                 BINARY SEARCH.
   CHECK sy-subrc = 0.
   l_vtts_start_tabix = sy-tabix.
   CLEAR:  lt_delivery, lt_E03339_adrnr.
   REFRESH:  lt_delivery, lt_E03339_adrnr.

*  look at each shipment stage within the shipment
   LOOP AT c_xvtts INTO l_xvtts FROM l_vtts_start_tabix.
     IF l_xvtts-tknum NE c_xvttk-tknum.
       EXIT.
     ENDIF.
   l_tabix = sy-tabix.


*** look at all deliveries on the stage,
*** double check that all deliveries are to the same ship-to
*** then use the address on the first delivery
*    get link between stage and delivery & create list of deliveries
*------------------------------------------------------------------*
     LOOP AT c_xvtsp
         WHERE tknum = l_xvtts-tknum
            AND tsnum = l_xvtts-tsnum.

        LOOP AT i_xvttp
          WHERE tknum = l_xvtts-tknum
          AND tpnum = c_xvtsp-tpnum.
          lt_delivery-vbeln = i_xvttp-vbeln.
          APPEND lt_delivery.
        ENDLOOP.
      ENDLOOP.

     CHECK NOT lt_delivery[] IS INITIAL.
     SORT lt_delivery.
     DELETE  ADJACENT DUPLICATES FROM lt_delivery.
*    get the ship-to partners for the deliveries
*    only proceed if all deliveries have the same kunnr
     SELECT kunnr adrnr FROM vbpa
            INTO TABLE lt_E03339_adrnr
            FOR ALL ENTRIES IN lt_delivery
            WHERE vbeln = lt_delivery-vbeln
                  AND parvw = c_ship_to.
     SORT lt_E03339_adrnr BY kunnr.
     DELETE ADJACENT DUPLICATES FROM lt_E03339_adrnr
            COMPARING kunnr.
*----Begin of changes by psunkar 04/01/08 CHG# 86898---------------*
*  Transport E0VK937874                                            *
*------------------------------------------------------------------*
*     DESCRIBE TABLE lt_E03339_adrnr LINES count.
*     CHECK count = 1.
*     READ TABLE lt_E03339_adrnr INDEX 1." psunkar

*    is stage address <> delivery address?
*    then replace address on stage with delivery address
*----Begin of changes by psunkar 04/01/08 CHG# 86898---------------*
*   Transport# E0VK937874                                          *
*------------------------------------------------------------------*
     if not l_xvtts-kunna is initial.
       clear lt_E03339_adrnr.
       read table lt_E03339_adrnr with key kunnr = l_xvtts-kunna.
       if sy-subrc = 0.
         if l_xvtts-adrna <> lt_e03339_adrnr-adrnr or
            l_xvtts-adrnad <> lt_E03339_adrnr-adrnr.
            l_xvtts-adrna  = lt_e03339_adrnr-adrnr.
            l_xvtts-adrnad = lt_e03339_adrnr-adrnr.
            l_xvtts-updada = c_update.
            l_recalc_distance = 'X'.
         endif.
       endif.
     endif.
    if not l_xvtts-kunnz is initial.
       clear lt_E03339_adrnr.
       read table lt_E03339_adrnr with key kunnr = l_xvtts-kunnz.
       if sy-subrc = 0.
         if l_xvtts-adrnz <> lt_e03339_adrnr-adrnr or
            l_xvtts-adrnzd <> lt_E03339_adrnr-adrnr.
            l_xvtts-adrnz  = lt_e03339_adrnr-adrnr.
            l_xvtts-adrnzd = lt_e03339_adrnr-adrnr.
            l_xvtts-updadz = c_update.
            l_recalc_distance = 'X'.
         endif.
       endif.
     endif.   " end of changes by psunkar as per chg.req.86898


*     get new city/state name for BEZKOMPRZ on the stage tab
       CALL FUNCTION 'ST_STAGE_DESCRIPTIONS'
         EXPORTING
           i_xvtts       = l_xvtts
         CHANGING
           c_locz_txtall = l_xvtts-bezkomprz.
       IF l_xvtts-updkz IS INITIAL.
         l_xvtts-updkz = c_update.
       ENDIF.
       MODIFY c_xvtts FROM l_xvtts INDEX l_tabix.
       CLEAR:  lt_delivery.
       REFRESH:  lt_delivery.

    ENDLOOP.


*  if the ship-to address was changed on any stage - recalc distances
   CHECK NOT l_recalc_distance IS INITIAL.
   l_xvttk = c_xvttk.

*   begin of copy from /SAPDDS/APO_DETERMINE_DISTANCE

   LOOP AT c_xvtts INTO l_xvtts
        WHERE tknum = l_xvttk-tknum.
     l_tabix = sy-tabix.

**   Transfer addressing data from stage to expected structures
*    origin address
     CALL FUNCTION 'ST_LOCATION_ADDR_GET'
       EXPORTING
         i_adrnr           = l_xvtts-adrnad
       IMPORTING
         e_addr            = i_dep_address
       EXCEPTIONS
         address_not_found = 1
         OTHERS            = 2.

     IF sy-subrc NE 0.
       CONTINUE.
     ENDIF.

*    destination address
     CALL FUNCTION 'ST_LOCATION_ADDR_GET'
       EXPORTING
         i_adrnr           = l_xvtts-adrnz
       IMPORTING
         e_addr            = i_dest_address
       EXCEPTIONS
         address_not_found = 1
         OTHERS            = 2.

     IF sy-subrc NE 0.
       CONTINUE.
     ENDIF.

*    get distance for stage
     CALL METHOD
       /sapdds/cl_dds_appl_gateway=>determine_ship_stage_distance
       EXPORTING
         i_shipment                = l_xvttk
         i_shipment_stage          = l_xvtts
         i_departure_point_address = i_dep_address
         i_destination_address     = i_dest_address
       IMPORTING
         e_distance                = e_distance
         e_distance_unit           = e_distance_unit
         e_distance_determined     = e_distance_determined.

     IF e_distance_determined IS NOT INITIAL.
       l_xvtts-distz = e_distance.
       l_xvtts-medst = e_distance_unit.
       MODIFY c_xvtts FROM l_xvtts INDEX l_tabix.

     ENDIF.

   ENDLOOP.

*** Need to calculate total distz on header!!!
   CLEAR: l_xvttk-distz.
   l_xvttk-medst = l_xvtts-medst.
   CALL FUNCTION 'SD_SHIPMENT_MEASUREMENT_DETERM'
        EXPORTING
            i_xvttk_wa                 = l_xvttk
        TABLES
             c_measurements            = l_measurements
             i_xvtts                   = c_xvtts
        EXCEPTIONS:
             OTHERS                    = 1.
   IF sy-subrc EQ 0.
     MOVE-CORRESPONDING l_measurements TO l_xvttk.
     c_xvttk = l_xvttk.
   ENDIF.
* end of copy from /SAPDDS/APO_DETERMINE_DISTANCE

 ENDDO.

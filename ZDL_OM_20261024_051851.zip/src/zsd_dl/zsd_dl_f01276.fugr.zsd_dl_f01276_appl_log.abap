FUNCTION ZSD_DL_F01276_APPL_LOG.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(IN_NAST) TYPE  NAST
*"     VALUE(IN_DCPFM) LIKE  USR01-DCPFM
*"----------------------------------------------------------------------

 Data: Ls_apploghead    Type bal_s_log,
       Ls_messages      Type bal_s_msg,
       Lt_messages      Type zca_bal_msg_tab,
       Lv_applog_extid  Type zdm_applog_extid,

       Lv_msg_no        Type SYMSGNO,
       Lv_oncom         Type Syoncom.

 Clear: Lv_applog_extid, Lv_msg_no.
 Concatenate Gc_inv_code Sy-Datum
        into Lv_applog_extid.

 Clear:   Ls_apploghead.
 Refresh: Lt_messages.

* Build Application logging header:
 Ls_apploghead-alprog    = sy-repid.
 Ls_apploghead-aluser    = sy-uname.
 Ls_apploghead-object    = Gc_app_log_object.
 Ls_apploghead-subobject = Gc_app_log_subobj.
 Ls_apploghead-extnumber = Lv_applog_extid.

 Add 1 to Lv_msg_no.
 Ls_messages-msgty       = Gc_msg_typ.
 Ls_messages-msgid       = Gc_msg_id.
 Ls_messages-msgno       = Lv_msg_no.

 Case: in_dcpfm.
*X=1,234,567.89
   When 'X'.
     Concatenate 'Default Decimal Notation ==>'(A03)
*'Default Decimal Notation ==>'
                 in_dcpfm ' 1,234,567.89<=='(A04)
     into Ls_messages-msgv1.
*Y=1 234 567,89
   When 'Y'.
     Concatenate 'Default Decimal Notation ==>'(A03)
                 in_dcpfm ' 1 234 567,89<=='(A05)
     into Ls_messages-msgv1.
* =1.234.567,89
   When Others.
     Concatenate 'Default Decimal Notation ==>'(A03)
                 in_dcpfm ' 1.234.567,89<=='(A06)
     into Ls_messages-msgv1.
 Endcase.
* Append Ls_messages to Lt_messages.
* Add 1 to Lv_msg_no.
* Ls_messages-msgno       = Lv_msg_no.
 Concatenate 'KAPPL =' In_Nast-kappl ',' 'OBJKY =' In_Nast-objky ','
             'KSCHL =' In_Nast-kschl ','
     into Ls_messages-msgv2.

 Concatenate 'NACHA =' In_Nast-nacha ','
             'VSTAT =' In_Nast-vstat
     into Ls_messages-msgv3.

 Append Ls_messages to Lt_messages.

* Open, Write to and close the Application log
 Call function 'Z_GEN_APP_LOG_MULT'
   Exporting
     Is_log_header = Ls_apploghead
   Tables
     It_messages   = Lt_messages.

 Lv_oncom = sy-oncom.
 sy-oncom = 'T'.
 Commit Work and wait.
 sy-oncom = Lv_oncom.


ENDFUNCTION.

FUNCTION zsd_dl_i02554_shipstatus_relev.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(IV_TKNUM) TYPE  TKNUM OPTIONAL
*"     REFERENCE(IV_ITNUM) TYPE  ZDL_ITNUM_D OPTIONAL
*"  EXPORTING
*"     VALUE(ES_ERROR) LIKE  BAPIRET2 STRUCTURE  BAPIRET2
*"  TABLES
*"      IT_VTTK STRUCTURE  VTTK OPTIONAL
*"      IT_VTTS STRUCTURE  VTTS OPTIONAL
*"      IT_VTTP STRUCTURE  VTTP OPTIONAL
*"      IT_VTSP STRUCTURE  VTSP OPTIONAL
*"      ET_RESULT TYPE  ZDL_I02554_REV_RESULT_T OPTIONAL
*"----------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT © 2007 by                             **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT ©                            **
**                          2008, 200n                                **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
* Program Name: FM for getting relevancy codes   Create Date: 06/17/08 *
* SAP Name    : ZSD_DL_I02554_SHIPSTATUS_RELEV   Version    : V4W3     *
* Programmer  : Raghava Myneedu                  Last Update:          *
* Inventory Code : I02554                                              *
************************************************************************
* Description : The purpose of this function module is to fetch required
*               information for a given shipment number & Itinerary    *
*               number and returns a list of stops, events and         *
*               recipients which are relevant for the outbound 214.    *
************************************************************************
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* Raghava Myneedu    06/17/08  EDVK963368  Initial Version             *
* Chandra Cherupally 10/2/08   E0VK944075  CHG93728 - Changed the      *
*        FM interface to add VTTK,VTTS,VTTP,VTSP structures to support *
*        the EM functionality during shipment creation - search CC01   *
*                                                                      *
************************************************************************

  DATA lv_structures.

*--> Refresh global internal tables
  CLEAR   : gs_vttk, lv_structures.
  REFRESH : gt_itinerary.

* >> Begin of Change - CC01
  IF it_vttk[] IS NOT INITIAL AND it_vtts[] IS NOT INITIAL AND
     it_vttp[] IS NOT INITIAL AND it_vtsp[] IS NOT INITIAL.
    lv_structures = 'X'.
  ELSE.
    CLEAR lv_structures.
  ENDIF.
* << End of Change - CC01

  IF lv_structures IS INITIAL.
    PERFORM validate_relev_input_data USING iv_tknum
                                            iv_itnum
                                   CHANGING es_error.
    IF es_error IS NOT INITIAL.
      RETURN.
    ENDIF.

*--> Get shipment itinerary view for the input shipment #
    PERFORM read_shipment_itinerary USING iv_itnum
                                 CHANGING es_error.
    IF es_error IS NOT INITIAL.
      RETURN.
    ENDIF.
  ELSE.
* >> Begin of Change - CC01
*--> Get shipment itinerary view for the structures data
    PERFORM read_shipment_itinerary_struct TABLES it_vttk
                                                  it_vtts
                                                  it_vttp
                                                  it_vtsp
                                         CHANGING es_error.
    IF es_error IS NOT INITIAL.
      RETURN.
    ENDIF.
* << End of Change - CC01
  ENDIF.

  PERFORM determine_relevancy_codes TABLES et_result.

ENDFUNCTION.

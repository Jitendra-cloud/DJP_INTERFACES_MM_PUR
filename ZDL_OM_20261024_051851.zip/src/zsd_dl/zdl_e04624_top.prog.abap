*&---------------------------------------------------------------------*
*&  Include           ZDL_E04624_TOP                                   *
*&---------------------------------------------------------------------*

*-- Screen Variables
DATA : gs_9000_docnum TYPE edi_docnum, "IDoc Number
       gs_9000_vbeln  TYPE vbeln,      "SD Document Number
       gs_9000_posnr  TYPE posnr,      "Item number
       gs_9000_matnr  TYPE matnr,      "Material number
       gs_9000_exidv  type exidv,      "External Handling Unit
       gs_9000_vemng  TYPE vemng,      "HU Base Quantity
       gs_9000_traid  TYPE traid,      "Means of Transport ID
       gs_9000_bolnr  TYPE bolnr,      "Bill of lading
       gs_9000_vbeln2 TYPE vbeln,      "IPCO number
       gs_9000_atwrt  TYPE atwrt,      "Width
       gs_9000_werks  TYPE werks_d,    "Plant Code
       gs_9000_tdobject TYPE tdobname, "Inbound PO #1
       gs_err_text TYPE string.        "Error message area

*-- Variables
DATA : gv_idoc_process_err TYPE c,
       gv_no_reprocess     type c,
       gv_idoc_num  TYPE  edi_docnum.

*-- WorkArea
DATA : gs_edidc    TYPE edidc.  "IDOC Control record

*-- Idoc segment structures
DATA: gs_e1edl20 TYPE e1edl20,  "Delivery header
      gs_e1edl15 TYPE e1edl15,  "Batch Characteristic
      gs_e1edl24 TYPE e1edl24,  "Batch Characteristic
      gs_e1edl44 TYPE e1edl44,  "Handling unit item
      gs_e1txth8 TYPE e1txth8.  "General Text Header

*-- Internal Tables
DATA : gt_edidd TYPE  edidd_tt,
       gt_itab_excl  TYPE STANDARD TABLE OF sy-ucomm,
       gt_zdl_fields TYPE STANDARD TABLE OF zdl_fields,
       gs_zdl_fields TYPE zdl_fields.

*-- Constants
CONSTANTS :   gc_e1txth8 TYPE edidd-segnam VALUE  'E1TXTH8',
              gc_e1edl20 TYPE edidd-segnam VALUE 'E1EDL20',
              gc_e1edl24 TYPE edidd-segnam VALUE 'E1EDL24',
              gc_e1edl15 TYPE edidd-segnam VALUE 'E1EDL15',
              gc_e1edl44 TYPE edidd-segnam VALUE 'E1EDL44',
              gc_status_51 TYPE edi_status VALUE '51',
              gc_status_68 TYPE edi_status VALUE '68',
              gc_char_e TYPE c VALUE 'E',  "Error
              gc_char_a TYPE c VALUE 'A',  "Abort
              gc_char_w type c value 'W',  "Warning
              gc_true   TYPE c VALUE 'X'.

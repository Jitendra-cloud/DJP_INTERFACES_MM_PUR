*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_SHIP_COMPL..................................*
DATA:  BEGIN OF STATUS_ZDL_SHIP_COMPL                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_SHIP_COMPL                .
CONTROLS: TCTRL_ZDL_SHIP_COMPL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_SHIP_COMPL                .
TABLES: ZDL_SHIP_COMPL                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

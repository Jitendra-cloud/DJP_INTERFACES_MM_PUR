FUNCTION z_idoc_output_proact.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(OBJECT) LIKE  NAST STRUCTURE  NAST
*"     VALUE(CONTROL_RECORD_IN) LIKE  EDIDC STRUCTURE  EDIDC
*"  EXPORTING
*"     VALUE(OBJECT_TYPE) LIKE  WFAS1-ASGTP
*"     VALUE(CONTROL_RECORD_OUT) LIKE  EDIDC STRUCTURE  EDIDC
*"  TABLES
*"      INT_EDIDD STRUCTURE  EDIDD
*"  EXCEPTIONS
*"      ERROR_MESSAGE_RECEIVED
*"----------------------------------------------------------------------
* Change History:                                                     *
*     Programmer        Date    Req. #            Action              *
*---------------------------------------------------------------------*
* Chandra Cherupally  07/28/08 EDVK961755  Modified code to add Z1EDP02
*                                          segments after E1EDP31 segmt
*                                          to add multiple SO/Items
*                                          Search for CC01
*                                                                     *
* Charles Ramey       03/17/11 CR10540     Made extensive changes to
*                     FM to be able to generate IDocs for Break Bulk  *
*                     transfers.  Since this info is available for    *
*                     container - it was decided by the business to   *
*                     change to that method for containers as well.   *
*                     The Changes are too numerous to call out each   *
*                     line of code - (rewriting over 1/2 the FM)      *
*                                                                     *
* Steve Pieri         10/25/2011 CR 129037 modified LZDL_PROACTF01    *
*                     In the form delete_roll_xfer change the read    *
*                     prameter for table zdl_roll_xfer from           *
*                     AND erzet = gv_objky-erzet to                   *
*                             AND erzet <= gv_objky-erzet             *
* Steve Pieri         CR# 11871 08/30/2012                            *
*                     Get the vendor batch number for segment E1EDP19 *
*                     from table MCH1 if sales order category and     *
*                     division match entries in ZSDOMFLD
*
***********************************************************************


* refresh the data
  PERFORM refresh_data.

* check for objectkey not being returned empty
  gs_object = object.
  IF gs_object-objky = space.
    MESSAGE ID 'ZSD_DL' TYPE 'E' NUMBER '000'
                WITH 'NO objky returned from nast'(005)
            RAISING error_message_received.
  ENDIF.

* check from which program the idoc has been executed
  IF gs_object-repid = 'E0299'.
    gv_matdoc = gs_object-objky.
    PERFORM get_data_matdoc.
* May or may NOT have Internal HU - but it is Roll transfer-
* use ZDL_ROLL_XFER  (if container - HU is now in PFLD1)
  ELSE.
    gv_venum = gs_object-pfld1.
    gv_objky = gs_object-objky.
    PERFORM get_data_xfer.
  ENDIF.

* control records
  PERFORM build_control USING   object
                                control_record_in
                                control_record_out.
*fill in the idoc
  PERFORM fill_idoc.

* Pass the data to idoc table
  IF NOT gt_edidd[] IS INITIAL.
    int_edidd[] = gt_edidd[].
    perform delete_roll_xfer.
  ENDIF.

ENDFUNCTION.

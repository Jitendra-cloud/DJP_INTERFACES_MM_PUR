FUNCTION-POOL zdl_proact.                   "MESSAGE-ID ..

**********************
* Tales
*********************

TABLES : nast.

********************
* Internal tables
********************

* internal table to hold  vepo records
DATA : BEGIN OF gt_vepo OCCURS 0,
         venum  TYPE  venum     ,
         matnr  TYPE  matnr     ,
         charg  TYPE  charg_d   ,
         werks  TYPE  werks_d   ,
         lgort  TYPE  lgort_d   ,
       END OF gt_vepo.

* internal table to hold mska records
DATA : BEGIN OF gt_mska OCCURS 0,
        vbeln TYPE vbeln,
        posnr TYPE posnr,
        matnr  TYPE  matnr     ,
        charg  TYPE  charg_d   ,
        werks  TYPE  werks_d   ,
        lgort  TYPE  lgort_d   ,
        kalab  TYPE  labst,
        ersda   TYPE ersda,
       END OF gt_mska.

*internal table to hold mseg records

DATA : BEGIN OF gt_mseg OCCURS 0 ,
         mblnr TYPE mblnr       ,
         mjahr TYPE mjahr       ,
         zeile TYPE mblpo       ,
         matnr TYPE matnr       ,
         werks TYPE werks_d     ,
         lgort TYPE lgort_d     ,
         charg TYPE charg_d     ,
         menge TYPE menge_d     ,
         umwrk TYPE umwrk       ,
         umlgo TYPE umlgo       ,
         mat_kdauf TYPE mat_kdauf,
         mat_kdpos TYPE mat_kdpos,
         kdauf TYPE kdauf        ,
         kdpos TYPE kdpos        ,
       END OF gt_mseg.

DATA : gt_mseg_initial LIKE gt_mseg OCCURS 0 WITH HEADER LINE.

* internal table to hold mpkf records

DATA : BEGIN OF gt_mkpf OCCURS 0 ,
         mblnr TYPE mblnr,
         mjahr TYPE mjahr,
         bldat TYPE bldat,
         cputm TYPE cputm,
       END OF gt_mkpf.

DATA : gv_venum TYPE venum,
       gv_posex TYPE i ,
       gv_matdoc TYPE mblnr,
       GV_OBJKY  type ZDL_XFER_NAST_OBJKY_STR.

data:  gt_zdl_roll_xfer type standard table of zdl_roll_xfer,
       gs_zdl_roll_xfer type zdl_roll_xfer,
       gs_object        type nast.


*********************************
* segment details
*********************************
DATA : c_segnam_e1edk34   LIKE edidd-segnam VALUE 'E1EDK34',
       c_segnam_e1edk02   LIKE edidd-segnam VALUE 'E1EDK02',
       c_segnam_e1adrm1   LIKE edidd-segnam VALUE 'E1ADRM1',
       c_segnam_e1edp31   LIKE edidd-segnam VALUE 'E1EDP31',
       c_segnam_z1edp02   LIKE edidd-segnam VALUE 'Z1EDP02'," CC01
       c_segnam_e1edp19   LIKE edidd-segnam VALUE 'E1EDP19',
       c_segnam_e1edp32   LIKE edidd-segnam VALUE 'E1EDP32',
       c_segnam_e1eds02   LIKE edidd-segnam VALUE 'E1EDS02'.

DATA : gt_edidd TYPE TABLE OF edidd.
TABLES : e1edk34,
         e1edk02,
         e1adrm1,
         e1edp31,
         e1edp32,
         e1edp19,
         e1eds02.

*&---------------------------------------------------------------------*
*&  Include           ZDL_E04624_I01                                   *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9000 INPUT.

  DATA: ok_code           LIKE sy-ucomm,
        lv_ipco_flg      TYPE char01.
  CONSTANTS: lc_post      TYPE sy-ucomm VALUE 'POST',
             lc_archive   TYPE sy-ucomm VALUE 'ARCHIVE',
             lc_reprocess TYPE sy-ucomm VALUE 'REPROCESS',
             lc_ccel      TYPE sy-ucomm VALUE 'CCEL'.


  MOVE sy-ucomm TO ok_code.

  CASE ok_code.
    WHEN lc_post .  " 'POST'
      CLEAR lv_ipco_flg.
      PERFORM validate_ipco CHANGING lv_ipco_flg.
      IF lv_ipco_flg EQ 'X'.
        PERFORM try_to_post.
      ELSE.
        MOVE  'IPCO is not in the valid TRADES range'(014)
        TO gs_err_text.
      ENDIF.
    WHEN lc_ccel.   " 'Cancel'.
      LEAVE PROGRAM.
    WHEN lc_archive. " ARCHIVE
      PERFORM do_the_archive.
    WHEN lc_reprocess. " REPROCESS
      DATA lv_vemng TYPE vemng.
      MOVE gs_e1edl44-vemng TO lv_vemng.
* The user may have changed some SAP data (e.g. added a Storage
* location on the PO Item) and they just want to reprocess the idoc
      IF gs_9000_vemng  EQ lv_vemng         AND
         gs_9000_werks  EQ gs_e1edl44-werks AND
         gs_9000_traid  EQ gs_e1edl20-traid AND
         gs_9000_bolnr  EQ gs_e1edl20-bolnr AND
         gs_9000_vbeln2 EQ gs_e1edl20-vbeln AND
         gs_9000_atwrt  EQ gs_e1edl15-atwrt.
        SUBMIT rbdmani2 WITH so_docnu = gv_idoc_num AND RETURN.
        LEAVE PROGRAM.
      ELSE.
        MOVE  'Data has been modified; use EDIT function'(010)
        TO gs_err_text.
      ENDIF.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_9000  INPUT

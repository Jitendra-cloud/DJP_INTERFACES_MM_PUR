*&---------------------------------------------------------------------*
*&  Include           ZDL_E3637_3RD_PARTY_DISC_F01                     *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  validation
*&---------------------------------------------------------------------*
* Selection-screen variable validations:
*         Validate Shipping point against table TVST;
*         Open outbound deliveries against SHP_IDX_GDSI
*         Sales orders against LIPS table
*----------------------------------------------------------------------*
FORM validation.

  PERFORM ship_point_val.
  PERFORM out_dlvry_val.
  PERFORM so_val.

ENDFORM.                    " validation
*&---------------------------------------------------------------------*
*&      Form  ship_point_val
*&---------------------------------------------------------------------*
*  Validate shipping/receiving point against TVST table.
*----------------------------------------------------------------------*
FORM ship_point_val .

  SELECT SINGLE vstel
    INTO sp_plant
    FROM tvst
    WHERE vstel = sp_plant.

  IF sy-subrc <> 0.
* Invalid shippping/receiving point.
    MESSAGE e200.
  ENDIF.

ENDFORM.                    " ship_point_val
*&---------------------------------------------------------------------*
*&      Form  out_dlvry_val
*&---------------------------------------------------------------------*
* Validate the given outbound delivery number against the table
* SHP_IDX_GDSI - Outbound Deliveries: Not Posted for Goods Issue;
* if none is specifically mentioned, then pull over all
* open outbound deliveries from the table and take all these outbound
* deliveries into a table GT_REP for further processing
*----------------------------------------------------------------------*
FORM out_dlvry_val.

  SELECT vbeln            "Outbound delivery
    INTO CORRESPONDING FIELDS OF TABLE gt_rep
    FROM shp_idx_gdsi
    WHERE vstel =  sp_plant
      AND vbeln IN so_vbeln.

  IF sy-subrc <> 0.
* No open outbound deliveries found for the given criteria
    MESSAGE i203.
    STOP.
  ENDIF.

ENDFORM.                    " out_dlvry_val
*&---------------------------------------------------------------------*
*&      Form  so_val
*&---------------------------------------------------------------------*
* Validate the given sales order against the table LIPS for all
* open outbound deliveries.  Also fetch all these sales orders into the
* common table GT_REP with batch #, material and quantity
*----------------------------------------------------------------------*
FORM so_val.

  IF NOT gt_rep[] IS INITIAL.

* 33303 - lines below removed
*    SELECT vgbel        "Sales order
*           vbeln        "Outbound delivery
*           posnr        "Outbound delivery line item
*           matnr        "Material Number
*           lichn        "Vendor Batch #
*           charg        "SAP Batch #
*           lfimg        "Delivery Quantity
*           vrkme        "Sales Unit
*           erdat        "GR Date
*        INTO CORRESPONDING FIELDS OF TABLE gt_rep
*        FROM lips
*        FOR ALL ENTRIES IN gt_rep
*        WHERE vbeln = gt_rep-vbeln
*          AND lfimg > 0.

    SELECT lips~vgbel        "Sales order
           lips~vbeln        "Outbound delivery
           lips~posnr        "Outbound delivery line item
           lips~matnr        "Material Number
           lips~lichn        "Vendor Batch #
           lips~charg        "SAP Batch #
           lips~lfimg        "Delivery Quantity
           lips~vrkme        "Sales Unit
           lips~erdat        "GR Date
           likp~vkorg
        INTO CORRESPONDING FIELDS OF TABLE gt_rep
        FROM lips
        join likp on likp~vbeln = lips~vbeln
        FOR ALL ENTRIES IN gt_rep
        WHERE lips~vbeln = gt_rep-vbeln
          AND lips~lfimg > 0
          and likp~vkorg in so_vkorg.


    IF sy-subrc <> 0.
* No valid sales order for the given shipping point and outbound
* deliveries
      MESSAGE i204.
      STOP.
    ENDIF.
  ENDIF.

ENDFORM.                    " so_val
*&---------------------------------------------------------------------*
*&      Form  process
*&---------------------------------------------------------------------*
* Get inbound deliveries and purchase order informations
*----------------------------------------------------------------------*
FORM process.

  DATA:
    lt_rep LIKE TABLE OF gs_rep,
    ls_rep LIKE gs_rep.

* Inorder to get only sales order information, keep track only one
* record of sales order
  lt_rep[] = gt_rep[].

* Sort by sales order and delete duplicates so that we will get unique
* record by sales order
  SORT lt_rep BY vgbel.    "Sales order
  DELETE ADJACENT DUPLICATES
        FROM lt_rep
        COMPARING vgbel.

  IF NOT lt_rep[] IS INITIAL.
* Fetch purchase order information from table VBFA (Sales doc. flow)
* table. Take VBELN (which is purchase order) when document category
* VBFA-VBTYP_N = 'V' where VBELV (Preceding SD doc 3) = Sales order
* VGBEL #.

* 33303 - lines below removed
*    SELECT vbelv vbeln  "Sales order, Purchase order
*        INTO TABLE gt_so_p
*        FROM vbfa
*        FOR ALL ENTRIES IN lt_rep
*        WHERE vbelv   = lt_rep-vgbel
*          AND vbtyp_n = 'V'.        "Doc.catgory = 'Purchase order'

* 33303-start
    SELECT vbfa~vbelv
           vbfa~vbeln
           ekko~ekorg
        INTO TABLE gt_so_p
        FROM vbfa
        join ekko on ekko~ebeln = vbfa~vbeln
        FOR ALL ENTRIES IN lt_rep
        WHERE vbfa~vbelv   = lt_rep-vgbel
          AND vbfa~vbtyp_n = 'V'.        "Doc.catgory = 'Purchase order'
* 33303-end


* For all these purchase orders, take corresponding inbound deliveries
* again from the lips table.
    IF NOT gt_so_p[] IS INITIAL.
      SELECT vgbel    "Purchase order
             vbeln    "Inbound delivery
             matnr    "Material
             charg    "SAP Batch
        INTO TABLE gt_inb_dlvry
        FROM lips
        FOR ALL ENTRIES IN gt_so_p
        WHERE vgbel = gt_so_p-vbeln
          AND lfimg > 0.
    ENDIF.
  ENDIF.

ENDFORM.                    " process
*&---------------------------------------------------------------------*
*&      Form  output
*&---------------------------------------------------------------------*
* Display the output
*----------------------------------------------------------------------*
FORM output.

  PERFORM prepare_output.
  PERFORM build_fieldcatalog.
  PERFORM build_layout.
  PERFORM sort_table.
  PERFORM display.

ENDFORM.                    " output
*&---------------------------------------------------------------------*
*&      Form  prepare_output
*&---------------------------------------------------------------------*
* Pull over all related information (Purchase order & Inbound delivery)
* into a table so that it can be displayed using ALV
*----------------------------------------------------------------------*
FORM prepare_output.

  FIELD-SYMBOLS:
    <ls_rep> LIKE gs_rep.

  SORT gt_so_p      BY vbelv.  "Sales order
  SORT gt_inb_dlvry BY vgbel   "Purchase order
                       matnr   "Material
                       charg.  "Batch.

  LOOP AT gt_rep ASSIGNING <ls_rep>.
    CLEAR: gs_inb_dlvry, gs_so_p.

* For the given sales order, get corresponding purchase order
* from gt_so_p where VBELV - Sales order, VBELN - Pur. Order
    READ TABLE gt_so_p INTO gs_so_p
        WITH KEY vbelv = <ls_rep>-vgbel  "Sales order
        BINARY SEARCH.

* If PO found, check it has valid (qty>0) inbound delivery
    IF sy-subrc = 0.
      <ls_rep>-ebeln = gs_so_p-vbeln.    "Purchase order
      <ls_rep>-ekorg = gs_so_p-ekorg.                           "33303

      READ TABLE gt_inb_dlvry INTO gs_inb_dlvry
            WITH KEY vgbel = gs_so_p-vbeln    "Purchase order
                     matnr = <ls_rep>-matnr
                     charg = <ls_rep>-charg
            BINARY SEARCH.

      IF sy-subrc = 0.
        <ls_rep>-vbelv      = gs_inb_dlvry-vbeln.  "Inb. delivery.
      ELSE.
        <ls_rep>-line_color = 'C710'.
      ENDIF.  "Inb. Delivery
    ELSE.
      <ls_rep>-line_color = 'C710'.
    ENDIF.    "PO

  ENDLOOP.

* 33303-start
  if so_ekorg[] is not initial.
    delete gt_rep where ekorg not in so_ekorg.
  endif.
* 33303-end

ENDFORM.                    " prepare_output
*&---------------------------------------------------------------------*
*&      Form  build_fieldcatalog
*&---------------------------------------------------------------------*
*  Build field catalog for output:
*    Fields to be displayed:  Sales order, Purchase Order, Inb. Dlvry,
*    out. dlvry, Out.dlvry item, Material #, Vendor Batch #, SAP Batch #
*    Qty, GR date
*----------------------------------------------------------------------*
FORM build_fieldcatalog.

  FIELD-SYMBOLS:
      <ls_cat>  TYPE slis_fieldcat_alv.

  PERFORM update_fieldcat_table
*                  col_pos           fieldname      key     key_sel
*                  ref_tabname       text_fieldname do_sum  no_out
*                  reptext_ddic      outputlen      input   sp_group
*                  datatype
          USING: 1                   'VGBEL'        'X'      'X'
                 'GT_REP'            space          'X'      space
                 'Sales Order'       space           space   space
                  space                                        ,
                  2                  'EBELN'        'X'      'X'
                 'GT_REP'            space          'X'      space
                 'Pur.Order  '       space           space   space
                  space                                        ,
                  3                  'VBELV'        'X'      'X'
                 'GT_REP'            space          'X'      space
                 'Inb.Dlvry'         space           space   space
                  space                                        ,
                  4                  'VBELN'        'X'      'X'
                 'GT_REP'            space          'X'      space
                 'Out.Dlvry'         space           space   space
                  space                                        ,
                  5                  'POSNR'        'X'      'X'
                 'GT_REP'            space          'X'      space
                 'Out.Dlvry Item'    space           space   space
                  space                                        ,
                  6                  'MATNR'         space   space
                 'GT_REP'            space           space   space
                 'Material'          space           space   space
                  space                                        ,
                  7                  'LICHN'        space    space
                 'GT_REP'            space          space    space
                 'Vendor Batch'      space          space    space
                  space                                        ,
                  8                  'CHARG'        space    space
                 'GT_REP'            space          space    space
                 'SAP Batch'         space          space    space
                  space                                        ,
                  9                  'LFIMG'        space    space
                 'GT_REP'            space          space    space
                 'Quantity'          space          space    space
                  space                                        ,
                  10                 'VRKME'        space    space
                 'GT_REP'            space          space    space
                 'Sales UOM'         space          space    space
                  space                                        ,
                  11                 'ERDAT'        space    space
                 'LIPS'              space          space    space
                 'GR Date'           space          space    space
                  space                                        ,
* 33303-start
                  12                 'EKORG'        space    space
                 'EKKO'              space          space    'X'
                 'Purchasing Organization'   space  space    space
                  space                                        ,
                  13                 'VKORG'        space    space
                 'VBAK'              space          space    'X'
                 'Sales Organization'  space        space    space
                  space                                        .
* 33303-end
ENDFORM.                    " build_fieldcatalog
*&---------------------------------------------------------------------*
*&      Form  update_fieldcat_table
*&---------------------------------------------------------------------*
* Update field catalog table GT_FIELDCATALOG
*----------------------------------------------------------------------*
*      see list below
*----------------------------------------------------------------------*
FORM update_fieldcat_table  USING
               uv_col_pos
               uv_cfieldname
               uv_key
               uv_key_sel
               uv_ref_tabname
               uv_text_fieldname
               uv_do_sum
               uv_no_out
               uv_reptext_ddic
               uv_outputlen
               uv_input
               uv_sp_group
               uv_datatype.

  DATA:
    ls_fieldcat TYPE slis_fieldcat_alv.

  CLEAR ls_fieldcat.
  ls_fieldcat-col_pos        = uv_col_pos.
  ls_fieldcat-fieldname      = uv_cfieldname.
  ls_fieldcat-key            = uv_key.
  ls_fieldcat-key_sel        = uv_key_sel.
  ls_fieldcat-ref_tabname    = uv_ref_tabname.
  ls_fieldcat-text_fieldname = uv_text_fieldname.
  ls_fieldcat-do_sum         = uv_do_sum.
  ls_fieldcat-no_out         = uv_no_out.
  ls_fieldcat-reptext_ddic   = uv_reptext_ddic.
  ls_fieldcat-outputlen      = uv_outputlen.
  ls_fieldcat-input          = uv_input.
  ls_fieldcat-sp_group       = uv_sp_group.
  ls_fieldcat-datatype       = uv_datatype.

  APPEND ls_fieldcat TO gt_fieldcat.

ENDFORM.                    " update_fieldcat_table
*&---------------------------------------------------------------------*
*&      Form  sort_table
*&---------------------------------------------------------------------*
*  Sort the output by Sales order, Purchase order, Inbound delivery
*  outbound delivery and its line item
*----------------------------------------------------------------------*
FORM sort_table .

  PERFORM update_sort_table
        USING:
*                 fieldname  fieldorder order subtot   grp
                 'VGBEL'     '1'      'X'   'X'   space,
                 'EBELN'     '2'      'X'   space space,
                 'VBELV'     '3'      'X'   space space,
                 'VBELN'     '4'      'X'   space space.
*                 'POSNR'     '5'      'X'   space space.

ENDFORM.                    " sort_table
*&---------------------------------------------------------------------*
*&      Form  update_sort_table
*&---------------------------------------------------------------------*
*  Update table GT_SORT with the sort order
*----------------------------------------------------------------------*
*      see list below
*----------------------------------------------------------------------*
FORM update_sort_table  USING    uv_comp
                                 uv_spos
                                 uv_up
                                 uv_subtot
                                 uv_group.

  DATA:
    ls_sort TYPE slis_sortinfo_alv.

  CLEAR ls_sort.
  ls_sort-fieldname = uv_comp.
  ls_sort-spos      = uv_spos.
  ls_sort-up        = uv_up.
  ls_sort-subtot    = uv_subtot.
  ls_sort-group     = uv_group.

  APPEND ls_sort TO gt_sort.

ENDFORM.                    " update_sort_table
*&---------------------------------------------------------------------*
*&      Form  display
*&---------------------------------------------------------------------*
* Call 'REUSE_ALV_GRID_DISPLAY' to display the collected information
*----------------------------------------------------------------------*
FORM display.

  IF gt_rep[] IS INITIAL.
    WRITE: / 'No data to display'(i01).
  ELSE.
    CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
      EXPORTING
        is_layout     = gs_layout
        it_fieldcat   = gt_fieldcat[]
        it_sort       = gt_sort[]
      TABLES
        t_outtab      = gt_rep[]
      EXCEPTIONS
        program_error = 1
        OTHERS        = 2.
  ENDIF.

ENDFORM.                    " display
*&---------------------------------------------------------------------*
*&      Form  build_layout
*&---------------------------------------------------------------------*
*  Build layout for ALV grid report
*----------------------------------------------------------------------*
FORM build_layout .

  gs_layout-info_fieldname = 'LINE_COLOR'.

ENDFORM.                    " build_layout

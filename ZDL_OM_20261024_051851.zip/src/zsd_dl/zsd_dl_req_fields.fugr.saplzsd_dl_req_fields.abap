*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE lzsd_dl_req_fieldstop.             " Global Data
  INCLUDE lzsd_dl_req_fieldsuxx.             " Function Modules
  INCLUDE zca_applog_log_standard.

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE lzsd_dl_req_fieldsf01.             " Subprograms
* INCLUDE LZSD_DL_REQ_FIELDSO...             " PBO-Modules
* INCLUDE LZSD_DL_REQ_FIELDSI...             " PAI-Modules

INCLUDE LZSD_DL_REQ_FIELDSF01.

function zdl_rail_route.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_REQUNR) TYPE  SRSC_S_IF_SIMPLE-REQUNR
*"     VALUE(I_DSOURCE) TYPE  SRSC_S_IF_SIMPLE-DSOURCE OPTIONAL
*"     VALUE(I_MAXSIZE) TYPE  SRSC_S_IF_SIMPLE-MAXSIZE OPTIONAL
*"     VALUE(I_INITFLAG) TYPE  SRSC_S_IF_SIMPLE-INITFLAG OPTIONAL
*"     VALUE(I_READ_ONLY) TYPE  SRSC_S_IF_SIMPLE-READONLY OPTIONAL
*"  TABLES
*"      I_T_SELECT TYPE  SRSC_S_IF_SIMPLE-T_SELECT OPTIONAL
*"      I_T_FIELDS TYPE  SRSC_S_IF_SIMPLE-T_FIELDS OPTIONAL
*"      E_T_DATA STRUCTURE  ZDLE11462_LT_RAIL_ROUTE OPTIONAL
*"  EXCEPTIONS
*"      NO_MORE_DATA
*"      ERROR_PASSED_TO_MESS_HANDLER
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2019 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
************************************************************************
* Program Name: E11462 - Rail Route Function Module                   *
*                                                Create Date: 24/04/19 *
*                                                                      *
* SAP Name    : ZDL_RAIL_ROUTE                   Version    : final    *
*                                                                      *
* Programmer  : Helena Malkowska                 Last Update: mm/dd/yy *
*______________________________________________________________________*
* Description : Function Module for Extracting Rail Route              *
*______________________________________________________________________*
* Change History:                                                      *
* Programmer       Date      CD#        Action                         *
* ================ ========= ========== ===============================*
* Helena Malkowska 04/2019   2000001292 Initial transport              *
* Venkata Thota    08/2019   2000001292 Initial transport w/ newdesign *
*                                                                      *
************************************************************************

  types: begin of t_cond,
           knumh type knumh,
           kappl type kappl,
           kschl type kschl,
           vstel type vstel,
           vsbed type vsbed,
           kunwe type kunwe,
           zip   type /SAPRGX/CSTVND_ZIP10,
           datbi type kodatbi,
           datab type kodatab,
        end of t_cond.

  types: begin of t_rail_route.
      include type zdle11462_lt_rail_route.
  types: knumh type knumh,
         end of t_rail_route.

  statics: g_if type srsc_s_if_simple.

  types: t_kappl type range of kappl.
  types: t_kschl type range of kschl.
  types: t_cstvnd10 type range of /saprgx/cstvnd_zip10.
  types: t_cstvnd5 type range of /saprgx/cstvnd_zip5.
  types: t_vsbed type range of vsbed.
  types: t_kunwe type range of kunwe.
  types: t_vstel type range of vstel.
  types: t_datum type range of sy-datum.

  data: lr_kappl type t_kappl.
  data: lr_kschl type t_kschl.
  data: lr_cstvnd10 type t_cstvnd10.
  data: lr_cstvnd5 type t_cstvnd5.
  data: lr_vsbed type t_vsbed.
  data: lr_kunwe type t_kunwe.
  data: lr_vstel type t_vstel.
  data: lr_valid_to   type t_datum.
  data: lr_valid_from type t_datum.
  data: lr_valid_date type range of sy-datum.

  data: ls_kappl type line of t_kappl.
  data: ls_kschl type line of t_kschl.
  data: ls_cstvnd10 type line of t_cstvnd10.
  data: ls_cstvnd5 type line of t_cstvnd5.
  data: ls_vsbed type line of t_vsbed.
  data: ls_kunwe type line of t_kunwe.
  data: ls_vstel type line of t_vstel.
  data: ls_valid_to   type line of t_datum.
  data: ls_valid_from type line of t_datum.

  data: lt_cond type sorted table of t_cond
        with non-unique key knumh.
  data: lt_rail_route type standard table of t_rail_route.
  data: ls_cond type t_cond.
  data: lv_valid_from type sy-datum.
  data: lv_valid_to type sy-datum.
  DATA: ls_valid_date LIKE LINE OF lr_valid_date.

  refresh lt_rail_route[].

* Initialization mode (first call by SAPI) or data transfer mode
* (following calls) ?
  if i_initflag = sbiwa_c_flag_on.

* Check DataSource validity
    case i_dsource.

      when 'ZDL_RAIL_ROUTE'.

      when others.
        if 1 = 2.
          message e009(r3) with ''.
        endif.
        log_write 'E'
                  'R3'
                  '009'
                  i_dsource
                  ' '.
        raise error_passed_to_mess_handler.

    endcase.

    append lines of i_t_select to g_if-t_select.

* Fill parameter buffer for data extraction calls
    g_if-requnr    = i_requnr.
    g_if-dsource   = i_dsource.
    g_if-maxsize   = i_maxsize.

  else.
* Only process extraction once.
    if g_counter_datapakid = 0.
      g_counter_datapakid = g_counter_datapakid + 1.

* Fill the ranges
      loop at i_t_select into data(ls_select).

        case ls_select-fieldnm.
          when 'KAPPL'.
            ls_kappl    = corresponding #( ls_select ).
            append ls_kappl to lr_kappl.

          when 'KSCHL'.
            ls_kschl    = corresponding #( ls_select ).
            append ls_kschl to lr_kschl.

*          when 'VSTEL'.
*            ls_vstel    = corresponding #( ls_select ).
*            append ls_vstel to lr_vstel.
*
*          when 'KUNWE'.
*            ls_kunwe    = corresponding #( ls_select ).
*            append ls_kunwe to lr_kunwe.
*
*          when 'VSBED'.
*            ls_vsbed    = corresponding #( ls_select ).
*            append ls_vsbed to lr_vsbed.
*
*          when 'CSTVND5'.
*            ls_cstvnd5  = corresponding #( ls_select ).
*            append ls_cstvnd5 to lr_cstvnd5.
*
*          when 'CSTVND10'.
*            ls_cstvnd10 = corresponding #( ls_select ).
*            append ls_cstvnd10 to lr_cstvnd10.
*
*          when 'VALID_TO'.
*            ls_valid_to = corresponding #( ls_select ).
*            append ls_valid_to to lr_valid_to.
*
*          when 'VALID_FROM'.
*            ls_valid_from = corresponding #( ls_select  ).
*            append ls_valid_from to lr_valid_from.
        endcase.

      endloop.

      "VALID_FROM & VALID_TO should be a single value
      if lines( lr_valid_from ) = 0.
        lv_valid_from = '00010101'.
        lv_valid_to   = '99991231'.
      else.
        lv_valid_from = value #( lr_valid_from[ 1 ]-low optional ).
        lv_valid_to   = value #( lr_valid_to[ 1 ]-low optional ).
      endif.

      if not lv_valid_to is initial and lv_valid_to < lv_valid_from.
        lv_valid_to = lv_valid_from.
      endif.

      ls_valid_date-option = 'BT'.
      ls_valid_date-sign = 'I'.
      ls_valid_date-low = lv_valid_from.
      ls_valid_date-high = lv_valid_to.
      APPEND ls_valid_date TO lr_valid_date.


* Select Data
      select
        knumh,
        kappl,
        kschl,
        vstel,
        @space as vsbed,
        kunwe,
        CSTVND_ZIP10,
        datbi,
        datab
      from kot2911
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
          and datab in @lr_valid_date
          and datbi in @lr_valid_date

      union

      select
        knumh,
        kappl,
        kschl,
        vstel,
        @space as vsbed,
        kunwe,
        CSTVND_ZIP5,
        datbi,
        datab
      from kot2909
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
          and datab in @lr_valid_date
          and datbi in @lr_valid_date

      union

      select
        knumh,
        kappl,
        kschl,
        vstel,
        vsbed,
        kunwe,
        @space as zip,
        datbi,
        datab
      from kot2902
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
          and datab in @lr_valid_date
          and datbi in @lr_valid_date

      union

      select
        knumh,
        kappl,
        kschl,
        vstel,
        @space as vsbed,
        kunwe,
        @space as zip,
        datbi,
        datab
      from kot2907
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
          and datab in @lr_valid_date
          and datbi in @lr_valid_date

      union

      select
        knumh,
        kappl,
        kschl,
        @space as vstel,
        vsbed,
        @space as kunwe,
        @space as zip,
        datbi,
        datab
      from kot2908
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
          and datab in @lr_valid_date
          and datbi in @lr_valid_date

            union

      select
        knumh,
        kappl,
        kschl,
        vstel,
        @space as vsbed,
        @space as kunwe,
        @space as zip,
        datbi,
        datab
      from kot2910
        where kappl in @lr_kappl[]
          and kschl in @lr_kschl[]
          and datab in @lr_valid_date
          and datbi in @lr_valid_date

      into table @lt_cond.


      "Valid From/To
*      loop at lt_cond assigning field-symbol(<ls_cond>).
*        if lv_valid_to  is initial.
*          if not ( <ls_cond>-datbi >= lv_valid_from and
*                   <ls_cond>-datab <= lv_valid_from ).
*            delete table lt_cond from <ls_cond>.
*          endif.
*        else.
*          if not ( <ls_cond>-datbi >= lv_valid_from and
*                   <ls_cond>-datab <= lv_valid_from
*                   or
*                   <ls_cond>-datab >= lv_valid_from and
*                   <ls_cond>-datab <= lv_valid_to  ).
*            delete table lt_cond from <ls_cond>.
*          endif.
*        endif.
*      endloop.


      "Get Condition Record Header/Items
      if lt_cond[] is not initial.

        select
          kondh~knumh,
          kondp~kposn,
          kondh~kotabnr,
          kondh~kappl,
          kondh~kschl,
          kondp~route,
          tvro~tdlnr,
          tvro~routid,
          kondp~serv_preference,
          kondp~non_compliance
        from /saprgx/kond2 as kondh
          join /saprgx/kond2p as kondp on kondh~knumh = kondp~knumh
          join tvro on kondp~route = tvro~route
        into corresponding fields of table @lt_rail_route
          for all entries in @lt_cond
        where kondh~knumh = @lt_cond-knumh.

      endif.

      loop at lt_rail_route assigning field-symbol(<ls_rail_route>).

        ls_cond =
         value #( lt_cond[ knumh = <ls_rail_route>-knumh ] optional ).

        "Ship-to-Party
        <ls_rail_route>-kunwe = ls_cond-kunwe.

        "Shp Pt/Rec Pt
        <ls_rail_route>-vstel = ls_cond-vstel.

        "Shp cond
        <ls_rail_route>-vsbed = ls_cond-vsbed.

        "SAP Route
        <ls_rail_route>-routid4 =
          substring_to( val = <ls_rail_route>-routid sub = ` ` ).

        <ls_rail_route>-routid4 = condense( <ls_rail_route>-routid4 ).

        write: <ls_rail_route>-routid4
          to <ls_rail_route>-routid4 right-justified.

        "Get Route Desc
        select single bezei from tvrot into <ls_rail_route>-bezei
          where spras = sy-langu and route = <ls_rail_route>-route.

        "Get Postal code
*        select single pstlz from kna1 into <ls_rail_route>-pstlz
*          where kunnr = ls_cond-kunwe.
        <ls_rail_route>-pstlz = ls_cond-zip.

        "Valid From
        <ls_rail_route>-datab = ls_cond-datab.
        "Valid to
        <ls_rail_route>-datbi = ls_cond-datbi.

      endloop.

      sort lt_rail_route by kotabnr datab knumh serv_preference.

      e_t_data[] = corresponding #( lt_rail_route ).

* Stop after processing data.
    else.
      raise no_more_data.
    endif.

  endif.
endfunction.

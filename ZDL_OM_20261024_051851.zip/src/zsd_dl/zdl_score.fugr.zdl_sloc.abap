function zdl_sloc.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_REQUNR) TYPE  SRSC_S_IF_SIMPLE-REQUNR
*"     VALUE(I_DSOURCE) TYPE  SRSC_S_IF_SIMPLE-DSOURCE OPTIONAL
*"     VALUE(I_MAXSIZE) TYPE  SRSC_S_IF_SIMPLE-MAXSIZE OPTIONAL
*"     VALUE(I_INITFLAG) TYPE  SRSC_S_IF_SIMPLE-INITFLAG OPTIONAL
*"     VALUE(I_READ_ONLY) TYPE  SRSC_S_IF_SIMPLE-READONLY OPTIONAL
*"  TABLES
*"      I_T_SELECT TYPE  SRSC_S_IF_SIMPLE-T_SELECT OPTIONAL
*"      I_T_FIELDS TYPE  SRSC_S_IF_SIMPLE-T_FIELDS OPTIONAL
*"      E_T_DATA STRUCTURE  ZDLR10512_LT_SLOC OPTIONAL
*"  EXCEPTIONS
*"      NO_MORE_DATA
*"      ERROR_PASSED_TO_MESS_HANDLER
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2019 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
************************************************************************
* Program Name: R10512 - FM to extract Storage Location Data           *
*                                                Create Date: 24/04/19 *
*                                                                      *
* SAP Name    : ZDL_SLOC                         Version    : final    *
*                                                                      *
* Programmer  : Helena Malkowska                 Last Update: mm/dd/yy *
*______________________________________________________________________*
* Description : Storage Location Data Function Module                  *
*______________________________________________________________________*
* Change History:                                                      *
* Programmer       Date      CD#        Action                         *
* ================ ========= ========== ===============================*
* Helena Malkowska 03/2019   2000000536 Initial transport              *
* Helena Malkowska 04/2019   2000001292 Re-built the FM according to BW*
*                                       standards                      *
*                                                                      *
************************************************************************
  types: t_werks type range of werks_d.
  types: t_lgort type range of lgort_d.

  statics: g_if type srsc_s_if_simple.

  data: lr_werks type t_werks.
  data: lr_lgort type t_lgort.

  data: ls_werks type line of t_werks.
  data: ls_lgort type line of t_lgort.

* Initialization mode (first call by SAPI) or data transfer mode
* (following calls) ?
  if i_initflag = sbiwa_c_flag_on.

* Check DataSource validity
    case i_dsource.

      when 'ZDL_SLOC'.

      when others.
        if 1 = 2.
          message e009(r3) with ''.
        endif.
        log_write 'E'
                  'R3'
                  '009'
                  i_dsource
                  ' '.
        raise error_passed_to_mess_handler.

    endcase.

    append lines of i_t_select to g_if-t_select.

* Fill parameter buffer for data extraction calls
    g_if-requnr    = i_requnr.
    g_if-dsource   = i_dsource.
    g_if-maxsize   = i_maxsize.

  else.
* Only process extraction once.
    if g_counter_datapakid = 0.
      g_counter_datapakid = g_counter_datapakid + 1.
* Fill the ranges
      loop at i_t_select into data(ls_select).

        case ls_select-fieldnm.

          when 'WERKS'.
            ls_werks    = corresponding #( ls_select ).
            append ls_werks to lr_werks.

          when 'LGORT'.
            ls_lgort   = corresponding #( ls_select ).
            append ls_lgort to lr_lgort.

        endcase.

      endloop.

      refresh e_t_data[].

      select
        t001w~werks,
        t001w~name1,
        twlad~lgort,
        adrc~name1 as adrname,
        adrc~house_num1,
        adrc~street,
        adrc~city1,
        adrc~region,
        adrc~post_code1
      from twlad join t001w on twlad~werks = t001w~werks
            join adrc on twlad~adrnr = adrc~addrnumber
            into corresponding fields of table @e_t_data
      where t001w~werks in @lr_werks
        and twlad~lgort in @lr_lgort.

    else.
* Stop after processing data.
      raise no_more_data.
    endif.
  endif.

endfunction.

FUNCTION z_sd_dl_calc_frt_cost.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(I_TRANS_DATE) LIKE  KOMP-KURSK_DAT
*"     REFERENCE(I_LOCAL_CURR) LIKE  KOMK-WAERK
*"     REFERENCE(I_WEIGHT_UNIT) LIKE  KOMP-GEWEI
*"     REFERENCE(I_ORDER_WEIGHT) LIKE  KOMP-BRGEW
*"  EXPORTING
*"     REFERENCE(EXCHANGE_RATE) TYPE  KKURS
*"     REFERENCE(I_SALES_ORD_CURR) TYPE  WAERK
*"     REFERENCE(I_CALC_TYPE) TYPE  KRECH
*"     REFERENCE(I_CONDITION_VALUE) TYPE  KWERT
*"     REFERENCE(I_CONVERTED_WEIGHT) TYPE  BRGEW
*"  CHANGING
*"     REFERENCE(I_RATE) LIKE  VBAK-ZZBASERATE
*"     REFERENCE(I_UOM) TYPE  UNIT
*"  EXCEPTIONS
*"      ERROR
*"      CURRENCY_CONVERSION
*"----------------------------------------------------------------------
*&---------------------------------------------------------------------*
*& Convert currency and weight for export pricing conditions
*&---------------------------------------------------------------------*
*&  © International Paper - May 2004
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&  Change History:
*&     Programmer       Date        Action
*& ================== ========  ==============================
*& Maureen Carter     05/04/04  Initial creation from R/3
*& Sushila Chaudhary  05/23/04  Changes as suggested by Phil
*&                              for the rounding issues.
*& Maureen Carter     08/20/04  change EA to CON
*& Maureen Carter     10/15/04  move calc_type=D inside IF/ENDIF
*&---------------------------------------------------------------------*
  DATA: l_brgew TYPE brgew.

  CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
    EXPORTING
      date             = i_trans_date
      foreign_amount   = i_rate
      foreign_currency = 'USD'     "g_vbak-waerk in global?
      local_currency   = i_local_curr
    IMPORTING
      exchange_rate    = exchange_rate
      local_amount     = i_rate
    EXCEPTIONS
      no_rate_found    = 1
      overflow         = 2
      no_factors_found = 3
      no_spread_found  = 4
      derived_2_times  = 5
      OTHERS           = 6.


  IF sy-subrc <> 0.

    RAISE currency_conversion.

  ELSE.

    IF i_weight_unit NE i_uom AND NOT i_uom IS INITIAL
                               AND NOT i_weight_unit IS INITIAL.

      l_brgew = i_order_weight.        "gross weight
      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
        EXPORTING
          input    = l_brgew
          unit_in  = i_weight_unit
          unit_out = i_uom
        IMPORTING
          output   = l_brgew
        EXCEPTIONS
          OTHERS   = 1.

      IF sy-subrc = 0.

        i_calc_type = 'D'.
*       i_condition_value = ( i_rate * l_brgew ) / 1000.
        i_condition_value = ( i_rate * l_brgew ) * 100.  "S.C on 05/23

      ELSE.
*     replaced i line 08/20/2004
*        IF i_uom = 'EA'.
        IF i_uom = 'CON'.

          l_brgew =  g_anzpk.       "global data
          i_calc_type = 'C'.

        ELSE.

          l_brgew = 1.
          i_calc_type = 'B'.

        ENDIF.

*        i_condition_value = i_rate * l_brgew. " S.C on 05/23
        i_condition_value = i_rate * l_brgew * 100.

      ENDIF.
      i_converted_weight = l_brgew.
      i_calc_type = 'D'.                  "moved 10/04

    ENDIF.

    i_sales_ord_curr = g_vbak-waerk.
*    i_calc_type = 'D'.                                  " added S.C
    i_condition_value = ( i_rate * l_brgew ) * 100.     " added S.C


  ENDIF.

ENDFUNCTION.

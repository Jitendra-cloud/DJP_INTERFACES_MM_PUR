FUNCTION-POOL ZDLR10512.                    "MESSAGE-ID ..

* INCLUDE LZDLR10512D...                     " Local class definition

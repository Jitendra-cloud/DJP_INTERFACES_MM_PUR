*&---------------------------------------------------------------------*
*& Report  ZDL_E04624_EX_WF_GR                                         *
*&                                                                     *
*&---------------------------------------------------------------------*
*&                                                                     *
*&                                                                     *
*&---------------------------------------------------------------------*

REPORT  ZDL_E04624_EX_WF_GR.

data gv_docnum(16) type n.
data gs_9000_docnum like gv_docnum.

parameters p_docnum like gv_docnum.

move p_docnum to gs_9000_docnum.

call dialog 'ZDL_E04624_DIAG' exporting gs_9000_docnum.

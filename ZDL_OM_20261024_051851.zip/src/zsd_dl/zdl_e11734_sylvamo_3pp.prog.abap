************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           20xx                                     **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Fun. Name: ZDL_E11734_SYLVAMO_3PP                   Date: 05/05/2021 *
*            Sylvamo Third Party Processing Program                    *
*                                                                      *
* Programmer  : Helena Malkowska                                       *
*                                                                      *
* This program is copied from an existing program E03637 which is used *
* to perform automated functions to support products that were shipped *
* directly from the vendor to the end customer.                        *
*                                                                      *
* Items below 1,2,3 refer to the old functionality (included in E03637)*
* Items 4,5 are the functionality added in E11734                      *
*                                                                      *
* (1)	Perform the Goods receipt for selected inbound deliveries to     *
*     “receive” the product from the vendor into a “virtual” plant.    *
* (2)	Create an Outbound delivery using the products and batches that  *
*     were received in step 1.                                         *
* (3) Perform the Pick and Pack of the product from the virtual plant  *
*     in the outbound delivery                                         *
* (4) Create an Outbound Shipment assigning the outbound delivery      *
*     created.                                                         *
* (5) Set Shipment status to Load End                                  *
*______________________________________________________________________*
* Change History:                                                      *
* Date     CO#/TPR#/CR# Transport#  Remarks                            *
* =========================================                            *
* 03/05/07 TPR17697/CO73746  E0VK926702   as break/fix                 *
* SRENGAN-1)Batch job fails with no application log information        *
*         2)Post multiple inbound deliveries there in a problem in HU  *
*           is reflected in the subsequent inbound delivery posting.   *
*         3)Multiple Inbound delivery posting with over delivery-over  *
*           delivery when there is no open quantity to be delivered.   *
*         4)Update messages in application log to ordinary list so that*
*           user can see it in spool.                                  *
*                                                                      *
* 09/10/2012 CR# 11871
* JPIERI  1) Add screen selection options for plant and vendor         *
*         2) Validate plants entered against table ZPLANT and vendors  *
*            against table LFA1.
* 2/11/2016 CMS 29123
* ALANKAP Modified the program to handle the scenario where the Inb Del*
*         is linked with multiple Sales Orders. Now the program will   *
*         create multiple outbound Deliveries.                         *
* 2018/04 E0V CMS 33303
* JGRABOW Changes for DLK delivery
*
* 5/1/2019 CD# 1718
* JWILL68 1. If shipment is NOT updated on inbound delivery by sync    *
*            program then do not do GR.
*         2. If Shipment is DCGR relevant (build logic) then make sure *
*            shipment cost document is in C status. Otherwise do not   *
*            post GR.                                                  *
*
* 5/20/2019 CD#1626                                                    *
* JWILL68:                                                             *
*         1. Process creation of outbound if inbound fails.            *
*         2. process the pick if outbound is not picked.               *
*         3. Process the pack if the outbound is not packed            *
*----------------------------------------------------------------------*
* 05/2021 Helena Malkowska    - Copied to E11734 Sylvamo Third Party   *
*                               Processing Program                     *
*                             - Create an Outbound Shipment assigning  *
*                               the outbound delivery created          *
*                             - Set Shipment status to Load End        *
* CD# 2000000248                                                       *
* 09/2021 Helena Malkowska    - Delete the Inbound Deliveries where    *
*                               Total Weight LIKP-BTGEW is BLANK       *
*                             - If Delivery Route is blank then set    *
*                               default route from ZDL_FIELDS table    *
* CD# 2000000261                                                       *
* 09/2021 Helena Malkowska    - Adding a check if all Inbound Deliveries
*                               with the same BOLNR are processed      *
*                               together                               *
* CD# 2000000264                                                       *
* 09/2021 Helena Malkowska    - Fixing the logic error related to check*
*                               for Inb.Deliveries with the same BOLNR *
*                             - Use the LIKP-WADAT (Planned Goods Issue)
*                               and LIKP-WAUHR (Goods Issue Time) fields
*                               or LIKP-LFDAT and LIKP-ERZET, depend on*
*                               ZDL_FIELDS entry to populate the date/ *
*                               time fields status                     *
* CD# 2000000282                                                       *
* 09/2021 Helena Malkowska    - Fixing the bug related to multiple Out-*
*                               bound Deliveries that are created for  *
*                               one Inbound Delivery.                  *
* CD# 2000000330                                                       *
* 10/2021 Helena Malkowska    - Fixing the UTC time zone issue         *
*                             - Adding an option in ZDL_FIELDS to enable
*                               the use of LIKP fields:                *
*                               •ZZ_RCPT_DATE_FM                       *
*                               •ZZ_RCPT_TIME_FM                       *
*                               to populate the date/time fields status*
*                               on the Shipment                        *
*                             - USD ticket/email notification in case  *
*                               of error                               *
* CD# 2000000390                                                       *
* 10/2021 Helena Malkowska     Correction of logical condition         *
* CD# 2000000744                                                       *
* 06/2022 Mallik Aiely         Manual Update of outbound delivery Route*
*______________________________ _______________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*    ZDL_E3637_POST_INB_DLVRY_GR - Post GR for a inbound delivery      *
*    ZDL_E3637_GEN_OUT_DLVRY     - Create outbound delivery wrt SO     *
*    ZDL_E3637_SPLIT_PICK_PACK   - Split the batch and Pick & Pack del.*
*                                                                      *
*   Programs        :                                                  *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   : Everyday Night & On Demand                       *
*                                                                      *
*______________________________________________________________________*
************************************************************************
report  zdl_e11734_sylvamo_3pp message-id zsd_dl.

include zdl_e11734_sylvamo_3pp_top.
include zdl_e11734_sylvamo_3pp_def.
include zdl_e11734_sylvamo_3pp_imp.
include zdl_e11734_sylvamo_3pp_f01.

***** hmalkow - start
*-----------------------------------------------------------------------
initialization.
  lcl_3rd_party=>initialization( ).
***** hmalkow - end

*-----------------------------------------------------------------------
at selection-screen output.
  perform enable_out_dlvry.

*-----------------------------------------------------------------------
at selection-screen.
  refresh:  gt_inb_dlvry,   gt_so,  gt_messages.
  clear:    gs_inb_dlvry,   gs_so.

  if sy-ucomm = 'ONLI'.
***** hmalkow - start
    lcl_3rd_party=>check_action( ).
***** hmalkow - end
    perform sele_scr_val.  "Selection-Screen Validation
  endif.

* TPR 17697 - Point (4) - standard IP report heading - start
top-of-page.
  perform print_heading.
* TPR 17697 - Point (4) - standard IP report heading - end

start-of-selection.

*  PERFORM process.       "Process the inputs
  if sp_posgr is not initial or
     sp_vl01n is not initial or
     sp_charg is not initial.

    lcl_3rd_party=>process( ).
  endif.

***** hmalkow - start
  if lcl_3rd_party=>mt_process[] is not initial.
    lcl_3rd_party=>process_shp( ).
  endif.
***** hmalkow - end

end-of-selection.
  perform output.        "Display/Save the output

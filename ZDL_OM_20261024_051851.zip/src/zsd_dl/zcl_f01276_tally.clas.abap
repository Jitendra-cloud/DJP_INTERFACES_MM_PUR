class ZCL_F01276_TALLY definition
  public
  final
  create public .

*"* public components of class ZCL_F01276_TALLY
*"* do not include other source files here!!!
public section.
  type-pools ZMOS .

  class-data GV_TKNUM type TKNUM .
  class-data GS_NAST type NAST .

  class-methods ENTRY_SHIPMENT
    importing
      !IS_NAST type NAST
    exporting
      !ET_ODPAIR type ZF01276_ODPAIR_TAB .
  class-methods ENTRY_DELIVERY
    importing
      !IS_NAST type NAST
    exporting
      !ET_ODPAIR type ZF01276_ODPAIR_TAB .
  class-methods ENTRY_INVOICE
    importing
      !IS_NAST type NAST
    exporting
      !ET_ODPAIR type ZF01276_ODPAIR_TAB .
protected section.
*"* protected components of class ZCL_F01276_TALLY
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_F01276_TALLY
*"* do not include other source files here!!!

  class-data GT_INV type GT_INVOICE .
  class-data GT_NAST_DELV type GT_NAST_DELV .
  class-data GT_KNVK type GT_KNVK .
  class-data GT_KNVP type GT_KNVP .
  class-data GT_NAST_VBELN type GT_NAST_VBELN .

  class-methods GET_SOLD_TO_STO
    importing
      !IV_SORDER type CHAR10
    exporting
      !EV_SOLDTO type CHAR10 .
  class-methods SET_OD_PAIR
    importing
      !IT_LIKP type GT_LIKP
      !IT_NAST_PARNR type GT_NAST_PARNR optional
    exporting
      !ET_SOLDTO type ZF01276_ODPAIR_TAB .
  class-methods GET_DELIVERIES
    importing
      !IV_TKNUM type TKNUM
    exporting
      !ET_ITIN type GT_ITIN .
  class-methods GET_SOLD_TO
    importing
      !IT_ITIN type GT_ITIN
    exporting
      !ET_LIKP type GT_LIKP .
  class-methods GET_SALES_ORDER_STO
    importing
      !IV_VGBEL type VGBEL
      !IV_VGPOS type VGPOS
    exporting
      !EV_SALESORDER type CHAR10 .
  class-methods GET_NAST_RECORDS
    importing
      !IT_NAST_DELV type GT_NAST_DELV
    exporting
      !ET_NAST_PARNR type GT_NAST_PARNR .
  class-methods GET_ADDR_KEY
    importing
      !IV_PARNR type NA_PARNR
      !IV_PARVW type SNA_PARVW
      !IV_PRSNR type AD_PERSNUM
      !IV_SNDBC type AD_ADRTYPE
    exporting
      !EV_ADDR_KEY type ADDR_KEY .
  class-methods GET_CP_DETAILS
    importing
      value(IS_LIKP) type GS_LIKP
      value(IS_NAST_PARNR) type GS_NAST_PARNR
    exporting
      !ES_PARNR type ZPARNR_OD_PAIR_STR .
ENDCLASS.



CLASS ZCL_F01276_TALLY IMPLEMENTATION.


METHOD entry_delivery .

  DATA : lt_itin  TYPE STANDARD TABLE OF gs_itin,
         ls_itin TYPE gs_itin.
  DATA : lt_likp TYPE STANDARD TABLE OF gs_likp,
         lv_tknum TYPE tknum,
         ls_nast_delv TYPE gs_nast_delv,
         lt_nast_parnr TYPE STANDARD TABLE OF gs_nast_parnr.

  gs_nast = is_nast.
* get the shipment number from vttp
  SELECT SINGLE tknum
         INTO lv_tknum
         FROM vttp
  WHERE vbeln = is_nast-objky.

  IF sy-subrc = 0.
* for a single delivery also we need to run the itineary view to take
* care of replacement shipment
    CALL METHOD zcl_f01276_tally=>get_deliveries
      EXPORTING
        iv_tknum = lv_tknum
      IMPORTING
        et_itin  = lt_itin.

  ELSE.
* append the delivery to the internal table
    ls_itin-vbeln = is_nast-objky.
    APPEND ls_itin TO lt_itin.
    APPEND is_nast-objky TO gt_nast_delv.

    CLEAR ls_itin.
  ENDIF.

  CASE gs_nast-nacha.

    WHEN '1' OR
         '8'.
* get sold to
      CHECK lt_itin[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>get_sold_to
        EXPORTING
          it_itin = lt_itin
        IMPORTING
          et_likp = lt_likp.

* set up the od pair
      CHECK lt_likp[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>set_od_pair
        EXPORTING
          it_likp   = lt_likp
        IMPORTING
          et_soldto = et_odpair.

    WHEN '2' OR
         '5'.
* check for the condition records in table nast for the deliveries
      CHECK gt_nast_delv[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>get_nast_records
        EXPORTING
          it_nast_delv  = gt_nast_delv
        IMPORTING
          et_nast_parnr = lt_nast_parnr.

* get sold to
      CHECK lt_nast_parnr[] IS NOT INITIAL.

      CALL METHOD zcl_f01276_tally=>get_sold_to
        EXPORTING
          it_itin = lt_itin
        IMPORTING
          et_likp = lt_likp.

* set up the od pair
      CHECK lt_likp[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>set_od_pair
        EXPORTING
          it_likp       = lt_likp
          it_nast_parnr = lt_nast_parnr
        IMPORTING
          et_soldto     = et_odpair.
  ENDCASE.

ENDMETHOD.


METHOD entry_invoice .

  FIELD-SYMBOLS : <ls_inv> TYPE gs_invoice.

  DATA : lt_itin  TYPE STANDARD TABLE OF gs_itin,
         lt_itin_temp TYPE STANDARD TABLE OF gs_itin.

  DATA : lt_likp  TYPE STANDARD TABLE OF gs_likp.
  DATA : lt_delv  TYPE STANDARD TABLE OF gs_delvery,
         ls_nast_delv TYPE gs_nast_delv,
         lt_nast_parnr TYPE STANDARD TABLE OF gs_nast_parnr.

  DATA : ls_itin TYPE gs_itin,
         ls_delv TYPE gs_delvery.

  DATA : lv_lins_delv TYPE i,
         lv_lins_shp TYPE i.

  CLEAR gs_nast.
  gs_nast = is_nast.
  REFRESH : gt_inv.
  REFRESH : gt_nast_delv.
* get the deliveries from vbrp
  SELECT vbeln
         vgbel
    FROM vbrp
    INTO TABLE lt_delv
    WHERE vbeln = is_nast-objky.

  CHECK sy-subrc = 0.
  DELETE ADJACENT DUPLICATES FROM lt_delv COMPARING vgbel.
  DESCRIBE TABLE lt_delv LINES lv_lins_delv.
* check whether a shipment is attached to the delv
  SELECT tknum
         vbeln
    INTO TABLE gt_inv
    FROM vttp
    FOR ALL ENTRIES IN lt_delv
    WHERE vbeln = lt_delv-vgbel.
  IF sy-subrc = 0.
* delete adjacent duplicates from table gt_inv - though not possible
    SORT gt_inv BY tknum vbeln.
    DELETE ADJACENT DUPLICATES FROM gt_inv COMPARING tknum vbeln.
    DESCRIBE TABLE gt_inv LINES lv_lins_shp.
  ENDIF.

* get the shipping point for all the deliveries having shipment

  LOOP AT gt_inv ASSIGNING <ls_inv>.
    AT END OF tknum.
      CALL METHOD zcl_f01276_tally=>get_deliveries
        EXPORTING
          iv_tknum = <ls_inv>-tknum
        IMPORTING
          et_itin  = lt_itin_temp.

      APPEND LINES OF lt_itin_temp TO lt_itin.
      REFRESH lt_itin_temp.
    ENDAT.
  ENDLOOP.

* check whether all the deliveries have shipment attached to it
  IF lv_lins_delv <> lv_lins_shp.
    LOOP AT lt_delv INTO ls_delv.
      READ TABLE gt_inv INTO <ls_inv>
                     WITH KEY vbeln = ls_delv-vgbel.
      IF sy-subrc <> 0.
        ls_itin-vbeln = ls_delv-vgbel.
        APPEND ls_itin TO lt_itin.
        ls_nast_delv-objky = ls_delv-vgbel.
        APPEND ls_nast_delv TO gt_nast_delv.
      ENDIF.
    ENDLOOP.
  ENDIF.



  CASE is_nast-nacha.
    WHEN '1'.
* get sold to
      CHECK lt_itin[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>get_sold_to
        EXPORTING
          it_itin = lt_itin
        IMPORTING
          et_likp = lt_likp.

      CHECK lt_likp[] IS NOT INITIAL.
* set up the od pair
      CALL METHOD zcl_f01276_tally=>set_od_pair
        EXPORTING
          it_likp   = lt_likp
        IMPORTING
          et_soldto = et_odpair.

    WHEN '2' OR
         '5'.

* check for the condition records in table nast for the deliveries
      CHECK gt_nast_delv[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>get_nast_records
        EXPORTING
          it_nast_delv  = gt_nast_delv
        IMPORTING
          et_nast_parnr = lt_nast_parnr.

* get sold to
      CHECK lt_nast_parnr[] IS NOT INITIAL.

      CALL METHOD zcl_f01276_tally=>get_sold_to
        EXPORTING
          it_itin = lt_itin
        IMPORTING
          et_likp = lt_likp.

* set up the od pair
      CHECK lt_likp[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>set_od_pair
        EXPORTING
          it_likp       = lt_likp
          it_nast_parnr = lt_nast_parnr
        IMPORTING
          et_soldto     = et_odpair.

  ENDCASE.

ENDMETHOD.


METHOD entry_shipment .

  DATA : lt_itin  TYPE STANDARD TABLE OF gs_itin.
  DATA : lt_likp TYPE STANDARD TABLE OF gs_likp,
         lt_nast_parnr TYPE STANDARD TABLE OF gs_nast_parnr,
         lv_tknum TYPE tknum.


* set the nast details to global attribute
  clear gs_nast.
  gs_nast = is_nast.
  lv_tknum = is_nast-objky.

  CHECK lv_tknum IS NOT INITIAL.

* get deliveries for the shipment
  CALL METHOD zcl_f01276_tally=>get_deliveries
    EXPORTING
      iv_tknum = lv_tknum
    IMPORTING
      et_itin  = lt_itin.

  CHECK lt_itin[] IS NOT INITIAL.
  CASE is_nast-nacha.
    WHEN '1'.
* get sold to
      CALL METHOD zcl_f01276_tally=>get_sold_to
        EXPORTING
          it_itin = lt_itin
        IMPORTING
          et_likp = lt_likp.

      CHECK lt_likp[] IS NOT INITIAL.
* set up the od pair
      CALL METHOD zcl_f01276_tally=>set_od_pair
        EXPORTING
          it_likp   = lt_likp
        IMPORTING
          et_soldto = et_odpair.

    WHEN '2' OR
         '5'.

* check for the condition records in table nast for the deliveries
      CHECK gt_nast_delv[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>get_nast_records
        EXPORTING
          it_nast_delv  = gt_nast_delv
        IMPORTING
          et_nast_parnr = lt_nast_parnr.

* get sold to
      CHECK lt_nast_parnr[] IS NOT INITIAL.

      CALL METHOD zcl_f01276_tally=>get_sold_to
        EXPORTING
          it_itin = lt_itin
        IMPORTING
          et_likp = lt_likp.

* set up the od pair
      CHECK lt_likp[] IS NOT INITIAL.
      CALL METHOD zcl_f01276_tally=>set_od_pair
        EXPORTING
          it_likp       = lt_likp
          it_nast_parnr = lt_nast_parnr
        IMPORTING
          et_soldto     = et_odpair.
  ENDCASE.

ENDMETHOD.


method GET_ADDR_KEY .

  if iv_parvw = 'ZF' OR  " Freight Forwarder
     iv_parvw = 'CA' .   " Carrier
        SELECT SINGLE adrnr INTO ev_addr_key-addrnumber
      FROM lfa1
      WHERE lifnr = iv_parnr.
else.
    SELECT SINGLE addrnumber
      FROM adcp
      INTO ev_addr_key-addrnumber
     WHERE persnumber = iv_prsnr.

    ev_addr_key-persnumber = iv_prsnr.
    ev_addr_key-addr_type  = iv_sndbc.

    endif.
endmethod.


METHOD get_cp_details .

  DATA :  ls_knvk TYPE gs_knvk,
          ls_knvp TYPE gs_knvp.

    READ TABLE gt_knvk INTO ls_knvk
                       WITH KEY kunnr = is_likp-kunag
                                parnr = is_nast_parnr-parnr.
    IF sy-subrc <> 0 .
      READ TABLE gt_knvp INTO ls_knvp
                         WITH KEY kunnr = is_likp-kunag
                                  parnr = is_nast_parnr-parnr.

      READ TABLE gt_knvk INTO ls_knvk
                          WITH KEY parnr = is_nast_parnr-parnr.

    ENDIF.

    es_parnr-parnr = is_nast_parnr-parnr.
    es_parnr-cont_prsn = ls_knvk-kunnr.
    es_parnr-name1 = ls_knvk-name1.
    IF ls_knvk-namev IS INITIAL.
      es_parnr-namev = 'Receiving Department'(t01).
    ELSE.
      es_parnr-namev = ls_knvk-namev.
    ENDIF.

    es_parnr-kschl = is_nast_parnr-kschl.
    es_parnr-parvw = is_nast_parnr-parvw.
    es_parnr-telfx = is_nast_parnr-telfx.
    es_parnr-tland = is_nast_parnr-tland.
* get address key
    CALL METHOD zcl_f01276_tally=>get_addr_key
      EXPORTING
        iv_parnr    = is_nast_parnr-parnr
        iv_parvw    = is_nast_parnr-parvw
        iv_prsnr    = ls_knvk-prsnr
        iv_sndbc    = is_nast_parnr-sndbc
      IMPORTING
        ev_addr_key = es_parnr-addr_key.
*  ENDLOOP.

ENDMETHOD.


METHOD get_deliveries .

  DATA : ls_inv TYPE gs_invoice.

  DATA : ls_itinerary TYPE  zmos_itinerary,
         lt_itinerary TYPE TABLE OF zmos_itinerary,
         ls_deliveries  TYPE zmos_deliveries ,
         lt_deliveries  TYPE TABLE OF zmos_deliveries ,
         ls_ittin TYPE gs_itin,
         ls_nast_delv TYPE gs_nast_delv.


* get the origin and the deliveries from FM
  CALL FUNCTION 'ZSD_DL_MOS_ITINERARY_VIEW'
    EXPORTING
      i_tknum                        = iv_tknum
*    IMPORTING
*      e_mos_ind                      = lv_mos
    TABLES
      t_itinerary                    = lt_itinerary
    EXCEPTIONS
      invalid_input                  = 1
      shipment_not_found             = 2
      no_deliveries_found            = 3
      no_stages_on_shipment          = 4
      no_authority                   = 5
      deliveries_unassigned_to_stage = 6
      flex_multi_origin_not_allowed  = 7
      OTHERS                         = 8.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.

    LOOP AT lt_itinerary INTO ls_itinerary.

* check for the origin stop type
      IF ls_itinerary-stpty = 'CL' OR
         ls_itinerary-stpty = 'PL'.

* check in case of multi origin. when the packing list is fired
* from transcation Z03732 then only deliveries associated with that
* stop point should be retreived
        IF gs_nast-pfld1 IS NOT INITIAL.
          IF ls_itinerary-vstel <> gs_nast-pfld1.
            CONTINUE.
          ENDIF.
        ENDIF.

* move the deliveries to the internal table.
        MOVE ls_itinerary-deliveries TO lt_deliveries.
        LOOP AT lt_deliveries INTO ls_deliveries.

*****************************************************
* check if entry type is invoice . the read the deliveries which has
* been returned by invoice

          IF gs_nast-kappl = 'V3'.
            READ TABLE gt_inv INTO ls_inv
                              WITH KEY tknum = iv_tknum
                                       vbeln = ls_deliveries-vbeln.
            IF sy-subrc <> 0.
              CONTINUE.
            ENDIF.
          ENDIF.

***************************************************
* check if entry type is delv
          IF gs_nast-kappl = 'V2'.
            IF ls_deliveries-vbeln <> gs_nast-objky.
              CONTINUE.
            ENDIF.
          ENDIF.
**************************************************************
          ls_ittin-tknum = iv_tknum.
          ls_ittin-vbeln = ls_deliveries-vbeln.
          ls_ittin-vstel = ls_itinerary-vstel.
          APPEND ls_ittin TO et_itin.
* also append deliveries to a range of nast
          ls_nast_delv-objky = ls_deliveries-vbeln.
          APPEND ls_nast_delv TO gt_nast_delv.
        ENDLOOP.
      ENDIF.
    ENDLOOP.

    SORT et_itin BY vstel vbeln.
  ENDIF.
ENDMETHOD.


METHOD get_nast_records .

  DATA : lt_nast_knvk TYPE STANDARD TABLE OF gs_nast_knvk.
  DATA : lt_nast_knvp TYPE STANDARD TABLE OF gs_nast_knvp,
         ls_nast_knvk TYPE gs_nast_knvk,
         ls_nast_knvp TYPE gs_nast_knvp,
         ls_nast_parnr TYPE gs_nast_parnr,
         ls_nast_vbeln TYPE gs_nast_vbeln.

* begin of change / nparchu
  IF gs_nast-kappl = 'V3'.
* The commented code was put to output fax or email when an invoice
* is fired to the partner on the invoice only , unlike shipment where
* it needs to be fired for all the deliveries and the condition record
* associated with the deliveries
*  This fix was not working when the user was manually procesinf the
* invoice . so we are now processing the nast record and not reading
* from the table.

*
*    SELECT  parnr
*            kschl
*            objky
*            parvw
*            nacha
*            vstat
*            sndbc
*            telfx
*            tland
*
*      FROM nast
*      INTO TABLE et_nast_parnr
*      WHERE objky = gs_nast-objky AND
*            parnr = gs_nast-parnr.
       move-corresponding gs_nast to ls_nast_parnr.
       APPEND ls_nast_parnr to et_nast_parnr.
       clear ls_nast_parnr.
*
** end of change / nparchu
 ELSE.
  SELECT  parnr
          kschl
          objky
          parvw
          nacha
          vstat
          sndbc
          telfx
          tland

    FROM nast
    INTO TABLE et_nast_parnr
    FOR ALL ENTRIES IN it_nast_delv
    WHERE kappl = 'V2' AND
          objky = it_nast_delv-objky .
  ENDIF.
  CHECK sy-subrc = 0 .

* if medium is not matching with the shipment record
  SORT et_nast_parnr BY nacha.
  DELETE et_nast_parnr WHERE nacha <> gs_nast-nacha.

* delete processing by status 0
  SORT et_nast_parnr BY vstat.
  DELETE et_nast_parnr WHERE vstat <> 0.

  CHECK et_nast_parnr IS NOT INITIAL.

* parnr is type char 10 in nast table and numc 10 in knvk and knvp
* table hence we need to convert parnr to type numc .
  LOOP AT et_nast_parnr INTO ls_nast_parnr.
    ls_nast_knvk-parnr = ls_nast_parnr-parnr.
    ls_nast_knvp-parnr = ls_nast_parnr-parnr.
    ls_nast_knvp-parvw = ls_nast_parnr-parvw.
    ls_nast_vbeln = ls_nast_parnr-objky.
    APPEND ls_nast_knvk TO lt_nast_knvk.
    APPEND ls_nast_knvp TO lt_nast_knvp.
    APPEND ls_nast_vbeln TO gt_nast_vbeln.
  ENDLOOP.

  SORT lt_nast_knvp BY parnr.
  DELETE ADJACENT DUPLICATES FROM lt_nast_knvp COMPARING parnr.

  SORT lt_nast_knvk BY parnr.
  DELETE ADJACENT DUPLICATES FROM lt_nast_knvk COMPARING parnr.

  SORT  gt_nast_vbeln BY vbeln.
  DELETE ADJACENT DUPLICATES FROM gt_nast_vbeln COMPARING vbeln.

* get the contact person for the delivery
  SELECT parnr
         kunnr
         prsnr
         name1
         namev
  FROM knvk INTO TABLE gt_knvk
  FOR ALL ENTRIES IN lt_nast_knvk
  WHERE parnr = lt_nast_knvk-parnr.


* get the contact person for the delivery
  SELECT kunnr
         parnr
    FROM knvp INTO TABLE gt_knvp
    FOR ALL ENTRIES IN lt_nast_knvp
    WHERE parnr = lt_nast_knvp-parnr
    AND   parvw = lt_nast_knvp-parvw.

ENDMETHOD.


METHOD get_sales_order_sto .

  SELECT SINGLE vbeln
        FROM ekkn
        INTO ev_salesorder
    WHERE ebeln = iv_vgbel and
          ebelp = iv_vgpos.

  IF sy-subrc <> 0 .
    SELECT SINGLE zzvbeln
          FROM ekko
          INTO ev_salesorder
      WHERE ebeln = iv_vgbel.
  ENDIF.

ENDMETHOD.


METHOD get_sold_to .

  DATA :  ls_itin TYPE gs_itin,
          lv_zzpackflag TYPE zzpackflag,
          lv_kunnr TYPE kunnr,
          lv_tabix TYPE sy-tabix.

  FIELD-SYMBOLS : <ls_likp> TYPE gs_likp.

  CASE gs_nast-nacha.
* depending upon the medium select the detatls from the
* appopriate table
    WHEN '1' OR
         '8'.
* get the lips  origin , sold to , ship to
      SELECT   likp~vstel
               likp~kunnr
               likp~kunag
               likp~vkorg
               lips~vbeln
               lips~posnr
               lips~vgtyp
               lips~vgbel
               lips~vgpos
               lips~matnr
               lips~vbelv
               lips~posnv
               lips~spart
               lips~vtweg
           INTO CORRESPONDING FIELDS OF TABLE et_likp
           FROM likp
           INNER JOIN lips
           ON likp~vbeln = lips~vbeln
           FOR ALL entries IN it_itin
           WHERE likp~vbeln = it_itin-vbeln AND
                 lips~pstyv <> 'ZBAT'.
* when email or fax
    WHEN '2' OR
         '5'.
** begin of change / np
      IF gs_nast-kappl = 'V3'.
        SELECT   likp~vstel
                 likp~kunnr
                 likp~kunag
                 likp~vkorg
                 lips~vbeln
                 lips~posnr
                 lips~vgtyp
                 lips~vgbel
                 lips~vgpos
                 lips~matnr
                 lips~vbelv
                 lips~posnv
                 lips~spart
                 lips~vtweg
             INTO CORRESPONDING FIELDS OF TABLE et_likp
             FROM likp
             INNER JOIN lips
             ON likp~vbeln = lips~vbeln
             FOR ALL entries IN it_itin
             WHERE likp~vbeln = it_itin-vbeln AND
                   lips~pstyv <> 'ZBAT'.
      ELSE.
        SELECT   likp~vstel
                  likp~kunnr
                  likp~kunag
                  likp~vkorg
                  lips~vbeln
                  lips~posnr
                  lips~vgtyp
                  lips~vgbel
                  lips~vgpos
                  lips~matnr
                  lips~vbelv
                  lips~posnv
                  lips~spart
                  lips~vtweg
              INTO CORRESPONDING FIELDS OF TABLE et_likp
              FROM likp
              INNER JOIN lips
              ON likp~vbeln = lips~vbeln
              FOR ALL entries IN gt_nast_vbeln
              WHERE likp~vbeln = gt_nast_vbeln-vbeln AND
                    lips~pstyv <> 'ZBAT'.
      ENDIF.
  ENDCASE.
* check for returned entries
  CHECK sy-subrc = 0 .
  SORT et_likp BY vstel kunnr kunag.


  LOOP AT et_likp ASSIGNING <ls_likp> .
    lv_tabix = sy-tabix.

* populate the internal table with origin and shipping number
* as derived from the method get_deliveries
    READ TABLE it_itin INTO ls_itin WITH KEY vbeln = <ls_likp>-vbeln.
    <ls_likp>-tknum = ls_itin-tknum.
* get the origin point from itinerinary view table , in case of
* consignment issue let the vstel of the likp hold good
    IF ls_itin-vstel <> space.
      <ls_likp>-vstel = ls_itin-vstel.
    ENDIF.

* check for the zzpackflag being checked in case of div 13
    IF gs_nast-kappl = 'V7'.  "shipment
      IF gs_nast-nacha = '1'. " only printing
        IF gs_nast-manue <>  'X'. " not manually processed
          IF <ls_likp>-kunnr <> lv_kunnr.
            lv_kunnr = <ls_likp>-kunnr.
            IF <ls_likp>-spart = '13'.
              SELECT SINGLE zzpackflag
                   FROM knvv
                INTO lv_zzpackflag
                WHERE kunnr = <ls_likp>-kunnr AND
                      vkorg = <ls_likp>-vkorg AND
                      vtweg = <ls_likp>-vtweg AND
                      spart = <ls_likp>-spart.

              IF lv_zzpackflag <> 'X'.
                IF NOT <ls_likp>-tknum IS INITIAL .
                  DELETE et_likp WHERE tknum = <ls_likp>-tknum
                                 AND   kunnr = <ls_likp>-kunnr  .
                  CONTINUE.
                ELSE.
                  DELETE et_likp INDEX lv_tabix .
                  CONTINUE.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
* we need to check if it is a sto . That is based on the
* vgtyp . If vgtyp = 'v' then it is an STO
    CHECK <ls_likp>-vgtyp = 'V'.
* no sales order
    IF <ls_likp>-vbelv IS INITIAL.
* get the sales order
      CALL METHOD zcl_f01276_tally=>get_sales_order_sto
        EXPORTING
          iv_vgbel      = <ls_likp>-vgbel
          iv_vgpos      = <ls_likp>-vgpos
        IMPORTING
          ev_salesorder = <ls_likp>-vbelv.
    ENDIF.

    IF NOT <ls_likp>-vbelv IS INITIAL.
* get the sold to by passing sales order
      CALL METHOD zcl_f01276_tally=>get_sold_to_sto
        EXPORTING
          iv_sorder = <ls_likp>-vbelv
        IMPORTING
          ev_soldto = <ls_likp>-kunag.
    ENDIF.
  ENDLOOP.

  SORT et_likp BY vstel kunnr kunag tknum vbeln.

ENDMETHOD.


method GET_SOLD_TO_STO .

  select single kunnr
         from vbak
         into ev_soldto
         where vbeln = iv_sorder.
endmethod.


METHOD set_od_pair .

  FIELD-SYMBOLS <ls_likp> TYPE gs_likp.
  DATA : ls_soldto TYPE zf01276_odpair_str ,
         ls_vbeln TYPE  zvbeln_odpair_str,
         ls_parnr TYPE zparnr_od_pair_str,
         lt_zvbeln TYPE zvbeln_odpair_tab,
         lt_zparnr TYPE zparnr_od_pair_tab,
         ls_nast_parnr TYPE gs_nast_parnr,
          ls_knvk TYPE gs_knvk,
          ls_knvp TYPE gs_knvp,
          lt_likp TYPE gt_likp.

  lt_likp = it_likp.

  LOOP AT lt_likp ASSIGNING <ls_likp>.
* assigin the deliveries to deliveries table
    ls_vbeln-vbeln = <ls_likp>-vbeln.
    ls_vbeln-posnr = <ls_likp>-posnr.
    APPEND ls_vbeln TO lt_zvbeln.
    CLEAR ls_vbeln.

* email or fax
    IF gs_nast-nacha = '2' OR
       gs_nast-nacha = '5'.
* get the contact person details
* begin of change / nparchu
      IF gs_nast-kappl = 'V3'.
        LOOP AT it_nast_parnr INTO ls_nast_parnr.

          CALL METHOD zcl_f01276_tally=>get_cp_details
            EXPORTING
              is_likp       = <ls_likp>
              is_nast_parnr = ls_nast_parnr
            IMPORTING
              es_parnr      = ls_parnr.

          IF NOT ls_parnr IS INITIAL.
            APPEND ls_parnr TO lt_zparnr.
          ELSE.
            DELETE TABLE lt_likp FROM <ls_likp>.
          ENDIF.
        ENDLOOP.
      ELSE.

* end of change / nparchu
* get the contact person details
        LOOP AT it_nast_parnr INTO ls_nast_parnr
                                WHERE objky = <ls_likp>-vbeln .

          CALL METHOD zcl_f01276_tally=>get_cp_details
            EXPORTING
              is_likp       = <ls_likp>
              is_nast_parnr = ls_nast_parnr
            IMPORTING
              es_parnr      = ls_parnr.

          IF NOT ls_parnr IS INITIAL.
            APPEND ls_parnr TO lt_zparnr.
          ELSE.
            DELETE TABLE lt_likp FROM <ls_likp>.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.

* for each origin , shipto and sold to append a record
    AT END OF kunag .
      ls_soldto-tknum = <ls_likp>-tknum.
      ls_soldto-vstel = <ls_likp>-vstel.
      SORT lt_zvbeln BY vbeln posnr.
      DELETE ADJACENT DUPLICATES FROM lt_zvbeln COMPARING vbeln posnr.
      ls_soldto-vbeln = lt_zvbeln.
      ls_soldto-kunwe = <ls_likp>-kunnr.
      ls_soldto-kunag = <ls_likp>-kunag.
* assign partners
      IF lt_zparnr IS NOT INITIAL.
        SORT lt_zparnr BY parnr.
        DELETE ADJACENT DUPLICATES FROM lt_zparnr COMPARING parnr.
      ENDIF.
      ls_soldto-parnr = lt_zparnr.
      ls_soldto-vgtyp = <ls_likp>-vgtyp.
      APPEND ls_soldto TO et_soldto.
      CLEAR : ls_soldto.
      REFRESH : lt_zvbeln ,
                lt_zparnr.
    ENDAT.
  ENDLOOP.
ENDMETHOD.
ENDCLASS.

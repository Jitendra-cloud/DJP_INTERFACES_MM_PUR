*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_E3068TOP.                  " Global Data
  INCLUDE LZSD_DL_E3068UXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_E3068F...                  " Subprograms
* INCLUDE LZSD_DL_E3068O...                  " PBO-Modules
* INCLUDE LZSD_DL_E3068I...                  " PAI-Modules

************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**           COPYRIGHT (C) 2016 by INTERNATIONAL PAPER                **
**                     ALL RIGHTS RESERVED                            **
**             REVISIONS COPYRIGHT (C) 2008, 20nn                     **
**                    by INTERNATIONAL PAPER                          **
*______________________________________________________________________*
* Report Name      : ZDLE10681_BATCH_SPLIT       Date   : 12/20/2015   *
* Programmer       : Prabu Ragupathi                                   *
*______________________________________________________________________*
* Description :                                                        *
*If there are more than 255 split batch lines created or updated at one*
*time in ERP then this will cause failures in APO. The creation or     *
*update sends the split batch lines to APO via CIF queues. When the CIF*
*queues are processed in APO and there are more than 255 split batch   *
* lines, the CIF queues fail because liveCache cannot handle changing  *
*that many at one time.
*There was a customer message created for SAP and they are unwilling to*
*fix this problem. Their solution is for us not to create deliveries   *
*with more than 255 split batch lines. This is not a viable solution.  *
*There is a work around, the SAP Integration team saves off the CIF    *
*queues and then runs a tool (CCR) to fix the corresponding delivery   *
*lines in APO. This is cumbersome and time consuming.                  *
*After debugging the queues, it looks like that ERP is sending more    *
*split batch lines than is needed. In the CIF queues, the last split   *
*batch line contains the necessary information and only it needs to be *
*sent to APO. So we would like to change the code so only the header   *
*item lines and the last split batch line for each header item line    *
*are sent to ERP.                                                      *

*EXIT_SAPLMEAP_001=>ZXCIFU14=>ZDLE10681_BATCH_SPLIT                    *
*______________________________________________________________________*
* Change History:                                                      *
*   Programmer       Date     Req. #            Action                 *
* ===============  ========  ========== ===============================*
* Prabu Ragupathi  12/20/15   E0VK9A0HV6 Initial creation              *
*______________________________________________________________________*
 DATA: lv_field(50)      TYPE c,
        lt_xekbe_one_item TYPE me_ekbe,
        lv_exit,
        lt_ekbev_one_item TYPE me_ekbev.        "shipment PGI

   FIELD-SYMBOLS:  <lt_xekbe>      TYPE me_ekbe,
                  <ls_xekbe>      TYPE ekbe,
                  <ls_xekbe_last> TYPE ekbe,

                  <lt_ekbev>      TYPE me_ekbev,  "shipment PGI
                  <ls_ekbev_last> TYPE ekbev.     "shipment PGI

  STATICS : lv_rec_count      TYPE i,
            lv_curr_rec_count TYPE i.

****************************** Begin of Delivery confirm Picking/PGI  Process ********************************
"Assign the structure of the current record from XEKBE in program SAPLEINU
  lv_field = '(SAPLEINU)XEKBE'.
  ASSIGN (lv_field) TO <ls_xekbe>.

  "Assign the internal table which has all the batch split records
  lv_field = '(SAPLEINU)XEKBE[]'.
  ASSIGN (lv_field) TO <lt_xekbe>.


  IF <ls_xekbe> IS ASSIGNED.
    "Header record always needs to be passed to the CIF
    "gjahr has the batch split line items
    IF <ls_xekbe>-gjahr = '0000'.
      lv_exit = abap_true.
    ENDIF.
  ELSE.
    lv_exit = abap_true.
  ENDIF.


  IF lv_exit IS INITIAL.
    IF <lt_xekbe> IS ASSIGNED .
      "Get all the records for the current purchase order and line item
      lt_xekbe_one_item = <lt_xekbe>.
      "Get the last batch split item record for the current po number and line item
      DELETE lt_xekbe_one_item  WHERE ebeln = <ls_xekbe>-ebeln  AND  ebelp <> <ls_xekbe>-ebelp.
      DELETE lt_xekbe_one_item  WHERE ebeln <> <ls_xekbe>-ebeln  AND  ebelp <> <ls_xekbe>-ebelp.
      "Need this for Insert/Delete - read the last record
      SORT lt_xekbe_one_item BY zekkn DESCENDING vgabe DESCENDING gjahr DESCENDING belnr DESCENDING buzei DESCENDING.
      READ TABLE lt_xekbe_one_item ASSIGNING <ls_xekbe_last> INDEX 1.
    ENDIF.

    "For Batch split insert/Delete process the last record only if the elikz indicator is 'I' or 'D'
    IF ( <ls_xekbe>-elikz = 'I' OR <ls_xekbe>-elikz = 'D' )  AND <ls_xekbe>-buzei = <ls_xekbe_last>-buzei .
      lv_exit = abap_true.
    ENDIF.
  ENDIF.


  IF lv_exit IS INITIAL.
    CLEAR : it_input[], it_output[],it_inputx[],it_outputx[],it_input_cus[],it_output_cus[].
  ENDIF.

****************************** End of Delivery confirm Picking/PGI  Process ********************************


******************************Begin Shipment PGI Process ********************************
*  "Assign the structure of the current record from XEKBE in program SAPLEINU
  UNASSIGN <ls_xekbe>.
  lv_field = '(SAPLEINU)EKBE'.
  ASSIGN (lv_field) TO <ls_xekbe>.

*  "Assign the internal table which has all the batch split records
  lv_field = '(SAPLEINU)TEKBE[]'.
  ASSIGN (lv_field) TO <lt_ekbev>.
  IF lv_rec_count IS INITIAL AND <lt_ekbev> IS ASSIGNED .
    lv_rec_count  = lines( <lt_ekbev> ).
  ENDIF.
  lv_curr_rec_count = lv_curr_rec_count + 1.
*
****if current record is the last record in the table
  IF <ls_xekbe> IS ASSIGNED and <lt_ekbev> is ASSIGNED  .
    IF lv_rec_count <= lv_curr_rec_count.
    ELSE.
      CLEAR : it_input[], it_output[],it_inputx[],it_outputx[],it_input_cus[],it_output_cus[].
    ENDIF.
  ENDIF.


****************************** End Shipment PGI Process ********************************

FUNCTION z_dl_e03126_unit_id_check.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_ONLY_GEN_UNIQUE_NO) TYPE  CHAR1 OPTIONAL
*"     VALUE(IV_GEN_UNIQUE_ID_TAB) TYPE  CHAR1 OPTIONAL
*"  TABLES
*"      IT_BATCH STRUCTURE  ZDL_UNIQUEID
*"  EXCEPTIONS
*"      NUMBER_RANGE_NOT_FOUND
*"----------------------------------------------------------------------
************************************************************************
*                                                                      *
*             C O M P A N Y   C O N F I D E N T I A L                  *
*                                                                      *
*                    COPYRIGHT (C) 2005 by                             *
*                     INTERNATIONAL PAPER                              *
*                                                                      *
*        This program is the property of International Paper.          *
*        Care should be taken to prevent its unauthorized use.         *
*                                                                      *
* Function Module: Z_SD_DL_I1375_DETERMINE_ACTION                      *
*                                                                      *
* Description : This Function module validates the Unit-id/Batch and   *
* field length to make sure that the Unit-id/Batch does not already    *
* exist.if initial validation fails a new unique ID would be generated *
* and the unique id would be for furthur posting.                      *
*----------------------------------------------------------------------*
*                                                                      *
*                                                                      *
*  Change History:                                                     *
*     Programmer       Date        Action                              *
* ================== ========  ==============================          *
* Subba R Boyalla    10/25/05  Initial development                     *
*                                                                      *
* Subba R Boyalla    03/27/06  The unique id generation has been       *
*                              modified,The Funtion module would       *
*                              generate an unique id for all materials *
*                              passed to the FM.                       *
*                                                                      *
* Bruce C Ballehr    05/03/07  EDEK907890  / BCB01                     *
*                              For U01267 Create Container HU, we need *
*                              a new HU number for the Container HU.   *
*                              Sub-HU's will be packed into the        *
*                              Container HU. The Container HU will be  *
*                              like an empty shell (ie: no material,   *
*                              no batch, etc). So, we need a way to    *
*                              ONLY generate the next unique number.   *
*                              This change will add an optional parm   *
*                              to achieve this functionality.          *
*                                                                      *
* Bruce C Ballehr    04/22/08  EDVK962009  / BCB02 / CR7631            *
*                                                                      *
*                              We had an issue where we though we had  *
*                              a duplicate Vendor Batch but the        *
*                              business did not think so since they    *
*                              had a unique BOL on the Manual ASN      *
*                              screen. We enhanced this code to pass   *
*                              in the BOL on the table that's passed   *
*                              in when called from the Vendor ASN      *
*                              (LZSD_DL_VENASNF02) and EDI ASN         *
*                              (LZSD_DL_VENASNF01). This validation is *
*                              now similary, using the BOL, to func    *
*                              Z_SD_DL_I2301_CHECK_DUPLI_ASN           *
*                                                                      *
*                              NOTE: This logic is similar to logic in *
*                                    function module                   *
*                                    Z_SD_DL_I2301_CHECK_DUPLI_ASN so  *
*                                    if changes are made to this logic *
*                                    here then similar changes might   *
*                                    be needed in that function as     *
*                                    well.                             *
*                                                                      *
* Bruce C Ballehr    06/25/08  EDVK963930  / BCB03 / CR7631/ TPR01398  *
*                                                                      *
*                         R12  Expand table structure to allow a       *
*                              calling program to pass in a PO. If a   *
*                              PO was passed in, use this as part of   *
*                              the Duplicate check. This was supposed  *
*                              to be part of CR7631 but was not added  *
*                              for some reason.                        *
*                                                                      *
* Bruce C Ballehr    08/13/08  EDVK963930  / BCB04 / CR7632            *
*                                                                      *
*                         R12  As part of the R12 changes for          *
*                              enhancing the Manual & EDI ASN for      *
*                              Sheets and Skids, we need to allow the  *
*                              Vendor Batch to be used (instead of     *
*                              creating a new one) in CERTAIN          *
*                              circumstances. Here is a brief descript *
*                              of the logic:                           *
*                                                                      *
*                              IF Batch Managed                        *
*                                IF Vendor Batch is not a Duplicate    *
*                                  IF Vendor Batch Number = 10 bytes   *
*                                    IF first 2 bytes of Vendor Batch  *
*                                    found in ZDL_UNI_EQIP_ID          *
*                                      IF a Vendor Number was passed   *
*                                      in on new field LIFNR (new to   *
*                                      struct ZDL_UNIQUEID)            *
*                                        IF a Matching Record was      *
*                                        found on table ZDL_FIELDS     *
*                                          USE the Vendor Batch Number *
*                                          passed in instead of        *
*                                          generating a new Vendor     *
*                                          Batch Number                *
*                                                                      *
*                              A handful of programs call this funct   *
*                              module but we ONLY want this logic to   *
*                              processed for EDI ASN Idoc code and     *
*                              Manual ASN Idoc code (LZSD_DL_VENASNF01 *
*                              and LZSD_DL_VENASNF02 respectively).    *
*                              At this time, these two programs will   *
*                              be the only ones to populate the LIFNR  *
*                              field passed in on the TABLES parm.     *
*                                                                      *
*                              ZDL_FIELDS will have entries for        *
*                              certain Vendors.  Here is an example on *
*                              what a entry will look like in table    *
*                              ZDL_FIELDS:                             *
*                                                                      *
*                              Field Name    Value                     *
*                              ----------    -----
*                              CATEGORY      E03261_BATCH              *
*                              FIELDNAME     T4 (1st 2 bytes of VB)    *
*                              SIGN          I (for Include)           *
*                              OPTN          EQ                        *
*                              LOWVAL        IP0500010 (vendor)        *
*                              HIGHVAL       blank                     *
*                                                                      *
*                                                                      *
* Bruce C Ballehr    09/25/08  E0VK943820  / BCB05                     *
*                                                                      *
*                         R12  Fix for E03382 Return Deliveries.       *
*                              ZSD_DL_E03382_RET_DELIV_HUS now calls   *
*                              this Function with IMPORT parm          *
*                              IV_GEN_UNIQUE_ID_TAB = 'X' so that we   *
*                              only retrieve a new ZZ<batch> number    *
*                              for each entry of TABLES IT_BATCH into  *
*                              field IT_BATCH-BATCH_NUM. The duplicate *
*                              checks are bypassed since               *
*                              ZSD_DL_E03382_RET_DELIV_HUS only passes *
*                              in field IT_BATCH-MATNR. The Dup check  *
*                              was processing extremely long since     *
*                              they don't pass in a BOL or PO          *
************************************************************************
*-----------Constants Declaration  ------------------------------------*
  CONSTANTS:
    c_flag(1) TYPE c VALUE 'X',          " general flag
    c_ten     TYPE i VALUE  10.          " ten digit

*-----------Types declaration------------------------------------------*
* Types for Material and Batch indicator
  TYPES: BEGIN OF ty_mara,
           matnr TYPE matnr,                 " Material Number
           xchpf TYPE xchpf,                 " Batch Indicator flag
         END OF ty_mara.

* Types for Materil and Batch Number
  TYPES: BEGIN OF ty_mch1,
           matnr TYPE matnr,                 " Material Number
           charg TYPE charg_d,               " Batch Number
           licha TYPE lichn,
         END OF ty_mch1.

* Types for Materil and Batch Number
  TYPES: BEGIN OF ty_mch11,
           matnr TYPE matnr,                 " Material Number
           licha TYPE lichn,
         END OF ty_mch11.

* Types for External handling unit number
  TYPES: BEGIN OF ty_vekp,
           exidv TYPE exidv,                 " External Unit-id
         END OF ty_vekp.

* Types for Unique Batch id
  TYPES: BEGIN OF ty_zdl_uni_eqip_id,
           unique_id TYPE zuniqid,           " IP Batch/Unit-id
         END OF ty_zdl_uni_eqip_id.

*-----------Variables Declaration--------------------------------------*
  DATA: ws_id        TYPE zcharg_d,             " IP Batch/Unit-id
        ws_strlen    TYPE i,                    " String length
        ws_uniqueid  TYPE char2,                " 2 Digit IP batch id's
        ws_batch_num TYPE zcharg_d,             " Batch Number
        ws_batch     TYPE charg_d.              " Batch Number


*-----------Internal Table Declaration---------------------------------*
*      Internal table to store material and batch indicator
  DATA: int_mara            TYPE HASHED TABLE OF ty_mara WITH UNIQUE KEY matnr
                                                INITIAL SIZE 0,
*      Internal table to store Material and Batch number
        int_mch1            TYPE STANDARD TABLE OF ty_mch1 INITIAL SIZE 0,

*      Internal table to store Material and Batch number
        int_mch11           TYPE STANDARD TABLE OF ty_mch11 INITIAL SIZE 0,

*      Internal table to store External Unit-id
        int_vekp            TYPE STANDARD TABLE OF ty_vekp INITIAL SIZE 0,

*      Internal table to store unique equipment id
        int_zdl_uni_eqip_id TYPE STANDARD TABLE OF ty_zdl_uni_eqip_id
                                                INITIAL SIZE 0.

*-----------Work Area Declaration--------------------------------------*
  DATA: wa_vekp  TYPE ty_vekp,                   " Work area for INT_VEKP
        wa_mara  TYPE ty_mara,                   " Work area for INT_MARA
        wa_mch1  TYPE ty_mch1,                   " Work area for INT_mch1
        wa_mch11 TYPE ty_mch11,                   " Work area for INT_mch1
        wa_unid  TYPE ty_zdl_uni_eqip_id,        " Work area for INT_UNID
        wa_zdlid TYPE zdl_gen_unit_id.          " Work area for INT_ZDLID

* Begin BCB04
  DATA:
      lv_use_vb TYPE  boolean. "indicates whether to use the Vend Batch
* End BCB04

  "Added for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
  CONSTANTS: lc_cat TYPE zdl_fields-category VALUE 'I2301'.

* Clear all variables
  CLEAR: ws_id,
         ws_strlen,
         ws_uniqueid,
         ws_batch_num,
         ws_batch.
* Clear all work areas
  CLEAR: wa_vekp,
         wa_mara,
         wa_mch1,
         wa_unid,
         wa_zdlid.
* Clear all internal table work areas
  CLEAR: it_batch,
         int_zdl_uni_eqip_id,
         int_vekp,
         int_mch1,
         int_mara.

* Refresh all internal tables
  REFRESH: int_zdl_uni_eqip_id,
           int_vekp,
           int_mch1,
           int_mara.

*--> Begin BCB01
* Only generate the next unique number to be used when creating a
* Container HU. If this parm is space, perform normal validation
* on the table passed.
*  IF iv_only_gen_unique_no IS INITIAL.     "BCB05
  IF iv_only_gen_unique_no IS INITIAL AND   "BCB05
     iv_gen_unique_id_tab  IS INITIAL.      "BCB05

*--> End BCB01

*   Select Material and Batch Indicator from Material Master(MARA).
    IF NOT it_batch[] IS INITIAL.
      SELECT matnr                              " Materil Number
             xchpf                              " Batch Indicator
        FROM mara                               " General Material Data
        INTO TABLE int_mara
        FOR ALL ENTRIES IN it_batch
        WHERE matnr = it_batch-matnr.
      IF sy-subrc = 0.
*     sy-subrc not required to check
      ENDIF.

*     populate internal table to adjust field size
      LOOP AT it_batch.
        wa_mch11-matnr = it_batch-matnr.
        IF it_batch-batch_num IS INITIAL.
          wa_mch11-licha = it_batch-exidv.
        ELSE.
          wa_mch11-licha = it_batch-batch_num.
        ENDIF.
        APPEND wa_mch11 TO int_mch11.
        CLEAR wa_mch11.
      ENDLOOP.

*     Select Material and Batch number from Batches(mch1)
      SELECT matnr                              " Material Number
             charg                              " Batch Number
             licha                              " Vendor Batch Number
        FROM mch1                               " Batches
        INTO TABLE int_mch1
        FOR ALL ENTRIES IN int_mch11
        WHERE matnr = int_mch11-matnr
          AND lvorm <> c_flag
          AND licha = int_mch11-licha.
      IF sy-subrc = 0.
*       sy-subrc not required to check
      ENDIF.
*     Select External Handling unit number from Handling Unit - Header
*     Table(VEKP)
      SELECT exidv
      " External handling unit number
        FROM vekp
        " Handling Unit - Header Table
        INTO TABLE int_vekp
        FOR ALL ENTRIES IN it_batch
        WHERE exidv = it_batch-exidv.
    ENDIF.

*   Select Unique ID from 2 digit Unique Code for IP
*   Equipment(zdl_uni_eqip_id)
    SELECT unique_id                            " Unique ID
      FROM zdl_uni_eqip_id
      " 2 digit Unique Code for IP Equipment
      INTO TABLE int_zdl_uni_eqip_id.

*   Select Unique IP Batch number from Table to store the Generated
*   Batch Numbers(zdl_gen_unit_id)
    SELECT SINGLE batch_num                     " Batch Number
             FROM zdl_gen_unit_id
             " Table to store the Generated Batch Numbers
             INTO ws_batch_num.
*   Store originalbatch number in a variable
    ws_batch = ws_batch_num.

*   Sort INT_mch1 by Material Number and Batch Number
    SORT: int_mch1 BY matnr licha,
          int_vekp BY exidv.

*   Begin BCB02
*   Retrieve Delivery information by BOL (if exists)
    PERFORM get_dup_info USING it_batch[].
*   End BCB02

*   Looping through internal table IT_BATCH to read Material and
*   batch/Unit-id number.
    LOOP AT it_batch.

*     Begin BCB02
*     Determine if Vendor Batch and Material already exist on a
*     Delivery with the same BOL.
      PERFORM check_dup USING it_batch.
*     End BCB02

*     Read table INT_MARA to get material number
      READ TABLE int_mara INTO wa_mara WITH KEY matnr = it_batch-matnr.
*     Start of change 03/27/2006
      IF sy-subrc = 0 AND NOT it_batch-exidv IS INITIAL.
*     End of change 03/27/2006
*       Check for Batch indicator,if the flag is set the material is
*       batch managed
        IF wa_mara-xchpf = c_flag.
*         Read table INT_mch1 to check the materil and batch is
*         maintained by IP
          READ TABLE int_mch1 INTO wa_mch1
            WITH KEY matnr = it_batch-matnr
                     licha = it_batch-exidv+0(15)
            BINARY SEARCH.
          IF sy-subrc = 0.

*           if the IP standard batch is exist,then the same batch number
*           would be updated. check vendor batch number is not initial,
*           if the IP standard batch number exist.
*            IF wa_mch1-charg IS NOT INITIAL.  "BCB02
            IF wa_mch1-charg IS NOT INITIAL AND gv_dup = gc_true."BCB02
              it_batch-batch_num      = wa_mch1-charg.
              it_batch-old_batch_flag = c_flag.
              MODIFY it_batch TRANSPORTING batch_num old_batch_flag.
              CLEAR it_batch.
              CONTINUE.
            ENDIF.

*           if the materil and batch is found create new unique unit-id
*           and continue process
            PERFORM generate_unit_id USING    ws_batch_num
            " batch number
                                     CHANGING ws_id.
            " unique unit-id
            it_batch-batch_num = ws_id.
            ws_batch_num       = ws_id.
            MODIFY it_batch TRANSPORTING batch_num.
            CLEAR: ws_id,
                   it_batch.
            CONTINUE.
            " Continue with next record
          ENDIF.

*         check the Batch length,whether the batch length is more/less
*         then standard batch number
          IF NOT it_batch-exidv IS INITIAL.
            ws_strlen = strlen( it_batch-exidv ).
            IF ws_strlen <> c_ten.
              PERFORM generate_unit_id USING ws_batch_num
              " batch number
                                    CHANGING ws_id.
              " unique unit-id
              it_batch-batch_num = ws_id.
              ws_batch_num       = ws_id.
              MODIFY it_batch TRANSPORTING batch_num.
              CLEAR: ws_id,
                     it_batch.
              CONTINUE.
              " Continue with next record
            ENDIF.
            IF ws_strlen = c_ten.
              ws_uniqueid = it_batch-exidv+0(2).
*---Start of changes for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
              SELECT COUNT( * ) FROM zdl_fields
                WHERE category = lc_cat
                AND lowval = it_batch-lifnr.
              IF sy-subrc = 0.
                SELECT SINGLE land1 FROM lfa1
                  INTO @DATA(lv_land)
                  WHERE lifnr = @it_batch-lifnr.
                IF sy-subrc = 0.
                  ws_uniqueid = lv_land.
                ENDIF.
              ENDIF.
*---End of changes for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
*             Read table INT_ZDL_UNI_EQIP_ID to check unique equipment
*             code
              READ TABLE int_zdl_uni_eqip_id INTO wa_unid
                WITH KEY unique_id = ws_uniqueid.
              IF sy-subrc = 0.
*               Begin BCB04
*               If a Vendor was passed in then determine whether we
*               should use the 10-byte, non dup vendor batch by
*               inspecting table ZDL_FIELDS.
                lv_use_vb = gc_false.
                IF it_batch-lifnr IS NOT INITIAL.
                  PERFORM determine_whether_to_use_vb
                    USING    ws_uniqueid    "1st two bytes of vend batch
                             it_batch-lifnr "vendor
                    CHANGING lv_use_vb.  "flag to tell whether to use vb
                ENDIF.
                IF lv_use_vb = gc_false.
*                 Do not use the Vendor Batch passed in
*               End BCB04
                  PERFORM generate_unit_id USING ws_batch_num
                  " batch number
                                        CHANGING ws_id.
                  " unique unit-id
                  it_batch-batch_num = ws_id.
                  ws_batch_num       = ws_id.
                  MODIFY it_batch  TRANSPORTING batch_num.
                  CLEAR: ws_id,
                         it_batch,
                         ws_uniqueid.
                  CONTINUE.
                  " Continue with next record
*               Begin BCB04
                ELSE.
*                 Use the Vendor Batch passed in
                  it_batch-batch_num      = it_batch-exidv. "vend batch
*                  it_batch-old_batch_flag = c_flag. "ind to use old vb
                  MODIFY it_batch TRANSPORTING batch_num old_batch_flag.
                  CLEAR it_batch.
                  CONTINUE.
                ENDIF.
*               End BCB04
              ELSE.
*               03/15/06 - Start of change
                MOVE it_batch-exidv TO it_batch-batch_num.
                MODIFY it_batch TRANSPORTING batch_num.
                CLEAR it_batch.
                CONTINUE.
*               03/15/06 - End of changed
              ENDIF.
            ENDIF.
*           read table INT_VEKP to check the batch/unit-id
            READ TABLE int_vekp INTO wa_vekp
              WITH KEY exidv = it_batch-exidv
              BINARY SEARCH.
*           if the batch is found generate new unique unit-id
            IF sy-subrc <> 0.
              " 03/15/06 changed to <>
              PERFORM generate_unit_id USING ws_batch_num
              " batch number
                                    CHANGING ws_id.
              " unique unit-id
              it_batch-batch_num = ws_id.
              ws_batch_num       = ws_id.
              MODIFY it_batch TRANSPORTING batch_num.
              CLEAR: ws_id,
                     it_batch.
              CONTINUE.
              " Continue with next record
            ENDIF.
            it_batch-batch_num = it_batch-exidv.
            MODIFY it_batch  TRANSPORTING batch_num.
          ENDIF.
        ELSE.                      "if the material is not batch managed
*         get Unit-id length
          ws_strlen = strlen( it_batch-exidv ).
          IF ws_strlen = c_ten.
            ws_uniqueid = it_batch-exidv+0(2).
*---Start of changes for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
            SELECT COUNT( * ) FROM zdl_fields
              WHERE category = lc_cat
              AND lowval = it_batch-lifnr.
            IF sy-subrc = 0.
              SELECT SINGLE land1 FROM lfa1
                INTO @lv_land
                WHERE lifnr = @it_batch-lifnr.
              IF sy-subrc = 0.
                ws_uniqueid = lv_land.
              ENDIF.
            ENDIF.
*---End of changes for S 2000003223: Manual ASN COO Update by VKAKI3 TR#S0VK915188
*           Read table INT_ZDL_UNI_EQIP_ID to get unique quipment id
            READ TABLE int_zdl_uni_eqip_id INTO wa_unid WITH KEY
            unique_id = ws_uniqueid.
            IF sy-subrc = 0.
              " 03/15/06 changed to <>
              PERFORM generate_unit_id USING ws_batch_num
              " batch number
                                    CHANGING ws_id.
              " unique unit-id
              it_batch-batch_num = ws_id.
              ws_batch_num       = ws_id.
              MODIFY it_batch  TRANSPORTING batch_num.
              CLEAR: ws_id,
                     it_batch,
                     ws_uniqueid.
              CONTINUE.
              " Continue with next record
            ELSE.
*             03/15/06 start of change
              MOVE it_batch-exidv TO it_batch-batch_num.
              MODIFY it_batch TRANSPORTING batch_num.
              CLEAR it_batch.
              CONTINUE.
*             03/15/06 end of change
            ENDIF.
          ENDIF.
*         Read table INT_VEKP to check the batch/unit-id
          READ TABLE int_vekp INTO wa_vekp
            WITH KEY exidv = it_batch-exidv
            BINARY SEARCH.
*         if the batch is found generate new unique unit-id
          IF sy-subrc <> 0.
            " 03/15/06 changed to <>
            PERFORM generate_unit_id USING ws_batch_num
            " batch number
                                  CHANGING ws_id.
            " unique unit-id
            it_batch-batch_num = ws_id.
            ws_batch_num       = ws_id.
            MODIFY it_batch TRANSPORTING batch_num.
            CLEAR: ws_id,
                   it_batch.
            CONTINUE.
            " Continue with next record
          ENDIF.
          it_batch-batch_num = it_batch-exidv.
          MODIFY it_batch  TRANSPORTING batch_num.
        ENDIF.
*     Start of Change 03/27/2006
      ELSEIF sy-subrc = 0.
        PERFORM generate_unit_id USING ws_batch_num   " batch number
                              CHANGING ws_id.
        " unique unit-id
        it_batch-batch_num = ws_id.
        ws_batch_num       = ws_id.
        MODIFY it_batch TRANSPORTING batch_num.
        CLEAR: ws_id,
               it_batch.
        CONTINUE.
        " Continue with next record
*    End of change 03/27/2006
      ENDIF.
      CLEAR it_batch.
    ENDLOOP.

*--> Begin BCB01
* Only generate the next unique number to be used when creating a
* Container HU if this parm is 'X'
*  ELSE.  "BCB05
  ELSEIF iv_only_gen_unique_no = 'X'."Retrieve new ZZ Container HU BCB05

*   Retrieve the lone record in table ZDL_GEN_UNIT_ID. The batch number
*   will be used to lock the table for update later.
    SELECT SINGLE batch_num    " Batch Number / HU Number
      FROM zdl_gen_unit_id
      INTO ws_batch_num.
*   Store originalbatch number in a variable
    ws_batch = ws_batch_num.

*   Generate the next unique number to be used for the Container HU
    PERFORM generate_unit_id USING ws_batch_num         " batch number
                           CHANGING ws_id.

*   Set table/field for table locking
    it_batch-batch_num = ws_batch. "current value in ZDL_GEN_UNIT_ID

*   Set variable with new unique HU/Batch number
    ws_batch_num = ws_id.

*   Format new Container HU number into HU field of 1st record of
*   function module table it_batch.
    CLEAR it_batch.
    it_batch-exidv = ws_id.
    INSERT it_batch INDEX 1.
*--> End BCB01

* Begin BCB05
  ELSEIF iv_gen_unique_id_tab = 'X'.

*   Retrieve the lone record in table ZDL_GEN_UNIT_ID. The batch number
*   will be used to lock the table for update later.
    SELECT SINGLE batch_num    " Batch Number / HU Number
      FROM zdl_gen_unit_id
      INTO ws_batch_num.
*   Store originalbatch number in a variable
    ws_batch = ws_batch_num.

    LOOP AT it_batch.

*     Generate the next unique number to be used for the Container HU
      PERFORM generate_unit_id USING ws_batch_num       " batch number
                             CHANGING ws_id.

**     Set table/field for table locking
*      it_batch-batch_num = ws_batch. "current value in ZDL_GEN_UNIT_ID

*     Set variable with new unique HU/Batch number
      ws_batch_num = ws_id.

*     Format new Container HU number into HU field of 1st record of
*     function module table it_batch.
      CLEAR it_batch.
      it_batch-batch_num = ws_id.
      MODIFY it_batch TRANSPORTING batch_num.

    ENDLOOP.

*   Set table/field for table locking
    it_batch-batch_num = ws_batch. "current value in ZDL_GEN_UNIT_ID


  ENDIF.
* End BCB05


* Call Function 'ENQUEUE_EZZDL_GEN_UNIT_I' to lock the table
* zdl_gen_unit_id,
* refresh tables and update with the new entry
* Try to lock table for 5 times
  IF ws_batch <> ws_batch_num.
    DO 5 TIMES.
      CALL FUNCTION 'ENQUEUE_EZZDL_GEN_UNIT_I'
        EXPORTING
          mode_zdl_gen_unit_id = 'S'
          client               = sy-mandt
          batch_num            = it_batch-batch_num
          x_batch_num          = ' '
          _scope               = '2'
          _wait                = ' '
          _collect             = ' '
        EXCEPTIONS
          foreign_lock         = 1
          system_failure       = 2
          OTHERS               = 3.
      IF sy-subrc = 0.
        wa_zdlid-client    = sy-mandt.
        " Client id
        wa_zdlid-batch_num = ws_batch_num.
        " Batch Number
*       refresh table to store a new batch number
        DELETE FROM zdl_gen_unit_id.
*       Append new batch number to the table ZDL_GEN_UNIT_ID
        INSERT zdl_gen_unit_id FROM wa_zdlid.
*       Release the lock for table zdl_gen_unit_id
        CALL FUNCTION 'DEQUEUE_EZZDL_GEN_UNIT_I'
          EXPORTING
            mode_zdl_gen_unit_id = 'S'
            client               = sy-mandt
            batch_num            = it_batch-batch_num
            x_batch_num          = ' '
            _scope               = '3'
            _synchron            = ' '
            _collect             = ' '.
*       Exit from the locking process
        EXIT.
      ENDIF.
*     if the table is locked by conqurent user, wait for 5 seconds and
*     try to lock again
      WAIT UP TO 5 SECONDS.
    ENDDO.
  ENDIF.
ENDFUNCTION.

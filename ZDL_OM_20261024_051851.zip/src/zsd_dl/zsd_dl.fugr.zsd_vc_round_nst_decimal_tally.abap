FUNCTION ZSD_VC_ROUND_NST_DECIMAL_TALLY.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(I_FLOATING_POINT_VALUE) LIKE  CUOV_01-ATFLV OPTIONAL
*"     VALUE(I_DECIMAL_VALUE) TYPE  ZCFAC OPTIONAL
*"     VALUE(I_DECIMAL_PLACES_TO_ROUND_TO) TYPE  NUM1 DEFAULT 5
*"  EXPORTING
*"     VALUE(E_FLOATING_POINT_VALUE) LIKE  CUOV_01-ATFLV
*"     VALUE(E_DECIMAL_VALUE) TYPE  ZCFAC_TALLY
*"  EXCEPTIONS
*"      NO_INPUT
*"----------------------------------------------------------------------


************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
************************************************************************
* Function Name : ZSD_VC_ROUND_NEAREST_DECIMAL    Create Date: 06/27/06
*
* Function Group: ZSD_OM_VC_FUNCTIONS
*
* Programmer    : Mark M Tomazin                  Last Update:
*
* Technical Spec: E3507
************************************************************************

*eject.

************************************************************************
**Change History:
*   Description:                           EDVK        User     Date:
*
*     1) Function Module Creation          EDEK905832  MTOMAZI  06/27/06
*
************************************************************************


************************************************************************
* Description :  This is a General Purpose VC Function Module that
*                rounds the value passed to a pre-determined or a
*                passed in decimal point value.
*
************************************************************************

*eject.

  DATA: l_rounded_value_0_dec_pts_pd   TYPE p DECIMALS 0.

  DATA: l_rounded_value_1_dec_pts_pd   TYPE p DECIMALS 1.
  DATA: l_rounded_value_2_dec_pts_pd   TYPE p DECIMALS 2.

  DATA: l_rounded_value_3_dec_pts_pd   TYPE p DECIMALS 3.
  DATA: l_rounded_value_4_dec_pts_pd   TYPE p DECIMALS 4.

  DATA: l_rounded_value_5_dec_pts_pd   TYPE p DECIMALS 5.
  DATA: l_rounded_value_6_dec_pts_pd   TYPE p DECIMALS 6.

  DATA: l_rounded_value_7_dec_pts_pd   TYPE p DECIMALS 7.
  DATA: l_rounded_value_8_dec_pts_pd   TYPE p DECIMALS 8.
  DATA: l_rounded_value_9_dec_pts_pd   TYPE p DECIMALS 9.


************************************************************************
* Ensure we have Input
************************************************************************
  IF i_floating_point_value IS INITIAL AND
     i_decimal_value        IS INITIAL.

    RAISE no_input.

  ENDIF.

*eject.

  CASE i_decimal_places_to_round_to.

    WHEN 0.
      l_rounded_value_0_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_0_dec_pts_pd.
      e_decimal_value              = l_rounded_value_0_dec_pts_pd.

    WHEN 1.
      l_rounded_value_1_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_1_dec_pts_pd.
      e_decimal_value              = l_rounded_value_1_dec_pts_pd.

    WHEN 2.
      l_rounded_value_2_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_2_dec_pts_pd.
      e_decimal_value              = l_rounded_value_2_dec_pts_pd.

    WHEN 3.
      l_rounded_value_3_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_3_dec_pts_pd.
      e_decimal_value              = l_rounded_value_3_dec_pts_pd.

    WHEN 4.
      l_rounded_value_4_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_4_dec_pts_pd.
      e_decimal_value              = l_rounded_value_4_dec_pts_pd.

    WHEN 5.
      l_rounded_value_5_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_5_dec_pts_pd.
      e_decimal_value              = l_rounded_value_5_dec_pts_pd.

   WHEN OTHERS.
      l_rounded_value_5_dec_pts_pd = i_floating_point_value.
      e_floating_point_value       = l_rounded_value_5_dec_pts_pd.
      e_decimal_value              = l_rounded_value_5_dec_pts_pd.

*    WHEN 6.
*      l_rounded_value_6_dec_pts_pd = i_floating_point_value.
*      e_floating_point_value       = l_rounded_value_6_dec_pts_pd.
*      e_decimal_value              = l_rounded_value_6_dec_pts_pd.
*
*    WHEN 7.
*      l_rounded_value_7_dec_pts_pd = i_floating_point_value.
*      e_floating_point_value       = l_rounded_value_7_dec_pts_pd.
*      e_decimal_value              = l_rounded_value_7_dec_pts_pd.
*
*    WHEN 8.
*      l_rounded_value_8_dec_pts_pd = i_floating_point_value.
*      e_floating_point_value       = l_rounded_value_8_dec_pts_pd.
*      e_decimal_value              = l_rounded_value_8_dec_pts_pd.
*
*    WHEN 9.
*      l_rounded_value_9_dec_pts_pd = i_floating_point_value.
*      e_floating_point_value       = l_rounded_value_9_dec_pts_pd.
*      e_decimal_value              = l_rounded_value_9_dec_pts_pd.

  ENDCASE.


ENDFUNCTION.

*eject.

*End-of-Function
*End-of-Function
*End-of-Function

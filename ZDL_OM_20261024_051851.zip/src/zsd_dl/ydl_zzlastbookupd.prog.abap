************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2014 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: Y Program To Update Table                              *
*                                                                      *
* SAP Name    : YDL_ZZLASTBOOKUPD                Create Date: 11/17/14 *
*                                                                      *
* Programmer  : Amit Maole                       Last Update: 01/05/15 *
*                                                                      *
* Transaction : YDL_ZZLASTBOOKUPD                                      *
*______________________________________________________________________*
* Description :                                                        *
* Program to Update Field - Last booking change (VTTK-ZZLASTBOOKUPD)   *
* with time stamp information                                          *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* Amit Maole          11/17/14                                         *
*                                                                      *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
REPORT ydl_zzlastbookupd MESSAGE-ID zdl_utilities.


DATA:
gt_xvttk LIKE vttkvb OCCURS 1 WITH HEADER LINE,
gt_yvttk LIKE vttkvb OCCURS 1 WITH HEADER LINE,
gt_xvttp LIKE vttpvb OCCURS 0 WITH HEADER LINE,
gt_yvttp LIKE vttpvb OCCURS 0 WITH HEADER LINE,
gt_xvtts LIKE vttsvb OCCURS 0 WITH HEADER LINE.

DATA gs_xvttk TYPE vttkvb.

DATA lv_timestamp TYPE tzntstmps.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
PARAMETERS:p_tknum LIKE vttk-tknum OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN ON p_tknum.
  IF p_tknum IS NOT INITIAL.

    SELECT SINGLE * FROM vttk
      INTO CORRESPONDING FIELDS OF gs_xvttk
      WHERE tknum = p_tknum.

    IF sy-subrc NE 0.
      MESSAGE e000 WITH text-002.
    ENDIF.

  ENDIF.

START-OF-SELECTION.

  IF gs_xvttk-tknum IS NOT INITIAL.

*      UPDATE vttk SET zzlastbookupd = lv_timestamp WHERE tknum = gs_xvttk-tknum.

    gs_xvttk-updkz = 'U'.
    APPEND gs_xvttk TO gt_yvttk.

    CALL FUNCTION 'ABI_TIMESTAMP_CONVERT_INTO'
      EXPORTING
        iv_date          = sy-datum
        iv_time          = sy-timlo
      IMPORTING
        ev_timestamp     = lv_timestamp
      EXCEPTIONS
        conversion_error = 1
        OTHERS           = 2.


    gs_xvttk-zzlastbookupd = lv_timestamp.
    APPEND gs_xvttk TO gt_xvttk.

    SELECT * FROM vttp INTO CORRESPONDING FIELDS OF TABLE gt_xvttp WHERE tknum = p_tknum.
    gt_yvttp[] = gt_xvttp[].

    SELECT * FROM vtts INTO TABLE gt_xvtts WHERE tknum = p_tknum.

    CALL FUNCTION 'SD_SHIPMENTS_SAVE'
      EXPORTING
        i_transaktionstyp            = 'V'
*         I_UPD_DEADLINES              = 'X'
*         I_UPD_TEXTS                  = 'X'
*         I_UPD_SHIPPING_UNITS         = 'X'
       i_upd_output                 = 'X'
       i_opt_update_task            = 'X'
       i_opt_activities             = 'X'
*         I_OPT_NO_STATISTICS          = ' '
       i_opt_read_ship_units        = 'X'
       i_flag_tra_complete          = 'X'
*         I_TRA_SAVE_CALLER            =
*       IMPORTING
*         E_LOG_ALWAYS                 =
*         E_LOG_ON_ERROR_WARNING       =
*         E_SAVE_LOG                   =
      TABLES
        i_xvttk                      = gt_xvttk
        i_yvttk                      = gt_yvttk
        i_xvttp                      = gt_xvttp
        i_yvttp                      = gt_yvttp
*         I_VTRLK                      =
*         I_VTRLP                      =
        i_xvtts                      = gt_xvtts
*         I_YVTTS                      =
*         I_XVTSP                      =
*         I_YVTSP                      =
*         I_XVBPA                      =
*         I_YVBPA                      =
*         I_XSADR                      =
*         I_YSADR                      =
*         I_XVTFA                      =
*         I_YVTFA                      =
*         I_XVEKP                      =
*         I_YVEKP                      =
*         I_XVEPO                      =
*         I_YVEPO                      =
*       CHANGING
*         C_SPLIT_DIALOG_WA            =
     EXCEPTIONS
       no_change                    = 1
       delivery_split_error         = 2
       OTHERS                       = 3
              .
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.

    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*       EXPORTING
*         WAIT          =
*       IMPORTING
*         RETURN        =
              .

  ENDIF.

*---------------------------------------------------------------------*
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZ_ZREQ_FIELDS_TMTOP.              " Global Data
  INCLUDE LZ_ZREQ_FIELDS_TMUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZ_ZREQ_FIELDS_TMF...              " Subprograms
* INCLUDE LZ_ZREQ_FIELDS_TMO...              " PBO-Modules
* INCLUDE LZ_ZREQ_FIELDS_TMI...              " PAI-Modules
  INCLUDE LZ_ZREQ_FIELDS_TMF00                    . " subprograms
  INCLUDE LZ_ZREQ_FIELDS_TMI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

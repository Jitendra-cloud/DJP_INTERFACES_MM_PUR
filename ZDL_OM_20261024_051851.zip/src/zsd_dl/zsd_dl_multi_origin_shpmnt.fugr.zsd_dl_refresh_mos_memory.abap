FUNCTION ZSD_DL_REFRESH_MOS_MEMORY.
*"----------------------------------------------------------------------
*"*"Local interface:
*"----------------------------------------------------------------------

* This Function Module requires no input - returns no output
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2010 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       2010, 2011, 20xx                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: Refresh MOS Memory               Create Date: 12/07/10 *
*                                                                      *
* SAP Name    : ZSD_DL_REFRESH_MOS_MEMORY        Version    :          *
*                                                                      *
* Programmer  : Charles Ramey                    Last Update:          *
*______________________________________________________________________*
* Description :                                                        *
*     FM to clear out global tables accessed by Function Modules       *
*  within  ZSD_DL_MULTI_ORIGIN_SHPMNT Function Group.  This includes   *
*     ZSD_DL_MOS_ITINERARY_VIEW (itinerary) ,                          *
*     ZSD_DL_DET_SHPMNTPLN_RELEVANCE,                                  *
*     ZSD_DL_DET_NO_OF_SHIP_UNITS (Common Units FM)                    *
*            etc...                                                    *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* C. Ramey            12/07/10              Initial creation           *
*                                                                      *
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*                                                                      *
*   Transactions    :                                                  *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************


Refresh : gt_stops            ,
          gt_stage_data       ,
          gt_curr_stage       ,
          gt_prev_stage       ,
          gt_next_stage       ,
          gt_deliveries       ,
          gt_date_time        ,
          gt_control_data     ,
          gt_itinerary        ,
          gt_vttk             ,
          gt_vttp             ,
          gt_vtts             ,
          gt_vtsp             ,
          gt_vtts_copy        ,
          gt_VBPLK            ,
          gt_vbplp            ,
          gt_delivery_roll    ,
          gt_shipment_no      ,
          gt_shipments        ,
          gt_delivery         ,
          gt_delivery_items   ,
          gt_ship_units       ,
          gt_delv_units       ,
          gt_delv_item_units  ,
          gt_atnam            ,
          gt_HU_CONTENTS      ,
          gt_marc_vc_char     ,
          gt_delv_data        ,
          gt_vbeln            ,
          gt_vbup             ,
          gt_marc_cuobj       ,
          gt_char_atinn       ,
          gt_ekko             ,
          gt_ekkn             ,
          gt_vekp             ,
          gt_vepo             ,
          gt_vepo_l           ,
          gt_vekp_del         ,
          gt_vpobjkey         ,
          gt_vbup_copy        ,
          gt_item_data        ,
          gt_conf_out         ,
          gt_batch_char       ,
*    Table currently blowing up billing tally
          gt_delv_batch_char  ,
*
          gt_char_name        ,
          gt_object_data      ,
          gt_delv_data_temp   .

ENDFUNCTION.

function zsd_dl_shpmnt_multi_origin_ind.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  EXPORTING
*"     VALUE(MULTI_ORIGIN_IND) TYPE  ZSD_DL_MULTI_ORIGIN_SHPMNT_IND
*"  TABLES
*"      TVTTS STRUCTURE  VTTS
*"----------------------------------------------------------------------


  data:
    lv_vstel_count type i,
    lv_kunnr_count type i,
    lv_lifna_count type i.

  clear: lv_vstel_count, lv_kunnr_count, lv_lifna_count.

* Do a simple count of the number of Shipping points/customer nos.

  loop at tvtts.
    if not tvtts-vstel is initial.
      add 1 to   lv_vstel_count.
    endif.
    if not tvtts-vstez is initial.
      add 1 to   lv_vstel_count.
    endif.
    if not tvtts-kunna is initial.
      add 1 to lv_kunnr_count.
    endif.
    if not tvtts-kunnz is initial.
      add 1 to lv_kunnr_count.
    endif.
    if not tvtts-lifna is initial.
      add 1 to lv_lifna_count.
    endif.
    if not tvtts-lifnz is initial.
      add 1 to lv_lifna_count.
    endif.
  endloop.

* Add up shipping points and customer numbers to determine the result.
  if lv_vstel_count = 1.
    if lv_kunnr_count = 1.
      multi_origin_ind = 1.
    endif.
    if lv_kunnr_count > 1.
      multi_origin_ind = 3.
    endif.
  endif.

  if lv_vstel_count > 1.
    if lv_kunnr_count = 1.
      multi_origin_ind = 2.
    endif.
    if lv_kunnr_count gt 1.
      multi_origin_ind = 4.
    endif.
  endif.

*The exceptions will be added to the function module as we go.



endfunction.

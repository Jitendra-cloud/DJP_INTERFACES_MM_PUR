"Name: \PR:SDBONT06\EX:FAKTURA_LESEN_01\EI
ENHANCEMENT 0 ZSD_E10754_CHANGE_VBRK.


**    DATA:    BEGIN OF lt_XVBRK OCCURS 10.
**      INCLUDE STRUCTURE VBRK.
**    DATA:    END OF lt_XVBRK.
**    DATA:   BEGIN OF XVBFS OCCURS 0.
**      INCLUDE STRUCTURE VBFS.
**    DATA:   END   OF XVBFS.
**    DATA:   BEGIN OF XTHEAD OCCURS 0.
**      INCLUDE STRUCTURE THEADVB.
**    DATA:   END   OF XTHEAD.
**    DATA:   BEGIN OF XVBSS OCCURS 0.
**      INCLUDE STRUCTURE VBSS.
**    DATA:   END   OF XVBSS.
**
**  CALL FUNCTION 'RV_INVOICE_DOCUMENT_READ'
**    EXPORTING
**      activity             = '02'       "Ändern
**      konv_read            = 'X'
**      no_nast              = 'X'
**      vbrk_i               = vbrk
**      i_no_authority_check = 'X'
**    IMPORTING
**      vbrk_e               = vbrk
**      vbuk_e               = vbuk
**    TABLES
**      xkomv                = tkomv
**      xvbpa                = xvbpa
**      xvbrk                = xvbrk
**      xvbrp                = xvbrp
**      xkomfk               = xkomfk
**      XVBFS = XVBFS
**      XTHEAD = XTHEAD
**      XVBSS = XVBSS
**    EXCEPTIONS
**      error_message        = 4
**      OTHERS               = 4.
**
**  if vbrk-vkorg = '0100'.
**
**    LOOP AT xvbrk.
**      xvbrk-ZZ_VATLOCAL = xvbrk-ZZ_VATLOCAL + 1.
**      modify xvbrk TRANSPORTING ZZ_VATLOCAL.
**      MOVE-CORRESPONDING xvbrk to lt_xvbrk.
**      append lt_xvbrk.
**    ENDLOOP.
**
**  CALL FUNCTION 'RV_INVOICE_HEAD_MAINTAIN'
**    EXPORTING
**      vbrk_i        = lt_xvbrk
**    tables
**      xkomfk        = xkomfk
**      xkomv         = tkomv
**      xthead        = xthead
**      xvbfs         = xvbfs
**      xvbpa         = xvbpa
**      xvbrk         = xvbrk
**      xvbrp         = xvbrp
**      xvbss         = XVBSS.
**
**  endif.

ENDENHANCEMENT.

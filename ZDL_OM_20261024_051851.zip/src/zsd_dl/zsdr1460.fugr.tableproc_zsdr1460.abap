*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSDR1460
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSDR1460            .

  PERFORM TABLEPROC.

ENDFUNCTION.

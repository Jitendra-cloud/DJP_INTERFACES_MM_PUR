*&---------------------------------------------------------------------*
*&  Include           ZDL_E11734_SYLVAMO_3PP_IMP
*&---------------------------------------------------------------------*
*----------------------------------------------------------------------*
* Sameena Padasalagi   07/22/2025      proposed solution for Riverdale *
* (SPADASA)                            shipments with Inactive Carriers*
* TR: S0VK913003    Charm:2000002878   ScTask:SCTASK0090810            *
*                                                                      *
*----------------------------------------------------------------------*
class lcl_3rd_party implementation.

  method: get_inb_dlvry.
*On the selection screen, if Run Post GR check box is checked then –
*Read open inbound deliveries for the receiving plant.

    clear et_inb_dlvry.
    check sp_posgr is not initial.

    select vbeln
      from shp_idx_gdrc
      into table @data(lt_inb_dlvry)
      where vbeln in @so_vbeln and
            vstel in @so_plant.

    if sy-subrc <> 0.
      return.
    endif.

* Get delivery header information
    select vbeln,
           erdat,
           vstel,
           zz_exit_pass_no,
           zz_scac,
           zz_signi,
           zz_bale_cnt,
           zz_bol,
           zz_scale,
           zz_complete,
           zz_ship_date,
           zz_gross_wt,
           zz_net_wt,
           zz_tare_wt,
***** hmalkow - start
           zz_seal,
           zz_shtyp,
           btgew,
           anzpk
*           zz_vgm
***** hmalkow - end
      from likp
      into corresponding fields of table @et_inb_dlvry
      for all entries in @lt_inb_dlvry
      where vbeln = @lt_inb_dlvry-vbeln and
            vstel in @so_plant and
            erdat in @so_erdat and
            vsbed in @so_vsbed and
            vbtyp = '7'. " 7 Is for inbound delivery
***** 2000000248 - start
    delete et_inb_dlvry where btgew is initial and anzpk is initial.
***** 2000000248 - end
    if et_inb_dlvry[] is initial.
      return.
    endif.

* Get inbound dlvry line item details.
    get_dlvry_item_info(
  exporting
    it_inb_dlvry = et_inb_dlvry
  importing
    et_lips      = et_lips ).
  endmethod.

  method: get_inb_with_no_outb.
    types: ty_t_lifex type range of lifex,
           ty_t_vbeln type range of vbeln_vl.
    clear:et_inb_dlvry,
          et_obd_dlvry.
*If Run Post GR check box is Unchecked then we have
*to select all inbound deliveries and process the
*inbounds where outbound is not created yet

* Read Inbound deliveries (Open and Closed).
    check sp_posgr is initial.
    select vbeln,
           erdat,
           vstel,
           zz_exit_pass_no,
           zz_scac,
           zz_signi,
           zz_bale_cnt,
           zz_bol,
           zz_scale,
           zz_complete,
           zz_ship_date,
           zz_gross_wt,
           zz_net_wt,
           zz_tare_wt,
           btgew
      from likp
      into corresponding fields of table @et_inb_dlvry
      where vbeln in @so_vbeln and
            vstel in @so_plant and
            erdat in @so_erdat and
            vsbed in @so_vsbed and
            vbtyp = '7'. " 7 Is for inbound delivery
***** 2000000248 - start
    delete et_inb_dlvry where btgew is initial and anzpk is initial.
***** 2000000248 - end
    if et_inb_dlvry[] is initial.
      return.
    endif.

* The above select will fetch inbound deliveries that are open
* and closed status. In this scenario we will eliminate the
*inbound deliveries that are in open status.

    select vbeln
      from vbuk
      into table @data(lt_inb_compltd)
      for all entries in @et_inb_dlvry
      where vbeln = @et_inb_dlvry-vbeln and
            wbstk = 'C'.
    if sy-subrc <> 0.
      return.
    endif.

* Get inbound dlvry line item details.
    get_dlvry_item_info(
      exporting
it_inb_dlvry = value ty_t_inb_dlvry( for ls_inb_compltd in lt_inb_compltd
( vbeln = ls_inb_compltd-vbeln ) )
importing
et_lips      = et_lips ).

    get_obd_line_itm(
      exporting
        it_lips = et_lips
      importing
        et_lips = et_obd_dlvry ).

    get_zdl_fields(
      importing
        et_fiels = data(lt_fields) ).

* Get wait time from ZDL_FIELDS.
    data(lv_retry_time) = value #( lt_fields[ fieldname = 'LOCK_RETRY' ]-lowval optional ).
    data(lv_wait_time) = value #( lt_fields[ fieldname = 'LOCK_WAIT' ]-lowval optional ).

*Get the Picking Status from VBUK table.
    if et_obd_dlvry is not initial.
      select vbeln,
             kostk
        from vbuk
        into table @data(lt_picking_status)
        for all entries in @et_obd_dlvry
        where vbeln = @et_obd_dlvry-vbeln.
      if sy-subrc = 0.
* Delete all the outbound deliverys found from the above select.
* We delete all the outbound deliverys inorder to proceed with creating
* new outbound and pick and pack
        loop at lt_picking_status into data(ls_delete_outbound) where kostk <> 'C'.
          data(ls_lock) = value #( et_obd_dlvry[ vbeln = ls_delete_outbound-vbeln ] optional ).
          if ls_lock is not initial.
            do lv_retry_time times.
              so_lock(
                exporting
                  iv_so      = ls_lock-vgbel
                importing
                  ev_lock    = data(lv_lock)
                  ev_so_user = data(lv_user) ).
              if lv_lock is not initial.
                wait up to lv_wait_time seconds.
              else.
                exit.
              endif.
            enddo.
          endif.
          if lv_lock is not initial.
* Fill app log.
            append value #( msgty  = gc_success
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '085 '
                            msgv1  = ls_lock-vgbel
                            msgv2  = lv_user ) to gt_messages.
            clear: ls_lock,
                   lv_lock,
                   lv_user.
            continue.
          endif.
* Fill app log.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '092'
                          msgv1  = ls_delete_outbound-vbeln
                     msgv2  = ls_delete_outbound-kostk ) to gt_messages.

          zcl_dl_e3637_dcgr_checks=>delete_delivery(
          exporting
            iv_delivery = conv bapiobdlvhdrchg-deliv_numb( ls_delete_outbound-vbeln )
          importing
            et_return   = data(lt_return) ).

          if lt_return is not initial.
            data(lt_messages_del) = value zca_bal_msg_tab( for ls_return_del in lt_return
                                    (  msgty  = ls_return_del-type
                                       msgid  = ls_return_del-id
                                       msgno  = ls_return_del-number
                                       msgv1  = ls_return_del-message_v1
                                       msgv2  = ls_return_del-message_v2
                                       msgv3  = ls_return_del-message_v3
                                       msgv4  = ls_return_del-message_v4 ) ).

***  2000000330 - start
*           append lines of lt_messages_del to gt_messages.
            msg_add_bal( exporting iv_notifobj    = ls_delete_outbound-vbeln
                                   iv_notifobjtyp = 'O'
                                   it_balmsg      = lt_messages_del ).
***  2000000330 - end
            clear lt_messages_del.
            append value #( msgty  = gc_success
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '094'
                     msgv1  = ls_delete_outbound-vbeln ) to gt_messages.
            append value #( msgty  = gc_success
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '101'
                            msgv1  = space ) to gt_messages.
            clear: ls_lock,
                   lv_lock,
                   lv_user.
          else.
            delete lt_picking_status where vbeln = ls_delete_outbound-vbeln.
            append value #( msgty  = gc_success
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '093'
                     msgv1  = ls_delete_outbound-vbeln ) to gt_messages.
            append value #( msgty  = gc_success
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '101'
                            msgv1  = space ) to gt_messages.
            clear: ls_lock,
                   lv_lock,
                   lv_user.
          endif.
        endloop.
      endif.
    endif.
  endmethod.

  method get_dlvry_item_info.
    clear et_lips.

    check it_inb_dlvry is not initial.
* At this point, we have all Inbound deliveries that are open and
*Inbound deliveries that are completed but no outbound delivery.
*Now we have to select all item level information for the above Inbound
*deliverys.
    select vbeln,
           posnr,
           matnr,
           werks,
           lgort,
           charg,
           lfimg,
           vrkme,
           meins,
           umvkz,
           umvkn,
           ntgew,
           brgew,
           gewei,
           lgmng,
           vbelv,
           posnv,
           vgbel,
           vgpos
      from lips
      into corresponding fields of table @et_lips
      for all entries in @it_inb_dlvry
      where vbeln = @it_inb_dlvry-vbeln.
    if sy-subrc = 0.
* Eliminate LIPS line items where batch (CHARG) is blank.
      delete et_lips where charg is initial.

*Eliminate LIPS line items where Actual Delivery quantity LFIMG is blank.
      delete et_lips where lfimg is initial.
    endif.
  endmethod.
  method:filter_po_org.
    clear et_ebeln.
*LIPS select find the unique Purchase order numbers (VGBEL).
* Filter based on the PO and PO Org.
    if it_lips is not initial.
      select ebeln,
             ekorg
        from ekko
        into table @et_ebeln
        for all entries in @it_lips
        where ebeln = @it_lips-vgbel and
              ekorg in @so_ekorg and
              lifnr in @so_lifnr.
      if sy-subrc <> 0.
        clear et_ebeln.
      endif.
    endif.
  endmethod.
  method filter_so_org.
    clear et_so_org.
*LIPS select find the unique Sales Order number (VBELV)
    check it_lips is not initial.
    select vbeln,
           vkorg,
           vgbel
      from vbak
      into table @et_so_org
      for all entries in @it_lips
      where vbeln = @it_lips-vbelv and
            vkorg in @so_vkorg.
    if sy-subrc <> 0.
      clear et_so_org.
    endif.
  endmethod.
  method get_so_item_info.
    clear et_so_item.
*Get Sales Unit of measure and conversion factor from Sales order item table
    check it_lips is not initial.
    select vbeln,
           vbelv,
           posnv,
           vrkme,
           umvkz,
           umvkn
      from vbap
      into table @et_so_item
      for all entries in @it_lips
      where vbeln = @it_lips-vbelv and
            posnr = @it_lips-posnv.
    if sy-subrc <> 0.
      clear et_so_item.
    endif.
  endmethod.

  method get_processing_inb_dlvry_data.

    gt_inb_dlvry = value #( for ls_lips in it_lips " Item table
                         for ls_inb_dlvry in it_inb_dlvry " Header table
                           where ( vbeln = ls_lips-vbeln )
                         for ls_filter_po in it_filter_po " PO filter
                           where ( ebeln = ls_lips-vgbel )
                         for ls_so_org in it_so_org       " SO filter
                           where ( vbeln = ls_lips-vbelv )
                         for ls_so_item in it_so_item     " So item
                           where ( vbelv = ls_lips-vbelv and
                                   posnv = ls_lips-posnv )
                         ( vbeln           = ls_inb_dlvry-vbeln
                           zz_complete     = ls_inb_dlvry-zz_complete
                          zz_exit_pass_no = ls_inb_dlvry-zz_exit_pass_no
                          zz_scac         = ls_inb_dlvry-zz_scac
                          zz_signi        = ls_inb_dlvry-zz_signi
                          zz_bale_cnt     = ls_inb_dlvry-zz_bale_cnt
                          zz_bol          = ls_inb_dlvry-zz_bol
                          zz_scale        = ls_inb_dlvry-zz_scale
                          zz_ship_date    = ls_inb_dlvry-zz_ship_date
                          zz_gross_wt     = ls_inb_dlvry-zz_gross_wt
                          zz_net_wt       = ls_inb_dlvry-zz_net_wt
                          zz_tare_wt      = ls_inb_dlvry-zz_tare_wt
                          posnr           = ls_lips-posnr
                          matnr           = ls_lips-matnr
                          werks           = ls_lips-werks
                          lgort           = ls_lips-lgort
                          charg           = ls_lips-charg
                          lfimg           = ls_lips-lfimg
                          vbelv           = ls_lips-vbelv
                          posnv           = ls_lips-posnv
                          vgbel           = ls_lips-vgbel
                          vgpos           = ls_lips-vgpos
                          lips_vrkme      = ls_lips-vrkme
                          meins           = ls_lips-meins
                          lgmng           = ls_lips-lgmng
                          brgew           = ls_lips-brgew
                          ntgew           = ls_lips-ntgew
                          gewei           = ls_lips-gewei
                          ekorg           = ls_filter_po-ekorg
                          vkorg           = ls_so_org-vkorg
                          vbap_vrkme      = ls_so_item-vrkme
                          umvkz           = ls_so_item-umvkz
                          umvkn           = ls_so_item-umvkn
***** hmalkow - start
*                          zz_seal         = ls_inb_dlvry-zz_seal
*                          zz_shtyp        = ls_inb_dlvry-zz_shtyp

***** hmalkow - end
                           ) ).
  endmethod.
  method get_inb_dlvry_data.

    clear gt_inb_dlvry.
    if sp_posgr is not initial.
      get_inb_dlvry(
        importing
          et_inb_dlvry = data(lt_inb_dlvry)
          et_lips      = data(lt_lips) ).
    else.
      get_inb_with_no_outb(
        importing
          et_inb_dlvry = lt_inb_dlvry
          et_obd_dlvry = data(lt_obd_dlvry)
          et_lips      = lt_lips ).

      compare_batches(
        exporting
          et_obd_dlvry = lt_obd_dlvry
        changing
          ct_inb_dlvry = lt_lips ).
    endif.

    if lt_inb_dlvry is not initial.
      filter_po_org(
        exporting
          it_lips = lt_lips
        importing
          et_ebeln = data(lt_filter_po) ).

      filter_so_org(
        exporting
          it_lips = lt_lips
        importing
          et_so_org = data(lt_so_org) ).

      get_so_item_info(
        exporting
          it_lips    = lt_lips
        importing
          et_so_item = data(lt_so_item) ).
      get_processing_inb_dlvry_data(
         exporting it_inb_dlvry = lt_inb_dlvry
                   it_lips      = lt_lips
                   it_filter_po = lt_filter_po
                   it_so_org    = lt_so_org
                   it_so_item   = lt_so_item ).
    endif.
    if gt_inb_dlvry is initial.
      "No Inbound found for processing
      message w124(zdl_sylvamo_3pp).
      return.
    endif.
  endmethod.

  method check_lock.
    clear: ev_lock,
           ev_po_user,
           ev_so_user.
* Get wait time from ZDL_FIELDS.
    data(lv_retry_time) = value #( gt_fields[ fieldname = 'LOCK_RETRY' ]-lowval optional ).
    data(lv_wait_time) = value #( gt_fields[ fieldname = 'LOCK_WAIT' ]-lowval optional ).

    do lv_retry_time times.
      po_lock(
        exporting
          iv_po   = iv_po
        importing
          ev_lock = data(lv_po_lock)
          ev_po_user = ev_po_user ).

      so_lock(
        exporting
          iv_so   = iv_so
        importing
          ev_lock = data(lv_so_lock)
          ev_so_user = ev_so_user ).

      if lv_po_lock = abap_true or
         lv_so_lock = abap_true.
        wait up to lv_wait_time seconds.
        ev_lock = abap_true.
      else.
        exit.
      endif.
    enddo.
  endmethod.
  method po_lock.
* Check if the po is locked. if it is locked, then return flag.
    call function 'ENQUEUE_EMEKKOE'
      exporting
        mandt          = sy-mandt
        ebeln          = iv_po
      exceptions
        foreign_lock   = 1
        system_failure = 2
        others         = 3.
    if sy-subrc <> 0.
      ev_lock = abap_true.
      ev_po_user = sy-msgv1.
    else.
* Unlock
      call function 'DEQUEUE_EMEKKOE'
        exporting
          mode_ekko = 'E'
          mode_ekpo = 'E'
          mandt     = sy-mandt
          ebeln     = iv_po.
      clear: ev_lock,
             ev_po_user.
    endif.
  endmethod.
  method so_lock.
    call function 'ENQUEUE_EVVBAKE'
      exporting
        mode_vbak      = 'E'
        mandt          = sy-mandt
        vbeln          = iv_so
      exceptions
        foreign_lock   = 1
        system_failure = 2
        others         = 3.
    if sy-subrc <> 0.
      ev_lock = abap_true.
      ev_so_user = sy-msgv1.
    else.
* Unlock
      call function 'DEQUEUE_EVVBAKE'
        exporting
          mode_vbak = 'E'
          mandt     = sy-mandt
          vbeln     = iv_so.
      clear: ev_lock,
             ev_so_user.
    endif.
  endmethod.
  method get_zdl_fields.
    clear et_fiels.
    select *
      from zdl_fields
      into table @et_fiels
      where category = 'E11734' and
          ( fieldname = 'WERKS' or
            fieldname = 'LOCK_RETRY' or
            fieldname = 'LOCK_WAIT' ).
    if sy-subrc <> 0.
      clear et_fiels.
    endif.
  endmethod.
  method calculate_quantity.
    clear ev_quantity.
* Check if the quantity is not initial.
    if is_inb_del-lips_vrkme <> is_inb_del-vbap_vrkme.
* For TON or GMT, BAPI will convert, calculation is required for the RL
      if is_inb_del-vbap_vrkme = 'RL'.
* Get the delivery quantity.
        ev_quantity =  1.
      else.
        ev_quantity = is_inb_del-lfimg.
      endif.
    else.
      ev_quantity = is_inb_del-lfimg.
    endif.
  endmethod.

  method process.
**********************************************************************
* Local types declaration.
**********************************************************************
    data: lt_outbound_data type zdl_bapidlvreftosalesorder_t,
          lv_qty           type lfimg,
          lt_vbpok         type vbpok_t,
          lv_brgew         type brgew,
          lv_ntgew         type ntgew,
          lt_vbpok_pp      type vbpok_t,
          lv_error         type abap_bool,
          lv_shipment      type tknum,
          lt_messages      type zca_bal_msg_tab.
    data: lv_ftime type abap_bool.
    data: lv_err type abap_bool.
    data: lv_delivlist type symsgv.
    data: lt_delivlist type string_table.
    data: lv_delivery  type vbeln_vl.
***** 2000000261 - start
    data: lt_ibd_bolnr type tt_ibd_bolnr.
    data: ls_ibd_bolnr type line of tt_ibd_bolnr.
    data: ls_err_vbeln  type line of tt_err_vbeln.

    refresh mr_err_bolnr[].
    refresh mr_err_vbeln[].
***** 2000000261 - end
    lv_ftime = abap_true.

**********************************************************************
* Main Business Logic
**********************************************************************
    check gt_inb_dlvry is not initial.

* ZDL fields read. This is to remove the constant for PO org and SO Org.
    get_zdl_fields(
      importing
        et_fiels = gt_fields ).

* Covert it into range table.
***  hmalkow - start
    data(lr_werks) =
      value /bofu/t_fbi_value_range( for ls_fields in gt_fields
                              where ( fieldname = 'WERKS' )
                                    ( sign = 'I'
                                     option = 'EQ'
                                     low = ls_fields-lowval ) ).
***  hmalkow - end

* Get the all the required fileds to a new table so that control break statments works.
    data(lt_obd_data) =
      value ty_t_obd_data( for ls_inb_delvry in gt_inb_dlvry
                         ( vbeln = ls_inb_delvry-vbeln
                           vbelv = ls_inb_delvry-vbelv
                           vgbel = ls_inb_delvry-vgbel
                           posnv = ls_inb_delvry-posnv ) ).

    sort: lt_obd_data by vbeln ascending
                         vgbel ascending
                         posnv ascending,

          gt_inb_dlvry by vbeln ascending
                          vgbel ascending
                          posnv ascending.

***** hmalkow - start
    "Create Delivery List & table for BOLNR check
    loop at lt_obd_data into data(ls_outdel).
      data(ls_inbdeliv) = value #( gt_inb_dlvry[ sy-tabix ] optional ).
      at new vgbel.
        append ls_inbdeliv-vbeln to lt_delivlist.
        if strlen( lv_delivlist ) + strlen( ls_inbdeliv-vbeln ) <= 50.
          lv_delivlist = lv_delivlist && ` ` && ls_inbdeliv-vbeln.
        endif.
      endat.
***** 2000000261 - start
      at end of vgbel.
        clear: ls_ibd_bolnr.

        select single bolnr from likp into @data(lv_bolnr)
          where vbeln = @ls_inbdeliv-vbeln.

        if sy-subrc = 0.
          ls_ibd_bolnr-bolnr = lv_bolnr.
          ls_ibd_bolnr-vbeln = ls_inbdeliv-vbeln.
          append ls_ibd_bolnr to lt_ibd_bolnr.
        endif.
      endat.
***** 2000000261 - end
    endloop.

    delete adjacent duplicates from lt_delivlist comparing all fields.
    lv_delivlist = lines( lt_delivlist ).
    lv_delivlist = condense( lv_delivlist ).

    append value #( msgty  = gc_success
                    msgid  = 'ZDL_SYLVAMO_3PP'
                    msgno  = '122'
                    msgv1  = lv_delivlist ) to gt_messages.

    if check_inbound_delivery( exporting iv_err = 'B'
                               changing  ct_ibd_bolnr = lt_ibd_bolnr  ) = 'X'.
      lv_err = 'X'.
    endif.

    loop at lt_obd_data into data(ls_obd_dlvry).
      data(ls_inbdel) = value #( gt_inb_dlvry[ sy-tabix ] optional ).
      at new vgbel.
        if check_all_data( ls_inbdel-vbeln ) = 'X'.
          lv_err = 'X'.
          ls_err_vbeln-option = 'EQ'.
          ls_err_vbeln-sign   = 'I'.
          ls_err_vbeln-low    = ls_inbdel-vbeln.
          append ls_err_vbeln to mr_err_vbeln.
        endif.
      endat.
    endloop.

    if lv_err = 'X'.
      delete adjacent duplicates from gt_messages comparing all fields.
      mv_error = 'X'.
*     return.                                              "2000000330
    else.
      append value #( msgty  = gc_success
                    msgid  = 'ZDL_SYLVAMO_3PP'
                    msgno  = '123' ) to gt_messages.
    endif.
***** hmalkow - end

* Loop the table gt_inb_dlvry to create GR, Outbound, Pick and Pack.
    loop at lt_obd_data into ls_obd_dlvry.

      data(ls_inb_dlvry) = value #( gt_inb_dlvry[ sy-tabix ] optional ).

***  2000000330 - start
      if ( mr_err_vbeln[] is not initial and ls_inb_dlvry-vbeln in mr_err_vbeln[] ) or
         ( mr_err_bolnr[] is not initial and get_bolnr( ls_inb_dlvry-vbeln ) in mr_err_bolnr[] ).

        clear: ls_obd_dlvry,
               ls_inb_dlvry.
        continue.
      endif.
***  2000000330 - end

      if sp_posgr is not initial.
* Get wait time from ZDL_FIELDS.
        data(lv_retry_time) =
       value #( gt_fields[ fieldname = 'LOCK_RETRY' ]-lowval optional ).

        data(lv_wait_time) =
        value #( gt_fields[ fieldname = 'LOCK_WAIT' ]-lowval optional ).

        do lv_retry_time times.
          matnr_lock(
            exporting
              iv_matnr      = ls_inb_dlvry-matnr
              iv_werks      = ls_inb_dlvry-werks
            importing
              ev_lock       = data(lv_matnr_lock)
              ev_matnr_user = data(lv_matnr_user) ).
          if lv_matnr_lock is not initial.
            wait up to lv_wait_time seconds.
          else.
            exit.
          endif.
        enddo.

      endif.

      if lv_matnr_lock = abap_true.
        delete gt_inb_dlvry where vbeln = ls_inb_dlvry-vbeln.
        delete lt_obd_data  where vbeln = ls_obd_dlvry-vbeln.
        if gt_inb_dlvry is initial.
          message s090(zdl_sylvamo_3pp).
          return.
        endif.
        continue.
      endif.

      at new vgbel.
* Check the lock. Two locks have to be checked.
* 1. PO Lock
* 2. SO Lock.
* There will be multiple same SO and multiple same PO. but
* Checking lock should be on unique PO and SO.
        check_lock(
          exporting
            iv_po   = ls_inb_dlvry-vgbel
            iv_so   = ls_inb_dlvry-vbelv
          importing
            ev_lock = data(lv_lock)
            ev_po_user = data(lv_po_user)
            ev_so_user = data(lv_so_user) ).

        if lv_lock = abap_true.
          if lv_po_user is not initial.
            append value #( msgty  = 'W'
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '082'
                            msgv1  = ls_inb_dlvry-vgbel
                            msgv2  = lv_po_user ) to gt_messages.
          endif.
          if lv_so_user is not initial.
            append value #( msgty  = 'W'
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '085'
                            msgv1  = ls_inb_dlvry-vbelv
                            msgv2  = lv_so_user ) to gt_messages.
          endif.
          delete gt_inb_dlvry where vbeln = ls_inb_dlvry-vbeln.
          delete lt_obd_data  where vbeln = ls_obd_dlvry-vbeln.
          if gt_inb_dlvry is initial.
            message s090(zdl_sylvamo_3pp).
            return.
          endif.
          clear ls_inb_dlvry.
          continue.
        endif.

      endat.

* Prepare the internal table for picking and packing.
      append value #( vbeln = ls_inb_dlvry-vbelv
                      posnn = ls_inb_dlvry-posnr
                      vbeln_vl = ls_inb_dlvry-vbelv
                      posnr_vl = ls_inb_dlvry-posnv
                      vbtyp_n = 'Q'
                      matnr = ls_inb_dlvry-matnr
                      charg = ls_inb_dlvry-charg
                      werks = ls_inb_dlvry-werks
                      taqui = abap_true
                      kzntg = abap_true
                      kzbrg = abap_true
                      pikmg = ls_inb_dlvry-lgmng
                      brgew = ls_inb_dlvry-brgew
                      ntgew = ls_inb_dlvry-ntgew
                      meins = ls_inb_dlvry-meins
                      gewei = ls_inb_dlvry-meins
                      lgort = ls_inb_dlvry-lgort ) to lt_vbpok.

* Calculate quantity.
* There will be multiple batches and quantity for the same line item.
* All the quantity for the same item has to be added and sent to BAPI
* for creating Outbound delivery.
      calculate_quantity(
         exporting
           is_inb_del  = ls_inb_dlvry
         importing
           ev_quantity = data(lv_quantity) ).

      lv_qty = lv_qty + lv_quantity.

      at end of posnv.
        if ls_inb_dlvry-vbap_vrkme = 'RL'.
          append value #( ref_doc    = ls_inb_dlvry-vbelv
                          ref_item   = ls_inb_dlvry-posnv
                          dlv_qty    = lv_qty
            sales_unit = ls_inb_dlvry-vbap_vrkme )  to lt_outbound_data.
        else.
          append value #( ref_doc    = ls_inb_dlvry-vbelv
                          ref_item   = ls_inb_dlvry-posnv
                          dlv_qty    = lv_qty
            sales_unit = ls_inb_dlvry-lips_vrkme )  to lt_outbound_data.
        endif.

        clear: lv_qty,
               lv_quantity.
      endat.

      at end of vbeln.
*--------------------------------------------------------------------
*       GR should be created per Inbound delivery
*--------------------------------------------------------------------
        if sp_posgr is not initial and
           ls_inb_dlvry-werks in lr_werks[].

          if lv_ftime = abap_true.
            clear: lv_ftime.
          else.
            msg_add_empty( ).
          endif.
* Fill app log.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '095'
                          msgv1  = ls_inb_dlvry-vbeln ) to gt_messages.

          call function 'ZDL_E3637_POST_INB_DLVRY_GR'
            exporting
              iv_inb_dlvry  = ls_inb_dlvry-vbeln
            tables
              et_messages   = lt_messages
            exceptions
              error_post_gr = 1
              others        = 2.

          if sy-subrc = 0.
            msg_add_bal( exporting iv_notifobj    = ls_inb_dlvry-vbeln
                                   iv_notifobjtyp = 'I'
                                   it_balmsg      = lt_messages ).
            "---Inbound delivery &1 Goods Receipt Complete.
            append value #( msgty  = gc_success
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '091'
                            msgv1  = ls_inb_dlvry-vbeln ) to gt_messages.
          else.
* Append all messages
            msg_add_bal( exporting iv_notifobj    = ls_inb_dlvry-vbeln
                                   iv_notifobjtyp = 'I'
                                   it_balmsg      = lt_messages ).
            clear: lt_messages,
                   ls_inb_dlvry.
* Clear all the local variable and table for the next inbound to be proccessed.
            clear: ls_obd_dlvry,
                   ls_inb_dlvry,
                   lt_vbpok,
                   lt_outbound_data,
                   lv_lock,
                   lv_po_user,
                   lv_so_user,
                   lv_error,
                   lv_shipment.
            continue.
          endif.
        endif.

        if ls_inb_dlvry-werks not in lr_werks[].
          commit work.
** Capture application log.
          "---Inbound delivery &1 Goods Receipt Complete.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '091'
                          msgv1  = ls_inb_dlvry-vbeln ) to gt_messages.

        endif.

*--------------------------------------------------------------------
*       Create Outbound delivery.
*--------------------------------------------------------------------
        if sp_vl01n is not initial and
           ls_inb_dlvry-werks in lr_werks[].
** Capture application log.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '096'
                          msgv1  = ls_inb_dlvry-vbeln ) to gt_messages.
* Capture all the item table entry in an application log.
          lt_messages = value #( for ls_outbound_data in lt_outbound_data
                               (  msgty  = gc_success
                                  msgid  = 'ZDL_SYLVAMO_3PP'
                                  msgno  = '97'
                                  msgv1  = ls_outbound_data-ref_doc
                                  msgv2  = ls_outbound_data-ref_item
                                  msgv3  = |{ ls_outbound_data-dlv_qty }|
                                msgv4  = ls_outbound_data-sales_unit ) ).
***  2000000330 - start
*         append lines of lt_messages to gt_messages.
          msg_add_bal( exporting it_balmsg = lt_messages ).
***  2000000330 - end

          clear lt_messages.

          zcl_dl_e3637_dcgr_checks=>create_obd_dlvry(
                    exporting
                      iv_dlk        = abap_false
                      is_inb_dlvry  = ls_inb_dlvry
                      it_outbound_data = lt_outbound_data
                    importing
                      ev_out_dlvry = data(lv_out_dlvry)
                      et_messages  = lt_messages ).

* Read the retrun table from the babi irrespective of error and success.
* 1. If error, fill app log table and the continue for another inbound dlvry
* 2. If success, then get the outbound delivery number created just now.
*  2.1. Read LIPS table with newly created outbound delivery and fill item table
*       LT_VBLOK for Pick and Pack Process.

* Scenario 1.
          if lt_messages is not initial.
* Read all the message except Success and populate them in applog table.
            data(ls_error) =
              value #( lt_messages[ msgty = 'E' ] optional ).
            data(ls_warning) =
               value #( lt_messages[ msgty = 'W' ] optional ).

            if ls_error is not initial.
              append value #( notifobj    = ls_inb_dlvry-vbeln
                              notifobjtyp = 'I'
                              msgty  = ls_error-msgty
                              msgid  = ls_error-msgid
                              msgno  = ls_error-msgno
                              msgv1  = ls_error-msgv1
                              msgv2  = ls_error-msgv2
                              msgv3  = ls_error-msgv3
                              msgv4  = ls_error-msgv4 ) to gt_messages.
            endif.

            if ls_warning is not initial.
              append value #( msgty  = ls_warning-msgty
                              msgid  = ls_warning-msgid
                              msgno  = ls_warning-msgno
                              msgv1  = ls_warning-msgv1
                              msgv2  = ls_warning-msgv2
                              msgv3  = ls_warning-msgv3
                             msgv4  = ls_warning-msgv4 ) to gt_messages.
            endif.

* Now read all the success record for which outbound is created and fill it in
* Outbound table.
            data(lr_new_outbound) =
             value fip_t_vbeln_range( for ls_new_outbound in lt_messages
                                         where ( msgty = 'S' and
                                           msgid  = 'VL' and
                                           msgno  = '311' )
                                         ( sign   = 'I'
                                           option = 'EQ'
                                     low    = ls_new_outbound-msgv1 ) ).
          endif.

          delete lr_new_outbound where low is initial.
          if lr_new_outbound is not initial.
* Fill applog with new outbound delivery.
            data(lt_success_msg) =
              value zca_bal_msg_tab( for ls_success_msg in lt_messages
                                        where ( msgty = 'S' and
                                        msgid = 'VL' and
                                        msgno = '311' )
                                        ( msgty = ls_success_msg-msgty
                                        msgid = ls_success_msg-msgid
                                        msgno = ls_success_msg-msgno
                                        msgv1 = ls_success_msg-msgv1
                                        msgv2 = ls_success_msg-msgv2
                                        msgv3 = ls_success_msg-msgv3
                                       msgv4 = ls_success_msg-msgv4 ) ).
***  2000000330 - start
*           append lines of lt_success_msg to gt_messages.
            msg_add_bal( exporting it_balmsg = lt_success_msg ).
***  2000000330 - end
***  hmalkow - start
            update_process_tab( exporting iv_inbdel = ls_inb_dlvry-vbeln
                                          ir_outdel = lr_new_outbound ).
***  hmalkow - end
* Commit work.
            call function 'BAPI_TRANSACTION_COMMIT'
              exporting
                wait = abap_true.

** Capture application log.
            if sp_posgr is not initial.
              append value #( msgty  = gc_success
                              msgid  = 'ZDL_SYLVAMO_3PP'
                              msgno  = '091'
                           msgv1  = ls_inb_dlvry-vbeln ) to gt_messages.
            endif.
            clear lt_outbound_data.
          else.
* Continue to the next inb dlvry if there are error in creating outbound delivery.
            rollback work.
** Capture application log.
            if sp_posgr is not initial.
              append value #( msgty  = gc_success
                              msgid  = 'ZDL_SYLVAMO_3PP'
                              msgno  = '098'
                              msgv1  = ls_inb_dlvry-vbeln )
                to gt_messages.

            endif.
            clear lt_outbound_data.
            clear: ls_obd_dlvry,
                   ls_inb_dlvry,
                   lt_vbpok,
                   lt_outbound_data,
                   lr_new_outbound,
                   lv_lock,
                   lv_po_user,
                   lv_so_user,
                   lv_error,
                 lv_shipment.
            continue.
          endif.
        endif.

* If there are outbound delivery created for the inbound
*( it can be multiple outbound or single outbound )
* Proceed to picking and packing for the newly created outbound delivery.

* Read LIPS table to get the data for the new outbound.

********************* picking and packing process - START
        if sp_charg is not initial and
           ls_inb_dlvry-werks in lr_werks[].

          if lv_out_dlvry is initial and
             sp_vbeln is not initial.
            lv_out_dlvry = sp_vbeln.
          endif.

          fill_pick_with_obd(
            exporting
              iv_vrkme     = ls_inb_dlvry-vbap_vrkme
              it_vbpok     = lt_vbpok
              ir_obd_dlvry = lr_new_outbound
            importing
              et_vbpok     = data(lt_vbpok_tab) ).

* SUM of all items VBPOK_TAB-BRGEW
          sort lt_vbpok_tab by vbeln_vl ascending.
          loop at lt_vbpok_tab into data(ls_vbpok_tab).
            lv_brgew = lv_brgew + ls_vbpok_tab-brgew.
            lv_ntgew = lv_ntgew + ls_vbpok_tab-ntgew.
            append value #( vbeln_vl = ls_vbpok_tab-vbeln_vl
                            vbeln    = ls_vbpok_tab-vbeln
                            posnr_vl = ls_vbpok_tab-posnr_vl
                            posnn    = ls_vbpok_tab-posnn
                            vbtyp_n  = ls_vbpok_tab-vbtyp_n
                            matnr    = ls_vbpok_tab-matnr
                            charg    = ls_vbpok_tab-charg
                            werks    = ls_vbpok_tab-werks
                            taqui    = ls_vbpok_tab-taqui
                            kzntg    = ls_vbpok_tab-kzntg
                            kzbrg    = ls_vbpok_tab-kzbrg
                            umvkz    = ls_vbpok_tab-umvkz
                            umvkn    = ls_vbpok_tab-umvkn
                            vrkme    = ls_vbpok_tab-vrkme
                            pikmg    = ls_vbpok_tab-pikmg
                            brgew    = ls_vbpok_tab-brgew
                            ntgew    = ls_vbpok_tab-ntgew
                            meins    = ls_vbpok_tab-meins
                            gewei    = ls_vbpok_tab-gewei
                         lgort    = ls_vbpok_tab-lgort ) to lt_vbpok_pp.
            at end of vbeln_vl.
** Capture application log.
              append value #( msgty  = gc_success
                              msgid  = 'ZDL_SYLVAMO_3PP'
                              msgno  = '099'
                        msgv1  = ls_vbpok_tab-vbeln_vl ) to gt_messages.
*--------------------------------------------------------------------
*             Pick and Pack HU
*--------------------------------------------------------------------
              zcl_dl_e3637_dcgr_checks=>pick_pack_hu(
              exporting
                iv_obd_dlvry = ls_vbpok_tab-vbeln_vl
                is_vbkok     = value #( vbeln_vl = ls_vbpok_tab-vbeln_vl
                                      kzbrg    = abap_true
                                      kzntg    = abap_true
                                      komue    = abap_true
                                      lifex    = ls_inb_dlvry-vbeln
                                      gewei    = ls_inb_dlvry-gewei
                                      brgew    = lv_brgew
                                      ntgew    = lv_ntgew )
                it_vbpok     = lt_vbpok_pp
              importing
                et_port = data(lt_prot)
                ev_subrc = data(lv_subrc)
                et_messages = lt_messages ).

              if lt_messages is not initial.
***  2000000330 - start
*               append lines of lt_messages to gt_messages.
                msg_add_bal( exporting iv_notifobj    = ls_vbpok_tab-vbeln_vl
                                       iv_notifobjtyp = 'O'
                                       it_balmsg      = lt_messages ).
***  2000000330 - end
                clear lt_messages.

                clear: ls_obd_dlvry,
                       ls_inb_dlvry,
                       lt_vbpok,
                       lt_outbound_data,
                       lr_new_outbound,
                       lv_lock,
                       lv_po_user,
                       lv_so_user,
                       lv_error,
                 lv_shipment.
                lv_subrc = 4.
              endif.
*--------------------------------------------------------------------
*    If a failure occurred where the pick/pack HU process then
*    delete of the outbound delivery
*--------------------------------------------------------------------
              if lv_subrc <> 0.
                loop at lt_prot into data(ls_prot).
                  append value #( notifobj    = ls_vbpok_tab-vbeln_vl
                                  notifobjtyp = 'O'
                                  msgty  = ls_prot-msgty
                                  msgid  = ls_prot-msgid
                                  msgno  = ls_prot-msgno
                                  msgv1  = ls_prot-msgv1
                                  msgv2  = ls_prot-msgv2
                                  msgv3  = ls_prot-msgv3
                                  msgv4  = ls_prot-msgv4 ) to gt_messages.
                endloop.
** Capture application log.
                append value #( msgty  = gc_success
                                msgid  = 'ZDL_SYLVAMO_3PP'
                                msgno  = '083'
                        msgv1  = ls_vbpok_tab-vbeln_vl ) to gt_messages.

                zcl_dl_e3637_dcgr_checks=>delete_delivery(
                  exporting
                    iv_delivery =
                conv bapiobdlvhdrchg-deliv_numb( ls_vbpok_tab-vbeln_vl )
                  importing
                    et_return   = data(lt_return) ).

                if lt_return is not initial.
                  data(lt_messages_del) =
                   value zca_bal_msg_tab( for ls_return_del in lt_return
                                        ( msgty  = ls_return_del-type
                                           msgid  = ls_return_del-id
                                           msgno  = ls_return_del-number
                                       msgv1  = ls_return_del-message_v1
                                       msgv2  = ls_return_del-message_v2
                                       msgv3  = ls_return_del-message_v3
                                  msgv4  = ls_return_del-message_v4 ) ).

***  2000000330 - start
*                 append lines of lt_messages_del to gt_messages.
                  msg_add_bal( exporting iv_notifobj    = ls_vbpok_tab-vbeln_vl
                                         iv_notifobjtyp = 'O'
                                         it_balmsg      = lt_messages_del ).
***  2000000330 - end
                  clear lt_messages_del.
                else.
                  append value #( msgty  = gc_success
                                  msgid  = 'ZDL_SYLVAMO_3PP'
                                  msgno  = '084'
                        msgv1  = ls_vbpok_tab-vbeln_vl ) to gt_messages.
                endif.
              else.
                append value #( msgty  = gc_success
                                msgid  = 'ZDL_SYLVAMO_3PP'
                                msgno  = '100'
                        msgv1  = ls_vbpok_tab-vbeln_vl ) to gt_messages.
                data(lv_success) = abap_true.
              endif.
              clear:lv_brgew,
                    lv_ntgew,
                    lt_vbpok_pp.
            endat.
          endloop.
        endif.
        if lv_success = abap_true.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '104'
                          msgv1  = ls_inb_dlvry-vbeln ) to gt_messages.
        endif.
********************* picking and packing process - END

        clear: ls_obd_dlvry,
               ls_inb_dlvry,
               lt_vbpok,
               lt_outbound_data,
               lr_new_outbound,
               lv_lock,
               lv_po_user,
               lv_so_user,
               lv_success,
               lv_error,
               lv_shipment.
      endat."VBELN
    endloop.
  endmethod.

  method fill_pick_with_obd.
    clear et_vbpok.
    select *
      from lips
      into table @data(lt_lips_obd)
      where vbeln in @ir_obd_dlvry.
    if sy-subrc <> 0.
      clear lt_lips_obd.
    endif.
***** 2000000330 - lines below commented out
*    if iv_vrkme = 'RL'.
* Fill pick pack table with new outbound delivery number.
*      et_vbpok = value #( for ls_vbpok in it_vbpok
*                              for ls_lips_obd in lt_lips_obd
*                              where ( vgbel = ls_vbpok-vbeln_vl and
*                                      vgpos = ls_vbpok-posnr_vl )
*                          ( vbeln_vl = ls_lips_obd-vbeln
*                            vbeln    = ls_lips_obd-vbeln
*                            posnr_vl = ls_lips_obd-posnr
*                            posnn    = ls_lips_obd-posnr
*                            vbtyp_n  = 'Q'
*                            matnr    = ls_vbpok-matnr
*                            charg    = ls_vbpok-charg
*                            werks    = ls_vbpok-werks
*                            taqui    = abap_true
*                            kzntg    = abap_true
*                            kzbrg    = abap_true
*                            umvkz    = ls_vbpok-pikmg
*                            umvkn    = 1
*                            vrkme    = 'RL'
*                            pikmg    = ls_vbpok-pikmg
*                            brgew    = ls_vbpok-brgew
*                            ntgew    = ls_vbpok-ntgew
*                            meins    = ls_vbpok-meins
*                            gewei    = ls_vbpok-gewei
*                            lgort    = ls_vbpok-lgort ) ).
*    else.
***** 2000000330 - end lines commented out

* Fill pick pack table with new outbound delivery number.
    et_vbpok = value #( for ls_vbpok in it_vbpok
                            for ls_lips_obd in lt_lips_obd
                            where ( vgbel = ls_vbpok-vbeln_vl and
                                    vgpos = ls_vbpok-posnr_vl )
                        ( vbeln_vl = ls_lips_obd-vbeln
                          vbeln    = ls_lips_obd-vbeln
                          posnr_vl = ls_lips_obd-posnr
                          posnn    = ls_lips_obd-posnr
                          vbtyp_n  = 'Q'
                          matnr    = ls_vbpok-matnr
                          charg    = ls_vbpok-charg
                          werks    = ls_vbpok-werks
                          taqui    = abap_true
                          kzntg    = abap_true
                          kzbrg    = abap_true
                          pikmg    = ls_vbpok-pikmg
                          meins    = ls_vbpok-meins
                          brgew    = ls_vbpok-brgew
                          ntgew    = ls_vbpok-ntgew
                          gewei    = ls_vbpok-gewei
                          lgort    = ls_vbpok-lgort ) ).
*  endif.                                                           "2000000330
  endmethod.

  method compare_batches.
* Compare outbound delivery batches with inbound delivery batches.
* get all outbound delivery batches in a range table, so the it can be deleted in one go.
    data(lr_batches) = value bicbh_t_charg( for ls_batch in et_obd_dlvry
                                                ( sign = 'I'
                                                  option = 'EQ'
                                               low = ls_batch-charg ) ).
    delete lr_batches where low is initial.
    if lr_batches is not initial.
      delete ct_inb_dlvry where charg in lr_batches.
    endif.
  endmethod.
  method get_obd_line_itm.
    clear et_lips.

* Get the date filed changed to current date.
    data(lr_date) = value /ibx/ty_create_date_ran( for ls_date in so_erdat
                                               ( sign   = ls_date-sign
                                                 option = 'BT'
                                                 low    = ls_date-low
                                                 high   = sy-datum ) ).

    check it_lips is not initial.
* At this point, we have all Inbound deliveries that are open and
*Inbound deliveries that are completed but no outbound delivery.
*Now we have to select all item level information for the above Inbound
*deliverys.
    select vbeln,
           posnr,
           matnr,
           werks,
           lgort,
           charg,
           lfimg,
           vrkme,
           meins,
           umvkz,
           umvkn,
           ntgew,
           brgew,
           gewei,
           lgmng,
           vbelv,
           posnv,
           vgbel,
           vgpos
      from lips
      into corresponding fields of table @et_lips
      for all entries in @it_lips
      where erdat in @lr_date and
            matnr = @it_lips-matnr and
            werks = @it_lips-werks and
            vgbel = @it_lips-vbelv and
            vgpos = @it_lips-posnv and
            vgtyp = 'C'.

    if sy-subrc = 0.
*Eliminate LIPS line items where Actual Delivery quantity LFIMG is blank.
      delete et_lips where lfimg is initial.
    endif.
  endmethod.

  method screen_modify.
*    loop at screen.
*      case screen-group1.
*        when 'MD1'.
*          screen-input = 0.
*          screen-invisible = 1.
*          modify screen.
*        when 'MSX'.
*          if sp_shipm  = ' '.
*            screen-input = 0.
*            clear: sp_stats.
*          else.
*            screen-input = 1.
*          endif.
*          modify screen.
*      endcase.
*    endloop.
  endmethod.

  method matnr_lock.
* Check if the material is locked. If the material is locked, then it will fail while
* Posting a GR
    call function 'ENQUEUE_EMMARAE'
      exporting
        mode_mara      = 'E'
        mandt          = sy-mandt
        matnr          = iv_matnr
      exceptions
        foreign_lock   = 1
        system_failure = 2
        others         = 3.
    if sy-subrc <> 0.
      ev_lock = abap_true.
      ev_matnr_user = sy-msgv1.
    else.
      call function 'DEQUEUE_EMMARAE'
        exporting
          mode_mara = 'E'
          mandt     = sy-mandt
          matnr     = iv_matnr.
      clear: ev_lock,
             ev_matnr_user.
    endif.
  endmethod.

***** hmalkow - start
*&---------------------------------------------------------------------*
*&      Method  SHIPMENT_SETUP
*&---------------------------------------------------------------------*
*       Set up the data to pass into Shipment Create Bapi
*----------------------------------------------------------------------*
  method shipment_setup.
    data: ls_headerdeadline type bapishipmentheaderdeadline.
    data: ls_itemdata       type bapishipmentitem.
    data: ls_stagedata      type bapishipmentstage.
    data: ls_stagedeadline  type bapishipmentstagedeadline.
    data: ls_itemonstage    type bapishipmentitemonstage.
    data: lv_sdate type sy-datum.
    data: lv_stime type sy-uzeit.

    clear:   gs_headerdata.
    refresh: gt_headerdeadline.
    refresh: gt_itemdata.
    refresh: gt_stagedata.
    refresh: gt_stagedeadline.
    refresh: gt_itemonstage.

    "--- Inboud delivery header data
    select single * from likp into @data(ls_inbdel)
      where vbeln = @iv_inbdel.

    "---Headerdata setup
    data(lv_service_agent) = get_service_agent( ls_inbdel-vbeln ).

    gs_headerdata-shipment_num  = ls_inbdel-bolnr.

    gs_headerdata-shipment_type = ls_inbdel-zz_shtyp.
    gs_headerdata-external_id_1 = ls_inbdel-zz_seal.    "Seal
    gs_headerdata-container_id  = ls_inbdel-zz_signi.   "Container ID
    gs_headerdata-shipping_cond = ls_inbdel-vsbed.      "Shipping Condition
    "gs_headerdata-external_id_2 =
    gs_headerdata-status_plan       = 'X'.
    gs_headerdata-status_load_start = 'X'.
    gs_headerdata-status_load_end   = 'X'.
    gs_headerdata-service_agent_id  = lv_service_agent. "Number of forwarding agent
    gs_headerdata-time_travel = 0.
    gs_headerdata-time_total = 0.
    gs_headerdata-time_unit = ztp_constants=>time_unit_s.
    gs_headerdata-time_unit_iso = ztp_constants=>seconds. "SEC

    "---Header deadline setup
    data(lv_timezone) = get_plant_time_zone( ls_inbdel-vstel ).

***** 2000000264 - start
    get_status_date_time( exporting is_likp = ls_inbdel
                          changing  cv_date = lv_sdate
                                    cv_time = lv_stime ).
***** 2000000264 - end

    data(lv_timestamp) = get_time_stamp( exporting
***** 2000000264 - start
                                           iv_date = lv_sdate
                                           iv_time = lv_stime ).
***** 2000000264 - end
***** 2000000264 - lines below commented out
*                                          iv_date = ls_inbdel-lfdat
*                                          iv_time = ls_inbdel-erzet  ).
***** 2000000264 - end lines commented out
***  2000000330 - start
    lv_timezone = 'UTC'.
***  2000000330 - end

    ls_headerdeadline-time_type = ztp_constants=>stpldt. "Planned Date
    ls_headerdeadline-time_stamp_utc = lv_timestamp.
    ls_headerdeadline-time_zone = lv_timezone.
    append ls_headerdeadline to gt_headerdeadline.

    ls_headerdeadline-time_type = ztp_constants=>stpladt."Check-in
    ls_headerdeadline-time_stamp_utc = lv_timestamp.
    ls_headerdeadline-time_zone = lv_timezone.
    append ls_headerdeadline to gt_headerdeadline.

    ls_headerdeadline-time_type = ztp_constants=>stlspdt."Load start plan
    ls_headerdeadline-time_stamp_utc = lv_timestamp.
    ls_headerdeadline-time_zone = lv_timezone.
    append ls_headerdeadline to gt_headerdeadline.

    ls_headerdeadline-time_type = ztp_constants=>stlepdt. "Load end plan
    ls_headerdeadline-time_stamp_utc = lv_timestamp.
    ls_headerdeadline-time_zone = lv_timezone.
    append ls_headerdeadline to gt_headerdeadline.

    ls_headerdeadline-time_type = ztp_constants=>stlsadt."Load start actual
    ls_headerdeadline-time_stamp_utc = lv_timestamp.
    ls_headerdeadline-time_zone = lv_timezone.
    append ls_headerdeadline to gt_headerdeadline.

    ls_headerdeadline-time_type = ztp_constants=>stleadt. "Load end actual
    ls_headerdeadline-time_stamp_utc = lv_timestamp.
    ls_headerdeadline-time_zone = lv_timezone.
    append ls_headerdeadline to gt_headerdeadline.

    "---ItemData setup and ItemOnStage setup
    loop at it_ovbeln into data(ls_ovbeln).

      "--- Outbound delivery header data
      select single * from likp into @data(ls_outdel)
        where vbeln = @ls_ovbeln-outdel.

      out_del_update_route( exporting
                              iv_outdel = ls_outdel-vbeln
                              is_inbdel = ls_inbdel ).

      ls_itemdata-delivery = ls_outdel-vbeln.
      ls_itemdata-itenerary = 0001.
      append ls_itemdata to gt_itemdata.

      ls_itemonstage-stage_seq = 0001.
      ls_itemonstage-delivery = ls_outdel-vbeln.
      append ls_itemonstage to gt_itemonstage.

    endloop.

    "---StageData Setup
    ls_stagedata-stage_cat = 1.
    ls_stagedata-stage_seq = 0001.
    ls_stagedata-shipping_type = ls_inbdel-vsart.
    ls_stagedata-org_shipp_dpmnt = ls_outdel-vstel.
    ls_stagedata-dest_cust = ls_outdel-kunnr.
    ls_stagedata-service_agent = lv_service_agent.
    ls_stagedata-distance = '0.000'.
    ls_stagedata-time_travel = 0.
    ls_stagedata-time_total = 0.
    ls_stagedata-time_unit = ztp_constants=>time_unit_s.
    ls_stagedata-time_unit_iso = ztp_constants=>seconds. "SEC
    append ls_stagedata to gt_stagedata.

    "---StageDeadline Setup
    ls_stagedeadline-stage_seq = 0001.
    ls_stagedeadline-time_type = ztp_constants=>lenpdt.
    ls_stagedeadline-time_stamp_utc = lv_timestamp.
    ls_stagedeadline-time_zone = lv_timezone.
    append ls_stagedeadline to gt_stagedeadline.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_SERVICE_AGENT
*&---------------------------------------------------------------------*
*      Get Service Agent
*----------------------------------------------------------------------*
  method get_service_agent.
DATA: lv_loevm type LOEVM_X.                             "Added by SPADASA/2000002878/S0VK913003
    select single zz_scac from likp into @data(lv_scac)
      where vbeln = @iv_vbeln.

    if sy-subrc = 0.
      if lv_scac is initial.
        rv_lifnr = space.
      else.
*Begin of changes SPADASA/2000002878/S0VK913003
*        select lifnr up to 1 rows from lfa1 into rv_lifnr
*          where scacd = lv_scac.
        SELECT single lifnr loevm into (rv_lifnr,lv_loevm)
          from lfa1
          where scacd = lv_scac.
          if sy-subrc is initial.
            if lv_loevm = abap_true.
              rv_lifnr = space.
            endif.
          endif.
*        endselect.
*End of changes SPADASA/2000002878/S0VK913003
      endif.
    else.
      rv_lifnr = space.
    endif.
  endmethod.
*&---------------------------------------------------------------------*
*&      Method  SHIPMENT_CREATE
*&---------------------------------------------------------------------*
*      Create Outbound shipment assigning the outbound delivery created
*----------------------------------------------------------------------*
  method shipment_create.
    data: lt_return   type standard table of bapiret2.
    data: lv_shipment type bapishipmentids-shipmentnum.
    data: ls_return type bapiret2.

    check sp_shipm is not initial.

    "---Set up the data to pass into Shipment Create Bapi
    shipment_setup( exporting iv_inbdel = iv_inbdel
                              it_ovbeln = it_ovbeln ).

    call function 'BAPI_SHIPMENT_CREATE'
      exporting
        headerdata     = gs_headerdata
      importing
        transport      = lv_shipment
      tables
        headerdeadline = gt_headerdeadline
        itemdata       = gt_itemdata
        stagedata      = gt_stagedata
        stagedeadline  = gt_stagedeadline
        itemonstage    = gt_itemonstage
        return         = lt_return.

    "---Log the messages from the Shipment Create Bapi
    msg_add_bapiret( exporting iv_notifobj    = gs_headerdata-shipment_num
                               iv_notifobjtyp = 'S'
                               it_bapiret     = lt_return ).

    "If a shipment fails to be created, rollback created deliveries.
    if lv_shipment is initial.
      call function 'BAPI_TRANSACTION_ROLLBACK'.
    else.
      rv_tknum = lv_shipment.
      "If a shipment is created, commit it to the database.
      call function 'BAPI_TRANSACTION_COMMIT'
        exporting
          wait = 'X'.
    endif.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  SHIPMENT_STATUS_UPDATE
*&---------------------------------------------------------------------*
*       Set Shipment status to Shipment Complete
*----------------------------------------------------------------------*
  method shipment_status_update.
    data: ls_z1eds01 type z1eds01.
    data: lt_z1edstz type standard table of z1edstz.
    data: ls_z1edstz type z1edstz.
    data: lt_z1edstc type standard table of z1edstc.
    data: ls_z1edstc type z1edstc.
    data: lt_return type standard table of bapiret2.
    data: lv_date  type sy-datum.
    data: lv_time  type sy-uzeit.
    data: lv_sdate type sy-datum.
    data: lv_stime type sy-uzeit.

    check sp_stats is not initial.

    select single * from likp into @data(ls_likp)
      where vbeln = @iv_inbdel.

    select single * from vttk into @data(ls_vttk)
      where tknum = @iv_tknum.

    select single * from vtts into @data(ls_vtts)
      where tknum = @iv_tknum
        and tsnum = 0001. "???

    ls_z1eds01-tknum = ls_vttk-tknum.
    ls_z1eds01-shtyp = ls_vttk-shtyp.
    ls_z1eds01-tsnum = ls_vtts-tsnum.
    ls_z1eds01-vstel = ls_vtts-vstel.

    ls_z1edstz-qualf = 'Z90'.

    data(lv_timezone) = get_plant_time_zone( ls_likp-vstel ).
***  2000000330 - start
    lv_timezone = 'UTC'.
***  2000000330 - end
***** 2000000264 - start
    get_status_date_time( exporting is_likp = ls_likp
                          changing  cv_date = lv_sdate
                                    cv_time = lv_stime ).
***** 2000000264 - end

    data(lv_timestamp) = get_time_stamp( exporting
***** 2000000264 - start
                                           iv_date = lv_sdate
                                           iv_time = lv_stime  ).
***** 2000000264 - end
***** 2000000264 - lines below commented out
*                                          iv_date = ls_likp-lfdat
*                                          iv_time = ls_likp-erzet  ).
***** 2000000264 - end lines commented out
    convert time stamp lv_timestamp time zone lv_timezone into
      date lv_date time lv_time.

    ls_z1edstz-ntanf = lv_date.
    ls_z1edstz-ntanz = lv_time.
    append ls_z1edstz to lt_z1edstz.

    ls_z1edstc-qualf = 'S01'.
    ls_z1edstc-param = ls_likp-zz_seal.
    append ls_z1edstc to lt_z1edstc.

    call function 'ZDL_PROCESS_SHPSTAT'
      exporting
        is_z1eds01 = ls_z1eds01
        iv_source  = 'R3TR'
        iv_commit  = abap_true
      tables
        it_z1edstz = lt_z1edstz
        it_z1edstc = lt_z1edstc
        et_errors  = lt_return.

    msg_add_bapiret( exporting iv_notifobj    = ls_vttk-tknum
                               iv_notifobjtyp = 'S'
                               it_bapiret     = lt_return ).

    if msg_err_bapiret( lt_return ) = abap_true.
      rv_error = 'X'.
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_PLANT_TIME_ZONE
*&---------------------------------------------------------------------*
*       Get Plant Time Zone
*----------------------------------------------------------------------*
  method get_plant_time_zone.

    select single * from t001w into @data(lv_t001w)
      where werks = @iv_werks.

    if sy-subrc = 0.

      call function 'TZON_LOCATION_TIMEZONE'
        exporting
          if_country        = lv_t001w-land1
          if_region         = lv_t001w-regio
        importing
          ef_timezone       = rv_timezone
        exceptions
          no_timezone_found = 1.

      if sy-subrc <> 0.
        clear: rv_timezone.
      endif.
    endif.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_TIME_STAMP
*&---------------------------------------------------------------------*
*       Get Time Stamp
*----------------------------------------------------------------------*
  method get_time_stamp.

    if iv_zone is supplied.

      call function 'CONVERT_INTO_TIMESTAMP'
        exporting
          i_datlo     = iv_date
          i_timlo     = iv_time
          i_tzone     = iv_zone
        importing
          e_timestamp = rv_timestamp.
    else.

      call function 'CONVERT_INTO_TIMESTAMP'
        exporting
          i_datlo     = iv_date
          i_timlo     = iv_time
***  2000000330 - start
          i_tzone     = 'UTC'
***  2000000330 - end
        importing
          e_timestamp = rv_timestamp.
    endif.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  MSG_ADD_BAPIRET
*&---------------------------------------------------------------------*
*       Add Bapi messages to table GT_MESSAGES
*----------------------------------------------------------------------*
  method msg_add_bapiret.
    data: lt_messages type zca_bal_msg_tab.

    lt_messages = value #( for ls_bapiret  in it_bapiret
                              (  msgty  = ls_bapiret-type
                                 msgid  = ls_bapiret-id
                                 msgno  = ls_bapiret-number
                                 msgv1  = ls_bapiret-message_v1
                                 msgv2  = ls_bapiret-message_v2
                                 msgv3  = ls_bapiret-message_v3
                                 msgv4  = ls_bapiret-message_v4  ) ).

    "delete adjacent duplicates from lt_messages.

    msg_add_bal( exporting iv_notifobj    = iv_notifobj
                           iv_notifobjtyp = iv_notifobjtyp
                           it_balmsg      = lt_messages ).

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  MSG_ADD_BAL
*&---------------------------------------------------------------------*
*       Add BAL messages to table GT_MESSAGES
*----------------------------------------------------------------------*
  method msg_add_bal.
    data: lt_balmsg type zca_bal_msg_tab.
    data: ls_messages type t_messages.

    "lt_balmsg[] = it_balmsg[].
    "delete adjacent duplicates from lt_balmsg.

    loop at it_balmsg into data(ls_mess).
      ls_messages = corresponding #( ls_mess ).
      if iv_notifobj is supplied.
        ls_messages-notifobj = iv_notifobj.
      endif.
      if iv_notifobjtyp is supplied.
        ls_messages-notifobjtyp = iv_notifobjtyp.
      endif.
      append ls_messages to gt_messages.
    endloop.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  MSG_ADD_EMPTY
*&---------------------------------------------------------------------*
*       Add empty line
*----------------------------------------------------------------------*
  method msg_add_empty.

    append value #( msgty  = gc_success
                    msgid  = 'ZDL_SYLVAMO_3PP'
                    msgno  = '101'
                    msgv1  = space ) to gt_messages.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  MSG_ERR_BAPIRET
*&---------------------------------------------------------------------*
*       Check if table consists any  Error message
*----------------------------------------------------------------------*
  method msg_err_bapiret.

    data(ls_return) = value #( it_bapiret[ type = 'E' ] optional ).

    if ls_return is not initial.
      rv_error = 'X'.
    endif.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  UNLOCK
*&---------------------------------------------------------------------*
*       Unlock All
*----------------------------------------------------------------------*
  method unlock.

    commit work and wait.

    call function 'DEQUEUE_ALL'.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  OUT_DEL_UPDATE_ROUTE
*&---------------------------------------------------------------------*
*       Outbound Delivery Update Route
*----------------------------------------------------------------------*
  method out_del_update_route.
    data: ls_header_data type bapiobdlvhdrchg.
    data: lt_header_control type table of  bapiobdlvhdrctrlchg,
          ls_header_control type bapiobdlvhdrctrlchg.
    data: lt_return  type table of  bapiret2.
    data: lv_delivery type vbeln_vl.
    data: lv_route type route.

***** 2000000248 - start
"--Only determine route Where "SP_VL01N (Run Create Out.delivery wrt SO) = 'X "CD2000000744
    IF SP_VL01N IS NOT INITIAL.                           "CD2000000744

     if is_inbdel-route is initial.
      "---Read ZDL_FIELDS for default route
      select * from zdl_fields up to 1 rows into @data(ls_zdl_fields)
        where category  = 'E11734'
          and fieldname = 'ROUTE'.
      endselect.
      lv_route = ls_zdl_fields-lowval.
      if lv_route is initial. return. endif.
     else.
      lv_route = is_inbdel-route.
     endif.
***** 2000000248 - end

    ls_header_data-deliv_numb = iv_outdel.
    ls_header_data-route = lv_route.

    ls_header_control-deliv_numb = iv_outdel.
    ls_header_control-route_flg = 'X'.

    lv_delivery = iv_outdel.

    call function 'BAPI_OUTB_DELIVERY_CHANGE'
      exporting
        header_data    = ls_header_data
        header_control = ls_header_control
        delivery       = lv_delivery
      tables
        return         = lt_return.

    if msg_err_bapiret( lt_return ) = 'X'.
      call function 'BAPI_TRANSACTION_ROLLBACK'.
    else.
      call function 'BAPI_TRANSACTION_COMMIT'
        exporting
          wait = 'X'.
    endif.

   ENDIF.                                               "CD2000000744

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  UPDATE_PROCESS_TAB
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
  method update_process_tab.

    loop at ir_outdel into data(ls_outdel).
      clear: ms_process.
      ms_process-processed = abap_true.

      if iv_inbdel is initial.
        ms_process-processed = abap_false.
      else.
        ms_process-inbdel = iv_inbdel.
        select single bolnr from likp into ms_process-inbbolnr
          where vbeln = ms_process-inbdel.

        if ms_process-inbbolnr is initial.
          clear: ms_process-processed.
        endif.
      endif.

      if ls_outdel-low is initial.
        ms_process-processed = abap_false.
      else.
        ms_process-outdel = ls_outdel-low.
        ms_process-outbolnr = ms_process-inbbolnr.
*      select single bolnr from likp into ms_process-outbolnr
*        where vbeln = iv_outdel.
      endif.

      if ms_process-processed = abap_true.
        append ms_process to mt_process.
      endif.

    endloop.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  PROCESS_SHP
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
  method process_shp.

    data: ls_process  type t_process.
    data: lt_process  type tt_process.
    data: lv_error    type abap_bool.
    data: lv_shipment type tknum.
    data: lv_outdeliveries type symsgv.
    data: lv_inbdelivery type symsgv.
    data: lt_ibd_bolnr type tt_ibd_bolnr.

***  2000000330 - start
    loop at mt_process  into data(ls_proc).
      if ( mr_err_vbeln[] is not initial and ls_proc-inbdel in mr_err_vbeln[] ) or
         ( mr_err_bolnr[] is not initial and ls_proc-inbbolnr in mr_err_bolnr[] ).

        delete mt_process.
      endif.
    endloop.
***  2000000330 - end

    "--- Group the outbound deliveries of the same BOLNR (from the inbound it was created from)
    loop at mt_process assigning field-symbol(<ls_process>)
                                    group by ( outbolnr = <ls_process>-outbolnr
                                              )
                                    ascending
                                    assigning field-symbol(<ls_group_key>).

      refresh lt_process[].
      refresh lt_ibd_bolnr[].
      data(ls_members) = value tt_process( ).

      loop at group <ls_group_key> assigning field-symbol(<ls_member>).
        ls_members = value #( base ls_members ( <ls_member> ) ).

        ls_process = corresponding #( <ls_member> ).

        append ls_process to lt_process.

      endloop.

      "-------- Create a Shipment --------
      if sp_shipm is not initial.
        clear: lv_outdeliveries.
        clear: ls_process.

        lv_outdeliveries = get_delivery_list( exporting iv_inbout  = 'O'
                                                        it_process = lt_process ).
        if lt_process[] is not initial.
          ls_process = lt_process[ 1 ].
        else.
          return.
        endif.

        unlock( ).

        append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '111'
                          msgv1  = ls_process-outbolnr
                          msgv2  = lv_outdeliveries ) to gt_messages.

***** 2000000264 - start
        lt_ibd_bolnr = corresponding #( lt_process mapping vbeln = inbdel
                                                           bolnr = inbbolnr ).

        if check_inbound_delivery( exporting iv_err = 'S'
                                   changing  ct_ibd_bolnr = lt_ibd_bolnr  ) = 'X'.
          continue.
        endif.
***** 2000000264 - end

        lv_shipment =
          shipment_create( exporting iv_inbdel = ls_process-inbdel
                                     it_ovbeln = lt_process ).
        if lv_shipment is not initial.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '066'
                          msgv1  = lv_shipment ) to gt_messages.
        else.

          continue.
        endif.
      endif.

      "-------- Update Shipment Status to Shipment Complete (status 5) ---------
      if sp_stats is not initial and
         ( lv_shipment is not initial or sp_shipm is initial ).

        if lv_shipment is initial.
          lv_shipment = get_shipment( ls_process-outdel ).
        endif.

        append value #( msgty  = gc_success
                        msgid  = 'ZDL_SYLVAMO_3PP'
                        msgno  = '112'
                        msgv1  = lv_shipment ) to gt_messages.

        lv_error = shipment_status_update( exporting iv_tknum  = lv_shipment
                                                     iv_inbdel = ls_process-inbdel ).

        if lv_error is initial.
          append value #( msgty  = gc_success
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '110'
                          msgv1  = lv_shipment ) to gt_messages.
        else.
          continue.
        endif.
      endif.

    endloop.

  endmethod.


*&---------------------------------------------------------------------*
*&      Method  CHECK_BATCHES
*&---------------------------------------------------------------------*
*       Check in to ensure all of the batches in LIPS are packed into a
*       handling unit that is on the Inbound Delivery
*----------------------------------------------------------------------*
  method check_batches.
    data: lv_inbdeliveries type symsgv.

    select single
      vbeln,
      bolnr,
      vstel,
      lfart
    from likp into @data(ls_inbdel)
      where vbeln = @iv_vbeln.

    "--- Get all Inbound Delivery with the same BOLNR
    select
       vbeln,
       bolnr,
       btgew,
       anzpk
     from likp into table @data(lt_likp)
       where bolnr = @ls_inbdel-bolnr
         and vstel = @ls_inbdel-vstel
         and lfart = @ls_inbdel-lfart.

***** 2000000248 - start
    delete lt_likp where btgew is initial and anzpk is initial.
***** 2000000248 - end

    if lt_likp[] is not initial.
      "--- Create a list of inbound deliveres with the same BOLNR
      loop at lt_likp into data(ls_list).
        if strlen( lv_inbdeliveries ) + strlen( ls_list-vbeln ) > 50.
          exit.
        else.
          lv_inbdeliveries = lv_inbdeliveries && ` ` && ls_list-vbeln.
        endif.
      endloop.

      lv_inbdeliveries = lv_inbdeliveries && `, (BOLNR = ` && ls_inbdel-bolnr && `)`.

      "---Fetch batches from LIPS
      select
        vbeln,
        matnr,
        charg
      from lips into table @data(lt_lips)
        for all entries in @lt_likp
      where vbeln = @lt_likp-vbeln
        and charg <> @space.

      if sy-subrc = 0.
        "--- Select the HU contents
        select
          venum,
          vbeln,
          matnr,
          charg
        from vepo into table @data(lt_vepo)
          for all entries in @lt_lips
        where matnr = @lt_lips-matnr
          and charg = @lt_lips-charg.
      endif.

      "--- Check if there is a mismatch here then we know not all
      "--- the batches in the delivery were packed in an HU

      data: lv_nlips type string.
      data: lv_nvepo type string.

      lv_nlips = lines( lt_lips ).
      lv_nvepo = lines( lt_vepo ).

      lv_nlips = condense( lv_nlips ).
      lv_nvepo = condense( lv_nvepo ).

      if lv_nlips <> lv_nvepo.
        "Not all batches in LIPS (&1) are packed into handling unit VEPO (&3)
        append value #( notifobj    = ls_inbdel-bolnr
                        notifobjtyp = 'B'
                        msgty  = gc_error
                        msgid  = 'ZDL_SYLVAMO_3PP'
                        msgno  = '113'
                        msgv1  = lv_nlips
                        msgv2  = lv_inbdeliveries
                        msgv3  = lv_nvepo ) to gt_messages.
        rv_return = 'X'.
        return.
      else.

        if lt_vepo[] is not initial.

          loop at lt_lips into data(ls_lips).

            data(ls_vepo) = value #( lt_vepo[ matnr = ls_lips-matnr charg = ls_lips-charg ] optional ) .

            if ls_vepo is initial.
              "Batch &1 is not packed into a handling unit
              append value #( notifobj    = ls_inbdel-bolnr
                              notifobjtyp = 'B'
                              msgty  = gc_error
                              msgid  = 'ZDL_SYLVAMO_3PP'
                              msgno  = '114'
                              msgv1  = ls_lips-charg ) to gt_messages.

              rv_return = 'X'.
              exit.
            else.
              "--- Check if the HU’s in VEPO are assigned to the inbound delivery
              data(ls_likp) = value #( lt_likp[ vbeln = ls_vepo-vbeln ] optional ).

              if ls_likp is initial.
                "HU &1 is not assigned to inbound delivery &2
***  hmalkow1 - start
                select single exidv from vekp into @data(lv_exidv) where venum = @ls_vepo-venum.
***  hmalkow1 - end

                append value #( notifobj    = ls_inbdel-bolnr
                                notifobjtyp = 'B'
                                msgty  = gc_error
                                msgid  = 'ZDL_SYLVAMO_3PP'
                                msgno  = '115'
                                msgv1  = lv_exidv
                                msgv2  = lv_inbdeliveries ) to gt_messages.

                rv_return = 'X'.
                exit.
              endif.

            endif.
          endloop.

        endif.

      endif.
    endif.


  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_SHIPMENT
*&---------------------------------------------------------------------*
*       Get Shipment for Outbound Delivery
*----------------------------------------------------------------------*
  method get_shipment.

    select
      tknum,
      tpnum,
      vbeln
    from vttp up to 1 rows into @data(ls_vttp)
      where vbeln = @iv_vbeln.
    endselect.

    if sy-subrc = 0.
      rv_tknum = ls_vttp-tknum.
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_BOLNR
*&---------------------------------------------------------------------*
*       Get BOLNR for Inbound Delivery
*----------------------------------------------------------------------*
  method get_bolnr.

    select single
      bolnr
    from likp into @data(lv_bolnr)
      where vbeln = @iv_vbeln.

    if sy-subrc = 0.
      rv_bolnr = lv_bolnr.
    endif.

  endmethod.
*&---------------------------------------------------------------------*
*&      Method  GET_OUTBOUND_DELIVERY
*&---------------------------------------------------------------------*
*       Get Outbound Deliveries for Inbound Delivery
*----------------------------------------------------------------------*
  method get_outbound_delivery.
    data: ls_outdel type line of fip_t_vbeln_range.

    select single
      vbeln,
      bolnr,
      vstel,
      lfart,
      erdat
    from likp into @data(ls_likp)
      where vbeln = @iv_vbeln.

    "--- Check if outbound delivery has been created
    select
      mandt,
      vbeln,
      bolnr,
      vstel,
      lfart
    from likp into table @data(lt_olikp)
      where erdat >= @ls_likp-erdat
        and lifex = @iv_vbeln
        and vstel = @ls_likp-vstel
        and lfart = 'LF'.

    if sy-subrc = 0.
      loop at lt_olikp into data(ls_olikp).
        ls_outdel-option = 'EQ'.
        ls_outdel-sign = 'I'.
        ls_outdel-low = ls_olikp-vbeln.
        append ls_outdel to rt_outdel.
      endloop.
    else.
      refresh: rt_outdel.
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  CHECK_GR
*&---------------------------------------------------------------------*
*       Check if the Inbound Delivery has been GR’d
*----------------------------------------------------------------------*
  method check_gr.

    select single
      vbeln,
      wadat_ist
    from likp into @data(ls_likp)
      where vbeln = @iv_vbeln.

    if ls_likp-wadat_ist is initial.
      "Inbound Delivery &1 has not been GR'd
      append value #( notifobj    = ls_likp-vbeln
                      notifobjtyp = 'I'
                      msgty  = gc_error
                      msgid  = 'ZDL_SYLVAMO_3PP'
                      msgno  = '116'
                      msgv1  = ls_likp-vbeln ) to gt_messages.

      rv_return = 'X'.
    else.
      rv_return = ' '.
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  CHECK_OUTBOUND_DELIVERY
*&---------------------------------------------------------------------*
*       Check if the outbound delivery has been created
*----------------------------------------------------------------------*
  method check_outbound_delivery.

    if get_outbound_delivery( iv_vbeln ) is initial.

      "Outbound Delivery for Inbound Delivery &1 has not been created
      append value #( notifobj    = iv_vbeln
                      notifobjtyp = 'I'
                      msgty  = gc_error
                      msgid  = 'ZDL_SYLVAMO_3PP'
                      msgno  = '117'
                      msgv1  = iv_vbeln ) to gt_messages.

      rv_return = 'X'.

    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  CHECK_PICKED_PACKED
*&---------------------------------------------------------------------*
*       Check if the outbound delivery has been Picked and Packed
*----------------------------------------------------------------------*
  method check_picked_packed.

    data(lt_outdel) = get_outbound_delivery( iv_vbeln ).

    if lt_outdel[] is not initial.

      select
        vbeln,
        kostk,
        pkstk
      from vbuk into table @data(lt_vbuk)
        where vbeln in @lt_outdel[].

      loop at lt_vbuk into data(ls_vbuk).
        if ls_vbuk-kostk <> 'C'.
          "Outbound Delivery &1 has not been fully Picked
          append value #( notifobj    = ls_vbuk-vbeln
                          notifobjtyp = 'O'
                          msgty  = gc_error
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '118'
                          msgv1  = ls_vbuk-vbeln ) to gt_messages.

          rv_return = 'X'.
        endif.

        if ls_vbuk-pkstk <> 'C'.
          "Outbound Delivery &1 has been fully Packed
          append value #( notifobj    = ls_vbuk-vbeln
                          notifobjtyp = 'O'
                          msgty  = gc_error
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '119'
                          msgv1  = ls_vbuk-vbeln ) to gt_messages.

          rv_return = 'X'.
        endif.
      endloop.
    endif.


  endmethod.

*&---------------------------------------------------------------------*
*&      Method  CHECK_SHP
*&---------------------------------------------------------------------*
*       Check if the shipment has been created
*----------------------------------------------------------------------*
  method check_shp.

    data(lt_outdel) = get_outbound_delivery( iv_vbeln ).

    if lt_outdel[] is not initial.

      loop at lt_outdel into data(ls_outdel).
        if get_shipment( ls_outdel-low ) is initial.

          "Shipment for Inbound/Outbound Delivery &1/&2 has not been created
          append value #( notifobj    = iv_vbeln
                          notifobjtyp = 'O'
                          msgty  = gc_error
                          msgid  = 'ZDL_SYLVAMO_3PP'
                          msgno  = '126'
                          msgv1  = iv_vbeln
                          msgv2  = ls_outdel-low ) to gt_messages.

          rv_return = 'X'.
        endif.
      endloop.
    endif.

  endmethod.


*&---------------------------------------------------------------------*
*&      Method  CHECK_ACTION
*&---------------------------------------------------------------------*
*      Perform checks depend on selected action
*----------------------------------------------------------------------*
  method check_action.

    clear: mv_action.

    if sp_posgr  = 'X'.  mv_action = mv_action + 2 ** 0.  endif.
    if sp_vl01n  = 'X'.  mv_action = mv_action + 2 ** 1.  endif.
    if sp_charg  = 'X'.  mv_action = mv_action + 2 ** 2.  endif.
    if sp_shipm  = 'X'.  mv_action = mv_action + 2 ** 3.  endif.
    if sp_stats  = 'X'.  mv_action = mv_action + 2 ** 4.  endif.

    if  sp_posgr is initial and
        sp_vl01n is initial and
        sp_charg is initial and
        sp_shipm is initial and
        sp_stats is initial.

      "Please select at least one action
      message e120(zdl_sylvamo_3pp).
    endif.

    if mv_action not in mr_proper_action[].
      "There must be no gaps between the first and last action selection
      message e121(zdl_sylvamo_3pp).
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_DATA_FOR_SHP
*&---------------------------------------------------------------------*
*      Get data for Shipment creating/updating
*----------------------------------------------------------------------*
  method get_data_for_shp.
    data: lv_err type abap_bool.
    data: lv_inbdeliveries type symsgv.
    data: lt_ibd_bolnr type tt_ibd_bolnr.
    data: lt_process type tt_process.
    data: ls_proc type t_process.
    data: ls_err_vbeln  type line of tt_err_vbeln.

    check sp_posgr is initial and
          sp_vl01n is initial and
          sp_charg is initial.

    refresh mr_err_bolnr[].
    refresh mr_err_vbeln[].

    select
      vbeln as inbdel,
      bolnr as inbbolnr,
      btgew,
      anzpk
    from likp into corresponding fields of table @lt_process
    where vbeln in @so_vbeln and
          vstel in @so_plant and
          erdat in @so_erdat and
          vsbed in @so_vsbed and
          vbtyp = '7'. " 7 Is for inbound delivery

***** 2000000248 - start
    delete lt_process where btgew is initial and anzpk is initial.
***** 2000000248 - end

***  2000000265 - start
    if lt_process[] is initial. return. endif.

    loop at lt_process into data(ls_process).
      clear ls_proc.
      ls_proc = ls_process.
      data(lr_outdel) = get_outbound_delivery( ls_process-inbdel ).
      loop at lr_outdel into data(ls_outdel).
        ls_proc-outdel = ls_outdel-low.
        append ls_proc to mt_process.
      endloop.
    endloop.
***  2000000265 - end

    loop at mt_process assigning field-symbol(<ls_process>).

***** 2000000265 - lines below commented out
*   <ls_process>-outdel = get_outbound_delivery( <ls_process>-inbdel ).
***** 2000000265 - end lines commented out

      if <ls_process>-outdel is not initial.
        <ls_process>-outbolnr = <ls_process>-inbbolnr.
        if get_shipment( <ls_process>-outdel ) is not initial.
          if sp_shipm = 'X'.
            delete mt_process.
          endif.
        else.
          if sp_stats = 'X' and sp_shipm = ' '.
            delete mt_process.
          endif.
        endif.
      else.
        delete mt_process.
      endif.

    endloop.

    if mt_process[] is initial.
      return.
    endif.

    lv_inbdeliveries = get_delivery_list( exporting iv_inbout  = 'I'
                                                    it_process = mt_process ).
    lv_inbdeliveries = lines( mt_process ).
    lv_inbdeliveries = condense( lv_inbdeliveries ).

    ">>>Attempting to data check
    append value #( msgty  = gc_success
                    msgid  = 'ZDL_SYLVAMO_3PP'
                    msgno  = '122'
                    msgv1  = lv_inbdeliveries ) to gt_messages.

***** 2000000261 - start
    lt_ibd_bolnr = corresponding #( mt_process mapping vbeln = inbdel
                                                       bolnr = inbbolnr ).

    if check_inbound_delivery( exporting iv_err = 'B'
                               changing  ct_ibd_bolnr = lt_ibd_bolnr  ) = 'X'.
      lv_err = 'X'.
    endif.
***** 2000000261 - end

    loop at mt_process into ls_process.
      if check_all_data( ls_process-inbdel ) = 'X'.
        lv_err = 'X'.
        ls_err_vbeln-option = 'EQ'.
        ls_err_vbeln-sign   = 'I'.
        ls_err_vbeln-low    = ls_process-inbdel.
        append ls_err_vbeln to mr_err_vbeln.
      endif.
    endloop.

    if lv_err = 'X'.
      mv_error = 'X'.
      return.
    else.
      "Data check was successful
      append value #( msgty  = gc_success
                      msgid  = 'ZDL_SYLVAMO_3PP'
                      msgno  = '123' ) to gt_messages.
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  INITIALIZATION
*&---------------------------------------------------------------------*
*      Initialization
*----------------------------------------------------------------------*
  method initialization.

    "--- Proper Actions - no gaps between first and last selected action
    "SP_POSGR   Run Post GR for Inb. Delivery   1   1       1           1               1
    "SP_VL01N   Run Create Out.delivery wrt SO  1   1   1   1   1       1   1              1
    "SP_CHARG   Run Split Batch, Pick & Pack    1   1   1   1   1   1       1   1             1
    "SP_SHIPM   Run Create Shpm & Asgn Out Del  1   1   1       1   1           1   1            1
    "SP_STATS   Run Shipm. Started Status Upd.  1       1           1               1                1
    "--------------------------------------------------------------------------------------------------
    "                                           31  15  30  7   14  28  3   6   12  24  1  2  4  8   16

    mr_proper_action = value tt_irange(
                        ( sign = 'I' option = 'EQ' low = 1 )
                        ( sign = 'I' option = 'EQ' low = 2 )
                        ( sign = 'I' option = 'EQ' low = 3 )
                        ( sign = 'I' option = 'EQ' low = 4 )
                        ( sign = 'I' option = 'EQ' low = 6 )
                        ( sign = 'I' option = 'EQ' low = 7 )
                        ( sign = 'I' option = 'EQ' low = 8 )
                        ( sign = 'I' option = 'EQ' low = 12 )
                        ( sign = 'I' option = 'EQ' low = 14 )
                        ( sign = 'I' option = 'EQ' low = 15 )
                        ( sign = 'I' option = 'EQ' low = 16 )
                        ( sign = 'I' option = 'EQ' low = 24 )
                        ( sign = 'I' option = 'EQ' low = 28 )
                        ( sign = 'I' option = 'EQ' low = 30 )
                        ( sign = 'I' option = 'EQ' low = 31 )
                         ).

    mr_need_gr_check = value tt_irange(
                       ( sign = 'I' option = 'EQ' low = 30 )
                       ( sign = 'I' option = 'EQ' low = 14 )
                       ( sign = 'I' option = 'EQ' low = 28 )
                       ( sign = 'I' option = 'EQ' low = 6 )
                       ( sign = 'I' option = 'EQ' low = 12 )
                       ( sign = 'I' option = 'EQ' low = 24 )
                       ( sign = 'I' option = 'EQ' low = 14 )
                       ( sign = 'I' option = 'EQ' low = 2 )
                       ( sign = 'I' option = 'EQ' low = 4 )
                       ( sign = 'I' option = 'EQ' low = 8 )
                       ( sign = 'I' option = 'EQ' low = 16 )
                        ).

    mr_need_outdel_check = value tt_irange(
                          ( sign = 'I' option = 'EQ' low = 28 )
                          ( sign = 'I' option = 'EQ' low = 12 )
                          ( sign = 'I' option = 'EQ' low = 24 )
                          ( sign = 'I' option = 'EQ' low = 4 )
                          ( sign = 'I' option = 'EQ' low = 8 )
                          ( sign = 'I' option = 'EQ' low = 16 )
                          ).

    mr_need_pick_pack_check = value tt_irange(
                              ( sign = 'I' option = 'EQ' low = 24 )
                              ( sign = 'I' option = 'EQ' low = 8 )
                              ( sign = 'I' option = 'EQ' low = 16 )
                              ).

    mr_need_shipment_check = value tt_irange(
                               ( sign = 'I' option = 'EQ' low = 16 )
                               ).

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  CHECK_ALL_DATA
*&---------------------------------------------------------------------*
*      Check Data
*----------------------------------------------------------------------*
  method check_all_data.

    if sp_posgr is not initial.
      if check_batches( iv_vbeln ) = 'X'.
        rv_return = 'X'.
      endif.
    endif.

    if mv_action in  mr_need_gr_check[].
      if check_gr( iv_vbeln ) = 'X'.
        rv_return = 'X'.
      endif.
    endif.

    if mv_action in  mr_need_outdel_check[].
      if check_outbound_delivery( iv_vbeln ) = 'X'.
        rv_return = 'X'.
      endif.
    endif.

    if mv_action in  mr_need_pick_pack_check[].
      if check_picked_packed( iv_vbeln ) = 'X'.
        rv_return = 'X'.
      endif.
    endif.

    if mv_action in  mr_need_shipment_check[].
      if check_shp( iv_vbeln ) = 'X'.
        rv_return = 'X'.
      endif.
    endif.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_DELIVERY_LIST
*&---------------------------------------------------------------------*
*       Get List of Delivieries for Shipment
*----------------------------------------------------------------------*
  method get_delivery_list.
    data: lv_delivlist type symsgv.
    data: lv_delivery  type vbeln_vl.

    loop at it_process into data(ls_proc).

      case iv_inbout.
        when 'I'.
          lv_delivery = ls_proc-inbdel.
        when 'O'.
          lv_delivery = ls_proc-outdel.
      endcase.

      if strlen( lv_delivlist ) + strlen( lv_delivery ) > 50.
        exit.
      else.
        lv_delivlist = lv_delivlist && ` ` && lv_delivery.
      endif.
    endloop.

    rv_return = lv_delivlist.

  endmethod.
***** hmalkow - end

*&---------------------------------------------------------------------*
*&      Method  CHECK_INBOUND_DELIVERY
*&---------------------------------------------------------------------*
*       Check if all Inbound Deliveries with the same BOLNR
*       are processed together
*       CD# 2000000261
*----------------------------------------------------------------------*
  method check_inbound_delivery.
    data: lt_ibd_bolnr type tt_ibd_bolnr.
    data: ls_ibd_bolnr type line of tt_ibd_bolnr.
    data: lv_cnt type i.
    data: lv_msgv2 type symsgv.
    data: lv_msgv3 type symsgv.
    data: lv_bolnr_check type abap_bool.
    data: ls_err_bolnr  type line of tt_err_bolnr.

    select
      lowval
    from zdl_fields up to 1 rows
      into @data(lv_check)
    where category  = 'E11734'
      and fieldname = 'BOLNR_CHECK'.
    endselect.

    if sy-subrc = 0.
      lv_bolnr_check = condense( lv_check ).
    endif.

    if lv_bolnr_check is initial. return. endif.

    delete adjacent duplicates from ct_ibd_bolnr comparing all fields.

    "Group table by BOLNR
    sort ct_ibd_bolnr by bolnr.
    lv_cnt = 0.

    loop at ct_ibd_bolnr into data(ls_ibd).
      lv_cnt = lv_cnt + 1.
      at end of bolnr.
        ls_ibd_bolnr-bolnr = ls_ibd-bolnr.
        ls_ibd_bolnr-cnt = lv_cnt.
        append ls_ibd_bolnr to lt_ibd_bolnr.
        clear: ls_ibd_bolnr.
        lv_cnt = 0.
      endat.
    endloop.

*   delete lt_ibd_bolnr where cnt <= 1.                     "2000000264
    delete lt_ibd_bolnr where cnt = 0.                      "2000000264

    loop at lt_ibd_bolnr into data(ls_bolnr).

      select
        count(*)
      from likp into @data(lv_likp_cnt)
        where bolnr = @ls_bolnr-bolnr
          and vstel in @so_plant
          and vbtyp = '7'
          and btgew <> 0
          and anzpk <> 0.

      if sy-subrc = 0 and ls_bolnr-cnt <> lv_likp_cnt.

        lv_msgv2 = ls_bolnr-cnt.
        lv_msgv3 = lv_likp_cnt.
        lv_msgv2 = condense( lv_msgv2 ).
        lv_msgv3 = condense( lv_msgv3 ).

        case iv_err.
          when 'B'.
            "Not all Inbound Deliveries with BOLNR = &1 are being processed (&2 <> &3)
            append value #( notifobj = ls_bolnr-bolnr
                            notifobjtyp = 'S'
                            msgty  = gc_error
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '127'
                            msgv1  = ls_bolnr-bolnr
                            msgv2  = lv_msgv2
                            msgv3  = lv_msgv3 ) to gt_messages.
***  2000000330 - start
            ls_err_bolnr-option = 'EQ'.
            ls_err_bolnr-sign   = 'I'.
            ls_err_bolnr-low    = ls_bolnr-bolnr.
            append ls_err_bolnr to mr_err_bolnr.
***  2000000330 - end
          when 'S'.
            "Shipment &1 should have assigned &2 Outbound Deliveries instead of &3
            append value #( notifobj = ls_bolnr-bolnr
                            notifobjtyp = 'S'
                            msgty  = gc_error
                            msgid  = 'ZDL_SYLVAMO_3PP'
                            msgno  = '128'
                            msgv1  = ls_bolnr-bolnr
                            msgv2  = lv_msgv3
                            msgv3  = lv_msgv2 ) to gt_messages.
***  2000000330 - start
            ls_err_bolnr-option = 'EQ'.
            ls_err_bolnr-sign   = 'I'.
            ls_err_bolnr-low    = ls_bolnr-bolnr.
            append ls_err_bolnr to mr_err_bolnr.
***  2000000330 - end
        endcase.

        rv_return = 'X'.
      endif.
    endloop.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  SUPPRESS_MESSAGES
*&---------------------------------------------------------------------*
*       Suppress messages definied in ZDL_FIELDS table
*       CD# 2000000261
*----------------------------------------------------------------------*
  method suppress_messages.
    data: lr_msg type range of zsp_lowval.

    select
      sign,
      optn as option,
      lowval as low
    from zdl_fields
      into table @lr_msg
    where category  = 'E11734'
      and fieldname = 'MESSAGE'.

    if  lr_msg[] is not initial.

      loop at gt_messages into data(ls_msg).
        if ls_msg-msgid && ls_msg-msgno && ls_msg-msgty in lr_msg[].
          delete gt_messages.
        endif.
      endloop.

    endif.
  endmethod.

*&---------------------------------------------------------------------*
*&      Method  GET_STATUS_DATE_TIME
*&---------------------------------------------------------------------*
*       Get shipment status date/time depend on ZDL_FIELDS entry
*       CD# 2000000264
*----------------------------------------------------------------------*
  method get_status_date_time.
    data: lv_status_dt type char1.

    select
      lowval
    from zdl_fields up to 1 rows
      into @data(lv_lowval)
    where category  = 'E11734'
      and fieldname = 'STATUS_DATE_TIME'.
    endselect.

    if sy-subrc <> 0 or lv_lowval is initial.
      lv_status_dt = '1'."default value
    else.
      lv_status_dt = condense( lv_lowval ).
    endif.

    case lv_status_dt.
      when '1'. " LIKP-LFDAT LIKP-ERZET
        cv_date = is_likp-lfdat.
        cv_time = is_likp-erzet.
      when '2'. " LIKP-WADAT LIKP-WAUHR
        cv_date = is_likp-wadat.
        cv_time = is_likp-wauhr.
***  2000000330 - start
      when '3'. " LIKP-ZZ_RCPT_DATE_FM LIKP-ZZ_RCPT_TIME_FM
        cv_date = is_likp-zz_rcpt_date_fm.
        cv_time = is_likp-zz_rcpt_time_fm.
***  2000000330 - end
    endcase.

  endmethod.

***  2000000330 - start
*&---------------------------------------------------------------------*
*&      Method  NOTIF_SEND
*&---------------------------------------------------------------------*
*       Send Notification - Ticket or Email depend on ZDL_FIELDS entries
*       CD# 2000000330
*----------------------------------------------------------------------*
  method notif_send.
    data: lv_subject type bcs_subject.

    notif_get_log_errors( ).
    notif_read_conf( ).

    if mv_notif_email = space and mv_notif_usd = space. return. endif. "2000000390

    loop at mt_errors into data(ls_errors).
      if ls_errors-msgty = 'E'.
        "Check notification setup
        data(ls_e11734_ntf) = notif_get_zdl_e11734( exporting is_error = ls_errors ).
        if ls_e11734_ntf is initial.
          "It is first error
          ls_e11734_ntf-notifobj = ls_errors-notifobj.
          ls_e11734_ntf-notifobjtyp = ls_errors-notifobjtyp.
          ls_e11734_ntf-msgid = ls_errors-msgid.
          ls_e11734_ntf-msgno = ls_errors-msgno.
          ls_e11734_ntf-errcounter = 1.
        else.
          ls_e11734_ntf-errcounter = ls_e11734_ntf-errcounter + 1.
        endif.

        if ls_e11734_ntf-errcounter >= mv_notif_threshold  and
           ls_e11734_ntf-errcounter <= mv_notif_max.
          "This error will be notified
          if mv_notif_email = 'X'.
            ls_e11734_ntf-emailcounter = ls_e11734_ntf-emailcounter + 1.
            ls_e11734_ntf-emaillastdate = ms_hlog-aldate.
            ls_e11734_ntf-emailasttime = ms_hlog-altime.
            ls_e11734_ntf-applog = lcl_3rd_party=>mv_lognum.
          endif.

          if mv_notif_usd = 'X'.
            ls_e11734_ntf-ticketcounter = ls_e11734_ntf-ticketcounter + 1.
            ls_e11734_ntf-ticketlastdate = ms_hlog-aldate.
            ls_e11734_ntf-ticketlasttime = ms_hlog-altime.
            ls_e11734_ntf-applog = lcl_3rd_party=>mv_lognum.
          endif.

          if mv_notif_email = 'X' or mv_notif_usd = 'X'.
            append ls_e11734_ntf to mt_e11734_ntf.
          endif.
        else.
          delete mt_errors.
        endif.
      endif.
    endloop.

    if mt_e11734_ntf is not initial.

      notif_create_text( ).
      lv_subject = 'E11734 failed in batch processing'(002).

      if mv_notif_email = 'X'.
        mv_mail_sent = notif_send_mail( lv_subject ).
      endif.

      if mv_notif_usd = 'X'.
        mv_usd_created = notif_usd( lv_subject ).
      endif.

      if mv_mail_sent = 'X' or mv_usd_created = 'X'.
        notif_not_sent( ).
        notif_upd_zdl_e11734( ).
      endif.

    endif.

  endmethod.
*&---------------------------------------------------------------------*
*&      Method  NOTIF_READ_CONF
*&---------------------------------------------------------------------*
*       Read configuration for error notification from ZDL_FIELDS
*       CD# 2000000330
*----------------------------------------------------------------------*
  method notif_read_conf.
    data: lv_str type string.

    select * from zdl_fields
      into table @data(lt_zdl_fields)
    where category = 'E11734'
      and fieldname like 'NOTIF_%'.

    loop at lt_zdl_fields into data(ls_fields).
      case ls_fields-fieldname.
        when 'NOTIF_USD_GROUP'.
          mv_notif_usd_group = condense( ls_fields-lowval ).
        when 'NOTIF_EMAIL'.
          mv_notif_email = condense( ls_fields-lowval ).
        when 'NOTIF_EMAIL_ADDRESS'.
          lv_str = condense( ls_fields-comments ).
          if lv_str is not initial.
            append lv_str to mt_email.
          endif.
        when 'NOTIF_MAX'.
          mv_notif_max = condense( ls_fields-lowval ).
          if mv_notif_max is initial.
            mv_notif_max = 1.
          endif.
        when 'NOTIF_THRESHOLD'.
          mv_notif_threshold = condense( ls_fields-lowval ).
          if mv_notif_threshold is initial.
            mv_notif_threshold = 0.
          endif.
        when 'NOTIF_USD'.
          mv_notif_usd = condense( ls_fields-lowval ).
        when 'NOTIF_USD_PRIORITY'.
          mv_notif_usd_priority = condense( ls_fields-lowval ).
          if mv_notif_usd_priority is initial.
            mv_notif_usd_priority = '1'.
          endif.
        when 'NOTIF_USD_RETRY'.
          mv_notif_usd_retry = condense( ls_fields-lowval ).
          if mv_notif_usd_retry is initial.
            mv_notif_usd_retry = 1.
          endif.
        when 'NOTIF_USD_LOOP'.
          mv_notif_usd_loop = condense( ls_fields-lowval ).
          if mv_notif_usd_loop is initial.
            mv_notif_usd_loop = 1.
          endif.
      endcase.
    endloop.

  endmethod.

*&---------------------------------------------------------------------*
*&      Method  NOTIF_GET_LOG_ERRORS
*&---------------------------------------------------------------------*
*       Get all Errors from Application Log
*       CD# 2000000330
*----------------------------------------------------------------------*
  method notif_get_log_errors.
    data: lv_header type string.
    data: lv_i type i.

    lv_i = 0.
    loop at gt_messages into data(ls_messages).
      if ls_messages-msgid = 'ZDL_SYLVAMO_3PP' and
         ( ls_messages-msgno = '092' or
           ls_messages-msgno = '095' or
           ls_messages-msgno = '096' or
           ls_messages-msgno = '099' or
           ls_messages-msgno = '111' or
           ls_messages-msgno = '112' or
           ls_messages-msgno = '122' ).

        message id ls_messages-msgid type 'S' number ls_messages-msgno
           with ls_messages-msgv1 ls_messages-msgv2
                ls_messages-msgv3 ls_messages-msgv4
           into lv_header.
        lv_i = lv_i + 1.
      endif.

      if ls_messages-msgty = 'E'.
        ls_messages-notifno = lv_i.
        ls_messages-notifheader = lv_header.
        append ls_messages to mt_errors.
      endif.

    endloop.

  endmethod.

*&---------------------------------------------------------------------*
*&      method  NOTIF_UPD_ZDL_E11734
*&---------------------------------------------------------------------*
*       Update ZDL_E11734_NOTIF Table
*----------------------------------------------------------------------
  method notif_upd_zdl_e11734.
    data: lv_locked type abap_bool.

    lv_locked = 'X'.

    delete adjacent duplicates from mt_e11734_ntf comparing all fields.

    loop at mt_e11734_ntf into data(ls_notif).

      "Lock Record
      call function 'ENQUEUE_EZDL_E11734_NTF'
        exporting
          notifobj       = ls_notif-notifobj
          notifobjtyp    = ls_notif-notifobjtyp
          msgid          = ls_notif-msgid
        exceptions
          foreign_lock   = 1
          system_failure = 2
          others         = 3.

      if sy-subrc <> 0.
        lv_locked = space.
      endif.
    endloop.

    if lv_locked = 'X'.

      modify zdl_e11734_notif from table mt_e11734_ntf.

      if sy-subrc = 0.
        commit work.
        rv_updated = 'X'.
        "Table &1 has been updated
        message s129(zdl_sylvamo_3pp) with 'ZDL_E11734_NOTIF'.
      else.
        rollback work.
        message s130(zdl_sylvamo_3pp) with 'ZDL_E11734_NOTIF'.
      endif.
      call function 'DEQUEUE_ALL'.

    else.
      message id sy-msgid type 'S' number sy-msgno
           with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      rv_updated = space.
    endif.

  endmethod.

*----------------------------------------------------------------------*
*       method NOTIF_CREATE_TEXT
*----------------------------------------------------------------------*
*       Create body message for ticket/email
*----------------------------------------------------------------------*

  method notif_create_text.

    data: lv_str  type string.
    data: lt_text  type bcsy_text.
    data: lv_txt type tdline.
    data: lt_endtext type re_t_textline.
    data: lv_aldate type baldate.
    data: lv_altime type baltime.
    data: lv_i(2) type n.

    lv_txt = 'System'.
    append lv_txt && `:  ` && sy-sysid to lt_text.

    lv_txt = 'Log Number'.
    append lv_txt && `:  ` && mv_lognum to lt_text.

    lv_txt = 'Object'.
    append lv_txt && `:  ` && ms_hlog-object to lt_text.

    lv_txt = 'Subobject'.
    append lv_txt && `:  ` && ms_hlog-subobject to lt_text.

    lv_txt = 'Date'.
    lv_aldate = ms_hlog-aldate.
    append lv_txt && `:  ` && lv_aldate+4(2) && '/' && lv_aldate+6(2) && '/' && lv_aldate(4) to lt_text.

    lv_txt = 'Time'.
    lv_altime = ms_hlog-altime.
    append lv_txt && `:  ` && lv_altime(2) && ':' && lv_altime+2(2) && ':' && lv_altime+4(2) && cl_abap_char_utilities=>newline
      to lt_text.

    loop at mt_errors into data(ls_msg).

      message id ls_msg-msgid type 'S' number ls_msg-msgno
       with ls_msg-msgv1 ls_msg-msgv2 ls_msg-msgv3 ls_msg-msgv4
       into data(lv_msg).
      lv_i = lv_i + 1.
      "append '(' && lv_i && `) ` && ls_msg-msgty && ` - ` && lv_msg
      append ls_msg-notifheader to lt_text.
      append '(' && ls_msg-msgty && `) ` && ` - ` && lv_msg
        to lt_text.
    endloop.

    clear: mv_ticket_text.
    loop at lt_text into lv_str.
      mv_ticket_text = mv_ticket_text &&
        condense( lv_str ) && cl_abap_char_utilities=>newline.
    endloop.

    clear: mv_mail_text.
    loop at lt_text into lv_str.
      mv_mail_text = mv_mail_text &&
        condense( lv_str ) && cl_abap_char_utilities=>newline.
    endloop.

  endmethod.

*----------------------------------------------------------------------*
*       method NOTIF_SEND_MAIL
*----------------------------------------------------------------------*
*       Send Email
*----------------------------------------------------------------------*
  method notif_send_mail.

    data: lv_email         type string.
    data: lv_stext         type string.
    data: ls_address       type bapiaddr3.
    data: lt_return        type standard table of bapiret2.
    data: lv_addr          type bcs_address.
    data: lv_visname       type bcs_visname.

    rv_sent = 'X'.

    try.
        data(lo_msg) = new cl_bcs_message( ).
        lo_msg->set_subject( iv_subject ).

        "Email TO...
        loop at mt_email into lv_email.

          lo_msg->add_recipient( exporting
                                   iv_address = lv_email ).
        endloop.

        "Sender
        call function 'BAPI_USER_GET_DETAIL'
          exporting
            username = sy-uname
          importing
            address  = ls_address
          tables
            return   = lt_return.

        lv_addr = ls_address-e_mail.
        lv_visname = ls_address-firstname && ` `
                     && ls_address-lastname.
        lo_msg->set_sender( exporting
                              iv_address      = lv_addr
                              iv_visible_name = lv_visname
                              ).

        lo_msg->set_main_doc( exporting
                                iv_contents_txt = mv_mail_text ).

        lo_msg->set_send_immediately( abap_true ).
        lo_msg->set_status_mail('N').

        lo_msg->send( ).

      catch cx_bcs_send into data(lv_ex).
        rv_sent = space.
    endtry.

  endmethod.

*----------------------------------------------------------------------*
*       method NOTIF_GET_ZDL_E11734
*----------------------------------------------------------------------*
*       Get ZDL_E11734_NOTIF entry
*----------------------------------------------------------------------*
  method notif_get_zdl_e11734.

    clear: rs_return.

    if is_error is supplied.

      select single * from zdl_e11734_notif
        into @data(ls_zdl_e11734)
      where notifobj = @is_error-notifobj
        and notifobjtyp = @is_error-notifobjtyp
        and msgid = @is_error-msgid
        and msgno = @is_error-msgno.

      if sy-subrc = 0.
        rs_return = ls_zdl_e11734.
      endif.
    elseif is_e11734_notif is supplied.

      select single * from zdl_e11734_notif
        into @ls_zdl_e11734
      where notifobj = @is_e11734_notif-notifobj
        and notifobjtyp = @is_e11734_notif-notifobjtyp
        and msgid = @is_e11734_notif-msgid
        and msgno = @is_e11734_notif-msgno.

      if sy-subrc = 0.
        rs_return = ls_zdl_e11734.
      endif.
    endif.
  endmethod.

*----------------------------------------------------------------------*
*       method NOTIF_USD
*----------------------------------------------------------------------*
*       Create USD ticket
*----------------------------------------------------------------------*
  method notif_usd.
    data: lv_usd_group type char30.
    data: lv_inventory_code	type zzinv6.

    lv_inventory_code = 'E11734'.
    lv_usd_group = notif_get_usd_group( ).

    do mv_notif_usd_retry times.

      call function 'Z_GEN_AHD_TICKET_ZZINV6'
        exporting
          if_inventory_code      = lv_inventory_code
          if_priority            = mv_notif_usd_priority
          if_severity            = '2'
          if_text                = mv_ticket_text
          if_usd_group           = lv_usd_group
        exceptions
          invalid_inv_code       = 1
          ahdgrp_not_found       = 2
          webmd_connection_error = 3
          others                 = 4.

      if sy-subrc = 0.
        rv_sent = 'X'.
        exit.
      else.
        wait up to mv_notif_usd_retry seconds.
      endif.

    enddo.
  endmethod.

*----------------------------------------------------------------------*
*       method NOTIF_NOT_SENT
*----------------------------------------------------------------------*
*       Modify MT_ERRORS table in case of notification has not been sent
*----------------------------------------------------------------------*
  method notif_not_sent.

    loop at mt_e11734_ntf assigning field-symbol(<ls_ntf>).

      if mv_mail_sent is initial.
        if <ls_ntf>-emailcounter > 0.
          <ls_ntf>-emailcounter = <ls_ntf>-emailcounter - 1.
        endif.
        data(ls_e11734_ntf) = notif_get_zdl_e11734( exporting is_e11734_notif = <ls_ntf> ).
        if ls_e11734_ntf is initial.
          <ls_ntf>-emailasttime  = '000000'.
          <ls_ntf>-emaillastdate = '00010101'.
        else.
          <ls_ntf>-emailasttime  = ls_e11734_ntf-emailasttime.
          <ls_ntf>-emaillastdate = ls_e11734_ntf-emaillastdate.
        endif.
      endif.

      if mv_usd_created is initial.
        if <ls_ntf>-ticketcounter > 0.
          <ls_ntf>-ticketcounter = <ls_ntf>-ticketcounter - 1.
        endif.
        ls_e11734_ntf = notif_get_zdl_e11734( exporting is_e11734_notif = <ls_ntf> ).
        if ls_e11734_ntf is initial.
          <ls_ntf>-ticketlasttime = '000000'.
          <ls_ntf>-ticketlastdate = '00010101'.
        else.
          <ls_ntf>-ticketlasttime = ls_e11734_ntf-ticketlasttime.
          <ls_ntf>-ticketlastdate = ls_e11734_ntf-ticketlastdate.
        endif.
      endif.

    endloop.

  endmethod.
*----------------------------------------------------------------------*
*       method NOTIF_GET_USD_GROUP
*----------------------------------------------------------------------*
*       Get Responsible Team
*----------------------------------------------------------------------*
  method notif_get_usd_group.

    rv_group = mv_notif_usd_group.

  endmethod.
***  2000000330 - end
endclass.

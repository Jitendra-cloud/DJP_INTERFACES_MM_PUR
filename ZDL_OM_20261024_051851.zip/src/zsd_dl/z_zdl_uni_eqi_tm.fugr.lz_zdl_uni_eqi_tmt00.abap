*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_UNI_EQIP_ID.................................*
DATA:  BEGIN OF STATUS_ZDL_UNI_EQIP_ID               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_UNI_EQIP_ID               .
CONTROLS: TCTRL_ZDL_UNI_EQIP_ID
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_UNI_EQIP_ID               .
TABLES: ZDL_UNI_EQIP_ID                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

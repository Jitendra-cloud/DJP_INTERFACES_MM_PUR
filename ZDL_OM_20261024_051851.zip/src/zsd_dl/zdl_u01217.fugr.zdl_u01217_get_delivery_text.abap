FUNCTION ZDL_U01217_GET_DELIVERY_TEXT.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(NAME) TYPE  TDOBNAME
*"  EXPORTING
*"     REFERENCE(ZZ_ZBOL_TEXT1) TYPE  TDLINE
*"     REFERENCE(ZZ_ZTNP_TEXT1) TYPE  TDLINE
*"----------------------------------------------------------------------
************************************************************************
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
************************************************************************
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       2000, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Function Name: ZDL_U01217_GET_DELIVERY_TEXT    Create Date: 03/12/07 *
*                                                                      *
* SAP Name     : ZDL_U01217_GET_DELIVERY_TEXT    Version    :          *
*                                                                      *
* Programmer   : William Mitzner                 Last Update: 03/12/07 *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
* This function is called to get the texts for the                     *
*   ZZ_ZBOL - Bill of Lading Notes text                                *
*   ZZ_ZTNP - Transportation Instr text                                *
* Then, it reads the 1st line of the text table and returns that line  *
*   back to the calling object.                                        *
*                                                                      *
* This function is called by Includes ZXV50QU01 and ZXV56U25           *
*  in EXIT_SAPLV50Q_001 and EXIT_SAPLV56L_002 which are objects of     *
*     transactions VL06T and VT01N,VT02N,VT03N.                        *
*                                                                      *
**********************************************************************-*
* Change History:                                                      *
* Programmer    Date      Corr #            Action                     *
* ==========  ========  ==========  ===================================*
* WMITZNE     03/12/07  EDEK907295  Initial Function created           *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes:           none                                             *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Logical Databases : none                                             *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules: none                                             *
*                                                                      *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Transactions    :                                                    *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*

data: lt_tlines   type standard table of tline,     "table
      ls_tline    type tline,                       "work structure
      lv_name     type tdobname,                    "70 Char
      lv_flag(01) type c.                           "Y=Yes
constants:
    c_y1(1) value 'Y'.

  clear: ZZ_ZBOL_TEXT1,                           "ZBOL One Line
         ZZ_ZTNP_TEXT1.                           "ZTNP One Line

  lv_name = name.                                 "Delivery Number

*----------------------------------------------------------------------*
*  Bill of Lading Notes text
*----------------------------------------------------------------------*
  clear   lv_flag.
  refresh lt_tlines.
  call function 'READ_TEXT'
    exporting
      id       = 'ZBOL'
      language = sy-langu
      name     = lv_name                      "Delivery Number
      object   = 'VBBK'
    tables
      lines    = lt_tlines
    exceptions
      others   = 1.

  if sy-subrc = 0.
    read table lt_tlines into ls_tline index 1.
    ZZ_ZBOL_TEXT1 =  ls_tline-tdline.
    lv_flag = c_y1.
  endif.

  if lv_flag <> c_y1.
    refresh lt_tlines.
    call function 'READ_TEXT'
      exporting
      id       = 'F040'         "Delivery for STO
      language = sy-langu
      name     = lv_name        "Delivery Number
      object   = 'VBBK'
      tables
      lines    = lt_tlines
      exceptions
      others   = 1.

    if sy-subrc = 0.
      Read table lt_tlines into ls_tline index 1.
      ZZ_ZBOL_TEXT1 =  ls_tline-tdline.
      lv_flag = c_y1.
    endif.
  endif.

*----------------------------------------------------------------------*
*  Transportation Instructions text
*----------------------------------------------------------------------*
  clear   lv_flag.
  refresh lt_tlines.
  call function 'READ_TEXT'
    exporting
      id       = 'ZTNP'
      language = sy-langu
      name     = lv_name                      "Delivery Number
      object   = 'VBBK'
    tables
      lines    = lt_tlines
    exceptions
      others   = 1.

  if sy-subrc = 0.
    read table lt_tlines into ls_tline index 1.
    ZZ_ZTNP_TEXT1 = ls_tline-tdline.
    lv_flag = c_y1.
  endif.

  if lv_flag <> c_y1.
    call function 'READ_TEXT'
      exporting
        id       = 'F030'         "Delivery for STO
        language = sy-langu
        name     = lv_name        "Delivery Number
        object   = 'VBBK'
      tables
        lines    = lt_tlines
      exceptions
        others   = 1.

    if sy-subrc = 0.
      read table lt_tlines into ls_tline index 1.
      ZZ_ZTNP_TEXT1 = ls_tline-tdline.
      lv_flag = c_y1.
    endif.
  endif.
*----------------------------------------------------------------------*
*  End of ZDL_U01217_GET_DELIVERY_TEXT
*----------------------------------------------------------------------*

ENDFUNCTION.

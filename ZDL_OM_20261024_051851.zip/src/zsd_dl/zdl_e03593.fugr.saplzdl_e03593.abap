*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E03593TOP.                    " Global Data
  INCLUDE LZDL_E03593UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E03593F...                    " Subprograms
* INCLUDE LZDL_E03593O...                    " PBO-Modules
* INCLUDE LZDL_E03593I...                    " PAI-Modules

FUNCTION z_idoc_input_railcar.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     VALUE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     VALUE(WORKFLOW_RESULT) LIKE  BDWF_PARAM-RESULT
*"     VALUE(APPLICATION_VARIABLE) LIKE  BDWF_PARAM-APPL_VAR
*"     VALUE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     VALUE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"----------------------------------------------------------------------
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2007, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
* Program Name: Inbound Railcar Visibility Shipment Creation           *
* Create Date : 02/16/2007                                             *
*                                                                      *
* SAP Name    : Z_IDOC_INPUT_RAILCAR             Version    : FINAL    *
*                                                                      *
* Programmer  : Nic Lira/Sabitha                 Last Update:          *
*                                                                      *
* CMS #       :                                                        *
*                                                                      *
*______________________________________________________________________*
* Description :This function module is triggered by process code       *
* ZINBD_RAIL.It reads the SHPMNT05 IDocs and updates some of the data  *
* field values (converts values)to support the creation of a minimal   *
* shipment in SAP in response to the receipt of a 417 EDI message from *
* Intellitrans.                                                        *
*                                                                      *
* This solution utilizes the standard function BORES_IDOC_INPUT_SHPMNT *
* but will need to do some custom conversions before calling this:     *
* The SCAC code will need to be converted to a  vendor code.
* The SPLC will need to be converted to a transportation planning point*
* The transportation planning point will be used to look up the points *
* for the stage. For Complete Functional Refer Inv#I02484              *
*_____________________________________________________________________ *
* Change History:                                                      *
* Programmer    Date       Req. #                 Action               *
* ==========  ========   ==========   ===============================  *
* NLIRA       02/16/2007 ESBK9A04DH   Initial                          *
* RWAINW1     05/01/2007 EDEK907224   I02484 V4W1 R11   (RLW01)        *
*                                       Inbound Railcar Visability     *
* SKOCHER     10/10/2007 EDVK957663   TPR-00154, set SY-BATCH = 'X'    *
*                                     to prevent popup during shipment *
*                                     create and modify select on VTTK *
*                                     to improve performance           *
* CCHERUP     10/30/2007 EDVK958228   TPR# 00245 Validating Equip Id   *
*                                     pushing Idoc status to 51 for    *
*                                     invalid equip id and also check  *
*                                     to see whether equipment exists  *
*                                     on any outbound shipment. If yes *
*                                     push idoc to 53                  *
* CCHERUP     04/25/2008 E0VK938889   CHG86925 - Resequence Validation *
*                                     Moved the "convert_splc" perform *
*                                     above "convert_scac" perform     *
* MGILL       08/27/2013              Change to use plant (instead of  *
*                                     shipping point) to get connection*
*                                     points (table tvkn)              *
*______________________________________________________________________*
************************************************************************

  DATA: lv_status TYPE bdidocstat-status,
        lv_msgty  TYPE bdidocstat-msgty,
        lv_msgv1  TYPE bdidocstat-msgv1,
        lv_msgv2  TYPE bdidocstat-msgv2,                    " <<RLW01+
        lv_msgv3  TYPE bdidocstat-msgv3,
        lv_flag   TYPE flag,
        lv_msg    TYPE bdidocstat-msgv1.

* Clear the Application log reference and data fields:
  CLEAR gv_applog_ref.                                      " <<RLW01+
  CLEAR x_log.                                              " <<RLW01+
  REFRESH t_log.                                            " <<RLW01+
  sy-batch = 'X'. " This will suppress dialogs in the ship create
                                                            " TPR-00154

* >> Begin of CHG86925 - CCHERUP - 04/25/2008
* Get the Transportation planning point.
  PERFORM convert_splc      TABLES idoc_data.
* Set IDoc Status: "Non IP SPLC code &"                     " <<RLW01+
  IF gv_tpp IS INITIAL.
    CLEAR idoc_status.                                      " <<RLW01+
    idoc_status-docnum = idoc_contrl-docnum.                " <<RLW01+
    idoc_status-status = '53'.                              " <<RLW01+
    idoc_status-msgty  = 'E'.                               " <<RLW01+
    idoc_status-msgid  = 'ZSD_DL_I02484'.                   " <<RLW01+
    idoc_status-msgno  = '003'.                             " <<RLW01+
    idoc_status-msgv1  = gv_splc.                           " <<RLW01+
    idoc_status-uname  = sy-uname.                          " <<RLW01+
    idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).       " <<RLW01+
    idoc_status-routid = space.                             " <<RLW01+
    APPEND idoc_status.                                     " <<RLW01+
    EXIT.
  ENDIF.
* << End of CHG86925 - CCHERUP - 04/25/2008

* >> Begin of TPR# 00245 - CCHERUP - 10/30
  CLEAR lv_flag.
  PERFORM validate_idoc_data TABLES idoc_contrl
                                    idoc_data
                                    idoc_status
                           CHANGING lv_flag.
  IF lv_flag EQ 'X'.
    EXIT.
  ENDIF.
* << End of TPR# 00245 - CCHERUP - 10/30

* Get the Vendor Code for the given SCAC code
  PERFORM convert_scac      TABLES idoc_data
                            CHANGING lv_flag
                                     lv_msg.
  IF lv_flag IS NOT INITIAL.

*    lv_status = '51'.                                       " <<RLW01-
*    lv_msgty  = 'E'.                                        " <<RLW01-
*    lv_msgv1  = lv_msg.                                     " <<RLW01-
*    lv_msgv3  = idoc_contrl-docnum.                         " <<RLW01-
*    PERFORM set_idoc_status TABLES idoc_status              " <<RLW01-
*                            USING  idoc_contrl-docnum       " <<RLW01-
*                                   lv_status                " <<RLW01-
*                                   lv_msgty                 " <<RLW01-
*                                   lv_msgv1                 " <<RLW01-
*                                   lv_msgv3.                " <<RLW01-
* Set IDoc Status: "SCAC code provided & is not valid"      " <<RLW01+
    CLEAR idoc_status.                                      " <<RLW01+
    idoc_status-docnum = idoc_contrl-docnum.                " <<RLW01+
    idoc_status-status = '51'.                              " <<RLW01+
    idoc_status-msgty  = 'E'.                               " <<RLW01+
    idoc_status-msgid  = 'ZSD_DL_I02484'.                   " <<RLW01+
    idoc_status-msgno  = '001'.                             " <<RLW01+
    idoc_status-uname  = sy-uname.                          " <<RLW01+
    idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).       " <<RLW01+
    idoc_status-routid = space.                             " <<RLW01+
    APPEND idoc_status.                                     " <<RLW01+

    EXIT.
  ELSE.

    CLEAR gv_flg_delete_fail.                               " <<RLW01+
    PERFORM process_diversion TABLES idoc_data.             " <<RLW01+
    IF NOT gv_flg_delete_fail IS INITIAL.                   " <<RLW01+
*      lv_status = '52'.                                     " <<RLW01+
*      lv_msgty  = 'E'.                                      " <<RLW01+
*      lv_msgv1  = 'Diversion Shipment delete failed.'(e01). " <<RLW01+
*      lv_msgv2  = gv_applog_ref.                            " <<RLW01+
*      lv_msgv3  = idoc_contrl-docnum.                       " <<RLW01+
*      PERFORM set_idoc_status TABLES idoc_status
*                              USING  idoc_contrl-docnum
*                                     lv_status
*                                     lv_msgty
*                                     lv_msgv1
*                                     lv_msgv3.              " <<RLW01+
* Set IDoc Status: "At least 1 diversion Shipment delete failed."
*   " <<RLW01+
      CLEAR idoc_status.                                    " <<RLW01+
      idoc_status-docnum = idoc_contrl-docnum.              " <<RLW01+
      idoc_status-status = '51'.                            " <<RLW01+
      idoc_status-msgty  = 'E'.                             " <<RLW01+
      idoc_status-msgid  = 'ZSD_DL_I02484'.                 " <<RLW01+
      idoc_status-msgno  = '002'.                           " <<RLW01+
      idoc_status-uname  = sy-uname.                        " <<RLW01+
      idoc_status-repid  = 'Z_IDOC_INPUT_RAILCAR'(001).     " <<RLW01+
      idoc_status-routid = space.                           " <<RLW01+
      APPEND idoc_status.                                   " <<RLW01+

      EXIT.                                                 " <<RLW01+
    ENDIF.                                                  " <<RLW01+

    IF gv_tpp IS NOT INITIAL.
      PERFORM get_stage_points.
      PERFORM get_time_zone USING gv_tpp
                         CHANGING gv_tz.                    " <<RLW01+
      PERFORM groom_idoc      TABLES idoc_data.
      PERFORM create_shipment TABLES idoc_contrl
                                     idoc_data
                                     idoc_status
                                     return_variables
                                     serialization_info.
    ENDIF.
  ENDIF.
*      lv_status = '52'.
*      lv_msgty  = 'E'.
*      lv_msgv1  = 'Non-IP SPLC'(003).
*      lv_msgv3  = idoc_contrl-docnum.
*      PERFORM set_idoc_status TABLES idoc_status
*                              USING  idoc_contrl-docnum
*                                     lv_status
*                                     lv_msgty
*                                     lv_msgv1
*                                     lv_msgv3.

ENDFUNCTION.

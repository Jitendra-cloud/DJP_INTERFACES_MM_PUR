*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_DELETE_ZSDVEKPTOP.      " Global Data
  INCLUDE LZDL_DELETE_ZSDVEKPUXX.      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_OM_PROMO_SALES_ORDERF...      " Subprograms
* INCLUDE LZSD_OM_PROMO_SALES_ORDERO...      " PBO-Modules
* INCLUDE LZSD_OM_PROMO_SALES_ORDERI...      " PAI-Modules

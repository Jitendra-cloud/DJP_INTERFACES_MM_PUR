*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_VENASN_CL .
*----------------------------------------------------------------------*

*{   INSERT         EDVK972584                                        1
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2005, 2006 by                     **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005, 2006                                 **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Programmer: Savithri Renganathan                Date:  09/09/2005    *
*                                                                      *
* Description:  This function module is used to create batches and     *
* Inbound Deliveries from the IDoc DELVRY03 - Vendor ASN into R/3.     *
*                                                                      *
*                                                                      *
* Transport # - EDEK902750, EDVK942814                                 *
*                                                                      *
*----------------------------------------------------------------------*
* Change History                                                       *
*----------------------------------------------------------------------*
* Date      Name           Description                                 *
*                                                                      *
* 02/13/06  Subba Boyalla  Add MTO/MTS Logic for Message Type          *
*                          ZDL_MTS_MTOASN                              *
*                                                                      *
* 02/21/06  Subba Boyalla  Add Portal ASN logic for Message Type       *
*                          ZDL_PASN                                    *
*                                                                      *
* 04/26/06  Bruce Ballehr  EDVK946089                                  *
*                                                                      *
*                          Logic added for both Trades ASN1 and Trades *
*                          ASN2, which will use the same message type  *
*                          as the Vendor ASN interface: ZDL_VASN       *
*                                                                      *
*                          Most of the logic between the Vendor ASN &  *
*                          Trades ASNs are the same but we'll separate *
*                          some logic based on whether or not it's a   *
*                          Trades ASN or not.                          *
*                                                                      *
*                          Trades ASN1:                                *
*                          - Idoc will be sent by a Trades partner     *
*                          - We'll determine it's Trades ASN1 by       *
*                            checking the PO Type of the PO's on the   *
*                            E1EDL43-BELNR where E1EDL43-QUALF = 'V'   *
*                          - The data on the idoc will be PO2 data so  *
*                            we'll convert some idoc data to PO1 data  *
*                            so we generate the Trades Inbound         *
*                            Delivery 1 against the Trades PO1.        *
*                                                                      *
*                          Trades ASN2:                                *
*                          - Idoc will be generated in the Goods       *
*                            Receipt process via a call to function    *
*                            IDOC_INBOUND_SINGLE.                      *
*                          - We'll determine it's Trades ASN2 by       *
*                            checking that the Idoc Control Record     *
*                            Message Code field is 'TR2'. The GR       *
*                            process will set this prior to calling    *
*                            IDOC_INBOUND_SINGLE as it lets us easily  *
*                            identify that it's a Trades ASN2.         *
*                          - The data on the idoc will be PO1 data so  *
*                            we'll convert some idoc data to PO2 data  *
*                            so we generate the Trades Inbound         *
*                            Delivery 2 against the Trades PO2.        *
*                                                                      *
* Savithri.R.            EDVK946089                                    *
*                         Batch characteristics format manipulation    *
*                        - because the Vendor will send in just numeric*
*                        with max. of 3 decimals but in SAP each chara-*
*                        cteristics will have different format.  So,   *
*                        adjust the characteristics (Only ROLL_WIDTH)  *
*                        sent by Vendor, since others will be taken by *
*                        '*BATMAS03' creation function module          *
*                                                                      *
* 07/25/06  Bruce Ballehr  EDVK946089                                  *
*                                                                      *
*                          Logic added for Portal Trades ASN1.         *
*                                                                      *
*                          According to the functional spec for E03261 *
*                          Portal ASN, when creating a manual Trades   *
*                          ASN, the user is SUPPOSED to enter PO2 but  *
*                          CAN enter PO1. So, we need to code for      *
*                          each scenario. The bottom line is that we   *
*                          need the ASN to create an Inbound Delivery  *
*                          against PO1.                                *
*                                                                      *
*                          If PO2 entered:                             *
*                          - Retrieve various PO1 information and      *
*                            replace the PO2 info with PO1 info prior  *
*                            to generating the Inbound Delivery.       *
*                          - Retrieve the neccessary information to    *
*                            create a ZDL_TRADES record(s) for Goods   *
*                            Receipt purposes.                         *
*                                                                      *
*                          If PO1 entered:                             *
*                          - Retrieve the neccessary information to    *
*                            create a ZDL_TRADES record(s) for Goods   *
*                            Receipt purposes.                         *
*                                                                      *
*                          We will use Message Type ZDL_NONOMD_ASN     *
*                          for Vendor ASN's for Georgetown and Terre   *
*                          Haute (these will come in via Webmethods    *
*                          while other Vendor ASN's will come in via   *
*                          Gentran). This message type will execute    *
*                          almost identical to ZDL_VASN except for     *
*                          a change to the IPCO field. Instead of      *
*                          retrieving the IPCO from EKKO, it will be   *
*                          on the Georgetown and Terre Haute idocs in  *
*                          segment-field E1EDL41-BSTNR where           *
*                          E1EDL41-QUALI = '002'.                      *
*                                                                      *
* 08/28/06  Bruce Ballehr  EDVK949032                                  *
*                                                                      *
*                          For Terre Haute / Georgetown, make sure we  *
*                          only store the rightmost 5 bytes of the     *
*                          IPCOB they send on the E1EDL41 segment.     *
*                                                                      *
*                                                                      *
* 09/19/06  Bruce Ballehr  EDVK949484                                  *
*                                                                      *
*                          This change will prevent an already-existing*
*                          ASN2 from being created. A test case was    *
*                          accidentally created where a GR idoc was    *
*                          created and the ASN2 idoc never processed   *
*                          since the Partner Profile was not created   *
*                          in the new instance. So, the user kept on   *
*                          performing WE19 until there were 5 duplicate*
*                          GR idocs in failed status and 5 duplicate   *
*                          ASN2 idocs in falied status. The user then  *
*                          created the partner profile and manually    *
*                          processed each ASN2 idoc until all processd.*
*                          Each time one processed, it created an inb  *
*                          2 idoc against the PO and kept replacing    *
*                          ZDL_TRADES-IB_DELIVERY_2 on the record for  *
*                          the Inbound Delivery 1 and PO1. This change *
*                          will prevent this USER ERROR from generating*
*                          multiple Inbound Delivery 2's via the Trades*
*                          process.                                    *
*                                                                      *
* 11/29/06  Bruce Ballehr  E0VK924165  TPR#16553                       *
*                                                                      *
*                          Remove call to subroutine                   *
*                          sub_upd_idoc_status which opened and closed *
*                          the idoc and attempted to insert additional *
*                          status records. When the idoc comes through *
*                          the ALE layer this causes a failure         *
*                          "Idoc xxx cannot be opened". We do not need *
*                          this subroutine and it was deleted (can look*
*                          at version management to see where this call*
*                          was.)                                       *
*                                                                      *
* 02/20/07  Bruce Ballehr  E0VK926240  Change Order 72971   BCB01      *
*                                                                      *
*                          Break/Fix: If an error occurs (during ASN1  *
*                          processing for Trades) while trying to gen  *
*                          the Inbound Delivery 1 via function mod     *
*                          BORES_IDOC_INPUT_DESADV1 (see below) then   *
*                          the logic slips past and executes subroutine*
*                          update_zdl_trades_table. An example of an   *
*                          error that could occur is that the corresp  *
*                          PO was locked and the Inbound 1 could not   *
*                          be generated. This fix will prevent routine *
*                          update_zdl_trades_table from being processed*
*                                                                      *
* 03/06/2007 Bruce Ballehr E0VK926240                       BCB02      *
*                                                                      *
*                          We had an issue after the March 2007 go     *
*                          live. PO1's were changed if an item was     *
*                          partially received. A new PO1 item was      *
*                          created. We had code that assumed all       *
*                          PO2 item numbers were the SAME as PO1       *
*                          item numbers. This is now false. We         *
*                          now retrieve the proper PO2 line item.      *
*                                                                      *
* 03/07/2007 Bruce Ballehr E0VK926843                       BCB02      *
*                                                                      *
*                          - We had an issue from a Vendor ASN1 where  *
*                            we tried to retrieve the PO1 and PO2 item *
*                            using the Material on E1EDL24 but could   *
*                            not since it was not yet converted from   *
*                            the AFPA code to the SAP Material. We     *
*                            pushed our derivation logic of PO1 and    *
*                            PO2 line items to routine                 *
*                            retrieve_trades_asn1_info.                *
*                                                                      *
*                                                           BCB03      *
*                                                                      *
*                          - In routine sub_mat we are selecting       *
*                            potential PO's and PO Line Items to help  *
*                            with converting the AFPA Codes to SAP     *
*                            Materials. The lookup of table EKPO needs *
*                            additional logic to avoid using PO items  *
*                            that may have been deleted or have a non- *
*                            valuated account assignment.              *
*                                                                      *
* 01/11/2008 Bruce Ballehr EDVK959727   TPR 22386           BCB04      *
*                                                                      *
*                          - When processing the retrieval of new HU   *
*                            NUmbers for non Batch Managed materials,  *
*                            the code attempts to update internal table*
*                            lt_char with sy-index instead of the      *
*                            proper sy-tabix.                          *
*                                                                      *
* 01/24/2008 Bruce Ballehr EDEK910619                       BCB05      *
*                                                                      *
*                          - Pricef 07293  for R12 - Oct 2008          *
*                                                                      *
*                          - Add logic to handle Individual Goods      *
*                            Receipts for V2 Trades OMD. Trades Non    *
*                            OMD will process normally (receive the    *
*                            entire Delivery at one time).             *
*                            1. Individual Idocs will have an idoc     *
*                               Message Code of 'IND' just like V2.    *
*                            2. Final Idoc will have an idoc Message   *
*                               Code of 'V2F' like the current Final   *
*                               Idoc for V2.                           *
*                                                                      *
* Bruce C Ballehr    04/22/08  EDVK962009  / BCB06 / CR7631            *
*                                                                      *
*                              Change 1                                *
*                              --------                                *
*                              We had an issue where we though we had  *
*                              a duplicate Vendor Batch but the        *
*                              business did not think so since they    *
*                              had a unique BOL on the Manual ASN      *
*                              screen. We enhanced this code to pass   *
*                              in the BOL on the table that's passed   *
*                              in when called from the Vendor ASN      *
*                              (LZSD_DL_VENASNF02) and EDI ASN         *
*                              (LZSD_DL_VENASNF01). This validation is *
*                              now similary, using the BOL, to func    *
*                              Z_SD_DL_I2301_CHECK_DUPLI_ASN           *
*                                                                      *
*                              Change 2                                *
*                              --------                                *
*                              When passing a table of information to  *
*                              function module                         *
*                              Z_SD_DL_I2301_CHECK_DUPLI_ASN we pass   *
*                              the Material the Vendor sends on the    *
*                              idoc, which is the Sales Grade I        *
*                              believe, because they don't have the    *
*                              SAP Material number. We need to send    *
*                              the DUPLI function the SAP material     *
*                              it compares the Material number to the  *
*                              LIPS material as one of the DUP checks. *
*                                                                      *
* Bruce C Ballehr    06/22/08  EDVK963930  / BCB07 / TPR01398          *
*                                                                      *
*                              Fyi, this should have been a part of    *
*                              CR7631 but was missed. In the CR7631    *
*                              change above, we added an optional BOL  *
*                              number to the Dup Check in function     *
*                              module Z_DL_E03126_UNIT_ID_CHECK.  We   *
*                              should have also added an optional PO   *
*                              Number to the Duplicate Vendor Batch    *
*                              check. This change adds the PO to the   *
*                              Duplicate Vendor Batch check. So, if a  *
*                              BOL and/or a PO are passed in to fm     *
*                              Z_DL_E03126_UNIT_ID_CHECK then they     *
*                              will be used as part of the Dup check.  *
*                              This ASN idoc function module is now    *
*                              modified, for both the EDI ASN and the  *
*                              Manual/Portal ASN, to now send the PO.  *
*                                                                      *
*                              Just a note that if the ASN's will be   *
*                              sending in Bundled Rolls in the future, *
*                              which they will be, we'll have some     *
*                              major code changes because some of the  *
*                              work internal tables ASSume a 1-to-1    *
*                              relationship between an E1EDL37 segment *
*                              and an E1EDL24 segment. Actually, a     *
*                              Bundled Roll scenario should still only *
*                              have a single E1EDL37 seg with multiple *
*                              E1EDL44 segments underneath. We will    *
*                              have to look at that. I know an issue   *
*                              would arise if we ever had multiple HUs *
*                              per Delivery Item. This would equate to *
*                              multiple E1EDL37 segments per E1EDL24   *
*                              segment.                                *
*                                                                      *
* Bruce C Ballehr    08/06/08  EDVK964689  / BCB08 / R12               *
*                                                                      *
*                              Bundled Roll changes for R12 Manual ASN *
*                                                                      *
*                              The key is to make sure the following   *
*                              scenarios will all work:                *
*                              1. Bundled Rolls [HU Managed]           *
*                              2. Non Bundled Rolls [HU Managed]       *
*                              3. Non Batch Managed (V2) [HU Managed]  *
*                                                                      *
*                              One change is that field CHARG is not   *
*                              populated on segments E1EDL24 and       *
*                              E1EDL44 if the related Material is NOT  *
*                              Batch Managed from Manual ASN frontend  *
*                              program ZSD_DL_E03261_ASN_CUST_TRANS    *
*                                                                      *
*                              Another change is that the Vendor Batch *
*                              Number (which would equate to the       *
*                              Vendor HU Number for Non Batch Managed  *
*                              Materials) is formatted into            *
*                              segment-fields E1EDL24-KDMAT &          *
*                              E1EDL44-KDMAT from Manual ASN frontend  *
*                              program ZSD_DL_E03261_ASN_CUST_TRANS    *
*                                                                      *
*                              Another change is that if there is a    *
*                              Bundled Rolls scenario, all of the      *
*                              Batches that belong to HU ZZ12345678    *
*                              for example, must have the value        *
*                              ZZ12345678 as the value in Batch        *
*                              Characteristic PACKAGE_NUMBER.          *
*                                                                      *
* Bruce C Ballehr    08/13/08  EDVK963930  / BCB09 / CR7632            *
*                                                                      *
*                         R12  As part of the R12 changes for          *
*                              enhancing the Manual & EDI ASN for      *
*                              Sheets and Skids, we need to allow the  *
*                              Vendor Batch to be used (instead of     *
*                              creating a new one) in CERTAIN          *
*                              circumstances. Here is a brief descript *
*                              of the logic in function module:        *
*                              Z_DL_E03126_UNIT_ID_CHECK               *
*                                                                      *
*                              IF Batch Managed                        *
*                                IF Vendor Batch is not a Duplicate    *
*                                  IF Vendor Batch Number = 10 bytes   *
*                                    IF first 2 bytes of Vendor Batch  *
*                                    found in ZDL_UNI_EQIP_ID          *
*                                      IF a Vendor Number was passed   *
*                                      in on new field LIFNR (new to   *
*                                      struct ZDL_UNIQUEID)            *
*                                        IF a Matching Record was      *
*                                        found on table ZDL_FIELDS     *
*                                          USE the Vendor Batch Number *
*                                          passed in instead of        *
*                                          generating a new Vendor     *
*                                          Batch Number                *
*                                                                      *
*                              A handful of programs call this funct   *
*                              module but we ONLY want this logic to   *
*                              processed for EDI ASN Idoc code and     *
*                              Manual ASN Idoc code (LZSD_DL_VENASNF01 *
*                              and LZSD_DL_VENASNF02 respectively).    *
*                              At this time, these two programs will   *
*                              be the only ones to populate the LIFNR  *
*                              field passed in on the TABLES parm.     *
*                                                                      *
*                              ZDL_FIELDS will have entries for        *
*                              certain Vendors.  Here is an example on *
*                              what a entry will look like in table    *
*                              ZDL_FIELDS:                             *
*                                                                      *
*                              Field Name    Value                     *
*                              ----------    -----
*                              CATEGORY      E03261_BATCH              *
*                              FIELDNAME     T4 (1st 2 bytes of VB)    *
*                              SIGN          I (for Include)           *
*                              OPTN          EQ                        *
*                              LOWVAL        IP0500010 (vendor)        *
*                              HIGHVAL       blank                     *
*                                                                      *
* Showry Kocherla    08/06/08  EDVK964689  / CR-8050 / R12             *
* Bruce C Ballehr                                                      *
*                              Bundled Roll changes for R12 EDI ASN    *
*                                                                      *
*                              The only source providing EDI Bundled   *
*                              Rolls for R12 will be Paper Pro. Most   *
*                              of their idocs will actually NOT be     *
*                              Bundled Rolls. Their idocs will have a  *
*                              Message Type of ZDL_NONOMD_ASN and a    *
*                              Message Code of 'PPR'. We drive some    *
*                              logic based on the Message Code. One    *
*                              assumption is that ALL of the Vendor    *
*                              Batches sent in by Paper Pro will be 10 *
*                              bytes. This is why our mapping has the  *
*                              Vendor Batch for Paper Pro in fields    *
*                              E1EDL24-CHARG & E1EDL44-CHARG. Other    *
*                              Vendors sending in ASN idocs might have *
*                              Vendor Batches > 10 bytes so their VB's *
*                              are mapped to E1EDL37-EXIDV & E1EDL44-  *
*                              EXIDV (if batch managed). This is not   *
*                              the desirable setup.                    *
*
*                              In the future we'll need ALL Vendors &  *
*                              Paper Pro to send Vendor Batches in the *
*                              SAME fields on E1EDL24 & E1EDL44 for    *
*                              conformity.                             *
*                                                                      *
*                              The key is to make sure the following   *
*                              scenarios will all work:                *
*                              1. Bundled Rolls [HU Managed]           *
*                              2. Non Bundled Rolls [HU Managed]       *
*                              3. Non Batch Managed (V2) [HU Managed]  *
*                                                                      *
*                                                                      *
* Bruce C Ballehr    09/21/08  E0VK943577  / CR-8050-FIX1              *
*                                                                      *
*                              R12 Go live issue. The Material, Plant  *
*                              and Batch are not being formatted on    *
*                              the HU item when creating HU's for      *
*                              Non PaperPro scenarios                  *
*                                                                      *
* Bruce C Ballehr    09/23/08  E0VK943653  / CR-8050-FIX2              *
*                                                                      *
*                              R12 Go live issue. Field CHARG of itab  *
*                              gt_mbhp_tab not being formatted         *
*                              correctly for Non PaperPro scenarios.   *
*                              This is causing a mismatch of internal  *
*                              tables in subroutine sub_mat so that    *
*                              the proper SAP Material is not being    *
*                              derived OR we're referencing the        *
*                              SAP Material on the WRONG PO Line Item  *
*                              (two different errors are occurring).   *
*                                                                      *
* Bruce C Ballehr    09/24/08  E0VK943759  / CR-8050-FIX3              *
*                                                                      *
*                              R12 Go live issue. The Duplicate ASN    *
*                              check function module                   *
*                              Z_SD_DL_I2301_CHECK_DUPLI_ASN was fixed *
*                              for R12 (never really worked due to the *
*                              design). Now that it's working, for     *
*                              every line on the ASN that is a         *
*                              Duplicate, we Loop at the table of ASN  *
*                              items and generate an idoc 51 status    *
*                              message. Each time a 51 status msg is   *
*                              generated, we generate a USD Ticket.    *
*                              We need to modify the logic so that a   *
*                              USD ticket is only generated one time   *
*                              per idoc.                               *
* Kishor Thakur    04/20/09    EDEK914995   CR#8805/8806 V4.0 R14
*                              Brazil ASN
*1) Validate PO(s) in E1EDL43.BELNR; when E1EDL43.QUALF=#V# and the PO
*  contains a storage location.Check that the PO line item exists in
*  the table EKPO.EBELN/EKPO.POSNR and the vendor for that PO is the
*  same as the sender partner number in the EDI_DC EKKO.LIFNR = EDI_DC.
*  EKPO.SLOC not blank.
*2)Check if ASN is GR relevant, set to 68 with message saying it is not
* relevant if not relevant, and mention the PO, and PO line item. It is
* assumed that if any line is not relevant, they are not relevant, and
* should not process further.PO#s account assignment is relevant if it
* is not #Y# in EKPO.KNTTP; when EKPO.EBELN = E1EDL43.BELNR
*3)Validate IDOC plant matches PO plant. E1EDL24.WERKS = EKKO.EKORG
*4)Validate Materials in the ASN are valid and in the PO.
*  E1EDL44.MATNR=EKPO.MATNR
*5)Validate Pallet ID code in E1EDL24.CHARG.Make sure it begins
* with '6C' and is 10 characters in length, and it is unique within
* the IDOC.
* Note:  The pallet weight will be taken from WEIGHT_OF_PALLET_IN_LBS
* From MARM table field UMREZ/UMREN when E1EDL44.MATNR=MARM.
* MATNR and MARM.MEINH=PAL, MARM.ATINN= WEIGHT_OF_PALLET_IN_LBS.
* Not from the IDOC. Overlay E1EDL24.LFIMG and E1EDL44.VEMNG
*                                                                      *
* Bruce C Ballehr    07/13/10  EDVK977740  / R18                       *
*                              This change is in conjunction with      *
*                              E04625 Transport EDV977677              *
*                                                                      *
*                              Search from programming tag BCB10       *
*                                                                      *
*                              Perform different logic if this is the  *
*                              Trades ASN1 (but not a Manual ASN):     *
*                              - If certain error conditions occur     *
*                                then use new error messages. We       *
*                                already set WORKFLOW_RESULT to        *
*                                '99999' if ANY validation error       *
*                                occurred so this had to be changed    *
*                              - The new ZSD_DL error messages that are*
*                                part of this change are: 601 - 605    *
*                                                                      *
* Bruce C Ballehr    09/30/10  EDVK977740  / R18                       *
*                              This change is in conjunction with      *
*                              I02639 Trades Outbound ASN for CTA      *
*                              (Container of Americas). Once our       *
*                              Inbound Delivery is created, if it was  *
*                              a CTA partner then Header Output ZCTA   *
*                              would have been proposed in status      *
*                              "Send with Periodically Scheduled Job". *
*                              This code change triggers the ZCTA      *
*                              output AFTER table ZDL_TRADES has been  *
*                              updated.                                *
*                                                                      *
*                              Search from programming tag BCB11       *
*                                                                      *
* Steve Pieri   12/09/2011 TPR# 40946 Replace function module          *
*                          BORES_IDOC_INPUT_DESADV1 with the newer     *
*                          /SPE/IDOC_INPUT_DESADV1 for ECC 6.0         *
*                         EDVK982442. This new function uses different *
*                         IDOC STATUS MESSAGES in returning the inbound*
*                         delivery document number.
* Bala Mandla   09/11/2012 EDVK986992                                  *
*                    CR 11871                                          *
*                    Populate Shipping Conditions onto Inbound Delivery*
*                     MTO Scenario Changes to validation for ROOL Width*
* RSURED1     07/28/2015  E0VK9A0DK7                                   *
*                         CHG#177752 and CMS 28753
*                         Avoid creating multiple inbound delivery     *
*                         records by adding try catch method when HU   *
*                         is assigned to inbd delivery and also check  *
*                         vend batch and BOL exist in Delivery tables  *
* AMAOLE1| 11042016| CMS31175| Bug Fix:                                *
* Function module Z_SD_DL_I2301_INPUT_ZVASN was changed to correct the *
* net & gross weight for the MTO materials on the IDoc created for     *
* vendor ASNs. Method PARSE_AND_HANDLE_IDOC_DELVRY03 in class          *
* /SPE/CL_IBDLV_CONTROL was also enhanced.                             *
* ENHANCEMENT-POINT - parse_and_handle_idoc_dlv03_03                   *
* SPOT - /spe/cl_ibdlv_control.                                        *
* Enhancement Implementation - ZEI_DL_I2301_WT_FOR_MTO_MATL            *
* AMAOLE1| 07132017| CMS32255| Bug Fix:                                *
* Fix MTO PASN IDoc indexing issue                                     *
*----------------------------------------------------------------------*
*
*-----------------------------------------------------------------------
*&---------------------------------------------------------------------*
*&      Form  Z_SD_DL_I2301_CHANGE_LOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM z_sd_dl_i2301_change_log .

ENDFORM.                    " Z_SD_DL_I2301_CHANGE_LOG

*}   INSERT

*{   INSERT         EDVK972584                                        2
*&---------------------------------------------------------------------*
*&      Form  INITIALIZATION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM initialization .

* Clear all global variables and tables
  CLEAR: gs_idoc_ctrl,

         gt_idoc_data[],
         gs_idoc_data,

         gt_idoc_status[],
         gs_idoc_status,
         gv_inb_vbeln,
         gt_mbpsv,
         gt_mbh,
         gt_bat_char,
         gt_hu.

  gv_trades_asn1 = gc_false.                                "EDVK946089
  gv_trades_asn2 = gc_false.                                "EDVK946089
  gv_ib2_exists  = gc_false.                                "EDVK949484
  gv_usd_created = gc_false.
  "CR-8050-FIX3
  gv_trigger_wf  = gc_false.                                "BCB10

*Begin of changes pragup1 06/15/2012 CHG 136783
  CLEAR gv_chk_multiple_usd.
*End of changes pragup1 06/15/2012 CHG 136783


  REFRESH: gt_hu,
           gt_mbpsv,
           gt_mbh,
           gt_bat_char.

  SELECT * INTO TABLE gt_zdl_fields_matkl FROM zdl_fields
         WHERE category = 'I2301'
         AND   fieldname = 'MATKL'.

ENDFORM.                    " INITIALIZATION

*}   INSERT

FUNCTION-POOL zsd_dl_milemaker.             "MESSAGE-ID ..

DATA: gs_vttk TYPE vttk.

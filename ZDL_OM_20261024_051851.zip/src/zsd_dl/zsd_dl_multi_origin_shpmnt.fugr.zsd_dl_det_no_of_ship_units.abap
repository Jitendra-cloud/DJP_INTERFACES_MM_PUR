FUNCTION zsd_dl_det_no_of_ship_units .
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IT_SHIPMENTS) TYPE  ZMOS_SHIPMENT_S OPTIONAL
*"     REFERENCE(IT_DELIVERIES) TYPE  ZMOS_DELIVERY_S OPTIONAL
*"     REFERENCE(IT_ATNAM) TYPE  ZMOS_SEL_CHAR_S OPTIONAL
*"  TABLES
*"      T_SHIP_UNITS TYPE  ZMOS_SHIP_UNITS_S OPTIONAL
*"      T_DELV_UNITS TYPE  ZMOS_DELV_UNITS_S OPTIONAL
*"      T_DELV_ITEM_UNITS TYPE  ZMOS_DELV_ITEM_UNITS_S OPTIONAL
*"      T_HU_CONTENTS TYPE  ZMOS_HU_CONTENTS_S OPTIONAL
*"  EXCEPTIONS
*"      INVALID_INPUT
*"      NO_DELIVERIES_FOUND
*"      NO_DELIVERY_DATA_FOUND
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2007 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       2007, 2008, 20xx                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: Determine Number of              Create Date: 03/01/07 *
*               Shipping Units                                         *
*                                                                      *
* SAP Name    : ZSD_DL_DET_NO_OF_SHIP_UNITS      Version    :          *
*                                                                      *
* Programmer  : Chandra Cherupally               Last Update:          *
*                                                                      *
* Inventory Code : I02419                                              *
*______________________________________________________________________*
* Description : This function module takes either the shipments internal
* table or deliveries internal table as input and reads the            *
* corresponding delivery items and determines the no. of Packages,     *
* units (rolls) and generates output at Delivery Item level, Delivery  *
* Level and Shipment level(optional, generated only if the input is    *
* Shipment internal table).                                            *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* C. Cherupally       03/01/07  EDEK907395  Initial creation           *
*                                                                      *
* W. Mitzner          06/18/07  EDEK908273  Added the Volume Calculate *
*                                           for each line item         *
*                                           Summarize by Delivery &    *
*                                           Shipment                   *
*                                                                      *
* W. Mitzner          06/21/07  EDEK908444  Changed the Volume Calc    *
* C. Cherupally                             for SALES_ROLL_1           *
*                                           and SALES_ROLL_2           *
*                                           and SALES_BALE_1 to be done*
*                                           by material/batch splits   *
*                                                                      *
* C. Cherupally       09/12/07  EDEK909422   CR#6546 Sheeter & Cartons *
*                                           Volume calc.               *
*                                                                      *
* C. Cherupally       07/09/08  EDVK964144  CR8056/TPR25002 - Added    *
*                                           logic to determine Sales   *
*                                           Unit tolerances            *
* C. Cherupally       08/13/08  EDVK965182  CR 8289 - Tolerances       *
*                                           (search CC01)              *
* C. Cherupally       08/14/08  EDVK965182  TPR 1780 (Search CC02)     *
*                                           Added code for Skids/Cartons
*                                           dimension & non-dimension id
* Kishor Thakur       01/30/09  EDVK968126  PRICEFI0197
*                                           Added table containing
*                                           HU data for SHIPMENT
*                                           or Delivery
* C. Ramey            02/26/09  EDVK968126  PRICEF 07420 - add in logic
*                                           for rounding up MTO skids
* C. Cherupally       04/27/09  EDVK970680  TPR 31346 - No.of packages *
*                                           coming as zero for MTS Roll*
*                                           product - search CC03      *
*                                           TPR 31546 - fix the above
* C. Cherupally       10/12/09 EDEK916150   As part of new DSR changes,*
*                                           changed the logic around   *
*                                           sy-tabix in order to make it
*                                           work for multiple shipments*
*                                           search CC04
* Amit Maole 06/08/2017 CMS31694 Add new characteristics for Madrid Prj*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*      'VC_I_GET_CONFIGURATION_IBASE' - To get VC data                 *
*      'Z_MM_GET_APO_RFCDES' - To get RFC destination                  *
*      'ZDL_I01217_GUIDANCE_READ' - RFC call to get APO guidance data  *
*      'ZSD_VC_GET_DENSITY' - To get the density factor                *
*      'ZSD_VC_GET_WEIGHT_VALUES' - To get weight values               *
*      'CEVA_CONVERT_FLOAT_TO_CHAR' - To do float to char conversion   *
*      'CLAF_CLASSIFICATION_OF_OBJECTS' - To get batch characteristics *
*      'CONVERSION_EXIT_ATINN_INPUT' - To do conversion                *
*                                                                      *
*   Transactions    :                                                  *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************


  DATA : lv_delv(12)      TYPE n,
         lv_tknum         TYPE tknum,
         lv_ship_units    TYPE anzpk,
         lv_ship_pckgs    TYPE anzpk,
         lv_ship_ntgew    TYPE ntgew_15,
         lv_ship_brgew    TYPE brgew_15,
         lv_delv_units    TYPE anzpk,
         lv_delv_pckgs    TYPE anzpk,
         lv_delv_ntgew    TYPE ntgew_15,
         lv_delv_brgew    TYPE brgew_15,
         lv_delv_uom      TYPE lrmei,
         lv_ship_uom      TYPE lrmei,
*
         lv_ship_volume   TYPE volum,
         lv_ship_voluom   TYPE meins,
         lv_delv_volume   TYPE volum,
         lv_delv_voluom   TYPE meins,
*
         lv_diff_delv_uom,
         lv_diff_ship_uom,
         lv_ship_del,   "Flag to identify Shipment or Delivery

         lv_tabix         TYPE sy-tabix.                    " CC04

  REFRESH : gt_delv_item_units,
            gt_delv_units,
            gt_atnam,  "PRICEF 01298 CR# 10132
            gt_ship_units.
  CLEAR   : gt_delv_item_units,
            gt_delv_units,
            gt_ship_units,
            gt_atnam,  "PRICEF 01298 CR# 10132
            lv_tabix.

* As per the assumptions, atleast one of the three input tables is
* provided to get the required output.
  IF it_shipments[]   IS   INITIAL AND
     it_deliveries[]  IS   INITIAL.
    RAISE invalid_input.
  ENDIF.

*Begin insert by jpieri - PRICEF 01298 CR# 10132
*Save a copy of the input parameter for the internal batch characteristic key
  IF it_atnam[] IS NOT INITIAL.
    gt_atnam[] = it_atnam[].
  ENDIF.
*End insert by jpieri - PRICEF 01298 CR# 10132

* As per the assumptions, if shipment(s) are provided, deliveries
* are ignored.
  IF it_shipments[] IS NOT INITIAL.
    REFRESH  : gt_vbeln,
               gt_delv_data.
    gt_shipments[] = it_shipments[].
* Collect shipment numbers for RFC Call to APO Guidance
    LOOP AT it_shipments INTO gs_shipments.
      gs_shipment-shipment = gs_shipments-tknum.
      APPEND gs_shipment TO gt_shipment_no.
    ENDLOOP.
    PERFORM get_deliveries TABLES gt_shipments.
    PERFORM get_delivery_data.
*>> Begin change by kthakur  PRICEFI0197  TR # EDVK968126
*    lv_ship_del = 'T'.
*    REFRESH : gt_vekp,gt_vepo.
*     perform get_hu_data using lv_ship_del.
*<< End change by kthakur PRICEFI0197  TR # EDVK968126
  ELSEIF it_deliveries[] IS NOT INITIAL.
    REFRESH  : gt_vbeln,
               gt_delv_data.
    gt_delivery[] = it_deliveries[].
    LOOP AT gt_delivery.
      gt_vbeln-vbeln = gt_delivery-vbeln.
      APPEND gt_vbeln.
      CLEAR gt_vbeln.
    ENDLOOP.
    IF NOT gt_vbeln[] IS INITIAL.
      SORT gt_vbeln BY vbeln.
      DELETE ADJACENT DUPLICATES FROM gt_vbeln.
      PERFORM get_delivery_data.
    ENDIF.
  ENDIF.
*>> Begin change by kthakur  PRICEFI0197  TR # EDVK968126
  PERFORM get_hu_data.
*>> End change by kthakur  PRICEFI0197  TR # EDVK968126
* >> Begin of change - CCHERUP - CR8056/TPR25002
  PERFORM get_ekko_data.
  PERFORM get_ekkn_data.
* << End of change - CCHERUP - CR8056/TPR25002
* Getting VBUP data (Picking & Packing status)
  PERFORM get_vbup_data.
* Getting VC data for MARC-CUOBJ
  PERFORM get_marc_vc_data.
* Determing MTO/MTS and doing further calculations
  PERFORM determine_mto_mts.
  SORT gt_delv_item_units BY tknum vbeln posnr.

  t_delv_item_units[] = gt_delv_item_units[].

  SORT gt_delv_batch_char BY vbeln posnr item.

  LOOP AT gt_delv_item_units.
    lv_tabix = sy-tabix.                                    " CC04
    AT NEW vbeln.                                           " CC04
      CLEAR lv_delv_uom.                                    " CC04
    ENDAT.                                                  " CC04
    AT NEW tknum.                                           " CC04
      CLEAR lv_ship_uom.                                    " CC04
    ENDAT.                                                  " CC04
    IF lv_delv_uom IS INITIAL.
      lv_delv_uom = gt_delv_item_units-uom.
    ENDIF.
    IF lv_ship_uom IS INITIAL.
      lv_ship_uom = gt_delv_item_units-uom.
    ENDIF.
    IF lv_delv_uom NE gt_delv_item_units-uom.
      lv_diff_delv_uom = 'X'.
    ENDIF.
    IF lv_ship_uom NE gt_delv_item_units-uom.
      lv_diff_ship_uom = 'X'.
    ENDIF.
    IF lv_delv_voluom IS INITIAL.
      lv_delv_voluom = gt_delv_item_units-voluom.
    ENDIF.
    IF lv_ship_voluom IS INITIAL.
      lv_ship_voluom = gt_delv_item_units-voluom.
    ENDIF.

* Shipment Level calculations, only if shipment(s) is entered
    IF it_shipments[] IS NOT INITIAL.
      lv_ship_pckgs  = lv_ship_pckgs  + gt_delv_item_units-packages.
      lv_ship_units  = lv_ship_units  + gt_delv_item_units-units.
      lv_ship_ntgew  = lv_ship_ntgew  + gt_delv_item_units-ntgew.
      lv_ship_brgew  = lv_ship_brgew  + gt_delv_item_units-brgew.
      lv_ship_volume = lv_ship_volume + gt_delv_item_units-volume.
    ENDIF.

* Delivery Level calculations
    lv_delv_pckgs  = lv_delv_pckgs  + gt_delv_item_units-packages.
    lv_delv_units  = lv_delv_units  + gt_delv_item_units-units.
    lv_delv_ntgew  = lv_delv_ntgew  + gt_delv_item_units-ntgew.
    lv_delv_brgew  = lv_delv_brgew  + gt_delv_item_units-brgew.
    lv_delv_volume = lv_delv_volume + gt_delv_item_units-volume.

*------  AT END of Delivery  ------------------------------------------*
    AT END OF vbeln.
      READ TABLE gt_delv_item_units INDEX lv_tabix.         " CC04
      gt_delv_units-tknum = gt_delv_item_units-tknum.
      gt_delv_units-vbeln = gt_delv_item_units-vbeln.
      gt_delv_units-packages = lv_delv_pckgs.
      gt_delv_units-units = lv_delv_units.
      IF lv_diff_delv_uom NE 'X'.
        gt_delv_units-uom = lv_delv_uom.
      ENDIF.
      gt_delv_units-ntgew  = lv_delv_ntgew.
      gt_delv_units-brgew  = lv_delv_brgew.
      gt_delv_units-gewei  = gt_delv_item_units-gewei.
      gt_delv_units-volume = lv_delv_volume.
      gt_delv_units-voluom = lv_delv_voluom.
      REFRESH gt_batch_char.
      LOOP AT gt_delv_batch_char WHERE vbeln EQ gt_delv_units-vbeln.
        MOVE-CORRESPONDING gt_delv_batch_char TO gt_batch_char.
        APPEND gt_batch_char.
        CLEAR  gt_batch_char.
      ENDLOOP.
      gt_delv_units-batch_char[] = gt_batch_char[].
      APPEND gt_delv_units.
      CLEAR  gt_delv_units.
      CLEAR : lv_delv_units, lv_delv_ntgew, lv_delv_brgew,
              lv_diff_delv_uom, lv_delv_pckgs,
              lv_delv_volume, lv_delv_voluom.
    ENDAT.

*------  AT END of Shipment  ------------------------------------------*
    AT END OF tknum.
      IF it_shipments[] IS NOT INITIAL.
        READ TABLE gt_delv_item_units INDEX lv_tabix.       " CC04
        gt_ship_units-tknum = gt_delv_item_units-tknum.
        gt_ship_units-packages = lv_ship_pckgs.
        gt_ship_units-units = lv_ship_units.
        IF lv_diff_ship_uom NE 'X'.
          gt_ship_units-uom = lv_ship_uom.
        ENDIF.
        gt_ship_units-ntgew = lv_ship_ntgew.
        gt_ship_units-brgew = lv_ship_brgew.
        gt_ship_units-gewei = gt_delv_item_units-gewei.
        gt_ship_units-volume = lv_ship_volume.
        gt_ship_units-voluom = lv_ship_voluom.
        APPEND gt_ship_units.
        CLEAR  gt_ship_units.
        CLEAR : lv_ship_units, lv_ship_ntgew, lv_ship_brgew,
                lv_diff_ship_uom, lv_ship_pckgs,
                lv_ship_volume, lv_ship_voluom.
      ENDIF.
    ENDAT.
  ENDLOOP.

*------  SORT  --------------------------------------------------------*
  IF it_shipments[] IS NOT INITIAL.
    SORT gt_ship_units BY tknum.
    t_ship_units[] = gt_ship_units[].
  ENDIF.

  SORT gt_delv_units BY tknum vbeln.
  t_delv_units[] = gt_delv_units[].
* Begin insert by kthakur
  IF NOT gt_hu_contents[] IS INITIAL.
    SORT gt_hu_contents BY exidv.
    t_hu_contents[] = gt_hu_contents[].
    CLEAR :gt_hu_contents.
    REFRESH: gt_hu_contents[].
  ENDIF.

ENDFUNCTION.

FUNCTION-POOL zdl_e03126.                   "MESSAGE-ID ..

* Begin of BCB02
  TYPES: BEGIN OF gts_lips,
           vbeln TYPE vbeln_vl,
           posnr TYPE posnr_vl,
           matnr TYPE matnr,
           lichn TYPE lichn, "Vendor Batch
           vgbel TYPE vgbel,
        END OF gts_lips.

* Types to store delivery number and bill of lading number
  TYPES: BEGIN OF gts_likp,
           vbeln TYPE vbeln_vl,
           bolnr TYPE bolnr,
        END OF gts_likp.

* Types to store handling unit number,vendor unit number and objects
  TYPES: BEGIN OF gts_vekp,
         venum TYPE venum,
         exidv TYPE venum,
         inhalt TYPE inhalt,
         vpobj  TYPE vpobj,
         vpobjkey TYPE vpobjkey,
        END OF gts_vekp.

* Types to store convertion object
  TYPES: BEGIN OF gts_obj,
           object TYPE vpobjkey,
         END OF gts_obj.

*Internal Table to store Handling Unit data
  DATA: gt_vekp TYPE STANDARD TABLE OF gts_vekp,
        gs_vekp TYPE gts_vekp.

*Internal table to store Delivery header data
  DATA: gt_likp TYPE STANDARD TABLE OF gts_likp,
        gs_likp TYPE gts_likp.

*Internal table to store Delivery item data
  DATA: gt_lips TYPE STANDARD TABLE OF gts_lips,
        gs_lips TYPE gts_lips.

*Internal table to store temp object convertion data
  DATA: gt_obj TYPE STANDARD TABLE OF gts_obj,
        gs_obj TYPE gts_obj.

DATA:
    gv_dup     TYPE  boolean.   "Duplicate indicator

CONSTANTS:
    gc_true              TYPE  boolean VALUE 'X',   "True
    gc_false             TYPE  boolean VALUE '-'.   "False


* End of BCB02



**&---------------------------------------------------------------------*
**&      Form  Generate_unit_id
**&---------------------------------------------------------------------*
**       This routine is used to generate a sequantial number based on
**       system date.
**----------------------------------------------------------------------*
**  -->  P_WS_BATCH_NUM      Previous Batch number Stored in a table
**  <--  WS_ID               Generated new batch/unitid number
**----------------------------------------------------------------------*
*FORM generate_unit_id USING    p_ws_batch_num TYPE zcharg_d
*                      CHANGING ws_id.
*
**--------Constants Declaration-----------------------------------------*
*CONSTANTS: c_flag     TYPE char1 VALUE 'X',          " Flag value
*           c_object06 TYPE nrobj VALUE 'ZDL_UNIT06',
*           " Number range object
*           c_object07 TYPE nrobj VALUE 'ZDL_UNITID',
*           " Number range object
*           c_number   TYPE nrnr  VALUE '01',         " Number sequence
*           c_zz       TYPE char2 VALUE 'ZZ',         " value ZZ
*           c_a        TYPE char1 VALUE 'A'.          " value A
*
**--------Variable Declaration------------------------------------------*
*DATA: ws_unitid   TYPE char07,                " 7 digit Sequntial number
*      ws_unitid06 TYPE char6,                 " 6 digit Sequntial number
*      ws_alpha    TYPE sy-abcde,              " Alphabets
*      ws_offset   TYPE i,                     " Offset value
*      ws_char     TYPE char1,                 " single character
*      ws_flag     TYPE char1,                 " flag value
*      ws_year     TYPE gjahr.                 " Year
*
**Clear all variables
* CLEAR: ws_unitid,
*        ws_unitid06,
*        ws_alpha,
*        ws_offset,
*        ws_char,
*        ws_flag,
*        ws_year.
*
*  ws_alpha  = sy-abcde.                " Move Alphabets into variable
*  ws_unitid = p_ws_batch_num+3(7).     " Move Sequential Number
*
**check whether the number reached maximum level or contains any
**alphabets
* IF ws_unitid+0(1) CA ws_alpha OR ws_unitid = '9999999'.
*
*    ws_year = sy-datum+0(4).          " Move year only
**   check for current year
*    IF p_ws_batch_num+2(1) <> ws_year+3(1).
*      ws_flag = c_flag.
*    ENDIF.
**if the year matches, call function 'NUMBER_GET_NEXT' to generate a
**sequantial number
*    IF ws_flag <> c_flag.
*      CALL FUNCTION 'NUMBER_GET_NEXT'
*        EXPORTING
*          nr_range_nr             = c_number
*          object                  = c_object06
*        IMPORTING
*          number                  = ws_unitid06
*        EXCEPTIONS
*          interval_not_found      = 1
*          number_range_not_intern = 2
*          object_not_found        = 3
*          quantity_is_0           = 4
*          quantity_is_not_1       = 5
*          interval_overflow       = 6
*          buffer_overflow         = 7
*          OTHERS                  = 8.
*      IF sy-subrc = 0.
*        IF ws_unitid06 = '000001'.
*          IF ws_unitid = '9999999'.
*            CONCATENATE c_zz ws_year+3(1) c_a ws_unitid06 INTO ws_id.
*          ELSE.
*            FIND  ws_unitid+0(1) IN ws_alpha MATCH OFFSET ws_offset.
*            ws_offset = ws_offset + 1.
*            ws_char = ws_alpha+ws_offset(1).
*            CONCATENATE c_zz ws_year+3(1) ws_char ws_unitid06 INTO ws_id
*            .
*          ENDIF.
*        ELSE.
*          CONCATENATE p_ws_batch_num+0(4) ws_unitid06 INTO ws_id.
*        ENDIF.
*      ELSE.
*          RAISE NUMBER_RANGE_NOT_FOUND.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
**If the year does not matches,start generating sequential  number from
**the begining
* IF ws_flag = c_flag OR
*   ( ws_unitid < '9999999' AND ws_unitid+0(1) NA ws_alpha ).
**   Current year
*    ws_year = sy-datum+0(4).
**   Call function to generate a Sequential number
*    CALL FUNCTION 'NUMBER_GET_NEXT'
*      EXPORTING
*        nr_range_nr             = c_number
*        object                  = c_object07
*        toyear                  = ws_year
*      IMPORTING
*        number                  = ws_unitid
*      EXCEPTIONS
*        interval_not_found      = 1
*        number_range_not_intern = 2
*        object_not_found        = 3
*        quantity_is_0           = 4
*        quantity_is_not_1       = 5
*        interval_overflow       = 6
*        buffer_overflow         = 7
*        OTHERS                  = 8.
*    IF sy-subrc = 0.
*      CONCATENATE c_zz ws_year+3(1) ws_unitid INTO ws_id.
*      CLEAR ws_flag.
*    ELSE.
*        RAISE NUMBER_RANGE_NOT_FOUND.
*    ENDIF.
* ENDIF.
*ENDFORM.                    " Generate_unit_id

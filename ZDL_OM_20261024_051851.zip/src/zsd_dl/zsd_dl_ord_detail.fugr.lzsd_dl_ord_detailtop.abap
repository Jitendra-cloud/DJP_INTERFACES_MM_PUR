FUNCTION-POOL zsd_dl_ord_detail.            "MESSAGE-ID ..

*// begin of schaudh 10/19/2005
*/  declared the table AFRU .
TABLES :   AFRU .                               "<< EDVK940286

DATA : BEGIN OF t_afru occurs 0 ,               "<< EDVK940286
        aufnr like afru-aufnr,
        satza like afru-satza,
      END OF t_afru.

CONSTANTS : c_confirm_l20 like afru-satza value 'L20' .
*// end of schaudh 10/19/2005 .

CONSTANTS: c_trim_order LIKE aufk-auart VALUE 'ZTRM'.

* For ZSD_DL_CR3694_READ_MACHINE_DET
CONSTANTS: c_aplzl LIKE afvc-aplzl VALUE '00000001',
           c_objty LIKE crhd-objty VALUE 'A'.

* For selecting data from RESB
DATA: BEGIN OF t_resb OCCURS 0,
        rsnum LIKE resb-rsnum,
        rspos LIKE resb-rspos,
        rsart LIKE resb-rsart,
        xloek LIKE resb-xloek,
        erfmg LIKE resb-erfmg,
        erfme LIKE resb-erfme,
        aufnr LIKE resb-aufnr,
        kdauf LIKE resb-kdauf,
        kdpos LIKE resb-kdpos,
        objnr LIKE resb-objnr,
        afpos LIKE resb-afpos,
      END OF t_resb.

* For selecting data from AUFK
DATA: BEGIN OF t_aufk OCCURS 0,
        aufnr LIKE aufk-aufnr,
*        posnr like afpo-posnr,
        kdauf LIKE resb-kdauf,
        kdpos LIKE resb-kdpos,
        auart LIKE aufk-auart,
        kRSNR like afpo-kRSNR,
        kRSPS like afpo-krsps,
      END OF t_aufk.

* Begin of change  03/10/2008
data: t_aufk_pkg like t_aufk occurs 0 WITH HEADER LINE.
  data: begin of int_afpo OCCURS 0,
          aufnr type aufnr,
          dauat type auart,
          krsnr type rsnum,
          krsps type rspos,
          vbeln type vbeln,
          posnr type posnr,
        end of int_afpo.
  data: begin of int_afpo_temp OCCURS 0,
          aufnr type aufnr,
          dauat type auart,
          krsnr type rsnum,
          krsps type rspos,
          vbeln type vbeln,
          posnr type posnr,
        end of int_afpo_temp.
* End of change  03/10/2008
Types: begin of ty_jest,
        aufnr type aufnr,
        STAT  type char5,
        inact type char1,
       end of ty_jest.

data: int_jest type standard table of ty_jest with header line initial size 0.



DATA: t_sales_ord_in  LIKE zst_trim_details
                OCCURS 0 WITH HEADER LINE,
      t_sales_ord_out LIKE zst_trim_details
                OCCURS 0 WITH HEADER LINE.

* For filtering records from RESB using AUFK, into orders that
*  have a trim record in AUFK and those that don't, respectively.
*  ( Records without an AUFK 'Trim' record will be processed
*     using NCP rules ).
DATA: t_resb_aufk LIKE t_resb         OCCURS 0 WITH HEADER LINE,
      t_ncp       LIKE t_sales_ord_in OCCURS 0 WITH HEADER LINE.

* ATINN mapping fields
DATA: g_sets_atinn LIKE ibinval_sel_f-atinn,
      g_utwt_atinn LIKE ibinval_sel_f-atinn,
      g_node_atinn LIKE ibinval_sel_f-atinn.

* Range for mapped ATINN values SELECT by Characteristic names
RANGES: r_atinn FOR ibinval_sel_f-atinn.

* PROCESS_NCP internal table to get/track
*      packaging Production Order Data
DATA: BEGIN OF t_afpo OCCURS 0,
        aufnr LIKE afpo-aufnr,
        posnr LIKE afpo-posnr,
        kdauf LIKE afpo-kdauf,
        kdpos LIKE afpo-kdpos,
        psmng LIKE afpo-psmng,
        meins like afpo-meins,
        objkey LIKE ibinval_sel_f-objkey,
      END OF t_afpo.

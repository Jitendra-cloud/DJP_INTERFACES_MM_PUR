*&---------------------------------------------------------------------*
*&  Include           ZDL_E3637_3RD_PARTY_DISC_TOP                     *
*&---------------------------------------------------------------------*
report  zdl_e3637_3rd_party_disc   message-id zsd_dl.

************************************************************************
*   DATA DECLARATION
************************************************************************
constants:
  gc_success value 'S',
  gc_msgid   type  symsgid  value 'ZSD_DL'.

tables:
  likp,    "Delivery Header
  lips,    "Delivery Item
  ekko.                                                         "33303

type-pools:
  slis.    "For ALV list

data:
* Report Output
  begin of gs_rep,
    vgbel  type vgbel,       "Sales order
    ebeln  type ebeln,       "Purchase order
    vbelv  type vbeln_vl,    "Inbound delivery
    vbeln  type vbeln_vl,    "Delivery
    posnr  type posnr_vl,    "Delivery item
    matnr  type matnr,       "Material Number
    lichn  type lichn,       "Vendor Batch Number
    charg  type charg_d,     "SAP Batch Number
    lfimg  type lfimg,       "Actual Qty Delivered (in sales unit)
    vrkme  type vrkme,       "Sales UOM
    erdat  type erdat,       "GR date
    ekorg  type ekko-ekorg,                                     "33303
    vkorg  type vbak-vkorg,                                     "33303
    line_color(4) type c,    "used to store row color attributes
  end of gs_rep,

  gt_rep like table of gs_rep,

* Sales order and Pur. order information
  begin of gs_so_p,
    vbelv  type vbeln_vl,   "Sales order
    vbeln  type vbeln_nach, "Purchase order
    ekorg  type ekko-ekorg,                                     "33303
  end of gs_so_p,

  gt_so_p like table of gs_so_p,

* Inbound delivery information
  begin of gs_inb_dlvry,
    vgbel  type vgbel,      "Purchase Order
    vbeln  type vbeln_vl,   "Inbound Delivery
    matnr  type matnr,      "Material
    charg  type charg_d,    "SAP batch
  end of gs_inb_dlvry,

  gt_inb_dlvry like table of gs_inb_dlvry,

* For ALV Grid
  gs_layout    type slis_layout_alv,      "ALV layout
  gt_fieldcat  type slis_t_fieldcat_alv,  "Fieldcatalog
  gt_sort      type slis_t_sortinfo_alv.  "Sort table

************************************************************************
* SELECTION-SCREEN
************************************************************************

selection-screen begin of block b01 with frame title text-t01.

selection-screen skip.
* Delivery information
parameters:
  "Shipping /Receiving Point
  sp_plant like likp-vstel default '9427' obligatory.
select-options:
  so_vbeln for likp-vbeln,    "Outbound Delivery
  so_so    for lips-vgbel,    "Sales Order
  so_ekorg for ekko-ekorg,                                      "33303
  so_vkorg for likp-vkorg.                                      "33303
selection-screen skip.

selection-screen end of block b01.

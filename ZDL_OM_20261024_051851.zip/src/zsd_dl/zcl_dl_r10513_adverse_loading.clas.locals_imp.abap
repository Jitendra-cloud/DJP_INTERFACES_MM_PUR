*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

CLASS lcl_adverse_loading DEFINITION FINAL.
  PUBLIC SECTION.

* Local type declaration.
    TYPES:
* Screen fields
      BEGIN OF ty_s_input,
        mill TYPE tplst,
        date TYPE dptbg,
      END OF ty_s_input,

* Shipment Header( VTTK ) data
      BEGIN OF ty_s_vttk,
        tknum TYPE tknum,
        shtyp TYPE shtyp,
        tplst TYPE tplst,
        vsart TYPE vsarttr,
        vsbed TYPE vsbed,
        route TYPE routr,
        dptbg TYPE dptbg,
        sttrg TYPE sttrg,
        tdlnr TYPE tdlnr,
        sdabw TYPE sdabw,
      END OF ty_s_vttk,

* Stage of Shipment( VTTS ) data
      BEGIN OF ty_s_vtts,
        tknum   TYPE tknum,
        tsnum   TYPE tsnum,
        distz   TYPE distz,
        knota   TYPE knota,
        knotz   TYPE knotz,
        abpstlz TYPE abpstlz,
        edpstlz TYPE edpstlz,
      END OF ty_s_vtts,

* Shipment Item ( VTTP ) data
      BEGIN OF ty_s_vttp,
        tknum TYPE tknum,
        vbeln TYPE vbeln_vl,
      END OF ty_s_vttp,

* SD document: Delivery: Item data ( LIPS ) data
      BEGIN OF ty_s_lips,
        vbeln TYPE vbeln_vl,
        mfrgr TYPE mfrgr,
        vgbel TYPE vgbel,
        spart TYPE spart,
      END OF ty_s_lips,

* SD Document: Delivery Header Data ( LIKP )
      BEGIN OF ty_s_likp,
        vbeln TYPE vbeln_vl,
        kunnr TYPE kunwe,
      END OF ty_s_likp,

* General Data in Customer Master ( KNA1 ) data
      BEGIN OF ty_s_kna1,
        kunnr TYPE kunnr,
        name1 TYPE name1_gp,
        ort01 TYPE ort01_gp,
        regio TYPE regio,
        pstlz TYPE pstlz,
        land1 TYPE land1_gp,
      END OF ty_s_kna1,

* Purchasing Document Item ( EKPO ) data
      BEGIN OF ty_s_ekpo,
        ebeln TYPE ebeln,
        werks TYPE ewerk,
        lgort TYPE lgort_d,
      END OF ty_s_ekpo,

* Vendor Master (General Section) ( LFA1) data,
      BEGIN OF ty_s_lfa1,
        lifnr TYPE lifnr,
        name1 TYPE name1_gp,
        scacd TYPE scacd,
      END OF ty_s_lfa1,

* Mill Texts ( TVSBT ) data
      BEGIN OF ty_s_ttdst,
        tplst TYPE tplst,
        bezei TYPE bezei20,
      END OF ty_s_ttdst,

* Shipping Conditions: Texts ( TVSBT ) data
      BEGIN OF ty_s_tvsbt,
        vsbed TYPE vsbed,
        vtext TYPE vsbed_bez,
      END OF ty_s_tvsbt,

* Plants/Branches ( T001W ) data
*      BEGIN OF ty_s_t001w,
*        werks TYPE werks_d,
*        name1 TYPE name1,
*      END OF ty_s_t001w,

*Determination of Address from Plant and Storage Location ( TWLAD ) data.
      BEGIN OF ty_s_twlad,
        werks TYPE werks_d,
        lgort TYPE lgort_d,
        adrnr TYPE ad_addrnum,
      END OF ty_s_twlad,

* Addresses (Business Address Services) ( ADRC ) data.
      BEGIN OF ty_s_adrc,
        addrnumber TYPE ad_addrnum,
        name1      TYPE ad_name1,
        city1      TYPE ad_city1,
        post_code1 TYPE ad_pstcd1,
        region     TYPE regio,
        country    TYPE land1,
      END OF ty_s_adrc,

* Rail Route Data,
      BEGIN OF ty_s_route_info,
        primary_route   TYPE route,
        secondary_route TYPE route,
        prim_tdlnr      TYPE tdlnr,
        sec_tdlnr       TYPE tdlnr,
        prim_routid     TYPE routid,
        sec_routid      TYPE routid,
      END OF ty_s_route_info,

* Rail Rate Info
      BEGIN OF ty_s_rate_info,
        primary_rate   TYPE kbetr_kond,
        secondary_rate TYPE kbetr_kond,
      END OF ty_s_rate_info,

* Rail Rate Primary/Secondary info.
      BEGIN OF ty_s_rail_route_info,
        kotabnr            TYPE kotabnr,
        kappl              TYPE kappl,
        kschl              TYPE kscha,
        vstel              TYPE vstel,
        kunwe              TYPE kunwe,
        vsbed              TYPE vsbed,
        pstlz              TYPE pstlz,
*        tdlnr              TYPE tdlnr,
        bezei              TYPE routbez,
*        routid4            TYPE char4,
*        serv_preference    TYPE /saprgx/serv_preference,
*        non_compliance     TYPE /saprgx/non_compliance,
        datab              TYPE kodatab,
        datbi              TYPE kodatbi,
        primary_route      TYPE route,
        primary_tdlnr      TYPE tdlnr,
        primary_route_id   TYPE routid,
        secondary_route    TYPE route,
        secondary_tdlnr    TYPE tdlnr,
        secondary_route_id TYPE routid,
      END OF ty_s_rail_route_info,

* Read info
      BEGIN OF ty_s_read_info,
        shipment_type      TYPE kscha,
        service_agent      TYPE tdlnrs,
        shipping_condition TYPE vsbed,
        departure_point    TYPE knota,
        destination_point  TYPE knotz,
        destination_region TYPE regioz,
        customer           TYPE kunnr_v,
        city               TYPE /saprgx/cstvnd_city,
        stcc               TYPE zzstcc,
        trsp_plan_point    TYPE tplst,
        route              TYPE routr,
        country            TYPE land1z,
        sdabw              TYPE sdabw,
        date               TYPE dptbg,
      END OF ty_s_read_info,

* Table type:
      ty_t_rail_route_info TYPE STANDARD TABLE OF ty_s_rail_route_info.

* Structure declaration.
    CLASS-DATA: gs_screen_input TYPE ty_s_input.

*    CLASS-DATA: gr_date TYPE /ibx/ty_system_date_ran.
    CLASS-DATA: gr_date TYPE piq_selopt_t.

* Internal table declaration.
    CLASS-DATA: gt_vttk           TYPE STANDARD TABLE OF ty_s_vttk,
                gt_ttdst          TYPE STANDARD TABLE OF ty_s_ttdst,
                gt_ship_text      TYPE STANDARD TABLE OF ty_s_tvsbt,
                gt_vtts           TYPE STANDARD TABLE OF ty_s_vtts,
                gt_vttp           TYPE STANDARD TABLE OF ty_s_vttp,
                gt_lips           TYPE STANDARD TABLE OF ty_s_lips,
                gt_likp           TYPE STANDARD TABLE OF ty_s_likp,
                gt_kna1           TYPE STANDARD TABLE OF ty_s_kna1,
                gt_ekpo           TYPE STANDARD TABLE OF ty_s_ekpo,
                gt_lfa1           TYPE STANDARD TABLE OF ty_s_lfa1,
*                gt_t001w              TYPE STANDARD TABLE OF ty_s_t001w,
                gt_twlad          TYPE STANDARD TABLE OF ty_s_twlad,
                gt_adrc           TYPE STANDARD TABLE OF ty_s_adrc,
                gt_load_fee       TYPE STANDARD TABLE OF zdl_adverse_load,
                gt_rail_route_911 TYPE STANDARD TABLE OF ty_s_rail_route_info,
                gt_rail_route_909 TYPE STANDARD TABLE OF ty_s_rail_route_info,
                gt_rail_route_902 TYPE STANDARD TABLE OF ty_s_rail_route_info,
                gt_rail_route_907 TYPE STANDARD TABLE OF ty_s_rail_route_info,
                gt_rail_route_908 TYPE STANDARD TABLE OF ty_s_rail_route_info,
                gt_rail_route_910 TYPE STANDARD TABLE OF ty_s_rail_route_info,
                gt_rail_rate_983  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_981  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_958  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_946  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_936  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_900  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_933  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_971  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_943  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_937  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_906  TYPE zdle11459_lt_rail_rate_t,
                gt_rail_rate_919  TYPE zdle11459_lt_rail_rate_t,
*                gt_rail_rate          TYPE zdle11459_lt_rail_rate_t,
*                gt_rail_rate_911      TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_911_pr   TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_911_sr   TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_911_data TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_909      TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_902      TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_907      TYPE zdle11462_lt_rail_route_t,
*                gt_rail_rate_908      TYPE zdle11462_lt_rail_route_t,
*                gt_rail_route_data TYPE STANDARD TABLE OF ty_s_rail_route_data,
                gt_alv_data       TYPE STANDARD TABLE OF zcl_dl_r10513_adverse_loading=>ty_s_alv_data.

    CLASS-DATA: gv_message TYPE string.

* Methods
    METHODS: validate_mill,
      get_data,
      prepare_alv_data.

  PRIVATE SECTION.
    METHODS: get_vttk_data,
      get_mill_text,
      get_ship_text,
      get_vtts_data,
      get_vttp_data,
      get_lips_data,
      get_likp_data,
      get_kna1_data,
      get_ekpo_data,
      get_lgort_data,
      get_rail_route_data,
      get_rail_rate_data,
      read_arrw_tables
        IMPORTING
          is_route_info     TYPE ty_s_route_info
          is_read_info      TYPE ty_s_read_info
        EXPORTING
          ev_primary_rate   TYPE kbetr_kond
          ev_secondary_rate TYPE kbetr_kond,
      read_ztfs_tables
        IMPORTING
          is_route_info     TYPE ty_s_route_info
          is_read_info      TYPE ty_s_read_info
        EXPORTING
          ev_primary_rate   TYPE kbetr_kond
          ev_secondary_rate TYPE kbetr_kond,
      read_ztfm_tables
        IMPORTING
          is_route_info     TYPE ty_s_route_info
          is_read_info      TYPE ty_s_read_info
        EXPORTING
          ev_primary_rate   TYPE kbetr_kond
          ev_secondary_rate TYPE kbetr_kond,
      read_zrbw_tables
        IMPORTING
          is_route_info     TYPE ty_s_route_info
          is_read_info      TYPE ty_s_read_info
        EXPORTING
          ev_primary_rate   TYPE kbetr_kond
          ev_secondary_rate TYPE kbetr_kond,
      merge_route_data
        IMPORTING
          iv_kotabnr    TYPE kotabnr
          it_rail_route TYPE zdle11462_lt_rail_route_t
        EXPORTING
          et_rail_route TYPE  ty_t_rail_route_info,
*      get_merge_route_911_data CHANGING
*                                 ct_rail_route TYPE zdle11462_lt_rail_route_t,
*      get_merge_route_909_data CHANGING
*                                 ct_rail_route TYPE zdle11462_lt_rail_route_t,
*      get_merge_route_902_data CHANGING
*                                 ct_rail_route TYPE zdle11462_lt_rail_route_t,
*      get_address_route_rate,
      get_lfa1_data,
      get_adv_load_fee_data,
      get_rail_route_info IMPORTING iv_tplst      TYPE tplst
                                    iv_kunnr      TYPE kunnr
                                    iv_pstlz      TYPE pstlz
                                    iv_vsbed      TYPE vsbed
                                    iv_date       TYPE dptbg
                          EXPORTING es_route_info TYPE ty_s_route_info,
      get_rail_rate_info
        IMPORTING
          is_route_info TYPE ty_s_route_info
          is_read_info  TYPE ty_s_read_info
        EXPORTING
          es_rate_info  TYPE ty_s_rate_info.
ENDCLASS.

CLASS lcl_adverse_loading IMPLEMENTATION.
  METHOD: validate_mill.
    SELECT tplst
      FROM vttk
      INTO TABLE @DATA(lt_mill_point)
      WHERE tplst = @gs_screen_input-mill.
    IF sy-subrc <> 0.
      MESSAGE e001(zdl_r10513) WITH gs_screen_input-mill
                               INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD get_data.
    get_vttk_data( ).
    IF gv_message IS NOT INITIAL.
      RETURN.
    ENDIF.
    get_mill_text( ).
    get_ship_text( ).
    get_vtts_data( ).
    get_vttp_data( ).
    get_lips_data( ).
    get_likp_data( ).
    get_kna1_data( ).
    get_ekpo_data( ).
    get_lgort_data( ).
    get_rail_route_data( ).
    get_rail_rate_data( ).
    get_lfa1_data( ).
    get_adv_load_fee_data( ).
  ENDMETHOD.
  METHOD get_vttk_data.
    SELECT tknum,
           shtyp,
           tplst,
           vsart,
           vsbed,
           route,
           dptbg,
           sttrg,
           tdlnr,
           sdabw
      FROM vttk
      INTO TABLE @gt_vttk
      WHERE tplst = @gs_screen_input-mill AND
            dptbg IN @gr_date AND
            sttrg = '1' AND
            vsart = 'ZB'.
    IF sy-subrc <> 0.
      CLEAR gt_vttk.
      MESSAGE e002(zdl_r10513) WITH gs_screen_input-mill
                               INTO gv_message.
      RETURN.
    ENDIF.
* Avoid all the inbound shipments.
    LOOP AT gt_vttk INTO DATA(ls_vttk).
      IF ls_vttk+0(1) <> '2'.
        DELETE TABLE gt_vttk FROM ls_vttk.
      ENDIF.
    ENDLOOP.
    IF gt_vttk IS INITIAL.
      MESSAGE e002(zdl_r10513) WITH gs_screen_input-mill
                               INTO gv_message.
    ENDIF.
  ENDMETHOD.
  METHOD get_mill_text.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT tplst,
           bezei
      FROM ttdst
      INTO TABLE @gt_ttdst
      FOR ALL ENTRIES IN @gt_vttk
      WHERE spras = @sy-langu AND
            tplst = @gt_vttk-tplst.
    IF sy-subrc <> 0.
      CLEAR gt_ttdst.
    ENDIF.
  ENDMETHOD.
  METHOD get_ship_text.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT vsbed,
           vtext
      FROM tvsbt
      INTO TABLE @gt_ship_text
      FOR ALL ENTRIES IN @gt_vttk
      WHERE spras = @sy-langu AND
            vsbed = @gt_vttk-vsbed.
    IF sy-subrc <> 0.
      CLEAR gt_ship_text.
    ENDIF.
  ENDMETHOD.
  METHOD get_vtts_data.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT tknum,
           tsnum,
           distz,
           knota,
           knotz,
           abpstlz,
           edpstlz
      FROM vtts
      INTO TABLE @gt_vtts
      FOR ALL ENTRIES IN @gt_vttk
      WHERE tknum = @gt_vttk-tknum.
    IF sy-subrc = 0.
      SORT gt_vtts BY tknum ASCENDING
                      tsnum ASCENDING.
    ENDIF.
  ENDMETHOD.
  METHOD get_vttp_data.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT tknum,
           vbeln
      FROM vttp
      INTO TABLE @gt_vttp
      FOR ALL ENTRIES IN @gt_vttk
      WHERE tknum = @gt_vttk-tknum.
    IF sy-subrc = 0.
      SORT gt_vttp BY tknum ASCENDING.
    ENDIF.
  ENDMETHOD.
  METHOD get_lips_data.
    CHECK gt_vttp IS NOT INITIAL.
    SELECT vbeln,
           mfrgr,
           vgbel,
           spart
      FROM lips
      INTO TABLE @gt_lips
      FOR ALL ENTRIES IN @gt_vttp
      WHERE vbeln = @gt_vttp-vbeln.
    IF sy-subrc <> 0.
      CLEAR gt_lips.
    ENDIF.
  ENDMETHOD.
  METHOD get_likp_data.
    CHECK gt_vttp IS NOT INITIAL.
    SELECT vbeln,
           kunnr
      FROM likp
      INTO TABLE @gt_likp
      FOR ALL ENTRIES IN @gt_vttp
      WHERE vbeln = @gt_vttp-vbeln.
    IF sy-subrc <> 0.
      CLEAR gt_likp.
    ENDIF.
  ENDMETHOD.
  METHOD get_kna1_data.
    CHECK gt_likp IS NOT INITIAL.
    SELECT kunnr,
           name1,
           ort01,
           regio,
           pstlz,
           land1
      FROM kna1
      INTO TABLE @gt_kna1
      FOR ALL ENTRIES IN @gt_likp
      WHERE kunnr = @gt_likp-kunnr.
    IF sy-subrc <> 0.
      CLEAR gt_kna1.
    ENDIF.
  ENDMETHOD.
  METHOD get_ekpo_data.
    CHECK gt_lips IS NOT INITIAL.
    SELECT ebeln,
           werks,
           lgort
      FROM ekpo
      INTO TABLE @gt_ekpo
      FOR ALL ENTRIES IN @gt_lips
      WHERE ebeln = @gt_lips-vgbel.
    IF sy-subrc <> 0.
      CLEAR gt_ekpo.
    ENDIF.
  ENDMETHOD.
  METHOD get_rail_route_data.
    DATA: lt_rail_route       TYPE zdle11462_lt_rail_route_t.

    CALL FUNCTION 'ZDL_RAIL_ROUTE_ECC'
      EXPORTING
        ir_plnd_shp_date = gr_date
      IMPORTING
        et_adverse_rout  = lt_rail_route.

* Delete all the entries where Service preference is not 1 and 2.
    DELETE lt_rail_route WHERE serv_preference <> 1 AND
                               serv_preference <> 2.

    merge_route_data(
      EXPORTING
        iv_kotabnr    = '911'
        it_rail_route = lt_rail_route
      IMPORTING
        et_rail_route   = gt_rail_route_911 ).

    merge_route_data(
      EXPORTING
        iv_kotabnr    = '909'
        it_rail_route = lt_rail_route
      IMPORTING
        et_rail_route   = gt_rail_route_909 ).

    merge_route_data(
      EXPORTING
        iv_kotabnr    = '902'
        it_rail_route = lt_rail_route
      IMPORTING
        et_rail_route   = gt_rail_route_902 ).

    merge_route_data(
      EXPORTING
        iv_kotabnr    = '907'
        it_rail_route = lt_rail_route
      IMPORTING
        et_rail_route   = gt_rail_route_907 ).

    merge_route_data(
      EXPORTING
        iv_kotabnr    = '908'
        it_rail_route = lt_rail_route
      IMPORTING
        et_rail_route   = gt_rail_route_908 ).

    merge_route_data(
      EXPORTING
        iv_kotabnr    = '910'
        it_rail_route = lt_rail_route
      IMPORTING
        et_rail_route   = gt_rail_route_910 ).

  ENDMETHOD.
  METHOD get_rail_rate_data.

    DATA: lt_rail_rate TYPE zdle11459_lt_rail_rate_t.

    CALL FUNCTION 'ZDL_RAIL_RATE_ECC'
      EXPORTING
        ir_plnd_shp_date     = gr_date
      IMPORTING
        et_adverse_rail_rate = lt_rail_rate.

* Separate into internal table based on the table number.
    gt_rail_rate_983 = gt_rail_rate_981 = gt_rail_rate_958 =
    gt_rail_rate_946 = gt_rail_rate_936 = gt_rail_rate_900 =
    gt_rail_rate_933 = gt_rail_rate_971 = gt_rail_rate_943 =
    gt_rail_rate_937 = gt_rail_rate_906 = gt_rail_rate_919 = lt_rail_rate.

    DELETE gt_rail_rate_983 WHERE kotabnr <> '983'.
    DELETE gt_rail_rate_981 WHERE kotabnr <> '981'.
    DELETE gt_rail_rate_958 WHERE kotabnr <> '958'.
    DELETE gt_rail_rate_946 WHERE kotabnr <> '946'.
    DELETE gt_rail_rate_936 WHERE kotabnr <> '936'.
    DELETE gt_rail_rate_900 WHERE kotabnr <> '900'.
    DELETE gt_rail_rate_933 WHERE kotabnr <> '933'.
    DELETE gt_rail_rate_971 WHERE kotabnr <> '971'.
    DELETE gt_rail_rate_943 WHERE kotabnr <> '943'.
    DELETE gt_rail_rate_937 WHERE kotabnr <> '937'.
    DELETE gt_rail_rate_906 WHERE kotabnr <> '906'.
    DELETE gt_rail_rate_919 WHERE kotabnr <> '919'.
  ENDMETHOD.
  METHOD get_lgort_data.
    CHECK gt_ekpo IS NOT INITIAL.
    SELECT werks,
           lgort,
           adrnr
      FROM twlad
      INTO TABLE @gt_twlad
      FOR ALL ENTRIES IN @gt_ekpo
      WHERE werks = @gt_ekpo-werks AND
            lgort = @gt_ekpo-lgort.
    IF sy-subrc = 0.
      SELECT addrnumber,
             name1,
             city1,
             post_code1,
             region,
             country
        FROM adrc
        INTO TABLE @gt_adrc
        FOR ALL ENTRIES IN @gt_twlad
        WHERE addrnumber = @gt_twlad-adrnr.
      IF sy-subrc <> 0.
        CLEAR gt_adrc.
      ENDIF.
    ENDIF.

*    SELECT werks,
*           name1
*      FROM t001w
*      INTO TABLE @gt_t001w
*      FOR ALL ENTRIES IN @gt_ekpo
*      WHERE werks = @gt_ekpo-werks.
*    IF sy-subrc <> 0.
*      CLEAR gt_t001w.
*    ENDIF.
  ENDMETHOD.
  METHOD get_lfa1_data.
    CHECK gt_vttk IS NOT INITIAL.
    SELECT lifnr,
           name1,
           scacd
      FROM lfa1
      INTO TABLE @gt_lfa1
      FOR ALL ENTRIES IN @gt_vttk
      WHERE lifnr = @gt_vttk-tdlnr.
    IF sy-subrc <> 0.
      CLEAR gt_lfa1.
    ENDIF.
  ENDMETHOD.
  METHOD get_adv_load_fee_data.
    SELECT *
      FROM zdl_adverse_load
      INTO TABLE @gt_load_fee.
  ENDMETHOD.
  METHOD merge_route_data.
    CLEAR et_rail_route.

    DATA(lt_rail_route) = it_rail_route.

    SORT lt_rail_route BY kotabnr ASCENDING.

    DELETE lt_rail_route WHERE kotabnr <> iv_kotabnr.
    DATA(lt_rail_route_sec) = lt_rail_route.

    LOOP AT lt_rail_route INTO DATA(ls_rail_route) WHERE serv_preference = 1.
* Read the temp table LT_RAIL_ROUTE with serv_preference = 2.
      DATA(ls_rail_route_2) = VALUE #( lt_rail_route_sec[ kotabnr = ls_rail_route-kotabnr
                                                          kappl  = ls_rail_route-kappl
                                                          kschl  = ls_rail_route-kschl
                                                          vstel  = ls_rail_route-vstel
                                                          kunwe  = ls_rail_route-kunwe
                                                          vsbed  = ls_rail_route-vsbed
                                                          serv_preference = 2
                                                          datab  = ls_rail_route-datab
                                                          datbi  = ls_rail_route-datbi ] OPTIONAL ).
      APPEND VALUE #( kotabnr  = ls_rail_route-kotabnr
                      kappl    = ls_rail_route-kappl
                      kschl    = ls_rail_route-kschl
                      vstel    = ls_rail_route-vstel
                      kunwe    = ls_rail_route-kunwe
                      vsbed    = ls_rail_route-vsbed
                      pstlz    = ls_rail_route-pstlz
*                      tdlnr    = ls_rail_route-tdlnr
                      bezei    = ls_rail_route-bezei
                      datab    = ls_rail_route-datab
                      datbi    = ls_rail_route-datbi
                      primary_route       = condense( val = ls_rail_route-routid4 )
*                      primary_route       = | { ls_rail_route-routid4 } |
                      primary_route_id    = ls_rail_route-routid
                      primary_tdlnr       = ls_rail_route-tdlnr
                      secondary_route     = condense( val = ls_rail_route_2-routid4 )
*                      secondary_route     = |{ ls_rail_route_2-routid4 }|
                      secondary_route_id  = ls_rail_route_2-routid
                      secondary_tdlnr     = ls_rail_route_2-tdlnr ) TO et_rail_route.
      CLEAR ls_rail_route_2.
    ENDLOOP.
  ENDMETHOD.
  METHOD get_rail_route_info.
    CLEAR es_route_info.


    LOOP AT gt_rail_route_911 INTO DATA(ls_route_info)
                                          WHERE kunwe = iv_kunnr AND
                                                vstel = iv_tplst AND
                                                pstlz = iv_pstlz AND
                                               ( datab <= iv_date AND
                                                 datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
                               prim_tdlnr    = ls_route_info-primary_tdlnr
                               prim_routid   = ls_route_info-primary_route_id
                               secondary_route = ls_route_info-secondary_route
                               sec_tdlnr       = ls_route_info-secondary_tdlnr
                               sec_routid      = ls_route_info-secondary_route_id ).
        RETURN.
      ENDIF.
    ENDLOOP.
    LOOP AT gt_rail_route_909 INTO ls_route_info
                                      WHERE kunwe = iv_kunnr AND
                                            vsbed = iv_vsbed AND
                                            pstlz = iv_pstlz AND
                                          ( datab <= iv_date AND
                                            datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
                               prim_tdlnr    = ls_route_info-primary_tdlnr
                               prim_routid   = ls_route_info-primary_route_id
                               secondary_route = ls_route_info-secondary_route
                               sec_tdlnr       = ls_route_info-secondary_tdlnr
                               sec_routid      = ls_route_info-secondary_route_id ).
        RETURN.
      ENDIF.
    ENDLOOP.
    LOOP AT gt_rail_route_902 INTO ls_route_info
                                  WHERE kunwe = iv_kunnr AND
                                        vstel = iv_tplst AND
                                        vsbed = iv_vsbed AND
                                      ( datab <= iv_date AND
                                        datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
                               prim_tdlnr    = ls_route_info-primary_tdlnr
                               prim_routid   = ls_route_info-primary_route_id
                               secondary_route = ls_route_info-secondary_route
                               sec_tdlnr       = ls_route_info-secondary_tdlnr
                               sec_routid      = ls_route_info-secondary_route_id ).
        RETURN.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_rail_route_907 INTO ls_route_info
                                 WHERE kunwe = iv_kunnr AND
                                       vstel = iv_tplst AND
                                     ( datab <= iv_date AND
                                       datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
                               prim_tdlnr    = ls_route_info-primary_tdlnr
                               prim_routid   = ls_route_info-primary_route_id
                               secondary_route = ls_route_info-secondary_route
                               sec_tdlnr       = ls_route_info-secondary_tdlnr
                               sec_routid      = ls_route_info-secondary_route_id ).
        RETURN.
      ENDIF.
    ENDLOOP.
    LOOP AT gt_rail_route_910 INTO ls_route_info
                             WHERE vstel = iv_tplst AND
                                 ( datab <= iv_date AND
                                   datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
                               prim_tdlnr    = ls_route_info-primary_tdlnr
                               prim_routid   = ls_route_info-primary_route_id
                               secondary_route = ls_route_info-secondary_route
                               sec_tdlnr       = ls_route_info-secondary_tdlnr
                               sec_routid      = ls_route_info-secondary_route_id ).
        RETURN.
      ENDIF.
    ENDLOOP.
    LOOP AT gt_rail_route_908 INTO ls_route_info
                         WHERE vsbed = iv_vsbed AND
                             ( datab <= iv_date AND
                               datbi >= iv_date ).
      IF ls_route_info IS NOT INITIAL.
        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
                               prim_tdlnr    = ls_route_info-primary_tdlnr
                               prim_routid   = ls_route_info-primary_route_id
                               secondary_route = ls_route_info-secondary_route
                               sec_tdlnr       = ls_route_info-secondary_tdlnr
                               sec_routid      = ls_route_info-secondary_route_id ).
        RETURN.
      ENDIF.
    ENDLOOP.


** Read the table one by one where the program finds an entry for the
** primary/secondary route inofrmation. If not found, then fill it as
** empty value
*    DATA(ls_route_info) = VALUE #( gt_rail_route_911[ kunwe = iv_kunnr
*                                                      vstel = iv_tplst
*                                                      pstlz = iv_pstlz
*                                                     ] OPTIONAL ).
*    IF ls_route_info IS INITIAL.
** Read 909 table.
*      ls_route_info = VALUE #( gt_rail_route_909[ kunwe = iv_kunnr
*                                                  vsbed = iv_vsbed
*                                                  pstlz = iv_pstlz
*                                                 ] OPTIONAL ).
*      IF ls_route_info IS INITIAL.
* Read 902 table.
*        ls_route_info = VALUE #( gt_rail_route_902[ kunwe = iv_kunnr
*                                                    vstel = iv_tplst
*                                                    vsbed = iv_vsbed
*                                                   ] OPTIONAL ).
*        IF ls_route_info IS INITIAL.
* Read 907 table.
*          ls_route_info = VALUE #( gt_rail_route_907[ kunwe = iv_kunnr
*                                                      vstel = iv_tplst
*                                                     ] OPTIONAL ).
*          IF ls_route_info IS INITIAL.
* Read 910 table.
*            ls_route_info = VALUE #( gt_rail_route_910[ vstel = iv_tplst
*            ] OPTIONAL ).
*            IF ls_route_info IS INITIAL.
* Read 908 table.
*              ls_route_info = VALUE #( gt_rail_route_908[ vsbed = iv_vsbed
*                                                        ] OPTIONAL ).
*  ENDIF.
*ENDIF.
*ENDIF.
*ENDIF.
*ENDIF.

** Fill exporting structure.
*    IF ls_route_info IS NOT INITIAL.
*      IF iv_date BETWEEN ls_route_info-datab AND
*                     ls_route_info-datbi.
*        es_route_info = VALUE #( primary_route = ls_route_info-primary_route
*                               prim_tdlnr    = ls_route_info-primary_tdlnr
*                               prim_routid   = ls_route_info-primary_route_id
*                               secondary_route = ls_route_info-secondary_route
*                               sec_tdlnr       = ls_route_info-secondary_tdlnr
*                               sec_routid      = ls_route_info-secondary_route_id ).
*      ENDIF.
*    ENDIF.
  ENDMETHOD.
  METHOD get_rail_rate_info.
    CLEAR es_rate_info.
* Read tables based on the Special processing indicator.
    CASE is_read_info-sdabw.
      WHEN 'RF11' OR 'RR11'.
        read_arrw_tables(
        EXPORTING
          is_route_info     = is_route_info
          is_read_info      = is_read_info
        IMPORTING
          ev_primary_rate   = DATA(lv_arrw_primary_rate)
          ev_secondary_rate = DATA(lv_arrw_secondary_rate) ).

        read_ztfs_tables(
        EXPORTING
          is_route_info     = is_route_info
          is_read_info      = is_read_info
        IMPORTING
          ev_primary_rate   = DATA(lv_ztfs_primary_rate)
          ev_secondary_rate = DATA(lv_ztfs_secondary_rate) ).

        read_ztfm_tables(
        EXPORTING
          is_route_info     = is_route_info
          is_read_info      = is_read_info
        IMPORTING
          ev_primary_rate   = DATA(lv_ztfm_primary_rate)
          ev_secondary_rate = DATA(lv_ztfm_secondary_rate) ).
* Export the calculated value.
        es_rate_info = VALUE #( primary_rate = lv_arrw_primary_rate +
                                             lv_ztfs_primary_rate +
                                             lv_ztfm_primary_rate
                              secondary_rate = lv_arrw_secondary_rate +
                                               lv_ztfs_secondary_rate +
                                               lv_ztfm_secondary_rate ).
      WHEN space.
        read_zrbw_tables(
        EXPORTING
          is_route_info     = is_route_info
          is_read_info      = is_read_info
        IMPORTING
          ev_primary_rate   = DATA(lv_arbw_primary_rate)
          ev_secondary_rate = DATA(lv_arbw_secondary_rate) ).

        read_ztfs_tables(
        EXPORTING
          is_route_info     = is_route_info
          is_read_info      = is_read_info
        IMPORTING
          ev_primary_rate   = lv_ztfs_primary_rate
          ev_secondary_rate = lv_ztfs_secondary_rate ).

        read_ztfm_tables(
        EXPORTING
          is_route_info     = is_route_info
          is_read_info      = is_read_info
        IMPORTING
          ev_primary_rate   = lv_ztfm_primary_rate
          ev_secondary_rate = lv_ztfm_secondary_rate ).
* Export the calculated value.
        es_rate_info = VALUE #( primary_rate = lv_arbw_primary_rate +
                                             lv_ztfs_primary_rate +
                                             lv_ztfm_primary_rate
                              secondary_rate = lv_arbw_secondary_rate +
                                               lv_ztfs_secondary_rate +
                                               lv_ztfm_secondary_rate ).
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.
  METHOD read_arrw_tables.
    CLEAR: ev_primary_rate,
    ev_secondary_rate.

* Primary
    LOOP AT gt_rail_rate_983 INTO DATA(ls_rail_rate_primary)
                                 WHERE kschl = is_read_info-shipment_type AND
                                       tdlnr = is_route_info-prim_tdlnr AND
                                       vsbed = is_read_info-shipping_condition AND
                                       knota = is_read_info-departure_point AND
                                       knotz = is_read_info-destination_point AND
                                     ( datab <= is_read_info-date AND
                                       datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Secondory
    LOOP AT gt_rail_rate_983 INTO DATA(ls_rail_rate_secondary)
                                 WHERE kschl = is_read_info-shipment_type AND
                                       tdlnr = is_route_info-sec_tdlnr AND
                                       vsbed = is_read_info-shipping_condition AND
                                       knota = is_read_info-departure_point AND
                                       knotz = is_read_info-destination_point AND
                                     ( datab <= is_read_info-date AND
                                       datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_981 INTO ls_rail_rate_primary
                                 WHERE kschl = is_read_info-shipment_type AND
                                       tdlnr = is_route_info-prim_tdlnr AND
                                       vsbed = is_read_info-shipping_condition AND
                                       tplst = is_read_info-trsp_plan_point AND
                                       knotz = is_read_info-destination_point AND
                                     ( datab <= is_read_info-date AND
                                       datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondory
    LOOP AT gt_rail_rate_981 INTO ls_rail_rate_secondary
                                 WHERE kschl = is_read_info-shipment_type AND
                                       tdlnr = is_route_info-prim_tdlnr AND
                                       vsbed = is_read_info-shipping_condition AND
                                       tplst = is_read_info-trsp_plan_point AND
                                       knotz = is_read_info-destination_point AND
                                     ( datab <= is_read_info-date AND
                                       datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
    ENDIF.

** Read ZRRW related table and get primary and secondary rate
*    DATA(ls_rail_rate_primary) = VALUE #( gt_rail_rate_983[ kschl = is_read_info-shipment_type
*                                                    tdlnr = is_route_info-prim_tdlnr
*                                                    vsbed = is_read_info-shipping_condition
*                                                    knota = is_read_info-departure_point
*                                                    knotz = is_read_info-destination_point
*                                                   ] OPTIONAL ).
*    DATA(ls_rail_rate_secondary) = VALUE #( gt_rail_rate_983[ kschl = is_read_info-shipment_type
*                                                    tdlnr = is_route_info-sec_tdlnr
*                                                    vsbed = is_read_info-shipping_condition
*                                                    knota = is_read_info-departure_point
*                                                    knotz = is_read_info-destination_point
*                                                   ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_981[ kschl = is_read_info-shipment_type
*                                                    tdlnr = is_route_info-prim_tdlnr
*                                                    vsbed = is_read_info-shipping_condition
*                                                    tplst = is_read_info-trsp_plan_point
*                                                    knotz = is_read_info-destination_point
*                                                   ] OPTIONAL ).
*      ls_rail_rate_secondary = VALUE #( gt_rail_rate_981[ kschl = is_read_info-shipment_type
*                                                    tdlnr = is_route_info-prim_tdlnr
*                                                    vsbed = is_read_info-shipping_condition
*                                                    tplst = is_read_info-trsp_plan_point
*                                                    knotz = is_read_info-destination_point
*                                                   ] OPTIONAL ).
*    ENDIF.
** Collect Primary/Secondary Rate.
*    ev_primary_rate = ls_rail_rate_primary-kbetr.
*    ev_secondary_rate = ls_rail_rate_secondary-kbetr.
  ENDMETHOD.
  METHOD read_ztfs_tables.
    CLEAR: ev_primary_rate,
    ev_secondary_rate.


* Read ZTFS related table and get primary and secondary rate
* Primary
    LOOP AT gt_rail_rate_900 INTO DATA(ls_rail_rate_primary)
                                     WHERE tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-primary_route AND
                                           tdlnr = is_route_info-prim_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_900 INTO DATA(ls_rail_rate_secondary)
                                     WHERE tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-secondary_route AND
                                           tdlnr = is_route_info-sec_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_933 INTO ls_rail_rate_primary
                             WHERE kschl = is_read_info-shipment_type AND
                                   tplst = is_read_info-trsp_plan_point AND
                                   route = is_route_info-primary_route AND
                                   kunnr = is_read_info-customer AND
                                 ( datab <= is_read_info-date AND
                                   datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_933 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-secondary_route AND
                                           kunnr = is_read_info-customer AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_971 INTO ls_rail_rate_primary
                             WHERE kschl = is_read_info-shipment_type AND
                                   tplst = is_read_info-trsp_plan_point AND
                                   route = is_route_info-primary_route AND
                                 ( datab <= is_read_info-date AND
                                   datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_971 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-secondary_route AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_943 INTO ls_rail_rate_primary
                             WHERE kschl = is_read_info-shipment_type AND
                                   route = is_route_info-primary_route AND
                                 ( datab <= is_read_info-date AND
                                   datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_943 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           route = is_route_info-primary_route AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_937 INTO ls_rail_rate_primary
                             WHERE tdlnr = is_route_info-prim_tdlnr AND
                                   tplst = is_read_info-trsp_plan_point AND
                                   land1z = is_read_info-country AND
                                   regioz = is_read_info-destination_region AND
                                   cstvnd_city = is_read_info-city AND
                                 ( datab <= is_read_info-date AND
                                   datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_937 INTO ls_rail_rate_secondary
                                     WHERE tdlnr = is_route_info-sec_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_906 INTO ls_rail_rate_primary
                             WHERE kschl = is_read_info-shipment_type AND
                                   tdlnr = is_route_info-prim_tdlnr AND
                                 ( datab <= is_read_info-date AND
                                   datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_906 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tdlnr = is_route_info-sec_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
    ENDIF.

**    Collect Primary/Secondary Rate.
*    ev_primary_rate   = ls_rail_rate_primary-kbetr.
*    ev_secondary_rate = ls_rail_rate_secondary-kbetr.

*    DATA(ls_rail_rate_primary) = VALUE #( gt_rail_rate_900[ tplst = is_read_info-trsp_plan_point
*                                                            route = is_route_info-primary_route
*                                                            tdlnr = is_route_info-prim_tdlnr
*                                                  ] OPTIONAL ).
*    DATA(ls_rail_rate_secondary) = VALUE #( gt_rail_rate_900[ tplst = is_read_info-trsp_plan_point
*                                                              route = is_route_info-secondary_route
*                                                              tdlnr = is_route_info-sec_tdlnr
*                                                  ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
** 933
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_933[ kschl = is_read_info-shipment_type
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        route = is_route_info-primary_route
*                                                        kunnr = is_read_info-customer
*                                                  ] OPTIONAL ).
*    ls_rail_rate_secondary = VALUE #( gt_rail_rate_933[ kschl = is_read_info-shipment_type
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        route = is_route_info-secondary_route
*                                                        kunnr = is_read_info-customer
*                                                ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
* 971
*    ls_rail_rate_primary = VALUE #( gt_rail_rate_971[ kschl = is_read_info-shipment_type
*                                                      tplst = is_read_info-trsp_plan_point
*                                                      route = is_route_info-primary_route
*                                                  ] OPTIONAL ).
*    ls_rail_rate_secondary = VALUE #( gt_rail_rate_971[ kschl = is_read_info-shipment_type
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        route = is_route_info-secondary_route
*                                                  ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*     ls_rail_rate_secondary IS INITIAL.
* 971
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_943[ kschl = is_read_info-shipment_type
*                                                        route = is_route_info-primary_route
*                                                      ] OPTIONAL ).
*    ls_rail_rate_secondary = VALUE #( gt_rail_rate_943[ kschl = is_read_info-shipment_type
*                                                        route = is_route_info-primary_route
*                                                    ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*       ls_rail_rate_secondary IS INITIAL.
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_937[ tdlnr = is_route_info-prim_tdlnr
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        land1z = is_read_info-country
*                                                        regioz = is_read_info-destination_region
*                                                        cstvnd_city = is_read_info-city
*                                                      ] OPTIONAL ).
*      ls_rail_rate_secondary = VALUE #( gt_rail_rate_937[ tdlnr = is_route_info-sec_tdlnr
*                                                          tplst = is_read_info-trsp_plan_point
*                                                          land1z = is_read_info-country
*                                                          regioz = is_read_info-destination_region
*                                                          cstvnd_city = is_read_info-city
*                                                      ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*       ls_rail_rate_secondary IS INITIAL.
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_906[ kschl = is_read_info-shipment_type
*                                                        tdlnr = is_route_info-prim_tdlnr
*                                                      ] OPTIONAL ).
*      ls_rail_rate_secondary = VALUE #( gt_rail_rate_906[ kschl = is_read_info-shipment_type
*                                                          tdlnr = is_route_info-sec_tdlnr
*                                                      ] OPTIONAL ).
*  ENDIF.
*ENDIF.
*ENDIF.
*ENDIF.
*ENDIF.
**    Collect Primary/Secondary Rate.
*ev_primary_rate = ls_rail_rate_primary-kbetr.
*ev_secondary_rate = ls_rail_rate_secondary-kbetr.
  ENDMETHOD.
  METHOD read_ztfm_tables.
    CLEAR: ev_primary_rate,
    ev_secondary_rate.

* Primary
    LOOP AT gt_rail_rate_900 INTO DATA(ls_rail_rate_primary)
                                     WHERE tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-primary_route AND
                                           tdlnr = is_route_info-prim_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_900 INTO DATA(ls_rail_rate_secondary)
                                     WHERE tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-secondary_route AND
                                           tdlnr = is_route_info-sec_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_919 INTO ls_rail_rate_primary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-primary_route AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_919 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-primary_route AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_943 INTO ls_rail_rate_primary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           route = is_route_info-primary_route AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_943 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           route = is_route_info-secondary_route AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_937 INTO ls_rail_rate_primary
                                     WHERE tdlnr = is_route_info-prim_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_937 INTO ls_rail_rate_secondary
                                     WHERE tdlnr = is_route_info-sec_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_906 INTO ls_rail_rate_primary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tdlnr = is_route_info-prim_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_906 INTO ls_rail_rate_secondary
                                     WHERE kschl = is_read_info-shipment_type AND
                                           tdlnr = is_route_info-sec_tdlnr AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
    ENDIF.

**    Collect Primary/Secondary Rate.
*    ev_primary_rate = ls_rail_rate_primary-kbetr.
*    ev_secondary_rate = ls_rail_rate_secondary-kbetr.

** Read ZTFM related table and get primary and secondary rate
*    DATA(ls_rail_rate_primary) = VALUE #( gt_rail_rate_900[ tplst = is_read_info-trsp_plan_point
*                                                            route = is_route_info-primary_route
*                                                            tdlnr = is_route_info-prim_tdlnr
*                                    ] OPTIONAL ).
*    DATA(ls_rail_rate_secondary) = VALUE #( gt_rail_rate_900[ tplst = is_read_info-trsp_plan_point
*                                                              route = is_route_info-secondary_route
*                                                              tdlnr = is_route_info-sec_tdlnr
*                                    ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
** 919
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_919[ kschl = is_read_info-shipment_type
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        route = is_route_info-primary_route
*                                            ] OPTIONAL ).
*      ls_rail_rate_secondary = VALUE #( gt_rail_rate_919[ kschl = is_read_info-shipment_type
*                                                          tplst = is_read_info-trsp_plan_point
*                                                          route = is_route_info-primary_route
*                                            ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
* 943
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_943[ kschl = is_read_info-shipment_type
*                                                        route = is_route_info-primary_route
*                                                    ] OPTIONAL ).
*      ls_rail_rate_secondary = VALUE #( gt_rail_rate_943[ kschl = is_read_info-shipment_type
*                                                          route = is_route_info-secondary_route
*                                                    ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
* 937
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_937[ tdlnr = is_route_info-prim_tdlnr
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        land1z = is_read_info-country
*                                                        regioz = is_read_info-destination_region
*                                                        cstvnd_city = is_read_info-city
*                                                        ] OPTIONAL ).
*      ls_rail_rate_secondary = VALUE #( gt_rail_rate_937[ tdlnr = is_route_info-sec_tdlnr
*                                                          tplst = is_read_info-trsp_plan_point
*                                                          land1z = is_read_info-country
*                                                          regioz = is_read_info-destination_region
*                                                          cstvnd_city = is_read_info-city
*                                                        ] OPTIONAL ).
*      IF ls_rail_rate_primary IS INITIAL AND
*         ls_rail_rate_secondary IS INITIAL.
*        ls_rail_rate_primary = VALUE #( gt_rail_rate_906[ kschl = is_read_info-shipment_type
*                                                          tdlnr = is_route_info-prim_tdlnr
*                                                          ] OPTIONAL ).
*        ls_rail_rate_secondary = VALUE #( gt_rail_rate_906[ kschl = is_read_info-shipment_type
*                                                            tdlnr = is_route_info-sec_tdlnr
*                                                          ] OPTIONAL ).
*  ENDIF.
*ENDIF.
*ENDIF.
*ENDIF.

**    Collect Primary/Secondary Rate.
*ev_primary_rate = ls_rail_rate_primary-kbetr.
*ev_secondary_rate = ls_rail_rate_secondary-kbetr.
  ENDMETHOD.
  METHOD read_zrbw_tables.
    CLEAR: ev_primary_rate,
    ev_secondary_rate.

* Primary
    LOOP AT gt_rail_rate_958 INTO DATA(ls_rail_rate_primary)
                                     WHERE tdlnr = is_route_info-prim_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-primary_route AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                           vsbed = is_read_info-shipping_condition AND
                                           zstcc = is_read_info-stcc AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_958 INTO DATA(ls_rail_rate_secondary)
                                     WHERE tdlnr = is_route_info-sec_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-secondary_route AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                           vsbed = is_read_info-shipping_condition AND
                                           zstcc = is_read_info-stcc AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_946 INTO ls_rail_rate_primary
                                     WHERE tdlnr = is_route_info-prim_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-primary_route AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                           vsbed = is_read_info-shipping_condition AND
                                           zstcc = is_read_info-stcc AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_946 INTO ls_rail_rate_secondary
                                     WHERE tdlnr = is_route_info-sec_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           route = is_route_info-secondary_route AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                           vsbed = is_read_info-shipping_condition AND
                                           zstcc = is_read_info-stcc AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
      RETURN.
    ENDIF.

* Primary
    LOOP AT gt_rail_rate_936 INTO ls_rail_rate_primary
                                     WHERE tdlnr = is_route_info-prim_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                           vsbed = is_read_info-shipping_condition AND
                                           zstcc = is_read_info-stcc AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_primary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.

* Secondary.
    LOOP AT gt_rail_rate_936 INTO ls_rail_rate_secondary
                                     WHERE tdlnr = is_route_info-sec_tdlnr AND
                                           tplst = is_read_info-trsp_plan_point AND
                                           land1z = is_read_info-country AND
                                           regioz = is_read_info-destination_region AND
                                           cstvnd_city = is_read_info-city AND
                                           vsbed = is_read_info-shipping_condition AND
                                           zstcc = is_read_info-stcc AND
                                         ( datab <= is_read_info-date AND
                                           datbi >= is_read_info-date ).
      IF ls_rail_rate_secondary IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
* Collect Primary/Secondary Rate.
    IF ls_rail_rate_primary IS NOT INITIAL OR
    ls_rail_rate_secondary IS NOT INITIAL.
      ev_primary_rate = ls_rail_rate_primary-kbetr.
      ev_secondary_rate = ls_rail_rate_secondary-kbetr.
    ENDIF.

*    Collect Primary/Secondary Rate.
*    ev_primary_rate = ls_rail_rate_primary-kbetr.
*    ev_secondary_rate = ls_rail_rate_secondary-kbetr.


* Read ZRBW related table and get primary and secondary rate
*    DATA(ls_rail_rate_primary) = VALUE #( gt_rail_rate_958[ tdlnr = is_route_info-prim_tdlnr
*                                                            tplst = is_read_info-trsp_plan_point
*                                                            route = is_route_info-primary_route
*                                                            land1z = is_read_info-country
*                                                            regioz = is_read_info-destination_region
*                                                            cstvnd_city = is_read_info-city
*                                                            vsbed = is_read_info-shipping_condition
*                                                            zstcc = is_read_info-stcc
*                            ] OPTIONAL ).
*    DATA(ls_rail_rate_secondary) = VALUE #( gt_rail_rate_958[ tdlnr = is_route_info-sec_tdlnr
*                                                              tplst = is_read_info-trsp_plan_point
*                                                              route = is_route_info-secondary_route
*                                                              land1z = is_read_info-country
*                                                              regioz = is_read_info-destination_region
*                                                              cstvnd_city = is_read_info-city
*                                                              vsbed = is_read_info-shipping_condition
*                                                              zstcc = is_read_info-stcc
*                            ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
* 933
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_946[ tdlnr = is_route_info-prim_tdlnr
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        route = is_route_info-primary_route
*                                                        land1z = is_read_info-country
*                                                        regioz = is_read_info-destination_region
*                                                        cstvnd_city = is_read_info-city
*                                                        vsbed = is_read_info-shipping_condition
*                                                        zstcc = is_read_info-stcc
*                                          ] OPTIONAL ).
*    ls_rail_rate_secondary = VALUE #( gt_rail_rate_946[ tdlnr = is_route_info-sec_tdlnr
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        route = is_route_info-secondary_route
*                                                        land1z = is_read_info-country
*                                                        regioz = is_read_info-destination_region
*                                                        cstvnd_city = is_read_info-city
*                                                        vsbed = is_read_info-shipping_condition
*                                                        zstcc = is_read_info-stcc
*                                        ] OPTIONAL ).
*    IF ls_rail_rate_primary IS INITIAL AND
*    ls_rail_rate_secondary IS INITIAL.
* 971
*      ls_rail_rate_primary = VALUE #( gt_rail_rate_936[ tdlnr = is_route_info-prim_tdlnr
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        land1z = is_read_info-country
*                                                        regioz = is_read_info-destination_region
*                                                        cstvnd_city = is_read_info-city
*                                                        vsbed = is_read_info-shipping_condition
*                                                        zstcc = is_read_info-stcc
*                                                ] OPTIONAL ).
*    ls_rail_rate_secondary = VALUE #( gt_rail_rate_936[ tdlnr = is_route_info-sec_tdlnr
*                                                        tplst = is_read_info-trsp_plan_point
*                                                        land1z = is_read_info-country
*                                                        regioz = is_read_info-destination_region
*                                                        cstvnd_city = is_read_info-city
*                                                        vsbed = is_read_info-shipping_condition
*                                                        zstcc = is_read_info-stcc
*                                              ] OPTIONAL ).
*  ENDIF.
*ENDIF.

**    Collect Primary/Secondary Rate.
*ev_primary_rate = ls_rail_rate_primary-kbetr.
*ev_secondary_rate = ls_rail_rate_secondary-kbetr.
  ENDMETHOD.
  METHOD prepare_alv_data.

* Loop at main table VTT.
    LOOP AT gt_vttk INTO DATA(ls_vttk).
* Read table for Mill text.
      DATA(ls_mill_text) = VALUE #( gt_ttdst[ tplst = ls_vttk-tplst ] OPTIONAL ).

* Read Table for container size text
      DATA(ls_ship_text) = VALUE #( gt_ship_text[ vsbed = ls_vttk-vsbed ] OPTIONAL ).

* VTTS would hold more then 1 stage per shipment. In that case, consider the
* Distance, Destination Postal code and Departure postal code from stage 1 &
* Departure point from stage 2 & destination point from last stage from the
* shipment.
      LOOP AT gt_vtts INTO DATA(ls_vtts) WHERE tknum = ls_vttk-tknum.
        DATA(ls_vtts_temp) = ls_vtts.
* Get distance, Departure/Destination Postal Code from stage 1.
*        IF ls_vtts-tsnum = 1.
*          DATA(lv_distance) = ls_vtts-distz.
*          DATA(lv_dep_postal_code) = ls_vtts-abpstlz.
*          DATA(lv_dest_postal_code) = ls_vtts-edpstlz.
*        ENDIF.
        IF ls_vtts-tsnum = 2.
*Departure Point from Stage 2.
          DATA(lv_dep_point) = ls_vtts-knota.
        ENDIF.
* Get Destination Point from Last stage.
        AT END OF tknum.
          DATA(lv_dest_point) = ls_vtts_temp-knotz.
        ENDAT.
      ENDLOOP.

* The program has to consider any one delivery  for a shipment as all the
* delivery would have same shipment.
      DATA(ls_vttp) = VALUE #( gt_vttp[ tknum = ls_vttk-tknum ] OPTIONAL ).

* With waterver Delivery number the program read for shipment, get PO for that
* delivery.
      DATA(ls_lips) = VALUE #( gt_lips[ vbeln = ls_vttp-vbeln ] OPTIONAL ).

* With waterver PO number the program read for Delivery, get Ship-To PArty for that
* PO.
      DATA(ls_likp) = VALUE #( gt_likp[ vbeln = ls_vttp-vbeln ] OPTIONAL ).

* Get ship to Party address
      DATA(ls_kna1) = VALUE #( gt_kna1[ kunnr = ls_likp-kunnr ] OPTIONAL ).

* Get the storage loactaion based on the PO. Based on the Storage Loacation,
* the program would decide to pick the address
      DATA(ls_ekpo) = VALUE #( gt_ekpo[ ebeln = ls_lips-vgbel ] OPTIONAL ).

* Decide the address to be from Ship-To party or from Port address.
      IF ls_ekpo-lgort+0(2) = 'HU' AND
      ls_ekpo-werks+0(2) = '92'.
* Read table for Determination of Address from Plant and Storage Location
        DATA(ls_twlad) = VALUE #( gt_twlad[ werks = ls_ekpo-werks
                                        lgort = ls_ekpo-lgort ] OPTIONAL ).
* Read table for Addresses (Business Address Services).
        DATA(ls_adrc) = VALUE #( gt_adrc[ addrnumber = ls_twlad-adrnr ] OPTIONAL ).

* Read table for Plant description.
        DATA(lv_customer_info)     = ls_adrc-name1.
        DATA(lv_city_state)        = |{ ls_adrc-city1 },{ ls_adrc-region }|.
        DATA(lv_storage_location)  = ls_ekpo-lgort.
        DATA(lv_postal_code)       = ls_adrc-post_code1.
        DATA(lv_region)            = ls_adrc-region.
        DATA(lv_city)              = ls_adrc-city1.
        DATA(lv_country)           = ls_adrc-country.
      ELSE.
        lv_customer_info     = ls_kna1-name1.
        lv_city_state        = |{ ls_kna1-ort01 },{ ls_kna1-regio }|.
        lv_postal_code       = ls_kna1-pstlz.
        lv_region            = ls_kna1-regio.
        lv_city              = ls_kna1-ort01.
        lv_country           = ls_kna1-land1.
      ENDIF.


* Get Rail Route.
      get_rail_route_info(
      EXPORTING
      iv_tplst      = ls_vttk-tplst
      iv_kunnr      = ls_kna1-kunnr
      iv_pstlz      = lv_postal_code
      iv_vsbed      = ls_vttk-vsbed
      iv_date       = ls_vttk-dptbg
      IMPORTING
      es_route_info = DATA(ls_route_info) ).

* No need to display the shipment if it does not have secondary info.
      IF ls_route_info-sec_routid IS INITIAL AND
         ls_route_info-sec_tdlnr  IS INITIAL AND
         ls_route_info-secondary_route IS INITIAL.
        CONTINUE.
      ENDIF.

* Read GT_LFA1 Table.
      DATA(ls_lfa1_prim) = VALUE #( gt_lfa1[ lifnr = ls_route_info-prim_tdlnr  ] OPTIONAL ).
      DATA(ls_lfa1_sec)  = VALUE #( gt_lfa1[ lifnr = ls_route_info-sec_tdlnr  ] OPTIONAL ).
* Get Rail Rate
      get_rail_rate_info(
      EXPORTING
      is_route_info = ls_route_info
      is_read_info  = VALUE #( shipment_type  = ls_vttk-shtyp
                       service_agent  = ls_vttk-tdlnr
                       shipping_condition = ls_vttk-vsbed
                       departure_point    = lv_dep_point
                       destination_point  = lv_dest_point
                       destination_region = lv_region
                       customer           = ls_likp-kunnr
                       city               = lv_city
                       sdabw              = ls_vttk-sdabw
                       stcc               = ls_lips-mfrgr
                       trsp_plan_point    = ls_vttk-tplst
                       country            = lv_country
                       date               = ls_vttk-dptbg )
      IMPORTING
      es_rate_info  = DATA(ls_rate_info) ).

* Primary - Secondary Rate
      DATA(lv_primary_secondary) = |{ ls_rate_info-primary_rate - ls_rate_info-secondary_rate }|.

      DATA(lv_scac) = ls_lfa1_prim-scacd.
      IF ls_lfa1_sec IS NOT INITIAL.
        lv_scac = ls_lfa1_sec-scacd.
      ENDIF.
* Adverse Loading fee
      LOOP AT gt_load_fee INTO DATA(ls_load_fee) WHERE carrier = lv_scac AND
                                            (  valid_from <= ls_vttk-dptbg AND
                                               valid_to >= ls_vttk-dptbg ).
        DATA(lv_load_fee) = ls_load_fee-fee.
        DATA(lv_primary_penalty) = ls_rate_info-primary_rate + lv_load_fee.
        EXIT.
      ENDLOOP.

* Low cost option.
      IF ls_rate_info-primary_rate > lv_primary_penalty.
        DATA(lv_change_route) = 'Change Route'.
      ELSE.
        lv_change_route = 'Adverse Load'.
      ENDIF.

* Alternate Route
      DATA(lv_alternate_route) = lv_primary_penalty - ls_rate_info-primary_rate.

* Load all the required data into ALV table
      APPEND VALUE #( mill              = |{ ls_vttk-tplst } - { ls_mill_text-bezei }|
          shipment          = ls_vttk-tknum
          from_scac         = ls_lfa1_prim-scacd "ls_lfa1-name1
          to_scac           = ls_lfa1_sec-scacd "lv_to_scac
          storage_location  = lv_storage_location"ls_ekpo-lgort
          ship_to           = ls_likp-kunnr
          customer_info     = lv_customer_info
          city_state        = lv_city_state" |{ ls_kna1-ort01 },{ ls_kna1-regio }|
          planned_ship_date = ls_vttk-dptbg
          car_size          = ls_ship_text-vtext "ls_vttk-vsbed
          primary_carrier   = ls_lfa1_prim-scacd "lv_from_scac
          primary_rate      = ls_rate_info-primary_rate
          secondary_carrier = ls_lfa1_sec-scacd "lv_to_scac
          secondary_rate    = ls_rate_info-secondary_rate
          primary_secondary = lv_primary_secondary
          adverse_load_fee  = lv_load_fee
          low_cost_option   = lv_change_route
          primary_penalty   = lv_primary_penalty
          primary_rate_est_cost = ls_rate_info-primary_rate
          alternate_route       = lv_alternate_route ) TO gt_alv_data.

      CLEAR: ls_mill_text,
      ls_vtts,
      lv_dep_point,
      lv_dest_point,
      lv_storage_location,
      ls_vttp,
      ls_lips,
      ls_likp,
      ls_kna1,
      ls_ekpo,
      ls_twlad,
      ls_adrc,
      lv_customer_info,
      lv_city_state,
      lv_customer_info,
      lv_city_state,
      ls_lfa1_prim,
      ls_lfa1_sec,
      lv_primary_secondary,
      lv_load_fee,
      lv_primary_penalty,
      lv_change_route,
      lv_alternate_route.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

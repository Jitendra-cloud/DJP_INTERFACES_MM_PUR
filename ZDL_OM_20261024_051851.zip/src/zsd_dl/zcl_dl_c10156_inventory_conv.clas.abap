CLASS zcl_dl_c10156_inventory_conv DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_s_input,
        batch           TYPE boolean,
        goods           TYPE boolean,
        goods_rev       TYPE boolean,
        hu              TYPE boolean,
        product_type    TYPE zzgroupset,
        posting_date    TYPE budat,
        check_inventory TYPE boolean,
        local_drive     TYPE boolean,
        app_server      TYPE boolean,
        local_file_path TYPE string,
        app_file_path   TYPE string,
        test_mode       TYPE boolean,
        update_mode     TYPE boolean,
        except_proc     TYPE boolean,   "CD2000007614
        forground       TYPE boolean,
        background      TYPE boolean,
        gr_562          TYPE boolean,
        gr_bapi         TYPE boolean,
        gr_rev_check    TYPE boolean,
        trans_file      TYPE string,
        error_file      TYPE string,
        success_file    TYPE string,
      END OF ty_s_input .

    CLASS-DATA mo_translation_data TYPE REF TO data .
    CLASS-DATA mv_message TYPE string .
    CLASS-DATA mo_excel_data TYPE REF TO data .

    METHODS constructor
      IMPORTING
        !is_input TYPE ty_s_input OPTIONAL .
    METHODS excel_create_template
      IMPORTING
        !iv_path TYPE localfile
        !iv_prod TYPE zzgroupset .
    METHODS validate_input_data .
    METHODS build_translation_file .
    METHODS upload_build_dyn_table .
    METHODS create_revers_process .
    CLASS-METHODS get_fields_in_order
      IMPORTING
        !iv_group           TYPE zzgroup
        !iv_groupset        TYPE zzgroupset
      EXPORTING
        !et_fields_in_order TYPE zz_tt_zzxrefdetail .
    METHODS write_files_in_app_server .
protected section.
private section.

  data MO_INVNETORY_CONVERSIOIN type ref to LCL_INVENTORY_CONVERSION .
ENDCLASS.



CLASS ZCL_DL_C10156_INVENTORY_CONV IMPLEMENTATION.


  METHOD build_translation_file.
    mo_invnetory_conversioin->translation_file_data( ).
    mo_translation_data = lcl_inventory_conversion=>go_translation_data.
  ENDMETHOD.


  METHOD constructor.
* Pass the screen fields to the local class implementaion
    lcl_inventory_conversion=>gs_screen_input = is_input.

    mo_invnetory_conversioin = COND #(
           WHEN is_input-batch = abap_true
              THEN NEW lcl_inventory_conversion_batch( )
           WHEN is_input-goods = abap_true
              THEN NEW lcl_inventory_conversion_goods( )
           WHEN is_input-goods_rev = abap_true
              THEN NEW lcl_inventory_conversion_gr( )
           WHEN is_input-hu = abap_true
              THEN NEW lcl_inventory_conversion_hu( ) ).
  ENDMETHOD.


  METHOD create_revers_process.
    mo_invnetory_conversioin->create_revers_process( ).
  ENDMETHOD.


  METHOD excel_create_template.

    TYPES: BEGIN OF ty_s_fieldnames,
             fields TYPE char50,
           END OF ty_s_fieldnames,

           BEGIN OF ty_s_rollname,
             rollname TYPE rollname,
           END OF ty_s_rollname,

           ty_t_filednames TYPE STANDARD TABLE OF ty_s_fieldnames WITH EMPTY KEY,
           ty_t_rollname   TYPE STANDARD TABLE OF ty_s_rollname WITH EMPTY KEY.

    DATA: lt_excel_data TYPE REF TO data,
          lt_fieldnames TYPE ty_t_filednames.

* Local table/strucuture/Variable declaration.
    DATA: lt_excel_components TYPE  cl_abap_structdescr=>component_table,
          ls_component        TYPE  cl_abap_structdescr=>component.

* Read field names and data element from the table ZZXREFDETAIL.
* For those fields which does not have maintained data element, get the data type CABN table.
    get_fields_in_order(
      EXPORTING
        iv_group           = 'DELIVER'
        iv_groupset        = iv_prod
      IMPORTING
        et_fields_in_order = DATA(lt_fields_in_order) ).

* Validate if data element or ZZVALUE1 is maintained.
    LOOP AT lt_fields_in_order INTO DATA(ls_fields_maitain).
**********************************************************************
* Build dynamic table inorder to pass it to excel download
      ls_component-name  = |{ 'column_' }{ sy-tabix }|.
      ls_component-type = CAST #( cl_abap_datadescr=>describe_by_name( '/ASU/CHAR72' ) ).
      APPEND ls_component TO lt_excel_components.
      CLEAR ls_component.
**********************************************************************
      IF ls_fields_maitain-zzvalue1 IS INITIAL AND
         ls_fields_maitain-zzvalue5 IS INITIAL.
        "Maintain ZZVALUE1 or ZZVALUE5 in the table ZZXREFDETAIL
        MESSAGE e003(zdl_c10156) WITH ls_fields_maitain-zzkey2.
      ENDIF.
    ENDLOOP.

    " Create table
    TRY.
        DATA(lo_structdescr) = cl_abap_structdescr=>create( lt_excel_components ).
        DATA(lo_tabledescr)  = cl_abap_tabledescr=>create( lo_structdescr ).
      CATCH cx_sy_table_creation INTO DATA(lo_msg).
        DATA(lv_text) = lo_msg->get_text( ).
        MESSAGE e000(zdl_c10156) WITH lv_text.
    ENDTRY.

* Internal table instance
    FIELD-SYMBOLS <lt_table> TYPE STANDARD TABLE.
    CREATE DATA lt_excel_data TYPE HANDLE lo_tabledescr.
    ASSIGN lt_excel_data->* TO <lt_table>.

* Inorder to avoid select inside the loop, separate the entries in 2 different tables
* and read them inside the loop.
* 1. Field with data element
* 2. Field with characteristics
    DATA(lt_data_element) = lt_fields_in_order.
    DELETE lt_data_element WHERE zzvalue5 IS INITIAL.

    DATA(lt_char) = lt_fields_in_order.
    DELETE lt_char WHERE zzvalue5 IS NOT INITIAL.

    DATA(lt_rollname) = VALUE ty_t_rollname( FOR ls_data_element IN lt_data_element
                                          ( rollname = ls_data_element-zzvalue5 ) ).
* Select all data element description.
    IF lt_rollname IS NOT INITIAL.
      SELECT rollname,
             ddtext
        FROM dd04t
        INTO TABLE @DATA(lt_de_description)
        FOR ALL ENTRIES IN @lt_rollname
        WHERE rollname = @lt_rollname-rollname AND
              ddlanguage = @sy-langu.
      IF sy-subrc <> 0.
        CLEAR lt_de_description.
      ENDIF.
    ENDIF.

* Get characteristics field description.
    IF lt_char IS NOT INITIAL.
      SELECT atinn,
             adzhl,
             atnam
        FROM cabn
        INTO TABLE @DATA(lt_cban)
        FOR ALL ENTRIES IN @lt_char
        WHERE atnam = @lt_char-zzkey2.
      IF sy-subrc = 0.
        SELECT atinn,
               adzhl,
               atbez
          FROM cabnt
          INTO TABLE @DATA(lt_char_description)
          FOR ALL ENTRIES IN @lt_cban
          WHERE atinn = @lt_cban-atinn AND
                spras = @sy-langu       AND
                adzhl = @lt_cban-adzhl.
        IF sy-subrc <> 0.
          CLEAR lt_char_description.
        ENDIF.
      ENDIF.
    ENDIF.

* Sorting to place the filed in order in accordance with the maintained table entries
    APPEND INITIAL LINE TO <lt_table>.

** Get the required field names for excel template.
*    DATA(lt_fieldnames) = VALUE ty_t_filednames( FOR ls_fields_dateail IN lt_fields_in_order
*                                             FOR ls_de_description IN lt_de_description
*                                             WHERE ( rollname = ls_fields_dateail-zzvalue5 )
*                                            ( fields = ls_de_description-ddtext ) ).
*    LOOP AT lt_char INTO DATA(ls_char).
** Read CABN table to get the characterisitcs ID
*      DATA(ls_cabn) = VALUE #( lt_cban[ atnam = ls_char-zzkey2 ] OPTIONAL ).
*      IF ls_cabn IS NOT INITIAL.
** Read characterisitcs description table.
*        DATA(ls_char_description) = VALUE #( lt_char_description[ atinn = ls_cabn-atinn
*                                                                  adzhl = ls_cabn-adzhl ] OPTIONAL ).
*        APPEND VALUE #( fields = ls_char_description-atbez ) TO lt_fieldnames.
*      ENDIF.
*    ENDLOOP.

** Get the required field names for upload template.
    LOOP AT lt_fields_in_order INTO DATA(ls_fields_in_order).
* Read table with data element available.
      DATA(ls_de_description) = VALUE #( lt_de_description[
                                        rollname = CONV rollname( ls_fields_in_order-zzvalue5 ) ]
                                                 OPTIONAL ).
      IF ls_de_description IS NOT INITIAL.
        APPEND VALUE #( fields = ls_de_description-ddtext ) TO lt_fieldnames.
      ELSE.
* Read CABN table to get the characterisitcs ID
        DATA(ls_cabn) = VALUE #( lt_cban[ atnam = ls_fields_in_order-zzkey2 ] OPTIONAL ).
        IF ls_cabn IS NOT INITIAL.
* Read characterisitcs description table.
          DATA(ls_char_description) = VALUE #( lt_char_description[ atinn = ls_cabn-atinn
                                                                    adzhl = ls_cabn-adzhl ] OPTIONAL ).
          IF ls_char_description IS NOT INITIAL.
            APPEND VALUE #( fields = ls_char_description-atbez ) TO lt_fieldnames.
          ENDIF.
        ELSE.
          APPEND VALUE #( fields = ls_fields_in_order-zzkey2 ) TO lt_fieldnames.
        ENDIF.
      ENDIF.
      CLEAR: ls_de_description,
             ls_cabn,
             ls_char_description.
    ENDLOOP.

    CALL FUNCTION 'MS_EXCEL_OLE_STANDARD_DAT'
      EXPORTING
        file_name                 = iv_path
        create_pivot              = 0
        data_sheet_name           = space
        pivot_sheet_name          = space
        password                  = space
        password_option           = 0
      TABLES
        data_tab                  = <lt_table>
        fieldnames                = lt_fieldnames
      EXCEPTIONS
        file_not_exist            = 1
        filename_expected         = 2
        communication_error       = 3
        ole_object_method_error   = 4
        ole_object_property_error = 5
        invalid_pivot_fields      = 6
        download_problem          = 7
        OTHERS                    = 8.
    IF sy-subrc <> 0.
      "Failed to create template
      MESSAGE e004(zdl_c10156).
    ENDIF.
  ENDMETHOD.


  METHOD get_fields_in_order.
    TYPES: BEGIN OF ty_s_fields_in_order.
             INCLUDE TYPE zzxrefdetail.
             TYPES : numc TYPE /bcv/sin_numc3,
           END OF ty_s_fields_in_order.

    TYPES: ty_t_fields_in_order TYPE STANDARD TABLE OF ty_s_fields_in_order WITH EMPTY KEY.

    CLEAR: et_fields_in_order.

    SELECT mandt,
           zzgroup,
           zzgroupset,
           zzkey1,
           zzkey2,
           zzkey3,
           zzeffect_until,
           zzvalue1,
           zzvalue2,
           zzvalue3,
           zzvalue4,
           zzvalue5,
           zzcreateby,
           zzcreatedate,
           zzupdateby,
           zzupdatedate
      FROM zzxrefdetail
      INTO TABLE @DATA(lt_fields)
      WHERE zzgroup    = @iv_group AND
            zzgroupset = @iv_groupset.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    DATA(lt_fields_in_order) = CORRESPONDING ty_t_fields_in_order( lt_fields
                                     MAPPING numc = zzkey1 ).

    SORT lt_fields_in_order BY numc ASCENDING.

    et_fields_in_order = CORRESPONDING #( lt_fields_in_order ).
  ENDMETHOD.


  METHOD upload_build_dyn_table.
    mo_invnetory_conversioin->upload_build_dyn_table_data( ).
    mv_message = lcl_inventory_conversion=>gv_message.
  ENDMETHOD.


  method VALIDATE_INPUT_DATA.
    mo_invnetory_conversioin->validate_input_file_data( ).
    mo_excel_data = lcl_inventory_conversion=>go_alv_output_ref.
  endmethod.


  METHOD write_files_in_app_server.
    mo_invnetory_conversioin->write_files_in_app_server( ).
  ENDMETHOD.
ENDCLASS.

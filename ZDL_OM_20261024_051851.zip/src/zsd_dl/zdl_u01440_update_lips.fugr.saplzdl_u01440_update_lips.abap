*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_U01440_UPDATE_LIPSTOP.        " Global Data
  INCLUDE LZDL_U01440_UPDATE_LIPSUXX.        " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_U01440_UPDATE_LIPSF...        " Subprograms
* INCLUDE LZDL_U01440_UPDATE_LIPSO...        " PBO-Modules
* INCLUDE LZDL_U01440_UPDATE_LIPSI...        " PAI-Modules

INCLUDE LZDL_U01440_UPDATE_LIPSF01.

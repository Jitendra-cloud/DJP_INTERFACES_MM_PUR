class ZCL_DL_E3637_DCGR_CHECKS definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ty_s_inb_dlvry,
             vbeln           TYPE vbeln_vl,
             vbelv           TYPE vbelv,
             posnv           TYPE posnv,
             zz_complete     TYPE zdl_complete,
             posnr           TYPE posnr_vl,
             matnr           TYPE matnr,
             werks           TYPE werks_d,
             lgort           TYPE lgort_d,
             charg           TYPE charg_d,
             lfimg           TYPE lfimg,
             vgbel           TYPE vgbel,
             vgpos           TYPE vgpos,
             ekorg           TYPE ekorg,
             vkorg           TYPE vkorg,
             lgmng           TYPE lgmng,
             brgew           TYPE brgew,
             ntgew           TYPE ntgew,
             gewei           TYPE gewei,
             meins           TYPE meins,
             lips_vrkme      TYPE vrkme,
             vbap_vrkme      TYPE vrkme,
             umvkz           TYPE umvkz,
             umvkn           TYPE umvkn,
             zz_exit_pass_no TYPE zz_exit_pass_no,
             zz_scac         TYPE zdl_scac,
             zz_signi        TYPE zdl_signi,
             zz_bale_cnt     TYPE zdl_bales,
             zz_bol          TYPE zz_dl_bol,
             zz_scale        TYPE zdl_scale_ticket,
             zz_ship_date    TYPE zdl_ship_date,
             zz_gross_wt     TYPE zdl_gross_wt,
             zz_net_wt       TYPE zdl_netwt,
             zz_tare_wt      TYPE zdl_tare_wt,
           END OF ty_s_inb_dlvry .
  types:
    ty_t_inb_dlvry TYPE STANDARD TABLE OF ty_s_inb_dlvry .
  types:
    BEGIN OF ts_vtts,
        tknum TYPE tknum,
        tsnum TYPE tsnum,
      END OF ts_vtts .
  types:
    tt_vtts TYPE STANDARD TABLE OF ts_vtts .
  types:
    BEGIN OF ts_tvftk,
        fkart TYPE fkart_t,
        fkpty TYPE fkpty,
      END OF ts_tvftk .
  types:
    tt_tvftk TYPE STANDARD TABLE OF ts_tvftk .
  types:
    BEGIN OF ts_tvtk,
        shtyp TYPE shtyp,
        fkart TYPE fkart_t,
      END OF ts_tvtk .
  types:
    tt_tvtk TYPE STANDARD TABLE OF ts_tvtk .
  types:
    BEGIN OF ts_likp,
        vbeln TYPE vbeln_vl,
        lifex TYPE lifex,
        bolnr TYPE bolnr,
      END OF ts_likp .
  types:
    tt_likp TYPE STANDARD TABLE OF ts_likp .
  types:
    BEGIN OF ts_vttk,
        tknum TYPE tknum,
        shtyp TYPE shtyp,
        frkrl TYPE kfrkrl,
        fbsta TYPE fbsta,
      END OF ts_vttk .
  types:
    tt_vttk TYPE STANDARD TABLE OF ts_vttk .
  types:
    BEGIN OF ts_ship_cost_itm_cat_config,
        fkpty TYPE fkpty,
        abrel TYPE abrel,
        beser TYPE beser,
      END OF ts_ship_cost_itm_cat_config .
  types:
    tt_ship_cost_itm_cat_config TYPE STANDARD TABLE OF ts_ship_cost_itm_cat_config .
  types:
    BEGIN OF ts_shipment_details,
        tknum TYPE tknum,
        tpnum TYPE tpnum,
        vbeln TYPE vbeln_vl,
      END OF ts_shipment_details .
  types:
    tt_shipment_details TYPE STANDARD TABLE OF ts_shipment_details .
  types:
    BEGIN OF ts_dcgr,
        vbeln      TYPE vbeln_vl,
        tknum      TYPE tknum,
        dcgr       TYPE char1,
        frkrl      TYPE kfrkrl,
        fbsta      TYPE fbsta,
        inb_assgnd TYPE char1,
        ship_ref   TYPE char1,
        ship_bolnr TYPE char1,
      END OF ts_dcgr .
  types:
    tt_dcgr_tab TYPE STANDARD TABLE OF ts_dcgr WITH EMPTY KEY .

  class-data GT_VTTK type TT_VTTK .
  class-data GT_TVTK type TT_TVTK .
  class-data GT_TVFTK type TT_TVFTK .
  class-data GT_TVFT type TT_SHIP_COST_ITM_CAT_CONFIG .
  class-data GT_VTSP type VTSP_TAB .
  class-data GT_LIKP type TT_LIKP .
  class-data GT_VTTP type TT_SHIPMENT_DETAILS .
  class-data GT_VTTS type TT_VTTS .

  class-methods CHECK_DCGR
    importing
      !IT_VBELN_TKNUM type ZDL_VBELN_TKNUM_T
    exporting
      !ET_DCGR_TAB type TT_DCGR_TAB .
  class-methods PICK_PACK_HU
    importing
      !IV_OBD_DLVRY type VBELN_VL
      !IS_VBKOK type VBKOK
      !IT_VBPOK type VBPOK_T
    exporting
      !ET_PORT type TAB_PROTT
      !EV_SUBRC type SY-SUBRC
      !ET_MESSAGES type ZCA_BAL_MSG_TAB .
  class-methods DELETE_DELIVERY
    importing
      !IV_DELIVERY type BAPIOBDLVHDRCHG-DELIV_NUMB
    exporting
      !ET_RETURN type BAPIRET2_T .
  class-methods CREATE_OBD_DLVRY
    importing
      !IV_DLK type BOOLEAN
      !IT_OUTBOUND_DATA type ZDL_BAPIDLVREFTOSALESORDER_T
      !IS_INB_DLVRY type TY_S_INB_DLVRY
    exporting
      !EV_OUT_DLVRY type VBELN_VL
      !ET_MESSAGES type ZCA_BAL_MSG_TAB .
protected section.
private section.

  class-methods GET_SHIPMENT
    importing
      !IT_VBELN_TKNUM type ZDL_VBELN_TKNUM_T
    exporting
      !ET_DCGR_TAB type TT_DCGR_TAB .
  class-methods MERGE_SHIPMENT
    importing
      !IT_SHIPMENT type ZDL_TKNUM_T .
  class-methods GET_DCGR_INFO .
  class-methods GET_INBOUND_ASSIGNED_STAGE .
  class-methods SHIPMENT_REF_INB .
  class-methods PREPARE_OUTPUT
    exporting
      !ET_DCGR_TAB type TT_DCGR_TAB .
  class-methods BUILD_HANDLING_UNIT
    importing
      !IT_VBPOK type VBPOK_T
      !IV_OBD_DLVRY type VBELN_VL
    exporting
      !ET_HANDLING_UNIT type HUM_REHANG_HU_T
      !ET_MESSAGES type ZCA_BAL_MSG_TAB .
  class-methods PREPARE_Z_FILEDS
    importing
      !IS_INB_DLVRY type TY_S_INB_DLVRY
    exporting
      !ET_EXTENSION_IN type BAPIPAREX_T .
ENDCLASS.



CLASS ZCL_DL_E3637_DCGR_CHECKS IMPLEMENTATION.


  METHOD build_handling_unit.
    CLEAR: et_handling_unit,
           et_messages.

    CHECK it_vbpok IS NOT INITIAL.
    SELECT venum,
           vepos
          INTO TABLE @DATA(lt_vepo)
          FROM vepo
          FOR ALL ENTRIES IN @it_vbpok
          WHERE matnr = @it_vbpok-matnr
            AND werks = @it_vbpok-werks
            AND lgort = @it_vbpok-lgort
            AND charg = @it_vbpok-charg.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.


    SORT lt_vepo BY venum.
    IF lt_vepo IS NOT INITIAL.
      SELECT venum,
             exidv,
             status
        INTO TABLE @DATA(lt_vekp)
        FROM vekp
        FOR ALL ENTRIES IN @lt_vepo
        WHERE venum = @lt_vepo-venum AND
              vpobj <> '01'.
      IF sy-subrc <> 0.
        RETURN.
      ENDIF.
    ENDIF.

    et_handling_unit = VALUE #( FOR ls_vekp IN lt_vekp
                              ( top_hu_external = ls_vekp-exidv ) ).
* Fill app log table if the HU status is 50 or 60.
    LOOP AT lt_vekp INTO DATA(ls_status).
      IF ls_status-status = '0050' OR
         ls_status-status = '0060'.
        APPEND VALUE #( msgty  = 'W'
                        msgid  = 'ZDL_RFSCOP'
                        msgno  = '102'
                        msgv1  = ls_status-exidv
                        msgv2  = ls_status-status
                        msgv3  = iv_obd_dlvry ) TO et_messages.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


  METHOD check_dcgr.
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2019 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: DCGR Check                                             *
*                                                                      *
* SAP Name    : CHECK_DCGR                       Create Date: 05/01/19 *
*                                                                      *
* Programmer  : John Leo William                 Last Update: 05/01/19 *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*                                                                      *
*    1. If shipment is NOT updated on inbound delivery by sync program *
*    then do not do GR.                                                *
*    2. If Shipment is DCGR relevant (build logic) then make sure      *
*    shipment cost document is in C status. Otherwise do not post GR.  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* John Leo William    05/01/19                                         *
*                                                                      *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
* Initialize exporting parameter.
    CLEAR et_dcgr_tab.

* Check if the importing tbale in empty
    CHECK  it_vbeln_tknum IS NOT INITIAL.

* Get shipment number based on the delivery and if only shipment number
* is passed, then merge them into one internal table
    get_shipment(
      EXPORTING
        it_vbeln_tknum      = it_vbeln_tknum
      IMPORTING
        et_dcgr_tab         = et_dcgr_tab ).

* Retrun if the exporting table is empty
    IF et_dcgr_tab IS NOT INITIAL.
      RETURN.
    ENDIF.

* Find DCGR all the shipments entered
    get_dcgr_info( ).

* If shipment is not DCGR relevent, then no need to check other
* validations
    IF gt_tvft IS INITIAL.
      RETURN.
    ENDIF.

* Get inbound assigned to stage for the shipments
    get_inbound_assigned_stage( ).

* Get reference to inbound to shipments
    shipment_ref_inb( ).

* Prepare required the output.
    prepare_output(
      IMPORTING
        et_dcgr_tab = et_dcgr_tab ).
  ENDMETHOD.


  METHOD create_obd_dlvry.
    DATA lt_return TYPE bapiret2_t.

    CLEAR: ev_out_dlvry,
           et_messages.

* Check if the process is DLK.
    CASE iv_dlk.
      WHEN abap_true.
        prepare_z_fileds(
          EXPORTING
            is_inb_dlvry    = is_inb_dlvry
          IMPORTING
            et_extension_in = DATA(lt_extension_in) ).    " BAPI Extension

* Fill sales order Item.
        DATA(lt_sales_ord_items) = VALUE zdl_bapidlvreftosalesorder_t(
                                             FOR ls_so_item IN it_outbound_data
                                          ( ref_doc    = ls_so_item-ref_doc
                                            ref_item   = ls_so_item-ref_item
                                            dlv_qty    = ls_so_item-dlv_qty
                                            sales_unit = ls_so_item-sales_unit ) ).
      WHEN abap_false.
        lt_sales_ord_items = VALUE zdl_bapidlvreftosalesorder_t(
                                             FOR ls_so_item IN it_outbound_data
                                          ( ref_doc    = ls_so_item-ref_doc
                                            ref_item   = ls_so_item-ref_item
                                            dlv_qty    = ls_so_item-dlv_qty
                                            sales_unit = ls_so_item-sales_unit ) ).
      WHEN OTHERS.
    ENDCASE.

* Call the BAPI to create outbound delivery
    CALL FUNCTION 'BAPI_OUTB_DELIVERY_CREATE_SLS'
      EXPORTING
        ship_point        = is_inb_dlvry-werks "iv_ship_point
        due_date          = '99991231'
      IMPORTING
        delivery          = ev_out_dlvry
      TABLES
        sales_order_items = lt_sales_ord_items
        extension_in      = lt_extension_in
        return            = lt_return.

* Read the retrun table with message type E.
*    IF line_exists( lt_return[ type = 'E' ] ).
*      ROLLBACK WORK.
* Fill the exporting table with BAPI returned error message.
    et_messages = VALUE #( FOR ls_return IN lt_return
                          ( msgty = ls_return-type
                            msgid = ls_return-id
                            msgno = ls_return-number
                            msgv1 = ls_return-message_v1
                            msgv2 = ls_return-message_v2
                            msgv3 = ls_return-message_v3
                            msgv4 = ls_return-message_v4 ) ).
*    ELSE.
*      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*        EXPORTING
*          wait = abap_true.
*    ENDIF.
  ENDMETHOD.


  METHOD delete_delivery.
    CLEAR et_return.
* Fill header level data.
    DATA(ls_header_data) = VALUE bapiobdlvhdrchg( deliv_numb = iv_delivery ).
    DATA(ls_header_ctrl) = VALUE bapiobdlvhdrctrlchg( deliv_numb = iv_delivery
                                                      dlv_del    = abap_true ).

* make sy-batch input as abap true to avoid popups from the bapi.
    sy-binpt = abap_true.
    CALL FUNCTION 'BAPI_OUTB_DELIVERY_CHANGE'
      EXPORTING
        header_data    = ls_header_data
        header_control = ls_header_ctrl
        delivery       = iv_delivery
      TABLES
        return         = et_return.

    IF et_return IS INITIAL.
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
        EXPORTING
          wait = abap_true.
    ENDIF.
    sy-binpt = abap_false.
  ENDMETHOD.


  METHOD get_dcgr_info.
* Find all the shipemts if they are relevent to DCGR.
    CHECK gt_vttp IS NOT INITIAL.

* 1. Get all the shipment typs for the shipments.
    SELECT tknum,
           shtyp,
           frkrl,
           fbsta
      INTO TABLE @gt_vttk
      FROM vttk
      FOR ALL ENTRIES IN @gt_vttp
      WHERE tknum = @gt_vttp-tknum.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
* Get shipment cost type.
    SELECT shtyp,
           fkart
      FROM tvtk
      INTO TABLE @gt_tvtk
      FOR ALL ENTRIES IN @gt_vttk
      WHERE shtyp = @gt_vttk-shtyp.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
* Get shipment cost item category
    SELECT fkart,
           fkpty
      FROM tvftk
      INTO TABLE @gt_tvftk
      FOR ALL ENTRIES IN @gt_tvtk
      WHERE fkart = @gt_tvtk-fkart.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
* o	Get Shipment cost item category type configuration
    SELECT fkpty,
           abrel,
           beser
      FROM tvft
      INTO TABLE @gt_tvft
      FOR ALL ENTRIES IN @gt_tvftk
      WHERE fkpty = @gt_tvftk-fkpty.
    IF sy-subrc <> 0.
      CLEAR gt_tvft.
    ENDIF.
  ENDMETHOD.


  METHOD get_inbound_assigned_stage.
    TYPES: lr_tpnum TYPE RANGE OF tpnum.

    CHECK gt_vttp IS NOT INITIAL.

* Get all the stage related information based on shipment number
    SELECT tknum,
           tsnum
      FROM vtts
      INTO TABLE @gt_vtts
      FOR ALL ENTRIES IN @gt_vttp
      WHERE tknum = @gt_vttp-tknum.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

* Convert TPNUM into range table.
    DATA(lr_tpnum) = VALUE lr_tpnum( FOR ls_tpnum IN gt_vttp
                                    ( sign = 'I'
                                     option = 'EQ'
                                     low = ls_tpnum-tpnum ) ).
    IF gt_vtts IS NOT INITIAL.
      SELECT *
        FROM vtsp
        INTO TABLE @gt_vtsp
        FOR ALL ENTRIES IN @gt_vtts
        WHERE tknum = @gt_vtts-tknum AND
              tsnum = @gt_vtts-tsnum AND
              tpnum IN @lr_tpnum.
      IF sy-subrc <> 0.
        CLEAR gt_vtsp.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD get_shipment.
* initialize exporting parameter
    CLEAR: et_dcgr_tab.

* Get deleivery into a separate internal table
    DATA(lt_inbound) = VALUE zdl_vbeln_t( FOR ls_inbound IN it_vbeln_tknum
                                        ( vbeln = ls_inbound-vbeln ) ).

    DELETE lt_inbound WHERE vbeln IS INITIAL.

* Shipment number into a separate internal table
    DATA(lt_tknum) = VALUE zdl_tknum_t( FOR ls_tknum IN it_vbeln_tknum
                                        ( tknum = ls_tknum-tknum ) ).

    DELETE lt_tknum WHERE tknum IS INITIAL.

* Identify the shipment# associated with the inbound delivery#
    IF lt_inbound IS NOT INITIAL.
      SELECT tknum,
             tpnum,
             vbeln
        FROM vttp
        INTO TABLE @gt_vttp
        FOR ALL ENTRIES IN @lt_inbound
        WHERE vbeln = @lt_inbound-vbeln.
      IF sy-subrc <> 0 AND lt_tknum IS INITIAL.
* Fill the exporting table and retrun.
        et_dcgr_tab = VALUE #( FOR ls_inb IN lt_inbound
                               ( vbeln = ls_inb-vbeln
                                 dcgr  = space
                                 fbsta = space
                                 frkrl = space
                                 inb_assgnd = space
                                 ship_ref = space
                                 ship_bolnr = space ) ).
        RETURN.
      ENDIF. " sy-subrc Check
    ENDIF. " For all entries Check

    merge_shipment(
      EXPORTING
        it_shipment         = lt_tknum ).
  ENDMETHOD.


  METHOD merge_shipment.
* If the input shipment table is not empty, then consider
* those input shipments as well for processing
    IF it_shipment IS NOT INITIAL.
      APPEND LINES OF it_shipment TO gt_vttp.
      SORT gt_vttp BY tknum ASCENDING.
      DELETE ADJACENT DUPLICATES FROM gt_vttp COMPARING tknum.
    ENDIF.
  ENDMETHOD.


  METHOD pick_pack_hu.
    CLEAR:et_port,
          ev_subrc.

    DATA(lt_vbpok) = it_vbpok[].
* build handling units table.
    build_handling_unit(
      EXPORTING
        iv_obd_dlvry = iv_obd_dlvry
        it_vbpok     = it_vbpok
      IMPORTING
        et_handling_unit = DATA(lt_handling_unit)
        et_messages      = et_messages ).

      IF et_messages IS NOT INITIAL.
        RETURN.
      ENDIF.
* Delete the handling unit which is not required for pick and pack.
*    DATA(lr_handling_unit) = VALUE bicbh_t_charg( FOR ls_hand_unit IN lt_vbpok
*                                                ( sign = 'I'
*                                                  option = 'EQ'
*                                                  low = ls_hand_unit-charg ) ).
*
*    DELETE lt_handling_unit WHERE top_hu_external NOT IN lr_handling_unit.
*  information messages/displaying the messages on status bar
    CALL FUNCTION 'HU_PACKING_REFRESH'.

    CALL FUNCTION 'WS_DELIVERY_UPDATE'
      EXPORTING
        vbkok_wa                 = is_vbkok
        delivery                 = is_vbkok-vbeln_vl
        update_picking           = abap_true
        if_database_update       = '1' "check & save
        if_error_messages_send_0 = space
        if_get_delivery_buffered = abap_true
      TABLES
        vbpok_tab                = lt_vbpok
        prot                     = et_port
        it_handling_units        = lt_handling_unit.

    IF et_port IS NOT INITIAL AND
       line_exists( et_port[ msgty = 'E' ] ).
      ev_subrc = 4.
    ELSE.
      COMMIT WORK AND WAIT.
      CLEAR lt_handling_unit.
      ev_subrc = sy-subrc.
    ENDIF.
  ENDMETHOD.


  METHOD prepare_output.
    CLEAR et_dcgr_tab.

    LOOP AT gt_vttp INTO DATA(ls_vttp).

* Read VTTK table with Shipment number to get the shipment type
      DATA(ls_vttk) = VALUE #( gt_vttk[ tknum = ls_vttp-tknum ] OPTIONAL ).

* Read TVTK table with shipment type to get shipment type configuration
      DATA(ls_tvtk) = VALUE #( gt_tvtk[ shtyp = ls_vttk-shtyp ] OPTIONAL ).

* Read TVFTK with shipment cost document type from TVTK in order to get
* the shipment cost item category
      DATA(ls_tvftk) = VALUE #( gt_tvftk[ fkart = ls_tvtk-fkart ] OPTIONAL ).

* Read TVFT with shipment cost item category from TVFTK
      DATA(ls_tvft) = VALUE #( gt_tvft[ fkpty = ls_tvftk-fkpty ] OPTIONAL ).

* Check the indicator Relevant for settlement and Generate Purchase order
      IF ls_tvft-abrel = 'A'
       AND ls_tvft-beser = space.
* Set the flag DCGR as X.
        DATA(lv_dcgr) = abap_true.
      ENDIF.

* If the shipment is relevent to DCGR then proceed with other validations
* else fill the exporting table accordingly and go to next record.
      CASE lv_dcgr.
        WHEN abap_true.
* SHIPMENT HEADER COST DOCUMENT STATUS
          IF ls_vttk-frkrl = abap_true.
            DATA(lv_fbsta) = ls_vttk-fbsta.
          ENDIF.

* INBOUND ASSIGNED TO STAGE
          DATA(ls_vtts) = VALUE #( gt_vtts[ tknum = ls_vttp-tknum ] OPTIONAL ).
* •	Read VTSP table. If the read success then fill the value else
* fill exporting table and exit
          DATA(ls_vtsp) = VALUE #( gt_vtsp[ tknum = ls_vttk-tknum
                                            tsnum = ls_vtts-tsnum
                                            tpnum = ls_vttp-tpnum ] OPTIONAL ).
          IF ls_vtsp IS NOT INITIAL.
            DATA(lv_inb_assigned_stage) = abap_true.
          ENDIF.

* SHIPMENT REFERENCE ON INBOUND
* Read LIKP table with Inbound delivery
          DATA(ls_likp) = VALUE #( gt_likp[ vbeln = ls_vttp-vbeln ] OPTIONAL ).
          IF ls_likp-lifex = ls_vttp-tknum.
            DATA(lv_shipment_ref_inb) = abap_true.
          ENDIF.
          IF ls_likp-bolnr = ls_vttp-tknum.
            DATA(lv_bolnr) = abap_true.
          ENDIF.

* Fill the exporting table.
          APPEND VALUE #( vbeln = ls_vttp-vbeln
                          tknum = ls_vttp-tknum
                          dcgr  = lv_dcgr
                          frkrl = ls_vttk-frkrl
                          fbsta = lv_fbsta
                          inb_assgnd = lv_inb_assigned_stage
                          ship_ref   = lv_shipment_ref_inb
                          ship_bolnr = lv_bolnr ) TO et_dcgr_tab.
        WHEN OTHERS.
* Fill the exporting table.
          APPEND VALUE #( vbeln = ls_vttp-vbeln
                          tknum = ls_vttp-tknum
                          dcgr  = space ) TO et_dcgr_tab.
      ENDCASE.

      CLEAR: lv_dcgr,
             lv_fbsta,
             lv_inb_assigned_stage,
             lv_shipment_ref_inb,
             ls_vttk,
             ls_tvtk,
             ls_tvftk,
             ls_tvft,
             ls_vtts,
             ls_vtsp,
             ls_likp.
    ENDLOOP.
  ENDMETHOD.


  METHOD prepare_z_fileds.
    CLEAR et_extension_in.

* Fill all the Z fields.
    et_extension_in = VALUE #( structure = 'LIKP'
                               ( valuepart1 = 'ZZ_EXIT_PASS_NO'
                                 valuepart2 = is_inb_dlvry-zz_exit_pass_no )
                               ( valuepart1 = 'ZZ_SCAC'
                                 valuepart2 = is_inb_dlvry-zz_scac )
                               ( valuepart1 = 'ZZ_SIGNI'
                                 valuepart2 = is_inb_dlvry-zz_signi )
                               ( valuepart1 = 'ZZ_BALE_CNT'
                                 valuepart2 = is_inb_dlvry-zz_bale_cnt )
                               ( valuepart1 = 'ZZ_BOL'
                                 valuepart2 = is_inb_dlvry-zz_bol )
                               ( valuepart1 = 'ZZ_SCALE'
                                 valuepart2 = is_inb_dlvry-zz_scale )
                               ( valuepart1 = 'ZZ_COMPLETE'
                                 valuepart2 = is_inb_dlvry-zz_complete )
                               ( valuepart1 = 'ZZ_SHIP_DATE'
                                 valuepart2 = is_inb_dlvry-zz_ship_date )
                               ( valuepart1 = 'ZZ_GROSS_WT'
                                 valuepart2 = is_inb_dlvry-zz_gross_wt )
                               ( valuepart1 = 'ZZ_NET_WT'
                                 valuepart2 = is_inb_dlvry-zz_net_wt )
                               ( valuepart1 = 'ZZ_TARE_WT'
                                 valuepart2 = is_inb_dlvry-zz_tare_wt ) ).
  ENDMETHOD.


  METHOD shipment_ref_inb.

    CHECK gt_vttp IS NOT INITIAL.

    SELECT vbeln,
           lifex,
           bolnr
      FROM likp
      INTO TABLE @gt_likp
      FOR ALL ENTRIES IN @gt_vttp
      WHERE vbeln = @gt_vttp-vbeln.
    IF sy-subrc <> 0.
      CLEAR gt_likp.
    ENDIF.
  ENDMETHOD.
ENDCLASS.

@AbapCatalog.sqlViewName: 'ZDL_TRDS_INB_SQL'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #CHECK
@Analytics.dataExtraction.enabled: true
@Analytics.dataCategory: #FACT
@EndUserText.label: 'SCORE Trades Inbound Deliveries CDS View'

define view ZDL_TRDS_INB_VW as select from zdl_trds_inb_veh {

    // Table: ZDL_TRDS_INB_VEH
    
    // Key Fields
    key ebeln as EBELN,
    key ebelp as EBELP,
    key etens as SEQNO,
    
    // Data Fields
    bolnr as BOLNR,
    traid as VEHNUM,
    lifnr as VENDOR,
    werks as PLANT,
    vsart as SHIPPTYP,
    
    
    // Key Figures
    @DefaultAggregation: #SUM
    btgew as GROSS_WT
    
}

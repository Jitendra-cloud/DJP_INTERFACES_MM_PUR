FUNCTION zsd_dl_sord_label_file.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IV_LABEL_NAME) TYPE  CHAR255
*"     REFERENCE(IV_LOCAL_FOLDER) TYPE  LOCALFILE OPTIONAL
*"     REFERENCE(IV_BAR_FILE_LOCATION) TYPE  LOCALFILE DEFAULT
*"       'C:\bar.bmp'
*"  TABLES
*"      IT_ZSOMTRANSF STRUCTURE  ZSOMTRANSF
*"      ET_FILENAMES STRUCTURE  ZSOMTRANSF_LABEL
*"----------------------------------------------------------------------
***********************************************************************
**                                                                   **
**             C O M P A N Y   C O N F I D E N T I A L               **
**                                                                   **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
**                                                                   **
***********************************************************************
***********************************************************************
**                                                                   **
**                    COPYRIGHT (C) 2005 by                          **
**                     INTERNATIONAL PAPER                           **
**                                                                   **
**                     ALL RIGHTS RESERVED                           **
**                                                                   **
**                   REVISIONS COPYRIGHT (C)                         **
**                            2005                                   **
**                             by                                    **
**                     INTERNATIONAL PAPER                           **
***********************************************************************
*_____________________________________________________________________*
* Function Module: ZSD_DL_SORD_LABEL_FILE        Date: 10/09/2005     *
*  Function Group: ZSD_DL_SORD_TRANSF                                 *
*                                                                     *
* Programmer  : Randall Wainwright                                    *
*                                                                     *
*_____________________________________________________________________*
* Description : Function module creates the label files               *
*   necessary for reprinting labels for sales order stock.            *
*  First implemented in program ZSD_DL_E02999_TRANSF_ROLLS:           *
*      Automated tool for transfer of rolls from one sales order to   *
*      another.                                                       *
*---------------------------------------------------------------------*
*_____________________________________________________________________*
* Change History:                                                     *
*     Programmer        Date    Req. #            Action              *
* ==================  ========  ======  ==============================*
* Chandra Cherupally  05/20/2008 E0VK939628  CHG89023 - USD4330607    *
* Description of changes - This FM was called for every batch once.   *
* So, in order to improve the performance, the interface to this FM is*
* changed so that it can be called only once per execution with all the
* batches and also removed selects outside the loop. Almost re-wrote  *
* the FM and also used GUI_UPLOAD instead of WS_UPLOAD (obsolete)     *
**                                                                   **
* Chandra Cherupally 06/05/2008 E0VK940141 USD4366015 - Instead of    *
*  using GUI_DOWNLOAD, GUI_UPLOAD was used. So used the correct FM    *
*   name.                                                              *
* ============  ========  ==========  =================================*
* BBALLEH       06/24/08  EDVK961704  Changes related to the changes   *
*                                     in fm ZSD_DL_SORD_MAT_TRANSF     *
*                         BCB01                                        *
*                                     Structure ZSOMTRANSF was         *
*                                     modified so this function and    *
*                                     ZSD_DL_SORD_MAT_TRANSF needed to *
*                                     be changed to follow suit.       *
*                                                                      *
************************************************************************

  DATA : lv_outfile    TYPE string,
         lv_old_cuobj  TYPE cuobj_va,
         lv_old_matnr  TYPE matnr,
         lv_old_werks  TYPE werks_d,
         lv_old_charg  TYPE charg_d,
         lv_filename   TYPE localfile.

  REFRESH : et_filenames.

  PERFORM get_vbap_data TABLES it_zsomtransf.

  PERFORM get_cust_info TABLES it_zsomtransf.

  LOOP AT it_zsomtransf.
    CLEAR gs_vbap.
*   Begin BCB01
*    READ TABLE gt_vbap INTO gs_vbap WITH KEY
*                                    vbeln = it_zsomtransf-vbeln
*                                    posnr = it_zsomtransf-posnr
*                                    BINARY SEARCH.
    READ TABLE gt_vbap INTO gs_vbap WITH KEY
                                    vbeln = it_zsomtransf-vbeln_from
                                    posnr = it_zsomtransf-posnr_from
                                    BINARY SEARCH.
*   End BCB01
    IF sy-subrc EQ 0.
      IF lv_old_cuobj NE gs_vbap-cuobj.
        lv_old_cuobj = gs_vbap-cuobj.
* SO characteristics
        PERFORM get_vc_char USING gs_vbap-cuobj.
      ENDIF.
    ENDIF.
    IF lv_old_matnr NE it_zsomtransf-matnr OR
*       lv_old_werks NE it_zsomtransf-werks OR  "BCB01
       lv_old_werks NE it_zsomtransf-werks_from OR  "BCB01
       lv_old_charg NE it_zsomtransf-charg.
      lv_old_matnr = it_zsomtransf-matnr.
*      lv_old_werks = it_zsomtransf-werks.  "BCB01
      lv_old_werks = it_zsomtransf-werks_from.  "BCB01
      lv_old_charg = it_zsomtransf-charg.
* Batch Characteristics
      PERFORM get_batch_char USING it_zsomtransf-matnr
*                                   it_zsomtransf-werks "BCB01
                                   it_zsomtransf-werks_from "BCB01
                                   it_zsomtransf-charg.
    ENDIF.

    CHECK NOT ( gt_config_si[] IS INITIAL AND
                gt_config_b[]  IS INITIAL ).

    PERFORM build_output_file USING it_zsomtransf
                                    iv_label_name
                                    iv_bar_file_location.
* Specify output location
    IF NOT iv_local_folder IS INITIAL.
      CONCATENATE iv_local_folder
                  it_zsomtransf-charg
                  '.txt'
             INTO lv_outfile.
    ELSE.
      CONCATENATE 'C:\'
                  it_zsomtransf-charg
                  '.txt'
             INTO lv_outfile.
    ENDIF.

    PERFORM download_file USING lv_outfile
                       CHANGING lv_filename.
    CLEAR et_filenames.
    et_filenames-charg = it_zsomtransf-charg.
    IF lv_filename IS INITIAL.
      et_filenames-type = 'E'.
      et_filenames-message = 'Error'(007).
    ELSE.
      et_filenames-filename = lv_filename.
    ENDIF.
    APPEND et_filenames.
  ENDLOOP.

ENDFUNCTION.

FUNCTION ZSD_DL_E03240_CALC_STO_SLOTS.
*"--------------------------------------------------------------------
*"*"Global interface:
*"       IMPORTING
*"             REFERENCE(I_VSBED) LIKE  LIKP-VSBED
*"             REFERENCE(I_PLANT) LIKE  LIKP-WERKS
*"             REFERENCE(I_CUOBJ) LIKE  AFKO-CUOBJ
*"             REFERENCE(I_MENGE) LIKE  EKET-MENGE
*"             REFERENCE(I_UNIT_WEIGHT) TYPE  ZUNIT_WEIGHT OPTIONAL
*"       EXPORTING
*"             REFERENCE(E_SLOTS) TYPE  /GCDS04/OS_SLOTS
*"             REFERENCE(E_SLOTS_UNIT) TYPE  /GCDS04/OS_SLOTS_UNIT
*"             REFERENCE(E_SLOTS_PER_UNIT) TYPE  CHAR20
*"       EXCEPTIONS
*"              CONFIGURATION_OBJECT_REQ
*"              NO_UNIT_WEIGHT
*"              NO_ROLL_WIDTH
*"              NO_CAR_HEIGHT
*"--------------------------------------------------------------------
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005, 200nn                                **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Include Name: ZZSD_DL_CALC_STO_SLOTS                Date: 10/28/2005 *
* Programmer  : Charles M. Ramey                                       *
*______________________________________________________________________*
* Description :                                                        *
*  Function to change calculate the number of slots that will be used  *
* by a given product and quantity.  This is necessary for TP/VS to     *
* be able to optimize the schedule line.  This is a compliment to the  *
* CDP code (written for Sales orders and Deliveries) to calculate      *
* slots for STOs.                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* External Calls                                                       *
*  Function Modules:                                                   *
*      VC_I_GET_CONFIGURATION - retrieves characteristics              *
*      /GCDS04/OS_READ_FPF    - retrieves footprint factor             *
*      ROUND                  - rounds a decimal up or down to next    *
*                               whole nubmer (depends upon direction)  *
*______________________________________________________________________*

  TYPE-POOLS: zsdc.

  IF i_cuobj IS INITIAL.
    RAISE configuration_object_req.
  ELSE.
    PERFORM get_characteristics.
  ENDIF.

  IF NOT i_unit_weight IS INITIAL.
    g_unit_weight = i_unit_weight.
  ENDIF.

  IF g_unit_weight IS INITIAL.
    RAISE no_unit_weight.
  ELSE.
    g_num_rolls = i_menge / g_unit_weight.
  ENDIF.

  PERFORM slot_mode_select USING i_vsbed i_plant.
  PERFORM get_car_dimensions USING g_slot_mode
          CHANGING g_max_stack_height g_car_height g_car_unit g_return.
  PERFORM get_footprint_factor.
  PERFORM calculate_slots.

ENDFUNCTION.
*&---------------------------------------------------------------------*
*&      Form  get_characteristics
*&---------------------------------------------------------------------*
* this Subroutine will take in the configuration object and retrives
* the characteristics for the material (MTS) or the Sales order -
* whichever it has been fed in.
*----------------------------------------------------------------------*
FORM get_characteristics.
  DATA l_char TYPE zsd_characteristic_name OCCURS 0 WITH HEADER LINE.
  CLEAR g_config_obj.
  g_config_obj = i_cuobj.

  l_char-atnam = zsdc_roll_diameter.
  APPEND l_char.
  l_char-atnam = zsdc_roll_width.
  APPEND l_char.
  l_char-atnam = zsdc_unit_weight.
  APPEND l_char.
  l_char-atnam = zsdc_max_roll_in_package.
  APPEND l_char.

  CALL FUNCTION 'ZSD_E2807_GET_CONFIGURATION'
    EXPORTING
      instance                       = g_config_obj
    TABLES
      t_get_specific_characteristics = l_char
      configuration                  = gt_config[]
    EXCEPTIONS
      instance_not_found             = 1
      no_configuration_data_found    = 2
      characteristic_not_found       = 3
      OTHERS                         = 4.

  IF sy-subrc is initial.
    SORT gt_config BY atnam.
    DELETE ADJACENT DUPLICATES FROM gt_config COMPARING atnam.
  ENDIF.

  PERFORM read_characteristic USING zsdc_roll_diameter.
  g_roll_diam    = gt_config-atwrt.
  PERFORM read_characteristic USING zsdc_roll_width.
  g_roll_width   = gt_config-atwrt.
  PERFORM read_characteristic USING zsdc_max_roll_in_package.
  g_rolls_in_pkg = gt_config-atwrt.
  PERFORM read_characteristic USING zsdc_unit_weight.
  g_unit_weight  = gt_config-atwrt.
ENDFORM.                    "get_characteristics
*&---------------------------------------------------------------------*
*&      Form  read_characteristic
*&---------------------------------------------------------------------*
*  Reads the Characteristic table to get the ones necessary to compute
* slots.  It also removes any UOM that may be attached
*----------------------------------------------------------------------*
FORM read_characteristic  USING p_characteristic LIKE conf_out-atnam.

  DATA: l_cha_data    LIKE gt_config-atwrt,
        l_cha_garbage LIKE gt_config-atwrt.

  IF NOT gt_config-atnam = p_characteristic.
    CLEAR: gt_config, l_cha_data, l_cha_garbage.
    READ TABLE gt_config WITH KEY
      atnam = p_characteristic
      BINARY SEARCH.
    IF NOT gt_config IS INITIAL.
* Skipping leading spaces, take the first string, separated by the
*  subsequent string with a space into a new field, throwing out
*  subsequent data. We are only concerned with the first.
      CONDENSE gt_config-atwrt.
      SPLIT gt_config-atwrt AT space INTO l_cha_data l_cha_garbage.

* Remove commas, if applicable
      REPLACE ALL OCCURRENCES OF ',' IN l_cha_data WITH ' '.
      CONDENSE l_cha_data NO-GAPS.

      gt_config-atwrt = l_cha_data.
    ENDIF. " NOT gt_config is initial.
  ENDIF. " NOT gt_config-atnam = p_characteristic.
ENDFORM.                    " READ_CHARACTERISTIC
*&---------------------------------------------------------------------*
*&      Form  slot_mode_select
*&---------------------------------------------------------------------*
* retrieves the MOT for the plant / Shipping Condition
*----------------------------------------------------------------------*
FORM slot_mode_select  USING    iv_mode
                                iv_plant.
  CLEAR g_slot_mode.

  SELECT SINGLE default_mode FROM /gcds04/os_mode INTO g_slot_mode
    WHERE doc_mode = iv_mode
      AND plant = iv_plant.

  IF sy-subrc NE 0.
    SELECT SINGLE default_mode FROM /gcds04/os_mode INTO g_slot_mode
    WHERE doc_mode = iv_mode
      AND plant = space.
  ENDIF.
ENDFORM.                    " slot_mode_select
*&---------------------------------------------------------------------*
*&      Form  get_car_dimensions
*&---------------------------------------------------------------------*
* Based upon the MOT, retrieves the dimensions of the vehicle
*----------------------------------------------------------------------*
FORM get_car_dimensions  USING    iv_slot_mode
                         CHANGING cv_msh
                                  cv_ch
                                  cv_ch_unit
                                  cv_rc.

  DATA: ls_osmoddim TYPE /gcds04/osmoddim.

  SELECT SINGLE * FROM /gcds04/osmoddim INTO ls_osmoddim
    WHERE default_mode = iv_slot_mode.

  IF sy-subrc EQ 0.
    cv_msh     = ls_osmoddim-max_stack_height.
    cv_ch      = ls_osmoddim-car_height.
    cv_ch_unit = ls_osmoddim-car_height_unit.
    cv_rc = 0.
  ELSE.
    cv_rc = 4.
  ENDIF.
ENDFORM.                    " get_car_dimensions
*&---------------------------------------------------------------------*
*&      Form  get_footprint_factor
*&---------------------------------------------------------------------*
* retrieves the FootPrint factor (which is used to help calculate the
*  number of a particular diameter are requred to fill a vehicle).
*----------------------------------------------------------------------*
FORM get_footprint_factor.
  DATA gv_roll_diam  TYPE /gcds04/os_roll_diameter.
  gv_roll_diam = g_roll_diam.

  CALL FUNCTION '/GCDS04/OS_READ_FPF'
    EXPORTING
      i_mode           = g_slot_mode
      i_plant          = i_plant
      i_roll_diameter  = gv_roll_diam
      i_roll_diam_unit = 'IN'
    IMPORTING
      e_fpf            = g_footprint_factor.
ENDFORM.                    "get_footprint_factor
*&---------------------------------------------------------------------*
*&      Form  CALCULATE_SLOTS
*&---------------------------------------------------------------------*
* - calculation to generate the number of slots used - it also
* calculates the number of slots per unit (which is slots per lb) which
* is important so a Partial delivery does not force the recalculation
* of slots.
*----------------------------------------------------------------------*
FORM calculate_slots.
  DATA: l_stack_factor    TYPE f,
        l_total_footprint TYPE f,
        l_stack_footprint TYPE f.

  IF g_car_height IS INITIAL.
    RAISE no_car_height.
  ELSE.
    IF g_roll_width IS INITIAL.
      RAISE no_roll_width.
    ELSE.
      l_stack_factor = g_car_height / g_roll_width.
      PERFORM round_whole USING gc_round_down l_stack_factor.
    ENDIF.
  ENDIF.

  l_total_footprint = g_num_rolls * g_footprint_factor.
  PERFORM round_whole USING gc_round_up l_total_footprint.

  IF NOT l_stack_factor IS INITIAL.
    l_stack_footprint = l_total_footprint / l_stack_factor.
    PERFORM round_whole USING gc_round_up l_stack_footprint.

    e_slots = l_stack_footprint * g_max_stack_height.
    e_slots_unit = 'SL'.
    e_slots_per_unit = e_slots / i_menge.
  ENDIF.
ENDFORM.                    "CALCULATE_SLOTS
*&---------------------------------------------------------------------*
*&      Form  round_whole
*&---------------------------------------------------------------------*
*  Subroutine rounds the input number either up or down depending
*  upon the direction provided by the caller.
*----------------------------------------------------------------------*
FORM round_whole  USING   p_sign
            CHANGING c_number.

  DATA: l_decimals TYPE andec.

  l_decimals = 0.
  CALL FUNCTION 'ROUND'
    EXPORTING
      decimals      = l_decimals
      input         = c_number
      sign          = p_sign
    IMPORTING
      output        = c_number
    EXCEPTIONS
      input_invalid = 1
      overflow      = 2
      type_invalid  = 3
      OTHERS        = 4.

ENDFORM.                    " round_whole
*
*

FUNCTION-POOL zdl_e3637.                    "MESSAGE-ID ..

CONSTANTS:
  gc_error   TYPE symsgty VALUE 'E',
  gc_success TYPE symsgty VALUE 'S',
  gc_info    TYPE symsgty VALUE 'I',
  gc_msgid   TYPE symsgid VALUE 'ZSD_DL',
  gc_true    TYPE char1   VALUE 'X'.

DATA:
* BDC data
  gt_bdcdata LIKE TABLE OF bdcdata,
  gs_bdcdata LIKE bdcdata,

* BDC messages
  gt_messtab LIKE TABLE OF bdcmsgcoll,
  gs_messtab LIKE bdcmsgcoll,

* Outbound delivery
  gv_out_dlvry LIKE likp-vbeln, "CMS30577 E0VK9A0KS2 08/1/2016 SMITHAI
  gv_err_vl02n TYPE char1.      "CMS30577 E0VK9A0KS2 08/1/2016 SMITHAI

************************************************************************
************ ZDL_E3637_PICK_PACK - DATA DECLARATIONS *******************
************************************************************************

INCLUDE mbdconwf.

DATA:
*   Variables for IDOC_INBOUND_SINGLE
    gv_segnum           TYPE idocdsgnum, "idoc segment number
    gv_idoc_num         TYPE edi_docnum,
    gv_error_app        TYPE edi_errflg,
    gv_pick_flag        type char1,  "Pick Flag
    gv_pack_flag        type char1.  "Pack Flag

DATA:
*   Idoc control record structure for IDOC_INBOUND_SINGLE
    gs_idoc_ctrl40      TYPE edi_dc40, "edidc,

*   Idoc data structure for IDOC_INBOUND_SINGLE
    gt_idoc_data40        TYPE STANDARD TABLE OF edi_dd40."edidd,

DATA:
* Idoc status structure
  gt_idoc_status      TYPE STANDARD TABLE OF bdidocstat,
  gs_idoc_status      TYPE bdidocstat,

* Outbound delivery information
  gt_lips        like table of lips,

* Outbound delivery Pick and Pack status
  gt_vbup       like table of vbup.

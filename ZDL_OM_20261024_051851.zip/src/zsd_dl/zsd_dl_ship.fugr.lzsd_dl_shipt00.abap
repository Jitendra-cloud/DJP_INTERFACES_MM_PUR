*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_SUPPLY_DRIVN................................*
DATA:  BEGIN OF STATUS_ZDL_SUPPLY_DRIVN              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_SUPPLY_DRIVN              .
CONTROLS: TCTRL_ZDL_SUPPLY_DRIVN
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_SUPPLY_DRIVN              .
TABLES: ZDL_SUPPLY_DRIVN               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

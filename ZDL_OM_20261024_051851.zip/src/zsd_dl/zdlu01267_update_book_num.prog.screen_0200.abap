
PROCESS BEFORE OUTPUT.
  MODULE status_0200.
*
PROCESS AFTER INPUT.

  MODULE leave_transaction_0100 AT EXIT-COMMAND .

  CHAIN.
    FIELD: gs_zvekp-booknum, "book confirmation number
           gs_zvekp-seal,    "seal id
           gs_zvekp-con_size,"container size
           gs_zvekp-tare. "tare weight


    MODULE user_command_0200.

  ENDCHAIN.

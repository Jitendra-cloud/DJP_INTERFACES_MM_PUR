FUNCTION zsd_u01217_populate_vl06t.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IV_FLAG_INBOUND) TYPE  CHAR1
*"     REFERENCE(IV_PROC_TYPE) TYPE  CHAR1
*"  TABLES
*"      ET_POSTAB STRUCTURE  LIPOV
*"----------------------------------------------------------------------

************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
************************************************************************
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       2000, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* FM Name     : ZSD_U01217_POPULATE_VL06T        Create Date: 09/10/07 *
*                                                                      *
* SAP Name    : ZSD_U01217_POPULATE_VL06T        Version    :          *
*                                                                      *
* Programmer  : PRAGUPA                        Last Update: 09/10/07   *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
* This FM is executed in user exit EXIT_SAPLV50Q_001 which is          *
* used to list the screen fields available for Shipment Deliveries     *
* from Transaction Code  VL06T.                                        *
* It contains the ABAP code to populate the following fields           *
* Delivery Header : Production Order,Start date/time, End date/time    *
*                   FPED status                                        *
* Delivery Item   : Production Order,Start date/time, End date/time    *
*                   FPED status                                        *
*                                                                      *
* MENU PATH   :EXIT_SAPLV50Q_001/ZXV50QU01/ZZSD_DL_V2_FPED_CHANGES_INC/*
*                F.M.ZSD_U01217_POPULATE_VL06T/POPULATE_FIELD_VALUES   *
*                                                                      *
**********************************************************************-*
* Change History:                                                      *
* Programmer    Date      Corr #            Action                     *
* ==========  ========  ==========  ===================================*
* pragupa     11/28/2007 TPR 13650  for multiple items of different    *
*                        EDVK958908 statuses,header status is not      *
*                                   populated correctly                *
*                                                                      *
* wmitzne     02/28/2008 EDEK911357 logic for Subcontracting FPED      *
*                        EDEK911462   statuses SC2V SC2C in form       *
*                                     POPULATE_FIELD_VALUES            *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes:           none                                             *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Logical Databases : none                                             *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*                                                                      *
*______________________________________________________________________*

*Clear variables, structures,internal tables used in this FM
  PERFORM clear_variables.

*Get records from table  zppfped_status for all entries in et_postab
  PERFORM get_zppfped_status TABLES et_postab.

*Get records from table zppkiwifped for all entries in gt_zppfped_status
  CHECK gt_zppfped_status[] IS NOT INITIAL.
  PERFORM get_zppkiwifped.


*Get records from table zdl_fped_loc
  PERFORM get_plant_shipping_point.

*Get records from table zsp_value
  PERFORM get_zsp_value.

*Populate the Delivery Hdr and Itm values
  IF iv_flag_inbound IS INITIAL.                  "Outbound Deliveries
    PERFORM populate_field_values TABLES et_postab.
  ENDIF.



ENDFUNCTION.

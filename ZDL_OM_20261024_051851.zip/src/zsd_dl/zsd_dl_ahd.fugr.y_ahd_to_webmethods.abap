FUNCTION Y_AHD_TO_WEBMETHODS.
*"--------------------------------------------------------------------
*"*"Local interface:
*"       IMPORTING
*"             REFERENCE(GROUPNAME) TYPE  CHAR30
*"             REFERENCE(PRIORITY) TYPE  CHAR1
*"             REFERENCE(SEVERITY) TYPE  CHAR1 OPTIONAL
*"             REFERENCE(IDOCNUMBER) TYPE  CHAR16 OPTIONAL
*"             REFERENCE(RECEIVER) TYPE  CHAR10 OPTIONAL
*"             REFERENCE(SENDER) TYPE  CHAR10 OPTIONAL
*"             REFERENCE(SERIAL) TYPE  CHAR20 OPTIONAL
*"             REFERENCE(TEXT1) TYPE  CHAR50
*"             REFERENCE(TEXT2) TYPE  CHAR50 OPTIONAL
*"             REFERENCE(TEXT3) TYPE  CHAR50 OPTIONAL
*"             REFERENCE(TEXT4) TYPE  CHAR50 OPTIONAL
*"             REFERENCE(TEXT5) TYPE  CHAR50 OPTIONAL
*"             REFERENCE(TEXT6) TYPE  CHAR50 OPTIONAL
*"       EXPORTING
*"             REFERENCE(RETURN) TYPE  RFCTEST-RFCDATA1
*"--------------------------------------------------------------------





ENDFUNCTION.

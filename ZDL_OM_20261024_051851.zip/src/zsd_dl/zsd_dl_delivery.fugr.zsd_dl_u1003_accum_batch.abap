************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**            COPYRIGHT (C) 2003 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                      2003, 2005, 20nn                              **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Function Name: ZSD_DL_U1003_ACCUM_BATCH             Date: 12/18/2003 *
* Programmer  : Charles M. Ramey                                       *
*______________________________________________________________________*
* Description :                                                        *
* Function reads thru the XLIPS table that is input and finds all      *
* batches that correspond to the line number that is input, that are   *
* not flagged for deletion.  It then totals up the lineal feet and     *
* figures the total airdry percentage for the line item                *
*______________________________________________________________________*
* Change History:                                                      *
* MACARTE    02/22/05 v1w3 remove checks on batch flag PSTYV           *                                                                     *
*                             CR 3034                                  *
* MACARTE    03/28/05  added LIPS fields for MES weight                *
*                       did not change air dry % calculation           *
*                                                                      *
* BBALLEH    08/16/06  EDEK906139 for R8                               *
*                      Add logic for the accumulation of characteristcs*
*                      SCALED_WEIGHT_LBS & SCALED_WEIGHT_KG from LIPS  *
*                                                                      *
* JPIERI     04/05/2010 CR#10683 EDVK979845  Add logic to accumulate   *
*             values for characteristic SHEETS_PER_PACKAGING_UNIT      *
*______________________________________________________________________*

* start of cramey 12/18/2003

FUNCTION zsd_dl_u1003_accum_batch.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(I_VBELN) LIKE  LIPS-VBELN
*"     REFERENCE(I_POSNR) LIKE  LIPS-POSNR
*"  EXPORTING
*"     REFERENCE(I_RETURN_ZZAIRDRY) TYPE  ZZAIRDRY
*"     REFERENCE(I_RETURN_ZZLINFEET) TYPE  ZZLINFEET
*"     REFERENCE(I_RETURN_VRKME) TYPE  VRKME
*"     REFERENCE(I_RETURN_ZZROLLWGTM) TYPE  ZZROLLWEIGHTMETRIC
*"     REFERENCE(I_RETURN_ZZROLLWGTM_UNIT) TYPE
*"        ZZROLLWEIGHTMETRIC_UNIT
*"     REFERENCE(I_RETURN_ZZLINEARMETERS) TYPE  ZZLINEARMETERS
*"     REFERENCE(I_RETURN_ZZLINEAR_UNIT) TYPE  ZZLINEARMETERS_UNIT
*"     REFERENCE(I_RETURN_ZZROLLWEIGHTMES) TYPE  ZZROLLWEIGHTMES
*"     REFERENCE(I_RETURN_ZZROLLWEIGHTMES_UNIT) TYPE
*"        ZZROLLWEIGHTMES_UNIT
*"     REFERENCE(I_RETURN_ZZSCALEDWGT) TYPE  ZZSCALEDWEIGHTLB
*"     REFERENCE(I_RETURN_ZZSCALEDWGT_UOM) TYPE  ZZSCALEDWEIGHTLB_UOM
*"     REFERENCE(I_RETURN_ZZSCALEDWGTKG) TYPE  ZZSCALEDWEIGHTKG
*"     REFERENCE(I_RETURN_ZZSCALEDWGTKGUOM) TYPE  ZZSCALEDWEIGHTKG_UOM
*"     REFERENCE(I_RETURN_ZZMSHEETS) TYPE  ZZMSHEETS
*"     REFERENCE(I_RETURN_ZZMSHEETSUNIT) TYPE  ZZMSHEETS_UNIT
*"  TABLES
*"      XLIPS TYPE  SHP_VL10_LIPS_T
*"  EXCEPTIONS
*"      NO_DELIVERIES_TO_ACCUM
*"----------------------------------------------------------------------

  CONSTANTS: c_batches           TYPE pstyv VALUE 'ZBAT',
             c_delete(1)         TYPE c     VALUE 'D'.

  DATA: i_total_zzairdry      TYPE f,
        i_total_zzlinfeet     TYPE zzlinfeet,
        i_total_brgew         LIKE lips-brgew,
        i_total_meters        TYPE zzlinearmeters,
        i_total_wgt_metric    TYPE zzrollweightmetric,
        i_total_wgt_mes       TYPE zzrollweightmes,
        i_total_scaledwgt     TYPE zzscaledweightlb,        "EDEK906139
        i_total_zzmsheets     TYPE zzmsheets,        "CR#10683 EDVK979845
        i_total_zzmsheetsunit TYPE zzmsheets_unit,   "CR#10683 EDVK979845
        i_total_scaledwgtkg   TYPE zzscaledweightkg.        "EDEK906139

  CLEAR: i_total_zzairdry,
         i_total_zzlinfeet,
         i_total_brgew,
         i_return_zzairdry,
         i_return_zzlinfeet,
         i_return_zzrollweightmes,
         i_total_wgt_mes,
         i_total_scaledwgt,                                 "EDEK906139
         i_total_zzmsheets,     "CR#10683 EDVK979845
         i_total_zzmsheetsunit, "CR#10683 EDVK979845
         i_total_scaledwgtkg.                               "EDEK906139

  CLEAR sy-subrc.
  IF NOT xlips[] IS INITIAL.
    LOOP AT xlips
      WHERE vbeln =  i_vbeln
        AND uecha =  i_posnr
*        AND pstyv =  c_batches         "02/22/05
        AND updkz <> c_delete.
      IF NOT xlips-zzlinfeet IS INITIAL.
        i_total_zzlinfeet     = i_total_zzlinfeet + xlips-zzlinfeet.
        i_return_vrkme        = xlips-zzvrkme.
      ENDIF.
      IF NOT xlips-zzairdry IS INITIAL.
        i_total_brgew         = i_total_brgew     + xlips-brgew.
        i_total_zzairdry      = i_total_zzairdry  +
                                  ( xlips-brgew * xlips-zzairdry ).
      ENDIF.
      IF NOT xlips-zzrollwgtm IS INITIAL.
        i_total_wgt_metric      = i_total_wgt_metric + xlips-zzrollwgtm.
        i_return_zzrollwgtm_unit = xlips-zzrollwgtm_unit.
      ENDIF.
      IF NOT xlips-zzlinearmeters IS INITIAL.
        i_total_meters         = i_total_meters + xlips-zzlinearmeters.
        i_return_zzlinear_unit =  xlips-zzlinear_unit.
      ENDIF.
      IF NOT xlips-zzrollweightmes IS INITIAL.
        i_total_wgt_mes = i_total_wgt_mes + xlips-zzrollweightmes.
      ENDIF.
*--> Begin EDEK906139
*     Scaled Weight LBS
      IF NOT xlips-zzscaledwgt IS INITIAL.
        i_total_scaledwgt        = i_total_scaledwgt + xlips-zzscaledwgt.
        i_return_zzscaledwgt_uom = xlips-zzscaledwgt_uom.
      ENDIF.
*     Scaled Weight KG
      IF NOT xlips-zzscaledwgtkg IS INITIAL.
        i_total_scaledwgtkg       = i_total_scaledwgtkg + xlips-zzscaledwgtkg.
        i_return_zzscaledwgtkguom = xlips-zzscaledwgtkguom.
      ENDIF.
*--> End   EDEK906139
*--> Begin CR#10683 EDVK979845
      IF NOT xlips-zzmsheets IS INITIAL.
        i_total_zzmsheets = i_total_zzmsheets + xlips-zzmsheets.
      ENDIF.
*--> End CR#10683 EDVK979845
    ENDLOOP.
    i_return_zzlinfeet       = i_total_zzlinfeet.
    IF NOT i_total_brgew IS INITIAL.
      i_return_zzairdry        = i_total_zzairdry / i_total_brgew.
    ELSE.
      CLEAR i_return_zzairdry.
    ENDIF.
    i_return_zzrollwgtm      = i_total_wgt_metric.
    i_return_zzlinearmeters  = i_total_meters.
    i_return_zzrollweightmes = i_total_wgt_mes.
    i_return_zzrollweightmes_unit = xlips-zzrollwgtmesunit.
*--> Begin EDEK906139
    i_return_zzscaledwgt 	   = i_total_scaledwgt.
    i_return_zzscaledwgtkg    = i_total_scaledwgtkg.
*--> End   EDEK906139
    i_return_zzmsheets     = i_total_zzmsheets.  "CR#10683 EDVK979845
    i_return_zzmsheetsunit = 'MSH'.              "CR#10683 EDVK979845
  ELSE.
    RAISE no_deliveries_to_accum.
  ENDIF.

ENDFUNCTION.

*
*

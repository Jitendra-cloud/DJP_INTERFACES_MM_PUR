FUNCTION-POOL ZDL_U01217.                   "MESSAGE-ID ..


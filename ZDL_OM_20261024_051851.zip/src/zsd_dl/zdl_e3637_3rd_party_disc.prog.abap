************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2006 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           20xx                                     **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Fun. Name: ZDL_E3637_3RD_PARTY_DISC                 Date: 10/12/2006 *
*                                                                      *
* Programmer  : Savithri Renganathan                                   *
*______________________________________________________________________*
* Description :                                                        *
*   This is a discrepancy/confirmation report which should determine   *
* if PGI was executed for PGR.  It also lists all outbound deliveries  *
* with no Post Goods Issue.
*______________________________________________________________________*
* Change History:                                                      *
*                                                                      *
* Date       TPR #/Progr Ch#  Remarks                                  *
* 2018/04 Jacek Grabowiecki E0V CMS 33303 Changes for DLK delivery
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*                                                                      *
*   Programs        :                                                  *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   : TBD                                              *
*                                                                      *
*______________________________________________________________________*
************************************************************************


*&---------------------------------------------------------------------*
*& Report  ZDL_E3637_3RD_PARTY_DISC                                    *
*&                                                                     *
*&---------------------------------------------------------------------*
*&                                                                     *
*&                                                                     *
*&---------------------------------------------------------------------*

INCLUDE zdl_e3637_3rd_party_disc_top.
INCLUDE zdl_e3637_3rd_party_disc_f01.

AT SELECTION-SCREEN.
  REFRESH: gt_rep,      gt_so_p, gt_inb_dlvry,
           gt_fieldcat, gt_sort.

  CLEAR:   gs_rep,      gs_so_p, gs_inb_dlvry.

  PERFORM validation.

START-OF-SELECTION.
  PERFORM process.

END-OF-SELECTION.
  PERFORM output.

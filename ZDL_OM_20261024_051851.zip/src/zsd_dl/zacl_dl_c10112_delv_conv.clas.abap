*----------------------------------------------------------------------*
*       CLASS ZACL_DL_C10112_DELV_CONV DEFINITION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
class ZACL_DL_C10112_DELV_CONV definition
  public
  inheriting from CL_WD_COMPONENT_ASSISTANCE
  create public .

public section.

  types:
    ty_lfart TYPE RANGE OF lfart .
  types:
    ty_erdat TYPE RANGE OF erdat .
  types:
    ty_zzfrtfwd TYPE RANGE OF zzfrtfwd .
  types:
    ty_zzbooknum TYPE RANGE OF zzbooknum .
  types:
    ty_zzbookdoc TYPE RANGE OF z_bookdoc .
  types:
    ty_wbstk TYPE RANGE OF wbstk .
  types:
    BEGIN OF ty_likp_vbuk,
                vbeln  TYPE vbeln_vl,
                erdat  TYPE erdat,
                lfart  TYPE lfart,
                zzfrtfwd  TYPE zzfrtfwd,
                zzbooknum  TYPE zzbooknum,
                zzbookdoc  TYPE z_bookdoc,
                wbstk  TYPE wbstk,
                zzbookdoc_vbap  TYPE char15,
                read_only  TYPE char1,
              END OF ty_likp_vbuk .
  types:
    BEGIN OF ty_likp_selected,
          vbeln  TYPE vbeln_vl,
          zzbookdoc_vbap  TYPE z_bookdoc,
        END OF ty_likp_selected .
  types:
    ty_likp_selected_tab TYPE STANDARD TABLE OF ty_likp_selected .
  types:
    BEGIN OF ty_likp_saved,
         vbeln  TYPE vbeln_vl,
         zzbookdoc_vbap  TYPE z_bookdoc,
       END OF ty_likp_saved .
  types:
    ty_likp_saved_tab TYPE STANDARD TABLE OF ty_likp_saved .

  data:
    gt_likp_vbuk TYPE STANDARD TABLE OF ty_likp_vbuk .

  methods GET_DELIVERIES
    importing
      !GT_VBELN type RANGE_VBELN_VA_TAB
      !GT_LFART type TY_LFART optional
      !GT_ERDAT type TY_ERDAT optional
      !GT_ZZFRTFWD type TY_ZZFRTFWD optional
      !GT_ZZBOOKNUM type TY_ZZBOOKNUM optional
      !GT_ZZBOOKDOC type TY_ZZBOOKDOC optional
      !GT_WBSTK type TY_WBSTK optional .
  methods SAVE_DELIVERIES
    importing
      !IT_LIKP_SELECTED type TY_LIKP_SELECTED_TAB
    exporting
      !ET_LIKP_SAVED type TY_LIKP_SAVED_TAB .
protected section.
private section.
ENDCLASS.



CLASS ZACL_DL_C10112_DELV_CONV IMPLEMENTATION.


METHOD get_deliveries.

  TYPES:BEGIN OF ty_lips,
        vbeln TYPE vbeln_vl,
        posnr TYPE posnr_vl,
        vgtyp TYPE vgtyp,
        vgbel TYPE vgbel,
        vgpos TYPE vgpos,
        END OF ty_lips.

  DATA lt_lips TYPE STANDARD TABLE OF ty_lips.
  DATA ls_lips TYPE ty_lips.
  FIELD-SYMBOLS: <fs_likp_vbuk> TYPE ty_likp_vbuk.

  TYPES:BEGIN OF ty_ekko,
      ebeln TYPE ebeln,
      zzvbeln	TYPE zsde3483_vbeln,
      zzposnr	TYPE zsde3483_posnr,
      END OF ty_ekko.

  DATA ls_ekko TYPE ty_ekko.

  TYPES:BEGIN OF ty_ekkn,
        ebeln TYPE ebeln,
        vbeln	TYPE vbeln_co,
        vbelp	TYPE posnr_co,
        END OF ty_ekkn.

  DATA ls_ekkn TYPE ty_ekkn.

  SELECT a~vbeln a~erdat a~lfart a~zzfrtfwd a~zzbooknum a~zzbookdoc b~wbstk
         INTO TABLE gt_likp_vbuk
         FROM likp AS a INNER JOIN vbuk AS b
         ON a~vbeln EQ b~vbeln
         WHERE a~vbeln IN gt_vbeln AND
               a~erdat IN gt_erdat AND
               a~lfart IN gt_lfart AND
               b~wbstk IN gt_wbstk.


  IF gt_zzfrtfwd[] IS NOT INITIAL.
    DELETE gt_likp_vbuk WHERE zzfrtfwd NOT IN gt_zzfrtfwd[].
  ENDIF.

  IF gt_zzbooknum[] IS NOT INITIAL.
    DELETE gt_likp_vbuk WHERE zzbooknum NOT IN gt_zzbooknum[].
  ENDIF.

  IF gt_zzbookdoc[] IS NOT INITIAL.
    DELETE gt_likp_vbuk WHERE zzbookdoc NOT IN gt_zzbookdoc[].
  ENDIF.

  IF gt_likp_vbuk[] IS INITIAL.
    RETURN.
  ENDIF.

  SELECT vbeln posnr vgtyp vgbel vgpos
          INTO TABLE lt_lips
          FROM lips
          FOR ALL ENTRIES IN gt_likp_vbuk
          WHERE vbeln = gt_likp_vbuk-vbeln.

  SORT lt_lips BY vbeln posnr.

  DELETE ADJACENT DUPLICATES FROM lt_lips COMPARING vbeln.

  LOOP AT gt_likp_vbuk ASSIGNING <fs_likp_vbuk>.

* A. Booking already exists
    IF <fs_likp_vbuk>-zzbookdoc IS NOT INITIAL.
      <fs_likp_vbuk>-zzbookdoc_vbap = text-t01.
      CONTINUE.
    ENDIF.

* B. No delivery line exists
    READ TABLE lt_lips INTO ls_lips WITH KEY vbeln = <fs_likp_vbuk>-vbeln BINARY SEARCH.
    IF sy-subrc NE 0.
      <fs_likp_vbuk>-zzbookdoc_vbap = text-t02.
      CONTINUE.
    ENDIF.

* C. Ocean delivery doesn't have to updated
    IF ls_lips-vgtyp EQ 'C'.
      <fs_likp_vbuk>-zzbookdoc_vbap = text-t03.
      CONTINUE.
    ENDIF.

* D. Find non export replenishment STO using table EKKO
    SELECT SINGLE ebeln zzvbeln zzposnr FROM ekko
      INTO ls_ekko
      WHERE ebeln = ls_lips-vgbel.

    IF ls_ekko-zzvbeln IS NOT INITIAL AND
      ls_ekko-zzposnr IS NOT INITIAL.

      SELECT SINGLE zzbookdoc FROM vbap
        INTO <fs_likp_vbuk>-zzbookdoc_vbap
        WHERE vbeln = ls_ekko-zzvbeln AND
              posnr = ls_ekko-zzposnr.
      IF <fs_likp_vbuk>-zzbookdoc_vbap IS INITIAL.
        <fs_likp_vbuk>-zzbookdoc_vbap = text-t04.
      ENDIF.

      CONTINUE.
    ENDIF.

* E. Find non export replenishment STO using table EKKN
    SELECT SINGLE ebeln vbeln vbelp FROM ekkn
          INTO ls_ekkn
          WHERE ebeln = ls_lips-vgbel AND
                ebelp = ls_lips-vgpos.

    IF sy-subrc EQ 0.

      SELECT SINGLE zzbookdoc FROM vbap
        INTO <fs_likp_vbuk>-zzbookdoc_vbap
        WHERE vbeln = ls_ekkn-vbeln AND
              posnr = ls_ekkn-vbelp.
      IF <fs_likp_vbuk>-zzbookdoc_vbap IS INITIAL.
        <fs_likp_vbuk>-zzbookdoc_vbap = text-t04.
      ENDIF.
    ELSE.
      <fs_likp_vbuk>-zzbookdoc_vbap = text-t04.
    ENDIF.

  ENDLOOP.

ENDMETHOD.


METHOD save_deliveries.

  DATA ls_likp_selected LIKE LINE OF it_likp_selected.

  LOOP AT it_likp_selected INTO ls_likp_selected.

    UPDATE likp SET zzbookdoc = ls_likp_selected-zzbookdoc_vbap
           WHERE vbeln =  ls_likp_selected-vbeln.

  ENDLOOP.

  IF it_likp_selected[] IS NOT INITIAL.
    SELECT vbeln zzbookdoc FROM likp INTO TABLE et_likp_saved
      FOR ALL ENTRIES IN it_likp_selected
      WHERE vbeln EQ it_likp_selected-vbeln.
  ENDIF.

ENDMETHOD.
ENDCLASS.

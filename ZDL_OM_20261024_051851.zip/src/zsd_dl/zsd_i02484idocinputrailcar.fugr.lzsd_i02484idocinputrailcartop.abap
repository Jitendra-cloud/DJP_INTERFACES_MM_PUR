FUNCTION-POOL zsd_i02484idocinputrailcar MESSAGE-ID zsd_dl_i02484.


* Global data.
DATA:  gv_carrier TYPE lfa1-lifnr,           "Vendor
*       gv_tpp     type zsp_value-fieldvalue,               " <<RLW01-
       gv_tpp     TYPE tvkn-vstel,                          " <<RLW01+
       gv_point   TYPE tvkn-knote,           "Stage point
       gv_tz      TYPE adrc-time_zone,                      " <<RLW01+
       gv_splc    TYPE e1edt20-signi.                       " <<RLW01+

* Program (error) log
DATA: x_log     TYPE bal_s_msg,                             " <<RLW01+
      t_log     TYPE bal_s_msg OCCURS 0.                    " <<RLW01+

DATA: gv_flg_delete_fail,                                   " <<RLW01+
      gv_applog_ref TYPE symsgv.                            " <<RLW01+

* >> Begin of TPR# 00245 - CCHERUP - 10/30
DATA : gv_equip_id  TYPE /saprcx/equip_id.

CONSTANTS : gc_shtyp_zrli TYPE vttk-shtyp VALUE 'ZRLI'.
* << End of TPR# 00245 - CCHERUP - 10/30

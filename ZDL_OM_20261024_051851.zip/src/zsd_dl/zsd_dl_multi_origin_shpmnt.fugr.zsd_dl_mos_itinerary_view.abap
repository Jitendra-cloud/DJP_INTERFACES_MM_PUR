FUNCTION zsd_dl_mos_itinerary_view.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(I_TKNUM) TYPE  TKNUM OPTIONAL
*"  EXPORTING
*"     VALUE(E_MOS_IND) TYPE  ZSD_DL_MULTI_ORIGIN_SHPMNT_IND
*"  TABLES
*"      T_VTTK STRUCTURE  VTTK OPTIONAL
*"      T_VTTS STRUCTURE  VTTS OPTIONAL
*"      T_VTTP STRUCTURE  VTTP OPTIONAL
*"      T_VTSP STRUCTURE  VTSP OPTIONAL
*"      T_ITINERARY TYPE  ZMOS_ITINERARY_S OPTIONAL
*"  EXCEPTIONS
*"      INVALID_INPUT
*"      SHIPMENT_NOT_FOUND
*"      NO_DELIVERIES_FOUND
*"      NO_STAGES_ON_SHIPMENT
*"      NO_AUTHORITY
*"      DELIVERIES_UNASSIGNED_TO_STAGE
*"      FLEX_MULTI_ORIGIN_NOT_ALLOWED
*"----------------------------------------------------------------------
* This Function Module will get either TKNUM as import parameter or
* VTTS, VTTP structures as input. Irrespective of the input, this FM
* will return the Itinerary table and Multi Origin Indicator as output.
*"----------------------------------------------------------------------
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2007 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       2007, 2008, 20xx                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* Program Name: Create itinerary table           Create Date: 03/01/07 *
*                                                                      *
* SAP Name    : ZSD_DL_MOS_ITINERARY_VIEW        Version    :          *
*                                                                      *
* Programmer  : Chandra Cherupally               Last Update:          *
*______________________________________________________________________*
* Description :                                                        *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #          Action               *
* ==================  ========  ==========  ===========================*
* C. Cherupally       03/01/07  EDEK907395  Initial creation           *
*                                                                      *
* Anand V.            12/18/07  ESBK9A066A  Added 'dummy' deliveries   *
*                                           for 'FLEX' shipments       *
* PRAGUPA             06/18/2008 EDEK912214 V2 Rollback                *
* CCHERUP             03/30/2009 EDVK969874 TPR 30404 - TSNUM & TSRFO  *
*                                           out of sequence issue      *
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*                                                                      *
*                                                                      *
*                                                                      *
*                                                                      *
*                                                                      *
*   Transactions    :                                                  *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
  CONSTANTS: gc_flex LIKE vttk-sdabw VALUE 'FLEX'.

  IF NOT t_vttk[] IS INITIAL.
    READ TABLE t_vttk INDEX 1.
  ENDIF.

  IF t_vttk-sdabw <> gc_flex.
    IF i_tknum  IS INITIAL   AND
     ( t_vtts[] IS INITIAL OR
       t_vttp[] IS INITIAL OR
       t_vtsp[] IS INITIAL ).
      RAISE invalid_input.
    ENDIF.
  ENDIF.

  IF ( t_vtts[] IS INITIAL   AND
       t_vttp[] IS INITIAL   AND
       t_vtsp[] IS INITIAL ) AND
       i_tknum  IS NOT INITIAL.
* >> Get Shipment data based on TKNUM
    PERFORM get_shipment_data USING i_tknum.
  ELSE.
    gt_vtts[] = t_vtts[].
    gt_vttp[] = t_vttp[].
    gt_vtsp[] = t_vtsp[].
    gt_vttk[] = t_vttk[].
  ENDIF.

* Begin of V2 Rollback By PRAGUPA 06/18/2008 EDEK912214
*  READ TABLE gt_vttk INDEX 1.
*  IF gt_vttp[] IS INITIAL AND
*     gt_vtsp[] IS INITIAL AND
*     gt_vttk-sdabw = gc_flex.
*    PERFORM add_dummy_flex_deliveries TABLES gt_vtts gt_vttp gt_vtsp.
*    if gv_origin_stages > 1.
*      raise FLEX_MULTI_ORIGIN_NOT_ALLOWED.
*    endif.
*  ENDIF.
* End of V2 Rollback By PRAGUPA 06/18/2008 EDEK912214

  REFRESH : gt_stops,
            gt_itinerary,
            t_itinerary.
  CLEAR   : gt_stops,
            gt_itinerary,
            t_itinerary,
            e_mos_ind.

  DESCRIBE TABLE gt_vtts LINES gv_stage_count.
  IF gv_stage_count EQ 0.
    RAISE no_stages_on_shipment.
  ENDIF.

  DESCRIBE TABLE gt_vttp LINES gv_delv_count.
  IF gv_delv_count EQ 0.
    RAISE no_deliveries_found.
  ENDIF.

  IF gt_vtsp[] IS INITIAL.
    RAISE deliveries_unassigned_to_stage.
  ENDIF.

* >> Translating "Stages" to "Stops"
  PERFORM stage_to_stop_conversion.

* >> If the Stop data is not initial, segregate the stop data further
*    to get the Itinerary data along with deliveries, dates & times
*    for every stop on the shipment
  IF gt_stops[] IS NOT INITIAL.
    PERFORM fill_itineray_data.         " Itinerary data
    PERFORM fill_itineray_dates_times.  " Dates & Times
    PERFORM determine_mos_indicator.    " MOS Indicator
    t_itinerary[] = gt_itinerary[].
    e_mos_ind = gv_mos_ind.
  ENDIF.

ENDFUNCTION.

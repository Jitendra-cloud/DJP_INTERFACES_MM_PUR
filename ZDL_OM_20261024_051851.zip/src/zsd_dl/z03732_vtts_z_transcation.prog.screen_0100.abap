
  PROCESS BEFORE OUTPUT.
    MODULE status_0100.
*
  PROCESS AFTER INPUT.
    MODULE exit_0100 AT EXIT-COMMAND.

* validations
    CHAIN .
      FIELD vttk-tknum.
      MODULE status_0100.
    ENDCHAIN.

* help for shipment number
  PROCESS ON VALUE-REQUEST.
    FIELD vttk-tknum  MODULE tknum_values.


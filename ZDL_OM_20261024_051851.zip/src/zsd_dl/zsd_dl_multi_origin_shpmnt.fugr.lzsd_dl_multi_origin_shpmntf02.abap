*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_MULTI_ORIGIN_SHPMNTF02 .
*----------------------------------------------------------------------*
*----------------------------------------------------------------------*
*       Form  get_deliveries
*----------------------------------------------------------------------*
* This form gets the deliveries associated to the shipment(s) for
* further processing based on user entered Shipment(s)
*----------------------------------------------------------------------*
FORM get_deliveries TABLES it_shipments STRUCTURE gs_shipments.

* Based on the assumption that the deliveries can be assigned to a
* shipment without having stages on the Shipment
  SELECT tknum tpnum vbeln
         INTO TABLE gt_vbeln
         FROM vttp
         FOR ALL ENTRIES IN it_shipments
         WHERE tknum EQ it_shipments-tknum.
  IF sy-subrc EQ 0.
    SORT gt_vbeln BY vbeln.   " Used for all entries to get Deliveries
  ELSE.
    RAISE no_deliveries_found.
  ENDIF.

ENDFORM.                    " get_deliveries
*----------------------------------------------------------------------*
*       Form  get_delivery_data
*----------------------------------------------------------------------*
* This form gets all the Delivery related data for further processing
* based on the Delivery Numbers
*----------------------------------------------------------------------*
FORM get_delivery_data .

* Getting Delivery data from LIPS
  SELECT vbeln posnr matnr matkl werks charg lfimg meins vrkme
         ntgew brgew gewei uebto untto vgbel vgpos spart vgtyp
         uecha cuobj
         INTO TABLE gt_delv_data
         FROM lips
         FOR ALL ENTRIES IN gt_vbeln
         WHERE vbeln = gt_vbeln-vbeln.
  IF sy-subrc EQ 0.
    SORT gt_delv_data BY vbeln posnr.
  ELSE.
    RAISE no_delivery_data_found.
  ENDIF.

ENDFORM.                    " get_delivery_data
*----------------------------------------------------------------------*
*       Form  determine_mto_mts
*----------------------------------------------------------------------*
* This form determines whether the delivery is MTS or MTO related
* and further calculates the No. of Units, Packages, Units/Package,
* Volume and Tolerances
*----------------------------------------------------------------------*
FORM determine_mto_mts .

  REFRESH gt_item_data.
  SORT gt_delv_data BY vbeln uecha.
  gt_item_data[] = gt_delv_data[].

  PERFORM get_batch_char_atinn.

  PERFORM get_plants_zdl_fields.                            "CMS31694

  LOOP AT gt_delv_data WHERE uecha IS INITIAL.
    PERFORM refresh_variables.

    PERFORM get_plant_specific_char USING gt_delv_data-werks. "CMS31694

    IF gt_delv_data-spart EQ '13'.
      PERFORM v2_data_determination.
    ELSE.
      CLEAR gt_marc_vc_char.
      READ TABLE gt_marc_vc_char WITH KEY werks = gt_delv_data-werks
                                          matnr = gt_delv_data-matnr
                                          BINARY SEARCH.
      IF sy-subrc EQ 0.
        CLEAR gs_conf_out.
        READ TABLE gt_marc_vc_char-confout INTO gs_conf_out
                                 WITH KEY atnam = zsdc_stock_indicator
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          PERFORM get_vbap_cuobj_zzwgtroll.
          IF gv_lips_cuobj IS NOT INITIAL.
            PERFORM get_vc_data  TABLES gt_conf_out
                                  USING gv_lips_cuobj.
          ENDIF.
          IF gs_conf_out-atwrt EQ 'M'.        " M T O
            PERFORM mto_data_determination.
            gv_mto_mts = 'MTO'.               " CR8056/TPR25002
          ELSEIF gs_conf_out-atwrt EQ 'S'.    " M T S
            PERFORM mts_data_determination.
            gv_mto_mts = 'MTS'.               " CR8056/TPR25002
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
    PERFORM get_reqd_batch_char_atinn.
    PERFORM get_additional_data.
    PERFORM get_sales_tolerances.  " CR8056/TPR25002
    PERFORM append_data.
    APPEND LINES OF gt_batch_char TO gt_delv_batch_char.
  ENDLOOP.

ENDFORM.                    " determine_mto_mts
*----------------------------------------------------------------------*
*       Form  append_data
*----------------------------------------------------------------------*
* This form appends the data to output table
*----------------------------------------------------------------------*
FORM append_data.
* >> Begin insert by pwadehr - CMS#33577
  DATA : lt_rf_shiptypes     TYPE RANGE OF shtyp,
         lv_shtyp            TYPE vttk-shtyp,
         lv_likp_zz_bale_cnt LIKE likp-zz_bale_cnt.
* >> End insert by pwadehr - CMS#33577

  CLEAR gt_delv_item_units.
  gt_delv_item_units-vbeln = gt_delv_data-vbeln.      " Delivery #
  gt_delv_item_units-posnr = gt_delv_data-posnr.      " Item #
  gt_delv_item_units-matnr = gt_delv_data-matnr.      " Material #
*  IF gv_no_packages LE 0.                                   " CC03
*    gv_no_packages = 1.                                     " CC03
*  ENDIF.                                                    " CC03
  gt_delv_item_units-packages = gv_no_packages.       " # Packages
*  IF gv_no_units LE 0.                                      " CC03
*    gv_no_units = 1.                                        " CC03
*  ENDIF.                                                    " CC03
  gt_delv_item_units-units = gv_no_units.             " # Units
* >> Begin of V4W2 Changes - CCHERUP - (Sheeting Product)
  IF gv_uom EQ 'KAR'. " Carton
    gv_uom = 'PL'.
  ENDIF.
* << End of V4W2 Changes
  gt_delv_item_units-uom   = gv_uom.                  " # UoM
  gt_delv_item_units-units_package = gv_units_package." # Units in Pckg
  gt_delv_item_units-ntgew = gv_net_weight.           " Net Weight
  gt_delv_item_units-brgew = gv_gross_weight.         " Gross Weight
  gt_delv_item_units-gewei = gt_delv_data-gewei.      " Weight Unit
  gt_delv_item_units-volume = gv_volume.              " Volume
  gt_delv_item_units-voluom = gv_voluom.              " M3 = U-O-M
  gt_delv_item_units-uebto = gv_uebto.                " Tol. Over  %
  gt_delv_item_units-untto = gv_untto.                " Tol. Under %
  gt_delv_item_units-uebqty = gv_uebqty.              " Tol. Over  Limit
  gt_delv_item_units-untqty = gv_untqty.              " Tol. Under Limit
* >> Begin of change - CCHERUP - CR8056/TPR25002
  gt_delv_item_units-sales_uebqty = gv_sales_uebqty.
  gt_delv_item_units-sales_untqty = gv_sales_untqty.
  gt_delv_item_units-sales_tol_uom = gv_sales_tol_uom.
* << End of change - CCHERUP - CR8056/TPR25002
  gt_delv_item_units-vc_char[] = gt_conf_out[].       " VC Char Data
  gt_delv_item_units-batch_char[] = gt_batch_char[].  " Batch Char data
  READ TABLE gt_vbeln WITH KEY vbeln = gt_delv_data-vbeln.
  IF sy-subrc EQ 0 AND gt_vbeln-tknum IS NOT INITIAL.
    gt_delv_item_units-tknum = gt_vbeln-tknum.        " Shipment #
  ENDIF.
* >> Begin insert by pwadehr - CMS#33577
  SELECT   'I'    AS sign,
           'EQ'   AS option,
           lowval AS low,
           '  '   AS high
                  FROM zdl_fields
                  INTO TABLE @lt_rf_shiptypes
                  WHERE category   = 'ITP_LOAD'
                  AND   fieldname  = 'SHTYP'.
  SELECT SINGLE shtyp
    INTO lv_shtyp
      FROM vttk
        WHERE tknum = gt_vbeln-tknum.
  IF NOT lt_rf_shiptypes[] IS INITIAL.
    IF lv_shtyp IN lt_rf_shiptypes.
      SELECT SINGLE zz_bale_cnt
             FROM   likp
             INTO   lv_likp_zz_bale_cnt
             WHERE  vbeln EQ gt_delv_data-vbeln.
      gt_delv_item_units-packages = lv_likp_zz_bale_cnt.
      gt_delv_item_units-units = lv_likp_zz_bale_cnt.
      IF lv_likp_zz_bale_cnt > 0.
        gt_delv_item_units-uom = 'BA'.
      ENDIF.
      gt_delv_item_units-ntgew = gt_delv_data-ntgew.
      gt_delv_item_units-brgew = gt_delv_data-brgew.
    ENDIF.
  ENDIF.
* >> END of insert by pwadehr - CMS#33577
  APPEND gt_delv_item_units.

ENDFORM. "append_data
*----------------------------------------------------------------------*
*       Form  mto_data_determination
*----------------------------------------------------------------------*
* This form determines data for MTO material
*----------------------------------------------------------------------*
FORM mto_data_determination.

*  if gv_lips_cuobj is not initial.
*    refresh gt_conf_out.
*    perform get_vbap_vc_data.                   " VC Char Data - VBAP
  PERFORM mto_tol_over_percent.               " Tol. Over  %
  PERFORM mto_tol_under_percent.              " Tol. Under %
  PERFORM get_net_gross_weight.               " Net & Gross Weight
  PERFORM mto_unit_of_measure.
* If Not Packed
  IF gv_packed IS INITIAL.
    PERFORM mto_units_package.          " # units in Pckg
    PERFORM mto_no_units.               " # units
*** code added by cramey for MTO partial skids
*    if gv_uom = 'SKD'.
*       gv_no_packages = CEIL( gv_no_units / gv_units_package ).
*    else.
*    IF gv_uom EQ 'RL' AND gv_units_package GT 1.            " CC03
*      gv_no_packages = CEIL( gv_no_units / gv_units_package )." CC03
*    ELSE.                                                   " CC03
    gv_no_packages = floor( gv_no_units / gv_units_package + 1 / 2 ).
*    ENDIF.                                                  " CC03
*    endif.
**** end of MTO Partial Skids change
    " # Packages
    IF gv_no_packages LE 0.
      gv_no_packages = 1.
    ENDIF.
* If Packed
  ELSE.
    PERFORM get_vbfa_hu_count.                " # Packages
    PERFORM get_vbfa_row_count.               " # units
    IF gv_no_packages LE 0.
      gv_no_packages = 1.
    ENDIF.
    gv_units_package = floor( gv_no_units / gv_no_packages + 1 / 2 ).
    " # units in pckg
    IF gv_units_package LE 0.
      gv_units_package = 1.
    ENDIF.
  ENDIF.
  PERFORM tol_over_under_limit.            " Tol. Over & Under Limit
*  endif.

ENDFORM. "mto_data_determination
*----------------------------------------------------------------------*
*       Form  mto_unit_of_measure
*----------------------------------------------------------------------*
* This form determines Unit of measure for MTO material
*----------------------------------------------------------------------*
FORM mto_unit_of_measure .

  READ TABLE gt_conf_out WITH KEY atnam = zsdc_unit_code
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    CASE gt_conf_out-atwrt.
      WHEN 'R'.
        gv_uom = 'RL'.
      WHEN 'B'.
        gv_uom = 'BA'.
* >> Begin of V4W2 Changes - CCHERUP - (Sheeting Product)
      WHEN 'C' OR 'D'.
        gv_uom = 'KAR'. " Carton
      WHEN 'S'.
        gv_uom = 'SKD'.
* << End of V4W2 Changes
      WHEN OTHERS.
    ENDCASE.
  ENDIF.

ENDFORM. "mto_unit_of_measure
*----------------------------------------------------------------------*
*       Form  mts_data_determination
*----------------------------------------------------------------------*
* This form determines data for MTS material
*----------------------------------------------------------------------*
FORM mts_data_determination.

  DATA : lt_supply_driven    LIKE zdl_supply_drivn
                               OCCURS 0 WITH HEADER LINE,
         lv_rfc_call_success.

  CLEAR lv_rfc_call_success.

  PERFORM mts_tol_over_under_percent.           " Tol. Over & Under %
  PERFORM get_net_gross_weight.                 " Net & Gross Weight
  PERFORM mts_units_package.
* If Not Packed
  IF gv_packed IS INITIAL.
    IF gt_delv_data-ntgew IS INITIAL.
      gv_no_units = gv_batch_line_count.
    ELSE.
      SELECT *
             FROM  zdl_supply_drivn
             INTO  TABLE lt_supply_driven
             WHERE locno EQ gt_delv_data-werks AND
*                   matkl EQ gt_delv_data-matkl.
* mbruno 8/14/14 cms 27202 - also include supply_driven in selection
                    matkl EQ gt_delv_data-matkl AND
                    z_supply_driven = 'Y'.
* MBRUNO 8/14/14 CMS 27202 - END.
      IF sy-subrc EQ 0.
* Make an RFC call to APO to get Guidance data only when Shipment number
* is passed
        IF gt_shipment_no[] IS NOT INITIAL.
          PERFORM rfc_function_call.
          READ TABLE gt_delivery_roll WITH KEY
                                     delivery      = gt_delv_data-vbeln
                                     delivery_item = gt_delv_data-posnr
                                      ASSIGNING <ls_delivery>
                                      BINARY SEARCH.
          IF sy-subrc EQ 0.
            lv_rfc_call_success = 'X'.
            gv_no_units  = <ls_delivery>-num_rolls.
          ENDIF.
        ENDIF.
* If RFC call did not go thru, proceed with determining the Units
        IF lv_rfc_call_success NE 'X'.
          PERFORM mts_no_units.
        ENDIF.
      ELSE.
        PERFORM mts_no_units.
      ENDIF.
    ENDIF.
    IF gv_units_package LE 0.
      gv_units_package = 1.
    ENDIF.
*    IF gv_uom EQ 'RL' AND gv_units_package GT 1.            " CC03
*      gv_no_packages = CEIL( gv_no_units / gv_units_package )." CC03
*    ELSE.                                                   " CC03
    gv_no_packages = floor( gv_no_units / gv_units_package + 1 / 2 ).
*    ENDIF.
    IF gv_no_packages LE 0.                                 " CC03
      gv_no_packages = 1.                                   " CC03
    ENDIF.                                                  " CC03
* If Packed
  ELSE.
    PERFORM get_vbfa_hu_count.                  " # Packages
    PERFORM get_vbfa_row_count.                 " # units
    IF gv_no_packages LE 0.
      gv_no_packages = 1.
    ENDIF.
    gv_units_package = floor( gv_no_units / gv_no_packages + 1 / 2 ).
    " # units in pckg
  ENDIF.
  PERFORM tol_over_under_limit.             " Tol. Over & Under Limit

ENDFORM. "mts_data_determination

*----------------------------------------------------------------------*
*       Form  get_net_gross_weight
*----------------------------------------------------------------------*
* This form determines Net Weight & Gross Weight
*----------------------------------------------------------------------*
FORM get_net_gross_weight.

  REFRESH : gr_batch_posnr.
  CLEAR   : gv_net_weight, gv_gross_weight, gv_batch_line_count,
            gr_batch_posnr, gv_packed.

  gv_packed = 'X'.
  gv_net_weight   = gt_delv_data-ntgew.
  gv_gross_weight = gt_delv_data-brgew.

  gr_batch_posnr-sign = 'I'.
  gr_batch_posnr-option = 'EQ'.

* For Batch split items
  READ TABLE gt_item_data WITH KEY vbeln = gt_delv_data-vbeln
                                   uecha = gt_delv_data-posnr
                          BINARY SEARCH.
  IF sy-subrc EQ 0.
    LOOP AT gt_item_data FROM sy-tabix.
      IF gt_item_data-uecha NE gt_delv_data-posnr.
        EXIT.
      ENDIF.
      ADD 1 TO gv_batch_line_count.
      READ TABLE gt_vbup WITH KEY vbeln = gt_delv_data-vbeln
                                  posnr = gt_item_data-posnr.
      IF sy-subrc EQ 0.
*      IF gt_vbup-kosta EQ 'C'.
        gv_net_weight   = gv_net_weight   + gt_item_data-ntgew.
        gv_gross_weight = gv_gross_weight + gt_item_data-brgew.
*      ENDIF.
        IF gt_delv_data-ntgew IS INITIAL. " New changes
          IF gt_vbup-pksta NE 'C'.
            CLEAR gv_packed.
          ENDIF.
        ELSE.
          CLEAR gv_packed.
        ENDIF.
      ENDIF.
      gr_batch_posnr-low = gt_item_data-posnr.
      APPEND gr_batch_posnr.
    ENDLOOP.
  ELSE.
* For Non-Batch split items
    READ TABLE gt_vbup WITH KEY vbeln = gt_delv_data-vbeln
                                posnr = gt_delv_data-posnr.
    IF sy-subrc EQ 0.
      IF gt_vbup-pksta NE 'C'.
        CLEAR gv_packed.
      ELSEIF gt_vbup-pksta EQ 'C'.
        gr_batch_posnr-low = gt_delv_data-posnr.
        APPEND gr_batch_posnr.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM. "get_net_gross_weight
*----------------------------------------------------------------------*
*       Form  get_vbfa_hu_count
*----------------------------------------------------------------------*
* This form gets Handling Unit count from VBFA in order to determine
* # Packages
*----------------------------------------------------------------------*
FORM get_vbfa_hu_count.

  DATA :  lv_vbfa_hu_count     TYPE    i.

  SELECT COUNT( DISTINCT vbeln )
         INTO  lv_vbfa_hu_count
         FROM  vbfa
         WHERE vbelv EQ gt_delv_data-vbeln AND
               posnv IN gr_batch_posnr AND
               vbtyp_n EQ 'X'.
  IF sy-subrc EQ 0.
    gv_no_packages = lv_vbfa_hu_count.
  ENDIF.

ENDFORM. "get_vbfa_hu_count
*----------------------------------------------------------------------*
*       Form  get_vbfa_row_count
*----------------------------------------------------------------------*
* This form gets the Row count from VBFA in order to determine Units #
*----------------------------------------------------------------------*
FORM get_vbfa_row_count.

  DATA :  lv_vbfa_row_count    TYPE    i.

  SELECT COUNT( * )
         INTO lv_vbfa_row_count
         FROM vbfa
         WHERE vbelv EQ gt_delv_data-vbeln AND
               posnv IN gr_batch_posnr AND
               vbtyp_n EQ 'X'.
  IF sy-subrc EQ 0.
    gv_no_units = lv_vbfa_row_count.
  ENDIF.

ENDFORM. "get_vbfa_row_count

*----------------------------------------------------------------------*
*       Form  mto_tol_over_percent
*----------------------------------------------------------------------*
* This form determines Tolerance Over Percent for MTO material
*----------------------------------------------------------------------*
FORM mto_tol_over_percent.

  READ TABLE gt_conf_out WITH KEY atnam = zsdc_tol_over_percent
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    gv_uebto = gt_conf_out-atwrt.
  ELSEIF gt_delv_data-uebto IS NOT INITIAL.
    gv_uebto = gt_delv_data-uebto.
  ELSE.
    SELECT SINGLE uebto
           INTO   gv_uebto
           FROM   knvv AS knvv
           INNER JOIN vbak AS vbak
           ON knvv~kunnr = vbak~kunnr AND
              knvv~vkorg = vbak~vkorg AND
              knvv~vtweg = vbak~vtweg AND
              knvv~spart = vbak~spart
        WHERE vbak~vbeln EQ gv_order.
  ENDIF.

ENDFORM. "mto_tol_over_percent
*----------------------------------------------------------------------*
*       Form  tol_over_under_limit
*----------------------------------------------------------------------*
* This form determines Tolerance Over Under Limit for both MTO  & MTS
* material
*----------------------------------------------------------------------*
FORM tol_over_under_limit.

  gv_uebqty = gv_net_weight * ( 100 + gv_uebto ) / 100.
  gv_untqty = gv_net_weight * ( 100 - gv_untto ) / 100.

ENDFORM. "tol_over_under_limit
*----------------------------------------------------------------------*
*       Form  mto_tol_under_percent
*----------------------------------------------------------------------*
* This form determines Tolerance Under percent for MTO material
*----------------------------------------------------------------------*
FORM mto_tol_under_percent.

  READ TABLE gt_conf_out WITH KEY atnam = zsdc_tol_under_percent
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    gv_untto = gt_conf_out-atwrt.
  ELSEIF gt_delv_data-untto IS NOT INITIAL.
    gv_untto = gt_delv_data-untto.
  ELSE.
    SELECT SINGLE untto
           INTO   gv_untto
           FROM   knvv AS knvv
           INNER JOIN vbak AS vbak
           ON knvv~kunnr = vbak~kunnr AND
              knvv~vkorg = vbak~vkorg AND
              knvv~vtweg = vbak~vtweg AND
              knvv~spart = vbak~spart
        WHERE vbak~vbeln EQ gv_order.
  ENDIF.

ENDFORM. "mto_tol_under_percent
*----------------------------------------------------------------------*
*       Form  mts_tol_over_under_percent
*----------------------------------------------------------------------*
* This form determines Tolerance Over & Under percent for MTS material
*----------------------------------------------------------------------*
FORM mts_tol_over_under_percent.

  DATA : BEGIN OF lt_percent_value OCCURS 0,
           fieldname  TYPE  zsp_fieldname,
           fieldvalue TYPE  zsp_fieldvalue,
         END OF lt_percent_value.

  SELECT fieldname fieldvalue
         FROM zsp_value
         INTO TABLE lt_percent_value
         WHERE pgrmid EQ 'ZSD_DL_I02419_SHIP_DELIV_INTER'.
  IF sy-subrc NE 0.
    SELECT fieldname fieldvalue
           FROM zsp_value
           INTO TABLE lt_percent_value
           WHERE pgrmid EQ 'ZSD_DL_I02249_SHIP_DELIV_INTER'.
  ENDIF.

  IF lt_percent_value[] IS NOT INITIAL.
    SORT lt_percent_value BY fieldname.
    READ TABLE lt_percent_value WITH KEY
                                fieldname = 'OVER_TOLERANCE'
                                BINARY SEARCH.
    IF sy-subrc EQ 0.
      gv_uebto = lt_percent_value-fieldvalue.
    ENDIF.
    READ TABLE lt_percent_value WITH KEY
                                fieldname = 'UNDER_TOLERANCE'
                                BINARY SEARCH.
    IF sy-subrc EQ 0.
      gv_untto = lt_percent_value-fieldvalue.
    ENDIF.
  ELSE.
    CLEAR : gv_uebto, gv_untto.
  ENDIF.

ENDFORM. "mts_tol_over_under_percent
*----------------------------------------------------------------------*
*       Form  mto_no_units
*----------------------------------------------------------------------*
* This form determines No. of Units for MTO material
*----------------------------------------------------------------------*
FORM mto_no_units.

  IF gt_delv_data-ntgew IS INITIAL.
    gv_no_units = gv_batch_line_count.
  ELSE.
    CLEAR gt_conf_out.
*   READ TABLE gt_conf_out WITH KEY atnam = zsdc_unit_weight "CMS31694
    READ TABLE gt_conf_out WITH KEY atnam = gv_unit_weight  "CMS31694
                                 BINARY SEARCH.
    IF sy-subrc EQ 0.
      IF gt_conf_out-atwrt IS INITIAL.
        gt_conf_out-atwrt = 1.
      ELSE.
        REPLACE ',' WITH space INTO gt_conf_out-atwrt.
        IF sy-subrc EQ 0.
          CONDENSE gt_conf_out-atwrt NO-GAPS.
        ELSEIF gt_conf_out-atwrt LT 0.
          gt_conf_out-atwrt = 1.
        ENDIF.
      ENDIF.
    ELSE.
      gt_conf_out-atwrt = 1.
    ENDIF.
*    gv_no_units = FLOOR( gv_net_weight / gt_conf_out-atwrt +
*                          1 / 2 ).
*** code added by cramey for MTO partial skids
    IF gv_uom = 'SKD'.
      gv_no_units = ceil( gv_net_weight / gt_conf_out-atwrt ).
    ELSE.
      gv_no_units = floor( gv_net_weight / gt_conf_out-atwrt
                       + 1 / 2 ).
    ENDIF.
**** end of MTO Partial Skids change

  ENDIF.

  IF gv_no_units LE 0.
    gv_no_units = 1.
  ENDIF.

ENDFORM. "mto_no_units

*----------------------------------------------------------------------*
*       Form  mto_units_package
*----------------------------------------------------------------------*
* This form determines Units & Packages for MTO material
*----------------------------------------------------------------------*
FORM mto_units_package.

  READ TABLE gt_conf_out WITH KEY atnam = zsdc_unit_code
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    CASE gt_conf_out-atwrt.
      WHEN 'R'.
        CLEAR gt_conf_out.
        READ TABLE gt_conf_out WITH KEY atnam = zsdc_rolls_in_package
                                        BINARY SEARCH.
        IF sy-subrc EQ 0 AND gt_conf_out-atwrt IS NOT INITIAL.
          gv_units_package = gt_conf_out-atwrt.
        ELSE.
          gv_units_package = 1.
        ENDIF.
      WHEN 'B'.
        CLEAR gt_conf_out.
        READ TABLE gt_conf_out WITH KEY atnam = zsdc_bales_per_unit
                                        BINARY SEARCH.
        IF sy-subrc EQ 0 AND gt_conf_out-atwrt IS NOT INITIAL.
          gv_units_package = gt_conf_out-atwrt.
        ELSE.
          gv_units_package = 1.
        ENDIF.
* >> Begin of V4W2 Changes - CCHERUP - (Sheeting Product)
      WHEN 'C' OR 'D'.
        CLEAR gt_conf_out.
        READ TABLE gt_conf_out WITH KEY atnam = zsdc_cartons_per_pallet
                                        BINARY SEARCH.
        IF sy-subrc EQ 0.
          IF gt_conf_out-atwrt IS NOT INITIAL.
            gv_units_package = gt_conf_out-atwrt.
          ELSE.
            gv_units_package = 1.
          ENDIF.
        ELSE.
          gv_units_package = 1.
        ENDIF.
      WHEN 'S'.
        gv_units_package = 1.
      WHEN OTHERS.
        gv_units_package = 1.
* << End of V4W2 Changes

    ENDCASE.
  ELSE.
    gv_units_package = 1.  " Contact Laxmana
  ENDIF.

  IF gv_units_package LE 0.
    gv_units_package = 1.
  ENDIF.

ENDFORM. "mto_units_package
*----------------------------------------------------------------------*
*       Form  get_vbap_cuobj_zzwgtroll
*----------------------------------------------------------------------*
* This form determines CUOBJ & ZZWGTROLL from VBAP table
*----------------------------------------------------------------------*
FORM get_vbap_cuobj_zzwgtroll.

  DATA : lv_vbeln TYPE    vbeln,
         lv_vbelp TYPE    vbelp.

  CASE gt_delv_data-vgtyp.
    WHEN 'C'.                                               "TPR 20363
*  IF gt_delv_data-vgtyp EQ 'C'.  "TPR 20363
      gv_order      = gt_delv_data-vgbel.
      gv_lips_cuobj = gt_delv_data-cuobj.     " LIPS-CUOBJ
      SELECT SINGLE zz_wgt_roll
             INTO   gv_zzwgt_roll
             FROM   vbap
             WHERE  vbeln EQ gt_delv_data-vgbel AND
                    posnr EQ gt_delv_data-vgpos.
*  ELSEIF gt_delv_data-vgtyp EQ 'V'.   "TPR 20363
    WHEN 'V'.                                               "TPR 20363
      gv_lips_cuobj = gt_delv_data-cuobj.     " LIPS-CUOBJ
      SELECT SINGLE vbeln vbelp
             INTO   (lv_vbeln, lv_vbelp)
             FROM   ekkn
             WHERE  ebeln EQ gt_delv_data-vgbel AND
                    ebelp EQ gt_delv_data-vgpos.
      IF sy-subrc EQ 0.
        gv_order = lv_vbeln.
        SELECT SINGLE zz_wgt_roll
               INTO   gv_zzwgt_roll
               FROM   vbap
               WHERE  vbeln EQ lv_vbeln AND
                      posnr EQ lv_vbelp.
        IF sy-subrc NE 0.
          CLEAR gv_zzwgt_roll.
        ENDIF.
      ENDIF.
    WHEN OTHERS.                                            "TPR 20363
* TPR 20363, when the Item Category is not C or V, we
* still need to get the VC char. similar to how we are
* getting it for 'C' (Sales order).
      gv_order      = gt_delv_data-vgbel.
      gv_lips_cuobj = gt_delv_data-cuobj.     " LIPS-CUOBJ
      SELECT SINGLE zz_wgt_roll
             INTO   gv_zzwgt_roll
             FROM   vbap
             WHERE  vbeln EQ gt_delv_data-vgbel AND
                    posnr EQ gt_delv_data-vgpos.
*  ENDIF.
  ENDCASE.

ENDFORM. "get_vbap_cuobj_zzwgtroll

*----------------------------------------------------------------------*
*       Form  get_vc_data
*----------------------------------------------------------------------*
* This form determines VC data
*----------------------------------------------------------------------*
FORM get_vc_data  TABLES gt_conf_out STRUCTURE conf_out
                   USING cuobj.

  REFRESH gt_conf_out.
  CLEAR   gt_conf_out.

  CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
    EXPORTING
      instance            = cuobj
      language            = sy-langu
      iv_invalid_possible = ' '
      iv_neutral          = 'X'
    TABLES
      configuration       = gt_conf_out
    EXCEPTIONS
      instance_not_found  = 1
      OTHERS              = 2.
  IF sy-subrc EQ 0.
    SORT gt_conf_out BY atnam.
  ENDIF.

ENDFORM.                    "get_vc_data
*----------------------------------------------------------------------*
*       Form  get_marc_vc_data
*----------------------------------------------------------------------*
* This form gets VC data based on MARC-CUOBJ
*----------------------------------------------------------------------*
FORM get_marc_vc_data .

  TYPES : BEGIN OF tt_matnr_werks,
            matnr TYPE matnr,
            werks TYPE werks_d,
          END   OF tt_matnr_werks.
  DATA  : lt_matnr_werks TYPE SORTED TABLE OF tt_matnr_werks
                         WITH UNIQUE KEY matnr werks,
          ls_matnr_werks TYPE tt_matnr_werks.

  REFRESH : gt_marc_cuobj, lt_matnr_werks.

* Getting MARC-CUOBJ to extract VC data
  SELECT matnr werks sobsl cuobj
         FROM marc
         INTO TABLE gt_marc_cuobj
         FOR ALL ENTRIES IN gt_delv_data
         WHERE matnr EQ gt_delv_data-matnr AND
               werks EQ gt_delv_data-werks.
  IF sy-subrc EQ 0.
    SORT gt_marc_cuobj BY matnr werks.
  ENDIF.

* Populating VC data based on MARC-CUOBJ
  LOOP AT gt_delv_data.
    CLEAR gt_marc_vc_char.
    READ TABLE lt_matnr_werks INTO ls_matnr_werks
                              WITH KEY matnr = gt_delv_data-matnr
                                       werks = gt_delv_data-werks.
    IF sy-subrc NE 0.
      CLEAR gt_marc_cuobj.
      READ TABLE gt_marc_cuobj WITH KEY matnr = gt_delv_data-matnr
                                        werks = gt_delv_data-werks
                                        BINARY SEARCH.
      IF sy-subrc EQ 0 AND gt_marc_cuobj-cuobj IS NOT INITIAL.
        PERFORM get_vc_data TABLES gt_conf_out
                             USING gt_marc_cuobj-cuobj.
        IF gt_conf_out[] IS NOT INITIAL.
          gt_marc_vc_char-werks = gt_delv_data-werks.
          gt_marc_vc_char-matnr = gt_delv_data-matnr.
          gt_marc_vc_char-confout[] = gt_conf_out[].
          APPEND gt_marc_vc_char.
          CLEAR  gt_marc_vc_char.
          ls_matnr_werks-matnr = gt_delv_data-matnr.
          ls_matnr_werks-werks = gt_delv_data-werks.
          INSERT ls_matnr_werks INTO TABLE lt_matnr_werks.
          CLEAR  ls_matnr_werks.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF gt_marc_vc_char[] IS NOT INITIAL.
    SORT gt_marc_vc_char BY werks matnr.
  ENDIF.

  REFRESH lt_matnr_werks.

ENDFORM.                    " get_marc_vc_data
*----------------------------------------------------------------------*
*       Form  get_vbup_data
*----------------------------------------------------------------------*
* This form gets the VBUP data (Item Picking & Packing Status)
*----------------------------------------------------------------------*
FORM get_vbup_data .

  SELECT vbeln posnr kosta pksta
         INTO TABLE gt_vbup
         FROM vbup
         FOR ALL ENTRIES IN gt_delv_data
         WHERE vbeln EQ gt_delv_data-vbeln AND
               posnr EQ gt_delv_data-posnr.
  IF sy-subrc EQ 0.
    SORT gt_vbup BY vbeln posnr.
  ENDIF.

ENDFORM.                    " get_vbup_data
*----------------------------------------------------------------------*
*       Form  v2_data_determination
*----------------------------------------------------------------------*
* This form determines data for V2
*----------------------------------------------------------------------*
FORM v2_data_determination.

  DATA  : lv_atwrt       TYPE   atwrt,
          lv_wrk02       TYPE   werks_d,
          lv_cuobj       TYPE   cuobj,
          lv_ntgew       TYPE   ntgew,
          lv_cuobj_found.

  PERFORM get_net_gross_weight.                 " Net & Gross Weight
  IF gv_packed IS INITIAL.
    PERFORM get_vbap_cuobj_zzwgtroll.
    CLEAR : lv_cuobj_found, lv_wrk02, lv_cuobj, lv_ntgew.
    IF gv_lips_cuobj IS INITIAL.
      CLEAR gt_marc_vc_char.
      READ TABLE gt_marc_vc_char WITH KEY werks = gt_delv_data-werks
                                          matnr = gt_delv_data-matnr
                                          BINARY SEARCH.
      IF sy-subrc EQ 0 AND gt_marc_vc_char-confout[] IS NOT INITIAL.
        lv_cuobj_found = 'X'.
        REFRESH gt_conf_out.
        gt_conf_out[] = gt_marc_vc_char-confout[].
*      CLEAR gt_marc_cuobj.
*      READ TABLE gt_marc_cuobj WITH KEY matnr = gt_delv_data-matnr
*                                        werks = gt_delv_data-werks
*                                        BINARY SEARCH.
*      IF sy-subrc EQ 0 AND gt_marc_cuobj-cuobj IS NOT INITIAL.
*        lv_cuobj_found = 'X'.
*        PERFORM get_vc_data  TABLES gt_conf_out
*                              USING gt_marc_cuobj-cuobj.
      ELSE.
        SELECT SINGLE wrk02
               FROM   t460a
               INTO   lv_wrk02
               WHERE  werks EQ gt_delv_data-werks AND
                      sobsl EQ gt_marc_cuobj-sobsl.
        IF sy-subrc EQ 0.
          SELECT SINGLE cuobj
                 FROM   marc
                 INTO   lv_cuobj
                 WHERE  matnr EQ gt_delv_data-matnr AND
                        werks EQ lv_wrk02.
          IF sy-subrc EQ 0.
            lv_cuobj_found = 'X'.
            PERFORM get_vc_data TABLES gt_conf_out
                                 USING lv_cuobj.
          ELSE.
            SELECT SINGLE ntgew
                   FROM   mara
                   INTO   lv_ntgew
                   WHERE  matnr EQ gt_delv_data-matnr.
          ENDIF.
        ENDIF.
      ENDIF.
    ELSE.
      lv_cuobj_found = 'X'.
      PERFORM get_vc_data TABLES gt_conf_out
                           USING gv_lips_cuobj. " VC Char Data - VBAP
    ENDIF.

    IF lv_cuobj_found EQ 'X'.
      CLEAR gt_conf_out.
      READ TABLE gt_conf_out WITH KEY atnam = gc_wp_kg_netto_st
                                      BINARY SEARCH.
      IF sy-subrc EQ 0.
        REPLACE ',' WITH space INTO gt_conf_out-atwrt.
        IF sy-subrc EQ 0.
          CONDENSE gt_conf_out-atwrt NO-GAPS.
        ELSEIF gt_conf_out-atwrt IS INITIAL.
          gt_conf_out-atwrt = 1.
        ENDIF.
      ELSE.
        gt_conf_out-atwrt = 1.
      ENDIF.
      gv_no_units = floor( gv_net_weight / gt_conf_out-atwrt + 1 / 2 ).

      CLEAR gt_conf_out.
      READ TABLE gt_conf_out WITH KEY atnam = zsdc_wp_stk_pro_pal
                                      BINARY SEARCH.
      IF sy-subrc EQ 0.
        REPLACE ',' WITH space INTO gt_conf_out-atwrt.
        IF sy-subrc EQ 0.
          CONDENSE gt_conf_out-atwrt NO-GAPS.
        ELSEIF gt_conf_out-atwrt LT 0.
          lv_atwrt = gv_no_units.
        ENDIF.
        lv_atwrt = gv_no_units / gt_conf_out-atwrt.
      ELSE.
        lv_atwrt = gv_no_units.
      ENDIF.

      CLEAR gt_conf_out.
      READ TABLE gt_conf_out WITH KEY atnam = zsdc_wp_units_per_pallet
                                      BINARY SEARCH.
      IF sy-subrc EQ 0 AND gt_conf_out-atwrt NE 0.
      ELSE.
        gt_conf_out-atwrt = 1.
      ENDIF.
      gv_units_package = gt_conf_out-atwrt.
*Start of Chage E0VK951541
*Change to to calculate # of packages correctly per CHG 102262
*Do Not Divide by the number of gv_units_package
*lv_atwrt is the number of units
*     gv_no_packages = FLOOR( lv_atwrt / gt_conf_out-atwrt + 1 / 2 ).
      gv_no_packages = floor( lv_atwrt + 1 / 2 ).
*End of Change E0VK951541

      IF gv_no_packages LT 1.
        gv_no_packages = 1.
      ENDIF.
    ELSE.
      IF lv_ntgew LE 0.
        lv_ntgew = 1.
      ENDIF.
      gv_no_units = floor( gv_net_weight / lv_ntgew + 1 / 2 ).
      gv_units_package = gv_no_units.
      gv_no_packages =  gv_no_units.
    ENDIF.
  ELSE.
    PERFORM get_vbfa_hu_count.                " # Packages
    PERFORM get_vbfa_row_count.               " # units
    IF gv_no_packages LE 0.
      gv_no_packages = 1.
    ENDIF.
    gv_units_package = floor( gv_no_units / gv_no_packages + 1 / 2 ).
    " # units in pckg
  ENDIF.

  IF gt_delv_data-vgtyp NE 'V'.
    gv_uebto = gt_delv_data-uebto.
    gv_untto = gt_delv_data-untto.
  ELSE.
    PERFORM mts_tol_over_under_percent.
  ENDIF.
  PERFORM tol_over_under_limit.             " Tol. Over & Under Limit
  gv_uom = gt_delv_data-meins.              " Unit of Measure

ENDFORM. "v2_data_determination
*----------------------------------------------------------------------*
*       Form  mts_units_package
*----------------------------------------------------------------------*
* This form determines Units & Packages for MTS material
*----------------------------------------------------------------------*
FORM mts_units_package.

  CLEAR gs_conf_out.
  READ TABLE gt_marc_vc_char-confout INTO gs_conf_out
                                     WITH KEY atnam = zsdc_unit_code
                                              BINARY SEARCH.
  IF sy-subrc EQ 0.
    CASE gs_conf_out-atwrt.
      WHEN 'R'.
        gv_uom = 'RL'.
        CLEAR gs_conf_out.
        READ TABLE gt_marc_vc_char-confout INTO gs_conf_out
                              WITH KEY atnam = zsdc_rolls_in_package
                                       BINARY SEARCH.
        IF sy-subrc EQ 0 AND gs_conf_out-atwrt IS NOT INITIAL.
          gv_units_package = gs_conf_out-atwrt.
        ELSE.
          gv_units_package = 1.
        ENDIF.
      WHEN 'B'.
        gv_uom = 'BA'.
        CLEAR gs_conf_out.
        READ TABLE gt_marc_vc_char-confout INTO gs_conf_out
                              WITH KEY atnam = zsdc_bales_per_unit
                                       BINARY SEARCH.
        IF sy-subrc EQ 0 AND gs_conf_out-atwrt IS NOT INITIAL.
          gv_units_package = gs_conf_out-atwrt.
        ELSE.
          gv_units_package = 1.
        ENDIF.
* >> Begin of V4W2 Changes - CCHERUP - (Sheeting Product)
      WHEN 'C' OR 'D'.
        gv_uom = 'KAR'.  " Carton
        CLEAR gs_conf_out.
        READ TABLE gt_marc_vc_char-confout INTO gs_conf_out
                              WITH KEY atnam = zsdc_cartons_per_pallet
                                        BINARY SEARCH.
        IF sy-subrc EQ 0.
          IF gs_conf_out-atwrt IS NOT INITIAL.
            gv_units_package = gs_conf_out-atwrt.
          ELSE.
            gv_units_package = 1.
          ENDIF.
        ELSE.
          gv_units_package = 1.
        ENDIF.
      WHEN 'S'.
        gv_uom = 'SKD'.
        gv_units_package = 1.
* << End of V4W2 Changes
      WHEN OTHERS.
        gv_units_package = 1.

    ENDCASE.
  ENDIF.

ENDFORM. "mts_units_package
*----------------------------------------------------------------------*
*       Form  mts_no_units
*----------------------------------------------------------------------*
* This form determines No. of Units for MTS material
*----------------------------------------------------------------------*
FORM mts_no_units.

  TABLES zdl_mts_density.
  DATA : lv_mara_cuobf TYPE cuobm,
         lv_atinn      TYPE atinn,
         lv_umrez      TYPE umrez,
         lv_umren      TYPE umren,
         lv_weight     TYPE zz_wgt_roll.

  IF gv_zzwgt_roll IS NOT INITIAL.
    gv_no_units = floor( gv_net_weight / gv_zzwgt_roll + 1 / 2 ).
    IF gv_no_units LT '1'.
      gv_no_units = 1.
    ENDIF.
  ELSE.
    SELECT SINGLE cuobf
           INTO   lv_mara_cuobf
           FROM   mara
           WHERE  matnr = gt_delv_data-matnr.
    CHECK sy-subrc = 0.
    SELECT SINGLE atinn
           INTO   lv_atinn
           FROM   cabn
*         WHERE  atnam = zsdc_unit_weight.                  "CMS31694
          WHERE  atnam = gv_unit_weight.                    "CMS31694

    IF sy-subrc IS INITIAL.
      SELECT SINGLE atflv
             INTO ibinval_sel_f-atflv
*             up to 1 rows
             FROM ibinval_sel_f
             WHERE atinn    = lv_atinn AND
                   objtyp   = 'MARAT' AND
                   instance = lv_mara_cuobf.
*      endselect.
      CHECK sy-subrc = 0.
    ENDIF.
    SELECT SINGLE *
           FROM  zdl_mts_density
           WHERE werks = gt_delv_data-werks AND
                 matkl = gt_delv_data-matkl.
    IF sy-subrc = 0.
      PERFORM get_mts_density USING lv_mara_cuobf.
      IF gv_atflv NE 0.
        gv_no_units = floor( ( gv_net_weight / gv_atflv ) + 1 / 2 ).
        IF gv_no_units LT '1'.
          gv_no_units = 1.
        ENDIF.
      ENDIF.
    ELSE.
      SELECT SINGLE umrez umren
             FROM   marm
             INTO   (lv_umrez, lv_umren)
             WHERE  matnr EQ gt_delv_data-matnr AND
                    meinh EQ gv_uom.
      IF sy-subrc EQ 0.
        lv_weight = lv_umrez / lv_umren.
        IF lv_weight LE 0.
          lv_weight = 1.
        ENDIF.
        gv_no_units = floor( gv_net_weight / lv_weight + 1 / 2 ).
        IF gv_no_units LT '1'.
          gv_no_units = 1.
        ENDIF.
      ENDIF.
*      read table gt_marc_vc_char-confout into gs_conf_out with key
*                                              atnam = gc_unit_weight.
*      if sy-subrc eq 0.
*        replace ',' with space into gs_conf_out-atwrt.
*        condense gs_conf_out-atwrt no-gaps.
*        gv_no_units = floor( gv_net_weight / gs_conf_out-atwrt +
*                             1 / 2 ).
*      endif.
    ENDIF.
  ENDIF.

ENDFORM. "mts_no_units
*----------------------------------------------------------------------*
*       Form  rfc_function_call
*----------------------------------------------------------------------*
* This form makes an RFC call to APO to get Delivery Roll info for the
* shipment(s)
*----------------------------------------------------------------------*
FORM rfc_function_call.

  DATA : lrfcdes_name TYPE rfcdes,
         dest         LIKE rfcdes-rfcdest.

  CALL FUNCTION 'Z_MM_GET_APO_RFCDES'
    IMPORTING
      rfcdes_name         = lrfcdes_name
    EXCEPTIONS
      process_error       = 1
      invalid_destination = 2
      not_found           = 3
      OTHERS              = 4.
  IF sy-subrc EQ 0.
    dest = lrfcdes_name-rfcdest.
    CALL FUNCTION 'ZDL_I01217_GUIDANCE_READ'
      DESTINATION dest
      EXPORTING
        it_shipment_no        = gt_shipment_no[]
      TABLES
        it_delivery_roll      = gt_delivery_roll
      EXCEPTIONS
        no_records_found      = 1
        communication_failure = 2
        system_failure        = 3.
    IF sy-subrc EQ 0.
      SORT gt_delivery_roll BY delivery delivery_item .
    ENDIF.
  ENDIF.

ENDFORM. "rfc_function_call
*----------------------------------------------------------------------*
*       Form  get_mts_density
*----------------------------------------------------------------------*
* This form determines MTS Density
*----------------------------------------------------------------------*
FORM get_mts_density USING  iv_cuobj TYPE vbap-cuobj.

  CONSTANTS: lc_found              VALUE 'X',
             lc_sales_grade        TYPE atnam VALUE 'SALES_GRADE',
             lc_sales_color        TYPE atnam VALUE 'SALES_COLOR',
             lc_sales_surface      TYPE atnam VALUE 'SALES_SURFACE',
             lc_mfg_work_center    TYPE atnam VALUE 'MFG_WORK_CENTER',
             lc_sales_basis_weight TYPE atnam VALUE 'SALES_BASIS_WEIGHT'
             ,
             lc_roll_diameter      TYPE atnam VALUE 'ROLL_DIAMETER'.

  DATA: lt_zpp_density LIKE zpp_density OCCURS 0 WITH HEADER LINE,
        lt_match       TYPE TABLE OF cuov_01 WITH HEADER LINE,
        lt_query       TYPE TABLE OF cuov_01 WITH HEADER LINE,
        lt_conf        TYPE TABLE OF conf_out WITH HEADER LINE,
        ls_globals     TYPE cuov_00.

  DATA: lv_fld1(30)         TYPE c,
        lv_fld2(30)         TYPE c,
        lv_cuobj            TYPE vbap-cuobj,
        lv_werks            TYPE werks_d,
        lv_grade            LIKE zpp_density-grade,
        lv_atflv            TYPE p DECIMALS 2,
        lv_basis_weight     LIKE zpp_density-basis_weight,
        lv_color            LIKE zpp_density-color,
        lv_surface          LIKE zpp_density-surface,
        lv_arbpl            LIKE zpp_density-arbpl,
        lv_diameter         LIKE zpp_density-diameter_from,
        lv_diameter_from_fp LIKE  cuov_01-atflv,
        lv_diameter_to_fp   LIKE  cuov_01-atflv,
        lv_factor           TYPE i,
        lv_atwrt            LIKE lt_match-atwrt.

  gv_atflv = ibinval_sel_f-atflv.  "initialize

  CHECK iv_cuobj IS NOT INITIAL.

* Gather the parameters we need to calculate the weight conversions.
* First gather all the characteristics for the line item.

  lv_cuobj = iv_cuobj.
  REFRESH lt_conf.
  CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
    EXPORTING
      instance           = lv_cuobj
    TABLES
      configuration      = lt_conf
    EXCEPTIONS
      instance_not_found = 1
      OTHERS             = 2.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.

  SORT lt_conf BY atnam.   "prepare for binary search

* Build the QUERY to obtain the density factor.
  DEFINE fill_query_1.
    CLEAR lt_query.
    lt_query-varnam = '&1'.
    lt_query-atfor  = '&2'.
    lt_query-atwrt  = &3.
    lt_query-atflv  = &4.
    APPEND lt_query.
  END-OF-DEFINITION.

  DEFINE fill_query_2c.
    READ TABLE lt_conf WITH KEY atnam = '&1' BINARY SEARCH.
    IF sy-subrc EQ 0.
      fill_query_1: &1 char lt_conf-atwrt 0.
    ENDIF.
  END-OF-DEFINITION.

  DEFINE fill_query_2n.
    READ TABLE lt_conf WITH KEY atnam = '&1' BINARY SEARCH.
    IF sy-subrc EQ 0.
      SPLIT lt_conf-atwrt AT space INTO lv_fld1 lv_fld2.
      "e.g., 58.02 IN"
      fill_query_1: &1 num space lv_fld1.
    ENDIF.
  END-OF-DEFINITION.

  REFRESH lt_query.
  fill_query_2c: sales_grade,
                 sales_color,
                 sales_surface,
                 mfg_work_center.
  fill_query_2n: roll_diameter,
                 sales_basis_weight.
  lv_werks = gt_delv_data-werks.
  fill_query_1:  plant_no_obj char lv_werks 0.

* First check if the entry exists in ZPP_DENSITY table
  READ TABLE lt_query WITH KEY varnam = lc_sales_grade.
  IF sy-subrc = 0.
    lv_grade = lt_query-atwrt.
  ELSE.
    EXIT.
  ENDIF.
  READ TABLE lt_query WITH KEY varnam = lc_sales_color.
  IF sy-subrc = 0.
    lv_color = lt_query-atwrt.
  ELSE.
    EXIT.
  ENDIF.
  READ TABLE lt_query WITH KEY varnam = lc_sales_surface.
  IF sy-subrc = 0.
    lv_surface = lt_query-atwrt.
  ELSE.
    EXIT.
  ENDIF.
  READ TABLE lt_query WITH KEY varnam = lc_mfg_work_center.
  IF sy-subrc = 0.
    lv_arbpl = lt_query-atwrt.
  ELSE.
    EXIT.
  ENDIF.
  READ TABLE lt_query WITH KEY varnam = lc_sales_basis_weight.
  IF sy-subrc = 0.
    lv_atflv = lt_query-atflv.
    lv_basis_weight = lv_atflv.
    SHIFT lv_basis_weight LEFT DELETING LEADING space.
    CONCATENATE '%' lv_basis_weight INTO lv_basis_weight.
  ELSE.
    EXIT.
  ENDIF.
  SELECT *                       "Table has few fields ( * ) - OK
        FROM zpp_density
        INTO CORRESPONDING FIELDS OF TABLE lt_zpp_density
        WHERE   grade           =     lv_grade
        AND     basis_weight    LIKE  lv_basis_weight
        AND     color           =     lv_color
        AND     surface         =     lv_surface
        AND     werks           =     lv_werks
        AND     arbpl           =     lv_arbpl.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.
  READ TABLE lt_query WITH KEY varnam = lc_roll_diameter.
  IF sy-subrc = 0.
    lv_atflv = lt_query-atflv.
  ELSE.
    EXIT.
  ENDIF.
  CLEAR lv_diameter.
  LOOP AT lt_zpp_density.    "Table built in the above select
    lv_diameter_from_fp = lt_zpp_density-diameter_from. "Set diameter fr
    lv_diameter_to_fp   = lt_zpp_density-diameter_to.   "Set diameter to
    IF ( lv_diameter_from_fp <= lv_atflv AND  "Compare diameter
         lv_atflv   <= lv_diameter_to_fp ). "from & diameter to
      lv_diameter = lc_found.  "We got it.
      EXIT.
    ENDIF.
  ENDLOOP.
  IF lv_diameter IS INITIAL.
    EXIT.
  ENDIF.

* Obtain the density factor; result to be found in MATCH.
  REFRESH lt_match.
  CLEAR ls_globals.
  CALL FUNCTION 'ZSD_VC_GET_DENSITY'
    EXPORTING
      globals        = ls_globals
    TABLES
      match          = lt_match
      query          = lt_query
    EXCEPTIONS
      fail           = 1
      internal_error = 2
      OTHERS         = 3.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.

* Build the QUERY to obtain the weight values.
  WRITE gt_delv_data-lfimg UNIT gt_delv_data-vrkme TO lv_atwrt
                                        LEFT-JUSTIFIED NO-GROUPING.
  lt_query[] = lt_match[].    "transfer the density factor
  fill_query_2c: deviation_manufacturing_cd.
  fill_query_2n: roll_diameter,
                 roll_width,
                 core_diameter.
  fill_query_1:  original_order_qty   num  space      lv_atwrt,
                 sales_uom            char vbap-vrkme 0.

* Obtain the derived weight values, which will be in LB.
  REFRESH lt_match.
  CLEAR ls_globals.
  CALL FUNCTION 'ZSD_VC_GET_WEIGHT_VALUES'
    EXPORTING
      globals        = ls_globals
*     I_PRINT_RESULTS       =
    TABLES
      match          = lt_match
      query          = lt_query
    EXCEPTIONS
      fail           = 1
      internal_error = 2
      OTHERS         = 3.
  IF sy-subrc <> 0.
    EXIT.
  ENDIF.

* Pull in the results.
*  READ TABLE lt_match WITH KEY varnam = 'UNIT_WEIGHT'.     "CMS31694
  READ TABLE lt_match WITH KEY varnam = gv_unit_weight.     "CMS31694
  CHECK sy-subrc EQ 0.
  lv_factor = lt_match-atflv * 1000.
  "force rounding to nearest whole num
  gv_atflv = lv_factor / 1000.

ENDFORM. "get_mts_density
*----------------------------------------------------------------------*
*       Form  refresh_variables
*----------------------------------------------------------------------*
* This form refreshes the global variables
*----------------------------------------------------------------------*
FORM refresh_variables.

  CLEAR :  gv_no_packages,
           gv_no_units,
           gv_units_package,
           gv_ntgew,
           gv_brgew,
           gv_uebto,
           gv_untto,
           gv_uebqty,
           gv_untqty,
           gv_net_weight,
           gv_gross_weight,
           gv_batch_line_count,
           gv_lips_cuobj,
           gv_zzwgt_roll,
           gv_uom,
           gv_volume,
           gv_voluom,
           gt_char_name[],
           gt_object_data[],
           gt_batch_char[].

ENDFORM. "refresh_variables
*&---------------------------------------------------------------------*
*&      Form  get_roll_volume_nonbatch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_roll_volume_nonbatch CHANGING cv_volume.

  DATA : lv_roll_diameter TYPE p DECIMALS 5,
         lv_roll_width    TYPE p DECIMALS 5,
         lv_roll_volume   TYPE p DECIMALS 5.

  CLEAR gt_conf_out.
* READ TABLE gt_conf_out WITH KEY atnam = zsdc_roll_diameter"CMS31694
  READ TABLE gt_conf_out WITH KEY atnam = gv_roll_diameter  "CMS31694
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_roll_diameter = gt_conf_out-atwrt.
  ENDIF.

  CLEAR gt_conf_out.
* READ TABLE gt_conf_out WITH KEY atnam = zsdc_roll_width   "CMS31694
  READ TABLE gt_conf_out WITH KEY atnam = gv_roll_width     "CMS31694
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_roll_width = gt_conf_out-atwrt.
  ENDIF.

  IF lv_roll_diameter GT 0 AND lv_roll_width GT 0.
    PERFORM calculate_roll_volume USING lv_roll_diameter
                                        lv_roll_width
                               CHANGING lv_roll_volume.
  ENDIF.
  cv_volume = lv_roll_volume.

ENDFORM.                    "get_roll_volume_nonbatch
*&---------------------------------------------------------------------*
*&      Form  get_bale_volume_nonbatch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_bale_volume_nonbatch CHANGING cv_volume.

  DATA : lv_bale_height    TYPE p DECIMALS 5,
         lv_bale_length    TYPE p DECIMALS 5,
         lv_bale_width     TYPE p DECIMALS 5,
         lv_bales_per_unit TYPE p DECIMALS 5,
         lv_bale_volume    TYPE p DECIMALS 5.

  CONSTANTS: lc_1000000     TYPE p DECIMALS 5  VALUE '1000000'.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_item_height_metric
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_bale_height = gt_conf_out-atwrt.
  ENDIF.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_item_length_metric
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_bale_length = gt_conf_out-atwrt.
  ENDIF.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_item_width_metric
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_bale_width = gt_conf_out-atwrt.
  ENDIF.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_bales_per_unit
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_bales_per_unit = gt_conf_out-atwrt.
  ENDIF.

  CLEAR lv_bale_volume.
  lv_bale_volume = ( ( lv_bale_height * lv_bale_length *
                       lv_bale_width  * lv_bales_per_unit )
                       / lc_1000000 ).

  cv_volume = lv_bale_volume.


ENDFORM.                    "get_bale_volume_nonbatch
*&---------------------------------------------------------------------*
*&      Form  calculate_roll_volume
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM calculate_roll_volume USING iv_roll_diameter
                                 iv_roll_width
                        CHANGING cv_roll_volume.

  CONSTANTS : lc_pi      TYPE p DECIMALS 5  VALUE '3.14159',
              lc_7645548 TYPE p DECIMALS 7  VALUE '0.7645548',
              lc_mm_2_m  TYPE p DECIMALS 7 VALUE '0.001',   "CMS31694
              lc_46656   TYPE p DECIMALS 5  VALUE '46656'.

  DATA      : lv_roll_radius    TYPE p DECIMALS 5,
              lv_roll_radius_sq TYPE p DECIMALS 5,
              lv_roll_base_area TYPE p DECIMALS 5.

  CLEAR cv_roll_volume.

  IF gv_flag_metric EQ abap_true.                           "CMS31694
*   Convert Millimeters to Meters
    iv_roll_diameter = iv_roll_diameter * lc_mm_2_m.
    iv_roll_width = iv_roll_width * lc_mm_2_m.

    lv_roll_radius    = iv_roll_diameter / 2.
    lv_roll_radius_sq = lv_roll_radius * lv_roll_radius.
    lv_roll_base_area = lv_roll_radius_sq * lc_pi.
    cv_roll_volume    = lv_roll_base_area * iv_roll_width.
  ELSE.

    lv_roll_radius    = iv_roll_diameter / 2.
    lv_roll_radius_sq = lv_roll_radius * lv_roll_radius.
    lv_roll_base_area = lv_roll_radius_sq * lc_pi.            "pi=3.14159
    cv_roll_volume    = ( ( lv_roll_base_area * iv_roll_width
                                     / lc_46656 ) )."46656 cu in=1 cu yd

    cv_roll_volume    = cv_roll_volume * lc_7645548.
*                                           "1 cu yd = 0.7645548 cu mtr
    "lv_roll_volume    = lv_roll_volume * gv_no_units.

  ENDIF.                                                    "CMS31694

ENDFORM.                    "calculate_roll_volume
*&---------------------------------------------------------------------*
*&      Form  get_roll_volume_batch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_roll_volume_batch CHANGING cv_volume.

  DATA : lt_object_data   TYPE clobjdat OCCURS 2 WITH HEADER LINE,
         lv_roll_diameter TYPE p DECIMALS 5,
         lv_roll_width    TYPE p DECIMALS 5,
         lv_roll_volume   TYPE p DECIMALS 5,
         lv_char_value    TYPE atwrt,
         lv_p10_4(10)     TYPE p DECIMALS 4.

  CLEAR gt_object_data.
* READ TABLE gt_object_data WITH KEY atnam = zsdc_roll_diameter"CMS31694
  READ TABLE gt_object_data WITH KEY atnam = gv_roll_diameter "CMS31694
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_roll_diameter = lv_char_value.
    ENDIF.
  ENDIF.

  CLEAR gt_object_data.
* READ TABLE gt_object_data WITH KEY atnam = zsdc_roll_width"CMS31694
  READ TABLE gt_object_data WITH KEY atnam = gv_roll_width  "CMS31694
                                      BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_roll_width = lv_char_value.
    ENDIF.
  ENDIF.

  IF lv_roll_diameter GT 0 AND lv_roll_width GT 0.
    PERFORM calculate_roll_volume USING lv_roll_diameter
                                        lv_roll_width
                               CHANGING lv_roll_volume.
  ENDIF.
  cv_volume = lv_roll_volume.

ENDFORM.                    "get_roll_volume_batch
*&---------------------------------------------------------------------*
*&      Form  get_bale_volume_batch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_bale_volume_batch CHANGING cv_volume.

  DATA : lt_object_data     TYPE clobjdat OCCURS 2 WITH HEADER LINE,
         lv_bale_height     TYPE p DECIMALS 5,
         lv_bale_length     TYPE p DECIMALS 5,
         lv_bale_width      TYPE p DECIMALS 5,
         lv_bales_per_batch TYPE p DECIMALS 5,
         lv_bale_volume     TYPE p DECIMALS 5,
         lv_char_value      TYPE atwrt.

  CONSTANTS: lc_1000000     TYPE p DECIMALS 5  VALUE '1000000'.

  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_item_height_metric
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_bale_height = lv_char_value.
    ENDIF.
  ELSE.
    CLEAR gt_conf_out.
    READ TABLE gt_conf_out WITH KEY atnam = zsdc_item_height_metric
                                    BINARY SEARCH.
    IF sy-subrc EQ 0.
      REPLACE ',' WITH space INTO gt_conf_out-atwrt.
      IF sy-subrc EQ 0.
        CONDENSE gt_conf_out-atwrt NO-GAPS.
      ENDIF.
      lv_bale_height = gt_conf_out-atwrt.
    ENDIF.
  ENDIF.

  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_item_length_metric
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_bale_length = lv_char_value.
    ENDIF.
  ELSE.
    CLEAR gt_conf_out.
    READ TABLE gt_conf_out WITH KEY atnam = zsdc_item_length_metric
                                    BINARY SEARCH.
    IF sy-subrc EQ 0.
      REPLACE ',' WITH space INTO gt_conf_out-atwrt.
      IF sy-subrc EQ 0.
        CONDENSE gt_conf_out-atwrt NO-GAPS.
      ENDIF.
      lv_bale_length = gt_conf_out-atwrt.
    ENDIF.
  ENDIF.

  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_item_width_metric
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_bale_width = lv_char_value.
    ENDIF.
  ELSE.
    CLEAR gt_conf_out.
    READ TABLE gt_conf_out WITH KEY atnam = zsdc_item_width_metric
                                    BINARY SEARCH.
    IF sy-subrc EQ 0.
      REPLACE ',' WITH space INTO gt_conf_out-atwrt.
      IF sy-subrc EQ 0.
        CONDENSE gt_conf_out-atwrt NO-GAPS.
      ENDIF.
      lv_bale_width = gt_conf_out-atwrt.
    ENDIF.
  ENDIF.

  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_bales_per_batch
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_bales_per_batch = lv_char_value.
    ENDIF.
  ENDIF.

  CLEAR lv_bale_volume.
  lv_bale_volume = ( ( lv_bale_height * lv_bale_length *
                       lv_bale_width  * lv_bales_per_batch )
                       / lc_1000000 ).

  cv_volume = lv_bale_volume.

ENDFORM.                    "get_bale_volume_batch
*&---------------------------------------------------------------------*
*&      Form  float_char_conversion
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM float_char_conversion USING iv_atflv
                        CHANGING cv_value.

  cv_value = |{ CONV f( iv_atflv ) NUMBER = RAW DECIMALS = 4 }|. "CMS31694

* CMS31694: Code to convert from float to char is commented below because
* it was causing a dump for european user's Decimal Notation settings (1.234.567,89)
* The above code will convert to char format without checking this user settings
* and the final converted value will always be in the raw format i.e. period as
* a decimal instead of a comma
*  DATA :   lv_p10_4(10) TYPE p DECIMALS 4.
*
*  CLEAR cv_value.
*  CALL FUNCTION 'CEVA_CONVERT_FLOAT_TO_CHAR'
*    EXPORTING
*      float_imp  = iv_atflv
*      format_imp = lv_p10_4
*    IMPORTING
*      char_exp   = cv_value.
*
*  CONDENSE cv_value NO-GAPS.

ENDFORM.                    "float_char_conversion
*&---------------------------------------------------------------------*
*&      Form  get_batch_characteristics
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_batch_characteristics TABLES ct_object_data STRUCTURE clobjdat
                                USING iv_matnr
                                      iv_charg
                                      iv_uom.

  DATA :  lt_char_name TYPE sel_char
                                         OCCURS 0 WITH HEADER LINE,
          lt_atinn     TYPE atinn,
          lt_class     TYPE sclass
                                         OCCURS 2 WITH HEADER LINE,
          lv_object    TYPE objnum.

  IF iv_uom EQ 'RL'.
*   PERFORM conversion_exit USING zsdc_roll_diameter        "CMS31694
    PERFORM conversion_exit USING gv_roll_diameter          "CMS31694
                         CHANGING lt_atinn.
    lt_char_name-atinn = lt_atinn.
    APPEND lt_char_name.
    CLEAR  lt_char_name.

*   PERFORM conversion_exit USING zsdc_roll_width           "CMS31694
    PERFORM conversion_exit USING gv_roll_width             "CMS31694
                         CHANGING lt_atinn.
    lt_char_name-atinn = lt_atinn.
    APPEND lt_char_name.
    CLEAR  lt_char_name.
  ELSEIF iv_uom EQ 'BA'.
    PERFORM conversion_exit USING zsdc_item_height_metric
                         CHANGING lt_atinn.
    lt_char_name-atinn = lt_atinn.
    APPEND lt_char_name.
    CLEAR  lt_char_name.

    PERFORM conversion_exit USING zsdc_item_length_metric
                         CHANGING lt_atinn.
    lt_char_name-atinn = lt_atinn.
    APPEND lt_char_name.
    CLEAR  lt_char_name.

    PERFORM conversion_exit USING zsdc_item_width_metric
                         CHANGING lt_atinn.
    lt_char_name-atinn = lt_atinn.
    APPEND lt_char_name.
    CLEAR  lt_char_name.

    PERFORM conversion_exit USING zsdc_bales_per_batch
                         CHANGING lt_atinn.
    lt_char_name-atinn = lt_atinn.
    APPEND lt_char_name.
    CLEAR  lt_char_name.
  ENDIF.

  IF iv_matnr CA 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.
    lv_object = iv_matnr.
    lv_object+18(10) = iv_charg.
  ELSE.
    CONCATENATE iv_matnr
                iv_charg
           INTO lv_object.
  ENDIF.

* Getting batch characteristics
  CALL FUNCTION 'CLAF_CLASSIFICATION_OF_OBJECTS'
    EXPORTING
      classtype            = '023'
      object               = lv_object
      objecttable          = 'MCH1'
    TABLES
      i_sel_characteristic = lt_char_name
      t_class              = lt_class
      t_objectdata         = ct_object_data
    EXCEPTIONS
      no_classification    = 1
      no_classtypes        = 2
      invalid_class_type   = 3
      OTHERS               = 4.
  IF sy-subrc EQ 0.
    SORT ct_object_data BY atnam.
  ENDIF.

ENDFORM.                    "get_batch_characteristics
*&---------------------------------------------------------------------*
*&      Form  conversion_exit
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM conversion_exit USING iv_char_name
                  CHANGING cv_atinn.

  CLEAR cv_atinn.
  CALL FUNCTION 'CONVERSION_EXIT_ATINN_INPUT'
    EXPORTING
      input  = iv_char_name
    IMPORTING
      output = cv_atinn.

ENDFORM.                    "conversion_exit
*----------------------------------------------------------------------*
*       Form  get_additional_data
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_additional_data .

  DATA : lv_volume    TYPE volum,    "Volume     dec 3
         lv_old_matnr TYPE matnr,
         lv_old_charg TYPE charg_d.

  LOOP AT gt_item_data WHERE vbeln = gt_delv_data-vbeln AND
                             uecha = gt_delv_data-posnr.
    IF lv_old_matnr NE gt_item_data-matnr OR
       lv_old_charg NE gt_item_data-charg.
      lv_old_matnr = gt_item_data-matnr.
      lv_old_charg = gt_item_data-charg.
      PERFORM get_batch_char_values USING gt_item_data-matnr
                                          gt_item_data-charg.
    ENDIF.
    PERFORM get_lineal_footage      USING gt_delv_data-vbeln
                                          gt_delv_data-posnr
                                          gt_item_data-posnr
                                          gt_item_data-matnr
                                          gt_item_data-charg.
    IF gv_packed EQ 'X'.  " If fully packed, then only calculate volume
      IF gv_uom EQ 'RL'.  " If Rolls
        PERFORM get_roll_volume_batch CHANGING lv_volume.
        gv_volume = gv_volume + lv_volume.
        gv_voluom = 'M3'.
      ELSEIF gv_uom EQ 'BA'. " If Bales
        PERFORM get_bale_volume_batch CHANGING lv_volume.
        gv_volume = gv_volume + lv_volume.
        gv_voluom = 'M3'.
* >> Begin of V4W2 Changes - CCHERUP
      ELSEIF gv_uom EQ 'KAR' OR gv_uom EQ 'SKD'.
        PERFORM get_skid_cart_volume_batch CHANGING lv_volume.
        gv_volume = gv_volume + lv_volume.
        gv_voluom = 'M3'.
* << End of V4W2 Changes
      ENDIF.
    ENDIF.
  ENDLOOP.
  IF sy-subrc NE 0.
    IF gt_delv_data-charg IS INITIAL.
      IF gv_packed EQ 'X'.  " If fully packed, then only calculate volume
        IF gv_uom EQ 'RL'. " If Rolls
          PERFORM get_roll_volume_nonbatch CHANGING lv_volume.
          gv_volume = lv_volume.
          gv_voluom = 'M3'.
        ELSEIF gv_uom EQ 'BA'. " If Bales
          PERFORM get_bale_volume_nonbatch CHANGING lv_volume.
          gv_volume = lv_volume.
          gv_voluom = 'M3'.
* >> Begin of V4W2 Changes - CCHERUP
        ELSEIF gv_uom EQ 'KAR' OR gv_uom EQ 'SKD'.
          PERFORM get_skid_cart_volume_nonbatch CHANGING lv_volume.
          gv_volume = lv_volume.
          gv_voluom = 'M3'.
* << End of V4W2 Changes
        ENDIF.
      ENDIF.
    ELSE.
      PERFORM get_batch_char_values USING gt_delv_data-matnr
                                          gt_delv_data-charg.
      PERFORM get_lineal_footage    USING gt_delv_data-vbeln
                                          gt_delv_data-posnr
                                          ' '
                                          gt_delv_data-matnr
                                          gt_delv_data-charg.
      IF gv_packed EQ 'X'.  " If fully packed, then only calculate volume
        IF gv_uom EQ 'RL'. " If Rolls
          PERFORM get_roll_volume_batch CHANGING lv_volume.
          gv_volume = lv_volume.
          gv_voluom = 'M3'.
        ELSEIF gv_uom EQ 'BA'. " If Bales
          PERFORM get_bale_volume_batch CHANGING lv_volume.
          gv_volume = lv_volume.
          gv_voluom = 'M3'.
* >> Begin of V4W2 Changes - CCHERUP
        ELSEIF gv_uom EQ 'KAR' OR gv_uom EQ 'SKD'.
          PERFORM get_skid_cart_volume_batch CHANGING lv_volume.
          gv_volume = lv_volume.
          gv_voluom = 'M3'.
* << End of V4W2 Changes
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

  IF gt_batch_char[] IS NOT INITIAL.
    SORT gt_batch_char BY vbeln posnr item.
  ENDIF.

ENDFORM.                    " get_additional_data

*----------------------------------------------------------------------*
*       Form  get_lineal_footage
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_lineal_footage USING iv_vbeln
                              iv_posnr
                              iv_item
                              iv_matnr
                              iv_charg.

  DATA  lv_char_value      TYPE atwrt.

  gt_batch_char-vbeln = iv_vbeln.
  gt_batch_char-posnr = iv_posnr.
  gt_batch_char-item  = iv_item.
  gt_batch_char-matnr = iv_matnr.
  gt_batch_char-charg = iv_charg.
* gt_batch_char-atnam = zsdc_lineal_footage.                "CMS31694
  gt_batch_char-atnam = gv_lineal_char.                     "CMS31694

  CLEAR gt_object_data.
* READ TABLE gt_object_data WITH KEY atnam = zsdc_lineal_footage"CMS31694
  READ TABLE gt_object_data WITH KEY atnam = gv_lineal_char "CMS31694
  BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      "gt_batch_char-atbez = gt_object_data-smbez.
      gt_batch_char-atwrt = lv_char_value.
    ELSE.
      gt_batch_char-atwrt = '0.0'.
    ENDIF.
  ELSE.
    gt_batch_char-atwrt = '0.0'.
  ENDIF.

  APPEND gt_batch_char.
  CLEAR  gt_batch_char.

*Begin insert by jpieri - PRICEF 01298 CR# 10132
*Get the batch characteristics that have not already been added populatedd.
  LOOP AT gt_atnam.
    CLEAR gt_object_data.
    READ TABLE gt_object_data WITH KEY atnam = gt_atnam.
    IF sy-subrc EQ 0.  "Get the characteristic value and add to table gt_batch_char
      gt_batch_char-vbeln = iv_vbeln.
      gt_batch_char-posnr = iv_posnr.
      gt_batch_char-item  = iv_item.
      gt_batch_char-matnr = iv_matnr.
      gt_batch_char-charg = iv_charg.
      IF gt_object_data-atflv IS NOT INITIAL. "A floating point characteristic value
        PERFORM float_char_conversion USING gt_object_data-atflv
                                      CHANGING lv_char_value.
        IF lv_char_value GT 0.
          gt_batch_char-atwrt = lv_char_value.
        ELSE.
          gt_batch_char-atwrt = '0.0'.
        ENDIF.
      ELSE.
        gt_batch_char-atwrt = gt_object_data-ausp1. "All other characteristic values
      ENDIF.
      gt_batch_char-atnam = gt_object_data-atnam.
      APPEND gt_batch_char.
      CLEAR  gt_batch_char.
    ENDIF.
  ENDLOOP.
*End insert by jpieri - PRICEF 01298 CR# 10132

ENDFORM.                    "get_lineal_footage
*----------------------------------------------------------------------*
*       Form  get_batch_char_values
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_batch_char_values USING iv_matnr
                                 iv_charg.

  DATA : lt_class  TYPE sclass OCCURS 2 WITH HEADER LINE,
         lv_object TYPE objnum.

  IF iv_matnr CA sy-abcde.
    lv_object = iv_matnr.
    lv_object+18(10) = iv_charg.
  ELSE.
    CONCATENATE iv_matnr
                iv_charg
           INTO lv_object.
  ENDIF.

  REFRESH gt_object_data.
* Getting batch characteristics
  CALL FUNCTION 'CLAF_CLASSIFICATION_OF_OBJECTS'
    EXPORTING
      classtype            = '023'
      object               = lv_object
      objecttable          = 'MCH1'
    TABLES
      i_sel_characteristic = gt_char_name
      t_class              = lt_class
      t_objectdata         = gt_object_data
    EXCEPTIONS
      no_classification    = 1
      no_classtypes        = 2
      invalid_class_type   = 3
      OTHERS               = 4.
  IF sy-subrc EQ 0.
    SORT gt_object_data BY atnam.
  ENDIF.


ENDFORM.                    "get_batch_char_values
*&---------------------------------------------------------------------*
*&      Form  get_batch_char_atinn
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_batch_char_atinn.

  DATA : lv_atinn TYPE  atinn.

  REFRESH gt_char_atinn.
* Lineal Footage Characteristic
* PERFORM conversion_exit USING zsdc_lineal_footage         "CMS31694
  PERFORM conversion_exit USING gv_lineal_char              "CMS31694
                       CHANGING lv_atinn.
* gt_char_atinn-atnam = zsdc_lineal_footage.                "CMS31694
  gt_char_atinn-atnam = gv_lineal_char.                     "CMS31694
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Roll Diameter
* PERFORM conversion_exit USING zsdc_roll_diameter          "CMS31694
  PERFORM conversion_exit USING gv_roll_diameter            "CMS31694
                       CHANGING lv_atinn.
* gt_char_atinn-atnam = zsdc_roll_diameter.                 "CMS31694
  gt_char_atinn-atnam = gv_roll_diameter.                   "CMS31694
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Roll Width
* PERFORM conversion_exit USING zsdc_roll_width             "CMS31694
  PERFORM conversion_exit USING gv_roll_width               "CMS31694
                       CHANGING lv_atinn.
* gt_char_atinn-atnam = zsdc_roll_width.                    "CMS31694
  gt_char_atinn-atnam = gv_roll_width.                      "CMS31694
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Item Height Metric
  PERFORM conversion_exit USING zsdc_item_height_metric
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_item_height_metric.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Item Length Metric
  PERFORM conversion_exit USING zsdc_item_length_metric
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_item_length_metric.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Item Width Metric
  PERFORM conversion_exit USING zsdc_item_width_metric
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_item_width_metric.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Bales Per Batch
  PERFORM conversion_exit USING zsdc_bales_per_batch
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_bales_per_batch.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* >> Begin of V4W2 Changes - CCHERUP
* Height Total
  PERFORM conversion_exit USING zsdc_height_total
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_height_total.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Pallet Length
  PERFORM conversion_exit USING zsdc_pallet_length
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_pallet_length.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.

* Pallet Width
  PERFORM conversion_exit USING zsdc_pallet_width
                       CHANGING lv_atinn.
  gt_char_atinn-atnam = zsdc_pallet_width.
  gt_char_atinn-atinn = lv_atinn.
  APPEND gt_char_atinn.
  CLEAR  gt_char_atinn.
* << End of V4W2 Changes - CCHERUP

*Begin insert by jpieri - PRICEF 01298 CR# 10132
  LOOP AT gt_atnam.
    PERFORM conversion_exit USING gt_atnam
                         CHANGING lv_atinn.
    gt_char_atinn-atnam = gt_atnam.
    gt_char_atinn-atinn = lv_atinn.
    APPEND gt_char_atinn.
    CLEAR  gt_char_atinn.
  ENDLOOP.
*End insert by jpieri - PRICEF 01298 CR# 10132

  SORT gt_char_atinn BY atnam.

  DELETE ADJACENT DUPLICATES  "Insert by jpieri - PRICEF 01298 CR# 10132
    FROM gt_char_atinn COMPARING ALL FIELDS.

ENDFORM.                    "get_batch_char_atinn
*----------------------------------------------------------------------*
*       Form  get_reqd_batch_char_atinn
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_reqd_batch_char_atinn.

  REFRESH gt_char_name.

* Lineal Footage Characteristic
  CLEAR gt_char_atinn.
* READ TABLE gt_char_atinn WITH KEY atnam = zsdc_lineal_footage"CMS31694
  READ TABLE gt_char_atinn WITH KEY atnam = gv_lineal_char  "CMS31694
                                    BINARY SEARCH.
  IF sy-subrc EQ 0.
    gt_char_name-atinn = gt_char_atinn-atinn.
    APPEND gt_char_name.
    CLEAR  gt_char_name.
  ENDIF.

* For Volume Calculations
  IF gv_packed EQ 'X'.
    CASE gv_uom.
      WHEN 'RL'.
* Roll Diameter
        CLEAR gt_char_atinn.
*       READ TABLE gt_char_atinn WITH KEY atnam = zsdc_roll_diameter"CMS31694
        READ TABLE gt_char_atinn WITH KEY atnam = gv_roll_diameter "CMS31694
                                          BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

* Roll Width
        CLEAR gt_char_atinn.
*       READ TABLE gt_char_atinn WITH KEY atnam = zsdc_roll_width"CMS31694
        READ TABLE gt_char_atinn WITH KEY atnam = gv_roll_width "CMS31694
                                          BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

      WHEN 'BA'.
* Item Height Metric
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_item_height_metric
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

* Item Length Metric
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_item_length_metric
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

* Item Width Metric
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_item_width_metric
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

* Bales Per Batch
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_bales_per_batch
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.
* >> Begin of V4W2 Changes - CCHERUP
      WHEN 'KAR' OR 'SKD'.
* Height Total
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_height_total
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

* Pallet Length
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_pallet_length
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.

* Pallet Width
        CLEAR gt_char_atinn.
        READ TABLE gt_char_atinn WITH KEY
                                 atnam = zsdc_pallet_width
                                 BINARY SEARCH.
        IF sy-subrc EQ 0.
          gt_char_name-atinn = gt_char_atinn-atinn.
          APPEND gt_char_name.
          CLEAR  gt_char_name.
        ENDIF.
* << End of V4W2 Changes - CCHERUP
    ENDCASE.
  ENDIF.

**Begin insert by jpieri - PRICEF 01298 CR# 10132
  LOOP AT gt_atnam.
    READ TABLE gt_char_atinn WITH KEY atnam = gt_atnam.
    IF sy-subrc EQ 0.
      gt_char_name-atinn = gt_char_atinn-atinn.
      APPEND gt_char_name.
      CLEAR  gt_char_name.
    ENDIF.
  ENDLOOP.
**End insert by jpieri - PRICEF 01298 CR# 10132


ENDFORM.                    " get_reqd_batch_char_atinn

* >> Begin of Changes - CCHERUP - CR #6546

*&---------------------------------------------------------------------*
*&      Form  get_skid_cart_volume_batch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_skid_cart_volume_batch CHANGING cv_volume.

  DATA : lv_height_total    TYPE p DECIMALS 5,
         lv_pallet_length   TYPE p DECIMALS 5,
         lv_pallet_width    TYPE p DECIMALS 5,
         lv_skid_ctn_volume TYPE p DECIMALS 5,
         lv_char_value      TYPE atwrt.

  CONSTANTS : lc_7645548 TYPE p DECIMALS 7  VALUE '0.7645548',
              lc_46656   TYPE p DECIMALS 5  VALUE '46656'.


  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_height_total
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_height_total = lv_char_value.
    ENDIF.
  ENDIF.

  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_pallet_length
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_pallet_length = lv_char_value.
    ENDIF.
  ENDIF.

  CLEAR gt_object_data.
  READ TABLE gt_object_data WITH KEY atnam = zsdc_pallet_width
                                     BINARY SEARCH.
  IF sy-subrc EQ 0.
    PERFORM float_char_conversion USING gt_object_data-atflv
                               CHANGING lv_char_value.
    IF lv_char_value GT 0.
      lv_pallet_width = lv_char_value.
    ENDIF.
  ENDIF.

  IF lv_height_total  IS NOT INITIAL OR
     lv_pallet_length IS NOT INITIAL OR
     lv_pallet_width  IS NOT INITIAL.
    CLEAR lv_skid_ctn_volume.
    lv_skid_ctn_volume = ( lv_height_total * lv_pallet_length *
                         lv_pallet_width ).
    lv_skid_ctn_volume    = ( ( lv_skid_ctn_volume / lc_46656 ) ).
    "46656 cu in=1 cu yd

    lv_skid_ctn_volume    = lv_skid_ctn_volume * lc_7645548.
    cv_volume = lv_skid_ctn_volume.
  ENDIF.

ENDFORM.                    "get_skid_cart_volume_batch

*&---------------------------------------------------------------------*
*&      Form  get_skid_cart_volume_nonbatch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_skid_cart_volume_nonbatch CHANGING cv_volume.

  DATA : lv_height_total    TYPE p DECIMALS 5,
         lv_pallet_length   TYPE p DECIMALS 5,
         lv_pallet_width    TYPE p DECIMALS 5,
         lv_skid_ctn_volume TYPE p DECIMALS 5.

  CONSTANTS : lc_7645548 TYPE p DECIMALS 7  VALUE '0.7645548',
              lc_46656   TYPE p DECIMALS 5  VALUE '46656'.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_height_total
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_height_total = gt_conf_out-atwrt.
  ENDIF.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_pallet_length
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_pallet_length = gt_conf_out-atwrt.
  ENDIF.

  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_pallet_width
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    REPLACE ',' WITH space INTO gt_conf_out-atwrt.
    IF sy-subrc EQ 0.
      CONDENSE gt_conf_out-atwrt NO-GAPS.
    ENDIF.
    lv_pallet_width = gt_conf_out-atwrt.
  ENDIF.

  IF lv_height_total  IS NOT INITIAL OR
     lv_pallet_length IS NOT INITIAL OR
     lv_pallet_width  IS NOT INITIAL.
    CLEAR lv_skid_ctn_volume.
    lv_skid_ctn_volume = ( lv_height_total * lv_pallet_length *
                         lv_pallet_width ).
    lv_skid_ctn_volume    = ( ( lv_skid_ctn_volume / lc_46656 ) ).
    "46656 cu in=1 cu yd

    lv_skid_ctn_volume    = lv_skid_ctn_volume * lc_7645548.
    cv_volume = lv_skid_ctn_volume.
  ENDIF.

ENDFORM.                    " get_skid_cart_volume_nonbatch

* << End of Changes - CCHERUP - CR #6546


* >> Begin of change - CCHERUP - CR8056/TPR25002
*&---------------------------------------------------------------------*
*&      Form  GET_EKKO_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_ekko_data .

  SELECT ebeln bsart zzvbeln zzposnr
         INTO TABLE gt_ekko
         FROM ekko
         FOR ALL ENTRIES IN gt_delv_data
         WHERE ebeln EQ gt_delv_data-vgbel.
  IF sy-subrc EQ 0.
    SORT gt_ekko.
  ENDIF.

ENDFORM.                    " GET_EKKO_DATA
*&---------------------------------------------------------------------*
*&      Form  GET_EKKN_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_ekkn_data .

  DATA : BEGIN OF lt_ekkn_lips OCCURS 0,
           vgbel LIKE ekkn-ebeln,
           vgpos LIKE ekkn-ebelp,                        " NUMC 5
         END OF lt_ekkn_lips,
         lt_delv_data LIKE gt_delv_data OCCURS 0 WITH HEADER LINE.

  REFRESH lt_delv_data.
  CLEAR   lt_delv_data.
  lt_delv_data[] = gt_delv_data[].
  SORT lt_delv_data BY vgbel vgpos.
  DELETE ADJACENT DUPLICATES FROM lt_delv_data COMPARING vgbel vgpos.
* >> since LIPS-VGPOS is NUMC 6 and EKKN-EBELP is NUMC 5, populating
*    LIPS-VGPOS into another internal table
  LOOP AT gt_delv_data.
    lt_ekkn_lips-vgbel = gt_delv_data-vgbel.
    lt_ekkn_lips-vgpos = gt_delv_data-vgpos.
    APPEND lt_ekkn_lips.
    CLEAR  lt_ekkn_lips.
  ENDLOOP.
  SORT lt_ekkn_lips.
  SELECT ebeln ebelp vbeln vbelp
         INTO TABLE gt_ekkn
         FROM ekkn
         FOR ALL ENTRIES IN lt_ekkn_lips
         WHERE ebeln EQ lt_ekkn_lips-vgbel AND
               ebelp EQ lt_ekkn_lips-vgpos.
  IF sy-subrc EQ 0.
    SORT gt_ekkn.
  ENDIF.

ENDFORM.                    " GET_EKKN_DATA



*----------------------------------------------------------------------*
*       Form  GET_SALES_TOLERANCES
*----------------------------------------------------------------------*
* This form calculates the Tolerances in Sales Units.
*
* Assumption: The tolerance quantity is in the unit of measure that
* corresponds to the entered unit of measure.
* i.e. entered in MASS dimension (i.e. LBS, KGS, TONNES etc) --
* calculate in LBS
* i.e. entered in LENGTH dimension (i.e. LF, SF, MSF including ZSF,ZLF
* ZLM etc.) -- calculate in LF
* i.e. entered in AAAADL ('units') (i.e. non-dimensional,except for ZSF/
* ZLF/ZLM etc.) -- calculate in Units.
*
* Units = rolls for rolls, pallets for carton product,
*         skids for skidded product.
*
* Assumption: All materials have units of measure maintained to permit
* conversion, or not maintained prohibiting it's entry (i.e. bales in
* any UoM other than pounds.)
*----------------------------------------------------------------------*
FORM get_sales_tolerances .

  DATA : lv_unitofmeasure TYPE meins,
         lv_salesunitqty  TYPE menge_d,
         lv_dimid         TYPE dimid.


  IF gt_delv_data-charg IS INITIAL.
    IF gv_packed IS INITIAL.
      PERFORM get_sales_uom_qty CHANGING lv_unitofmeasure
                                         lv_salesunitqty.
      SELECT SINGLE dimid
             FROM   t006
             INTO   lv_dimid
             WHERE  msehi EQ lv_unitofmeasure.

      CLEAR : gv_sales_tol_qty, gv_sales_tol_uom.

      CASE gv_uom.
        WHEN 'RL'.
* >> Begin of change - CC02
          PERFORM get_dimid_non_dimid_tolerances USING lv_dimid
                                                       lv_unitofmeasure
                                                       lv_salesunitqty.
*          IF gv_mto_mts EQ 'MTO'.
*            PERFORM get_dimid_non_dimid_tolerances
*                                                  USING lv_dimid
*                                                       lv_unitofmeasure
*                                                       lv_salesunitqty.
*          ELSEIF gv_mto_mts EQ 'MTS'.
*            PERFORM qty_unit_conversion USING gt_delv_data-matnr
*                                              lv_unitofmeasure"Curr UOM
*                                              lv_salesunitqty "Curr Qty
*                                              'RL'      " New UOM
*                                     CHANGING gv_sales_tol_qty.
*          ENDIF.
* << End of change - CC02
        WHEN 'BA'.
          PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                            lv_unitofmeasure " Curr UOM
                                            lv_salesunitqty  " Curr Qty
                                            'LB'      " New UOM
                                   CHANGING gv_sales_tol_qty.
        WHEN 'KAR'.
* >> Begin of change - CC02
          PERFORM get_dimid_non_dimid_tolerances USING lv_dimid
                                                       lv_unitofmeasure
                                                       lv_salesunitqty.
*          PERFORM qty_unit_conversion USING gt_delv_data-matnr
*                                            lv_unitofmeasure " Curr UOM
*                                            lv_salesunitqty  " Curr Qty
*                                            "'KAR'      " New UOM
*                                            'PAL'           " CC01
*                                   CHANGING gv_sales_tol_qty.
* << End of change - CC02
        WHEN 'SKD'.
* >> Begin of change - CC02
          PERFORM get_dimid_non_dimid_tolerances USING lv_dimid
                                                       lv_unitofmeasure
                                                       lv_salesunitqty.
*          IF gv_mto_mts EQ 'MTO'.
*            PERFORM qty_unit_conversion USING gt_delv_data-matnr
*                                             lv_unitofmeasure"Curr UOM
*                                             lv_salesunitqty "Curr Qty
*                                              'SKD'      " New UOM
*                                     CHANGING gv_sales_tol_qty.
*          ELSEIF gv_mto_mts EQ 'MTS'.

*          PERFORM qty_unit_conversion USING gt_delv_data-matnr
*                                            lv_unitofmeasure " Curr UOM
*                                            lv_salesunitqty  " Curr Qty
*                                            "'MSH'      " New UOM
*                                            'SKD'           " CC01
*                                   CHANGING gv_sales_tol_qty.
          "gv_sales_tol_qty = gv_sales_tol_qty * 1000.    " CC01
*          ENDIF.
* << End of change - CC02
      ENDCASE.

      IF gv_sales_tol_qty IS INITIAL.
        gv_sales_tol_qty = gv_no_units.
      ENDIF.
      PERFORM get_min_max_sales_tolerances.
    ENDIF.
  ENDIF.

ENDFORM.                    " GET_SALES_TOLERANCES
*&---------------------------------------------------------------------*
*&      Form  GET_SALES_UOM_QTY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_sales_uom_qty  CHANGING cv_unitofmeasure  TYPE meins
                                 cv_salesunitqty   TYPE menge_d.

  DATA    : lv_salord_number(10),
            lv_salord_item(6).

  IF gt_delv_data-vgtyp EQ 'V'.
    CLEAR gt_ekko.
    READ TABLE gt_ekko WITH KEY ebeln = gt_delv_data-vgbel
                                BINARY SEARCH.
    IF sy-subrc EQ 0.
      IF gt_ekko-zzvbeln IS NOT INITIAL OR
         gt_ekko-zzposnr IS NOT INITIAL.
        lv_salord_number = gt_ekko-zzvbeln.
        lv_salord_item   = gt_ekko-zzposnr.
      ELSE.
* Read the SO from EKKN
        READ TABLE gt_ekkn WITH KEY ebeln = gt_delv_data-vgbel
                                    ebelp = gt_delv_data-vgpos
                                    BINARY SEARCH.
        IF sy-subrc EQ 0.
          lv_salord_number = gt_ekkn-vbeln.
          lv_salord_item   = gt_ekkn-vbelp.
        ENDIF.
      ENDIF.
    ENDIF.

    IF lv_salord_number IS NOT INITIAL AND
       lv_salord_item   IS NOT INITIAL.
      SELECT SINGLE vrkme
             FROM   vbap
             INTO   cv_unitofmeasure
             WHERE  vbeln EQ lv_salord_number AND
                    posnr EQ lv_salord_item.
      IF sy-subrc EQ 0.
        PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                          gt_delv_data-vrkme " Curr UOM
                                          gt_delv_data-lfimg " Curr Qty
                                          cv_unitofmeasure   " New UOM
                                 CHANGING cv_salesunitqty.
      ENDIF.
    ENDIF.
  ENDIF.

  IF cv_unitofmeasure IS INITIAL.
    cv_unitofmeasure = gt_delv_data-vrkme.
  ENDIF.
  IF cv_salesunitqty IS INITIAL.
    cv_salesunitqty = gt_delv_data-lfimg.
  ENDIF.

ENDFORM.                    " GET_SALES_UOM_QTY
*&---------------------------------------------------------------------*
*&      Form  QTY_UNIT_CONVERSION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM qty_unit_conversion  USING iv_material  TYPE matnr
                                iv_curr_uom  TYPE vrkme
                                iv_curr_qty  TYPE lfimg
                                iv_new_uom   TYPE meins
                       CHANGING cv_new_qty   TYPE menge_d.

  DATA : lv_curr_uom LIKE t006-msehi,
         lv_new_uom  LIKE t006-msehi,
         lv_curr_qty LIKE vbdpl-volum,
         lv_new_qty  LIKE vbdpl-volum.

  lv_curr_uom = iv_curr_uom.
  lv_curr_qty = iv_curr_qty.
  lv_new_uom  = iv_new_uom.

  CALL FUNCTION 'Z_CF_UT_UNIT_CONVERSION'
    EXPORTING
      matnr_imp     = iv_material
      unit_new_imp  = lv_new_uom
      unit_old_imp  = lv_curr_uom
      value_old_imp = lv_curr_qty
    IMPORTING
      value_new_exp = lv_new_qty
    EXCEPTIONS
      overflow      = 1
      OTHERS        = 2.
  IF sy-subrc EQ 0.
    cv_new_qty = lv_new_qty.
  ELSE.
    cv_new_qty = lv_curr_qty.
  ENDIF.

  IF iv_new_uom EQ 'MSH'.
    gv_sales_tol_uom = 'SHT'.
  ELSE.
    gv_sales_tol_uom = iv_new_uom.
  ENDIF.

ENDFORM.                    " QTY_UNIT_CONVERSION
*&---------------------------------------------------------------------*
*&      Form  GET_DIMID_NON_DIMID_TOLERANCES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_dimid_non_dimid_tolerances  USING  iv_dimid TYPE dimid
                                            iv_uom   TYPE meins
                                            iv_qty   TYPE menge_d.

  CASE iv_dimid.
    WHEN 'MASS' OR 'LENGTH' OR 'SURFAC'.
      PERFORM get_tolerance_dimension     USING iv_dimid
                                                iv_uom
                                                iv_qty.
    WHEN 'AAAADL'.
      PERFORM get_tolerance_non_dimension USING iv_uom
                                                iv_qty.
  ENDCASE.

ENDFORM.                    " GET_DIMID_NON_DIMID_TOLERANCES
*&---------------------------------------------------------------------*
*&      Form  GET_TOLERANCE_DIMENSION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_tolerance_dimension  USING iv_dimid TYPE      dimid
                                    iv_uom   TYPE      meins
                                    iv_qty   TYPE      menge_d.

  DATA  lv_width_inches(10).

  CASE iv_dimid.
    WHEN 'MASS'.
*BEGIN of Insert PWADEHR CHG225256 CD# 2591
      SELECT SINGLE * FROM zdl_fields INTO @DATA(ls_zdl_fields)
                                      WHERE category = 'METRIC_CHAR'
                                      AND fieldname  = 'FACILITYID'
                                      AND lowval     = @gt_delv_data-werks.
      IF sy-subrc = 0.
        PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                          iv_uom    " Curr UOM
                                          iv_qty    " Curr Qty
                                          iv_uom    " New UOM
                                 CHANGING gv_sales_tol_qty.
      ELSE.
*END of Insert PWADEHR CHG225256 CD# 2591
        PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                          iv_uom    " Curr UOM
                                          iv_qty    " Curr Qty
                                          'LB'      " New UOM
                                 CHANGING gv_sales_tol_qty.
      ENDIF. "++ PWADEHR CHG225256 CD# 2591
    WHEN 'LENGTH'.
      PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                        iv_uom    " Curr UOM
                                        iv_qty    " Curr Qty
                                        'LF'      " New UOM
                               CHANGING gv_sales_tol_qty.
    WHEN 'SURFAC'.
      PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                        iv_uom    " Curr UOM
                                        iv_qty    " Curr Qty
                                        'SF'      " New UOM
                               CHANGING gv_sales_tol_qty.
      PERFORM get_width_inches CHANGING lv_width_inches.
      IF lv_width_inches LE 0.
        PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                          'SF'       " Curr UOM
                                          gv_sales_tol_qty " Curr Qty
                                          'LF'       " New UOM
                                 CHANGING gv_sales_tol_qty.
      ELSE.
        gv_sales_tol_qty = gv_sales_tol_qty * 12 / lv_width_inches.
        gv_sales_tol_uom = 'RL'.
      ENDIF.
  ENDCASE.

ENDFORM.                    " GET_TOLERANCE_DIMENSION
*&---------------------------------------------------------------------*
*&      Form  GET_WIDTH_INCHES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_width_inches  CHANGING cv_width_inches.

  DATA : lv_roll_width_whole(3),
         lv_roll_width_frac(10).

* ------ Roll Width Whole from VC Char
  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_roll_width_whole
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    lv_roll_width_whole = gt_conf_out-atwrt.
  ENDIF.

* ------ Decimal part of Roll Width from VC Char
  CLEAR gt_conf_out.
  READ TABLE gt_conf_out WITH KEY atnam = zsdc_roll_width_frac_dec_no_ws
                                  BINARY SEARCH.
  IF sy-subrc EQ 0.
    lv_roll_width_frac = gt_conf_out-atwrt.
  ENDIF.

  CLEAR cv_width_inches.
  cv_width_inches = lv_roll_width_whole + lv_roll_width_frac.
  CONDENSE cv_width_inches.

ENDFORM.                    " GET_WIDTH_INCHES
*&---------------------------------------------------------------------*
*&      Form  GET_TOLERANCE_NON_DIMENSION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_tolerance_non_dimension  USING iv_uom   TYPE  meins
                                        iv_qty   TYPE  menge_d.

  DATA  lv_width_inches(10).

  DATA lv_new_uom TYPE meins.

  CASE iv_uom.
    WHEN 'ZSF'.
      PERFORM get_width_inches CHANGING lv_width_inches.
      IF lv_width_inches LE 0.
        PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                          'ZSF'    " Curr UOM
                                          iv_qty   " Curr Qty
                                          'LF'     " New UOM
                                 CHANGING gv_sales_tol_qty.
        IF gv_sales_tol_qty IS INITIAL.
          PERFORM qty_unit_conversion USING gt_delv_data-matnr
                                            'MSF'  " Curr UOM
                                            iv_qty " Curr Qty
                                            'LF'   " New UOM
                                   CHANGING gv_sales_tol_qty.
        ENDIF.
      ELSE.
        gv_sales_tol_qty = iv_qty * 1000 / ( lv_width_inches / 12 ).
        gv_sales_tol_uom = 'SF'.
      ENDIF.
    WHEN 'ZLF'.
      gv_sales_tol_qty = iv_qty * 1000.
      gv_sales_tol_uom = 'LF'.
    WHEN 'ZLM'.
      gv_sales_tol_qty = iv_qty * 1000 * '3.28083989501'.
      gv_sales_tol_uom = 'LF'.
    WHEN OTHERS.
* >> Begin of Change - CC02
* Tolerance base value equals to planned unit qty calculate previously
* (this is b'coz the material master cannot hold accurate values for
*   configurable materials)
      gv_sales_tol_qty = gv_no_units.
      gv_sales_tol_uom = gv_uom.

*      IF iv_uom EQ 'RL'.
*        lv_new_uom = 'RL'.
*      ELSE.
*        IF gv_uom EQ 'KAR'. lv_new_uom = 'PAL'. ENDIF.
*        IF gv_uom EQ 'SKD'. lv_new_uom = 'SKD'. ENDIF.
*      ENDIF.
*      PERFORM qty_unit_conversion USING gt_delv_data-matnr
*                                        iv_uom  " Curr UOM
*                                        iv_qty  " Curr Qty
*                                        lv_new_uom
*                                        "'RL'   " New UOM
*                                        CHANGING gv_sales_tol_qty.
* << End of Change - CC02
  ENDCASE.

ENDFORM.                    " GET_TOLERANCE_NON_DIMENSION
*&---------------------------------------------------------------------*
*&      Form  GET_MIN_MAX_SALES_TOLERANCES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_min_max_sales_tolerances .

  DATA : lv_tolerance     TYPE menge_d,
         lv_max_tolerance TYPE menge_d,
         lv_min_tolerance TYPE menge_d.

  CLEAR : lv_tolerance, lv_max_tolerance, lv_min_tolerance.

* Calculating Over tolerance
  IF gv_uebto EQ '0.0'.
    lv_max_tolerance = gv_sales_tol_qty.
  ELSE.
    lv_tolerance = gv_sales_tol_qty +
                 ( gv_sales_tol_qty * gv_uebto / 100 ).
* Rounding to min value for Max Tolerance (34.1 or 34.5 = 34.0)
    lv_max_tolerance = floor( lv_tolerance ).
  ENDIF.

* Calculating Under tolerance
  CLEAR lv_tolerance.
  IF gv_untto EQ '0.0'.
    lv_min_tolerance = gv_sales_tol_qty.
  ELSE.
    lv_tolerance = gv_sales_tol_qty -
                 ( gv_sales_tol_qty * gv_untto / 100 ).
* Rounding to max value for Max Tolerance (29.1 or 29.7 = 30.0)
    lv_min_tolerance = floor( lv_tolerance + 1 ).
  ENDIF.

* If min > max, swap the values
  IF lv_min_tolerance > lv_max_tolerance.
    lv_tolerance = lv_max_tolerance.
    lv_max_tolerance = lv_min_tolerance.
    lv_min_tolerance = lv_tolerance.
  ENDIF.

  CLEAR :  gv_sales_uebqty, gv_sales_untqty.
  gv_sales_uebqty = lv_max_tolerance.
  gv_sales_untqty = lv_min_tolerance.

ENDFORM.                    " GET_MIN_MAX_SALES_TOLERANCES

* << End of change - CCHERUP - CR8056/TPR25002
*>> Begin change by kthakur  PRICEFI0197  TR # EDVK968126
*&---------------------------------------------------------------------*
*&      Form  GET_HU_DATA
*&---------------------------------------------------------------------*
*       Get Handling Unit Total for Shipment/Delivery
*----------------------------------------------------------------------*
*      -->P_LV_SHIP_DEL  text
*----------------------------------------------------------------------*
FORM get_hu_data .
  DATA : lv_vpobj             TYPE vpobj,
         lv_input             TYPE ntgew_15,
         lv_output            TYPE ntgew_15,
         lv_input_uom         TYPE gewei,
         lv_output_uom        TYPE gewei,
         lv_net_wt_delivery   LIKE gv_net_weight,
         lv_gross_wt_delivery LIKE gv_gross_weight,
         ls_vekp              LIKE LINE OF gt_vekp,
         ls_vepo_l            LIKE LINE OF gt_vepo_l,

         BEGIN OF lt_vpobjkey OCCURS 0,
           vpobjkey TYPE vpobjkey,
         END OF lt_vpobjkey,
         lt_vpobjkey_d LIKE lt_vpobjkey OCCURS 0
                                         WITH HEADER LINE .

*Clear all internal tables.
  CLEAR : gt_vekp, gt_vepo, gt_vepo_l.
  REFRESH: gt_vekp[], gt_vepo[], gt_vepo_l[].
* IF shipment 'T' then populate VPOBJ with '04' Shipment
  PERFORM  convert_shipment.
* Convert delivery number to vpobjkey format to get VEKP data.

  PERFORM  convert_delivery.
* Get data from VEKP for shipment
  IF NOT gt_vpobjkey[] IS INITIAL.
    PERFORM get_vekp_data.
  ENDIF.
* Get data from VEPO for shipment and delivery HU.
  IF NOT gt_vekp[] IS INITIAL.
    PERFORM get_vepo_data.
  ENDIF.
* Move data to internal table.
  PERFORM move_data_to_output_table.


ENDFORM.                    " GET_HU_DATA
*&---------------------------------------------------------------------*
*&      Form  CONVERT_WEIGHT_IN_LBS
*&---------------------------------------------------------------------*
*     Convert weight in LB if GEWEI is not LB
*----------------------------------------------------------------------*
*      -->P_LV_INPUT
*      -->P_LV_INPUT_UOM
*      -->P_LV_OUTPUT_UOM
*      <--P_LV_OUTPUT
*----------------------------------------------------------------------*
FORM convert_weight_in_lbs  USING    p_lv_input
                                     p_lv_input_uom
                                     p_lv_output_uom
                            CHANGING p_lv_output.
  CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
    EXPORTING
      input                = p_lv_input
*     NO_TYPE_CHECK        = 'X'
*     ROUND_SIGN           = ' '
      unit_in              = p_lv_input_uom
      unit_out             = p_lv_output_uom
    IMPORTING
*     ADD_CONST            =
*     DECIMALS             =
*     DENOMINATOR          =
*     NUMERATOR            =
      output               = p_lv_output
    EXCEPTIONS
      conversion_not_found = 1
      division_by_zero     = 2
      input_invalid        = 3
      output_invalid       = 4
      overflow             = 5
      type_invalid         = 6
      units_missing        = 7
      unit_in_not_found    = 8
      unit_out_not_found   = 9
      OTHERS               = 10.

  IF sy-subrc <> 0.
*                    MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*                    WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
    EXIT.
  ENDIF.




ENDFORM.                    " CONVERT_WEIGHT_IN_LBS
*>> End change by kthakur  PRICEFI0197  TR # EDVK968126

*&---------------------------------------------------------------------*
*&      Form  CONVERT_SHIPMENT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM convert_shipment.
  LOOP AT gt_shipments INTO gs_shipments.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = gs_shipments-tknum
      IMPORTING
        output = gs_shipments-tknum.

    gt_vpobjkey-vpobjkey = gs_shipments-tknum.
    APPEND gt_vpobjkey.
    CLEAR gt_vpobjkey.
  ENDLOOP.
ENDFORM.                    " CONVERT_SHIPMENT
*&---------------------------------------------------------------------*
*&      Form  CONVERT_DELIVERY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM convert_delivery .
  LOOP AT gt_vbeln  .
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = gt_vbeln-vbeln
      IMPORTING
        output = gt_vbeln-vbeln.

    gt_vpobjkey-vpobjkey = gt_vbeln-vbeln.
    APPEND gt_vpobjkey.
    CLEAR gt_vpobjkey.
  ENDLOOP.
ENDFORM.                    " CONVERT_DELIVERY
*&---------------------------------------------------------------------*
*&      Form  GET_VEKP_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM get_vekp_data .
  SELECT venum exidv vhilm magrv vhart vpobj vpobjkey
      INTO TABLE gt_vekp
      FROM vekp
      FOR ALL ENTRIES IN gt_vpobjkey
            WHERE vpobj IN ('01', '03', '04' ) "CMS33577 SMITHA1 05/23/2018
            AND   vpobjkey = gt_vpobjkey-vpobjkey
            AND   vhart = 'PKG'.
  CLEAR : gt_vpobjkey[],gt_vpobjkey.

ENDFORM.                    " GET_VEKP_DATA
*&---------------------------------------------------------------------*
*&      Form  GET_VEPO_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM get_vepo_data .
  SELECT venum vbeln posnr unvel
         INTO TABLE gt_vepo
         FROM vepo
         FOR ALL ENTRIES IN gt_vekp
         WHERE venum = gt_vekp-venum.
ENDFORM.                    " GET_VEPO_DATA

*&---------------------------------------------------------------------*
*&      Form  MOVE_DATA_TO_OUTPUT_TABLE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*

FORM move_data_to_output_table .
  DATA : lv_input             TYPE ntgew_15,
         lv_output            TYPE ntgew_15,
         lv_input_uom         TYPE gewei,
         lv_output_uom        TYPE gewei,
         lv_net_wt_delivery   LIKE gv_net_weight,
         lv_gross_wt_delivery LIKE gv_gross_weight,
         lv_vbeln             TYPE vbeln_vl,
         ls_vepo              LIKE LINE OF gt_vepo,
         ls_vekp              LIKE LINE OF gt_vekp.
  CLEAR : gv_net_weight,gv_gross_weight.

  gt_vepo_l[] = gt_vepo[].
  DELETE  gt_vepo_l WHERE unvel = ' '.

  LOOP AT gt_vekp.
    MOVE gt_vekp-vpobjkey TO  lv_vbeln.
    IF gt_vekp-vpobj = '04'.
      LOOP AT gt_vepo_l WHERE venum = gt_vekp-venum.
        LOOP AT gt_vepo WHERE venum = gt_vepo_l-unvel.
          READ TABLE gt_delv_data WITH KEY
                                        vbeln = gt_vepo-vbeln
                                        posnr = gt_vepo-posnr.
          IF sy-subrc = 0.
            IF gt_delv_data-gewei = 'LB'.
              gv_net_weight = gv_net_weight + gt_delv_data-ntgew.
              gv_gross_weight = gv_gross_weight +
                                gt_delv_data-brgew.
              lv_net_wt_delivery = lv_net_wt_delivery +
                                   gt_delv_data-ntgew.
              lv_gross_wt_delivery = lv_gross_wt_delivery +
                                     gt_delv_data-brgew.
            ELSE.
              lv_input_uom = gt_delv_data-gewei.
              lv_output_uom = 'LB'.
              lv_input = gt_delv_data-ntgew.
              PERFORM convert_weight_in_lbs USING lv_input
                                                  lv_input_uom
                                                  lv_output_uom
                                         CHANGING lv_output.
              gv_net_weight = gv_net_weight + lv_output.
              lv_net_wt_delivery = lv_net_wt_delivery + lv_output.
              CLEAR: lv_input,lv_output.
              PERFORM convert_weight_in_lbs USING lv_input
                                                   lv_input_uom
                                                   lv_output_uom
                                       CHANGING    lv_output.
              gv_gross_weight = gv_gross_weight + lv_output.
              lv_gross_wt_delivery = lv_gross_wt_delivery +
                                                 lv_output.
            ENDIF.
          ENDIF.
        ENDLOOP.
      ENDLOOP.
      IF sy-subrc = 0.
        gs_hu_contents-exidv  = gt_vekp-exidv.
        gs_hu_contents-venum  = gt_vekp-venum.
        gs_hu_contents-source = 'T'.  "Shipment
        gs_hu_contents-ntgew  = gv_net_weight.
        gs_hu_contents-brgew  = gv_gross_weight.
        gs_hu_contents-gewei  = 'LB'.
        gs_hu_contents-tknum  = gt_vekp-vpobjkey.
*            gs_HU_CONTENTS-vbeln  = gt_vekp-exidv.
        gs_hu_contents-vhilm  = gt_vekp-vhilm.
        gs_hu_contents-magrv  = gt_vekp-magrv.
        gs_hu_contents-vhart  = gt_vekp-vhart.
* Append HU output table at Shipment HU level
        APPEND  gs_hu_contents TO gt_hu_contents.
        CLEAR: gs_hu_contents,gv_net_weight,gv_gross_weight.
      ENDIF.
    ELSE.

      LOOP AT  gt_vepo  WHERE venum = gt_vekp-venum.

        READ TABLE gt_delv_data WITH KEY vbeln = gt_vepo-vbeln
                                         posnr = gt_vepo-posnr.
        IF sy-subrc = 0.
          IF gt_delv_data-gewei = 'LB'.
            gv_net_weight = gv_net_weight + gt_delv_data-ntgew.
            gv_gross_weight = gv_gross_weight + gt_delv_data-brgew.
            lv_net_wt_delivery = lv_net_wt_delivery +
                                                gt_delv_data-ntgew.

            lv_gross_wt_delivery = lv_gross_wt_delivery +
                                                gt_delv_data-brgew.
          ELSE.
            lv_input_uom = gt_delv_data-gewei.
            lv_output_uom = 'LB'.
            lv_input = gt_delv_data-ntgew.
            PERFORM convert_weight_in_lbs USING lv_input
                                                lv_input_uom
                                                lv_output_uom
                                       CHANGING lv_output.
            gv_net_weight = gv_net_weight + lv_output.
*               lv_net_wt_delivery = lv_net_wt_delivery + + lv_output.
            CLEAR: lv_input,lv_output.
            lv_input = gt_delv_data-brgew.
            PERFORM convert_weight_in_lbs USING lv_input
                                                lv_input_uom
                                                lv_output_uom
                                       CHANGING lv_output.
            gv_gross_weight = gv_gross_weight + lv_output.
            lv_gross_wt_delivery = lv_gross_wt_delivery + lv_output.

          ENDIF.
        ENDIF.

      ENDLOOP.
      IF sy-subrc = 0.
        READ TABLE gt_vepo INTO ls_vepo WITH  KEY
                                unvel = gt_vekp-venum.
        IF sy-subrc = 0.
          READ TABLE gt_vekp INTO ls_vekp WITH  KEY
                                venum = ls_vepo-venum.
          IF sy-subrc = 0.
            gs_hu_contents-tknum    = ls_vekp-vpobjkey.
            gs_hu_contents-h_exidv  = ls_vekp-exidv.
            gs_hu_contents-uevel    = ls_vekp-venum.
          ENDIF.
        ENDIF.
        IF gs_hu_contents-tknum IS INITIAL.

          CLEAR gt_vbeln.
          READ TABLE gt_vbeln WITH KEY  vbeln = gt_vepo-vbeln.
          gs_hu_contents-tknum    = gt_vbeln-tknum.
        ENDIF.

*          endif.
        gs_hu_contents-exidv  = gt_vekp-exidv.
        gs_hu_contents-venum  = gt_vekp-venum.
        gs_hu_contents-source = 'L'. "P_LV_SHIP_DEL.
        gs_hu_contents-ntgew  = gv_net_weight.
        gs_hu_contents-brgew  = gv_gross_weight.
        gs_hu_contents-gewei  = 'LB'.
*         gs_HU_CONTENTS-tknum  = gt_vekp-VPOBJKEY.
        gs_hu_contents-vbeln  = gt_vepo-vbeln.
        gs_hu_contents-vhilm  = gt_vekp-vhilm.
        gs_hu_contents-magrv  = gt_vekp-magrv.
        gs_hu_contents-vhart  = gt_vekp-vhart.

* Append HU output table at Shipment HU level
        APPEND  gs_hu_contents TO gt_hu_contents.
        CLEAR: gs_hu_contents,gv_net_weight,gv_gross_weight.
      ENDIF.
    ENDIF.
  ENDLOOP.


ENDFORM.                    " MOVE_DATA_TO_OUTPUT_TABLE

FORM get_plants_zdl_fields.                                 "CMS31694

  SELECT * FROM zdl_fields INTO TABLE gt_zdl_fields
    WHERE category = 'METRIC_CHAR' AND
          fieldname = 'FACILITYID'.

ENDFORM.

FORM get_plant_specific_char USING pv_werks TYPE marc-werks. "CMS31694

  CLEAR gv_flag_metric.

  IF line_exists( gt_zdl_fields[ lowval = pv_werks ] ).

    gv_flag_metric = abap_true.

    gv_unit_weight   = zsdc_unit_weight_m.
    gv_roll_diameter = zsdc_roll_diameter_m.
    gv_roll_width    = zsdc_roll_width_m.

    gv_lineal_char   = zsdc_lineal_meters_m.
  ELSE.
    gv_unit_weight   = zsdc_unit_weight.
    gv_roll_diameter = zsdc_roll_diameter.
    gv_roll_width    = zsdc_roll_width.
    gv_lineal_char   = zsdc_lineal_footage.
  ENDIF.
ENDFORM.

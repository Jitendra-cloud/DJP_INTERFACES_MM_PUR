*&---------------------------------------------------------------------*
*&  Include           ZDL_C10156_INVENTORY_SCREEN
*&---------------------------------------------------------------------*

* Create Excel Template
SELECTION-SCREEN FUNCTION KEY 1.  "Will have a function code of 'FC01'

********************************************************************
"Process radio buttons
SELECTION-SCREEN: BEGIN OF BLOCK b0 WITH FRAME TITLE TEXT-s01.
PARAMETERS: p_bat    RADIOBUTTON GROUP rb1 USER-COMMAND cl3 DEFAULT 'X', "Batch Create
            p_goods  RADIOBUTTON GROUP rb1, "Goods receipts
            p_uni    RADIOBUTTON GROUP rb1, "Handling units
            p_goodre RADIOBUTTON GROUP rb1. "Goods receipt reversal


***********************************************************************
SELECTION-SCREEN: BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-s02.
PARAMETERS: p_prod  TYPE zzgroupset OBLIGATORY AS LISTBOX VISIBLE LENGTH 20,
            p_pdate TYPE budat DEFAULT sy-datlo MODIF ID pdt,
            p_cb_gr AS CHECKBOX DEFAULT 'X'     MODIF ID prd,
            p_cb_re AS CHECKBOX DEFAULT 'X'     MODIF ID grs.
PARAMETERS: p_rb_bpi RADIOBUTTON GROUP gr1 DEFAULT 'X' MODIF ID grs,
            p_rb_562 RADIOBUTTON GROUP gr1 MODIF ID grs.
SELECTION-SCREEN: END OF BLOCK b1,
**********************************************************************
                  BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-s03,
                  BEGIN OF LINE.
PARAMETERS p_local RADIOBUTTON GROUP rb3 DEFAULT 'X' USER-COMMAND cl4.
SELECTION-SCREEN: COMMENT 2(12) TEXT-s04 FOR FIELD p_local,
                  POSITION 32.
PARAMETERS p_loc1 TYPE string MODIF ID loc. "DEFAULT 'Upload from PC'.
SELECTION-SCREEN: END OF LINE,

                  BEGIN OF LINE.
PARAMETERS p_app RADIOBUTTON GROUP rb3.
SELECTION-SCREEN: COMMENT 2(10) TEXT-s05 FOR FIELD p_app,
                  POSITION 32.
PARAMETERS p_serv TYPE string MODIF ID app.
SELECTION-SCREEN: END OF LINE,
                  END OF BLOCK b2,
**************************************************************************
                  BEGIN OF BLOCK b3 WITH FRAME TITLE TEXT-s06.
PARAMETERS: p_test   RADIOBUTTON GROUP rb4 DEFAULT 'X' USER-COMMAND cl4,
            p_update RADIOBUTTON GROUP rb4,     "CD2000007614
            p_excep AS CHECKBOX.                "CD2000007614
SELECTION-SCREEN: BEGIN OF LINE,
                  COMMENT 12(20) TEXT-s09 MODIF ID for.
PARAMETERS p_fore RADIOBUTTON GROUP rb5 DEFAULT 'X' USER-COMMAND cl5 MODIF ID for.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN: BEGIN OF LINE,
                  COMMENT 12(20) TEXT-s10 MODIF ID bgr.
PARAMETERS p_back RADIOBUTTON GROUP rb5 MODIF ID bgr.
SELECTION-SCREEN: END OF LINE,

*                  BEGIN OF LINE.
*                  COMMENT 12(20) TEXT-s07 MODIF ID bac.
**PARAMETERS p_jname TYPE cnv_frm_job_name MODIF ID bac.
*SELECTION-SCREEN: END OF LINE,
*
*                  BEGIN OF LINE,
*                  COMMENT 12(20) TEXT-s08 MODIF ID bac.
*PARAMETERS p_var TYPE cnv_frm_job_name MODIF ID bac.
*SELECTION-SCREEN: END OF LINE,
                  END OF BLOCK b3,
*********************************************************************
                  BEGIN OF BLOCK b4 WITH FRAME TITLE TEXT-s11,
                  COMMENT 1(31) TEXT-s12 MODIF ID txt.
PARAMETERS: p_alv_t TYPE boolean AS CHECKBOX MODIF ID txt,
            p_trans TYPE string, " MODIF ID bac,
            p_error TYPE string, " MODIF ID bac,
            p_succ  TYPE string. " MODIF ID bac.

SELECTION-SCREEN: END OF BLOCK b4,
                  END OF BLOCK b0.
**********************************************************************

class ZCL_IM_DL_E03637_DELV_PROC definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_LE_SHP_DELIVERY_PROC .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_DL_E03637_DELV_PROC IMPLEMENTATION.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_HEADER.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FCODE_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FIELD_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHECK_ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_FINAL_CHECK.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DOCUMENT_NUMBER_PUBLISH.
  endmethod.


  method if_ex_le_shp_delivery_proc~fill_delivery_header.

* J.Grabowiecki E0V CMS 33303
* RFSCOP E03637 DLK delivery - handle delivery LIKP-Z*fields ( copy from inbound to outbound delivery)
* Export of IT_EXTENSION_IN done in BADI ZDL_E03637_DLV_CREATE_SLS_EXT of BADI_DLV_CREATE_SLS_EXTIN,
* method ADDITIONAL_INPUT

    data: lt_ext   type bapiparex_t.
    data: ls_ext   type bapiparex.
    data: lv_field type string.
    field-symbols: <lv_val> type any.

    import it_extension_in to lt_ext from memory id 'ZDLE03637_DLV_EXTEN'.

    loop at lt_ext into ls_ext.
      case ls_ext-structure.
        when 'LIKP'.
          lv_field = 'CS_LIKP-' && ls_ext-valuepart1.
          assign (lv_field) to <lv_val>.
          if sy-subrc = 0.
            <lv_val> = ls_ext-valuepart2.
          endif.
      endcase.
    endloop.
    delete from memory id 'ZDLE03637_DLV_EXTEN'.

  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~INITIALIZE_DELIVERY.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~PUBLISH_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~READ_DELIVERY.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_BEFORE_OUTPUT.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_DOCUMENT.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_DOCUMENT_PREPARE.
  endmethod.
ENDCLASS.

class ZCL_F01276_USR_ID_NUM_VAL definition
  public
  final
  create public .

*"* public components of class ZCL_F01276_USR_ID_NUM_VAL
*"* do not include other source files here!!!
public section.

  methods CHARACTERISTIC_NUM_VAL
    importing
      !IV_VALUE_IN type ATWRT
    exporting
      !IV_VALUE_OUT type ATWRT .
protected section.
*"* protected components of class ZCL_F01276_USR_ID_NUM_VAL
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_F01276_USR_ID_NUM_VAL
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_F01276_USR_ID_NUM_VAL IMPLEMENTATION.


method CHARACTERISTIC_NUM_VAL .

Data: ls_usr01      Type usr01,
      lv_value      Like iv_value_in.

 Select single * into ls_usr01
   from Usr01
   where bname eq sy-uname.

 Check sy-subrc eq 0.

 Case: ls_usr01-Dcpfm.
*X=1,234,567.89 (Replace ',' with '')
   When 'X'.
     iv_value_out = iv_value_in.
     replace all occurrences of ',' in iv_value_out with ''.

*Y=1 234 567,89 (Replace ' ' with ''  - then  Replace ',' with '.')
   When 'Y'.
     lv_value = iv_value_in.
     condense lv_value no-gaps.
     replace ',' in lv_value with '.'.
*     write: lv_value to iv_value_out right-justified.
     write: lv_value to iv_value_out.

* =1.234.567,89 (Replace '.' with ''  - then  Replace ',' with '.')
   When Others.
     iv_value_out = iv_value_in.
     replace all occurrences of '.' in iv_value_out with ''.
     replace ',' in iv_value_out with '.'.

 Endcase.

endmethod.
ENDCLASS.

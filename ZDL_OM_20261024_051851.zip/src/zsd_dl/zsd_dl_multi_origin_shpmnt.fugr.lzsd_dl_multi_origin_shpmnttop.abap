FUNCTION-POOL zsd_dl_multi_origin_shpmnt.   "MESSAGE-ID ..

DATA  lt_vpobjkey.
TABLES     : ibinval_sel_f,
             zdl_fields,
             vbap,vttk, vtts, vttp.

TYPE-POOLS : zmos, zsdc.

************************************************************************
* Data Declaration for Itinerary View Function Module
************************************************************************

DATA : gs_deliveries   TYPE  zmos_deliveries,
       gs_date_time    TYPE  zmos_date_time,
       gs_control_data TYPE  zmos_control_data,
       gs_itinerary    TYPE  zmos_itinerary,
       gs_vttk         LIKE  vttkvb.

* >> Internal table for Stop data
DATA : BEGIN OF gt_stops OCCURS 0,
         seqnm        TYPE  zstopseq,
         stpty        TYPE  zstpty,
         location(10),
         loc_ind,
         tsrfo        TYPE  tsrfo,
         tsnum        TYPE  tsnum,
         itnum        TYPE  zitnum,
         vbeln        TYPE  vbeln,
       END OF gt_stops,

* >> Internal table for Stage data
       BEGIN OF gt_stage_data OCCURS 0,
         tsrfo LIKE  vtts-tsrfo,
         tsnum LIKE  vtts-tsnum,
         tpnum LIKE  vtsp-tpnum,
         vbeln LIKE  vttp-vbeln,
         vstel LIKE  vtts-vstel,
         werka LIKE  vtts-werka,
         kunna LIKE  vtts-kunna,
         lifna LIKE  vtts-lifna,
         vstez LIKE  vtts-vstez,
         werkz LIKE  vtts-werkz,
         kunnz LIKE  vtts-kunnz,
         lifnz LIKE  vtts-lifnz,
       END OF gt_stage_data.

DATA : gt_curr_stage   LIKE  gt_stage_data   OCCURS 0 WITH HEADER LINE,
       gt_prev_stage   LIKE  gt_stage_data   OCCURS 0 WITH HEADER LINE,
       gt_next_stage   LIKE  gt_stage_data   OCCURS 0 WITH HEADER LINE,
       gt_deliveries   LIKE  gs_deliveries   OCCURS 0 WITH HEADER LINE,
       gt_date_time    LIKE  gs_date_time    OCCURS 0 WITH HEADER LINE,
       gt_control_data LIKE  gs_control_data OCCURS 0 WITH HEADER LINE,
       gt_itinerary    LIKE  gs_itinerary    OCCURS 0 WITH HEADER LINE,
       gt_vttk         LIKE  vttk            OCCURS 0 WITH HEADER LINE,
       gt_vttp         LIKE  vttpvb          OCCURS 0 WITH HEADER LINE,
       gt_vtts         LIKE  vttsvb          OCCURS 0 WITH HEADER LINE,
       gt_vtsp         LIKE  vtspvb          OCCURS 0 WITH HEADER LINE,
       gt_vtts_copy    LIKE  gt_vtts         OCCURS 0 WITH HEADER LINE,
       gt_vbplk        LIKE  vbplk          OCCURS 0 WITH HEADER LINE,
       gt_vbplp        LIKE  vbplp          OCCURS 0 WITH HEADER LINE.

DATA : gv_stage_count TYPE  i,
       gv_delv_count  TYPE  i,
       gv_vstel_count TYPE  i,
       gv_kunnr_count TYPE  i,
       gv_lifnr_count TYPE  i,
       gv_first_stop  TYPE  zstopseq,
       gv_last_stop   TYPE  zstopseq,
       gv_mos_ind     TYPE  zsd_dl_multi_origin_shpmnt_ind.



************************************************************************
* Data Declaration for Common Units Function Module
************************************************************************

*TYPES : BEGIN OF tt_guidance_header,
*          shipment_number   TYPE  tknum,
*          ship_to(20),
*          ship_from(20),
*          vehicle_resource(40),
*          ship_load_start(15) TYPE  p,
*          ship_load_end(15)   TYPE  p,
*          transport_start(15) TYPE  p,
*          transport_end(15)   TYPE  p,
*        END OF tt_guidance_header.

TYPES : BEGIN OF tt_delivery_roll,
          shipment      TYPE tknum,
          delivery      LIKE vbak-vbeln,
          delivery_item TYPE posnr_vl,
          num_rolls     TYPE int4,
        END OF tt_delivery_roll.

TYPES : BEGIN OF tt_shipment_no ,
          shipment TYPE tknum,
        END OF tt_shipment_no .

DATA :  gt_delivery_roll TYPE tt_delivery_roll OCCURS 0 .

FIELD-SYMBOLS:  <ls_delivery>  TYPE  tt_delivery_roll.

DATA : gs_shipment TYPE tt_shipment_no  .
DATA : gt_shipment_no TYPE TABLE OF tknum .


*DATA   : gt_guidance_header TYPE tt_guidance_header OCCURS 0.

* >> Constants
CONSTANTS : gc_wp_kg_netto_st     TYPE  atnam
                                            VALUE 'WP_KG_NETTO_ST',
*
            gc_roll_diameter      TYPE  atnam
                                            VALUE 'ROLL_DIAMETER',
            gc_roll_width         TYPE  atnam
                                            VALUE 'ROLL_WIDTH',
            gc_item_height_metric TYPE  atnam
                                            VALUE 'ITEM_HEIGHT_METRIC',
            gc_item_length_metric TYPE  atnam
                                            VALUE 'ITEM_LENGTH_METRIC',
            gc_item_width_metric  TYPE  atnam
                                            VALUE 'ITEM_WIDTH_METRIC',
*
            gc_pi                 TYPE p DECIMALS 5  VALUE '3.14159',
            gc_cu_yd              TYPE p DECIMALS 5  VALUE '46656',
            gc_46656              TYPE p DECIMALS 5  VALUE '46656',
            gc_7645548            TYPE p DECIMALS 7  VALUE '0.7645548',
            gc_1000000            TYPE p DECIMALS 5  VALUE '1000000',
*
            gc_m3(03)             TYPE c VALUE 'M3 '.    "Cubic Meters

*            gc_manufacturing_plant    TYPE  atnam
*                                            VALUE
*'MANUFACTURING_PLANT',
*            gc_roll_width             TYPE  atnam
*                                            VALUE 'ROLL_WIDTH'.

* >> Variables
DATA      : gv_no_packages      TYPE  anzpk,
            gv_no_units         TYPE  anzpk,
            gv_units_package    TYPE  anzpk,
            gv_uom              TYPE  lrmei,
            gv_ntgew            TYPE  ntgew_15,
            gv_brgew            TYPE  brgew_15,
            gv_uebto            TYPE  uebto,
            gv_untto            TYPE  untto,
            gv_uebqty           TYPE  ntgew_15,
            gv_untqty           TYPE  brgew_15,
            gv_net_weight       TYPE  ntgew_15,
            gv_gross_weight     TYPE  brgew_15,
            gv_batch_line_count TYPE  i,
            gv_packed.

DATA      : gs_shipments       TYPE  zmos_shipment,
            gt_shipments       LIKE  gs_shipments
                                       OCCURS 0 WITH HEADER LINE,
            gs_delivery        TYPE  zmos_delivery,
            gt_delivery        LIKE  gs_delivery
                                       OCCURS 0 WITH HEADER LINE,
            gs_delivery_items  TYPE  zmos_delivery_item,
            gt_delivery_items  LIKE  gs_delivery_items
                                       OCCURS 0 WITH HEADER LINE,
            gs_ship_units      TYPE  zmos_ship_units,
            gt_ship_units      LIKE  gs_ship_units
                                       OCCURS 0 WITH HEADER LINE,
            gs_delv_units      TYPE  zmos_delv_units,
            gt_delv_units      LIKE  gs_delv_units
                                       OCCURS 0 WITH HEADER LINE,
            gs_delv_item_units TYPE  zmos_delv_item_units,
            gt_delv_item_units LIKE  gs_delv_item_units
                                       OCCURS 0 WITH HEADER LINE,
*Begin insert by jpieri PRICEF 01298 CR# 10132
            gs_atnam           TYPE atnam,
            gt_atnam           LIKE gs_atnam
                                      OCCURS 0 WITH HEADER LINE,
*End insert by jpieri PRICEF 01298 CR# 10132
*
* begin insert   By kthakur   PRICEFI0197_CORI02419
* TR# EDVK968126
            gs_hu_contents     TYPE      zmos_hu_contents,
            gt_hu_contents     LIKE      gs_hu_contents
                                       OCCURS 0 WITH HEADER LINE.

* End insert by kthakur




TYPES     : BEGIN OF gs_confout.
        INCLUDE STRUCTURE conf_out.
TYPES     : END OF gs_confout.

TYPES     : gt_confout TYPE gs_confout OCCURS 0.

TYPES     : BEGIN OF gs_marc_vc_char,
              werks   TYPE werks_d,
              matnr   TYPE matnr,
              confout TYPE gt_confout,
            END OF gs_marc_vc_char.

DATA      : gt_marc_vc_char TYPE gs_marc_vc_char
                                 OCCURS 0 WITH HEADER LINE,
            gs_conf_out     TYPE LINE OF gt_confout.

DATA      : gv_marc_cuobj    TYPE  cuobj,
            gv_lips_cuobj    TYPE  cuobj,
            gv_zzwgt_roll    TYPE  zz_wgt_roll,
            gv_order         TYPE  vbeln,
            gv_kunnr         TYPE  kunnr,
            gv_atflv         TYPE  atflv,
*
            gv_cuobj_bm      TYPE cuobj_bm, "MCH1-Object Num
            gv_volume        TYPE  volum,          "Volume     dec 3
            gv_voluom        TYPE  meins,          "Volume UOM
            gv_volume_sum    TYPE p DECIMALS 5,    "Volume Sum dec 5
            gv_volume_batch  TYPE p DECIMALS 5,    "Volume
            gv_voluom_batch  TYPE  meins,          "Volume UOM

* >> Begin of change - CCHERUP - CR8056/TPR25002
            gv_sales_tol_qty TYPE menge_d,
            gv_sales_tol_uom TYPE meins,
            gv_sales_uebqty  TYPE menge_d,
            gv_sales_untqty  TYPE menge_d,
            gv_mto_mts(3),
* << End of change - CCHERUP - CR8056/TPR25002
* >> Begin of change -kthakur  PRICEFI0197_CORI02419
            gv_tknum         TYPE tknum,
            gv_vpobj         TYPE vpobj.
*<< End of change by kthakur PRICEFI0197_CORI02419
DATA      : BEGIN OF gt_delv_data OCCURS 0,
              vbeln TYPE  vbeln,
              posnr TYPE  posnr,
              matnr TYPE  matnr,
              matkl TYPE  matkl,
              werks TYPE  werks_d,
              charg TYPE  charg_d,
              lfimg TYPE  lfimg,
              meins TYPE  meins,
              vrkme TYPE  vrkme,
              ntgew TYPE  ntgew_15,
              brgew TYPE  brgew_15,
              gewei TYPE  gewei,
              uebto TYPE  uebto,
              untto TYPE  untto,
              vgbel TYPE  vgbel,
              vgpos TYPE  vgpos,
              spart TYPE  spart,
              vgtyp TYPE  vbtyp,
              uecha TYPE  uecha,
              cuobj TYPE  cuobj,
            END OF gt_delv_data,

            BEGIN OF gt_vbeln OCCURS 0,
              tknum TYPE    tknum,
              tpnum TYPE    tpnum,
              vbeln TYPE    vbeln,
            END OF gt_vbeln,

            BEGIN OF gt_vbup OCCURS 0,
              vbeln TYPE  vbeln,
              posnr TYPE  posnr,
              kosta TYPE  kosta,
              pksta TYPE  pksta,
            END OF gt_vbup,

            BEGIN OF gt_marc_cuobj OCCURS 0,
              matnr TYPE    matnr,
              werks TYPE    werks_d,
              sobsl TYPE    sobsl,
              cuobj TYPE    cuobj,
            END OF gt_marc_cuobj,

            BEGIN OF gt_char_atinn OCCURS 0,
              atnam TYPE    atnam,
              atinn TYPE    atinn,
            END OF gt_char_atinn,

* >> Begin of change - CCHERUP - CR8056/TPR25002
            BEGIN OF gt_ekko OCCURS 0,
              ebeln   TYPE ebeln,
              bsart   TYPE bsart,
              zzvbeln TYPE vbeln,
              zzposnr TYPE posnr,
            END OF gt_ekko,

            BEGIN OF gt_ekkn OCCURS 0,
              ebeln TYPE ebeln,
              ebelp TYPE ebelp,
              vbeln TYPE vbeln,
              vbelp TYPE vbelp,
            END OF gt_ekkn,
* << End of change - CCHERUP - CR8056/TPR25002
* >> Begin of change -kthakur  PRICEFI0197_CORI02419

            BEGIN OF gt_vekp OCCURS 0,
              venum    TYPE venum,
              exidv    TYPE exidv,  "External
              vhilm    TYPE vhilm,  "Packing material
              magrv    TYPE magrv,  "Material Group: Packaging Materials
              vhart    TYPE vhart,  "Packaging Material Type
              vpobj    TYPE vpobj,
              vpobjkey TYPE vpobjkey,
            END OF gt_vekp,
            BEGIN OF gt_vepo OCCURS 0,
              venum    TYPE venum,
              vbeln    TYPE vbeln_vl,
              posnr    TYPE posnr,
              unvel    TYPE unvel,
              vpobj    TYPE vbobj,
              vpobjkey TYPE vpobjkey,
            END OF gt_vepo,
            gt_vepo_l   LIKE gt_vepo OCCURS 0 WITH HEADER LINE,
            gt_vekp_del LIKE gt_vekp OCCURS 0 WITH HEADER LINE,

            BEGIN OF gt_vpobjkey OCCURS 0,
              vpobjkey TYPE vpobjkey,
            END OF gt_vpobjkey,
*<< End of change by kthakur PRICEFI0197_CORI02419
            gt_vbup_copy       LIKE gt_vbup
                                  OCCURS 0 WITH HEADER LINE,

            gt_item_data       LIKE gt_delv_data
                                   OCCURS 0 WITH HEADER LINE,
            gt_conf_out        LIKE conf_out OCCURS 0 WITH HEADER LINE,

            gt_zdl_fields      TYPE STANDARD TABLE OF zdl_fields, "CMS31694

            gt_batch_char      TYPE zmos_batch_char
                                       OCCURS 0 WITH HEADER LINE,
            gt_delv_batch_char TYPE zmos_batch_char
                                       OCCURS 0 WITH HEADER LINE,
            gt_char_name       TYPE sel_char
                                       OCCURS 0 WITH HEADER LINE,
            gt_object_data     TYPE clobjdat OCCURS 2 WITH HEADER LINE.

DATA      : BEGIN OF gt_delv_data_temp OCCURS 0,
              vbeln TYPE  vbeln,
              posnr TYPE  posnr,
              matnr TYPE  matnr,
              matkl TYPE  matkl,
              werks TYPE  werks_d,
              charg TYPE  charg_d,
              lfimg TYPE  lfimg,
              meins TYPE  meins,
              vrkme TYPE  vrkme,
              ntgew TYPE  ntgew_15,
              brgew TYPE  brgew_15,
              gewei TYPE  gewei,
              uebto TYPE  uebto,
              untto TYPE  untto,
              vgbel TYPE  vgbel,
              vgpos TYPE  vgpos,
              spart TYPE  spart,
              vgtyp TYPE  vbtyp,
              uecha TYPE  uecha,
              cuobj TYPE  cuobj,
            END OF gt_delv_data_temp.

RANGES  : gr_batch_posnr FOR vbfa-posnv.
DATA: gv_origin_stages TYPE i VALUE 0.
DATA gv_flag_metric TYPE char1.                             "CMS31694
DATA gv_unit_weight TYPE zsdc_cn.                           "CMS31694
DATA gv_roll_diameter TYPE zsdc_cn.                         "CMS31694
DATA gv_roll_width TYPE zsdc_cn.                            "CMS31694
DATA gv_lineal_char TYPE zsdc_cn.                           "CMS31694
*======================================================================*

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_ALERTSTOP.                 " Global Data
  INCLUDE LZSD_DL_ALERTSUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_ALERTSF...                 " Subprograms
* INCLUDE LZSD_DL_ALERTSO...                 " PBO-Modules
* INCLUDE LZSD_DL_ALERTSI...                 " PAI-Modules

INCLUDE LZSD_DL_ALERTSAPP.

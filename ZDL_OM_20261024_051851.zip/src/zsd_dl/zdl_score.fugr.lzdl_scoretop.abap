FUNCTION-POOL ZDL_SCORE.                    "MESSAGE-ID ..

* Include LRSAXD01 can be directly referenced by application APIs !!
INCLUDE LRSAXD01.
* INCLUDE LZDL_SCORED...                     " Local class definition

* Type-pools
TYPE-POOLS:
  RSAOT,
  RSAZT.

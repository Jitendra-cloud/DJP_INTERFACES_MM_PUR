*&--------------------------------------------------------------------*
*& Include LZDL_E04516U02                                             *
*&--------------------------------------------------------------------*


***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**           COPYRIGHT (C) 2009 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                           **
**             REVISIONS COPYRIGHT (C) 2009, 20nn                    **
**                    by INTERNATIONAL PAPER                         **
*_____________________________________________________________________*
* Function Module: ZDL_E04516_WEIGHT_DIMEN_CAL       Date: 10/07/2009 *
* Programmer :     Satish Reddy                                       *
*_____________________________________________________________________*
* Description :                                                       *
*   This function module used for Calculation of Weight / Dimension   *
*   Value based formula from formula table for the batch and material.*
*_____________________________________________________________________*
*
***********************************************************************

*eject.

************************************************************************
*
**Change History:
*
**  Description:                         EDVK         User-Id  Date:
*
*     1) Created by Satish Reddy         EDVK973728   SREDDY  06/04/09
*
*     2) Changed by Mark Tomazin:        EDVK974096   MTOMAZ1 10/28/09
*         a) Fixed Volume Calculations:
*            Now get the VC Characteristics Values, from either the
*            Sales Order Table: VBAP or the Material Master Table: MARC,
*            and use those values instead of the Batch Characteristic
*            Values to calculate the Volume.
*         b) Added New Include: LZDL_E04516F01.
*         c) Added Text Symbols to support a NEW Formula "TYPE"
*            Calculation: VCHR, (residing in Table: ZDL_CHAR_FORMULA),
*            and also added additional Text Symbol Error Messages.
*         d) Fixed Rounding Issues, replaced references to TYPE: LABST,
*            (Quant 13, 3 Decimals) to a "Packed with 6 Decimals"
*         e) Added new ZSDOMFLD Values:
*              Report Category: E04516_MTART
*              FileName       : CONFIGURABLE_MATERIAL
*            Now Used to Determine a Configurable Material
*         f) Get VC Values by calling VC Function:
*            ZSD_GET_SINGLE_VALUES_OF_INST
*         g) Removed SAP Maintenance View Functions from this Function
*            group: ZDL_E04516, and created the Table Maintenance for
*            the Tables:ZDL_CHAR_FORMULA, ZDL_WGTDIMENSION,
*            in Function Group: ZDL_E04516_TBL_M.
*
*     3) Changed by Mark Tomazin:        EDVK974096   MTOMAZ1 11/24/09
*         a.  Stop returning the error message when unrestricted stock
*             for a single batch totals 0.  Right now we are returning
*             that error even if 1 batch stock record is 0 and another
*             is non 0.
*         b.  When total batch stock weight = 0, do not create the
*             weights for gross weight raw (GR) or net weight raw (NR).
*         c.  When total batch stock weight = 0, continue to create the
*             other (non GR / NR) weights and dimensions.
*      4) Changed for TPR# 05559       EDVK975185  RMYNEED    02/11/10
*Added additional parameter CUOBJ to the input structure for
*             for volume calculation from VC characteristics
*         Changed for CR#9831         EDVK975185  RMYNEED    02/24/10
*Added extra types(PALT & WTAR) to formula table and considered
*            when calculating the final result.

*      5) Changed by Anand Dhumbala
*         USD 5501162 / CHG 114951 - Include PLANT as optional parameter
*      6) Changed by JPIERI CHG # 135212  05/04/2012
*           Function ZDL_E04516_WEIGHT_DIMEN_CAL is modified to only call
*           function ZSD_GET_SINGLE_VALUES_OF_INS once per unique object
*           key; we pass only the characteristics that are defined by
*           entries in table ZSDOMFLD, using category key E04516_VC.
*           Search 135212
*
************************************************************************

*eject.

FUNCTION zdl_e04516_weight_dimen_cal.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  TABLES
*"      BATCH_IN STRUCTURE  ZCHARG
*"      BATCH_OUT TYPE  ZBATCH_OUT_TAB OPTIONAL
*"      BATCH_ERROR STRUCTURE  ZBERROR OPTIONAL
*"  EXCEPTIONS
*"      PLANT_REQUIRED
*"----------------------------------------------------------------------

***Clearing golbal data
  PERFORM refresh_data TABLES batch_out batch_error.

* USD 5501162 / CHG 114951
* If a Plant is entered against a Batch, then Plants should be
* entered across all the Batches.

*Begin E0VK989855 CMS 22306
*  CLEAR gv_plant_exists.
*  loop at batch_in into gs_batch_in where werks NE ''.
*    read table batch_in into gs_batch_in with key werks = ''.
*    if sy-subrc = 0.
*      raise plant_required.
*    else.
*      gv_plant_exists = 'Y'.
*      exit.
*    endif.
*  endloop.
* USD 5501162 / CHG 114951

  CLEAR gv_plant_exists.
  LOOP AT batch_in INTO gs_batch_in WHERE werks NE '' AND
                                          charg NE ''.
    IF sy-subrc EQ 0.
      gv_plant_exists = 'Y'.
      EXIT.
    ENDIF.
  ENDLOOP.

  IF gv_plant_exists = 'Y'.
    LOOP AT batch_in INTO gs_batch_in WHERE werks EQ space AND
                                            charg NE space.
      IF sy-subrc = 0.
        CLEAR gv_plant_exists.
        RAISE plant_required.
        EXIT.
      ENDIF.
    ENDLOOP.
  ENDIF.
*End E0VK989855 CMS 22306

*** Vaildation for the Batch and Material
  gt_batch_in[] = batch_in[].
  PERFORM batch_validation TABLES batch_in batch_error.

*** Get Batch data based on Batch,Material and plant.
  PERFORM get_data.

*** Collect all batch into batch table
  PERFORM collect_data TABLES batch_in batch_error.

*** Formatting Process internal table with material code
**** Unit code and Characteristics Values.
  PERFORM process_data TABLES batch_error.

*** Getting formula data from table ZDL_CHAR_FORMULA
****  based on Unit code and Material group
  PERFORM get_formula_data.

*** Calculation of batch data based on formula from
****  formula table ZDL_CHAR_FORMULA
  PERFORM calculate_batch_data TABLES batch_out batch_error.

ENDFUNCTION.

*End-of-Function
*End-of-Function
*End-of-Function

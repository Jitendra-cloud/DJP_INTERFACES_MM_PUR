FUNCTION ZSUBST_GET_FILE_LIST.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(DIRNAME) LIKE  ZSD_RSMRGSTR-PATH
*"     VALUE(FILENM) LIKE  ZSD_RSMRGSTR-NAME
*"     VALUE(PATTERN) LIKE  ZSD_RSMRGSTR-NAME OPTIONAL
*"  TABLES
*"      FILE_LIST STRUCTURE  RSFILLST
*"  EXCEPTIONS
*"      ACCESS_ERROR
*"----------------------------------------------------------------------
* Modified from SUBST_GET_FILE_LIST by RWAINW1 on 07/13/06

DATA: SAP_YES(1)  VALUE 'X',
      SAP_NO(1)   VALUE ' '.
DATA: NO_CS VALUE ' '.

*DATA FILE like FILE_LIST.
DATA: BEGIN OF FILE,
        DIRNAME(75) TYPE C, " name of directory.
        NAME(75)    TYPE C, " name of entry.
        TYPE(10)    TYPE C,            " type of entry.
        LEN(8)      TYPE P,            " length in bytes.
        OWNER(8)    TYPE C,            " owner of the entry.
        MTIME(6)    TYPE P, " last modification date, seconds since 1970
        FMODE(9)    TYPE C, " like "rwx-r-x--x": protection mode.
        USEABLE(1)  TYPE C,
        SUBRC(4)    TYPE C,
        ERRNO(3)    TYPE C,
        ERRMSG(40)  TYPE C,
        MOD_DATE    TYPE D,
        MOD_TIME(8) TYPE C,            " hh:mm:ss
        SEEN(1)     TYPE C,
        CHANGED(1)  TYPE C,
      END OF FILE.

DATA: ERRCNT(2) TYPE P VALUE 0.

  CALL 'C_DIR_READ_FINISH'             " just to be sure
      ID 'ERRNO'  FIELD FILE_LIST-ERRNO
      ID 'ERRMSG' FIELD FILE_LIST-ERRMSG.

  CALL 'C_DIR_READ_START' ID 'DIR'    FIELD DIRNAME
                          ID 'FILE'   FIELD FILENM
                          ID 'ERRNO'  FIELD FILE-ERRNO
                          ID 'ERRMSG' FIELD FILE-ERRMSG.
  IF SY-SUBRC <> 0.
    raise ACCESS_ERROR.
  ENDIF.

  DO.
    CLEAR FILE.
    CALL 'C_DIR_READ_NEXT'
      ID 'TYPE'   FIELD FILE-TYPE
      ID 'NAME'   FIELD FILE-NAME
      ID 'LEN'    FIELD FILE-LEN
      ID 'OWNER'  FIELD FILE-OWNER
      ID 'MTIME'  FIELD FILE-MTIME
      ID 'MODE'   FIELD FILE-FMODE
      ID 'ERRNO'  FIELD FILE-ERRNO
      ID 'ERRMSG' FIELD FILE-ERRMSG.
    FILE-DIRNAME = DIRNAME.
    MOVE SY-SUBRC TO FILE-SUBRC.
    CASE SY-SUBRC.
      WHEN 0.
        CLEAR: FILE-ERRNO, FILE-ERRMSG.
        CASE FILE-TYPE(1).
          WHEN 'F'.                    " normal file.
          WHEN 'f'.                    " normal file.
          WHEN OTHERS. " directory, device, fifo, socket,...
            MOVE SAP_NO  TO FILE-USEABLE.
        ENDCASE.
        IF FILE-LEN = 0.
          MOVE SAP_NO TO FILE-USEABLE.
        ENDIF.
      WHEN 1.
        EXIT.
      WHEN OTHERS.                     " SY-SUBRC >= 2
        ADD 1 TO ERRCNT.
        IF ERRCNT > 10.
          EXIT.
        ENDIF.
        IF SY-SUBRC = 5.
          MOVE: '???' TO FILE-TYPE,
                '???' TO FILE-OWNER,
                '???' TO FILE-FMODE.
        ELSE.
        ENDIF.
        MOVE SAP_NO TO FILE-USEABLE.
    ENDCASE.
*   * Does the filename contains the requested pattern?
*   * Then store it, else forget it.
    IF PATTERN = NO_CS.
      MOVE-CORRESPONDING FILE TO FILE_LIST.
      APPEND FILE_LIST.
    ELSE.
      IF FILE-NAME CP PATTERN.
        MOVE-CORRESPONDING FILE TO FILE_LIST.
        APPEND FILE_LIST.
      ENDIF.
    ENDIF.
  ENDDO.

  CALL 'C_DIR_READ_FINISH'
      ID 'ERRNO'  FIELD FILE_LIST-ERRNO
      ID 'ERRMSG' FIELD FILE_LIST-ERRMSG.
  IF SY-SUBRC <> 0.
  ENDIF.


ENDFUNCTION.

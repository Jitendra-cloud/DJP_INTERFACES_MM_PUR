*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_BATCH_STATTOP.                " Global Data
  INCLUDE LZDL_BATCH_STATUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_BATCH_STATF...                " Subprograms
* INCLUDE LZDL_BATCH_STATO...                " PBO-Modules
* INCLUDE LZDL_BATCH_STATI...                " PAI-Modules

FUNCTION z_idoc_output_container.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IDOC_CREATE) TYPE  C DEFAULT 'Y'
*"  TABLES
*"      I_CONTAINER_TALLY TYPE  ZSD_DL_CONTAINER_TALLY
*"      I_PARTNERS TYPE  ZSD_DL_VENUM_PARTNER
*"      I_RESULT STRUCTURE  EDIDC
*"  EXCEPTIONS
*"      CONTROL_RECORD_MISSING
*"----------------------------------------------------------------------
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**         COPYRIGHT (C) 2003 by INTERNATIONAL PAPER                  **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                      2007, 2008                                    **
**                   by INTERNATIONAL PAPER                           **
*______________________________________________________________________*
* Include Name: Z_IDOC_OUTPUT_CONTAINER               Date: 11/29/2007 *
* Programmer  : Kishor Thakur                                          *
*______________________________________________________________________*
* Description : This function module is designed to send               *
* Container Tally  via IDOC                                            *
* The desired state is to deliver this information via the 846 EDI     *
* message to customers and third party service providers who have      *
* the capability to receive electronic messages.                       *
* This method should reduce the possibility of data entry              *
* errors in the customer and third party systems                       *
* Change History :                                                     *
*     Programmer        Date      Req. #            Action             *
*     BMANDL2         01/08/09   E0VK946705  Idoc Changes for bundled  *
*                                            rolls IDOC_ROLLS_BALES    *
*                                            IDOC_UNIT_NUM             *
* M Carter  07/2015 CR#13267    EOP wave 2 - add PO to line item;      *
*                                            remove PO from header     *
* L Phillips 05/2016 CR#????    SOLAS      - add code to polulate      *
*                                            e1edk01 segments with new *
*                                            fields in zdlu01267_vekp  *
*                                            table (tare, vgm, uom).
* ==================  ========  ======  ===============================*
* master_idoc_distribute parameters
  DATA: lv_tare TYPE zsd_cont_tare,
        lv_vgm  TYPE zsd_vgm,
        lv_uom  TYPE zsd_uom.

  CLEAR  :i_result.
  REFRESH:i_result[].

  LOOP AT i_container_tally.  "Header level data
* Container ID
    CLEAR idoc_e1edk01.
    CLEAR: lv_tare, lv_vgm, lv_uom.
    idoc_e1edk01-belnr = i_container_tally-exidv2.
    gt_idoc_data-segnam = c_segnam_e1edk01 .                "E1EDK01
    gt_idoc_data-hlevel = c_hlevel_1 .
*   gt_idoc_data-sdata   = idoc_e1edk01.
* get tare weight, vgm and uom
    SELECT SINGLE tare vgm uom INTO
     (lv_tare, lv_vgm, lv_uom) FROM zdlu01267_vekp
     WHERE signi = i_container_tally-exidv2
      AND seal  = i_container_tally-seal_num
      AND bookdoc = i_container_tally-bookdoc.
    IF lv_tare IS NOT INITIAL.
      idoc_e1edk01-ntgew = lv_tare.
      idoc_e1edk01-brgew = lv_vgm.
      idoc_e1edk01-gewei = lv_uom.
    ENDIF.
    gt_idoc_data-sdata   = idoc_e1edk01.
    APPEND gt_idoc_data.

* Shipment Number
    CLEAR idoc_e1edk02.
    idoc_e1edk02-qualf = 'SHP'.                        "Shipment number
    idoc_e1edk02-belnr = i_container_tally-tknum.
    gt_idoc_data-segnam = c_segnam_e1edk02.                 "E1EDK02
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edk02.
    APPEND gt_idoc_data.

* Seal Number
    CLEAR idoc_e1edk02.
    idoc_e1edk02-qualf = 'SEA'.
    idoc_e1edk02-belnr = i_container_tally-seal_num.
    gt_idoc_data-segnam = c_segnam_e1edk02.                 "E1EDK02
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edk02.
    APPEND gt_idoc_data.

* Sales order number not available at header level
* to get it from item level , loop at item record only once and exit.

    LOOP AT i_container_tally-item INTO  gs_container_item.
      EXIT.
    ENDLOOP.

* Book number
    CLEAR idoc_e1edk02.
    idoc_e1edk02-qualf = 'BKN'.
*   idoc_e1edk02-belnr = i_container_tally-booknum.
    idoc_e1edk02-belnr = i_container_tally-bookdoc.         "CR # 8008
    gt_idoc_data-segnam = c_segnam_e1edk02.                 "E1EDK02
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edk02.
    APPEND gt_idoc_data.

* Start changes by Kmadde1 on 7/14/20 EH# 58593 E0VK9A1F6N
    " A change is needed to add the booking confirmation to the idoc
    " that is created to send information to the freight forwarder.
* Book confirmation
    CLEAR idoc_e1edk02.
    idoc_e1edk02-qualf = 'BKD'.
    idoc_e1edk02-belnr = i_container_tally-booknum.
    gt_idoc_data-segnam = c_segnam_e1edk02.                 "E1EDK02
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata  = idoc_e1edk02.
    APPEND gt_idoc_data.
* End changes by Kmadde1 on 7/14/20 EH# 58593 E0VK9A1F6N

* Vessel Name
    CLEAR idoc_e1edk02.
    idoc_e1edk02-qualf = 'VSL'.
    idoc_e1edk02-belnr = i_container_tally-veslname.
    gt_idoc_data-segnam = c_segnam_e1edk02.                 "E1EDK02
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edk02.
    APPEND gt_idoc_data.

* Steam Shipline.
    CLEAR idoc_e1edk02.
    idoc_e1edk02-qualf = 'SSL'.
    idoc_e1edk02-belnr = i_container_tally-stmshpline.
    gt_idoc_data-segnam = c_segnam_e1edk02.                 "E1EDK02
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edk02.
    APPEND gt_idoc_data.

* Date Idoc created
    CLEAR idoc_e1edk03.
    idoc_e1edk03-iddat = '011'.
    idoc_e1edk03-datum = sy-datum.
    idoc_e1edk03-uzeit = sy-uzeit.
    gt_idoc_data-segnam = c_segnam_e1edk03.                 "E1EDK03
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edk03.
    APPEND gt_idoc_data.

* Bill to partner.
    CLEAR idoc_e1edka1.
    idoc_e1edka1-parvw = 'BT'.
    idoc_e1edka1-partn = i_container_tally-kunnr_bp.  "Partner number
    idoc_e1edka1-name1 = i_container_tally-name1_bp.  "Partner Name
    idoc_e1edka1-name2 = i_container_tally-name2_bp.        "Street 3
    idoc_e1edka1-stras = i_container_tally-stras_bp.  "Street
    idoc_e1edka1-strs2 = i_container_tally-stras2_bp.       "Street2
    idoc_e1edka1-ort01 = i_container_tally-ort01_bp.  "City
    idoc_e1edka1-pstlz = i_container_tally-pstlz_bp.  "Postal code
    idoc_e1edka1-regio = i_container_tally-regio_bp.  "Region
    idoc_e1edka1-land1 = i_container_tally-land1_bp.  "Country
    gt_idoc_data-segnam = c_segnam_e1edka1.                 "E1EDKA1
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edka1.
    APPEND gt_idoc_data.

* Ship to partner.
    CLEAR idoc_e1edka1.
    idoc_e1edka1-parvw = 'SH'.
    idoc_e1edka1-partn = i_container_tally-kunnr_sh.
    idoc_e1edka1-name1 = i_container_tally-name1_sh.
    idoc_e1edka1-name2 = i_container_tally-name2_sh.
    idoc_e1edka1-stras = i_container_tally-stras_sh.
    idoc_e1edka1-strs2 = i_container_tally-stras2_sh.
    idoc_e1edka1-ort01 = i_container_tally-ort01_sh.
    idoc_e1edka1-pstlz = i_container_tally-pstlz_sh.
    idoc_e1edka1-regio = i_container_tally-regio_sh.
    idoc_e1edka1-land1 = i_container_tally-land1_sh.
    gt_idoc_data-segnam = c_segnam_e1edka1.                 "E1EDKA1
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edka1.
    APPEND gt_idoc_data.
* Final ship to partner.
    CLEAR idoc_e1edka1.
    idoc_e1edka1-parvw = 'ST'.
    idoc_e1edka1-partn = i_container_tally-kunnr_fsh.
    idoc_e1edka1-name1 = i_container_tally-name1_fsh.
    idoc_e1edka1-name2 = i_container_tally-name2_fsh.
    idoc_e1edka1-stras = i_container_tally-stras_fsh.
    idoc_e1edka1-strs2 = i_container_tally-stras2_fsh.
    idoc_e1edka1-ort01 = i_container_tally-ort01_fsh.
    idoc_e1edka1-pstlz = i_container_tally-pstlz_fsh.
    idoc_e1edka1-regio = i_container_tally-regio_fsh.
    idoc_e1edka1-land1 = i_container_tally-land1_fsh.
    gt_idoc_data-segnam = c_segnam_e1edka1.                 "E1EDKA1
    gt_idoc_data-hlevel = c_hlevel_1 .
    gt_idoc_data-sdata   = idoc_e1edka1.
    APPEND gt_idoc_data.

* Shipping Instructions
* Shipping instructions are in tline having length of 255 char.
* Move each 70 char length in to TDLIne  and append the segment to idoc.

    IF NOT i_container_tally-tline IS INITIAL.
      lv_tline_length = strlen( i_container_tally-tline ).
      lv_tline_length1 = 70.
      lv_tline_shift = 0.
* Do loop to split the 255 char leng in to 70 char length .
      DO .
        CLEAR idoc_e1edkt2.
        lv_tline = i_container_tally-tline+lv_tline_shift(lv_tline_length1).
        IF lv_tline IS INITIAL .
          EXIT.
        ENDIF.
        idoc_e1edkt2-tdline = lv_tline.
        gt_idoc_data-segnam = c_segnam_e1edkt2.             "E1EDKT2
        gt_idoc_data-hlevel = c_hlevel_1 .
        gt_idoc_data-sdata   = idoc_e1edkt2.
        APPEND gt_idoc_data.
        lv_tline_shift1 =  lv_tline_length -  ( lv_tline_length1 + lv_tline_shift ).
        IF  lv_tline_shift1 < 70.
          lv_tline_shift = lv_tline_length1 + lv_tline_shift.
          lv_tline_length1  =   lv_tline_shift1 .
        ELSE.
          lv_tline_shift = lv_tline_length1 + lv_tline_shift.
        ENDIF.
        IF  lv_tline_shift1 < 1.
          EXIT.
        ENDIF.
        CLEAR lv_tline.
      ENDDO.
    ENDIF.
    CLEAR : lv_tline_length,
            lv_tline_shift,
            gs_container_item.
* Loop at items internal table.
    LOOP  AT i_container_tally-item INTO  gs_container_item.

* Item data .
      CLEAR idoc_e1edp01 .
      idoc_e1edp01-menge =  gs_container_item-sum_units.
      CONDENSE idoc_e1edp01-menge.
      CASE gs_container_item-product.
        WHEN c_roll.
          idoc_e1edp01-menee =  'RL'.    "ROLL
        WHEN c_bales.
          idoc_e1edp01-menee =  'BA'.    "BALES
        WHEN c_skids.
          idoc_e1edp01-menee =  'SKD'.   "SKID
        WHEN c_carton.
          idoc_e1edp01-menee =  'CTN'.   "CORTON
      ENDCASE.
      idoc_e1edp01-posex =  gs_container_item-sonum+10(6). "SO Item
      idoc_e1edp01-matnr =  gs_container_item-matnr.       "Material
      idoc_e1edp01-ntgew =  gs_container_item-zzslbwt.     "Sales Basis  Weight
      idoc_e1edp01-gewei = c_lb.                           "UoM

      gt_idoc_data-segnam = c_segnam_e1edp01.               "E1EDP01
      gt_idoc_data-hlevel = c_hlevel_1 .
      gt_idoc_data-sdata   = idoc_e1edp01.
      APPEND gt_idoc_data.

* Material number
      CLEAR idoc_e1edp19.
      idoc_e1edp19-qualf = '002'.
      idoc_e1edp19-idtnr =  gs_container_item-matnr_c. "Customer material number
      idoc_e1edp19-ktext =  gs_container_item-arktx.   "Material text
      gt_idoc_data-segnam = c_segnam_e1edp19.               "E1EDP19
      gt_idoc_data-hlevel = c_hlevel_3 .
      gt_idoc_data-sdata   = idoc_e1edp19.
      APPEND gt_idoc_data.

* added 07/2015 for CR#13267 EOP2 - add segment E1EDP35 for sales order and for PO
*     at container level
* Sales order
      CLEAR idoc_e1edp35.
      idoc_e1edp35-qualz = 'ISO'.
      idoc_e1edp35-cusadd = gs_container_item-sonum+0(10).  "Sales Order
      gt_idoc_data-segnam = c_segnam_e1edp35.               "E1EDP35
      gt_idoc_data-hlevel = c_hlevel_3 .
      gt_idoc_data-sdata  = idoc_e1edp35.
      APPEND gt_idoc_data.
* Purchase order
      CLEAR idoc_e1edp35.
      idoc_e1edp35-qualz  = 'CPO'.
      idoc_e1edp35-cusadd = gs_container_item-bstnk.  "Customer purchase Order
      gt_idoc_data-segnam = c_segnam_e1edp35.               "E1EDP35
      gt_idoc_data-hlevel = c_hlevel_3 .
      gt_idoc_data-sdata  = idoc_e1edp35.
      APPEND gt_idoc_data.

* Material Grade.
      CLEAR idoc_e1edp35.
      idoc_e1edp35-qualz = 'GRC'.
      idoc_e1edp35-cusadd =  gs_container_item-zzslgrd.  "Sales Grade Code
      gt_idoc_data-segnam = c_segnam_e1edp35.               "E1EDP35
      gt_idoc_data-hlevel = c_hlevel_3 .
      gt_idoc_data-sdata   = idoc_e1edp35.
      APPEND gt_idoc_data.

* Material Surface.
      CLEAR idoc_e1edp35.
      idoc_e1edp35-qualz = 'SSF'.
      idoc_e1edp35-cusadd =  gs_container_item-zzslsur.  "Sales Surface
      gt_idoc_data-segnam = c_segnam_e1edp35.               "E1EDP35
      gt_idoc_data-hlevel = c_hlevel_3 .
      gt_idoc_data-sdata   = idoc_e1edp35.
      APPEND gt_idoc_data.

* Sales Color Code.
      CLEAR idoc_e1edp35.
      idoc_e1edp35-qualz = 'SCC'.
      idoc_e1edp35-cusadd =  gs_container_item-zzslclr.  "Sales Color Code
      gt_idoc_data-segnam = c_segnam_e1edp35.               "E1EDP35
      gt_idoc_data-hlevel = c_hlevel_3 .
      gt_idoc_data-sdata   = idoc_e1edp35.
      APPEND gt_idoc_data.


* Core diameter for Rolls only.
      IF gs_container_item-product = c_roll.
        CLEAR idoc_e1edp35.
        idoc_e1edp35-qualz = 'CDI'.
        idoc_e1edp35-cusadd =  gs_container_item-core_dia.
        gt_idoc_data-segnam = c_segnam_e1edp35.             "E1EDP35
        gt_idoc_data-hlevel = c_hlevel_3 .
        gt_idoc_data-sdata   = idoc_e1edp35.
        APPEND gt_idoc_data.

* Core type for Rolls only..
        CLEAR idoc_e1edp35.
        idoc_e1edp35-qualz = 'CTY'.
        idoc_e1edp35-cusadd =  gs_container_item-core_type.
        gt_idoc_data-segnam = c_segnam_e1edp35.             "E1EDP35
        gt_idoc_data-hlevel = c_hlevel_3 .
        gt_idoc_data-sdata   = idoc_e1edp35.
        APPEND gt_idoc_data.
        CLEAR gs_container_unit.

* Lineal Footage  for Rolls only.
        CLEAR idoc_e1edp35.
        idoc_e1edp35-qualz = 'ZLF'.
        idoc_e1edp35-cusadd =  gs_container_item-lineal_footage.
        gt_idoc_data-segnam = c_segnam_e1edp35.             "E1EDP35
        gt_idoc_data-hlevel = c_hlevel_3 .
        gt_idoc_data-sdata   = idoc_e1edp35.
        APPEND gt_idoc_data.
        CLEAR: gs_container_unit.

      ENDIF.

* Loop at unit table to populate unit level data
      LOOP AT gs_container_item-units INTO gs_container_unit.
        CLEAR idoc_z1subitm.
        IF gs_container_item-metric_indicator = c_yes.  "Metric indicator
          idoc_z1subitm-uom  = c_cm.        "Centimeter
          idoc_z1subitm-grosswt = gs_container_unit-weight_kg.
          idoc_z1subitm-nom_wt = gs_container_unit-nom_wt_kg.
          CONDENSE idoc_z1subitm-nom_wt.
          idoc_z1subitm-uom_wt = c_kg.
        ELSE.
          idoc_z1subitm-uom  = c_in.        "Inch
          idoc_z1subitm-grosswt = gs_container_unit-weight_lb.
          idoc_z1subitm-nom_wt = gs_container_unit-nom_wt_lb.
          idoc_z1subitm-uom_wt = c_lb.
        ENDIF.
        IF gs_container_item-product = c_roll.

          PERFORM format_length_width USING gs_container_unit-len_dia_idoc
                                      CHANGING lv_length.
          idoc_z1subitm-diameter  = lv_length.
          CLEAR lv_length.


        ELSE.
          PERFORM format_length_width USING gs_container_unit-len_dia_idoc
                                      CHANGING lv_length.
          idoc_z1subitm-length  = lv_length.
          CLEAR lv_length.

        ENDIF.
        PERFORM format_length_width USING gs_container_unit-width_idoc
                                      CHANGING lv_length.
        idoc_z1subitm-width  = lv_length.
        CLEAR lv_length.

        IF gs_container_item-product <> c_skids.

          idoc_z1subitm-qty = gs_container_unit-idoc_rolls_bales.
*..For Bales Populate the Quantity as original
          IF gs_container_item-product = c_bales.
            idoc_z1subitm-qty = gs_container_unit-rolls_bales.
          ENDIF.
        ELSE.
          idoc_z1subitm-qty = gs_container_unit-charg.
        ENDIF.

        IF ( gs_container_item-product = c_roll )
               OR
           ( gs_container_item-product = c_bales ) .
          idoc_z1subitm-charg  = gs_container_unit-charg.
          idoc_z1subitm-metton = gs_container_unit-metric_tons.
          idoc_z1subitm-pctair = gs_container_unit-airdry.
        ELSEIF gs_container_item-product = c_carton.
          idoc_z1subitm-reams  = gs_container_unit-charg.
          CONDENSE idoc_z1subitm-reams.
        ENDIF.

        IF gs_container_item-product = c_roll.
          idoc_z1subitm-pkg    = gs_container_unit-idoc_unit_num.
*..For other than Rolls Populate the Pkg as original
        ELSE.
          idoc_z1subitm-pkg    = gs_container_unit-unit_num.
        ENDIF.

        idoc_z1subitm-lbs    = gs_container_unit-weight_lb.
        idoc_z1subitm-kgs    = gs_container_unit-weight_kg.
        IF ( gs_container_item-product = c_carton )
               OR
           ( gs_container_item-product = c_skids ) .
          idoc_z1subitm-charg  = gs_container_unit-idoc_unit_num.
          idoc_z1subitm-pal_skid_wt = gs_container_unit-pal_skid_wt.
          idoc_z1subitm-tare_wt = gs_container_unit-tare_wt.
        ENDIF.
        CONDENSE idoc_z1subitm-pkg.
        CONDENSE idoc_z1subitm-metton.
        CONDENSE idoc_z1subitm-grosswt.
        CONDENSE idoc_z1subitm-nom_wt.
        CONDENSE idoc_z1subitm-lbs.
        CONDENSE idoc_z1subitm-kgs.
        CONDENSE idoc_z1subitm-pal_skid_wt.
        CONDENSE idoc_z1subitm-tare_wt.
        gt_idoc_data-segnam = c_segnam_z1subitm.            "z1subitm
        gt_idoc_data-hlevel = c_hlevel_3 .
        gt_idoc_data-sdata   = idoc_z1subitm.
        APPEND gt_idoc_data.
      ENDLOOP.
*  Add item total to gross total
      lv_gross_mt   =  lv_gross_mt + gs_container_item-sum_metric_ton.
      lv_gross_admt =  lv_gross_admt + gs_container_item-sum_admt.
      lv_gross_lbs  =  lv_gross_lbs + gs_container_item-sum_weight_lb.
      lv_gross_kgs  =  lv_gross_kgs + gs_container_item-sum_weight_kg.


    ENDLOOP.
    lv_gross_units =  i_container_tally-tot_roll_units +
                      i_container_tally-tot_bale_units +
                      i_container_tally-tot_skid_units +
                      i_container_tally-tot_pallet_units.

    CLEAR idoc_e1eds01.
    idoc_e1eds01-sumid  = 'TUN'.
    idoc_e1eds01-summe  = lv_gross_units.
    CONDENSE idoc_e1eds01-summe.
    idoc_e1eds01-sunit  = 'EA'.
    gt_idoc_data-segnam = c_segnam_e1eds01.                 "e1eds01
    gt_idoc_data-hlevel = c_hlevel_2 .
    gt_idoc_data-sdata  = idoc_e1eds01.
    APPEND gt_idoc_data.


    CLEAR idoc_e1eds01.
    idoc_e1eds01-sumid = 'GWP'.
    idoc_e1eds01-summe = lv_gross_lbs.
    CONDENSE idoc_e1eds01-summe.
    idoc_e1eds01-sunit  = c_lb.
    gt_idoc_data-segnam = c_segnam_e1eds01.                 "e1eds01
    gt_idoc_data-hlevel = c_hlevel_2 .
    gt_idoc_data-sdata  = idoc_e1eds01.
    APPEND gt_idoc_data.
    idoc_e1eds01-sumid = 'GWK'.
    idoc_e1eds01-summe = lv_gross_kgs.
    CONDENSE idoc_e1eds01-summe.
    idoc_e1eds01-sunit  = c_kg.
    gt_idoc_data-segnam = c_segnam_e1eds01.                 "e1eds01
    gt_idoc_data-hlevel = c_hlevel_2 .
    gt_idoc_data-sdata  = idoc_e1eds01.
    APPEND gt_idoc_data.
    idoc_e1eds01-sumid = 'VOL'.
    idoc_e1eds01-sunit  = 'M3'.
    idoc_e1eds01-summe  =  i_container_tally-gross_volume.
    CONDENSE idoc_e1eds01-summe.
    gt_idoc_data-segnam = c_segnam_e1eds01.                 "e1eds01
    gt_idoc_data-hlevel = c_hlevel_2 .
    gt_idoc_data-sdata  = idoc_e1eds01.
    APPEND gt_idoc_data.


    IF ( i_container_tally-bales = c_yes ) OR ( i_container_tally-rolls = c_yes ).
      idoc_e1eds01-sumid = 'GMT'.
      idoc_e1eds01-summe = lv_gross_mt.
      CONDENSE idoc_e1eds01-summe.
      idoc_e1eds01-sunit  = c_ton.
      gt_idoc_data-segnam = c_segnam_e1eds01.               "e1eds01
      gt_idoc_data-hlevel = c_hlevel_2 .
      gt_idoc_data-sdata  = idoc_e1eds01.
      APPEND gt_idoc_data.
      idoc_e1eds01-sumid = 'GAD'.
      idoc_e1eds01-summe = lv_gross_admt.
      CONDENSE idoc_e1eds01-summe.
      idoc_e1eds01-sunit  = c_ton.
      gt_idoc_data-segnam = c_segnam_e1eds01.               "e1eds01
      gt_idoc_data-hlevel = c_hlevel_2 .
      gt_idoc_data-sdata  = idoc_e1eds01.
      APPEND gt_idoc_data.
    ENDIF.
    CLEAR :lv_gross_lbs,
           lv_gross_kgs,
           lv_gross_admt,
           lv_gross_mt,
           lv_gross_units.
  ENDLOOP.

  PERFORM get_logical_system.

  LOOP AT i_partners INTO gs_partners.
    PERFORM fill_idoc_control_rec.

    CALL FUNCTION 'MASTER_IDOC_DISTRIBUTE'
      EXPORTING
        master_idoc_control            = gt_idoc_control
      TABLES
        communication_idoc_control     = gt_idoc_com_control
        master_idoc_data               = gt_idoc_data[]
      EXCEPTIONS
        error_in_idoc_control          = 1
        error_writing_idoc_status      = 2
        error_in_idoc_data             = 3
        sending_logical_system_unknown = 4
        OTHERS                         = 5.

    LOOP AT gt_idoc_com_control.
      gs_comm_control  =  gt_idoc_com_control.
      APPEND gs_comm_control TO i_result.
      CLEAR gs_comm_control.
    ENDLOOP.
    CALL FUNCTION 'EDI_DOCUMENT_DEQUEUE_LATER'
      EXPORTING
        docnum                 = gt_idoc_com_control-docnum
      EXCEPTIONS
        idoc_is_not_to_dequeue = 1
        OTHERS                 = 2.
    COMMIT WORK.
  ENDLOOP.

  CLEAR : gt_idoc_data,gt_idoc_com_control.
  REFRESH :gt_idoc_data[],gt_idoc_com_control[].

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSDR1460_PARTNRS................................*
DATA:  BEGIN OF STATUS_ZSDR1460_PARTNRS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSDR1460_PARTNRS              .
CONTROLS: TCTRL_ZSDR1460_PARTNRS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSDR1460_PARTNRS              .
TABLES: ZSDR1460_PARTNRS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

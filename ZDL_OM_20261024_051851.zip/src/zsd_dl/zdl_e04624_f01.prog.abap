*&---------------------------------------------------------------------*
*&  Include           ZDL_E04624_F01                                   *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  get_zdl_fields
*&---------------------------------------------------------------------*
FORM get_zdl_fields.

  CLEAR: gt_zdl_fields.
  REFRESH gt_zdl_fields.

  CONSTANTS : lc_e04624 TYPE zcatgory VALUE 'E04624'.

* Retrieve the Message Id#s for which the Reprocess and Arcjhive
* buttons will be Active
  SELECT * FROM zdl_fields INTO TABLE gt_zdl_fields
     WHERE category = lc_e04624.

ENDFORM.                    "get_zdl_fields

*&---------------------------------------------------------------------*
*&      Form  validate_IPCO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM validate_ipco using p_flag type any.

  CONSTANTS:
  lc_zdl_fields_cat TYPE zcatgory  VALUE  'I02410',
  lc_category        TYPE zcatgory  VALUE  'I02307',
  lc_nonomd_ipco    TYPE fieldname VALUE  'NONOMD_IPCO'.

  RANGES: lr_category  FOR zdl_fields-category.

  DATA: BEGIN OF lt_zdl_fields OCCURS 0,
          sign  LIKE zdl_fields-sign,
          optn  LIKE zdl_fields-optn,
          lowval LIKE zdl_fields-lowval,
          highval LIKE zdl_fields-highval,
        END OF lt_zdl_fields.
data  lv_field like GS_9000_VBELN2. "zdl_fields-LOWVAL.
data  lv_test_lowval like zdl_fields-LOWVAL.
data lv_ipco_num(10) type n.
ranges: lr_zdl for lv_field.

  lr_category-sign = 'I'. lr_category-option = 'EQ'.
  lr_category-low = lc_zdl_fields_cat.
  APPEND lr_category.

  lr_category-low = lc_category.
  APPEND lr_category.

  SELECT * FROM zdl_fields INTO CORRESPONDING
           FIELDS OF TABLE lt_zdl_fields
    WHERE   category IN lr_category
     AND   fieldname = lc_nonomd_ipco.

   loop at lt_zdl_fields.
    clear lr_zdl.
    lr_zdl-sign   = lt_zdl_fields-sign.
    lr_zdl-option = lt_zdl_fields-optn.
    lr_zdl-low    = lt_zdl_fields-lowval.
    lr_zdl-high   = lt_zdl_fields-highval.
    append lr_zdl.
   endloop.

   move GS_9000_VBELN2 to lv_ipco_num.
   if lv_ipco_num in lr_zdl.
      p_flag = 'X'.
   else.
      clear p_flag.
   endif.

ENDFORM.                    "validate_IPCO

*&---------------------------------------------------------------------*
*&      Form  do_the_archive
*&---------------------------------------------------------------------*
FORM do_the_archive.

  DATA : lt_idoc_status TYPE STANDARD TABLE OF bdidocstat,
         ls_idoc_status TYPE bdidocstat,
         ls_objkey      LIKE  sweinstcou-objkey,
         lv_eventid     LIKE swedumevid-evtid.

  CLEAR ls_idoc_status.
  ls_idoc_status-status = '68'.
  APPEND ls_idoc_status TO lt_idoc_status.
  CALL FUNCTION 'IDOC_STATUS_WRITE_TO_DATABASE'
    EXPORTING
      idoc_number               = gv_idoc_num
    TABLES
      idoc_status               = lt_idoc_status
    EXCEPTIONS
      idoc_foreign_lock         = 1
      idoc_not_found            = 2
      idoc_status_records_empty = 3
      idoc_status_invalid       = 4
      db_error                  = 5
      OTHERS                    = 6.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
    INTO gs_err_text.
  ELSE.
    CLEAR ls_objkey.
    ls_objkey = gv_idoc_num.
    CALL FUNCTION 'SWE_EVENT_CREATE'
      EXPORTING
        objtype           = 'IDOCAPPL'
        objkey            = ls_objkey "idoc number
        event             = 'INPUTFINISHED'
      IMPORTING
        event_id          = lv_eventid
      EXCEPTIONS
        objtype_not_found = 1
        OTHERS            = 2.
    COMMIT WORK.
  ENDIF.
  LEAVE PROGRAM.

ENDFORM.                    "do_the_archive

*&---------------------------------------------------------------------*
*&                  Form UPDATE_IDOC_DATA_SEGMENT                      *
*&---------------------------------------------------------------------*
* To update the Data segment of IDOC from screen fields.
*----------------------------------------------------------------------*

FORM update_idoc_data_segment.

  DATA :  ls_edidd TYPE edidd,
          ls_e1txth8_ipco TYPE e1txth8,
          lv_index TYPE sy-tabix .



  CLEAR : ls_edidd, lv_index.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl44.
  IF sy-subrc = 0.
    lv_index =  sy-tabix .
    gs_e1edl44 = ls_edidd-sdata.
*   IF gs_9000_charg NE gs_e1edl44-charg OR
*    if gs_9000_vemng NE gs_e1edl44-vemng OR
    if gs_9000_werks NE gs_e1edl44-werks.

      MOVE gs_9000_werks TO gs_e1edl44-werks.
*     MOVE gs_9000_charg TO gs_e1edl44-charg.
*      MOVE gs_9000_vemng TO gs_e1edl44-vemng.
      MOVE gs_e1edl44 TO ls_edidd-sdata.
      MODIFY gt_edidd FROM ls_edidd INDEX lv_index
      TRANSPORTING sdata.

    ENDIF.
  ENDIF.

  CLEAR : ls_edidd, lv_index.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl24.
  IF sy-subrc = 0.
    lv_index =  sy-tabix .
    gs_e1edl24 = ls_edidd-sdata.
    IF gs_9000_werks NE gs_e1edl24-werks.
      MOVE gs_9000_werks TO gs_e1edl24-werks.
      MOVE gs_e1edl24 TO ls_edidd-sdata.
      MODIFY gt_edidd FROM ls_edidd INDEX lv_index
      TRANSPORTING sdata.
    ENDIF.
  ENDIF.

  CLEAR : ls_edidd, lv_index.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl20.
  IF sy-subrc = 0.
    lv_index =  sy-tabix .
    gs_e1edl20 = ls_edidd-sdata.
    IF  gs_9000_traid  NE gs_e1edl20-traid OR
        gs_9000_bolnr  NE gs_e1edl20-bolnr OR
        gs_9000_vbeln2 NE gs_e1edl20-vbeln.

      MOVE gs_9000_traid  TO gs_e1edl20-traid.
      MOVE gs_9000_bolnr  TO gs_e1edl20-bolnr.
      MOVE gs_9000_vbeln2 TO gs_e1edl20-vbeln.

      MOVE gs_e1edl20 TO ls_edidd-sdata.
      MODIFY gt_edidd FROM ls_edidd  INDEX lv_index
      TRANSPORTING sdata .

    ENDIF.
  ENDIF.

  CLEAR : ls_edidd, lv_index.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl15.
  IF sy-subrc = 0 .
    lv_index =  sy-tabix .
    gs_e1edl15 = ls_edidd-sdata.
    IF gs_9000_atwrt NE gs_e1edl15-atwrt.
      MOVE  gs_9000_atwrt TO gs_e1edl15-atwrt.
      MOVE gs_e1edl15     TO ls_edidd-sdata.
      MODIFY gt_edidd FROM ls_edidd INDEX lv_index
      TRANSPORTING sdata .
*      WHERE docnum = gv_idoc_num  AND segnam = gc_e1edl15.
    ENDIF.
  ENDIF.


*read the text segment to update the IPCO number from screen
  LOOP AT gt_edidd INTO  ls_edidd
         WHERE docnum = gv_idoc_num
         AND   segnam  = gc_e1txth8 .
    lv_index = sy-tabix.
    ls_e1txth8_ipco = ls_edidd-sdata.
    IF ls_e1txth8_ipco-tdid = 'IPCO'.
      ls_e1txth8_ipco-tdobname =  gs_9000_vbeln2.
      MOVE ls_e1txth8_ipco  TO ls_edidd-sdata.
      MODIFY gt_edidd FROM ls_edidd INDEX lv_index
       TRANSPORTING sdata .
      EXIT.
    ENDIF.
  ENDLOOP.


ENDFORM.                    "UPDATE_IDOC_DATA_SEGMENT


*&---------------------------------------------------------------------*
*&      Form  TRY_TO_POST
*&---------------------------------------------------------------------*
*  Try to Post Edited IDOC.
*----------------------------------------------------------------------*
FORM try_to_post.

  DATA : lt_return_variables   TYPE STANDARD TABLE OF bdwfretvar ,
         lt_serialization_info TYPE STANDARD TABLE OF bdi_ser,
         lt_edidc2      TYPE STANDARD TABLE OF edidc,
         lt_idoc_status TYPE STANDARD TABLE OF  bdidocstat,
         ls_idoc_status TYPE bdidocstat,
         ls_stat TYPE edids,
         lv_err_flag TYPE c.

  CONSTANTS : lc_call_source TYPE  programm VALUE  'ZDL_E04624_WF_GR'.

*-- Populate the edited data from Screen and Update IDOC Data Segement
*   and pass it to FM  Z_SD_IDOC_INPUT_ZDELVRY03_GR.

  PERFORM update_idoc_data_segment.

  CLEAR : lt_edidc2.
  APPEND gs_edidc TO lt_edidc2.

  CALL FUNCTION 'Z_SD_IDOC_INPUT_ZDELVRY03_GR'
    EXPORTING
      input_method          = space
      mass_processing       = space
      call_source           = lc_call_source
    TABLES
      idoc_contrl           = lt_edidc2
      idoc_data             = gt_edidd
      idoc_status           = lt_idoc_status
      return_variables      = lt_return_variables
      serialization_info    = lt_serialization_info
    EXCEPTIONS
      wrong_function_called = 1
      OTHERS                = 2.
  IF sy-subrc <> 0.
    MESSAGE 'Error in Z_SD_IDOC_INPUT_ZDELVRY03_GR function call'(007)
    TYPE gc_char_e .
    EXIT.
  ELSE.
*-- Check for that status of IDOC after above FM call.
    LOOP AT  lt_idoc_status INTO ls_idoc_status WHERE msgty = gc_char_e
                                                OR  msgty =  gc_char_a .
      MESSAGE ID 'ZSD_DL' TYPE 'E' NUMBER ls_idoc_status-msgno WITH
      ls_idoc_status-msgv1   ls_idoc_status-msgv2
      ls_idoc_status-msgv3  ls_idoc_status-msgv4
      INTO gs_err_text.
      lv_err_flag = gc_true.
      EXIT.
    ENDLOOP.

*-- ELSE if no records with status message type E or A , that says
*-- IDOC doesn't have any more error.
    IF lv_err_flag IS INITIAL.
      SUBMIT rbdagaie WITH p_idoc = gv_idoc_num AND RETURN.
      LEAVE PROGRAM.
    ENDIF.

  ENDIF.

ENDFORM.                    "try_to_post
*&---------------------------------------------------------------------*
*&      Form  GET_IDOC_DATA
*&---------------------------------------------------------------------*
*   Get Data from IDOC and map to screen fields
*----------------------------------------------------------------------*
FORM get_idoc_data .

  DATA : ls_stat TYPE edids,
         ls_edidd TYPE edidd,
         lv_msg TYPE string,
         lv_tdid TYPE e1txth8-tdid.
  CONSTANTS : lc_po1        TYPE e1txth8-tdid VALUE 'PO1',
              lc_archive    TYPE fieldname VALUE 'ARCHIVE',
              lc_edit       TYPE fieldname VALUE 'EDIT',
              lc_reprocess  TYPE fieldname VALUE 'REPROCESS'.

  CLEAR : gv_idoc_num.
  MOVE gs_9000_docnum TO gv_idoc_num.

*-- Read IDOC
  CALL FUNCTION 'EDI_DOCUMENT_OPEN_FOR_READ'
    EXPORTING
      document_number         = gv_idoc_num
    IMPORTING
      idoc_control            = gs_edidc
    EXCEPTIONS
      document_foreign_lock   = 1
      document_not_exist      = 2
      document_number_invalid = 3
      OTHERS                  = 4.
  IF sy-subrc <> 0.
    CONCATENATE 'IDoc Does Not Exist.'(001) gv_idoc_num
         INTO gs_err_text SEPARATED BY ' - '.
    gv_idoc_process_err = gc_true.
    MESSAGE gs_err_text TYPE gc_char_e.
    LEAVE PROGRAM.
  ENDIF.

  CALL FUNCTION 'EDI_SEGMENTS_GET_ALL'
    EXPORTING
      document_number         = gv_idoc_num
    TABLES
      idoc_containers         = gt_edidd
    EXCEPTIONS
      document_number_invalid = 1
      end_of_document         = 2
      OTHERS                  = 3.
  IF sy-subrc <> 0.
    MOVE 'Error While retriving all segements data'(009) TO
    gs_err_text.
    gv_idoc_process_err = gc_true.
    EXIT.
  ENDIF.

*-- Check if Segment E1EDL44 exists.
  CLEAR : ls_edidd.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl44.
  IF sy-subrc <> 0.
    CONCATENATE 'Segement E1EDL44 doesnot exist in IDOC -'(002)
    'Contact tech.support'(003)  INTO  gs_err_text SEPARATED BY space.
    gv_idoc_process_err = gc_true.
    EXIT.
  ELSE.
*-- Retrive data from E1EDL44 Segment
    gs_9000_docnum = ls_edidd-docnum.  " IDoc Number
    gs_e1edl44     = ls_edidd-sdata.
*    gs_9000_vbeln  = gs_e1edl44-vbeln. " Inbound Delivery
*    gs_9000_posnr  = gs_e1edl44-posnr. " Inbound Delivery Item
    gs_9000_matnr  = gs_e1edl44-matnr. " SAP Material #
    gs_9000_exidv  = gs_e1edl44-exidv. " Vendor Batch
*   gs_9000_charg  = gs_e1edl44-charg. " SAP Batch
    gs_9000_vemng  = gs_e1edl44-vemng. " SAP Weight
    gs_9000_werks  = gs_e1edl44-werks. " Plant/Cust

  ENDIF.

*-- Read the IDOC Status
  CALL FUNCTION 'EDI_DOCUMENT_READ_LAST_STATUS'
    EXPORTING
      document_number        = gv_idoc_num
    IMPORTING
      status                 = ls_stat
    EXCEPTIONS
      document_not_open      = 1
      no_status_record_found = 2
      OTHERS                 = 3.
  IF sy-subrc <> 0.
    MOVE 'Error while reading IDoc status.'(004) TO  gs_err_text.
    gv_idoc_process_err = gc_true.
    EXIT.
  ENDIF.

  REFRESH gt_itab_excl. CLEAR gt_itab_excl.

* If the error message number, in the retrieved Idoc Status record,
* is NOT found in the message number(s) retrieved from zdl_fields,
* then Exclude the "Archive" application toolbar button from being
* active on the Gui Status
  READ TABLE gt_zdl_fields INTO gs_zdl_fields
    WITH KEY fieldname = lc_archive
             lowval = ls_stat-stamno. "Idoc status record's msg number
  IF sy-subrc <> 0.
    APPEND lc_archive TO gt_itab_excl.
  ENDIF.

* If the error message number, in the retrieved Idoc Status record,
* is NOT found in the message number(s) retrieved from zdl_fields,
* then Exclude the "Reprocess Idoc" application toolbar button from
* being active on the Gui Status
  READ TABLE gt_zdl_fields INTO gs_zdl_fields
    WITH KEY fieldname = lc_reprocess
             lowval = ls_stat-stamno. "Idoc status record's msg number
  IF sy-subrc <> 0.
    APPEND lc_reprocess TO gt_itab_excl.
  ENDIF.

* If the error message number, in the retrieved Idoc Status record,
* is NOT found in the message number(s) retrieved from zdl_fields,
* then Exclude the "EDIT Idoc" application toolbar button from
* being active on the Gui Status
  READ TABLE gt_zdl_fields INTO gs_zdl_fields
    WITH KEY fieldname = lc_edit
             lowval = ls_stat-stamno. "Idoc status record's msg number
  IF sy-subrc <> 0.
    APPEND lc_edit TO gt_itab_excl.
  ENDIF.

*-- Close the IDOC.
  CALL FUNCTION 'EDI_DOCUMENT_CLOSE_READ'
    EXPORTING
      document_number   = gv_idoc_num
    EXCEPTIONS
      document_not_open = 1
      parameter_error   = 2
      OTHERS            = 3.
  IF sy-subrc <> 0.
    MOVE 'Error while closing IDoc'(005) TO  gs_err_text.
    gv_idoc_process_err = gc_true.
    EXIT.
  ENDIF.

  IF ls_stat-docnum = gv_idoc_num  AND ls_stat-status = gc_status_51.
    MESSAGE ID ls_stat-stamid TYPE 'W' NUMBER ls_stat-stamno WITH
    ls_stat-stapa1 ls_stat-stapa2 ls_stat-stapa3 ls_stat-stapa4
    INTO gs_err_text.
  ENDIF.

*-- Retrive data from E1EDL20 Segment
  CLEAR : ls_edidd.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl20.
  IF sy-subrc = 0.
    gs_e1edl20    = ls_edidd-sdata.
    gs_9000_traid = gs_e1edl20-traid.  "Transport ID
    gs_9000_bolnr = gs_e1edl20-bolnr.  " Bill of Lading #
    gs_9000_vbeln2 = gs_e1edl20-vbeln. " IPCO #
  ENDIF.

*-- Retrive data from E1EDL15 Segment
  CLEAR : ls_edidd.
  READ TABLE  gt_edidd INTO  ls_edidd
                        WITH  KEY docnum = gv_idoc_num
                                  segnam = gc_e1edl15 .
  IF sy-subrc = 0 .
    gs_e1edl15 = ls_edidd-sdata.
    gs_9000_atwrt = gs_e1edl15-atwrt.  " SAP Width
  ENDIF.

*-- Retrive data from E1TXTH8 Segment
*  LOOP AT gt_edidd INTO ls_edidd WHERE docnum = gv_idoc_num
*                                   AND segnam = gc_e1txth8.
*    CLEAR : lv_tdid, gs_e1txth8.
*    gs_e1txth8 = ls_edidd-sdata.
*    lv_tdid = gs_e1txth8-tdid.
*    IF lv_tdid = lc_po1.
*      gs_9000_tdobject = gs_e1txth8-tdobname.  "Inbound PO# 1
*      EXIT.
*    ENDIF.
*  ENDLOOP.

ENDFORM.                    " GET_IDOC_DATA

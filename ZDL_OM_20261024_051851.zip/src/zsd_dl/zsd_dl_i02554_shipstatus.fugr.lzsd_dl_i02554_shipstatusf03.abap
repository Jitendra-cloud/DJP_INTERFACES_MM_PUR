*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_I02554_SHIPSTATUSF03 .
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
* Form routine for ZDL_IDOC_OUTPUT_ZSDSHIPSTATUS function module
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       Form  BUILD_IDOC_DATA
*----------------------------------------------------------------------*
* This form builds the Idoc data
*----------------------------------------------------------------------*
FORM build_idoc_data TABLES ct_edidd  STRUCTURE edidd.

* --> E1EVMHDR02
*  |
*  -----> E1EVMTID
*  -----> E1EVMPID
*     |
*     ------> E1ADRM4
*     ------> E1EVMPAI
*  -----> E1EVMREF02

* ->> E1EVMHDR02 Segment
  PERFORM append_e1evmhdr02_segment TABLES ct_edidd.

* ---->> E1EVMTID Segment
  PERFORM append_e1evmtid_segment   TABLES ct_edidd.

* ---->> E1EVMPID Segment
  PERFORM append_e1evmpid_segment   TABLES ct_edidd
                                     USING 'OSP'
                                           gs_idoc_info-ship_from.
* ---------->> E1ADRM4 Segment
  PERFORM append_e1adrm4_segment    TABLES ct_edidd
                                     USING gs_idoc_info-ship_from_adrnr.

* ---->> E1EVMPID Segment
  PERFORM append_e1evmpid_segment   TABLES ct_edidd
                                     USING gc_parvw_we
                                           gs_idoc_info-ship_to.
* ---------->> E1ADRM4 Segment
  PERFORM append_e1adrm4_segment    TABLES ct_edidd
                                     USING gs_idoc_info-ship_to_adrnr.

* ---------->> E1EVMPAI Segment
  PERFORM append_e1evmpai_segment   TABLES ct_edidd.

* ---->> E1EVMREF02 Segment
  PERFORM append_e1evmref02_segment TABLES ct_edidd.


ENDFORM.                    " BUILD_IDOC_DATA
*----------------------------------------------------------------------*
*       Form  APPEND_E1EVMHDR02_SEGMENT
*----------------------------------------------------------------------*
* This form appends E1EVMHDR02 segment to the Idoc data
*----------------------------------------------------------------------*
FORM append_e1evmhdr02_segment TABLES ct_edidd STRUCTURE edidd.

  DATA : lv_scacd      TYPE scacd,
         ls_e1evmhdr02 LIKE e1evmhdr02.

  CLEAR ls_e1evmhdr02.
  ls_e1evmhdr02-evtcod = gs_idoc_info-event_code.
  ls_e1evmhdr02-evtdat = gs_idoc_info-event_date.
  ls_e1evmhdr02-evttim = gs_idoc_info-event_time.
  ls_e1evmhdr02-evtzon = gs_idoc_info-event_zone.
  IF gs_vttk-vsart EQ 'ZB'.                                 " CR#8159
    ls_e1evmhdr02-repcod = 'RAIL'.
  ELSE.
    ls_e1evmhdr02-repcod = 'TRUCK'.
  ENDIF.
  PERFORM get_scacd USING gs_idoc_info-tknum
                 CHANGING lv_scacd.
  ls_e1evmhdr02-repid  = lv_scacd.
  ls_e1evmhdr02-dataid = gs_vttk-text2.                     " CR#8159

* Append segment to Idoc
  PERFORM append_segment TABLES ct_edidd
                          USING ls_e1evmhdr02
                                'E1EVMHDR02'.


ENDFORM.                    " APPEND_E1EVMHDR02_SEGMENT
*----------------------------------------------------------------------*
*       Form  GET_SCACD
*----------------------------------------------------------------------*
* This form gets the SCACD of the Vendor on the shipment
*----------------------------------------------------------------------*
FORM get_scacd  USING    iv_tknum TYPE tknum
                CHANGING cv_scacd TYPE scacd.

  CLEAR cv_scacd.
* Get SCACD code
  SELECT SINGLE scacd
         INTO   cv_scacd
         FROM   lfa1 AS lfa1
         INNER JOIN vtpa AS vtpa
         ON lfa1~lifnr = vtpa~lifnr
         WHERE vtpa~vbeln EQ iv_tknum AND
               vtpa~posnr EQ '000000'.

ENDFORM.                    " GET_SCACD
*----------------------------------------------------------------------*
*       Form  APPEND_SEGMENT
*----------------------------------------------------------------------*
* This form actually appends the segments to the Idoc data
*----------------------------------------------------------------------*
FORM append_segment TABLES ct_edidd        STRUCTURE edidd
                     USING is_segment_data TYPE      any
                           is_segment_name TYPE      edilsegtyp.

  DATA ls_idoc_data  TYPE edidd.

  IF is_segment_data IS NOT INITIAL.
    CLEAR ls_idoc_data.
    ls_idoc_data-segnam = is_segment_name.
    ls_idoc_data-sdata  = is_segment_data.
    APPEND ls_idoc_data TO ct_edidd.
  ENDIF.

ENDFORM.                    " APPEND_SEGMENT
*----------------------------------------------------------------------*
*       Form  APPEND_E1EVMTID_SEGMENT
*----------------------------------------------------------------------*
* This form appends E1EVMTID segment to the Idoc data
*----------------------------------------------------------------------*
FORM append_e1evmtid_segment TABLES ct_edidd  STRUCTURE edidd.

  DATA : ls_e1evmtid   LIKE e1evmtid.

  CLEAR ls_e1evmtid.
  ls_e1evmtid-trxid = gs_idoc_info-tknum.
  ls_e1evmtid-tipid = gs_idoc_info-itnum.

* Append segment to Idoc
  PERFORM append_segment TABLES ct_edidd
                          USING ls_e1evmtid
                                'E1EVMTID'.

ENDFORM.                    " APPEND_E1EVMTID_SEGMENT
*----------------------------------------------------------------------*
*       Form  APPEND_E1EVMPID_SEGMENT
*----------------------------------------------------------------------*
* This form appends E1EVMPID segment to the Idoc data
*----------------------------------------------------------------------*
FORM append_e1evmpid_segment TABLES ct_edidd      STRUCTURE edidd
                              USING value(iv_ind)
                                    value(iv_value).

  DATA : ls_e1evmpid   LIKE e1evmpid.

  CLEAR ls_e1evmpid.
  ls_e1evmpid-parrol = iv_ind.
  ls_e1evmpid-parid  = iv_value.

* Append segment to Idoc
  PERFORM append_segment TABLES ct_edidd
                          USING ls_e1evmpid
                                'E1EVMPID'.

ENDFORM.                    " APPEND_E1EVMPID_SEGMENT
*----------------------------------------------------------------------*
*       Form  APPEND_E1ADRM4_SEGMENT
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM append_e1adrm4_segment  TABLES ct_edidd STRUCTURE edidd
                              USING iv_adrnr TYPE      adrnr.

  DATA : ls_e1adrm4    LIKE e1adrm4,
         ls_address    TYPE addr1_val.

  PERFORM get_address        USING iv_adrnr
                          CHANGING ls_address.
  CLEAR ls_e1adrm4.
  ls_e1adrm4-name1      = ls_address-name1.
  ls_e1adrm4-name2      = ls_address-name2.
  ls_e1adrm4-street1    = ls_address-street.
  ls_e1adrm4-street2    = ls_address-streetcode.
  ls_e1adrm4-city1      = ls_address-city1.
  ls_e1adrm4-region     = ls_address-region.
  ls_e1adrm4-county_cod = ls_address-country.
  ls_e1adrm4-postl_cod1 = ls_address-post_code1.

* Append segment to Idoc
  PERFORM append_segment    TABLES ct_edidd
                             USING ls_e1adrm4
                                   'E1ADRM4'.

ENDFORM.                    "append_e1adrm4_segment
*----------------------------------------------------------------------*
*       Form  GET_ADDRESS
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_address     USING iv_adrnr   TYPE      adrnr
                  CHANGING cs_address STRUCTURE addr1_val.

  DATA : ls_address_selection TYPE addr1_sel,
         ls_address_value     TYPE addr1_val.

* Determine the address
  ls_address_selection-addrnumber = iv_adrnr.

  CALL FUNCTION 'ADDR_GET'
    EXPORTING
      address_selection = ls_address_selection
    IMPORTING
      address_value     = cs_address
    EXCEPTIONS
      parameter_error   = 1
      address_not_exist = 2
      version_not_exist = 3
      internal_error    = 4
      OTHERS            = 5.
  IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.


ENDFORM.                    " GET_ADDRESS
*----------------------------------------------------------------------*
*       Form  APPEND_E1EVMPAI_SEGMENT
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM append_e1evmpai_segment  TABLES ct_edidd STRUCTURE edidd.

  DATA : lt_vbpa      TYPE STANDARD TABLE OF vbpa,
         ls_vbpa      TYPE vbpa,
         lt_knvp      TYPE STANDARD TABLE OF knvp,
         ls_knvp      TYPE knvp,
         lv_vkorg     TYPE vkorg,
         lv_vtweg     TYPE vtweg,
         lv_spart     TYPE spart,
         ls_e1evmpai  LIKE e1evmpai.

* gt_vbpa_data will contain all the deliveries associated to the
* Itinerary Number that came from EM.
  lt_vbpa[] = gt_vbpa[].

* Reading one of the deliveries whose ship-to matches which was
* determined earlier (assuming that all the deliveries associated to one
* ship-to will get off at that stop)
  READ TABLE gt_vbpa INTO ls_vbpa WITH KEY parvw = gc_parvw_we
                                           kunnr = gs_idoc_info-ship_to.
  IF sy-subrc EQ 0.
* Deleting all other deliveries that are not associated with the
* ship-to
    DELETE lt_vbpa WHERE vbeln NE ls_vbpa-vbeln.
*    PERFORM get_knvp_data TABLES lt_vbpa
*                                 lt_knvp
*                           USING ls_vbpa.
*    IF lt_knvp[] IS NOT INITIAL.
*      SORT lt_knvp BY kunn2 parvw.
*      LOOP AT lt_knvp INTO ls_knvp.
*        IF ls_knvp-knref IS NOT INITIAL.
*          CLEAR ls_e1evmpai.
*          ls_e1evmpai-parcod = '301'.
*          ls_e1evmpai-parid = ls_knvp-knref.
*
** Append segment to Idoc
*          PERFORM append_segment    TABLES ct_edidd
*                                     USING ls_e1evmpai
*                                           'E1EVMPAI'.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.


*** TPR 27352 requested we use KNREF from VBPA instead of KNVP
        LOOP AT lt_vbpa into ls_vbpa.
        IF ls_vbpa-knref IS NOT INITIAL.
          CLEAR ls_e1evmpai.
          ls_e1evmpai-parcod = '301'.
          ls_e1evmpai-parid = ls_vbpa-knref.

* Append segment to Idoc
          PERFORM append_segment    TABLES ct_edidd
                                     USING ls_e1evmpai
                                           'E1EVMPAI'.
       ENDIF.
      ENDLOOP.

  ENDIF.

ENDFORM.                    " APPEND_E1EVMPAI_SEGMENT
*----------------------------------------------------------------------*
*       Form  GET_KNVP_DATA
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_knvp_data  TABLES it_vbpa STRUCTURE vbpa
                           ct_knvp STRUCTURE knvp
                    USING  is_vbpa STRUCTURE vbpa.

  DATA :  lv_vkorg     TYPE vkorg,
          lv_vtweg     TYPE vtweg,
          lv_spart     TYPE spart.

  SELECT SINGLE vkorg vtweg spart
         INTO (lv_vkorg, lv_vtweg, lv_spart)
         FROM likp AS likp
         INNER JOIN lips AS lips
         ON likp~vbeln = lips~vbeln
         WHERE likp~vbeln EQ is_vbpa-vbeln.
  IF sy-subrc EQ 0 AND is_vbpa-kunnr IS NOT INITIAL.
* For the current delivery partners, extract the KNVP data
    SELECT *
          FROM knvp
          INTO TABLE ct_knvp
          FOR ALL ENTRIES IN it_vbpa
          WHERE kunnr EQ is_vbpa-kunnr  AND
                vkorg EQ lv_vkorg       AND
                vtweg EQ lv_vtweg       AND
                spart EQ lv_spart       AND
                parvw EQ it_vbpa-parvw  AND
                kunn2 EQ it_vbpa-kunnr.
  ENDIF.

ENDFORM.                    " GET_KNVP_DATA
*----------------------------------------------------------------------*
*       Form  APPEND_E1EVMREF02_SEGMENT
*----------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM append_e1evmref02_segment  TABLES ct_edidd STRUCTURE edidd.

  DATA : lv_zequip_initial TYPE  scacd,
         lv_ztrailer_id    TYPE  signi,
         ls_e1evmref02     LIKE  e1evmref02,
         ls_vbfa           TYPE  tt_vbfa,
         ls_vbak           TYPE  tt_vbak,
         ls_vbkd           type  tt_vbkd.

  CALL FUNCTION 'ZDL_SPLIT_VEHICLE_NBR'
    EXPORTING
      signi    = gs_vttk-signi
    IMPORTING
      scac     = lv_zequip_initial
      equip_id = lv_ztrailer_id.

  IF lv_zequip_initial IS NOT INITIAL.
    CLEAR ls_e1evmref02.
    ls_e1evmref02-refcod = 'ZIT'.
    ls_e1evmref02-refid = lv_zequip_initial.
* Append segment to Idoc
    PERFORM append_segment    TABLES ct_edidd
                               USING ls_e1evmref02
                                     'E1EVMREF02'.
  ENDIF.

  IF lv_ztrailer_id IS NOT INITIAL.
    CLEAR ls_e1evmref02.
    ls_e1evmref02-refcod = 'ZNM'.
    ls_e1evmref02-refid = lv_ztrailer_id.
* Append segment to Idoc
    PERFORM append_segment    TABLES ct_edidd
                               USING ls_e1evmref02
                                     'E1EVMREF02'.
  ENDIF.

* >> Begin of change - CCHERUP - CR 8159
* Populating SO Numbers
  LOOP AT gt_vbfa INTO ls_vbfa.
    CLEAR ls_e1evmref02.
    ls_e1evmref02-refcod = 'SO'.
    ls_e1evmref02-refid = ls_vbfa-vbelv.
* Append segment to Idoc
    PERFORM append_segment    TABLES ct_edidd
                               USING ls_e1evmref02
                                     'E1EVMREF02'.
  ENDLOOP.

* Populating PO Numbers
* LOOP AT gt_vbak INTO ls_vbak.
* changed from VBAK to VBKD due to TPR 27352
  LOOP AT gt_vbkd INTO ls_vbkd.
    CLEAR ls_e1evmref02.
    ls_e1evmref02-refcod = 'PO'.
    ls_e1evmref02-refid = ls_vbkd-bstkd.
* Append segment to Idoc
    PERFORM append_segment    TABLES ct_edidd
                               USING ls_e1evmref02
                                     'E1EVMREF02'.
  ENDLOOP.
* << End of change - CCHERUP - CR 8159


ENDFORM.                    " APPEND_E1EVMREF02_SEGMENT

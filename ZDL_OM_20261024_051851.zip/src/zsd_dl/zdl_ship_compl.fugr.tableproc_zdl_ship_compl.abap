*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_SHIP_COMPL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_SHIP_COMPL      .

  PERFORM TABLEPROC.

ENDFUNCTION.

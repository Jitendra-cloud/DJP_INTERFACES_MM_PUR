FUNCTION-POOL zdl_e04516                 MESSAGE-ID sv.


***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2009 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
************************************************************************
**Include Name:       LZDL_E04516_TOP             Create Date: 10/28/09
*
* Supports Functions: ZDL_E04516_WEIGHT_DIMEN_CAL
*                     ZDL_E04516_GET_MATNR_UNIT_CODE
*
**Programmer  : Mark Tomazin                      Last Update: 10/28/09
*
************************************************************************
*
*eject.
*
************************************************************************
*
**Change History:
*
**  Description:                         EDVK         User-Id  Date:
*
*     1) Changes by Mark Tomazin         EDVK974096   MTOMAZ1  10/28/09
*        Added Support For Volume Calculation
*     2) Shabbir Mithaiwala              E0VK9A0LMV
*        Add Fix for Return of a broken Pallet.       SMITHAI 08/05/2015
************************************************************************

*eject.

******* Data Declaration **********************************************

******* Type Declaration **********************************************
TYPES: BEGIN OF typ_mat_obj,
            matnr TYPE mara-matnr,
            cuobf TYPE mara-cuobf,
         END   OF typ_mat_obj.
TYPES: tt_mat_obj TYPE STANDARD TABLE OF typ_mat_obj.

TYPES : BEGIN OF ts_mch1,
        matnr TYPE matnr,
        charg TYPE charg_d,
        werks TYPE werks_d,
        lgort TYPE lgort_d,
       END OF ts_mch1.

TYPES:  BEGIN OF ts_mska,
        matnr TYPE matnr,
        werks TYPE werks_d,
        lgort TYPE lgort_d,
        charg TYPE charg_d,
        kalab TYPE labst,
        vbeln TYPE vbeln,
        posnr TYPE posnr,
       END OF ts_mska.

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
TYPES:  BEGIN OF ts_mska_with_order_info,
        matnr TYPE matnr,
        werks TYPE werks_d,
        lgort TYPE lgort_d,
        charg TYPE charg_d,
        kalab TYPE labst,
        vbeln TYPE vbeln,
        posnr TYPE posnr,
       END OF ts_mska_with_order_info.
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

*eject.

TYPES: BEGIN OF ts_msku,
        matnr TYPE matnr,
        werks TYPE werks_d,
        charg TYPE charg_d,
        kulab TYPE labst,
       END OF ts_msku.

TYPES: BEGIN OF ts_mchb,
        matnr TYPE matnr,
        werks TYPE werks_d,
        lgort TYPE lgort_d,
        charg TYPE charg_d,
        clabs TYPE labst,
       END OF ts_mchb.

TYPES: BEGIN OF ts_mara,
        matnr TYPE matnr,
        matkl TYPE matkl,
        cuobf TYPE cuobm,
       END OF ts_mara.

TYPES: BEGIN OF ts_marm,
        matnr TYPE matnr,
        meinh TYPE lrmei,
        umrez TYPE umrez,
        umren TYPE umren,
       END OF ts_marm.

TYPES: BEGIN OF ts_batch,
        matnr TYPE matnr,
        charg TYPE charg_d,
        werks TYPE werks_d,
        kalab TYPE labst,
        END OF ts_batch.

TYPES: BEGIN OF ts_process,
        matnr      TYPE matnr,
        charg      TYPE charg_d,
        unit_code  TYPE z_unitcode,
        matkl      TYPE matkl,
        kalab      TYPE labst,
        charval    TYPE tt_bapi1003_alloc_values_num,

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
        vc_charval TYPE ztt_zsd_characteristic_value,
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

       END OF ts_process.

*eject.

TYPES : BEGIN OF ts_unit,
        type       TYPE z_type,
        uom        TYPE meins,
       END OF    ts_unit.
*-->CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
TYPES : BEGIN OF ts_part,
          matnr TYPE matnr,
          charg TYPE charg_d,
          werks TYPE werks_d,
          kalab TYPE labst,
        END OF ts_part.
*<--CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
******* Work Area Declaration *****************************************

DATA : gs_batch_in          TYPE zcharg,
       gs_batch_out         TYPE zbatch_out,
       gs_batch_error       TYPE zberror,
       gs_formula           TYPE zdl_char_formula,
       *gs_formula          TYPE zdl_char_formula,
       gs_messages          TYPE bal_s_msg,
       gs_charval           TYPE bapi1003_alloc_values_num,
       gv_plant_exists      TYPE c,

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
        gs_vc_charval        TYPE zsd_characteristic_value,
*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

       gs_mch1              TYPE ts_mch1,                   "#EC NEEDED
       gs_mska              TYPE ts_mska,
       gs_msku              TYPE ts_msku,
       gs_mchb              TYPE ts_mchb,
       gs_mara              TYPE ts_mara,
       gs_marm              TYPE ts_marm,
       gs_batch             TYPE ts_batch,
       gs_process           TYPE ts_process,
       gs_matnr_in          TYPE zmatnr_in,
       gs_matnr_out         TYPE zmatnr_out,
       gs_matnr_err         TYPE zmatnr_err,
*-->CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
       gs_wgtdim            TYPE ts_unit,
       gs_part              TYPE ts_part.
*<--CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
*eject.

**** Internal table Declaration ***************************************

DATA : gt_mch1    TYPE STANDARD TABLE OF ts_mch1,
       gt_mska    TYPE STANDARD TABLE OF ts_mska,

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
       gt_mska_with_order_info
               TYPE STANDARD TABLE OF ts_mska_with_order_info,
       gs_mska_with_order_info
               TYPE ts_mska_with_order_info,
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------


       gt_msku    TYPE STANDARD TABLE OF ts_msku,
       gt_mchb    TYPE STANDARD TABLE OF ts_mchb,
       gt_mara    TYPE STANDARD TABLE OF ts_mara,
       gt_marm    TYPE STANDARD TABLE OF ts_marm,
       gt_batch   TYPE STANDARD TABLE OF ts_batch,
       gt_process TYPE STANDARD TABLE OF ts_process,
       gt_formula TYPE STANDARD TABLE OF zdl_char_formula,
       gt_batch_char TYPE STANDARD TABLE OF bapi1003_alloc_values_num,
       gt_batch_val TYPE STANDARD TABLE OF BAPI1003_ALLOC_VALUES_CHAR, "CMS30690 E0VK9A0LMV SMITHAI 08/04/2016

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
        gt_vc_char TYPE STANDARD TABLE OF zsd_characteristic_value,
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------


       gt_messages TYPE zca_bal_msg_tab,
       gt_matnr_in  TYPE STANDARD TABLE OF zmatnr_in,
       gt_matnr_out TYPE STANDARD TABLE OF zmatnr_out,
       gt_matnr_err TYPE STANDARD TABLE OF zmatnr_err,
       gt_wgtdim    TYPE STANDARD TABLE OF ts_unit,
*-->CMS30690 E0VK9A0LMV SMITHAI 08/04/2016
       gt_batch_in  TYPE  zcharg OCCURS 0 WITH HEADER LINE,
       gt_part      TYPE STANDARD TABLE OF ts_part,
       gt_sddomfld  TYPE STANDARD TABLE OF zsdomfld.
*<--CMS30690 E0VK9A0LMV SMITHAI 08/04/2016

**** Variable Declaration  ********************************************

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
DATA:  gv_packed_with_6_decimals TYPE p DECIMALS 6,
       gv_packed_with_3_decimals TYPE p DECIMALS 3.
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

*eject.

DATA :

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------
*       GV_TOT_VAL_TYPE1 TYPE LABST,   "Mark Tomazin Removed LABST
*       GV_TOT_VAL_TYPE2 TYPE LABST,   "Replaced with Packed 6 Decimals
*       GV_TOT_VAL_TYPE3 TYPE LABST,   "Rounding Problem with LABST
*       GV_TOT_VAL_TOTAL TYPE LABST,   "which has 3 Decimals

       gv_tot_val_type1 LIKE gv_packed_with_6_decimals,
       gv_tot_val_type2 LIKE gv_packed_with_6_decimals,
       gv_tot_val_type3 LIKE gv_packed_with_6_decimals,
       gv_tot_val_total LIKE gv_packed_with_6_decimals,
       gv_row_tot_val   LIKE gv_packed_with_6_decimals,   " ADHUMBA
       gv_tot_val_total_3_decimals LIKE gv_packed_with_3_decimals,
*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

       gv_rounding_val1 TYPE p,
       gv_flag_calc2    TYPE c,
       gv_descrip       TYPE string,
       gv_flag_calc3    TYPE c,
       gv_flag_unit     TYPE c,
       gv_char_err      TYPE c.

*eject.

*-----------------------------------------------------------------------
* Start of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------

************************************************************************
* Include: ZSDOMFLD Macro Declares: GET-VALUE-RANGE
************************************************************************

INCLUDE zsdomfld.


************************************************************************
* Constants:
************************************************************************

** Constants - ZSDOMFLD Table Key Values:

CONSTANTS:
        gc_zsdomfld_e04516_cat            LIKE zsdomfld-category
                    VALUE 'E04516_MTART',            "CATEGORY 12 ch

        gc_zsdomfld_e04516_fieldname      LIKE zsdomfld-fieldname
                    VALUE 'CONFIGURABLE_MATERIAL',   "FIELDNAME 30 ch
        gc_zsdomfld_e04516_vc            LIKE zsdomfld-category " CHG135212
                    VALUE 'E04516_VC',     "CATEGORY 09 ch         CHG135212
        gc_zsdomfld_e04516_blank         LIKE zsdomfld-category " CHG135212
                    VALUE space.           "CATEGORY 30 ch         CHG135212

** Ranges - ZSDOMFLD Range Tables Built

RANGES: gr_configurable_material   FOR zsdomfld-fieldname,
        gr_atnam FOR zsdomfld-fieldname.                    " CHG135212

DATA: gw_validation_fg(1) TYPE c.
DATA: gv_error_message LIKE gs_batch_error-error.
DATA: gv_cuobj         TYPE cuobj.                          " CHG135212

*-----------------------------------------------------------------------
* End   of Changes by Mark Tomazin EDVK974096   MTOMAZ1 10/28/09
*-----------------------------------------------------------------------



*End-of-Include
*End-of-Include
*End-of-Include

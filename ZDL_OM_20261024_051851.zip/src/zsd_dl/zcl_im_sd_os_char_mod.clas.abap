class ZCL_IM_SD_OS_CHAR_MOD definition
  public
  final
  create public .

*"* public components of class ZCL_IM_SD_OS_CHAR_MOD
*"* do not include other source files here!!!
public section.

  interfaces /GCDS04/IF_EX_OS_CHAR_READ .
protected section.
*"* protected components of class ZCL_IM_SD_OS_CHAR_MOD
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_SD_OS_CHAR_MOD
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_SD_OS_CHAR_MOD IMPLEMENTATION.


METHOD /gcds04/if_ex_os_char_read~characteristic_read .
*----------------------------------------------------------------------*
* Copyright: March 2006 by International Paper Company
* Author	: Showry P. Kocherla
*----------------------------------------------------------------------*
* U01228 for Order Split process.
*       sales order and item
* Requires OSS note 932660.
*
* Append structure CT_ATPFIELD with PO item ZZ_UNIT_WGT, field name and value
* Requires a matching BAdi in APO to receive the data.
*
* This method is processed for each delivery line item
*----------------------------------------------------------------------*
* Data Stuctures for this BADI implementation
* I_SALES_ORG             Import      Type    VKORG                       Sales Organization
* I_DIST_CHANNEL          Import      Type    VTWEG                       Distribution Channel
* I_DIVISION              Import      Type    SPART                       Division
* I_PLANT                 Import      Type    WERKS_D                     Plant
* I_MATERIAL              Import      Type    MATNR                       Material Number
* I_CONFIG_OBJECT         Import      Type    CUOBJ                       Configuration (internal o
* I_VBAP	            Import      Type    VBAP                        Sales Document: Item Data
* E_DIAMETER              Export      Type    ATWRT                       Characteristic Value
* E_DIAMETER_UNIT         Export      Type    MEINS                       Base Unit of Measure
* E_WIDTH                 Export      Type    ATWRT                       Characteristic Value
* E_WIDTH_UNIT            Export      Type    MEINS                       Base Unit of Measure
* E_ITEM_QTY              Export      Type    ATWRT                       Characteristic Value
* E_ITEM_QTY_UNIT         Export      Type    MEINS                       Base Unit of Measure
*----------------------------------------------------------------------*
* Change History:
* 06/21/2006   SKOCHER  EDVK947463 TPRS: 13705 & 13670 MTS to prevent Roll stacking.
*----------------------------------------------------------------------*
  CONSTANTS: lc_vrkme_rl TYPE vrkme VALUE 'RL',   "Roll
             lc_meins_in TYPE meins VALUE 'IN',
             lc_width type atwrt value '100',
             lc_atnam_rolldia TYPE atnam VALUE 'ROLL_DIAMETER_WHOLE',
             lc_atnam_rollwid TYPE atnam VALUE 'ROLL_WIDTH_WHOLE',
             lc_atnam_unitwt  TYPE atnam VALUE 'UNIT_WEIGHT'.
  DATA: lt_conf    TYPE TABLE OF conf_out,
        ls_conf TYPE conf_out.
  DATA: lv_matkl TYPE matkl,
        lv_zz_wgt_roll TYPE vbap-zz_wgt_roll.

* Check if MTS Density logic needed or not by referencing table
* ZDL_MTS_DENSITY
  SELECT SINGLE matkl INTO lv_matkl
         FROM mara WHERE matnr = i_material.
  IF sy-subrc = 0.
    SELECT SINGLE matkl INTO lv_matkl FROM zdl_mts_density
                    WHERE werks = i_plant
                    AND   matkl = lv_matkl.
    IF sy-subrc <> 0.
      EXIT.  "Not MTS
    ENDIF.
  ELSE.
    EXIT.
  ENDIF.
  lv_zz_wgt_roll = i_vbap-zz_wgt_roll.

* First gather all the characteristics for the line item.
  REFRESH lt_conf.
  CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
    EXPORTING
      instance                  = i_vbap-cuobj
    TABLES
      configuration             = lt_conf
    EXCEPTIONS
      instance_not_found        = 1
      OTHERS                    = 2.
  IF sy-subrc = 0.
    CLEAR ls_conf.
    READ TABLE lt_conf INTO ls_conf WITH KEY atnam = lc_atnam_rolldia.
    IF sy-subrc = 0.
      SPLIT ls_conf-atwrt AT space INTO ls_conf-atwrt ls_conf-atwtb.
      e_diameter = ls_conf-atwrt.
    ENDIF.
*    CLEAR ls_conf.
*    READ TABLE lt_conf INTO ls_conf WITH KEY atnam = lc_atnam_rollwid.
*    IF sy-subrc = 0.
*      SPLIT ls_conf-atwrt AT space INTO ls_conf-atwrt ls_conf-atwtb.
*      e_width = ls_conf-atwrt.
*    ENDIF.
    e_width = lc_width.  "TPR-13705 & 13670
* If the ZZ_UNIT_WGT is inital, get the enterprise weight from char.
    IF lv_zz_wgt_roll IS INITIAL.
      READ TABLE lt_conf INTO ls_conf WITH KEY atnam = lc_atnam_unitwt.
      IF sy-subrc = 0.
        SPLIT ls_conf-atwrt AT space INTO ls_conf-atwrt ls_conf-atwtb.
        replace all OCCURRENCES OF ',' in ls_conf-atwrt with space.
        condense ls_conf-atwrt no-gaps.
        lv_zz_wgt_roll = ls_conf-atwrt.
      ENDIF.
    ENDIF.
  ELSE.
    "No Processing Logic
  ENDIF.

  IF i_vbap-vrkme = lc_vrkme_rl.
    IF NOT i_vbap-kwmeng IS INITIAL.
      e_item_qty = i_vbap-kwmeng.
    ENDIF.
  ELSE.
    IF NOT i_vbap-kwmeng IS INITIAL.
      IF NOT lv_zz_wgt_roll IS INITIAL.
        e_item_qty = i_vbap-kwmeng / lv_zz_wgt_roll.
      ENDIF.
    ENDIF.
  ENDIF.

  e_item_qty_unit = lc_vrkme_rl.
  e_width_unit = lc_meins_in.
  e_diameter_unit = lc_meins_in.

ENDMETHOD.
ENDCLASS.

*&---------------------------------------------------------------------*
*&  Include           ZSDU01267_CLASS                                  *
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       CLASS gcl_event_handler IMPLEMENTATION
*----------------------------------------------------------------------*
CLASS gcl_event_handler IMPLEMENTATION.

  METHOD handle_double_click.
    PERFORM handle_double_click USING e_row
                                      e_column
                                      es_row_no.
  ENDMETHOD.

ENDCLASS.                    "

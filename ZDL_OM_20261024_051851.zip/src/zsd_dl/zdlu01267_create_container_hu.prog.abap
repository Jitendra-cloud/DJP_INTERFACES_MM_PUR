*&--------------------------------------------------------------------*
*& Report  ZSDU01267_CREATE_CONTAINER_HU                              *
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**           COPYRIGHT (C) 2003 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                           **
**             REVISIONS COPYRIGHT (C) 2007, 20nn                    **
**                    by INTERNATIONAL PAPER                         **
*_____________________________________________________________________*
* Report Name: ZSDU01267_CREATE_CONTAINER_HU         Date: 04/16/2007 *
* Programmer : Bruce Ballehr                                          *
*_____________________________________________________________________*
* Description :                                                       *
*   This program will allow the user to either create a Container     *
*   Handling Unit or re-issue a Container Tally.                      *
*_____________________________________________________________________*
* Change History:                                                     *
*   Programmer       Date     Req. #            Action                *
* ===============  ========  =========  ==============================*
* Bruce Ballehr    04/16/07  EDEK907765 Initial creation              *
*                                                                     *
***********************************************************************


INCLUDE ZDLU01267top.

INCLUDE zdlu01267_class.

INCLUDE ZDLU01267O01.

INCLUDE ZDLU01267I01.

INCLUDE ZDLU01267F01.

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_SYVASNTOP.                    " Global Declarations
  INCLUDE LZDL_SYVASNUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_SYVASNF...                    " Subroutines
* INCLUDE LZDL_SYVASNO...                    " PBO-Modules
* INCLUDE LZDL_SYVASNI...                    " PAI-Modules
* INCLUDE LZDL_SYVASNE...                    " Events
* INCLUDE LZDL_SYVASNP...                    " Local class implement.
* INCLUDE LZDL_SYVASNT99.                    " ABAP Unit tests

INCLUDE lzdl_syvasnf01.

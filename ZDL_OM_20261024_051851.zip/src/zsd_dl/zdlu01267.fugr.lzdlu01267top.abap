FUNCTION-POOL ZDLU01267                  MESSAGE-ID SV.

* INCLUDE LZDLU01267D...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDLU01267T00                           . "view rel. data dcl.

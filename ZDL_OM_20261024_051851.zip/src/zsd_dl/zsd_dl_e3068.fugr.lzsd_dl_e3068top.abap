FUNCTION-POOL zsd_dl_e3068.                 "MESSAGE-ID ..

DATA:
  l_xvtts_new LIKE vttsvb,
  l_counter LIKE sy-tabix,
  l_shtyp LIKE vttk-shtyp,
  l_vttk LIKE vttkvb.

FIELD-SYMBOLS:
  <a> TYPE vttsvb, "Origin
  <z> TYPE vttsvb, "Destination
  <r> TYPE vttsvb. "Return Leg

CONSTANTS:
  BEGIN OF c,
    return_leg  LIKE vttsvb-laufk        VALUE '5',
    update_flag LIKE vttsvb-updkz        VALUE 'I',
    prog_id     LIKE zsp_value-pgrmid    VALUE 'ZSD_DL_E3068_RETURN_LEG' ,
    fieldname   LIKE zsp_value-fieldname VALUE 'RECEIVER',
    true                                 value 'X',
    route_ok1                            value 'D',
    route_ok2                            value 'P',
    receiver    like zrecmail-receiver   value 'WILLIAM.ROY1@IPAPER.COM',
    mailtype    like zrecmail-mail_type   value 'U',
  END OF c.

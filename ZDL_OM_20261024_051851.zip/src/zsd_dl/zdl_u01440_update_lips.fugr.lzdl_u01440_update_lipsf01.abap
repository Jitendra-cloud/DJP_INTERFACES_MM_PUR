*----------------------------------------------------------------------*
***INCLUDE LZDL_U01440_UPDATE_LIPSF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DELV_QTY_UOM
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_XLIPS_MATNR  text
*      -->P_XLIPS_ZZLINEAR_UNIT  text
*      -->P_LV_OUT_ME  text
*      -->P_LV_MENGE_IN  text
*      <--P_LV_MENGE_OUT  text
*----------------------------------------------------------------------*
form get_delv_qty_uom  using    iv_matnr type matnr
                                iv_in_me type meins
                                iv_out_me type meins
                                iv_menge_in type ekpo-menge
                       changing cv_anfme type ekpo-menge.


*if iv_matnr is INITIAL.
CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
  EXPORTING
    input                      = iv_menge_in
*   NO_TYPE_CHECK              = 'X'
*   ROUND_SIGN                 = ' '
   UNIT_IN                    = iv_in_me
   UNIT_OUT                   = iv_out_me
 IMPORTING
*   ADD_CONST                  =
*   DECIMALS                   =
*   DENOMINATOR                =
*   NUMERATOR                  =
   OUTPUT                     = cv_anfme
* EXCEPTIONS
*   CONVERSION_NOT_FOUND       = 1
*   DIVISION_BY_ZERO           = 2
*   INPUT_INVALID              = 3
*   OUTPUT_INVALID             = 4
*   OVERFLOW                   = 5
*   TYPE_INVALID               = 6
*   UNITS_MISSING              = 7
*   UNIT_IN_NOT_FOUND          = 8
*   UNIT_OUT_NOT_FOUND         = 9
*   OTHERS                     = 10
          .
*IF sy-subrc <> 0.
** MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
**         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
*ENDIF.
*
*else.
*  call function 'MD_CONVERT_MATERIAL_UNIT'
*    exporting
*      i_matnr              = iv_matnr "material
*      i_in_me              = iv_in_me
*      i_out_me             = iv_out_me "'FT'
*      i_menge              = iv_menge_in
*    importing
*      e_menge              = cv_anfme
*    exceptions
*      error_in_application = 1
*      error                = 2
*      others               = 3.
*endif.

endform.                    " GET_DELV_QTY_UOM

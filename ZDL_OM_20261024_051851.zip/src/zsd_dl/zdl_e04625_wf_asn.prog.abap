************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2005 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: R2863 - Allocation Record Comparison Report            *
*                                                                      *
* SAP Name    : ZDL_E04625_WF_ASN                Create Date: 07/16/10 *
*                                                                      *
* Programmer  : Veeram Satish Reddy              Last Update:          *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*                                                                      *
* Workflow calls this new custom Z transaction to perform a certain    *
* operation on the idoc. The operations will be one of the following:  *
*  1.	Change the PO number that was in error on the idoc               *
*      and reprocess the idoc                                          *
*      o  This process will mimic the WE19 transaction                 *
*      o  A new idoc is processed and the old one is set to a status   *
*         of #70#. The old idoc will store the new idoc#s #idoc number#*
*         in field EDIDS-STAPA1                                        *
*  2.	Archive idoc (set to status 68)                                  *
*  3.	Reprocess idoc as is (with no changes) # mimics transaction BD87 *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Veeram Satish Reddy 07/16/10          Initial development CR#09966   *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*   Function Modules:                                                  *
*                                                                      *
*   Transactions    : ZDL_E04625                                       *
*   Function Module : ZDL_E04625_GET_ASN_DATA                          *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************

** Top Include
INCLUDE zdl_e04625_top.
** PAI Include
INCLUDE zdl_e04625_i01.
** PBO Include
INCLUDE zdl_e04625_o01.
** Subrountines Include
INCLUDE zdl_e04625_f01.

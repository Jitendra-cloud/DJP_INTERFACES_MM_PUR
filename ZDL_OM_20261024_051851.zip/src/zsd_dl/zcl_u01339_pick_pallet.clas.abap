class ZCL_U01339_PICK_PALLET definition
  public
  final
  create public .

*"* public components of class ZCL_U01339_PICK_PALLET
*"* do not include other source files here!!!
public section.
  type-pools ZWMPP .

  data GT_HU_ITEM type ZWMPP_TT_VEPO .
  data GT_SOURCE_HU type ZWMPP_TT_S_HU .
  data GS_VEKP type VEKP .
  data GS_LEIN type LEIN .
  data GT_LOG_MSG type ZCA_BAL_MSG_TAB .
  class-data GT_WMPP_TYP_CHARG type ZWMPP_TT_CHARG .
  data GV_SOURCE_NESTED_FLAG type CHAR1 .
  data GT_SR_CHILD_RELATION type HUM_HU_HEADER_T .
  data GT_DE_CHILD_RELATION type HUM_HU_HEADER_T .
  data GS_DES_VEKP type VEKP .
  data GT_DES_VEPO type ZWMPP_TT_VEPO .
  data GV_DES_NESTED_FLAG type CHAR1 .
  data GV_ASSOCIATION_FLAG type CHAR1 .
  data GV_INITIAL_CHILD_HU type NUM8 .

  class-methods BATCH_2_BATCH_TRANS_MB1B
    importing
      !IT_BATCH type ZWMPP_TT_BATCH_TO_BATCH
    exporting
      !ET_CHARG_MBLNR type ZWMPP_TT_CHARG_MBLNR
      !ET_BAL_S_MSG type ZCA_BAL_MSG_TAB
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods BATCH_CHARACTERISTICS_UPDATE
    importing
      !IT_BATCH_CHARACTERISTICS type TT_BAPI1003_ALLOC_VALUES_NUM
      !IV_BATCH type VEPO-CHARG
      !IV_MATERIAL type VEPO-MATNR
      !IV_PLANT type VEPO-WERKS
      !IV_OLD_BATCH type CHARG_D
    exporting
      !ET_MESSAGES type ZCA_BAL_MSG_TAB .
  class-methods BATCH_TO_BATCH_TRANSFER
    importing
      !IT_HU_BATCH_OLD type TAB_VEPO
      !IT_HU_BATCH_NEW type TAB_VEPO
      !IV_EXIDV type HUM_EXIDV
    exporting
      !EV_MATERIAL_DOCUMENT type MBLNR
      !ET_RETURN type BAPIRET2_T
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods CHECK_ALPHANUMERIC_CHAR
    importing
      !IV_VALUE type CHAR30
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods CHECK_HU_LENGTH
    importing
      !IV_EXIDV type EXIDV
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods CHECK_MATERIAL_DELIVERY
    importing
      !IV_MATNR type MATNR
      !IV_VBELN type VBELN_VL
      !IV_POSNR type POSNR_VL
    exporting
      !EV_INVALID_DELIVERY type CHAR1 .
  class-methods CHECK_MATERIAL_UNIT_CODE
    importing
      !IV_ATNAM type ATNAM
      !IT_MATNR type ZWMPP_TT_MATNR
    exporting
      !EV_ERR_FLAG type CHAR1 .
  class-methods CHECK_MATERIAL_UOM
    importing
      !IV_MATNR type MATNR
      !IV_ALT_UOM type LRMEI
      !IV_BASE_UOM type LRMEI
      !IV_MENGE type BSTMG
    exporting
      !EV_CONVERTED_QTY type BSTMG
    raising
      ZCX_U01339_PICK_PALLET .
  methods CONSTRUCTOR
    importing
      !IV_EXIDV type EXIDV
      !IV_LGNUM type LGNUM
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods DELETE_HU
    importing
      !IV_EXIDV type EXIDV
    exporting
      !ET_RETURN type ZCA_BAL_MSG_TAB
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_CARTONS_PER_PALLET
    importing
      !IV_MATNR type MATNR
      !IV_CHARG type CHARG_D
      !IV_WERKS type WERKS_D
    exporting
      !EV_ATWRT type ATWRT
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_HUDAT_ENTRIES
    importing
      !IT_HU type ZWMPP_TT_HANDLING_UNIT optional
      !IT_TKNUM type ZWMPP_TT_TKNUM optional
    exporting
      !ET_HUDAT type ZWMPP_TT_HUDAT
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_HU_FOR_MATERIAL
    importing
      !IV_MATNR type MATNR
      !IV_LGNUM type LGNUM
    exporting
      !ET_VEPO type ZWMPP_TT_VEPO
      !ET_VEKP type ZWMPP_TT_VEKP
      !ET_HU_MATERIAL type ZWMPP_TT_LGPLA
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_HU_HEADER_DETAILS
    importing
      !IV_EXIDV type EXIDV optional
      !IV_VENUM type VENUM optional
      !IV_LGNUM type LGNUM
      !IV_WHERE_FLAG type CHAR1 optional
    exporting
      !EV_VEKP type VEKP
    raising
      ZCX_U01339_PICK_PALLET .
  methods GET_HU_ITEM_DETAILS
    importing
      !IV_VENUM type VENUM optional
    exporting
      !ET_HU_ITEM type ZWMPP_TT_VEPO
      !ET_CHILD_RELATION type HUM_HU_HEADER_T
      !EV_HU_NESTED type CHAR1
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_MAT_CHARACTERISTICS
    importing
      !IT_CHARAC type ZWMPP_TT_CHARAC
    exporting
      !ET_CHARAC_VALUES type ZWMPP_TT_CHARC_VALUES
      !ET_RETURN type ZWMPP_TT_BAPIRET2 .
  class-methods GET_NEXT_BATCH_NUMBER
    returning
      value(EV_CHARG) type CHARG_D .
  class-methods GET_PARTNER_STOLOC
    importing
      !IV_WERKS type WERKS_D
      !IV_LGORT type LGORT_D
    returning
      value(IV_PARLG) type PARLG
    raising
      ZCX_U01339_PICK_PALLET .
  methods GET_PICK_PALLET_DATA
    importing
      !IT_VEPO type ZWMPP_TT_VEPO
    exporting
      !ET_HU_ITEM type ZWMPP_TT_S_HU
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_STORAGE_UNIT_DETAILS
    importing
      !IV_EXIDV type EXIDV
    exporting
      !EV_LEIN type LEIN
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods GET_USER_ATTRIBUTES
    exporting
      !EV_LGNUM type LGNUM
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods LOCK_HANDLING_UNIT
    importing
      !IV_VENUM type VENUM
    raising
      ZCX_U01339_PICK_PALLET .
  methods MOVE_HU_BIN_TO_BIN
    importing
      !IV_EXIDV type EXIDV
      !IV_LGPLA type LGPLA
      !IV_NLTYP type LTAP_NLTYP
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods PACK_HANDLING_UNIT
    importing
      !IS_VEKP type VEKP
      !IT_VEPO type ZWMPP_TT_VEPO
      !IV_REPACK type CHAR1 optional
    exporting
      !ET_RETURN type ZCA_BAL_MSG_TAB
      !ET_HU_HEADER type HUM_HU_HEADER_T
      !ET_HU_ITEMS type HUM_HU_ITEM_T
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods PACK_NESTED_HU
    importing
      !IS_PARENT_HU type VEKP
      !IT_SUB_HU type ZWMPP_TT_SUB_HU
    exporting
      !ET_RETURN type ZCA_BAL_MSG_TAB
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods READ_BATCH_CHARACTERISTIC
    importing
      !IV_BATCH type VEPO-CHARG
      !IV_MATERIAL type VEPO-MATNR
      !IV_PLANT type VEPO-WERKS
    exporting
      !ET_BATCH_CHARACTERISTICS type TT_BAPI1003_ALLOC_VALUES_NUM
      !EV_MSG type UMGATEXT39
      !ET_MESSAGES type ZCA_BAL_MSG_TAB
      !ET_BATCH_CHAR_VALUES type TT_BAPI1003_ALLOC_VALUES_CHAR .
  methods SET_DES_HUHEADER_DETAILS
    importing
      !IV_VEKP type VEKP .
  methods SET_DES_HU_ITEM_DETAILS
    importing
      !IT_DES_VEPO type ZWMPP_TT_VEPO optional
      !IT_DES_CHILD_RELATION type HUM_HU_HEADER_T optional
      !IV_HU_NESTED type CHAR1 optional .
  class-methods SET_MESSAGE_BUFFER
    importing
      !IV_MESSAGE_TYPE type SYMSGTY
      !IV_MSGV1 type SYMSGV
      !IV_MSGV2 type SYMSGV optional
      !IV_MSGV3 type SYMSGV optional
      !IV_MSGV4 type SYMSGV optional
      !IV_MSGID type SYMSGID optional
      !IV_MSGNO type SYMSGNO optional
    exporting
      !ES_BAL_S_MSG type BAL_S_MSG .
  methods SET_SOURCE_HU
    importing
      !IT_BATCH type ZWMPP_TT_S_HU
      !IV_EXIDV type EXIDV
      !IV_CONSOLIDATION_FLAG type CHAR1 optional .
  methods SET_SOURCE_HU_CHILD_REL
    importing
      !IT_SR_CHILD_RELATION type HUM_HU_HEADER_T optional
      !IT_SR_HU_VEPO type ZWMPP_TT_VEPO optional
      !IV_HU_NESTED type CHAR1 optional .
  class-methods UNLOCK_HANDLING_UNIT
    importing
      !IV_VENUM type VENUM .
  class-methods UNPACK_HANDLING_UNIT
    importing
      !IT_VEPO type ZWMPP_TT_VEPO optional
      !IS_VEKP type VEKPVB optional
      !IV_HU_DELETE type CHAR1 optional
    exporting
      !EV_SUBRC type SUBRC
      !ET_RETURN type ZCA_BAL_MSG_TAB
      !EV_PALLET_DELETED type CHAR1
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods UNPACK_NESTED_SOURE_HU
    importing
      !IS_PARENT_HU_HEADER type VEKP
      !IT_PARENT_HU_ITEMS type HUM_HU_ITEM_T
      !IT_CHILD_HU_HEADER type HUM_HU_HEADER_T
    exporting
      !ET_RETURN type ZCA_BAL_MSG_TAB
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods UPDATE_HUDATE
    importing
      !IV_UPDATE_MODE type CHAR1
      !IT_HUDAT type ZWMPP_TT_HUDAT
    exporting
      !ET_RETURN type ZCA_BAL_MSG_TAB .
  class-methods VALIDATE_SHPMT_DEL_WHS
    importing
      !IV_TKNUM type TKNUM
      !IT_DEL_ITEM type ZWMPP_TT_DEL_ITEM
      !IV_LGNUM type LGNUM
    exporting
      !EV_TPLST type TPLST
      !EV_KUNNR type KUNNR
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods VALIDATE_STORAGE_BIN
    importing
      !IV_LGPLA type LGPLA
      !IV_LGNUM type LGNUM
    exporting
      !ES_LAGP type LAGP
    raising
      ZCX_U01339_PICK_PALLET .
  methods WRITE_APPLICATION_LOG
    importing
      !IV_EXIDV type EXIDV
      !IT_LOG_MSG type ZCA_BAL_MSG_TAB optional .
protected section.
*"* protected components of class ZCL_U01339_PICK_PALLET
*"* do not include other source files here!!!

  class-methods LOCK_HUDAT_ENTRY
    importing
      !IV_PARENT type ZDL_PEXIDV optional
      !IV_CHILD type ZDL_CEXIDV optional
      !IV_MATNR type MATNR optional
      !IV_CHARG type CHARG_D optional
    raising
      ZCX_U01339_PICK_PALLET .
  class-methods UNLOCK_HUDAT_ENTRY
    importing
      !IV_PARENT type ZDL_PEXIDV optional
      !IV_CHILD type ZDL_CEXIDV optional
      !IV_MATNR type MATNR optional
      !IV_CHARG type CHARG_D optional .
private section.
*"* private components of class ZCL_U01339_PICK_PALLET
*"* do not include other source files here!!!

  methods VALIDATE_HANDLING_UNIT
    importing
      !IV_EXIDV type EXIDV
      !IV_LGNUM type LGNUM
    exporting
      !EV_LEIN type LEIN
      !EV_VEKP type VEKP
    raising
      ZCX_U01339_PICK_PALLET .
ENDCLASS.



CLASS ZCL_U01339_PICK_PALLET IMPLEMENTATION.


METHOD BATCH_2_BATCH_TRANS_MB1B .
*-----------------------------------------------------------*
*              D A T A   D E C L A R A T I O N S            *
*-----------------------------------------------------------*
  DATA: LS_IMKPF       TYPE IMKPF,
        LS_IMSEG       TYPE IMSEG,
        LS_EMKPF       TYPE EMKPF,
        LT_EMSEG       TYPE STANDARD TABLE OF EMSEG,
        LT_IMSEG       TYPE STANDARD TABLE OF IMSEG,
        LS_BATCH       TYPE ZWMPP_TYP_BATCH_TO_BATCH,
        LS_BAL_S_MSG   TYPE BAL_S_MSG,
        LS_CHARG_MBLNR TYPE ZWMPP_TYP_CHARG_MBLNR.
  CONSTANTS : LC_BWART TYPE BWART VALUE '309'.
  DATA: LV_MSG TYPE SYMSGV,
        LV_MSG1 TYPE SYMSGV,
        LV_MSG2 TYPE SYMSGV,
        LV_TYP TYPE SYMSGTY,
* Start of Changes by VBHAGAV on 05/22/2009
        LV_MSGID         TYPE SYMSGID,
        LV_MSGNO         TYPE SYMSGNO,
        LV_MSGV1         TYPE SYMSGV,
        LV_MSGV2         TYPE SYMSGV,
        LV_MSGV3         TYPE SYMSGV,
        LV_MSGV4         TYPE SYMSGV.
* End   of Changes by VBHAGAV on 05/22/2009
* Collect the current date
  LS_IMKPF-BLDAT = LS_IMKPF-BUDAT = SY-DATUM.
* Collect the movement type
  LS_IMSEG-BWART = LC_BWART.

* Capture both from and to batch details. Transfer posting for each from and to batch
  LOOP AT IT_BATCH INTO LS_BATCH.
    IF LS_BATCH-FR_CHARG <> LS_BATCH-TO_CHARG.
      LS_IMSEG-WERKS     = LS_IMSEG-UMWRK     =  LS_BATCH-WERKS.  " Plant
      LS_IMSEG-LGORT     = LS_IMSEG-UMLGO     =  LS_BATCH-LGORT.  " Storage Location
      LS_IMSEG-MATNR     = LS_IMSEG-UMMAT     =  LS_BATCH-MATNR.  " Material
      LS_IMSEG-MENGE     = LS_BATCH-MENGE.   " Quantity
      LS_IMSEG-ERFMG     = LS_BATCH-MENGE.   " Quantity
* If the Base unit of measure is CARTONS, then populate Unit of entry to CARTONS.
      CASE LS_BATCH-MEINS.
        WHEN ZWMPP_GC_CARTONS.
*        LS_IMSEG-MEINS     = ZWMPP_GC_POUNDS.       "'LB'
          LS_IMSEG-ERFME     = LS_BATCH-MEINS.
* If the Base unit of measure is POUNDS, then populate Unit of entry to POUNDS.
        WHEN OTHERS.
          LS_IMSEG-MEINS   = LS_IMSEG-ERFME = LS_BATCH-MEINS.   " Unit of Measure
      ENDCASE.
*    LS_IMSEG-MEINS     = LS_IMSEG-ERFME     = LS_BATCH-MEINS.   " Unit of Measure
      LS_IMSEG-CHARG     = LS_BATCH-FR_CHARG.                     " Old_Batch
      LS_IMSEG-UMCHA     = LS_BATCH-TO_CHARG.                     " New Batch

      APPEND LS_IMSEG TO LT_IMSEG.
    ELSE.
      CONTINUE.
    ENDIF.

* process batch to batch transfer. A material document number would be returned
* if the transfer is successful
    CALL FUNCTION 'MB_CREATE_GOODS_MOVEMENT'
      EXPORTING
        IMKPF       = LS_IMKPF
        XALLP       = 'X'
        XALLB       = 'X'
        XALLR       = 'X'
        CTCOD       = 'MB1B'
        X_AUTHORITY = 'X'
      IMPORTING
        EMKPF       = LS_EMKPF
      TABLES
        EMSEG       = LT_EMSEG
        IMSEG       = LT_IMSEG.
    IF NOT LS_EMKPF-MBLNR IS INITIAL.
* If a Material document is returned, then post the document and Commit the
* database.
      CALL FUNCTION 'MB_POST_GOODS_MOVEMENT'.
      COMMIT WORK AND WAIT.
* Capture the Material document, from batch and to batch
      LS_CHARG_MBLNR-MBLNR = LS_EMKPF-MBLNR.
      LS_CHARG_MBLNR-FR_CHARG = LS_BATCH-FR_CHARG.                     " Old_Batch
      LS_CHARG_MBLNR-TO_CHARG = LS_BATCH-TO_CHARG.                     " New Batch
      APPEND LS_CHARG_MBLNR TO ET_CHARG_MBLNR.
      CLEAR LS_CHARG_MBLNR.
* Return success Message to the calling program
      CLEAR : LV_MSG1,
              LV_TYP.
* Populate the error message
      LV_MSG1 = 'Batch transfer successful'(I33).
      LV_TYP = ZWMPP_GC_S.
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MESSAGE_TYPE = LV_TYP
          IV_MSGV1        = LV_MSG1
          IV_MSGV2        = LV_MSG2
*    IV_MSGV3        =
*    IV_MSGV4        =
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_S_MSG.
* Start of Changes by VBHAGAV on 05/22/2009
      APPEND LS_BAL_S_MSG TO ET_BAL_S_MSG.  "
      CLEAR LS_BAL_S_MSG.
* End   of Changes by VBHAGAV on 05/22/2009
    ELSE.
* IF no material document is created in the above process, then populate error
* message and return it to the calling program
      CLEAR : LV_MSG,
              LV_MSGID,
              LV_MSGNO,
              LV_MSGV1,
              LV_MSGV2,
              LV_MSGV3,
              LV_MSGV4.
* Start of Changes by VBHAGAV on 05/22/2009
      LV_MSGID = SY-MSGID.
      LV_MSGNO = SY-MSGNO.
      LV_MSGV1 = SY-MSGV1.
      LV_MSGV2 = SY-MSGV2.
      LV_MSGV3 = SY-MSGV3.
      LV_MSGV4 = SY-MSGV4.
* End   of Changes by VBHAGAV on 05/22/2009

* capture the error message
      CALL FUNCTION 'FORMAT_MESSAGE'
        EXPORTING
          ID        = SY-MSGID
          LANG      = SY-LANGU
          NO        = SY-MSGNO
          V1        = SY-MSGV1
          V2        = SY-MSGV2
          V3        = SY-MSGV3
          V4        = SY-MSGV4
        IMPORTING
          MSG       = LV_MSG
        EXCEPTIONS
          NOT_FOUND = 1
          OTHERS    = 2.
      IF SY-SUBRC <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
      ENDIF.
      LV_TYP = ZWMPP_GC_E.
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MESSAGE_TYPE = LV_TYP
          IV_MSGV1        = LV_MSG
*    IV_MSGV2        =
*    IV_MSGV3        =
*    IV_MSGV4        =
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_S_MSG.

      APPEND LS_BAL_S_MSG TO ET_BAL_S_MSG.  "
      CLEAR LS_BAL_S_MSG.

* Start of Changes by VBHAGAV on 05/22/2009
* Capture the standard message
      CLEAR LS_BAL_S_MSG.
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MESSAGE_TYPE = LV_TYP
          IV_MSGV1        = LV_MSGV1
          IV_MSGV2        = LV_MSGV2
          IV_MSGV3        = LV_MSGV3
          IV_MSGV4        = LV_MSGV4
          IV_MSGID        = LV_MSGID
          IV_MSGNO        = LV_MSGNO
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_S_MSG.
      APPEND LS_BAL_S_MSG TO ET_BAL_S_MSG.  "
      CLEAR LS_BAL_S_MSG.
* End   of Changes by VBHAGAV on 05/22/2009

      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
         EXPORTING
           TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_BATCH_TO_BATCH_ERR.

    ENDIF.

*   Raise exception when ever Batch to Batch failed


  ENDLOOP.

ENDMETHOD.


method batch_characteristics_update .
*------------------------------------------------------------------------------------------------*
* This method updates the characteristics of a Batch Number. The following interface is provided *
* IT_BATCH_CHARACTERISTICS  - Contains the characteristics and their corresponding values        *
* IV_BATCH                  - Contains the batch number whose characteristics need to be updated *
* IV_MATERIAL               - Material number, the batch number is associated with.              *
* IV_PLANT                  - Plant associated with the material.                                *
* ET_MESSAGES	              - Returns any errors messages generated by this method.              *
* LOGIC :  The Class name and type, which will usually be the batch and material concatenated    *
*********  together, are retrieved using the function module 'QC01_BATCH_CLASS'. The             *
*          characteristics are then suppilied to a BAPI 'BAPI_OBJCL_CHANGE'. This BAPI would     *
*          inturn update the Batch characteristics. An error message is populated if the update  *
*          fails.                                                                                *
* NOTE :   Pick Pallet process requires a specific message format. All the messages preceed with *
*          Handling Unit. To facilitate this, Pick Pallet would supply a dummy characteristic    *
*         'HU_NUMBER' with the Handling unit(HU) as its corresponding value. The below program   *
*          would capture the Handling unit number and populate seperate messages for Pick Pallet.*
*          The following is the message format used by Pick Pallet.
*          <HU Number> : <Message> <Batch Number>.
*------------------------------------------------------------------------------------------------*
  data: ls_class              type klah-class,
        ls_class_type         type klah-klart,
        ls_pobtab             type tclao-obtab,
        lv_objec_charg        type  kssk-objek,
        lv_item_no            type huitem_unpack-unpack_posnr,
        lv_no_of_rolls        type i,
        ls_allocvaluescharnew type bapi1003_alloc_values_char,
        ls_allocvaluesnumnew type bapi1003_alloc_values_num,
        lt_allocvaluesnumnew  type table of bapi1003_alloc_values_num,
        lt_allocvaluescharnew type table of bapi1003_alloc_values_char,
        lt_allocvaluescurrnew type table of bapi1003_alloc_values_curr,
        lt_bapiret2           type zwmpp_tt_bapiret2,
        lf_objectkey          type bapi1003_key-object,
        lf_objecttable        type bapi1003_key-objecttable,
        lf_classnum           type bapi1003_key-classnum,
        lf_classtype          type bapi1003_key-classtype,
        lv_msg                type symsgv,
        lv_msgtyp             type symsgty,
        ls_bal_msg            type bal_s_msg,
        ls_batch_ch           type bapi1003_alloc_values_num,
        ls_wmpp_typ_charg     type zwmpp_typ_charg,
        lv_exidv              type exidv,
        ls_char_batch         type bapi1003_alloc_values_char,
        ls_bapiret2           type bapiret2.

* Capture the Handling Unit. This process is specific for Pick Pallet
  read table it_batch_characteristics into ls_batch_ch with key charact = 'HU_NUMBER'.
  if sy-subrc = 0.
    lv_exidv = ls_batch_ch-charact_descr.
  endif.
*Once the original HU has been successfully unpacked , then Repack the
*batches based on the new HU entered on the second screen. Before that ,
*the batch characteristics needs to be updated with Cartons per pallet and weight in pounds

*Get the Class name and type which will usually be the batch and
*material concatenated together.
  call function 'QC01_BATCH_CLASS'
    exporting
      i_batch        = iv_batch
      i_material     = iv_material
      i_plant        = iv_plant
      i_language     = sy-langu
    importing
      e_class        = ls_class
      e_class_type   = ls_class_type
      e_objec_charg  = lv_objec_charg
      e_obtab        = ls_pobtab
    exceptions
      no_class       = 1
      internal_error = 2
      no_material    = 3
      no_batch       = 4
      no_plant       = 5
      others         = 6.
* No data is retrieved, then populate error messages
  if sy-subrc <> 0.
    case sy-subrc.
      when '1'.
        if not lv_exidv is initial.
          concatenate lv_exidv ':' 'No class found'(e15) iv_batch into lv_msg separated by space.
        else.
          concatenate 'No class found'(e15) iv_batch into lv_msg separated by space.
        endif.
      when '2'.
        if not lv_exidv is initial.
          concatenate lv_exidv ':' 'Batch update failed.Internal Error'(e16) iv_batch into lv_msg separated by space.
        else.
          concatenate 'Batch update failed.Internal Error'(e16) iv_batch into lv_msg separated by space.
        endif.
      when '3'.
        if not lv_exidv is initial.
          concatenate lv_exidv ':' 'Batch update failed.No Material found'(e17) iv_batch into lv_msg separated by space.
        else.
          concatenate 'Batch update failed.No Material found'(e17) iv_batch into lv_msg separated by space.
        endif.
      when '4'.
        if not lv_exidv is initial.
          concatenate lv_exidv ':' 'Batch update failed.Invalid batch'(e18) iv_batch into lv_msg separated by space.
        else.
          concatenate 'Batch update failed.Invalid batch'(e18) iv_batch into lv_msg separated by space.
        endif.
      when '5'.
        if not lv_exidv is initial.
          concatenate lv_exidv ':' 'Batch update failed.No Plant found'(e19) iv_batch  into lv_msg separated by space.
        else.
          concatenate 'Batch update failed.No Plant found'(e19) iv_batch  into lv_msg separated by space.
        endif.
      when others.
        if not lv_exidv is initial.
          concatenate lv_exidv ':' 'Batch update failed'(e12) iv_batch  into lv_msg separated by space.
        else.
          concatenate 'Batch update failed'(e12) iv_batch  into lv_msg separated by space.
        endif.
    endcase.
* Rollback Work
    rollback work.
    lv_msgtyp = zwmpp_gc_e.
* Set the Message
    call method zcl_u01339_pick_pallet=>set_message_buffer
      exporting
        iv_msgv1        = lv_msg
        iv_msgid        = zwmpp_dl_wm
        iv_msgno        = zwmpp_gc_000
        iv_message_type = lv_msgtyp
      importing
        es_bal_s_msg    = ls_bal_msg.
  endif.


* Return the error messages to the calling program
  if not ls_bal_msg is initial.
    append ls_bal_msg to et_messages.
    clear : ls_bal_msg.
  endif.
* If no Class is found, then return to the calling program
  if lv_msgtyp = zwmpp_gc_e.
* return to the calling program
    exit.
  endif.

* Call BAPI 'BAPI_OBJCL_CHANGE' This BAPI changes an existing classification, or creates the classification
* if it does not yet exist. The classification is defined by the required entry fields for the object key
* (ObjectKey),object table (ObjectTable), class name (AllocDetail-Class_Num), and class type
* (AllocDetail-Class_Type).The default value for the optional date field (KeyDate) is the system date,
* on which all classifications become valid. The new characteristics and/or values are transferred to
* different tables according to data type. Numeric, time, and date characteristics are transferred to
* table AllocValuesNumNew, character and boolean characteristics are transferred to table AllocValuesCharNew,
* and currency characteristics are transferred to AllocValuesCurrNew.
  clear : lv_msgtyp,
          lv_msg.

* Populate the class, class type, Batch number and the Name of database table for object
  lf_classnum  = ls_class.            " Class
  lf_classtype = ls_class_type.       " Class type
  lf_objectkey = lv_objec_charg.      " Batch Number
  lf_objecttable = ls_pobtab.         " Name of database table for object

* Call BAPI to update the characteristics

*Retain the original characteristics
  clear : ls_wmpp_typ_charg .
  read table gt_wmpp_typ_charg into ls_wmpp_typ_charg
                   with key matnr = iv_material
                            charg = iv_old_batch.
  lt_allocvaluescharnew  = ls_wmpp_typ_charg-alloc_values_char.
  lt_allocvaluescurrnew  = ls_wmpp_typ_charg-alloc_values_curr .
  lt_allocvaluesnumnew  =  ls_wmpp_typ_charg-alloc_values_num .
* Following characteristics will be populated from Source processing table
  delete lt_allocvaluesnumnew  where charact = 'CARTONS_PER_PALLET'.
  delete lt_allocvaluesnumnew  where charact = 'WEIGHT_OF_PALLET_IN_LBS'.

* Populate all the characteristics that need to be updated. Dummy Characteristic HU_NUMBER is ignored.
  loop at it_batch_characteristics into ls_batch_ch.
    if not ls_batch_ch-charact = 'HU_NUMBER'.
      ls_allocvaluesnumnew-charact = ls_batch_ch-charact.
      ls_allocvaluesnumnew-value_from = ls_batch_ch-value_from.
      append ls_allocvaluesnumnew to lt_allocvaluesnumnew.
      clear ls_allocvaluesnumnew.
    endif.
  endloop.


* Call BAPI to update the characteristics
  call function 'BAPI_OBJCL_CHANGE'
    exporting
      objectkey          = lf_objectkey
      objecttable        = lf_objecttable
      classnum           = lf_classnum
      classtype          = lf_classtype
    tables
      allocvaluesnumnew  = lt_allocvaluesnumnew
      allocvaluescharnew = lt_allocvaluescharnew
      allocvaluescurrnew = lt_allocvaluescurrnew
      return             = lt_bapiret2.

  read table lt_bapiret2 into ls_bapiret2 with key type = zwmpp_gc_e.
  if sy-subrc <> 0.
* Populate the message type
    lv_msgtyp = zwmpp_gc_s.
* Populate the error message
    if not lv_exidv is initial.
      concatenate lv_exidv ':' 'Batch'(i12) iv_batch 'updated'(i09)   into
      lv_msg separated by space.
    else.
      concatenate 'Batch'(i12) iv_batch 'updated'(i09)   into
                        lv_msg separated by space.
    endif.
* Commit the database and wait
    call function 'BAPI_TRANSACTION_COMMIT'.
  else.
    lv_msgtyp = zwmpp_gc_e.
    clear: lv_msg.
    call function 'FORMAT_MESSAGE'
      exporting
        id        = ls_bapiret2-id
        no        = ls_bapiret2-number
        v1        = ls_bapiret2-message_v1
        v2        = ls_bapiret2-message_v2
        v3        = ls_bapiret2-message_v3
        v4        = ls_bapiret2-message_v4
      importing
        msg       = lv_msg
      exceptions
        not_found = 1
        others    = 2.
    if lv_msg is initial.
      concatenate lv_exidv ':' 'Batch'(i12) iv_batch 'update failed'(e12)
       into lv_msg separated by space.
    else.
      concatenate iv_batch ':' lv_msg into lv_msg separated by space.
    endif.
    call function 'BAPI_TRANSACTION_ROLLBACK'.
  endif.

* Set the Message

  call method zcl_u01339_pick_pallet=>set_message_buffer
    exporting
      iv_msgv1        = lv_msg
      iv_msgid        = zwmpp_dl_wm
      iv_msgno        = zwmpp_gc_000
      iv_message_type = lv_msgtyp
    importing
      es_bal_s_msg    = ls_bal_msg.
  if not ls_bal_msg is initial.
    append ls_bal_msg to et_messages.
    clear : ls_bal_msg.
  endif.
  if lv_msgtyp = zwmpp_gc_e.
    call method zcl_u01339_pick_pallet=>set_message_buffer
      exporting
        iv_msgv1        = ls_bapiret2-message_v1
        iv_msgv2        = ls_bapiret2-message_v2
        iv_msgv3        = ls_bapiret2-message_v3
        iv_msgv4        = ls_bapiret2-message_v4
        iv_msgid        = ls_bapiret2-id
        iv_msgno        = ls_bapiret2-number
        iv_message_type = lv_msgtyp
      importing
        es_bal_s_msg    = ls_bal_msg.

    if not ls_bal_msg is initial.
      append ls_bal_msg to et_messages.
      clear : ls_bal_msg.
    endif.
  endif.

* Return the error message
































*


endmethod.


METHOD BATCH_TO_BATCH_TRANSFER .
* Constants
  CONSTANTS : C_0010 TYPE HUWBEVENT VALUE '0010',
              C_309 TYPE BWART VALUE '309',
              GC_TCODE_VLMOVE TYPE SYTCODE VALUE 'VLMOVE'.

* Local Variables
  DATA: LT_MOVE_TO      TYPE HUM_DATA_MOVE_TO_T ,
        LS_MOVE_TO      TYPE HUM_DATA_MOVE_TO,
        LT_EXIDV        TYPE HUM_EXIDV_T,
        LS_EXIDV        TYPE HUM_EXIDV,
        LS_MESS         TYPE HUITEM_MESSAGES,
        LF_POSTED       TYPE SY-SUBRC,
        LT_MESS         TYPE HUITEM_MESSAGES_T,
        LS_MESS_01      TYPE HUITEM_MESSAGES,
        LS_HU_BATCH     TYPE VEPO,
        LS_HU_BATCH_NEW TYPE VEPO,
        LS_RETURN       TYPE BAPIRET2,
        LS_EMKPF        TYPE EMKPF ,
        LS_HUITEMS      TYPE HUM_HUMSEG,
        LS_BAL_S_MSG    TYPE BAL_S_MSG.

  REFRESH : LT_MOVE_TO, LT_EXIDV.

  LOOP AT IT_HU_BATCH_OLD INTO LS_HU_BATCH.
    CLEAR : LS_HU_BATCH_NEW , LS_HUITEMS , LS_MOVE_TO.
    READ TABLE IT_HU_BATCH_NEW INTO LS_HU_BATCH_NEW
            WITH KEY VENUM = LS_HU_BATCH-VENUM
                     VEPOS = LS_HU_BATCH-VEPOS.
    IF SY-SUBRC <> 0.
      REFRESH LT_MOVE_TO.
      EXIT.
    ENDIF.
    LS_MOVE_TO-HUWBEVENT = C_0010.
    LS_MOVE_TO-MATNR = LS_HU_BATCH-MATNR.
    LS_MOVE_TO-CHARG = LS_HU_BATCH_NEW-CHARG.
    LS_MOVE_TO-WERKS = LS_HU_BATCH-WERKS.
    LS_MOVE_TO-BWART = C_309.
    LS_HUITEMS-VENUM = LS_HU_BATCH-VENUM.
    LS_HUITEMS-VEPOS = LS_HU_BATCH-VEPOS.
    APPEND LS_HUITEMS TO LS_MOVE_TO-HU_ITEMS .
    APPEND LS_MOVE_TO TO LT_MOVE_TO.
    AT LAST.
      APPEND IV_EXIDV TO LT_EXIDV.
    ENDAT.
  ENDLOOP.

  IF LT_MOVE_TO IS NOT INITIAL.

    CALL FUNCTION 'HU_CREATE_GOODS_MOVEMENT'
      EXPORTING
        IF_SIMULATE    = ' '
        IF_COMMIT      = ' '
        IF_TCODE       = GC_TCODE_VLMOVE        "'VLMOVE'
        IT_MOVE_TO     = LT_MOVE_TO
        IT_EXTERNAL_ID = LT_EXIDV
      IMPORTING
        EF_POSTED      = LF_POSTED
        ES_MESSAGE     = LS_MESS
        ET_MESSAGES    = LT_MESS
        ES_EMKPF       = LS_EMKPF.

*   An error occurred during the HU Goods Movement. Log the error into
*   the global error table
    IF LS_MESS-MSGID IS NOT INITIAL AND
       LS_MESS-MSGTY EQ ZWMPP_GC_E.    "'E'
      CLEAR: LS_RETURN.
      MOVE: LS_MESS-MSGTY TO LS_RETURN-TYPE,
            LS_MESS-MSGID TO LS_RETURN-ID,
            LS_MESS-MSGNO TO LS_RETURN-NUMBER.
      CONCATENATE IV_EXIDV ':'
                  'Batch transfer failed'(I10) INTO LS_MESS-MSGV1.
      MOVE: LS_MESS-MSGV2 TO LS_RETURN-MESSAGE_V2,
            LS_MESS-MSGV3 TO LS_RETURN-MESSAGE_V3,
            LS_MESS-MSGV4 TO LS_RETURN-MESSAGE_V4.
      APPEND LS_RETURN TO ET_RETURN.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
  EXPORTING
    TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_BATCH_TO_BATCH_ERR.
*    PREVIOUS =
*          .
    ENDIF.

*   If any errors were logged in the return table of the HU Goods
*   Movement function then log them in the global error table.
    LOOP AT LT_MESS INTO LS_MESS_01 .

      IF LS_MESS_01-MSGTY = ZWMPP_GC_S AND
                  EV_MATERIAL_DOCUMENT IS INITIAL.
        EV_MATERIAL_DOCUMENT = LS_MESS_01-MSGV1.
        COMMIT WORK AND WAIT.
      ENDIF.

      CLEAR: LS_RETURN.
      MOVE: LS_MESS_01-MSGTY TO LS_RETURN-TYPE,
            LS_MESS_01-MSGID TO LS_RETURN-ID,
            LS_MESS_01-MSGNO TO LS_RETURN-NUMBER.
      IF LS_RETURN-TYPE = ZWMPP_GC_E.
        CONCATENATE IV_EXIDV ':'
                    'Batch transfer failed'(I10)
                    INTO LS_MESS-MSGV1 SEPARATED BY SPACE.
      ELSE.
        CONCATENATE IV_EXIDV
                          'Batches transferred'(I11)
                          TEXT-I07 EV_MATERIAL_DOCUMENT INTO
                          LS_RETURN-MESSAGE_V1 SEPARATED BY SPACE.
      ENDIF.
      MOVE: LS_MESS_01-MSGV2 TO LS_RETURN-MESSAGE_V2,
            LS_MESS_01-MSGV3 TO LS_RETURN-MESSAGE_V3,
            LS_MESS_01-MSGV4 TO LS_RETURN-MESSAGE_V4.
      APPEND LS_RETURN TO ET_RETURN.
    ENDLOOP.
  ENDIF.
ENDMETHOD.


METHOD CHECK_ALPHANUMERIC_CHAR .
  DATA: LV_VALUE(30) TYPE C.
  DATA: LV_STRLEN    TYPE I,
        LV_CHARACTER TYPE C,
        LV_INDEX     TYPE I.

* Translate the importing data to Upper case
  LV_VALUE = IV_VALUE.
  TRANSLATE LV_VALUE TO UPPER CASE.
* Check the string length of the handling unit
  LV_STRLEN = STRLEN( LV_VALUE ).

* Check every character in the given data
  DO LV_STRLEN TIMES.
    LV_INDEX = SY-INDEX - 1.
    LV_CHARACTER = LV_VALUE+LV_INDEX(1).
* Check for alphabetical characters
    FIND LV_CHARACTER IN SY-ABCDE .
* If no alpha characters are found, then check for Numeric characters
    IF SY-SUBRC NE 0.
      FIND LV_CHARACTER IN '0123456789'.
* If no numeric characters are found, then raise the exception message
      IF SY-SUBRC NE 0.
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_INVALID_CHARC.
        EXIT.
      ENDIF.
    ENDIF.
  ENDDO.
ENDMETHOD.


method check_hu_length .
*-----------------------------------------------------------------------*
* This method would check if the Handling unit contains not more than   *
* 10 alpha numeric characters. The handling unit supplied to this       *
* is validated aganist any special characters. Exception is raised if   *
* the handling unit is invalid                                          *
*-----------------------------------------------------------------------*
  data: lv_strlen    type i,
        lv_character type c,
        lv_index     type i,
        lv_exidv     type exidv,
        lv_exidv_temp     type exidv.

* A handling unit Number must contain a maximum of 10 characters.
  lv_exidv = iv_exidv.
* Check the string length of the handling unit
  lv_strlen = strlen( lv_exidv ).
* If the length of the handling unit number exceeds 10, then raise an
* exception message
  if lv_strlen ne 10.
    raise exception type zcx_u01339_pick_pallet
      exporting
        textid = zcx_u01339_pick_pallet=>zcx_u01339_hu_length.
    exit.
  endif.
* Now check whether the handling contains any special characters or not
* raise an exception if Handling unit number contains any special character
* To achive this, first the alpha numeric characters are translated to the
* upper case.
  translate lv_exidv to upper case.

* Check every character in the Handling unit
  do lv_strlen times.
    lv_index = sy-index - 1.
    lv_character = lv_exidv+lv_index(1).
* Check for alphabetical characters
    find lv_character in sy-abcde .
* If no alpha characters are found, then check for Numeric characters
    if sy-subrc ne 0.
      find lv_character in '0123456789'.
* If no numeric characters are found, then raise the exception message
      if sy-subrc ne 0.
        raise exception type zcx_u01339_pick_pallet
          exporting
            textid = zcx_u01339_pick_pallet=>zcx_u01339_hu_invalid_charc.
        exit.
      endif.
    endif.
  enddo.
*  Initially need to make sure that the dESTINATION handling unit
*  is not Blocked .
  clear : lv_exidv_temp .
  select single exidv from zdl_wm_block_hu
     into lv_exidv_temp where exidv = iv_exidv.
  if sy-subrc = 0.
    raise exception type zcx_u01339_pick_pallet
     exporting
       textid = zcx_u01339_pick_pallet=>zcx_u01339_dhu_blocked.
  endif.
endmethod.


METHOD CHECK_MATERIAL_DELIVERY .
  DATA: LS_LIPS TYPE LIPS.
* Check whether a record exists in the database for the Sales order, item and material
* combination. If no record is found, then return an error flag.
  SELECT SINGLE * FROM LIPS
    INTO LS_LIPS
   WHERE VBELN = IV_VBELN
     AND POSNR = IV_POSNR
     AND MATNR = IV_MATNR.
  IF SY-SUBRC <> 0.
    EV_INVALID_DELIVERY = ZWMPP_GC_X.
  ENDIF.

ENDMETHOD.


METHOD CHECK_MATERIAL_UNIT_CODE .
*------------------------------------------------------------------------*
* This method would check characteristic value for a given material and  *
* its corresponding characteristic. Currently this method would check    *
* the characteristic 'UNIT_CODE' contains value either 'C' or 'D'.       *
* Error flag is returned if the UNIT_CODE value contains any other value *
* Additional code could be included to validate the value of any other   *
* characteristic of a material at the highlighted portion in the below   *
* code                                                                   *
*------------------------------------------------------------------------*
  DATA: LT_MAT_OBJ TYPE TT_MAT_OBJ,
        LS_MAT_OBJ TYPE TYP_MAT_OBJ,
        LT_CONF    TYPE STANDARD TABLE OF IBVALUE0,
        LT_CHARAC  TYPE STANDARD TABLE OF ZSD_CHARACTERISTIC_NAME,
        LS_CHARAC  TYPE ZSD_CHARACTERISTIC_NAME,
        LS_CONF    TYPE IBVALUE0,
        LV_CUOBF   TYPE CUOBM.
  CONSTANTS : LC_CTN TYPE C LENGTH 3 VALUE 'CTN'.

* Get the internal object number of the material.
  SELECT MATNR
         CUOBF
  FROM MARA
  INTO TABLE LT_MAT_OBJ
  FOR ALL ENTRIES IN IT_MATNR
  WHERE MATNR = IT_MATNR-MATNR.
  IF SY-SUBRC = 0.

    LOOP AT LT_MAT_OBJ INTO LS_MAT_OBJ.

      LV_CUOBF = LS_MAT_OBJ-CUOBF.

** get the material unit code from config
*      CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
*        EXPORTING
*          INSTANCE           = LV_CUOBF
*          LANGUAGE           = SY-LANGU
*        TABLES
*          CONFIGURATION      = LT_CONF
*        EXCEPTIONS
*          INSTANCE_NOT_FOUND = 1
*          OTHERS             = 2.
      REFRESH LT_CHARAC.

      LS_CHARAC-ATNAM = IV_ATNAM.
      APPEND LS_CHARAC TO LT_CHARAC.
      CLEAR LS_CHARAC.

      CALL FUNCTION 'ZSD_GET_SINGLE_VALUES_OF_INST'
        EXPORTING
          INSTANCE                             = LV_CUOBF
*   I_SORT_ON_NAME                       = 'X'
*   I_EXTRA_FIELDS_OPTION                = ' '
*   I_NUMBER_OF_DECIMAL_PTS              = '5'
         I_IGNORE_EXCEPTIONS                  = ZWMPP_GC_X
       IMPORTING
         ET_VALUES                            = LT_CONF
       TABLES
         T_GET_SPECIFIC_CHARACTERISTICS       = LT_CHARAC
*   T_CHARACTERISTIC_VALUES              =
       EXCEPTIONS
         INSTANCE_NOT_FOUND                   = 1
         NO_CONFIGURATION_DATA_FOUND          = 2
         CHARACTERISTIC_NOT_FOUND             = 3
         OTHERS                               = 4.
* If no variant configuration details are found, then return an error flag
      IF SY-SUBRC NE 0.
        EV_ERR_FLAG = ZWMPP_GC_X.                 "'X'.
      ELSE.
* If variant configuration data is found, then check the characteristic supplied by IV_ATNAM
*        SORT LT_CONF BY ATNAM .
        READ TABLE LT_CONF INTO LS_CONF INDEX 1.      "WITH KEY ATNAM = IV_ATNAM.
        IF SY-SUBRC <> 0.
          EV_ERR_FLAG = ZWMPP_GC_X.               "'X'.
        ELSE.

          CASE IV_ATNAM.
* Check the Characteristic value for UNIT_CODE.
            WHEN 'UNIT_CODE'.
* If the characteristic value of UNIT_CODE is not either 'C' or 'D', then return an erroe flag
              IF LS_CONF-ATWRT = ZWMPP_GC_C OR    "'C' OR
                 LS_CONF-ATWRT = ZWMPP_GC_D.      "'D'.
              ELSE.
                EV_ERR_FLAG = ZWMPP_GC_X.         "'X'.
              ENDIF.
*************************************************************************************
* Additional Code can be added here to validate the value of any other characteristic
*************************************************************************************
            WHEN OTHERS.

          ENDCASE.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ELSE.
    EV_ERR_FLAG = ZWMPP_GC_X.
  ENDIF.

ENDMETHOD.


METHOD CHECK_MATERIAL_UOM .

  DATA: LV_MENGE   TYPE BSTMG,
        LV_QTY     TYPE BSTMG, "TYPE bstmg,
        LV_NUM(8)  TYPE P DECIMALS 0,
        LV_CHAR(8) TYPE C,
        LV_INT(8)  TYPE N,
        LV_UOM_IN TYPE MEINS,
        LV_UOM_OUT TYPE MEINS.

*-> Conversion routine to convert unit of measure to internal value
  CALL FUNCTION 'CONVERSION_EXIT_CUNIT_INPUT'
    EXPORTING
      INPUT          = IV_ALT_UOM
      LANGUAGE       = SY-LANGU
    IMPORTING
      OUTPUT         = LV_UOM_OUT
    EXCEPTIONS
      UNIT_NOT_FOUND = 1
      OTHERS         = 2.
  IF SY-SUBRC <> 0.
    MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
            WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.
*-> Conversion routine to convert unit of measure to internal value
  CALL FUNCTION 'CONVERSION_EXIT_CUNIT_INPUT'
    EXPORTING
      INPUT          = IV_BASE_UOM
      LANGUAGE       = SY-LANGU
    IMPORTING
      OUTPUT         = LV_UOM_IN
    EXCEPTIONS
      UNIT_NOT_FOUND = 1
      OTHERS         = 2.
  IF SY-SUBRC <> 0.
    MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
            WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.

  CALL FUNCTION 'MD_CONVERT_MATERIAL_UNIT'
    EXPORTING
      I_MATNR              = IV_MATNR
      I_IN_ME              = LV_UOM_IN
      I_OUT_ME             = LV_UOM_OUT
      I_MENGE              = IV_MENGE
    IMPORTING
      E_MENGE              = LV_QTY
    EXCEPTIONS
      ERROR_IN_APPLICATION = 1
      ERROR                = 2
      OTHERS               = 3.
  IF SY-SUBRC <> 0.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_UNIT_CONVERSION_ERR.
  ELSE.
    EV_CONVERTED_QTY = LV_QTY.
  ENDIF.


ENDMETHOD.


method constructor .
*--------------------------------------------------------------*
* This method would instantiate the given handling unit. The
* handling unit is validated and header and storage unit details
* are set to variables of this instance.
*--------------------------------------------------------------*
  data: lv_value type char30,
        lv_venum type venum,
        lv_exidv type exidv,
        lv_string type string.
  if not iv_exidv is initial.
*  Initially need to make sure that the source handling unit
*  is not Blocked .
    clear : lv_exidv .
    select single exidv from zdl_wm_block_hu
       into lv_exidv where exidv = iv_exidv.
    if sy-subrc = 0.
      raise exception type zcx_u01339_pick_pallet
       exporting
         textid = zcx_u01339_pick_pallet=>zcx_u01339_shu_blocked.
   endif.

* Call method VALIDATE_HANDLING_UNIT to validate the given
* handling unit.
*    try.
      call method me->validate_handling_unit
        exporting
          iv_exidv = iv_exidv
          iv_lgnum = iv_lgnum
        importing
          ev_lein  = me->gs_lein
          ev_vekp  = me->gs_vekp.
*    catch ZCX_U01339_PICK_PALLET
*    endtry.
* Retrieve ZDL_FIELDS entry for Initial Sub Handling Unit number
      if not gs_vekp is initial.
        select comments
                   from zdl_fields up to 1 rows
              into lv_value
              where category   = zwmpp_u01339
                and fieldname  = zwmpp_pick_pallet
                and sign       = zwmpp_gc_sign_i
                and optn       = zwmpp_gc_option_eq.
        endselect.
        if sy-subrc <> 0.

          raise exception type zcx_u01339_pick_pallet
            exporting
           textid = zcx_u01339_pick_pallet=>zcx_u01339_sub_hu_num_not_fnd
*    PREVIOUS =
              .
        else.
          condense lv_value.
          gv_initial_child_hu = lv_value.
*          concatenate '%_' lv_value into lv_string.
*          do.
*            select single venum from vekp
*              into lv_venum
*              where exidv like lv_string.
*            if sy-subrc = 0.
*              lv_value = lv_value + 1.
*              condense lv_value.
*              concatenate '%_' lv_value into lv_string.
*            else.
*              condense lv_value.
*              gv_initial_child_hu = lv_value.
*              exit.
*            endif.
*          enddo.
        endif.
      endif.
    endif.
  endmethod.


METHOD DELETE_HU.
*-----------------------------------------------------------------*
* This method would delete a given handling Unit using the BAPI   *
* BAPI_HU_DELETE. An Exception is raised if the delete fails      *
*
*-----------------------------------------------------------------*
  DATA: LS_HUKEY  TYPE BAPIHUKEY-HU_EXID,
        LV_MSG    TYPE SYMSGV,
        LV_MSGTYP TYPE SYMSGTY,
        LS_BAL_MSG  TYPE BAL_S_MSG,
        LT_RETURN   TYPE STANDARD TABLE OF BAPIRET2,
        LS_RETURN   TYPE BAPIRET2.

* Delete Handling Unit
  LS_HUKEY = IV_EXIDV.
* Call BAPI BAPI_HU_DELETE to delete the handling unit
  CALL FUNCTION 'BAPI_HU_DELETE'
    EXPORTING
      HUKEY  = LS_HUKEY
    TABLES
      RETURN = LT_RETURN.
  IF SY-SUBRC = 0.
* If the handling unit is deleted successfully, then populate the success message
* and Commit Work
    LV_MSGTYP = ZWMPP_GC_S.            "'S'.
    CONCATENATE LS_HUKEY ' : HU deleted'(E25) INTO LV_MSG
    SEPARATED BY SPACE.
    COMMIT WORK AND WAIT.
  ELSE.

* If the handling unit is not deleted, then populate the error message
* and Rollback Work
    LV_MSGTYP = ZWMPP_GC_E.             "'E'.
    CONCATENATE LS_HUKEY ' : HU delete failed'(E26) INTO LV_MSG
    SEPARATED BY SPACE.
    ROLLBACK WORK.
  ENDIF.
  LOOP AT LT_RETURN INTO LS_RETURN.
    LS_BAL_MSG-MSGTY = LS_RETURN-TYPE.
    LS_BAL_MSG-MSGID = LS_RETURN-ID.
    LS_BAL_MSG-MSGNO = LS_RETURN-NUMBER.
    LS_BAL_MSG-MSGV1 = LS_RETURN-MESSAGE_V1.
    LS_BAL_MSG-MSGV2 = LS_RETURN-MESSAGE_V2.
    LS_BAL_MSG-MSGV3 = LS_RETURN-MESSAGE_V3.
    LS_BAL_MSG-MSGV4 = LS_RETURN-MESSAGE_V4.
    APPEND LS_BAL_MSG TO ET_RETURN.
    CLEAR LS_BAL_MSG.
  ENDLOOP.
* Set the Message Buffer
  CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
    EXPORTING
      IV_MSGV1        = LV_MSG
      IV_MESSAGE_TYPE = LV_MSGTYP
      IV_MSGID        = ZWMPP_DL_WM
      IV_MSGNO        = ZWMPP_GC_000
    IMPORTING
      ES_BAL_S_MSG    = LS_BAL_MSG.
  IF NOT LS_BAL_MSG IS INITIAL.
* Append the message to the log table
*    APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
    CLEAR LS_BAL_MSG.
  ENDIF.
* Raise an exception when HU is not deleted
  IF LV_MSGTYP = ZWMPP_GC_E.          "'E'.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_DELETE_ERROR
*      PREVIOUS =
        .
  ENDIF.
ENDMETHOD.


METHOD GET_CARTONS_PER_PALLET .
  DATA: LT_CONF TYPE TT_BAPI1003_ALLOC_VALUES_NUM,
        LS_CONF TYPE BAPI1003_ALLOC_VALUES_NUM.


  CALL METHOD ZCL_U01339_PICK_PALLET=>READ_BATCH_CHARACTERISTIC
    EXPORTING
      IV_BATCH                 = IV_CHARG
      IV_MATERIAL              = IV_MATNR
      IV_PLANT                 = IV_WERKS
  IMPORTING
    ET_BATCH_CHARACTERISTICS = LT_CONF
*    EV_MSG                   =
*    ET_MESSAGES              =
      .

  IF SY-SUBRC <> 0.
  ELSE.
    READ TABLE LT_CONF INTO LS_CONF WITH KEY CHARACT = 'CARTONS_PER_PALLET'.
    IF SY-SUBRC = 0.
      EV_ATWRT = LS_CONF-VALUE_FROM.
    ELSE.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
        EXPORTING
          TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_UCODE_NO_CARTON.

    ENDIF.

*    READ TABLE LT_CONF INTO LS_CONF WITH KEY CHARACT = 'WEIGHT_OF_PALLETS_IN_LBS'.
*    IF SY-SUBRC = 0.
*      EV_ATWRT = LS_CONF-VALUE_FROM.
*    ELSE.
*      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
*        EXPORTING
*          TEXTID = 'ZCX_U01339_UCODE_NO_CARTON'.
*    ENDIF.

  ENDIF.


ENDMETHOD.


METHOD GET_HUDAT_ENTRIES.

  DATA: LR_EXIDV TYPE STANDARD TABLE OF ZDL_WM_EXIDV_RANGE,
        LR_TKNUM TYPE STANDARD TABLE OF TRA_TKNUM_RANGE,
        LS_RANGE_TKNUM TYPE TRA_TKNUM_RANGE,
        LS_TKNUM TYPE ZWMPP_TYP_TKNUM,
        LS_EXIDV TYPE ZDL_WM_EXIDV_RANGE,
        LS_HU    TYPE ZWMPP_TYP_HANDLING_UNIT.
  TYPES: BEGIN OF TYP_WHERE,
          TEXT(72) TYPE C,
        END   OF TYP_WHERE.
  DATA:  LT_WHERE TYPE STANDARD TABLE OF TYP_WHERE,
         LS_WHERE TYPE TYP_WHERE.

  IF NOT IT_HU[] IS INITIAL.
    LOOP AT IT_HU INTO LS_HU.
      LS_EXIDV-SIGN   = ZWMPP_GC_SIGN_I.
      LS_EXIDV-OPTION = ZWMPP_GC_OPTION_EQ.
      LS_EXIDV-LOW    = LS_HU-EXIDV.
      APPEND LS_EXIDV TO LR_EXIDV.
    ENDLOOP.
    LS_WHERE-TEXT = 'PEXIDV IN LR_EXIDV'.
    APPEND LS_WHERE TO LT_WHERE.
    CLEAR LS_WHERE.
  ENDIF.

  IF NOT IT_TKNUM[] IS INITIAL.
    LOOP AT IT_TKNUM INTO LS_TKNUM.
      LS_RANGE_TKNUM-SIGN   = ZWMPP_GC_SIGN_I.
      LS_RANGE_TKNUM-OPTION = ZWMPP_GC_OPTION_EQ.
      LS_RANGE_TKNUM-LOW    = LS_TKNUM-TKNUM.
      APPEND LS_RANGE_TKNUM TO LR_TKNUM.
    ENDLOOP.
    IF NOT LT_WHERE[] IS INITIAL.
      LS_WHERE-TEXT = 'AND TKNUM IN LR_TKNUM'.
      APPEND LS_WHERE TO LT_WHERE.
      CLEAR LS_WHERE.
    ELSE.
      LS_WHERE-TEXT = 'TKNUM IN LR_TKNUM'.
      APPEND LS_WHERE TO LT_WHERE.
      CLEAR LS_WHERE.
    ENDIF.
  ENDIF.


* Retrieve the HU Delivery association details from HUDAT table
  SELECT * FROM ZDL_WM_HUDAT
    INTO TABLE ET_HUDAT
*    FOR ALL ENTRIES IN IT_HU
    WHERE (LT_WHERE).
  IF SY-SUBRC <> 0.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HUDAT_NOT_FOUND
*    PREVIOUS =
        .
  ENDIF.
ENDMETHOD.


METHOD GET_HU_FOR_MATERIAL .
  DATA: LT_BATCH TYPE TT_BAPI1003_ALLOC_VALUES_NUM,
        LS_BATCH TYPE BAPI1003_ALLOC_VALUES_NUM.
  DATA: LT_LGPLA  TYPE STANDARD TABLE OF ZDL_WM_DISPLAY_MATL_SEARCH,
        LT_ERRORS TYPE STANDARD TABLE OF BAPIRET2.

  TYPES :  BEGIN OF TYP_LENUM_LQUA,
           LGNUM TYPE LGNUM,
           LQNUM TYPE LVS_LQNUM,
           LENUM TYPE LENUM,
           WERKS TYPE WERKS_D,
           END OF TYP_LENUM_LQUA.
  TYPES : TT_LGPLA TYPE STANDARD TABLE OF ZWMPP_TYP_LGPLA,
          TT_LENUM_LQUA TYPE STANDARD TABLE OF TYP_LENUM_LQUA.

  DATA: LT_LGPLA_TEMP TYPE ZWMPP_TT_LGPLA,
        LT_HU_LQUA    TYPE TT_LENUM_LQUA,
        LS_LGPLA_TEMP TYPE ZWMPP_TYP_LGPLA,
        LS_HU_LQUA    TYPE TYP_LENUM_LQUA,
        LV_NO_CART    TYPE CHAR1,
        LV_ATWRT      TYPE ATWRT,
        LV_SUM        TYPE ATFLV,
        LV_LOWVAL     TYPE ZSP_LOWVAL.
  DATA: LREF_PICK_PALLET TYPE REF TO ZCX_U01339_PICK_PALLET.

  FIELD-SYMBOLS : <LS_LGPLA>      TYPE ZDL_WM_DISPLAY_MATL_SEARCH,
                  <LS_LGPLA_TEMP> TYPE ZWMPP_TYP_LGPLA.

  CALL FUNCTION 'ZDL_WM_U01391_PICKING_STRATEGY'
    EXPORTING
      I_LGNUM         = IV_LGNUM
      I_MATNR         = IV_MATNR
*     I_BESTQ         =
*   IMPORTING
*     E_LGTYP         =
*     E_LGPLA         =
    TABLES
*     IT_LGTYP        =
      ET_LGPLA        = LT_LGPLA
      ET_ERRORS       = LT_ERRORS.
  IF NOT LT_LGPLA IS INITIAL.
*    LOOP AT LT_LGPLA ASSIGNING <LS_LGPLA>.
*      MOVE-CORRESPONDING <LS_LGPLA> TO LS_LGPLA_TEMP.
*      LS_LGPLA_TEMP-SORT = SY-TABIX.
*      APPEND LS_LGPLA_TEMP TO LT_LGPLA_TEMP.
*    ENDLOOP.
    SELECT LGNUM
           LQNUM
           LENUM
           WERKS
           FROM LQUA
      INTO CORRESPONDING FIELDS OF TABLE LT_HU_LQUA
      FOR ALL ENTRIES IN LT_LGPLA
      WHERE LQNUM = LT_LGPLA-LQNUM.
    IF SY-SUBRC = 0.
      SORT LT_HU_LQUA BY LQNUM LENUM.
      LOOP AT LT_LGPLA ASSIGNING <LS_LGPLA>.
        LS_LGPLA_TEMP-SORT = SY-TABIX.
        READ TABLE LT_HU_LQUA INTO LS_HU_LQUA WITH KEY LQNUM = <LS_LGPLA>-LQNUM.
        IF SY-SUBRC = 0.
          LS_LGPLA_TEMP-EXIDV = LS_HU_LQUA-LENUM.
          MOVE-CORRESPONDING <LS_LGPLA> TO LS_LGPLA_TEMP.
          LS_LGPLA_TEMP-WERKS = LS_HU_LQUA-WERKS.
          APPEND LS_LGPLA_TEMP TO LT_LGPLA_TEMP.
        ENDIF.
      ENDLOOP.

      IF NOT LT_LGPLA_TEMP IS INITIAL.
        SORT LT_LGPLA_TEMP BY EXIDV SORT.
      ENDIF.
* Start of Changes by VBHAGAV - 04/27/2009 -
* Read ZDL_FIELDS table to retrieve the Pick Pallet Pick line storage type.
      SELECT LOWVAL
             INTO LV_LOWVAL UP TO 1 ROWS
        FROM ZDL_FIELDS
        WHERE CATEGORY   = ZWMPP_U01339
          AND FIELDNAME  = ZWMPP_PICK_PAL_PICK_LINE
          AND SIGN       = ZWMPP_GC_SIGN_I
          AND OPTN       = ZWMPP_GC_OPTION_EQ.
      ENDSELECT.

* End   of Changes by VBHAGAV - 04/27/2009
      LOOP AT LT_LGPLA_TEMP ASSIGNING <LS_LGPLA_TEMP>.
        AT NEW EXIDV.
          CLEAR : LV_NO_CART , LV_SUM.
        ENDAT.

        REFRESH LT_BATCH.
        IF  LV_NO_CART IS INITIAL.  " one of the batches don't have  CARTONS_PER_PALLET
          CALL METHOD ZCL_U01339_PICK_PALLET=>READ_BATCH_CHARACTERISTIC
            EXPORTING
              IV_BATCH                 = <LS_LGPLA_TEMP>-CHARG
              IV_MATERIAL              = <LS_LGPLA_TEMP>-MATNR
              IV_PLANT                 = <LS_LGPLA_TEMP>-WERKS
            IMPORTING
              ET_BATCH_CHARACTERISTICS = LT_BATCH.
**    EV_MSG                   =
**    ET_MESSAGES              =

          IF NOT LT_BATCH IS INITIAL.
            READ TABLE LT_BATCH INTO LS_BATCH WITH KEY CHARACT =
              'CARTONS_PER_PALLET'.
            IF SY-SUBRC = 0.
              LV_SUM = LV_SUM + LS_BATCH-VALUE_FROM.
              CLEAR : LS_BATCH-VALUE_FROM.
            ELSE.
* Begin of change / nparchu / 12/10/2008
              LV_NO_CART = 'X'.
*              delete table lt_lgpla_temp from <ls_lgpla_temp>.
*             CLEAR <LS_LGPLA_TEMP>.
* End of change / nparchu / 12/10/2008
            ENDIF.
          ENDIF.
        ENDIF.
        AT END OF EXIDV.
          IF LV_NO_CART = 'X'.
            DELETE LT_LGPLA_TEMP WHERE EXIDV = <LS_LGPLA_TEMP>-EXIDV.
          ELSE.
            IF NOT LV_SUM IS INITIAL.
              <LS_LGPLA_TEMP>-CTNS = LV_SUM.
* Start of Changes by VBHAGAV on 04/27/2009
* Check the storage type aganist the ZDL_FIELDS entry. If the Storage type is
* is same as the ZDL_FIELDS entry, then populate SORT_STR_TYPE field by '0'.
* else populate the SORT_STR_TYPE by '1'.

              IF <LS_LGPLA_TEMP>-LGTYP = LV_LOWVAL.
                <LS_LGPLA_TEMP>-SORT_STR_TYPE = '0'.
              ELSE.
                <LS_LGPLA_TEMP>-SORT_STR_TYPE = '1'.
              ENDIF.
* End  of Changes by VBHAGAV on 04/27/2009

* Collect the records
              IF <LS_LGPLA_TEMP>-LGTYP+0(1) <> '9'.
                APPEND <LS_LGPLA_TEMP> TO ET_HU_MATERIAL.
              ENDIF.
            ENDIF.
            CLEAR : LS_LGPLA_TEMP,
                    LV_SUM.
          ENDIF.
        ENDAT.
      ENDLOOP.
    ENDIF.
  ENDIF.
* Start of Changes by VBHAGAV on 04/27/2009
*  SORT ET_HU_MATERIAL BY CTNS SORT.
  SORT ET_HU_MATERIAL BY SORT_STR_TYPE CTNS SORT.
* End   of Changes by VBHAGAV on 04/27/2009
ENDMETHOD.


METHOD GET_HU_HEADER_DETAILS .
  DATA: LV_WHERE(132) TYPE C,
        LT_VEKP TYPE STANDARD TABLE OF VEKP.

* Start of Changes by VBHAGAV on 08/11/2009
  DATA: LT_VENUM TYPE STANDARD TABLE OF VEKP,
        LS_VENUM TYPE VEKP,
        LV_VEKP_STATUS_EXISTS TYPE C.
* End   of Changes by VBHAGAV on 08/11/2009

  IF IV_EXIDV IS INITIAL AND
     IV_VENUM IS INITIAL.

  ENDIF.
* RETRIEVE THE HANDLING UNIT HEADER DETAILS. RETRIEVE THE RECORDS
*whose Handling Unit status is set either to 20(Stock at a non-HU
*storage location)
*or 30(Stock at HU storage location) and whose packing object status is
*not 05 or 06
* (Non-Assigned Handling Unit) or 12 (Non-Assigned Handling Unit).
  IF NOT IV_EXIDV IS INITIAL.
    CONCATENATE LV_WHERE 'EXIDV = IV_EXIDV' INTO LV_WHERE.
  ENDIF.
  IF NOT IV_VENUM IS INITIAL.
    IF NOT LV_WHERE IS INITIAL.
      CONCATENATE LV_WHERE 'AND VENUM = IV_EXIDV' INTO LV_WHERE.
    ELSE.
      CONCATENATE LV_WHERE 'VENUM = IV_VENUM' INTO LV_WHERE.
    ENDIF.
  ENDIF.
  IF IV_WHERE_FLAG IS INITIAL.
    SELECT * FROM VEKP
      INTO EV_VEKP UP TO 1 ROWS
       WHERE (LV_WHERE)
         AND ( STATUS = '0020' OR
               STATUS = '0030' )
         AND  ( VPOBJ = '12' OR
                   VPOBJ = '05' OR
                   VPOBJ = '06' )
         AND LGNUM = IV_LGNUM.
    ENDSELECT.
    IF EV_VEKP IS INITIAL.

* Raise Error message if no information is found for the handling unit
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
        EXPORTING
          TEXTID   = ZCX_U01339_PICK_PALLET=>ZCX_U01339_NO_HU_FOUND.
*    PREVIOUS =     .
      RETURN.
    ENDIF.
  ELSE.
* Start of Changes by VBHAGAV on 08/11/2009 - For USD ticket#4978967
*    SELECT * FROM VEKP
*        INTO EV_VEKP            " EV_VEKP UP TO 1 ROWS
*         WHERE (LV_WHERE)
*           AND ( STATUS = '0020' OR
*                 STATUS = '0030' ) .
*    ENDSELECT.
    SELECT * FROM VEKP
           INTO TABLE LT_VENUM
      WHERE (LV_WHERE).
* End   of Changes by VBHAGAV on 08/11/2009 - For USD ticket#4978967
    IF SY-SUBRC = 0.
* Start of Changes by VBHAGAV on 08/11/2009 - For USD ticket#4978967
      CLEAR : LV_VEKP_STATUS_EXISTS,
              LS_VENUM.
      LOOP AT LT_VENUM INTO LS_VENUM WHERE ( STATUS = '0020' OR
                                             STATUS = '0030' ).
        LV_VEKP_STATUS_EXISTS = ZWMPP_GC_X.
        EXIT.
      ENDLOOP.

      IF LV_VEKP_STATUS_EXISTS IS INITIAL.
* If no Handling Unit is found the given status, then raise an exception
* Raise Error message if no information is found for the handling unit
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID   = ZCX_U01339_PICK_PALLET=>ZCX_U01339_NO_HU_FOUND.
*    PREVIOUS =     .
        RETURN.
      ENDIF.
      EV_VEKP = LS_VENUM.
* End   of Changes by VBHAGAV on 08/11/2009 - For USD ticket#4978967

      IF EV_VEKP-LGNUM <> IV_LGNUM.
* Raise Error message if no information is found for the handling unit
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID   = ZCX_U01339_PICK_PALLET=>ZCX_U01339_NO_HU_FOUND.
*    PREVIOUS =     .
        RETURN.
      ENDIF.

      IF NOT ( EV_VEKP-VPOBJ = '12' OR
               EV_VEKP-VPOBJ = '05' OR
               EV_VEKP-VPOBJ = '06' ).
* Raise Error message if no information is found for the handling unit
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID   = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_OBJECT_ERR.
*    PREVIOUS =     .
        RETURN.
      ENDIF.
    ENDIF.
  ENDIF.
ENDMETHOD.


method get_hu_item_details .
  data: ls_hu_item      type vepo,
        ls_source_hu    type zwmpp_typ_s_hu,
        lt_hu_item      type standard table of vepo,
        lt_hu_item_temp type standard table of vepo,
        ls_mat          type zwmpp_typ_matnr,
        lt_mat          type zwmpp_tt_matnr,
        lv_err_flag     type c,
        lv_venum        type venum,
        lv_atwrt        type atwrt.
  data: lt_batch type tt_bapi1003_alloc_values_num,
        ls_batch type bapi1003_alloc_values_num.
  data: ls_venum type hum_venum,
        lt_venum type hum_venum_t,
        lt_items type hum_hu_item_t,
        lt_header type hum_hu_header_t.

  if iv_venum is initial.
    ls_venum = gs_vekp-venum.
    append ls_venum to lt_venum.
  else.
    ls_venum = iv_venum.
    append ls_venum to lt_venum.
  endif.
* Refresh the Global data
call function 'HU_PACKING_REFRESH'.
call function 'SERIAL_INTTAB_REFRESH'.


* Retrieve Handling Unit Item details
  call function 'HU_GET_HUS'
   exporting
*   IF_OBJECT                =
*   IF_NO_DB_SELECT          = ' '
*   IF_LOCK_HUS              = ' '
*   IF_WITH_TEXT             = ' '
*   IF_NO_LOOP               = 'X'
*   IF_MORE_HUS              =
*   IS_OBJECTS               =
*   IT_OBJECTS               =
*   IT_HUS                   =
     it_venum                 = lt_venum
*   IT_HANDLE                =
*   IF_MARA_PACKMITTEL       = ' '
   importing
   et_header                = et_child_relation
   et_items                 = et_hu_item
*   ET_ITEM_SERIALNO         =
*   ET_HISTORY               =
*   ET_HIGHEST_LEVELS        =
*   ET_MESSAGES              =
 exceptions
   hus_locked               = 1
   no_hu_found              = 2
   fatal_error              = 3
   others                   = 4.

  if sy-subrc = 0.
    sort et_hu_item by matnr.
* Check if the Handling UNit is nested or Single level HU
    clear ls_hu_item.
    read table  et_hu_item into ls_hu_item with key venum = ls_venum-venum
                                                    velin = '3'.
    if sy-subrc = 0.
* Parent Handling unit contains child handling unit and
* and also material. This condition is not acceptable
      clear ls_hu_item.
      read table  et_hu_item into ls_hu_item with key venum = ls_venum-venum
                                                          velin = '1'.
      if sy-subrc = 0.
* Raise error message
      else.
        ev_hu_nested = zwmpp_gc_x.
      endif.
    endif.

    clear ls_hu_item.
    loop at et_hu_item into ls_hu_item where velin = '1'.
*    This code for packing in Cartons . All we are doing is simulate
*    VEPO records as if they are packed in Cartons and see if everything
*    packed in cartons.
       if ls_hu_item-altme <> 'KAR'.
          ls_hu_item-altme = 'KAR'.
          modify et_hu_item from ls_hu_item index sy-tabix.
       endif.
      ls_mat-matnr = ls_hu_item-matnr.
      append ls_mat to lt_mat.
      clear ls_mat.

    endloop.

    sort lt_mat by matnr.
    delete adjacent duplicates from lt_mat comparing matnr.
    if not lt_mat[] is initial.
      call method zcl_u01339_pick_pallet=>check_material_unit_code
        exporting
          iv_atnam    = 'UNIT_CODE'
          it_matnr    = lt_mat
        importing
          ev_err_flag = lv_err_flag.

      if lv_err_flag is initial.
*If the UNIT_CODE of the materials in the HU is not Cartons, then raise
*an error message
      else.
        raise exception type zcx_u01339_pick_pallet
          exporting
            textid = zcx_u01339_pick_pallet=>zcx_u01339_ucode_no_carton
*    PREVIOUS =
            .
      endif.
    endif.
*    IF IV_VENUM IS INITIAL.
*      APPEND LINES OF ET_HU_ITEM TO ME->GT_HU_ITEM.
*    ENDIF.
  endif.
endmethod.


METHOD GET_MAT_CHARACTERISTICS .

  DATA: LT_MAT_OBJ     TYPE TT_MAT_OBJ,
        LT_CHARAC      TYPE ZWMPP_TT_CHARAC,
        LT_MAT_CHARAC  TYPE ZWMPP_TT_CHARAC,
        LT_CONF        TYPE STANDARD TABLE OF CONF_OUT,
        LS_CHARAC      TYPE ZWMPP_TYP_CHARAC_NAMES,
        LS_CONF        TYPE CONF_OUT,
        LS_VALUES      TYPE IBVALUE0,
        LS_RETURN      TYPE BAPIRET2,
        LS_MAT_OBJ     TYPE TYP_MAT_OBJ,
        LS_CHARAC_TEMP TYPE ZWMPP_TYP_CHARAC_NAMES,
        LS_CHARAC_VAL  TYPE ZWMPP_TYP_CHARAC,
        LV_CUOBF       TYPE CUOBM.


* Get the internal object number of the material.
  SELECT MATNR
         CUOBF
  FROM MARA
  INTO TABLE LT_MAT_OBJ
  FOR ALL ENTRIES IN IT_CHARAC
  WHERE MATNR = IT_CHARAC-MATNR.
  IF SY-SUBRC = 0.
    SORT LT_MAT_OBJ BY MATNR.
* COllect the Unique Object type for each material.
    DELETE ADJACENT DUPLICATES FROM LT_MAT_OBJ COMPARING MATNR.
    LT_MAT_CHARAC[] = IT_CHARAC[].

    SORT LT_MAT_CHARAC BY MATNR.
* Retrieve values for the above mentioned characteristics for each material.
    LOOP AT LT_MAT_CHARAC INTO LS_CHARAC.
* If Internal Object number is not retrieved for any of the materials, then return an error message
      CLEAR LS_MAT_OBJ.
      READ TABLE LT_MAT_OBJ INTO LS_MAT_OBJ WITH KEY MATNR = LS_CHARAC-MATNR.
      IF SY-SUBRC <> 0.
        LS_RETURN-TYPE       = ZWMPP_GC_E.
        LS_RETURN-ID         = ZWMPP_DL_WM.
        LS_RETURN-NUMBER     = ZWMPP_GC_000.
        LS_RETURN-MESSAGE_V1 = LS_CHARAC-MATNR.
        CONCATENATE 'Internal Object not found for'(E38) LS_CHARAC-MATNR INTO
        LS_RETURN-MESSAGE SEPARATED BY SPACE.
        APPEND LS_RETURN TO ET_RETURN.
        CLEAR LS_RETURN.
        CONTINUE.
      ENDIF.

      LV_CUOBF = LS_MAT_OBJ-CUOBF.

* If the internal Object number is initial, then return and error message
* and continue with the next material
      IF LV_CUOBF IS INITIAL.
        LS_RETURN-TYPE       = ZWMPP_GC_E.
        LS_RETURN-ID         = ZWMPP_DL_WM.
        LS_RETURN-NUMBER     = ZWMPP_GC_000.
        LS_RETURN-MESSAGE_V1 = LS_CHARAC-MATNR.
        CONCATENATE 'Internal Object not found for'(E38) LS_CHARAC-MATNR INTO
        LS_RETURN-MESSAGE SEPARATED BY SPACE.
        APPEND LS_RETURN TO ET_RETURN.
        CLEAR LS_RETURN.
        CONTINUE.
      ENDIF.
      IF NOT LS_CHARAC-ATNAM IS INITIAL.
* Collect the characteristic names for material
        LS_CHARAC_TEMP-ATNAM = LS_CHARAC-ATNAM.
        LS_CHARAC_TEMP-MATNR = LS_CHARAC-MATNR.
        APPEND LS_CHARAC_TEMP TO LT_CHARAC.
        CLEAR LS_CHARAC_TEMP.
      ENDIF.
      AT END OF MATNR.

        CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
          EXPORTING
            INSTANCE           = LV_CUOBF
            LANGUAGE           = SY-LANGU
          TABLES
            CONFIGURATION      = LT_CONF
          EXCEPTIONS
            INSTANCE_NOT_FOUND = 1
            OTHERS             = 2.
        IF SY-SUBRC <> 0.
          LS_RETURN-TYPE       = ZWMPP_GC_E.
          LS_RETURN-ID         = ZWMPP_DL_WM.
          LS_RETURN-NUMBER     = ZWMPP_GC_000.
          LS_RETURN-MESSAGE_V1 = LS_MAT_OBJ-MATNR.
          CONCATENATE 'Characteristics data not found for'(E37) LS_CHARAC-MATNR INTO
          LS_RETURN-MESSAGE SEPARATED BY SPACE.
          APPEND LS_RETURN TO ET_RETURN.
          CLEAR LS_RETURN.
          CONTINUE.
        ELSE.
* If variant configuration data is found, then check the characteristic supplied by IV_ATNAM
          IF NOT LT_CHARAC[] IS INITIAL.
            LOOP AT LT_CHARAC INTO LS_CHARAC_TEMP WHERE MATNR = LS_CHARAC-MATNR.
              READ TABLE LT_CONF INTO LS_CONF WITH KEY ATNAM = LS_CHARAC_TEMP-ATNAM.
              IF SY-SUBRC = 0.
                MOVE-CORRESPONDING LS_CONF TO LS_CHARAC_VAL.
                LS_CHARAC_VAL-MATNR = LS_MAT_OBJ-MATNR.
                APPEND LS_CHARAC_VAL TO ET_CHARAC_VALUES.
                CLEAR LS_CHARAC_VAL.
              ENDIF.
            ENDLOOP.
          ELSE.
            LOOP AT LT_CONF INTO LS_CONF.
              MOVE-CORRESPONDING LS_CONF TO LS_CHARAC_VAL.
              LS_CHARAC_VAL-MATNR = LS_MAT_OBJ-MATNR.
              APPEND LS_CHARAC_VAL TO ET_CHARAC_VALUES.
              CLEAR LS_CHARAC_VAL.
            ENDLOOP.
          ENDIF.
          REFRESH : LT_CHARAC,
                    LT_CONF.
        ENDIF.
      ENDAT.
    ENDLOOP.
  ELSE.
    LS_RETURN-TYPE       = ZWMPP_GC_E.
    LS_RETURN-ID         = ZWMPP_DL_WM.
    LS_RETURN-NUMBER     = ZWMPP_GC_000.
    LS_RETURN-MESSAGE = 'Characteristics not maintained for given input'(020).
    APPEND LS_RETURN TO ET_RETURN.
    CLEAR LS_RETURN.
  ENDIF.

ENDMETHOD.


method get_next_batch_number .
  data: lv_batch_num type charg_d,
        lv_num(8) type n,
        ls_batch_01 type zdl_uniqueid ,
        lt_batch  type standard table of zdl_uniqueid ,
        ls_batch     type zdl_gen_unit_id.


  refresh : lt_batch .

  call function 'Z_DL_E03126_UNIT_ID_CHECK'
    exporting
      iv_only_gen_unique_no = 'X'
    tables
      it_batch              = lt_batch.

  if sy-subrc = 0.
    clear : ls_batch,lv_batch_num.
    read table lt_batch into ls_batch_01 index 1.
    lv_batch_num = ls_batch_01-exidv.
    ev_charg = lv_batch_num.
  endif.

*************************OLD LOGIC**********************************

* Retrieve the Current Batch number from the table ZDL_GEN_UNIT_ID
*  select batch_num
*        from zdl_gen_unit_id up to 1 rows
*        into lv_batch_num.
*  endselect.

*  if sy-subrc = 0.
*
*    ev_charg = lv_batch_num.

*    call function 'ENQUEUE_EZZDL_GEN_UNIT_I'
*      exporting
*        batch_num      = lv_batch_num
*      exceptions
*        foreign_lock   = 1
*        system_failure = 2
*        others         = 3.

*    delete from zdl_gen_unit_id where batch_num = lv_batch_num.
*    lv_num = lv_batch_num+2(8).
*    lv_num = lv_num + 1.
*    concatenate lv_batch_num+0(2) lv_num into lv_batch_num.
*    ls_batch-batch_num = lv_batch_num.
*    insert into zdl_gen_unit_id values ls_batch.

*    if sy-subrc = 0.
*      commit work.
*    endif.

*    clear ls_batch.
*    call function 'DEQUEUE_EZZDL_GEN_UNIT_I'.
*  endif.
**********************************************************************
endmethod.


METHOD GET_PARTNER_STOLOC .
  SELECT SINGLE PARLG INTO IV_PARLG
  FROM  T001L
  WHERE WERKS = IV_WERKS
  AND   LGORT = IV_LGORT.

  IF SY-SUBRC NE 0 .
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_PARTNER_STOLOC_ERR
*        PREVIOUS =
        .
  ENDIF.

ENDMETHOD.


METHOD GET_PICK_PALLET_DATA .
  DATA: LS_HU_ITEM           TYPE VEPO,
        LS_SOURCE_HU         TYPE ZWMPP_TYP_S_HU.
  DATA: LT_BATCH             TYPE TT_BAPI1003_ALLOC_VALUES_NUM,
        LT_BATCH_CHAR        TYPE TT_BAPI1003_ALLOC_VALUES_CHAR,
        LS_BATCH             TYPE BAPI1003_ALLOC_VALUES_NUM,
        LS_BATCH_CHAR        TYPE BAPI1003_ALLOC_VALUES_CHAR,
        LS_SR_CHILD_RELATION TYPE VEKPVB.

  LOOP AT IT_VEPO INTO LS_HU_ITEM WHERE VELIN = '1'.
    READ TABLE GT_SR_CHILD_RELATION INTO LS_SR_CHILD_RELATION WITH KEY VENUM = LS_HU_ITEM-VENUM.
    IF SY-SUBRC = 0.
      LS_SOURCE_HU-EXIDV    = LS_SR_CHILD_RELATION-EXIDV.     "ME->GS_VEKP-EXIDV.
    ENDIF.
    LS_SOURCE_HU-MATNR    = LS_HU_ITEM-MATNR.
    LS_SOURCE_HU-CHARG    = LS_HU_ITEM-CHARG.
    LS_SOURCE_HU-VEMNG    = LS_HU_ITEM-VEMNG.
    LS_SOURCE_HU-VEMEH    = LS_HU_ITEM-VEMEH.
    LS_SOURCE_HU-ALTME    = LS_HU_ITEM-ALTME.
    REFRESH LT_BATCH.
    CLEAR LS_BATCH.

    CALL METHOD ZCL_U01339_PICK_PALLET=>READ_BATCH_CHARACTERISTIC
      EXPORTING
        IV_BATCH                 = LS_HU_ITEM-CHARG
        IV_MATERIAL              = LS_HU_ITEM-MATNR
        IV_PLANT                 = GS_VEKP-WERKS
      IMPORTING
        ET_BATCH_CHARACTERISTICS = LT_BATCH
        ET_BATCH_CHAR_VALUES     = LT_BATCH_CHAR
*    EV_MSG                   =
*    ET_MESSAGES              =
        .

    READ TABLE LT_BATCH INTO LS_BATCH WITH KEY CHARACT =
    'CARTONS_PER_PALLET'.
    IF SY-SUBRC = 0.
      LS_SOURCE_HU-SRC_CNTS = LS_BATCH-VALUE_FROM.
      LS_SOURCE_HU-CNTS = LS_BATCH-VALUE_FROM.
      IF LS_SOURCE_HU-CNTS > 99.
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
                EXPORTING
                  TEXTID =
                  ZCX_U01339_PICK_PALLET=>ZCX_U01339_INVALID_NO_OF_CNTS.
      ENDIF.
    ELSE.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
        EXPORTING
          TEXTID =
          ZCX_U01339_PICK_PALLET=>ZCX_U01339_CARTONS_NOT_FOUND
*    PREVIOUS =
          .
    ENDIF.
    CLEAR LS_BATCH.
    READ TABLE LT_BATCH INTO LS_BATCH WITH KEY CHARACT =
    'WEIGHT_OF_PALLET_IN_LBS'.
    IF SY-SUBRC = 0.
      LS_SOURCE_HU-BAT_VEMNG = LS_BATCH-VALUE_FROM.
    ELSE.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
             EXPORTING
               TEXTID =
ZCX_U01339_PICK_PALLET=>ZCX_U01339_CARTON_WT_NOT_FOUND.
    ENDIF.
* Check for SALES GRADE in the batch characteristics. If no sales grade is found
* for the batch, then raise an exception.
    CLEAR LS_BATCH.
    READ TABLE LT_BATCH_CHAR INTO LS_BATCH_CHAR WITH KEY CHARACT =
    'SALES_GRADE'.
    IF SY-SUBRC = 0.
      LS_SOURCE_HU-ZZSLGRD = LS_BATCH_CHAR-VALUE_CHAR.
    ELSE.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
             EXPORTING
               TEXTID =
ZCX_U01339_PICK_PALLET=>ZCX_U01339_SALES_GRADE_ERROR.
    ENDIF.



    LS_SOURCE_HU-LGNUM    = GS_LEIN-LGNUM.
    LS_SOURCE_HU-LGTYP    = GS_LEIN-LGTYP.
    LS_SOURCE_HU-LGPLA    = GS_LEIN-LGPLA.
    LS_SOURCE_HU-UPDATE   = SPACE.
    APPEND LS_SOURCE_HU TO ME->GT_SOURCE_HU.
    CLEAR LS_SOURCE_HU.
  ENDLOOP.
  APPEND LINES OF ME->GT_SOURCE_HU TO ET_HU_ITEM.
ENDMETHOD.


METHOD GET_STORAGE_UNIT_DETAILS .
  DATA: LS_LAGP TYPE LAGP.
* Retrieve the storage unit header details from LEIN table for the given Handling Unit.
* raise an error message if no details are found.
    SELECT SINGLE * INTO EV_LEIN
         FROM LEIN
    WHERE LENUM = IV_EXIDV.
  IF SY-SUBRC <> 0.
* Raise Error message if no information is found for the handling unit
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID   = ZCX_U01339_PICK_PALLET=>ZCX_U01339_LEIN_NOT_FOUND. "ZCX_U01339_STORAGE_INVALID. CMS-EDVK971424
*    PREVIOUS =     .
    RETURN.
* Start of Changes by VBHAGAV on 05/01/2009
* Validate the Storage Bin, the handling is associated with. Raise an
* exception if storage bin is invalid
  ELSE.
* Start of Changes by VBHAGAV on 05/04/2009
* Check if HU has any Open Transfer Order.
    if EV_LEIN-AOFTA > 0.
* Raise Error message if no information is found for the handling unit
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID   = ZCX_U01339_PICK_PALLET=>ZCX_U01339_OPEN_TO.
*    PREVIOUS =     .
    RETURN.
    endif.
* End   of Changes by VBHAGAV on 05/04/2009
*    TRY.
    CALL METHOD ZCL_U01339_PICK_PALLET=>VALIDATE_STORAGE_BIN
      EXPORTING
        IV_LGPLA = EV_LEIN-LGPLA
        IV_LGNUM = EV_LEIN-LGNUM
      IMPORTING
        ES_LAGP  = LS_LAGP.
*     CATCH ZCX_U01339_PICK_PALLET .
*    ENDTRY.
* End   of Changes by VBHAGAV on 05/01/2009
  ENDIF.
ENDMETHOD.


METHOD GET_USER_ATTRIBUTES .
*-> Local Data tables and Variables
  DATA : LT_LRF   TYPE STANDARD TABLE OF LRF_WKQU,
         LS_LRF   TYPE LRF_WKQU,
         LV_LINES TYPE I,
         LV_USER  TYPE SY-UNAME.

  LV_USER = SY-UNAME.

*-> Read user data
  CALL FUNCTION 'L_USER_DATA_GET'
    EXPORTING
      I_UNAME        = LV_USER
    TABLES
      T_XUSER        = LT_LRF
    EXCEPTIONS
      NO_ENTRY_FOUND = 1
      OTHERS         = 2.

  IF SY-SUBRC <> 0. " User not active in WH or not registered
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_USER_INVALID.
  ELSE.
    DELETE LT_LRF WHERE STATU <> 'X'.
*-> Find out if the user is active in more then 1 warehouse.
    DESCRIBE TABLE LT_LRF LINES LV_LINES.
    IF LV_LINES > 1.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
            EXPORTING
              TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_USER_INVALID.
    ENDIF.

*-> Retrieve the Warehouse number associated with the user.
    READ TABLE LT_LRF INTO LS_LRF INDEX 1.
    IF LS_LRF-STATU = 'X'.
      EV_LGNUM = LS_LRF-LGNUM. " Warehouse Number
    ENDIF.
  ENDIF.
ENDMETHOD.


METHOD LOCK_HANDLING_UNIT .
  CALL FUNCTION 'ENQUEUE_EVVEKPE'
   EXPORTING
*     MODE_VEKP            = 'E'
*     MANDT                = SY-MANDT
     VENUM                = IV_VENUM
*     X_VENUM              = ' '
*     _SCOPE               = '2'
*     _WAIT                = ' '
*     _COLLECT             = ' '
   EXCEPTIONS
     FOREIGN_LOCK         = 1
     SYSTEM_FAILURE       = 2
     OTHERS               = 3.
  IF SY-SUBRC <> 0.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_HU_LOCK_ERROR
*        PREVIOUS =
        .
  ENDIF.
ENDMETHOD.


method lock_hudat_entry .
* Lock HUDAT Entries
  call function 'ENQUEUE_EZZDL_WM_HUDAT'
    EXPORTING
*   MODE_ZDL_WM_HUDAT       = 'E'
    mandt                   =   sy-mandt
    pexidv                  =  iv_parent
    cexidv                  =  iv_child
*   X_PEXIDV                = ' '
*   X_CEXIDV                = ' '
*   _SCOPE                  = '2'
*   _WAIT                   = ' '
*   _COLLECT                = ' '
   exceptions
     foreign_lock            = 1
     system_failure          = 2
     others                  = 3.
  if sy-subrc <> 0.

    raise exception type zcx_u01339_pick_pallet
      exporting
        textid = zcx_u01339_pick_pallet=>zcx_u01339_hudat_lock_err
*        PREVIOUS =
        .

  endif.
*
endmethod.


METHOD MOVE_HU_BIN_TO_BIN .
  DATA:  LV_HAND_UNIT         TYPE EXIDV,
         LV_STO_BIN_CONF_TYPE TYPE LTAP_NLTYP,
         LV_STO_BIN_CONF      TYPE LGPLA,
         LV_MSG               TYPE SYMSGV,
         LV_MSG2              TYPE SYMSGV,
         LV_MSG3              TYPE SYMSGV,
         LV_MSG4              TYPE SYMSGV,
         LV_MSGTYP            TYPE SYMSGTY,
         LV_MSGID             TYPE SYMSGID,
         LV_MSGNO             TYPE SYMSGNO,
         LS_BAL_MSG           TYPE BAL_S_MSG.

  DATA:  LT_LTAP_VB           TYPE TABLE OF LTAP_VB.

* Move corresponding HU,storage Bin Type and storage bin
* to variables required for the below function module
  LV_HAND_UNIT         = IV_EXIDV.                          "GS_LEIN-LENUM.
  LV_STO_BIN_CONF_TYPE = IV_NLTYP.                           "'923'.                             " c_923.
  LV_STO_BIN_CONF      = IV_LGPLA.                           "'PACK.BIN'.

* Call FM L_TO_CREATE_MOVE_SU to create transfer Order
  CALL FUNCTION 'L_TO_CREATE_MOVE_SU'
    EXPORTING
      I_LENUM               = LV_HAND_UNIT
      I_BWLVS               = '999'                         "c_999
      I_NLTYP               = LV_STO_BIN_CONF_TYPE
      I_NLPLA               = LV_STO_BIN_CONF
      I_COMMIT_WORK         = 'X'
    TABLES
      T_LTAP_VB             = LT_LTAP_VB
    EXCEPTIONS
      NOT_CONFIRMED_TO      = 1
      FOREIGN_LOCK          = 2
      BWLVS_WRONG           = 3
      BETYP_WRONG           = 4
      NLTYP_WRONG           = 5
      NLPLA_WRONG           = 6
      NLTYP_MISSING         = 7
      NLPLA_MISSING         = 8
      SQUIT_FORBIDDEN       = 9
      LGBER_WRONG           = 10
      XFELD_WRONG           = 11
      DRUKZ_WRONG           = 12
      LDEST_WRONG           = 13
      NO_STOCK_ON_SU        = 14
      SU_NOT_FOUND          = 15
      UPDATE_WITHOUT_COMMIT = 16
      NO_AUTHORITY          = 17
      BENUM_REQUIRED        = 18
      LTAP_MOVE_SU_WRONG    = 19
      LENUM_WRONG           = 20
      ERROR_MESSAGE         = 22
      OTHERS                = 21.

* if transfer order created populate TO to message
* else mark invalid flag to 'X'
  IF SY-SUBRC = 0.
    LV_MSGTYP = ZWMPP_GC_S.
    CLEAR LV_MSG.
    CONCATENATE IV_EXIDV ': Moved to bin'(I05) IV_LGPLA ',TO' SY-MSGV1 INTO LV_MSG SEPARATED BY SPACE.
    COMMIT WORK AND WAIT.
  ELSE.
    LV_MSGTYP = ZWMPP_GC_E.
* Start of Changes by VBHAGAV on 04/28/2009
    LV_MSGID = SY-MSGID.
    LV_MSGNO = SY-MSGNO.
* End   of Changes by VBHAGAV on 04/28/2009
    CLEAR LV_MSG.
    CONCATENATE IV_EXIDV ': Moved to bin'(I05) IV_LGPLA 'failed' INTO LV_MSG SEPARATED BY SPACE.
    LV_MSG2 = SY-MSGV1.
    LV_MSG3 = SY-MSGV2.
    LV_MSG4 = SY-MSGV3.
    ROLLBACK WORK.
  ENDIF.


* Set the Message
  CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
    EXPORTING
      IV_MSGV1        = LV_MSG
      IV_MSGV2        = LV_MSG2
      IV_MSGV3        = LV_MSG3
      IV_MSGV4        = LV_MSG4
      IV_MSGID        = ZWMPP_DL_WM
      IV_MSGNO        = ZWMPP_GC_000
      IV_MESSAGE_TYPE = LV_MSGTYP
    IMPORTING
      ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
  IF NOT LS_BAL_MSG IS INITIAL.
    APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
    CLEAR : LS_BAL_MSG.
  ENDIF.

* Start of Changes by VBHAGAV on 04/28/2009
* If the move failed, then also Set the Standard SAP Message
  IF LV_MSGTYP = ZWMPP_GC_E.
    CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
      EXPORTING
        IV_MSGV1        = LV_MSG
        IV_MSGV2        = LV_MSG2
        IV_MSGV3        = LV_MSG3
        IV_MSGV4        = LV_MSG4
        IV_MSGID        = LV_MSGID
        IV_MSGNO        = LV_MSGNO
        IV_MESSAGE_TYPE = LV_MSGTYP
      IMPORTING
        ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
    IF NOT LS_BAL_MSG IS INITIAL.
      APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
      CLEAR : LS_BAL_MSG.
    ENDIF.
  ENDIF.
* End  of Changes by VBHAGAV on 04/28/2009

*   refresh the global memory
  CALL FUNCTION 'L_SAPLL03A_INIT_INT' .

  IF LV_MSGTYP = ZWMPP_GC_E.          "'E'.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
    EXPORTING
      TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_MOVE_INTERIM_ERR.
  ENDIF.

ENDMETHOD.


METHOD PACK_HANDLING_UNIT .
*----------------------------------------------------------------------*
* Change History                                                       *
* ==============                                                       *
* Programmer              Date               Description               *
* ===================  ===========  ================================== *
* Chandra Cherupally   07/23/2009   R14 - MTO Changes - Search CC01    *
*                                                                      *
*-----------------------------------------------------------------------

  DATA: LS_VEPO_HU   TYPE ZWMPP_TYP_S_HU,
        LS_HU_REF_ID TYPE VPOBJKEY.

  DATA: LS_HU_HEADER_MAIN           TYPE HUHDR_PROPOSAL,
        LS_HU_HEADER_CAPACITY       TYPE HUHDR_CAPACITY,
        LS_HU_HEADER_ADDITIONAL     TYPE HUHDR_ADDITIONAL_DATA,
        LS_HU_HEADER_TRANSPORT      TYPE HUHDR_TRANSPORT,
        LS_HU_ITEMS_PROPOSAL        TYPE HUITM_PROPOSAL,
        LS_HU_SERIAL_NR_LIST        TYPE HUITEM_SERIALNR,
        LS_HU_WORK_HEADER           TYPE VEKPVB,
        LS_HU_WORK_ITEMS            TYPE VEPOVB,
        LS_MM_DATA                  TYPE HUM_PLANT_STLOC.

  DATA: LT_HU_HEADER_MAIN           TYPE HUHDR_PROP,
        LT_HU_HEADER_CAPACITY       TYPE HUHDR_CAP,
        LT_HU_HEADER_ADDITIONAL     TYPE HUHDR_ADD,
        LT_HU_HEADER_TRANSPORT      TYPE HUHDR_TRA,
        LT_HU_ITEMS_PROPOSAL        TYPE HUITM_PROP,
        LT_HU_SERIAL_NR_LIST        TYPE HUITEM_SERNR,
        LT_HU_WORK_HEADER           TYPE HUM_HU_HEADER_T,
        LT_HU_WORK_ITEMS            TYPE HUM_HU_ITEM_T,
        LT_UNPACK_HU_EXT            TYPE HUM_EXIDV_T,
        LS_UNPACK_HU_EXT            TYPE HUM_EXIDV,
        LT_UNPACK_HU_INT            TYPE HUM_VENUM_T,
        LS_UNPACK_HU_INT            TYPE HUM_VENUM,
        LT_HU_MESSAGES              TYPE HUITEM_MESSAGES_T,
        LS_HU_MESSAGES              TYPE HUITEM_MESSAGES,
        LV_MBLNR                    TYPE MBLNR.

  DATA: LV_HU_ID        TYPE RLMOB-CLENUM,
        LV_NEW_HU        TYPE C,
        LV_UPDATE_DB     TYPE C,
        LV_CREATE_HU     TYPE C,
        LS_HU_REF_DOC    TYPE HUM_OBJECT,
        LV_SAVE_STEP(4)  TYPE C,
        LV_PACK_TYPE(3)  TYPE C,
        LV_MSG           TYPE SYMSGV,
        LV_MSG2           TYPE SYMSGV,
        LV_MSGTYP        TYPE SYMSGTY,
        LS_BAL_MSG       TYPE BAL_S_MSG,
        LV_PARLG         TYPE PARLG,
        LS_VEKP          TYPE VEKP,
        LS_VEPO          TYPE VEPO,
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGID         TYPE SYMSGID,
        LV_MSGNO         TYPE SYMSGNO,
        LV_MSGV1         TYPE SYMSGV,
        LV_MSGV2         TYPE SYMSGV,
        LV_MSGV3         TYPE SYMSGV,
        LV_MSGV4         TYPE SYMSGV.
* End   of Changes by VBHAGAV on 04/28/2009


  FIELD-SYMBOLS <LS_HU_ITEM> TYPE VEPO.
  DATA: LT_VEPO   TYPE STANDARD TABLE OF VEPO,
        LT_SOURCE_HU TYPE ZWMPP_TT_S_HU.

* This method can accept data from either the user or from private attributes of this class.
* if user inputs the data,then consider the same for the further processing. If no data is provided,
* then assume that data from the private attributes of the class.
  IF NOT IT_VEPO[] IS INITIAL.
    APPEND LINES OF IT_VEPO TO LT_VEPO.
  ELSE.
*    APPEND LINES OF ME->GT_HU_ITEM TO LT_VEPO.
  ENDIF.

  IF NOT IS_VEKP IS INITIAL.
    LS_VEKP = IS_VEKP.
  ELSE.
*    LS_VEKP = ME->GS_VEKP.
  ENDIF.

* Repack the batches to the new HU's entered on the second screen.
  LOOP AT LT_VEPO ASSIGNING  <LS_HU_ITEM>.

*    READ TABLE LT_VEPO INTO LS_HU_ITEM WITH KEY CHARG = LS_VEPO_HU-CHARG
*                                BINARY SEARCH.
* retrieve the partner storage location of the handling unit.
    CLEAR LV_PARLG.
*TRY.
    CALL METHOD ZCL_U01339_PICK_PALLET=>GET_PARTNER_STOLOC
      EXPORTING
        IV_WERKS = LS_VEKP-WERKS
        IV_LGORT = <LS_HU_ITEM>-LGORT
      RECEIVING
        IV_PARLG = LV_PARLG.
* CATCH ZCX_U01339_PICK_PALLET .
*ENDTRY.

* Update the items for the new HU
    LS_HU_ITEMS_PROPOSAL-EXIDV      = LS_VEKP-EXIDV.       "New External HU
    LS_HU_ITEMS_PROPOSAL-VELIN      = '1'.                 "Record 1 for creation
*    LS_HU_ITEMS_PROPOSAL-BELNR      = <LS_HU_ITEM>-VBELN.  "Document number of the packed item
*    LS_HU_ITEMS_PROPOSAL-POSNR      = <LS_HU_ITEM>-POSNR.  "Item number of the SD document
    LS_HU_ITEMS_PROPOSAL-CHARG      = <LS_HU_ITEM>-CHARG.  "Batch
    LS_HU_ITEMS_PROPOSAL-P_MATERIAL = LS_VEKP-VHILM.       "Package material
    LS_HU_ITEMS_PROPOSAL-MATNR      = <LS_HU_ITEM>-MATNR.  "Roll Material
    LS_HU_ITEMS_PROPOSAL-QUANTITY   = <LS_HU_ITEM>-VEMNG.  "Qty of Rolls
    IF <LS_HU_ITEM>-ALTME = 'KAR'.
      LS_HU_ITEMS_PROPOSAL-MEINS      = <LS_HU_ITEM>-ALTME.  "Alternate Unit of Measure
    ELSE.
      LS_HU_ITEMS_PROPOSAL-MEINS      = <LS_HU_ITEM>-VEMEH.  "Base Unit of Measure
    ENDIF.
    LS_HU_ITEMS_PROPOSAL-WERKS      = LS_VEKP-WERKS.       "Plant
    LS_HU_ITEMS_PROPOSAL-LGORT      = LV_PARLG.            "Partner Storage location(eg HP01)
    LS_HU_ITEMS_PROPOSAL-LGTYP      = '923'.               "Storage type
    LS_HU_ITEMS_PROPOSAL-LGPLA      = 'PACK.BIN'.          "Storage Bin
    LS_HU_ITEMS_PROPOSAL-UMLGO      = <LS_HU_ITEM>-LGORT.  "Move Storage Location for eg HU01
* >> Begin of Changes - CCHERUP - CC01
    LS_HU_ITEMS_PROPOSAL-SOBKZ      = <LS_HU_ITEM>-SOBKZ. " Spl. Stock Indicator
    LS_HU_ITEMS_PROPOSAL-SONUM      = <LS_HU_ITEM>-SONUM. " Spl. Stock No.
* << End of Changes - CCHERUP - CC01
    APPEND LS_HU_ITEMS_PROPOSAL TO LT_HU_ITEMS_PROPOSAL.

* One HU can have multiple batches . The Function Module will be
* invoked at the end of each new HU.
    AT END OF VENUM.
* Need to update the gv_hu_id with some value.
      LV_HU_ID =   'X'.
* Save step will be for ITEM since HU will be created with ITEMS.
* Also, Pack type will be 'HU' and the gv_create_hu flag will be set
*because we are going to create new HU's. Also, update flag gv_update_db
* will be set.
      LV_SAVE_STEP = 'ITEM'.    "C_ITEM_LEVEL. "'ITEM'
      LV_PACK_TYPE = 'HU'.      "C_NEW_HU.     "'HU'
      IF IV_REPACK IS INITIAL.
        LV_NEW_HU    = 'Y'.
        LV_CREATE_HU = 'X'.
      ELSE.

        LV_NEW_HU    = ''.
        LV_CREATE_HU = 'X'.

        LS_UNPACK_HU_EXT-EXIDV = LS_VEKP-EXIDV.
        APPEND LS_UNPACK_HU_EXT TO LT_UNPACK_HU_EXT.
        CLEAR LS_UNPACK_HU_EXT.

        LS_UNPACK_HU_INT-VENUM = LS_VEKP-VENUM.
        APPEND LS_UNPACK_HU_INT TO LT_UNPACK_HU_INT.
        CLEAR LS_UNPACK_HU_INT.
      ENDIF.
      LV_UPDATE_DB = 'X'.


*Update the Header structure with new external HU  entered on the second
*screen against the batch.Also, the package material will be added to
*the field VHILM.
      LS_HU_HEADER_MAIN-EXIDV  = LS_VEKP-EXIDV.  "New External HU
      LS_HU_HEADER_MAIN-VHILM  = LS_VEKP-VHILM.     "Package Material
      CLEAR LS_HU_HEADER_MAIN-STATUS.
      APPEND LS_HU_HEADER_MAIN TO LT_HU_HEADER_MAIN.

      IF NOT IV_REPACK IS INITIAL.
        LS_HU_REF_DOC-OBJKEY = LS_VEKP-EXIDV.
      ENDIF.
      LS_HU_REF_DOC-OBJECT = '12'.   "C_PACKAGE.                     "'12'.

*Update the gs_mm_data with Plant and Warehouse Number from VEKP. Also
*the storage type and bin from LEIN table will be used. The move
*storage location will be the new HU managed storage location .for eg
*HU01

      LS_MM_DATA-PLANT                 =  LS_VEKP-WERKS.        "Plant
      LS_MM_DATA-WHSE_NO               =  LS_VEKP-LGNUM.        "Warehouse Number
      LS_MM_DATA-STGE_TYPE             =  '923'.                "Storage Type
      LS_MM_DATA-STGE_BIN              =  'PACK.BIN'.           "Storage Bin
      LS_MM_DATA-MOVE_STLOC            =  <LS_HU_ITEM>-LGORT.   "HU storage location

      CALL FUNCTION 'HU_PACKING_REFRESH'.
      CALL FUNCTION 'SERIAL_INTTAB_REFRESH' .
      CALL FUNCTION 'L_SAPLL03A_INIT_INT' .

* Call the function module to pack the new HU's
      CALL FUNCTION 'PACK_HANDLING_UNIT'
        EXPORTING
          I_HU_ID                = LV_HU_ID
          I_NEW_HU               = LV_NEW_HU
          I_UPDATE_DB            = LV_UPDATE_DB
          I_CREATE_HU            = LV_CREATE_HU
          I_REFERENCE_OBJECT     = LS_HU_REF_DOC
          I_MM_DATA              = LS_MM_DATA
          I_HU_HEADER_MAIN       = LT_HU_HEADER_MAIN[]
          I_HU_HEADER_CAPACITY   = LT_HU_HEADER_CAPACITY[]
          I_HU_HEADER_ADDITIONAL = LT_HU_HEADER_ADDITIONAL[]
          I_HU_HEADER_TRANSPORT  = LT_HU_HEADER_TRANSPORT[]
          I_HU_ITEMS             = LT_HU_ITEMS_PROPOSAL[]
          I_HU_SERIAL_NR         = LT_HU_SERIAL_NR_LIST[]
          I_SAVE_STEP            = LV_SAVE_STEP
          I_PACK_ACTIVITY        = LV_PACK_TYPE
          I_HU_EXTERNAL          = LT_UNPACK_HU_EXT[]
          I_HU_INTERNAL          = LT_UNPACK_HU_INT[]
        IMPORTING
          O_HU_REF_ID            = LS_HU_REF_ID
          O_HU_HEADER            = ET_HU_HEADER[]
          O_HU_ITEMS             = ET_HU_ITEMS[]
          O_HU_MESSAGES          = LT_HU_MESSAGES[]
        EXCEPTIONS
          INPUT_MISSING          = 01
          NOT_POSSIBLE           = 02
          FATAL_ERROR            = 03
          OPERATION_FAILED       = 04
          ERROR_MESSAGE          = 99.

      IF SY-SUBRC = 0.

        COMMIT WORK AND WAIT.
        CLEAR LV_MBLNR.
        LOOP AT LT_HU_MESSAGES INTO LS_HU_MESSAGES
                       WHERE MSGID = 'HUGENERAL'
                         AND MSGTY = ZWMPP_GC_S
                         AND MSGNO = '309'.
          IF NOT LS_HU_MESSAGES-MSGV1 IS INITIAL.
            LV_MBLNR = LS_HU_MESSAGES-MSGV1.
            EXIT.
          ENDIF.
        ENDLOOP.
        CONCATENATE IS_VEKP-EXIDV ':'
                    'Pack'(S31)
                    'Mat.Doc'(I07)
                    LV_MBLNR INTO LV_MSG SEPARATED BY SPACE.
        LV_MSGTYP = ZWMPP_GC_S.     "'S'.
      ELSE.
        CASE SY-SUBRC.
          WHEN '1'.
            CONCATENATE IS_VEKP-EXIDV ':' 'Packing failed.Input missing'(E20) INTO LV_MSG SEPARATED BY SPACE.
          WHEN '2'.
            CONCATENATE IS_VEKP-EXIDV ':' 'Packing failed.Not possible'(E21) INTO LV_MSG SEPARATED BY SPACE.
          WHEN '3'.
            CONCATENATE IS_VEKP-EXIDV ':' 'Packing failed.Fatal error'(E22) INTO LV_MSG SEPARATED BY SPACE.
          WHEN '4'.
            CONCATENATE IS_VEKP-EXIDV ':' 'Packing was unsuccessful'(E23) INTO LV_MSG SEPARATED BY SPACE.
          WHEN OTHERS.
            CONCATENATE IS_VEKP-EXIDV ':' 'Packing was unsuccessful'(E23) INTO LV_MSG SEPARATED BY SPACE.
        ENDCASE.


        CALL FUNCTION 'FORMAT_MESSAGE'
          EXPORTING
            ID  = SY-MSGID
            NO  = SY-MSGNO
            V1  = SY-MSGV1
            V2  = SY-MSGV2
            V3  = SY-MSGV3
            V4  = SY-MSGV4
          IMPORTING
            MSG = LV_MSG2.

*        IF SY-SUBRC =  0 AND NOT LV_MSG2 IS INITIAL.
*          LV_MSG = LV_MSG2.
*        ENDIF.
        LV_MSGTYP = ZWMPP_GC_E.            "'E'.
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGID = SY-MSGID.
        LV_MSGNO = SY-MSGNO.
        LV_MSGV1 = SY-MSGV1.
        LV_MSGV2 = SY-MSGV2.
        LV_MSGV3 = SY-MSGV3.
        LV_MSGV4 = SY-MSGV4.
* End   of Changes by VBHAGAV on 04/28/2009
        ROLLBACK WORK.
      ENDIF.

* Set the Message
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MSGV1        = LV_MSG
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
          IV_MESSAGE_TYPE = LV_MSGTYP
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
      IF NOT LS_BAL_MSG IS INITIAL.
*        APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
        APPEND LS_BAL_MSG TO ET_RETURN.
        CLEAR : LS_BAL_MSG.
      ENDIF.

      IF LV_MSGTYP = ZWMPP_GC_E.      "'E'.
* Start of Changes by VBHAGAV on 04/28/2009
* If Packing fails, then also Set the Standard SAP Message
        CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
          EXPORTING
            IV_MSGV1        = LV_MSGV1
            IV_MSGV2        = LV_MSGV2
            IV_MSGV3        = LV_MSGV3
            IV_MSGV4        = LV_MSGV4
            IV_MSGID        = LV_MSGID
            IV_MSGNO        = LV_MSGNO
            IV_MESSAGE_TYPE = LV_MSGTYP
          IMPORTING
            ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
        IF NOT LS_BAL_MSG IS INITIAL.
*        APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
          APPEND LS_BAL_MSG TO ET_RETURN.
          CLEAR : LS_BAL_MSG.
        ENDIF.
* End   of Changes by VBHAGAV on 04/28/2009

        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_PACK_ERROR
*            PREVIOUS =
            .
      ENDIF.
* Clear data
      REFRESH : LT_HU_ITEMS_PROPOSAL,
                LT_UNPACK_HU_EXT,
                LT_UNPACK_HU_INT,
                LT_HU_HEADER_MAIN.
      CLEAR LS_MM_DATA.

    ENDAT.

  ENDLOOP.
ENDMETHOD.


METHOD PACK_NESTED_HU .
  DATA: LS_VEPO_HU   TYPE ZWMPP_TYP_S_HU,
            LS_HU_REF_ID TYPE VPOBJKEY.

  DATA: LS_HU_HEADER_MAIN           TYPE HUHDR_PROPOSAL,
        LS_HU_HEADER_CAPACITY       TYPE HUHDR_CAPACITY,
        LS_HU_HEADER_ADDITIONAL     TYPE HUHDR_ADDITIONAL_DATA,
        LS_HU_HEADER_TRANSPORT      TYPE HUHDR_TRANSPORT,
        LS_HU_ITEMS_PROPOSAL        TYPE HUITM_PROPOSAL,
        LS_HU_SERIAL_NR_LIST        TYPE HUITEM_SERIALNR,
        LS_HU_WORK_HEADER           TYPE VEKPVB,
        LS_HU_WORK_ITEMS            TYPE VEPOVB,
        LS_MM_DATA                  TYPE HUM_PLANT_STLOC.

  DATA: LT_HU_HEADER_MAIN           TYPE HUHDR_PROP,
        LT_HU_HEADER_CAPACITY       TYPE HUHDR_CAP,
        LT_HU_HEADER_ADDITIONAL     TYPE HUHDR_ADD,
        LT_HU_HEADER_TRANSPORT      TYPE HUHDR_TRA,
        LT_HU_ITEMS_PROPOSAL        TYPE HUITM_PROP,
        LT_HU_SERIAL_NR_LIST        TYPE HUITEM_SERNR,
        LT_HU_WORK_HEADER           TYPE HUM_HU_HEADER_T,
        LT_HU_WORK_ITEMS            TYPE HUM_HU_ITEM_T,
        LT_UNPACK_HU_EXT            TYPE HUM_EXIDV_T,
        LS_UNPACK_HU_EXT            TYPE HUM_EXIDV,
        LT_UNPACK_HU_INT            TYPE HUM_VENUM_T,
        LS_UNPACK_HU_INT            TYPE HUM_VENUM,
        LT_HU_MESSAGES              TYPE HUITEM_MESSAGES_T,
        LS_HU_MESSAGES              TYPE HUITEM_MESSAGES,
        LV_MBLNR                    TYPE MBLNR.

  DATA: LV_HU_ID        TYPE RLMOB-CLENUM,
        LV_NEW_HU        TYPE C,
        LV_UPDATE_DB     TYPE C,
        LV_CREATE_HU     TYPE C,
        LS_HU_REF_DOC    TYPE HUM_OBJECT,
        LV_SAVE_STEP(4)  TYPE C,
        LV_PACK_TYPE(3)  TYPE C,
        LV_MSG           TYPE SYMSGV,
        LV_MSGTYP        TYPE SYMSGTY,
        LS_BAL_MSG       TYPE BAL_S_MSG,
        LV_PARLG         TYPE PARLG,
        LS_VEKP          TYPE VEKP,
        LS_VEPO          TYPE VEPO,
        LS_SUB_HU_HEAD   TYPE VEKP,
        LREF_ERROR       TYPE REF TO ZCX_U01339_PICK_PALLET,
        LV_REPACK        TYPE C,
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGID         TYPE SYMSGID,
        LV_MSGNO         TYPE SYMSGNO,
        LV_MSGV1         TYPE SYMSGV,
        LV_MSGV2         TYPE SYMSGV,
        LV_MSGV3         TYPE SYMSGV,
        LV_MSGV4         TYPE SYMSGV,
        LV_SUBRC         TYPE SY-SUBRC.
* End   of Changes by VBHAGAV on 04/28/2009

  FIELD-SYMBOLS <LS_HU_ITEM> TYPE ZWMPP_TYP_SUB_HU.
  DATA: LT_VEPO   TYPE STANDARD TABLE OF VEPO,
        LT_SOURCE_HU TYPE ZWMPP_TT_S_HU.

* This method can accept data from either the user or from private attributes of this class.
* if user inputs the data,then consider the same for the further processing. If no data is provided,
* then assume that data from the private attributes of the class.
*  LS_VEKP = GS_VEKP.

  TRY.
      CALL METHOD ZCL_U01339_PICK_PALLET=>GET_HU_HEADER_DETAILS
        EXPORTING
          IV_EXIDV               = IS_PARENT_HU-EXIDV
*    IV_VENUM               =
          IV_LGNUM               = IS_PARENT_HU-LGNUM
*    IV_WHERE_FLAG          =
        IMPORTING
          EV_VEKP                = LS_VEKP.
    CATCH ZCX_U01339_PICK_PALLET INTO LREF_ERROR.
  ENDTRY.

  IF NOT LS_VEKP IS INITIAL.
    LV_REPACK = ZWMPP_GC_X.
  ELSE.
    LS_VEKP = IS_PARENT_HU.
  ENDIF.

* Repack the batches to the new HU's entered on the second screen.
  LOOP AT IT_SUB_HU ASSIGNING  <LS_HU_ITEM>.
* Update the items for the new HU
    LS_HU_ITEMS_PROPOSAL-EXIDV      = IS_PARENT_HU-EXIDV.        "New External HU
    LS_HU_ITEMS_PROPOSAL-VENUM      = LS_VEKP-VENUM.
    LS_HU_ITEMS_PROPOSAL-VELIN      = '3'.                       "Record 1 for creation
    LS_HU_ITEMS_PROPOSAL-P_MATERIAL = LS_VEKP-VHILM.        "Package material

    LS_HU_ITEMS_PROPOSAL-QUANTITY   = '1'.    "<LS_HU_ITEM>-BRGEW.    "Qty of Rolls
    LS_HU_ITEMS_PROPOSAL-VEANZ      = '1'.
    LS_HU_ITEMS_PROPOSAL-LGTYP      = '923'.                 "Storage type
    LS_HU_ITEMS_PROPOSAL-LGPLA      = 'PACK.BIN'.            "Storage Bin

    LS_HU_ITEMS_PROPOSAL-SUB_HU_VENUM = <LS_HU_ITEM>-VENUM.
    LS_HU_ITEMS_PROPOSAL-SUB_HU_EXIDV = <LS_HU_ITEM>-EXIDV.
    APPEND LS_HU_ITEMS_PROPOSAL TO LT_HU_ITEMS_PROPOSAL.

*    IF NOT LV_REPACK IS INITIAL.
    LS_UNPACK_HU_EXT-EXIDV = <LS_HU_ITEM>-EXIDV.
    APPEND LS_UNPACK_HU_EXT TO LT_UNPACK_HU_EXT.
    CLEAR LS_UNPACK_HU_EXT.

    LS_UNPACK_HU_INT-VENUM = <LS_HU_ITEM>-VENUM.
    APPEND LS_UNPACK_HU_INT TO LT_UNPACK_HU_INT.
    CLEAR LS_UNPACK_HU_INT.
*    ENDIF.

* One HU can have multiple batches . The Function Module will be
* invoked at the end of each new HU.
    AT LAST.
* Need to update the gv_hu_id with some value.
      LV_HU_ID =   'X'.
* Save step will be for ITEM since HU will be created with ITEMS.
* Also, Pack type will be 'HU' and the gv_create_hu flag will be set
*because we are going to create new HU's. Also, update flag gv_update_db
* will be set.
      LV_SAVE_STEP = 'ITEM'.    "C_ITEM_LEVEL. "'ITEM'
      LV_PACK_TYPE = 'HU'.      "C_NEW_HU.     "'HU'
      IF LV_REPACK IS INITIAL.
        LV_NEW_HU    = 'Y'.
        LV_CREATE_HU = 'X'.
      ELSE.
        LV_NEW_HU    = ''.
        LV_CREATE_HU = 'X'.
      ENDIF.
* Capture the ExternalHandling Unit numbers of the Parent
      LS_UNPACK_HU_EXT-EXIDV = LS_VEKP-EXIDV.
      APPEND LS_UNPACK_HU_EXT TO LT_UNPACK_HU_EXT.
      CLEAR LS_UNPACK_HU_EXT.
* Capture the Internal Handling Unit numbers of the Parent
      LS_UNPACK_HU_INT-VENUM = LS_VEKP-VENUM.
      APPEND LS_UNPACK_HU_INT TO LT_UNPACK_HU_INT.
      CLEAR LS_UNPACK_HU_INT.
      LV_UPDATE_DB = 'X'.

*Update the Header structure with new external HU  entered on the second
*screen against the batch.Also, the package material will be added to
*the field VHILM.
      LS_HU_HEADER_MAIN-EXIDV  = LS_VEKP-EXIDV.     "New External HU
      LS_HU_HEADER_MAIN-VHILM  = LS_VEKP-VHILM.     "Package Material
      CLEAR LS_HU_HEADER_MAIN-STATUS.
      APPEND LS_HU_HEADER_MAIN TO LT_HU_HEADER_MAIN.

*      IF NOT LV_REPACK IS INITIAL.
      LS_HU_REF_DOC-OBJKEY = LS_VEKP-EXIDV.
*      ENDIF.
      LS_HU_REF_DOC-OBJECT = '12'.   "C_PACKAGE.                     "'12'.

*Update the gs_mm_data with Plant and Warehouse Number from VEKP. Also
*the storage type and bin from LEIN table will be used. The move
*storage location will be the new HU managed storage location .for eg
*HU01

      LS_MM_DATA-PLANT                 =  LS_VEKP-WERKS.        "Plant
      LS_MM_DATA-WHSE_NO               =  LS_VEKP-LGNUM.        "Warehouse Number
      LS_MM_DATA-STGE_TYPE             =  '923'.                "Storage Type
      LS_MM_DATA-STGE_BIN              =  'PACK.BIN'.           "Storage Bin
      LS_MM_DATA-MOVE_STLOC            =  'HU01'.               "HU storage location

      CALL FUNCTION 'HU_PACKING_REFRESH'.
      CALL FUNCTION 'SERIAL_INTTAB_REFRESH' .
      CALL FUNCTION 'L_SAPLL03A_INIT_INT' .

* Call the function module to pack the new HU's
      CALL FUNCTION 'PACK_HANDLING_UNIT'
        EXPORTING
          I_HU_ID                = LV_HU_ID
          I_NEW_HU               = LV_NEW_HU
          I_UPDATE_DB            = LV_UPDATE_DB
          I_CREATE_HU            = LV_CREATE_HU
          I_REFERENCE_OBJECT     = LS_HU_REF_DOC
          I_MM_DATA              = LS_MM_DATA
          I_HU_HEADER_MAIN       = LT_HU_HEADER_MAIN[]
          I_HU_HEADER_CAPACITY   = LT_HU_HEADER_CAPACITY[]
          I_HU_HEADER_ADDITIONAL = LT_HU_HEADER_ADDITIONAL[]
          I_HU_HEADER_TRANSPORT  = LT_HU_HEADER_TRANSPORT[]
          I_HU_ITEMS             = LT_HU_ITEMS_PROPOSAL[]
          I_HU_SERIAL_NR         = LT_HU_SERIAL_NR_LIST[]
          I_SAVE_STEP            = LV_SAVE_STEP
          I_PACK_ACTIVITY        = LV_PACK_TYPE
          I_HU_EXTERNAL          = LT_UNPACK_HU_EXT[]
          I_HU_INTERNAL          = LT_UNPACK_HU_INT[]
        IMPORTING
          O_HU_REF_ID            = LS_HU_REF_ID
*          O_HU_HEADER            = ET_HU_HEADER[]
*          O_HU_ITEMS             = ET_HU_ITEMS[]
          O_HU_MESSAGES          = LT_HU_MESSAGES[]
        EXCEPTIONS
          INPUT_MISSING          = 01
          NOT_POSSIBLE           = 02
          FATAL_ERROR            = 03
          OPERATION_FAILED       = 04
          ERROR_MESSAGE          = 99.

      IF SY-SUBRC = 0.

        COMMIT WORK AND WAIT.
        CLEAR LV_MBLNR.
        LOOP AT LT_HU_MESSAGES INTO LS_HU_MESSAGES
                       WHERE MSGID = 'HUGENERAL'
                         AND MSGTY = ZWMPP_GC_S
                         AND MSGNO = '308'.
          IF NOT LS_HU_MESSAGES-MSGV1 IS INITIAL.
            LV_MBLNR = LS_HU_MESSAGES-MSGV1.
            EXIT.
          ENDIF.
        ENDLOOP..
        CONCATENATE IS_PARENT_HU-EXIDV ':'
                    'Pack'(S31)
                    'TO'(I30)
                    LV_MBLNR INTO LV_MSG SEPARATED BY SPACE.
        LV_MSGTYP = ZWMPP_GC_S.     "'S'.

      ELSE.
        LV_SUBRC = SY-SUBRC.
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGV1 = SY-MSGV1.
        LV_MSGV2 = SY-MSGV2.
        LV_MSGV3 = SY-MSGV3.
        LV_MSGV4 = SY-MSGV4.
        LV_MSGID = SY-MSGID.
        LV_MSGNO = SY-MSGNO.
* End   of Changes by VBHAGAV on 04/28/2009
        CASE LV_SUBRC.
          WHEN '1'.
            CONCATENATE LS_VEKP-EXIDV ':' 'Packing failed.Input missing'(E20) INTO LV_MSG SEPARATED BY SPACE.
          WHEN '2'.
            CONCATENATE LS_VEKP-EXIDV ':' 'Packing failed.Not possible'(E21) INTO LV_MSG SEPARATED BY SPACE.
          WHEN '3'.
            CONCATENATE LS_VEKP-EXIDV ':' 'Packing failed.Fatal error'(E22) INTO LV_MSG SEPARATED BY SPACE.
          WHEN '4'.
            CONCATENATE LS_VEKP-EXIDV ':' 'Packing was unsuccessful'(E23) INTO LV_MSG SEPARATED BY SPACE.
          WHEN OTHERS.
            CONCATENATE LS_VEKP-EXIDV ':' 'Packing was unsuccessful'(E23) INTO LV_MSG SEPARATED BY SPACE.
        ENDCASE.
        LV_MSGTYP = ZWMPP_GC_E.            "'E'.

        ROLLBACK WORK.
      ENDIF.

* Set the Message
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MSGV1        = LV_MSG
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
          IV_MESSAGE_TYPE = LV_MSGTYP
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_MSG.
      IF NOT LS_BAL_MSG IS INITIAL.
        APPEND LS_BAL_MSG TO ET_RETURN.
      ENDIF.
** Write the message to the application log
*      IF NOT LS_BAL_MSG IS INITIAL.
*        APPEND LS_BAL_MSG TO GREF_S_HU->GT_LOG_MSG.
*        CLEAR : LS_BAL_MSG.
*      ENDIF.

      IF LV_MSGTYP = ZWMPP_GC_E.      "'E'.
* Start of Changes by VBHAGAV on 04/28/2009
        CLEAR LS_BAL_MSG.
* If Packing fails, then also Set the Standard SAP Message
        CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
          EXPORTING
            IV_MSGV1        = LV_MSGV1
            IV_MSGV2        = LV_MSGV2
            IV_MSGV3        = LV_MSGV3
            IV_MSGV4        = LV_MSGV4
            IV_MSGID        = LV_MSGID
            IV_MSGNO        = LV_MSGNO
            IV_MESSAGE_TYPE = LV_MSGTYP
          IMPORTING
            ES_BAL_S_MSG    = LS_BAL_MSG.
        IF NOT LS_BAL_MSG IS INITIAL.
          APPEND LS_BAL_MSG TO ET_RETURN.
        ENDIF.
* End  of Changes by VBHAGAV on 04/28/2009
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_PACK_ERROR
*            PREVIOUS =
        .
      ENDIF.
* Clear data
      REFRESH : LT_HU_ITEMS_PROPOSAL,
                LT_UNPACK_HU_EXT,
                LT_UNPACK_HU_INT,
                LT_HU_HEADER_MAIN.
      CLEAR LS_MM_DATA.

    ENDAT.

  ENDLOOP.
ENDMETHOD.


METHOD READ_BATCH_CHARACTERISTIC .
  DATA: LS_CLASS              TYPE KLAH-CLASS,
        LS_CLASS_TYPE         TYPE KLAH-KLART,
        LS_POBTAB             TYPE TCLAO-OBTAB,
        LV_OBJEC_CHARG        TYPE KSSK-OBJEK,
        LV_NO_OF_ROLLS        TYPE I,
        LS_ALLOCVALUESCHARNEW TYPE BAPI1003_ALLOC_VALUES_CHAR,
        LT_ALLOCVALUESNUMNEW  TYPE TABLE OF BAPI1003_ALLOC_VALUES_NUM,
        LT_ALLOCVALUESCHARNEW TYPE TABLE OF BAPI1003_ALLOC_VALUES_CHAR,
        LT_ALLOCVALUESCURRNEW TYPE TABLE OF BAPI1003_ALLOC_VALUES_CURR,
        LT_BAPIRET2           TYPE BAPIRET2,
        LF_OBJECTKEY          TYPE BAPI1003_KEY-OBJECT,
        LF_OBJECTTABLE        TYPE BAPI1003_KEY-OBJECTTABLE,
        LF_CLASSNUM           TYPE BAPI1003_KEY-CLASSNUM,
        LF_CLASSTYPE          TYPE BAPI1003_KEY-CLASSTYPE,
        LO_OBJECT             TYPE OBJNUM,
        LT_OBJECTTABLE        TYPE TABELLE,
        LS_CLASSTYPE          TYPE KLASSENART,
        LV_OBJEK              TYPE INOB-OBJEK,
        LV_OBTAB              TYPE INOB-OBTAB,
        LT_RETURN             TYPE TT_BAPIRET2,
        LS_OBJECT_KEY         TYPE INOB-CUOBJ,
        LS_RETURN             TYPE BAPIRET2,
        LS_INOB               TYPE INOB,
        LV_MSG                TYPE SYMSGV,
        LV_MSGTYP             TYPE SYMSGTY,
        LS_WMPP_TYP_CHARG    TYPE ZWMPP_TYP_CHARG.

*Get the Class name and type which will usually be the batch and
*material concatenated together.

  CALL FUNCTION 'QC01_BATCH_CLASS'
    EXPORTING
      I_BATCH        = IV_BATCH
      I_MATERIAL     = IV_MATERIAL
      I_PLANT        = IV_PLANT
      I_LANGUAGE     = SY-LANGU
    IMPORTING
      E_CLASS        = LS_CLASS
      E_CLASS_TYPE   = LS_CLASS_TYPE
      E_OBJEC_CHARG  = LV_OBJEC_CHARG
      E_OBTAB        = LS_POBTAB
    EXCEPTIONS
      NO_CLASS       = 1
      INTERNAL_ERROR = 2
      NO_MATERIAL    = 3
      NO_BATCH       = 4
      NO_PLANT       = 5
      OTHERS         = 6.

  IF SY-SUBRC <> 0.
    CONCATENATE IV_BATCH 'Batch update failed'(E12) INTO LV_MSG.
    LV_MSGTYP = 'E'.
    EXIT.
  ENDIF.

  LF_CLASSNUM  = LS_CLASS.
  LF_CLASSTYPE = LS_CLASS_TYPE.
  LF_OBJECTKEY = LV_OBJEC_CHARG.
  LF_OBJECTTABLE = LS_POBTAB.

  SELECT SINGLE * FROM INOB INTO LS_INOB
                  WHERE KLART = LS_CLASS_TYPE
                    AND OBJEK = LV_OBJEC_CHARG
                    AND OBTAB = LS_POBTAB.

  IF SY-SUBRC = 0.
    LS_OBJECT_KEY = LS_INOB-CUOBJ.
  ELSE.
    CONCATENATE IV_BATCH 'Batch update failed'(E12) INTO LV_MSG.
    LV_MSGTYP = 'E'.
    EXIT.
  ENDIF.

  CALL FUNCTION 'BAPI_OBJCL_GETDETAIL_KEY'
    EXPORTING
      CLOBJECTKEY     = LS_OBJECT_KEY
      CLASSNUM        = LS_CLASS
    TABLES
      ALLOCVALUESNUM  = LT_ALLOCVALUESNUMNEW
      ALLOCVALUESCHAR = LT_ALLOCVALUESCHARNEW
      ALLOCVALUESCURR = LT_ALLOCVALUESCURRNEW
      RETURN          = LT_RETURN.
  .
  ET_BATCH_CHARACTERISTICS = LT_ALLOCVALUESNUMNEW.
  ET_BATCH_CHAR_VALUES     = LT_ALLOCVALUESCHARNEW.
  IF SY-SUBRC = 0.
    LV_MSGTYP = 'I'.
    CONCATENATE IV_BATCH 'Batch update successful'(I07) INTO
    LV_MSG.
* RMYNEEDU - 11/30/09 - No need to Commit\Rollback work here as
* this method is intended to read batch characteristic
*    COMMIT WORK AND WAIT.
    CLEAR : LS_WMPP_TYP_CHARG .
    LS_WMPP_TYP_CHARG-CHARG = IV_BATCH.
    LS_WMPP_TYP_CHARG-MATNR = IV_MATERIAL.
    LS_WMPP_TYP_CHARG-ALLOC_VALUES_NUM  = LT_ALLOCVALUESNUMNEW.
    LS_WMPP_TYP_CHARG-ALLOC_VALUES_CHAR = LT_ALLOCVALUESCHARNEW.
    LS_WMPP_TYP_CHARG-ALLOC_VALUES_CURR = LT_ALLOCVALUESCURRNEW.
    APPEND LS_WMPP_TYP_CHARG TO GT_WMPP_TYP_CHARG.
  ELSE.
    CONCATENATE IV_BATCH 'Batch update failed'(E12) INTO LV_MSG.
*    ROLLBACK WORK.
    LV_MSGTYP = 'E'.
    EXIT.
  ENDIF.

ENDMETHOD.


METHOD SET_DES_HUHEADER_DETAILS .
* Set the destination Handling Unit header details to the instance attribute
  ME->GS_DES_VEKP = IV_VEKP.
ENDMETHOD.


METHOD SET_DES_HU_ITEM_DETAILS .
  IF NOT IT_DES_VEPO[] IS INITIAL.
    ME->GT_DES_VEPO[] = IT_DES_VEPO[].
  ENDIF.

  IF NOT IT_DES_CHILD_RELATION[] IS INITIAL.
    ME->GT_DE_CHILD_RELATION[] = IT_DES_CHILD_RELATION[].
  ENDIF.

  IF NOT IV_HU_NESTED IS INITIAL.
    ME->GV_DES_NESTED_FLAG = IV_HU_NESTED.
  ENDIF.
ENDMETHOD.


METHOD SET_MESSAGE_BUFFER .

  DATA: LV_DUMMY  TYPE STRING .

  ES_BAL_S_MSG-MSGTY = IV_MESSAGE_TYPE.
  ES_BAL_S_MSG-MSGID = IV_MSGID.
  ES_BAL_S_MSG-MSGNO = IV_MSGNO.
  ES_BAL_S_MSG-MSGV1 = IV_MSGV1.
  ES_BAL_S_MSG-MSGV2 = IV_MSGV2.
  ES_BAL_S_MSG-MSGV3 = IV_MSGV3.
  ES_BAL_S_MSG-MSGV4 = IV_MSGV4.
ENDMETHOD.


METHOD SET_SOURCE_HU .
  DATA: LS_SOURCE_HU TYPE ZWMPP_TYP_S_HU,
        LS_BATCH     TYPE ZWMPP_TYP_S_HU,
        LS_VEPO      TYPE VEPO,
        LT_BATCH     TYPE ZWMPP_TT_S_HU,
        LV_MATNR     TYPE MATNR,
        LV_CNTS_TEMP TYPE I.

*  REFRESH ME->GT_SOURCE_HU.
* Set the Association flag
  GV_ASSOCIATION_FLAG = ZWMPP_GC_X.

  LT_BATCH[] = IT_BATCH[].
  SORT LT_BATCH BY MATNR CHARG.

  IF GS_VEKP-EXIDV <> GS_DES_VEKP-EXIDV.
    CLEAR GV_ASSOCIATION_FLAG.
  ENDIF.

  LOOP AT LT_BATCH INTO LS_BATCH.

    MOVE-CORRESPONDING LS_BATCH TO LS_SOURCE_HU.

* If Both Source and destination are the same and the Cartons are moved from
* Source, then Clear the association flag.
    IF GS_VEKP-EXIDV = GS_DES_VEKP-EXIDV.
      IF LS_BATCH-SRC_CNTS <> LS_BATCH-CNTS AND
         NOT LS_BATCH-SRC_CNTS IS INITIAL.
        CLEAR GV_ASSOCIATION_FLAG.
      ENDIF.
    ENDIF.

    LS_SOURCE_HU-EXIDV  = LS_BATCH-EXIDV.     "IV_EXIDV.
    LS_SOURCE_HU-CHARG  = LS_BATCH-CHARG.
    LS_SOURCE_HU-DES_CNTS = LS_BATCH-DES_CNTS.

    CASE LS_BATCH-ALTME.
      WHEN 'KAR'.
* Update the Quantity in Cartons
        LS_SOURCE_HU-SRC_VEMNG = LS_BATCH-SRC_CNTS.
      WHEN OTHERS.
* Update the final Quantity to be packed into the source pallet
        LS_SOURCE_HU-SRC_VEMNG = LS_BATCH-BAT_VEMNG * ( LS_BATCH-SRC_CNTS  /
                                                     LS_BATCH-CNTS ).
*        LS_SOURCE_HU-SRC_VEMNG = CEIL( LS_SOURCE_HU-SRC_VEMNG ).
    ENDCASE.

    LS_SOURCE_HU-SRC_CNTS = LS_BATCH-SRC_CNTS.
    LS_SOURCE_HU-DES_CNTS = LS_BATCH-CNTS - LS_SOURCE_HU-SRC_CNTS.
    LS_SOURCE_HU-DES_VEMNG = LS_BATCH-BAT_VEMNG - LS_SOURCE_HU-SRC_VEMNG.

    IF NOT LS_SOURCE_HU-SRC_CNTS = LS_SOURCE_HU-CNTS.
      IF NOT LS_SOURCE_HU-SRC_CNTS IS INITIAL.
        LS_SOURCE_HU-UPDATE = ZWMPP_GC_X.     "'X'
* Update the destination handling unit details.
      ENDIF.
    ENDIF.

    MODIFY ME->GT_SOURCE_HU FROM LS_SOURCE_HU INDEX SY-TABIX.
    CLEAR : LS_SOURCE_HU,
            LS_BATCH.
  ENDLOOP.
ENDMETHOD.


METHOD SET_SOURCE_HU_CHILD_REL .
  IF NOT IT_SR_CHILD_RELATION[] IS INITIAL.
    ME->GT_SR_CHILD_RELATION[] = IT_SR_CHILD_RELATION[].
  ENDIF.
  IF NOT IT_SR_HU_VEPO[] IS INITIAL.
    ME->GT_HU_ITEM[] = IT_SR_HU_VEPO[].
  ENDIF.
  IF NOT IV_HU_NESTED IS INITIAL.
    ME->GV_SOURCE_NESTED_FLAG = IV_HU_NESTED.
  ENDIF.
ENDMETHOD.


METHOD UNLOCK_HANDLING_UNIT .
  CALL FUNCTION 'DEQUEUE_EVVEKPE'
   EXPORTING
*     MODE_VEKP       = 'E'
*     MANDT           = SY-MANDT
     VENUM           = IV_VENUM
*     X_VENUM         = ' '
*     _SCOPE          = '3'
*     _SYNCHRON       = ' '
*     _COLLECT        = ' '
            .

ENDMETHOD.


method unlock_hudat_entry .
  call function 'DEQUEUE_EZZDL_WM_HUDAT'
   exporting
*     MODE_ZDL_WM_HUDAT       = 'E'
*     MANDT                   = SY-MANDT
     pexidv                  = iv_parent
     cexidv                  = iv_child
*     MATNR                   = IV_MATNR
*     CHARG                   = IV_CHARG
*     X_PARENT                = ' '
*     X_CHILD                 = ' '
*     X_MATNR                 = ' '
*     X_CHARG                 = ' '
*     _SCOPE                  = '3'
*     _SYNCHRON               = ' '
*     _COLLECT                = ' '
            .

endmethod.


METHOD UNPACK_HANDLING_UNIT .
  CONSTANTS :  C_923  TYPE LGTYP VALUE'923',
               C_PACK_BIN TYPE LGPLA VALUE 'PACK.BIN' .
* structure to hold storage Bin information
  DATA: BEGIN OF LS_LAGP,
         LGNUM  TYPE  LGNUM,
         LGTYP  TYPE LGTYP,
         LGPLA  TYPE LGPLA,
         SKZUA  TYPE LAGP_SKZUA,
         SKZUE   TYPE LAGP_SKZUE,
         SKZSI TYPE LAGP_SKZSI,
       END OF LS_LAGP.
  DATA : LV_MSG             TYPE SYMSGV,
         LV_CNTS_FLAG       TYPE C,
         LS_BAL_S_MSG       TYPE BAL_S_MSG,
         LS_HU_ITEM         TYPE VEPO,
         LS_MM_DATA         TYPE HUM_PLANT_STLOC,
         LS_HU_UNPACK_ITEMS TYPE HUITEM_UNPACK,
         LS_FROM_HU_ID      TYPE HUITEM_FROM,
         LV_ITEM_NO         TYPE HUITEM_UNPACK-UNPACK_POSNR,
         LS_UNPACK_HU_INT   TYPE HUM_VENUM,
         LS_UNPACK_HU_EXT   TYPE HUM_EXIDV,
         LT_UNPACK_HU_INT   TYPE HUM_VENUM_T,
         LT_UNPACK_HU_EXT   TYPE HUM_EXIDV_T,
         LT_HU_MESSAGES     TYPE HUITEM_MESSAGES_T,
         LS_HU_MESSAGES     TYPE HUITEM_MESSAGES,
         LS_HU_REF_DOC      TYPE HUM_OBJECT,
         LT_VEPO            TYPE STANDARD TABLE OF VEPO,
         LS_BAL_MSG         TYPE BAL_S_MSG,
         LV_MSGTYP          TYPE SYMSGTY,
         LS_SOURCE_HU       TYPE ZWMPP_TYP_S_HU,
         LS_LEIN            TYPE LEIN,
         LV_MBLNR           TYPE MBLNR,
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGID         TYPE SYMSGID,
        LV_MSGNO         TYPE SYMSGNO,
        LV_MSGV1         TYPE SYMSGV,
        LV_MSGV2         TYPE SYMSGV,
        LV_MSGV3         TYPE SYMSGV,
        LV_MSGV4         TYPE SYMSGV.
* End   of Changes by VBHAGAV on 04/28/2009

  DATA: LREF_PICK_PALLET TYPE REF TO ZCX_U01339_PICK_PALLET.
* Need to create Transfer order in case the handling unit that need to
* be unpacked is not in the packing area ( Storage type : c_923
* Storage Bin : c_PACK_BIN )
*  TRY.
  CALL METHOD ZCL_U01339_PICK_PALLET=>GET_STORAGE_UNIT_DETAILS
    EXPORTING
      IV_EXIDV = IS_VEKP-EXIDV
    IMPORTING
      EV_LEIN  = LS_LEIN.
*   CATCH ZCX_U01339_PICK_PALLET .
*  ENDTRY.

  IF LS_LEIN-LGTYP = '923' AND
     LS_LEIN-LGPLA = 'PACK.BIN'.    " C_PACK_BIN.

* Unpack the original HU which was entered on the first screen.
    CALL FUNCTION 'HU_PACKING_REFRESH'.
    CALL FUNCTION 'SERIAL_INTTAB_REFRESH' .               "  HP_412559

    IF NOT IT_VEPO[] IS INITIAL.
      LT_VEPO[] = IT_VEPO[].
*    ELSE.
*      APPEND LINES OF ME->GT_HU_ITEM TO LT_VEPO.
    ENDIF.

    LOOP AT LT_VEPO INTO LS_HU_ITEM.

      LV_ITEM_NO = LV_ITEM_NO + 1.

      LS_UNPACK_HU_INT-VENUM = IS_VEKP-VENUM.
      APPEND LS_UNPACK_HU_INT TO LT_UNPACK_HU_INT.
      CLEAR LS_UNPACK_HU_INT.

      LS_UNPACK_HU_EXT-EXIDV = IS_VEKP-EXIDV.
      APPEND LS_UNPACK_HU_EXT TO LT_UNPACK_HU_EXT.
      CLEAR LS_UNPACK_HU_EXT.

      LS_MM_DATA-PLANT                = IS_VEKP-WERKS.                 "Plant
      LS_HU_UNPACK_ITEMS-ITEM_NUMBER  = LS_HU_ITEM-VEPOS.              "LV_ITEM_NO.
      LS_HU_UNPACK_ITEMS-UNPACK_BELNR = LS_HU_ITEM-VBELN.
      LS_HU_UNPACK_ITEMS-UNPACK_POSNR = LS_HU_ITEM-POSNR.
      LS_HU_UNPACK_ITEMS-MATNR        = LS_HU_ITEM-MATNR.         "Material
      LS_HU_UNPACK_ITEMS-CHARG        = LS_HU_ITEM-CHARG.         "Batch
      LS_HU_UNPACK_ITEMS-QUANTITY     = LS_HU_ITEM-VEMNG.         "Qty
      LS_HU_UNPACK_ITEMS-UNPACK_BELNR = LS_HU_ITEM-VBELN.
      LS_HU_UNPACK_ITEMS-UNPACK_POSNR = LS_HU_ITEM-POSNR.
      LS_HU_UNPACK_ITEMS-WERKS        = LS_HU_ITEM-WERKS.
      LS_HU_UNPACK_ITEMS-VELIN        = LS_HU_ITEM-VELIN.

      LS_FROM_HU_ID-VENUM = IS_VEKP-VENUM.
      LS_FROM_HU_ID-EXIDV = IS_VEKP-EXIDV.
      REFRESH LT_HU_MESSAGES.
* Unpack the handling unit batch by batch calling standard SAP function module.
      CALL FUNCTION 'UNPACK_HANDLING_UNIT'
        EXPORTING
          I_REF_DOC         = LS_HU_REF_DOC
          I_MM_DATA         = LS_MM_DATA
          I_HU_INTERNAL     = LT_UNPACK_HU_INT[]
          I_HU_EXTERNAL     = LT_UNPACK_HU_EXT[]
          I_FROM_HU_ID      = LS_FROM_HU_ID
          I_HU_UNPACK_ITEMS = LS_HU_UNPACK_ITEMS
        IMPORTING
          O_MESSAGES        = LT_HU_MESSAGES[]
        EXCEPTIONS
          INPUT_MISSING     = 01
          INPUT_ERROR       = 02
          NOT_POSSIBLE      = 03
          NOT_UNPACKED      = 04
          FATAL_ERROR       = 05
          ERROR_MESSAGE     = 99.
      IF SY-SUBRC = 0.
* If Unpacking is successful, then raise a success message.
* Write a message to the Application Log and Commit the work.
        CLEAR LV_MBLNR.
        LOOP AT LT_HU_MESSAGES INTO LS_HU_MESSAGES
                    WHERE MSGID = 'HUGENERAL'
                      AND MSGTY = ZWMPP_GC_S
                      AND MSGNO = '309'.
          IF NOT LS_HU_MESSAGES-MSGV1 IS INITIAL.
            LV_MBLNR = LS_HU_MESSAGES-MSGV1.
            EXIT.
          ENDIF.
        ENDLOOP.
        CONCATENATE IS_VEKP-EXIDV
                    ':Unpacked'(I06) LS_HU_ITEM-CHARG
                    'Mat.Doc'(I07) LV_MBLNR
                    INTO
                    LV_MSG SEPARATED BY SPACE.
        LV_MSGTYP = ZWMPP_GC_S.
        COMMIT WORK AND WAIT.
      ELSE.
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGID = SY-MSGID.
        LV_MSGNO = SY-MSGNO.
        LV_MSGV1 = SY-MSGV1.
        LV_MSGV2 = SY-MSGV2.
        LV_MSGV3 = SY-MSGV3.
        LV_MSGV4 = SY-MSGV4.
* End   of Changes by VBHAGAV on 04/29/2009
        CLEAR LV_MSG.
** capture the error message
*        CALL FUNCTION 'FORMAT_MESSAGE'
*          EXPORTING
*            ID        = SY-MSGID
*            LANG      = SY-LANGU
*            NO        = SY-MSGNO
*            V1        = SY-MSGV1
*            V2        = SY-MSGV2
*            V3        = SY-MSGV3
*            V4        = SY-MSGV4
*          IMPORTING
*            MSG       = LV_MSG
*          EXCEPTIONS
*            NOT_FOUND = 1
*            OTHERS    = 2.
*        IF SY-SUBRC <> 0.
** MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
**         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
*        ENDIF.
        CASE SY-SUBRC.
          WHEN '01'.
            CONCATENATE IS_VEKP-EXIDV ':' 'Unpack failed. Input missing' INTO LV_MSG SEPARATED BY SPACE.
          WHEN '02'.
            CONCATENATE IS_VEKP-EXIDV  ':' 'Unpack failed. Input error' INTO LV_MSG SEPARATED BY SPACE.
          WHEN '03'.
            CONCATENATE IS_VEKP-EXIDV  ':' 'Unpack failed. Unpack not possible' INTO LV_MSG SEPARATED BY SPACE.
          WHEN '04'.
            CONCATENATE IS_VEKP-EXIDV  ':' 'Unpack failed.' INTO LV_MSG SEPARATED BY SPACE.
          WHEN '05'.
            CONCATENATE IS_VEKP-EXIDV  ':' 'Unpack failed. Input missing' INTO LV_MSG SEPARATED BY SPACE.
          WHEN OTHERS.
            CONCATENATE IS_VEKP-EXIDV  ':' 'Unpack failed'  INTO LV_MSG SEPARATED BY SPACE.
        ENDCASE.
        LV_MSGTYP = ZWMPP_GC_E.
        ROLLBACK WORK.
      ENDIF.

* Set the Message
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MSGV1        = LV_MSG
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
          IV_MESSAGE_TYPE = LV_MSGTYP
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
      IF NOT LS_BAL_MSG IS INITIAL.
*        APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
        APPEND LS_BAL_MSG TO ET_RETURN.
        CLEAR : LS_BAL_MSG.
      ENDIF.
      IF LV_MSGTYP = ZWMPP_GC_E.
* Start of Changes by VBHAGAV on 04/29/2009
        CLEAR LS_BAL_MSG.
* If Unpacking fails, then also Set the Standard Message
        CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
          EXPORTING
            IV_MSGV1        = LV_MSGV1
            IV_MSGV2        = LV_MSGV2
            IV_MSGV3        = LV_MSGV3
            IV_MSGV4        = LV_MSGV4
            IV_MSGID        = LV_MSGID
            IV_MSGNO        = LV_MSGNO
            IV_MESSAGE_TYPE = LV_MSGTYP
          IMPORTING
            ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
        IF NOT LS_BAL_MSG IS INITIAL.
*        APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
          APPEND LS_BAL_MSG TO ET_RETURN.
          CLEAR : LS_BAL_MSG.
        ENDIF.
* End   of Changes by VBHAGAV on 04/29/2009
        EXIT.
      ENDIF.
    ENDLOOP.

** Check if whether the Source HU needs to be packed with atleast one
** Batch or not.
*    CLEAR LV_CNTS_FLAG.
*    LOOP AT ME->GT_SOURCE_HU INTO LS_SOURCE_HU.
*      IF NOT LS_SOURCE_HU-SRC_CNTS IS INITIAL.
*        LV_CNTS_FLAG = ZWMPP_GC_X.        "'X'.
*        EXIT.
*      ENDIF.
*    ENDLOOP.
* If unpack is Successful, then check if any batch exists in the HU. If no batch
* is associated with the HU, the delete HU.
    IF LV_MSGTYP = ZWMPP_GC_S AND     "'S'
       NOT IV_HU_DELETE IS INITIAL.     " LV_CNTS_FLAG IS INITIAL.

      TRY.
          CALL METHOD DELETE_HU
            EXPORTING
              IV_EXIDV  = IS_VEKP-EXIDV
            IMPORTING
              ET_RETURN = ET_RETURN.
        CATCH ZCX_U01339_PICK_PALLET INTO LREF_PICK_PALLET.
      ENDTRY.
* if Delete failed, then raise exception
      IF NOT LREF_PICK_PALLET IS INITIAL.
        RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
          EXPORTING
            TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_DELETE_ERROR
*      PREVIOUS =
            .
      ELSE.
* If Source Pallet is successfully deleted, then return the delete success
* flag
        EV_PALLET_DELETED = ZWMPP_GC_X.
      ENDIF.

    ELSEIF LV_MSGTYP = ZWMPP_GC_E.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
        EXPORTING
          TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_UNPACK_ERROR
*          PREVIOUS =
          .
    ENDIF.


  ELSE.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID =  ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_STOLOC_UNPAK_ERR
*    PREVIOUS =
        .

  ENDIF.
ENDMETHOD.


METHOD UNPACK_NESTED_SOURE_HU .

  CONSTANTS :  C_923  TYPE LGTYP VALUE'923',
             C_PACK_BIN TYPE LGPLA VALUE 'PACK.BIN' .
* structure to hold storage Bin information
  DATA: BEGIN OF LS_LAGP,
         LGNUM  TYPE  LGNUM,
         LGTYP  TYPE LGTYP,
         LGPLA  TYPE LGPLA,
         SKZUA  TYPE LAGP_SKZUA,
         SKZUE   TYPE LAGP_SKZUE,
         SKZSI TYPE LAGP_SKZSI,
       END OF LS_LAGP.
  DATA : LV_MSG             TYPE SYMSGV,
         LV_CNTS_FLAG       TYPE C,
         LS_BAL_S_MSG       TYPE BAL_S_MSG,
         LS_HU_ITEM         TYPE VEPOVB,
         LS_VEPO_TEMP       TYPE VEPOVB,
         LS_MM_DATA         TYPE HUM_PLANT_STLOC,
         LS_HU_UNPACK_ITEMS TYPE HUITEM_UNPACK,
         LS_FROM_HU_ID      TYPE HUITEM_FROM,
         LV_ITEM_NO         TYPE HUITEM_UNPACK-UNPACK_POSNR,
         LS_UNPACK_HU_INT   TYPE HUM_VENUM,
         LS_UNPACK_HU_EXT   TYPE HUM_EXIDV,
         LT_UNPACK_HU_INT   TYPE HUM_VENUM_T,
         LT_UNPACK_HU_EXT   TYPE HUM_EXIDV_T,
         LT_HU_MESSAGES     TYPE HUITEM_MESSAGES_T,
         LS_HU_MESSAGES     TYPE HUITEM_MESSAGES,
         LS_HU_REF_DOC      TYPE HUM_OBJECT,
         LT_VEPO            TYPE HUM_HU_ITEM_T,
         LS_BAL_MSG         TYPE BAL_S_MSG,
         LV_MSGTYP          TYPE SYMSGTY,
         LS_SOURCE_HU       TYPE ZWMPP_TYP_S_HU,
         LS_LEIN            TYPE LEIN,
         LV_MBLNR           TYPE MBLNR,
* Start of Changes by VBHAGAV on 04/28/2009
        LV_MSGID         TYPE SYMSGID,
        LV_MSGNO         TYPE SYMSGNO,
        LV_MSGV1         TYPE SYMSGV,
        LV_MSGV2         TYPE SYMSGV,
        LV_MSGV3         TYPE SYMSGV,
        LV_MSGV4         TYPE SYMSGV,
        LV_SUBRC         TYPE SY-SUBRC.
* End   of Changes by VBHAGAV on 04/28/2009

  DATA: LREF_PICK_PALLET TYPE REF TO ZCX_U01339_PICK_PALLET,
        LS_BAPIRET2      TYPE BAPIRET2.
  DATA: LT_SUB_HU_ITEM TYPE STANDARD TABLE OF VEPO,
        LT_SUB_HU_HEAD TYPE STANDARD TABLE OF VEKP,
        LS_SUB_HU_ITEM TYPE VEPO,
        LS_SUB_HU_HEAD TYPE VEKP,
        LT_HUS         TYPE HUM_EXIDV_T,
        LS_HUS         TYPE HUM_EXIDV,
        LT_HEADER      TYPE HUM_HU_HEADER_T,
        LS_HEADER      TYPE VEKP.
* Need to create Transfer order in case the handling unit that need to
* be unpacked is not in the packing area ( Storage type : c_923
* Storage Bin : c_PACK_BIN )
* Unpack the original HU which was entered on the first screen.
  CALL FUNCTION 'HU_PACKING_REFRESH'.
  CALL FUNCTION 'SERIAL_INTTAB_REFRESH' .

  LOOP AT IT_PARENT_HU_ITEMS INTO LS_HU_ITEM.   " WHERE VELIN = '1'.
    CLEAR : LS_UNPACK_HU_INT,
            LS_UNPACK_HU_EXT,
            LS_MM_DATA,
            LS_HU_UNPACK_ITEMS,
            LS_FROM_HU_ID,
              LS_HEADER.
    REFRESH : LT_UNPACK_HU_INT,
              LT_UNPACK_HU_EXT,
              LT_HU_MESSAGES.


    READ TABLE IT_CHILD_HU_HEADER INTO LS_HEADER WITH KEY VENUM = LS_HU_ITEM-UNVEL.
    IF SY-SUBRC = 0.
      LS_UNPACK_HU_INT-VENUM = LS_HEADER-VENUM.
      APPEND LS_UNPACK_HU_INT TO LT_UNPACK_HU_INT.
      CLEAR LS_UNPACK_HU_INT.

      LS_UNPACK_HU_EXT-EXIDV = LS_HEADER-EXIDV.
      APPEND LS_UNPACK_HU_EXT TO LT_UNPACK_HU_EXT.
      CLEAR : LS_UNPACK_HU_EXT,
              LS_VEPO_TEMP.

      LV_ITEM_NO = LS_HU_ITEM-VEPOS.
      LS_HU_UNPACK_ITEMS-ITEM_NUMBER  = LV_ITEM_NO.
      LS_HU_UNPACK_ITEMS-UNPACK_VENUM = LS_HEADER-VENUM.
      LS_HU_UNPACK_ITEMS-UNPACK_EXIDV = LS_HEADER-EXIDV.
      LS_HU_UNPACK_ITEMS-VELIN        = '3'.
    ENDIF.

    LS_FROM_HU_ID-VENUM = IS_PARENT_HU_HEADER-VENUM.
    LS_FROM_HU_ID-EXIDV = IS_PARENT_HU_HEADER-EXIDV.
    LS_MM_DATA-PLANT    = IS_PARENT_HU_HEADER-WERKS.

    LS_UNPACK_HU_INT-VENUM = IS_PARENT_HU_HEADER-VENUM.
    APPEND LS_UNPACK_HU_INT TO LT_UNPACK_HU_INT.
    CLEAR LS_UNPACK_HU_INT.

    LS_UNPACK_HU_EXT-EXIDV = IS_PARENT_HU_HEADER-EXIDV.
    APPEND LS_UNPACK_HU_EXT TO LT_UNPACK_HU_EXT.
    CLEAR LS_UNPACK_HU_EXT.

* Unpack the handling unit batch by batch calling standard SAP function module.
    CALL FUNCTION 'UNPACK_HANDLING_UNIT'
      EXPORTING
        I_REF_DOC         = LS_HU_REF_DOC
        I_MM_DATA         = LS_MM_DATA
        I_HU_INTERNAL     = LT_UNPACK_HU_INT[]
        I_HU_EXTERNAL     = LT_UNPACK_HU_EXT[]
        I_FROM_HU_ID      = LS_FROM_HU_ID
        I_HU_UNPACK_ITEMS = LS_HU_UNPACK_ITEMS
      IMPORTING
        O_MESSAGES        = LT_HU_MESSAGES[]
      EXCEPTIONS
        INPUT_MISSING     = 01
        INPUT_ERROR       = 02
        NOT_POSSIBLE      = 03
        NOT_UNPACKED      = 04
        FATAL_ERROR       = 05
        ERROR_MESSAGE     = 99.
    IF SY-SUBRC = 0.
* If Unpacking is successful, then raise a success message.
* Write a message to the Application Log and Commit the work.
      CLEAR LV_MBLNR.
      LOOP AT LT_HU_MESSAGES INTO LS_HU_MESSAGES
                  WHERE MSGID = 'HUGENERAL'
                    AND MSGTY = 'S'
                    AND MSGNO = '308'.
        IF NOT LS_HU_MESSAGES-MSGV1 IS INITIAL.
          LV_MBLNR = LS_HU_MESSAGES-MSGV1.
          EXIT.
        ENDIF.
      ENDLOOP.
      CONCATENATE IS_PARENT_HU_HEADER-EXIDV
                  ':Unpacked'(I06) LS_HU_ITEM-UNVEL
                  'TO'(I30) LV_MBLNR
                  INTO
                  LV_MSG SEPARATED BY SPACE.
      LV_MSGTYP = ZWMPP_GC_S.
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MESSAGE_TYPE = LV_MSGTYP
          IV_MSGV1        = LV_MSG
*          IV_MSGV2        =
*          IV_MSGV3        =
*          IV_MSGV4        =
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
*          IV_MSGNO        =
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_MSG.
      APPEND LS_BAL_MSG TO ET_RETURN.
      CLEAR LS_BAL_MSG.
      COMMIT WORK AND WAIT.
    ELSE.
      LV_SUBRC = SY-SUBRC.
* Start of Changes by VBHAGAV on 04/28/2009
* Capture the messages
      CLEAR : LV_MSGNO,
              LV_MSGID,
              LV_MSGV1,
              LV_MSGV2,
              LV_MSGV3,
              LV_MSGV4.
      LV_MSGID = SY-MSGID.
      LV_MSGNO = SY-MSGNO.
      LV_MSGV1 = SY-MSGV1.
      LV_MSGV2 = SY-MSGV2.
      LV_MSGV3 = SY-MSGV3.
      LV_MSGV4 = SY-MSGV4.
* End   of Changes by VBHAGAV on 04/29/2009

      CASE LV_SUBRC.
        WHEN '01'.
          CONCATENATE IS_PARENT_HU_HEADER-EXIDV ':' 'Unpack failed. Input missing' INTO LV_MSG SEPARATED BY SPACE.
        WHEN '02'.
          CONCATENATE IS_PARENT_HU_HEADER-EXIDV  ':' 'Unpack failed. Input error' INTO LV_MSG SEPARATED BY SPACE.
        WHEN '03'.
          CONCATENATE IS_PARENT_HU_HEADER-EXIDV  ':' 'Unpack failed. Unpack not possible' INTO LV_MSG SEPARATED BY SPACE.
        WHEN '04'.
          CONCATENATE IS_PARENT_HU_HEADER-EXIDV  ':' 'Unpack failed.' INTO LV_MSG SEPARATED BY SPACE.
        WHEN '05'.
          CONCATENATE IS_PARENT_HU_HEADER-EXIDV  ':' 'Unpack failed. Input missing' INTO LV_MSG SEPARATED BY SPACE.
        WHEN OTHERS.
          CONCATENATE IS_PARENT_HU_HEADER-EXIDV  ':' 'Unpack failed'  INTO LV_MSG SEPARATED BY SPACE.
      ENDCASE.
      LV_MSGTYP = ZWMPP_GC_E.

      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MESSAGE_TYPE = LV_MSGTYP
          IV_MSGV1        = LV_MSG
*          IV_MSGV2        =
*          IV_MSGV3        =
*          IV_MSGV4        =
          IV_MSGID        = ZWMPP_DL_WM
          IV_MSGNO        = ZWMPP_GC_000
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_MSG.
      APPEND LS_BAL_MSG TO ET_RETURN.
      CLEAR LS_BAL_MSG.

* Start of Changes by VBHAGAV on 04/29/2009
* If Unpacking fails, then also Set the Standard Message
      CALL METHOD ZCL_U01339_PICK_PALLET=>SET_MESSAGE_BUFFER
        EXPORTING
          IV_MSGV1        = LV_MSGV1
          IV_MSGV2        = LV_MSGV2
          IV_MSGV3        = LV_MSGV3
          IV_MSGV4        = LV_MSGV4
          IV_MSGID        = LV_MSGID
          IV_MSGNO        = LV_MSGNO
          IV_MESSAGE_TYPE = LV_MSGTYP
        IMPORTING
          ES_BAL_S_MSG    = LS_BAL_MSG.
* Write the message to the application log
      IF NOT LS_BAL_MSG IS INITIAL.
*        APPEND LS_BAL_MSG TO ME->GT_LOG_MSG.
        APPEND LS_BAL_MSG TO ET_RETURN.
        CLEAR : LS_BAL_MSG.
      ENDIF.
* End   of Changes by VBHAGAV on 04/29/2009

      ROLLBACK WORK.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
        EXPORTING
          TEXTID =    ZCX_U01339_PICK_PALLET=>ZCX_U01339_HU_UNPACK_ERROR
*          PREVIOUS =
          .
    ENDIF.
    CLEAR LS_HU_ITEM.
  ENDLOOP.


ENDMETHOD.


METHOD UPDATE_HUDATE .
  DATA: LREF_ERROR TYPE REF TO ZCX_U01339_PICK_PALLET.
  DATA: LS_RETURN  TYPE BAL_S_MSG,
        LS_HUDAT   TYPE ZDL_WM_HUDAT.

* Lock the HUDAT table
  LOOP AT IT_HUDAT INTO LS_HUDAT.
    TRY.
        CALL METHOD ZCL_U01339_PICK_PALLET=>LOCK_HUDAT_ENTRY
          EXPORTING
            IV_PARENT = LS_HUDAT-PEXIDV
            IV_CHILD  = LS_HUDAT-CEXIDV
            IV_MATNR  = LS_HUDAT-MATNR
            IV_CHARG  = LS_HUDAT-CHARG.
      CATCH ZCX_U01339_PICK_PALLET INTO LREF_ERROR.
    ENDTRY.
  ENDLOOP.
  IF LREF_ERROR IS INITIAL.
    CASE IV_UPDATE_MODE.
* When Insert
      WHEN ZWMPP_GC_I.

        INSERT ZDL_WM_HUDAT FROM TABLE IT_HUDAT.
        IF SY-SUBRC = 0.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_S.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT insert Successful'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
              LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ELSE.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_E.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT insert failed'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
              LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ENDIF.
* When Modify
      WHEN ZWMPP_GC_M.
        MODIFY ZDL_WM_HUDAT FROM TABLE IT_HUDAT.
        IF SY-SUBRC = 0.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_S.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT update Successful'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
              LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ELSE.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_E.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT update failed'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
              LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ENDIF.
* When Update
      WHEN ZWMPP_GC_U.
        UPDATE ZDL_WM_HUDAT FROM TABLE IT_HUDAT.
        IF SY-SUBRC = 0.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_S.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT update Successful'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
            LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ELSE.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_E.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT update failed'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
            LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ENDIF.


* When Delete
      WHEN ZWMPP_GC_D.
        DELETE ZDL_WM_HUDAT FROM TABLE IT_HUDAT.
        IF SY-SUBRC = 0.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_S.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.
            LS_RETURN-MSGV1 = 'HUDAT delete Successful'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
            LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
*          append ls_return to et_return.
*          clear ls_return.
        ELSE.
          LOOP AT IT_HUDAT INTO LS_HUDAT.
            LS_RETURN-MSGTY = ZWMPP_GC_E.
            LS_RETURN-MSGID = ZWMPP_DL_WM.
            LS_RETURN-MSGNO = ZWMPP_GC_000.

            LS_RETURN-MSGV1 = 'HUDAT delete failed'.
            CONCATENATE LS_HUDAT-PEXIDV '/' LS_HUDAT-CEXIDV INTO
            LS_RETURN-MSGV2.
            APPEND LS_RETURN TO ET_RETURN.
            CLEAR LS_RETURN.
          ENDLOOP.
        ENDIF.
    ENDCASE.
  ELSE.

    LS_RETURN-MSGTY = ZWMPP_GC_E.
    LS_RETURN-MSGID = ZWMPP_DL_WM.
    LS_RETURN-MSGNO = ZWMPP_GC_000.
    LS_RETURN-MSGV1 = 'HUDAT lock error'.
    APPEND LS_RETURN TO ET_RETURN.
  ENDIF.
*  ES_RETURN = LS_RETURN.
* Unlock the HUDAT table
  LOOP AT IT_HUDAT INTO LS_HUDAT.
    CALL METHOD ZCL_U01339_PICK_PALLET=>UNLOCK_HUDAT_ENTRY
      EXPORTING
        IV_PARENT = LS_HUDAT-PEXIDV
        IV_CHILD  = LS_HUDAT-CEXIDV
        IV_MATNR  = LS_HUDAT-MATNR
        IV_CHARG  = LS_HUDAT-CHARG.
  ENDLOOP.

ENDMETHOD.


METHOD VALIDATE_HANDLING_UNIT .

* Retrieve the Handling Unit header details. Retrieve the records
* whose Handling Unit status is set either to 20(Stock at a non-HU storage location)
* or 30(Stock at HU storage location) and whose packing object status is not 05 or 06
* (Non-Assigned Handling Unit) or 12 (Non-Assigned Handling Unit).

*TRY.
  CALL METHOD ZCL_U01339_PICK_PALLET=>GET_HU_HEADER_DETAILS
    EXPORTING
      IV_EXIDV               = IV_EXIDV
*    IV_VENUM               =
      IV_LGNUM               = IV_LGNUM
    IMPORTING
      EV_VEKP                = EV_VEKP.
* CATCH ZCX_U01339_PICK_PALLET .
*ENDTRY.
  IF NOT EV_VEKP IS INITIAL.
* Retrieve the storage unit header details from LEIN table for the given Handling Unit.
* raise an error message if no details are found.
*    TRY.
    CALL METHOD ZCL_U01339_PICK_PALLET=>GET_STORAGE_UNIT_DETAILS
      EXPORTING
        IV_EXIDV = IV_EXIDV
      IMPORTING
        EV_LEIN  = EV_LEIN.
*     CATCH ZCX_U01339_PICK_PALLET .
*    ENDTRY.
  ENDIF.


ENDMETHOD.


method validate_shpmt_del_whs .
  data: lt_ship_delivery  type tt_ship_delivery,
        lt_delivery       type standard table of likp.
  data: ls_ship_delivery  type typ_ship_delivery,
        ls_delivery       type likp.
* Retrieve the Shipment and delivery details
  select a~tknum
         b~tpnum
         b~vbeln
         a~tplst
         into table lt_ship_delivery
    from vttk as a inner join vttp as b
    on a~tknum = b~tknum
    where a~tknum = iv_tknum.
  if sy-subrc = 0.
* Capture Transportation planning point.
    clear ls_ship_delivery.
    read table lt_ship_delivery into ls_ship_delivery index 1.
    ev_tplst = ls_ship_delivery-tplst.

* Validate the delivery aganist the Warehouse number
    select vbeln
           lgnum
           kunnr
        from likp into corresponding fields of table lt_delivery
      for all entries in it_del_item
      where vbeln = it_del_item-vbeln
        and lgnum = iv_lgnum.
    if sy-subrc = 0.
      loop at lt_delivery into ls_delivery.
* Capture the Ship-To party
        ev_kunnr = ls_delivery-kunnr.
        read table lt_ship_delivery into ls_ship_delivery with key vbeln = ls_delivery-vbeln.
        if sy-subrc <> 0.
* Raise exception
          raise exception type zcx_u01339_pick_pallet
            exporting
              textid = zcx_u01339_pick_pallet=>zcx_u01339_ship_del_err.
        endif.
      endloop.
    endif.
  else.
* raise exception
         raise exception type zcx_u01339_pick_pallet
           exporting
             textid = zcx_u01339_pick_pallet=>zcx_u01339_ship_del_err.
  endif.

endmethod.


METHOD VALIDATE_STORAGE_BIN .

  DATA: LS_LAGP   TYPE LAGP,        "ZWMPP_TYP_LAGP,
        LV_MSG    TYPE SYMSGV,
        LV_MSGTYP TYPE SYMSGTY.

  SELECT  *
     INTO LS_LAGP
     FROM LAGP UP TO 1 ROWS
     WHERE LGNUM = IV_LGNUM
       AND LGPLA = IV_LGPLA.
  ENDSELECT.
  IF SY-SUBRC = 0.
    IF LS_LAGP-SKZUA = ZWMPP_GC_X OR
       LS_LAGP-SKZUE = ZWMPP_GC_X OR
       LS_LAGP-SKZSI = ZWMPP_GC_X.
      RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
              EXPORTING
                TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_STORAGEBIN
*    PREVIOUS =
                .
    ENDIF.
    ES_LAGP = LS_LAGP.
  ELSE.
    RAISE EXCEPTION TYPE ZCX_U01339_PICK_PALLET
      EXPORTING
        TEXTID = ZCX_U01339_PICK_PALLET=>ZCX_U01339_STORAGE_INVALID.
  ENDIF.
ENDMETHOD.


METHOD WRITE_APPLICATION_LOG .
* Multiple line Application Log Data
  DATA: LS_APPLOGHEAD   TYPE BAL_S_LOG,
        LS_MESSAGES     TYPE BAL_S_MSG,
        LV_APPLOG_EXTID TYPE ZDM_APPLOG_EXTID,
        LV_APP_FLAG     TYPE ZSP_LOWVAL.
  DATA: LT_MSG TYPE ZCA_BAL_MSG_TAB,
        LS_MSG TYPE BAL_S_MSG.

  IF NOT LT_MSG IS INITIAL.
    APPEND LINES OF IT_LOG_MSG TO LT_MSG.
  ELSE.
    APPEND LINES OF ME->GT_LOG_MSG TO LT_MSG.
  ENDIF.
* Retrieve the Number range for Application Log from ZDL_FIELDS table
  SELECT LOWVAL
         FROM ZDL_FIELDS
    INTO LV_APP_FLAG UP TO 1 ROWS
    WHERE CATEGORY = 'U01339'
      AND FIELDNAME = 'PICK_PALLET_APPLICATION_LOG'
      AND SIGN   = 'I'
      AND OPTN   = 'EQ'
      AND LOWVAL = ZWMPP_GC_X.
  ENDSELECT.
  IF SY-SUBRC <> 0.
* If no record exists in the table, then read the application log table
* to check for an error message. If an error message exists, then
* write the messages to the applicatio log
    READ TABLE LT_MSG INTO LS_MSG WITH KEY MSGTY = ZWMPP_GC_E.
    IF SY-SUBRC <> 0.
      RETURN.
    ENDIF.
  ENDIF.

  DESCRIBE  TABLE LT_MSG LINES SY-TFILL.

  CHECK SY-TFILL > 0.

  CLEAR: LV_APPLOG_EXTID.

  CONCATENATE IV_EXIDV '_'
              SY-DATUM '_'  SY-UZEIT
              INTO LV_APPLOG_EXTID.


  CLEAR: LS_APPLOGHEAD.

* Build Application logging header:
  LS_APPLOGHEAD-ALPROG    = SY-REPID.
  LS_APPLOGHEAD-ALUSER    = SY-UNAME.
  LS_APPLOGHEAD-OBJECT    = ZWMPP_APP_LOG_OBJECT.
  LS_APPLOGHEAD-SUBOBJECT = ZWMPP_APP_LOG_SUBOBJ.
  LS_APPLOGHEAD-EXTNUMBER = LV_APPLOG_EXTID.

* Open, Write to and close the Application log
  CALL FUNCTION 'Z_GEN_APP_LOG_MULT'
    EXPORTING
      IS_LOG_HEADER = LS_APPLOGHEAD
    TABLES
      IT_MESSAGES   = LT_MSG.
  IF SY-SUBRC = 0.
    REFRESH ME->GT_LOG_MSG.
  ENDIF.
ENDMETHOD.
ENDCLASS.

FUNCTION-POOL ZSD_DL_AHD.                   "MESSAGE-ID ..

Tables: ZZPRODDOC ,
        ZZCONTACT ,
        EDIDC     .

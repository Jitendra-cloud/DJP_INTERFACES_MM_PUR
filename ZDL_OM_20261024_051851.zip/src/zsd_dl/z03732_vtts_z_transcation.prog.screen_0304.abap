PROCESS BEFORE OUTPUT.
 MODULE STATUS_0304.
*
PROCESS AFTER INPUT.
CHAIN .
 FIELD: vtts-zz_a_ge_dt,
        vtts-zz_a_ge_ti,
        vtts-zz_e_pa_dt,
        vtts-zz_e_pa_ti,
        vtts-zz_l_pa_dt,
        vtts-zz_l_pa_ti.
 MODULE USER_COMMAND_0304.
 ENDCHAIN.

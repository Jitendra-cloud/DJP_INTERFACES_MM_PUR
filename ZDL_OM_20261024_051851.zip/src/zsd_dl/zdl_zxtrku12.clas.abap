class ZDL_ZXTRKU12 definition
  public
  final
  create public .

*"* public components of class ZDL_ZXTRKU12
*"* do not include other source files here!!!
public section.

  interfaces /SPE/IF_BADI_IBDLV_CONTROL .
  interfaces IF_BADI_INTERFACE .
protected section.
*"* protected components of class ZDL_ZXTRKU12
*"* do not include other source files here!!!
private section.
*"* private components of class ZDL_ZXTRKU12
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZDL_ZXTRKU12 IMPLEMENTATION.


METHOD /spe/if_badi_ibdlv_control~process_idoc_delvry03.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2005 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005                                       **
**                  by INTERNATIONAL PAPER                            **
*______________________________________________________________________*
* Programmer  : Bruce Ballehr                   Date : 09/29/2005      *
*                                                                      *
*______________________________________________________________________*

* Description : This code is for Extension E03217 - the creation of    *
* inbound idocs from outbound idocs. This code will set the corresp-   *
* onding PO items' confirmation control key to '0004' (inb deliv req)  *
* PRIOR to the inbound delivery being created. This user exit is at    *
* the beginning of the inbound delivery function module                *
* BORES_IDOC_INPUT_DESADV1.                                            *
*                                                                      *
* Change History :                                                     *
* Bruce Ballehr   09/29/2005     Transport EDV939604                   *
*                                                                      *
*                                Initial Creation                      *
*                                                                      *
* Bruce Ballehr   02/06/2006     Transport EDVK943412                  *
*                                                                      *
*                                Add DISTINCT to the SELECT on table   *
*                                EKPO so we don't get duplicate PO     *
*                                line item information when attempting *
*                                to update their confirmation control  *
*                                keys.                                 *
*                                                                      *
*                                SCENARIO: If the delivery had 3 line  *
*                                items (LIPS) from a single PO line    *
*                                item, the SELECT would retrieve 3     *
*                                duplicate lines into my work table.   *
*                                Adding the DISTINCT keyword assures   *
*                                a unique set of PO line items to pass *
*                                to the Bapi to change the confirmation*
*                                control keys.                         *
*                                                                      *
* Bruce Ballehr   03/30/2006     Transport EDVK944791                  *
*                                                                      *
*                                Make this logic available to other    *
*                                inbound idoc message types that       *
*                                create inbound deliveries.            *
*                                                                      *
* Bruce Ballehr   05/01/2006     Transport EDVK945866                  *
*                                                                      *
*                                Remove the deletion of leading 0's    *
*                                from the Outbound Delivery number. It *
*                                is not needed by APO anymore.         *
*                                                                      *
* Bruce Ballehr   07/28/2006     Transport EDVK948404                  *
*                                                                      *
*                                The BAPI_PO_CHANGE does not work if   *
*                                multiple PO's make up the Outbound    *
*                                Delivery. We need to call the Bapi    *
*                                for each PO that makes up the Outb.   *
*                                We had thought only 1 PO per Outb     *
*                                                                      *
* Bruce Ballehr   08/27/2008     Transport EDVK965485                  *
*                                                                      *
*                                Rename Idoc Logical Message from      *
*                                ZDL_NONOMDASN to ZDL_NONOMD_ASN       *
*                                Delivery. We need to call the Bapi    *
*                                for each PO that makes up the Outb.   *
*                                We had thought only 1 PO per Outb     *
*                                                                      *
* Bruce Ballehr   09/30/2010     Transport ESBK9A08WQ    TPR39438      *
*                                                                      *
*                                As of ECC 6 user exit ZXTRKU12 is not *
*                                executed anymore for the E03217       *
*                                Outbound/Inbound process for STO's.   *
*                                The ZXTRKU12 code has been moved to   *
*                                this BADI and slightly tweaked due to *
*                                slightly different object parameters  *
*                                between user exit ZXTRKU12 and this   *
*                                BADI.                                 *
* Uday Peddigari  05/28/2019     Transport E0VK9A14SJ ,Charmid:        *
*                                CD#2000001172. Create an inbound      *
*                                delivery from an outbound delivery    *
*                                idoc using delivery type LF. Update   *
*                                PO and line item in E1EDL24,E1EDL43,  *
*                               update qualif 'V' in E1EDL43 and remove*
*                               po and line item from E1EDL44 segment  *
* AMAOLE1|06/032021| Add check for message type ZDL_SYVASN & populate  *
* internal table LT_EKPO                                               *
*----------------------------------------------------------------------*

  TYPES: BEGIN OF ty_ekpo,
           ebeln TYPE ebeln,   "PO number
           ebelp TYPE ebelp,   "PO line item number
           bstae TYPE bstae,   "Conf control key
         END OF ty_ekpo.


  DATA: lt_ekpo      TYPE STANDARD TABLE OF ty_ekpo,
        ls_ekpo      TYPE ty_ekpo,
        ls_ekpo_hold TYPE ty_ekpo,

        lt_poitem    TYPE STANDARD TABLE OF bapimepoitem,  "item data
        ls_poitem    TYPE bapimepoitem,

        lt_poitemx   TYPE STANDARD TABLE OF bapimepoitemx, "item chg data
        ls_poitemx   TYPE bapimepoitemx,

        lt_return    TYPE STANDARD TABLE OF bapiret2,
        ls_return    TYPE bapiret2.


  DATA: ls_idoc_contrl TYPE edidc, "control record
        ls_idoc_data   TYPE edidd,
        ls_e1edl20     TYPE e1edl20,
        ls_e1edl41     TYPE e1edl41,
        ls_e1edl43     TYPE e1edl43,
        lv_subrc       TYPE sysubrc,
        lv_tabix       TYPE sytabix.

  "Begin of change - Upeddig - 06/28/2019 -CD#2000001172
  DATA: ls_e1edl21   TYPE e1edl21,
        ls_e1edl24   TYPE e1edl24,
        ls_e1edl44_1 TYPE e1edl44,
        lv_ebeln     TYPE ebeln,
        ls_ve1edl24  TYPE e1edl24. "MAIELY/CD#1172:9/23/2019

  FIELD-SYMBOLS: <fs_idoc_data> LIKE ls_idoc_data.
  "End of change - Upeddig - 06/28/2019 -CD#2000001172

  lv_subrc = sy-subrc.

* Access Control Rec
  READ TABLE idoc_contrl INTO ls_idoc_contrl INDEX 1.

* Only process if proper message type
  CHECK ls_idoc_contrl-mestyp = 'ZSDDESADV'   OR
        ls_idoc_contrl-mestyp = 'ZDL_VASN'    OR  "Vendor asn EDK944791
        ls_idoc_contrl-mestyp = 'ZDL_SYVASN'    OR
        ls_idoc_contrl-mestyp = 'ZDL_NONOMD_ASN' OR"IPNONOMDasnEDVK944791
        ls_idoc_contrl-mestyp = 'ZDL_PASN' OR  "Portal OMD asn EDVK944791
        ls_idoc_contrl-mestyp = 'ZDL_MTS_MTOASN'. "MTO/MTS asn EDVK944791


* Retrieve outbound delivery number E1EDL20-VBELN
  IF ls_idoc_contrl-mestyp = 'ZSDDESADV'.
    LOOP AT idoc_data INTO ls_idoc_data WHERE segnam = 'E1EDL20'.
      ls_e1edl20 = ls_idoc_data-sdata.
      lv_tabix = sy-tabix.
    ENDLOOP.

*   Retrieve PO line item info associated with the delivery that have a
*   Confirmation Control key of space.
    SELECT DISTINCT a~ebeln                    "PO number
                    a~ebelp                    "PO line item
                    a~bstae                    "Conf control key
      INTO TABLE lt_ekpo
      FROM ekpo AS a
      INNER JOIN lips AS b ON a~ebeln = b~vgbel "po num
      WHERE b~vbeln = ls_e1edl20-vbeln   "out delivery number
        AND a~bstae = space.

    "Begin of change - Upeddig - 06/28/2019 -CD#2000001172
*        DATA(lv_tabix) = sy-tabix.

    LOOP AT idoc_data INTO ls_idoc_data WHERE segnam = 'E1EDL21'.
      ls_e1edl21 = ls_idoc_data-sdata.
    ENDLOOP.
    "Begin of change - Upeddig - 06/24/2019 -CD#2000001172
    DATA(lr_matkl) = zdl_e03217_set_default_data=>get_matgrp_range( ). "MAIELY/CD#1172:9/23/2019
    ls_ve1edl24 = VALUE #( idoc_data[ segnam = 'E1EDL24' ]-sdata OPTIONAL )."MAIELY/CD#1172:9/23/2019

    IF  ls_e1edl21-lfart EQ 'LF' AND ls_ve1edl24-matkl IN lr_matkl. "MAIELY/CD#1172:9/23/2019.
      "End of change - Upeddig - 06/24/2019 -CD#2000001172
      SELECT SINGLE vgbel INTO @DATA(gv_vgbel)      "STO number
        FROM lips
        WHERE vbeln = @ls_e1edl20-vbeln.
      IF sy-subrc = 0 AND NOT gv_vgbel IS INITIAL.

        "Get the associated purchase order for delivery type LF (Outbound delivery)
        SELECT SINGLE bstkd INTO @DATA(gv_vbkd_ebeln)
           FROM vbkd
           WHERE vbeln = @gv_vgbel.
        lv_ebeln = gv_vbkd_ebeln.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = lv_ebeln
          IMPORTING
            output = lv_ebeln.

        LOOP AT idoc_data ASSIGNING <fs_idoc_data>
                WHERE segnam  =  'E1EDL24'.
          ls_e1edl24 = <fs_idoc_data>-sdata.
          ls_e1edl24-vgbel = lv_ebeln.
          ls_e1edl24-vgpos = '00001'.
*          <fs_idoc_data>-sdata+15(10) = gv_vbkd_ebeln.
          <fs_idoc_data>-sdata = ls_e1edl24.
        ENDLOOP.

        LOOP AT idoc_data  ASSIGNING <fs_idoc_data>
        WHERE segnam  = 'E1EDL43'.
          ls_e1edl43 = <fs_idoc_data>-sdata.
*          <fs_idoc_data>-segnam = 'E1EDL43'.
          ls_e1edl43-qualf = 'V'.
          ls_e1edl43-belnr = lv_ebeln.
          ls_e1edl43-posnr = ls_e1edl24-vgpos.
          <fs_idoc_data>-sdata = ls_e1edl43.
        ENDLOOP.

        LOOP AT idoc_data  ASSIGNING <fs_idoc_data>
        WHERE segnam  = 'E1EDL44_1'.
          ls_e1edl44_1 = <fs_idoc_data>-sdata.
          CLEAR ls_e1edl44_1-vbeln.
          <fs_idoc_data>-sdata = ls_e1edl44_1.
        ENDLOOP.
      ENDIF.
      "End of change - Upeddig - 06/24/2019 -CD#2000001172
    ENDIF.



  ELSEIF ls_idoc_contrl-mestyp = 'ZDL_SYVASN'.

    DATA(ls_sdata) = VALUE #( idoc_data[ segnam = 'E1EDL41'
                                   sdata+0(3) = '001' ]-sdata OPTIONAL ).
    IF ls_sdata IS NOT INITIAL.
      lv_ebeln = ls_sdata+3(10).
    ENDIF.


    IF lv_ebeln IS NOT INITIAL.
*   Retrieve PO line item info associated with the delivery that have a
*   Confirmation Control key of space.

      SELECT DISTINCT ebeln    "PO number
                      ebelp    "PO line item
                      bstae    "Conf control key
        INTO TABLE lt_ekpo
        FROM ekpo
        WHERE ebeln   = lv_ebeln      "PO number
          AND bstae   = space.
    ENDIF.

  ELSE.

*   ASN's do not have outbound deliveries so must get PO info from idoc
    LOOP AT idoc_data INTO ls_idoc_data WHERE segnam = 'E1EDL43'.
      ls_e1edl43 = ls_idoc_data-sdata.
      lv_tabix = sy-tabix.

*     Retrieve all PO's from the idoc (probably the same PO)
      IF ls_e1edl43-qualf = 'V'.  "V = PO number
        ls_ekpo-ebeln = ls_e1edl43-belnr.

*       Only add unique PO numbers to the table
        READ TABLE lt_ekpo INTO ls_ekpo WITH KEY ebeln = ls_ekpo-ebeln.
        IF sy-subrc NE 0.
          APPEND ls_ekpo TO lt_ekpo.
        ENDIF.

      ENDIF.

    ENDLOOP.

*   Retrieve PO line item info associated with the delivery that have a
*   Confirmation Control key of space.
    IF NOT lt_ekpo[] IS INITIAL.

      SELECT DISTINCT ebeln                    "PO number
                      ebelp                    "PO line item
                      bstae                    "Conf control key
        INTO TABLE lt_ekpo
        FROM ekpo
        FOR ALL ENTRIES IN lt_ekpo
        WHERE ebeln   = lt_ekpo-ebeln      "PO number
          AND bstae   = space.
    ENDIF.

  ENDIF.


* If any PO items associated with the delivery has a blank confirmation
* control key then set it to '0004' requires inbound delivery
  IF NOT lt_ekpo[] IS INITIAL.
    SORT lt_ekpo BY ebeln ebelp.

    CLEAR: lt_poitem[], lt_poitemx[].
    LOOP AT lt_ekpo INTO ls_ekpo.
      ls_ekpo_hold = ls_ekpo.

*     Populate item table
      CLEAR: ls_poitem.
      ls_poitem-po_item   = ls_ekpo-ebelp. "po line item
      ls_poitem-conf_ctrl = '0004'. "requires inbound delivery
      APPEND ls_poitem TO lt_poitem.

*     Populate item table that tells which field needs updating
      CLEAR: ls_poitemx.
      ls_poitemx-po_item   = ls_ekpo-ebelp. "po line item
      ls_poitemx-conf_ctrl = 'X'.           "change conf control field
      APPEND ls_poitemx TO lt_poitemx.

*     For each different PO that makes up the Outbound Delivery, format
*     and call the Bapi to update the PO item confirmation control keys.
      AT END OF ebeln.

*       Attempt to lock the PO to make sure it is not already locked
        DO 300 TIMES.
          CALL FUNCTION 'ENQUEUE_EMEKPOE'
            EXPORTING
              ebeln          = ls_ekpo_hold-ebeln
              ebelp          = ls_ekpo_hold-ebelp
            EXCEPTIONS
              foreign_lock   = 2
              system_failure = 3.

          IF sy-subrc = 0.
            lv_subrc = sy-subrc.
            EXIT.
          ELSE.
            WAIT UP TO 1 SECONDS.
          ENDIF.
        ENDDO.

        IF lv_subrc = 0.
*         Unlock the the PO
          CALL FUNCTION 'DEQUEUE_EMEKPOE'
            EXPORTING
              ebeln = ls_ekpo_hold-ebeln
              ebelp = ls_ekpo_hold-ebelp.
        ENDIF.

*       Change the confirmation control key for the specified po items
        CALL FUNCTION 'BAPI_PO_CHANGE'
          EXPORTING
            purchaseorder = ls_ekpo_hold-ebeln   "PO number
          TABLES
            return        = lt_return
            poitem        = lt_poitem
            poitemx       = lt_poitemx.
        IF NOT lt_return IS INITIAL.
          READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
          IF sy-subrc NE 0.
            CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
              EXPORTING
                wait   = 'X'
              IMPORTING
                return = ls_return.
          ENDIF.

*         Attempt to lock the PO. We don't want to continue w/ the inb
*         create until the PO has been updated.
          DO 300 TIMES.
            CALL FUNCTION 'ENQUEUE_EMEKPOE'
              EXPORTING
                ebeln          = ls_ekpo_hold-ebeln
                ebelp          = ls_ekpo_hold-ebelp
              EXCEPTIONS
                foreign_lock   = 2
                system_failure = 3.

            IF sy-subrc = 0.
              lv_subrc = sy-subrc.
              EXIT.
            ELSE.
              WAIT UP TO 1 SECONDS.
            ENDIF.
          ENDDO.

          IF lv_subrc = 0.
*           Unlock the the PO
            CALL FUNCTION 'DEQUEUE_EMEKPOE'
              EXPORTING
                ebeln = ls_ekpo-ebeln
                ebelp = ls_ekpo-ebelp.
          ENDIF.

        ENDIF.

        CLEAR: lt_poitem[], lt_poitemx[].
      ENDAT.

    ENDLOOP.

  ENDIF. "if not lt_ekpo[] is initial

ENDMETHOD.
ENDCLASS.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z_ZDL_GEN_UNI_TM
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z_ZDL_GEN_UNI_TM    .

  PERFORM TABLEPROC.

ENDFUNCTION.

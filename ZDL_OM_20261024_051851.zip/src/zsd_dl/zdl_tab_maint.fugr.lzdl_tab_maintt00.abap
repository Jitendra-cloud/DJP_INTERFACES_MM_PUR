*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDL_SSCC........................................*
DATA:  BEGIN OF STATUS_ZDL_SSCC                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDL_SSCC                      .
CONTROLS: TCTRL_ZDL_SSCC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDL_SSCC                      .
TABLES: ZDL_SSCC                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

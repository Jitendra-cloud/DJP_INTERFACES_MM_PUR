*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_DL_FRT_COSTTOP.               " Global Data
  INCLUDE LZSD_DL_FRT_COSTUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_DL_FRT_COSTF...               " Subprograms
* INCLUDE LZSD_DL_FRT_COSTO...               " PBO-Modules
* INCLUDE LZSD_DL_FRT_COSTI...               " PAI-Modules

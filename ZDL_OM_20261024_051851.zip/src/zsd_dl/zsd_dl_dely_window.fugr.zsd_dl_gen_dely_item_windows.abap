FUNCTION zsd_dl_gen_dely_item_windows.
*"----------------------------------------------------------------------
*"*"Global interface:
*"  TABLES
*"      IT_LIPS TYPE  SHP_LIPS_T
*"----------------------------------------------------------------------
* description: R6  U01168 delivery windows on SO deliveries
*"----------------------------------------------------------------------
* Change History:                                                      *
* ===============                                                      *
* Maureen Carter   11/09/06  (MC01) CO69438 fix bug - FOR ALL ENTRIES  *
*                                                                      *
*                                                                      *
*"----------------------------------------------------------------------
  DATA: wa_lips LIKE LINE OF it_lips,
        l_hold_tabix    LIKE sy-tabix.

  LOOP AT it_lips INTO wa_lips.
    CHECK NOT wa_lips-lfimg IS INITIAL.
    l_hold_tabix = sy-tabix.
    SELECT * INTO TABLE it_vbbe
      FROM vbbe
      WHERE vbeln = wa_lips-vgbel
        AND posnr = wa_lips-vgpos.
    CHECK sy-subrc IS INITIAL.
    PERFORM reduce_vbbe USING wa_lips.
    IF NOT it_vbbe[] IS INITIAL.                            "<<MC01
      SELECT * INTO TABLE it_vbep
         FROM vbep
          FOR ALL ENTRIES IN it_vbbe
         WHERE vbeln = it_vbbe-vbeln
           AND posnr = it_vbbe-posnr
           AND etenr = it_vbbe-etenr.
      CHECK sy-subrc IS INITIAL.
      PERFORM find_window CHANGING wa_lips.
      MODIFY it_lips FROM wa_lips INDEX l_hold_tabix.
    ENDIF.                                                  "<<MC01
  ENDLOOP.

ENDFUNCTION.
*&---------------------------------------------------------------------*
*&      Form  reduce_vbbe
*&---------------------------------------------------------------------*
* loops thru the internal table brought back from VBBE and only keeps
* the ones needed by comparing quantities.
*----------------------------------------------------------------------*
FORM reduce_vbbe   USING wa_lips LIKE LINE OF it_lips.

  DATA: wa_vbbe       LIKE LINE OF it_vbbe,
        l_requirement LIKE wa_lips-lfimg,
        l_qty         LIKE wa_lips-lfimg,
        l_uom         LIKE wa_vbbe-meins.
  l_requirement = wa_lips-brgew.
  READ TABLE it_vbbe INTO wa_vbbe INDEX 1.
  IF sy-subrc IS INITIAL.
    IF wa_vbbe-meins = wa_lips-vrkme.
      l_requirement = wa_lips-lfimg.
    ENDIF.
  ENDIF.

  LOOP AT it_vbbe INTO wa_vbbe..
    IF wa_vbbe-vmeng IS INITIAL.
      DELETE it_vbbe INDEX sy-tabix.
      CONTINUE.
    ENDIF.
    IF wa_vbbe-meins = wa_lips-vrkme OR
       wa_vbbe-meins = wa_lips-gewei.
      l_qty = wa_vbbe-vmeng.
    ELSE.
*      break cramey.
      CALL FUNCTION 'MATERIAL_UNIT_CONVERSION'
        EXPORTING
          input                = wa_vbbe-vmeng
          matnr                = wa_vbbe-matnr
          meins                = wa_vbbe-meins
          meinh                = wa_lips-gewei
        IMPORTING
          meins                = l_uom
          output               = l_qty
        EXCEPTIONS
          conversion_not_found = 1
          input_invalid        = 2
          material_not_found   = 3
          meinh_not_found      = 4
          meins_missing        = 5
          no_meinh             = 6
          output_invalid       = 7
          overflow             = 8
          OTHERS               = 9.
      CHECK sy-subrc IS INITIAL.
    ENDIF.
    IF l_requirement <= 0.
      DELETE it_vbbe INDEX sy-tabix.
    ELSE.
      l_requirement = l_requirement - l_qty.
    ENDIF.
  ENDLOOP.
ENDFORM.                    "reduce_vbbe
*&---------------------------------------------------------------------*
*&      Form  find_window
*&---------------------------------------------------------------------*
* loops thru the schedule lines and finds the earliest and latest dates
* and makes that the delivery window
*----------------------------------------------------------------------*
FORM find_window          CHANGING wa_lips LIKE LINE OF it_lips.
  CONSTANTS c_eod    TYPE i VALUE 86399.
  DATA: wa_vbep      LIKE LINE OF it_vbep,
        l_days_prior LIKE /gcds04/del_win-days_prior,
        l_days_after LIKE /gcds04/del_win-days_after,
        l_del_window LIKE wa_vbep-del_window,
        ws_datefrom  LIKE wa_lips-zz_dly_date_from,
        ws_dateto    LIKE wa_lips-zz_dly_date_to,
        l_datefrom   LIKE wa_lips-zz_dly_date_from,
        l_dateto     LIKE wa_lips-zz_dly_date_to,
        l_timefrom   LIKE wa_lips-zz_dly_time_from,
        l_timeto     LIKE wa_lips-zz_dly_time_to.

  CLEAR l_del_window.
  LOOP AT it_vbep INTO wa_vbep.
    IF NOT l_del_window = wa_vbep-del_window.
      l_del_window = wa_vbep-del_window.
      SELECT SINGLE days_prior days_after
        INTO (l_days_prior, l_days_after)
        FROM /gcds04/del_win
       WHERE del_window = l_del_window.
      CHECK sy-subrc IS INITIAL.
    ENDIF.
    ws_datefrom = wa_vbep-edatu - l_days_prior.
    ws_dateto   = wa_vbep-edatu + l_days_after.

    IF l_datefrom IS INITIAL.
      l_datefrom = ws_datefrom.
      l_dateto   = ws_dateto.
      l_timefrom = wa_vbep-hours_from.
      l_timeto   = wa_vbep-hours_to.
    ELSE.
*      take the smallest from date
      IF ws_datefrom < l_datefrom.
        l_datefrom = ws_datefrom.
      ENDIF.
*      take the latest to date
      IF ws_dateto > l_dateto.
        l_dateto = ws_dateto.
      ENDIF.
*      if appoints don't match - let the carrier decide
      IF l_timefrom <> wa_vbep-hours_from OR
         l_timeto   <> wa_vbep-hours_to.
        l_timefrom = 000000.
        l_timeto   = c_eod.
      ENDIF.
    ENDIF.
  ENDLOOP.
  IF l_timeto = 000000.
    l_timeto = c_eod.
  ENDIF.
  wa_lips-zz_dly_date_from = l_datefrom.
  wa_lips-zz_dly_date_to   = l_dateto.
  wa_lips-zz_dly_time_from = l_timefrom.
  wa_lips-zz_dly_time_to   = l_timeto.
ENDFORM.                    "find_window
************************************************************************
*                  END OF FUNCTION MODULE
************************************************************************

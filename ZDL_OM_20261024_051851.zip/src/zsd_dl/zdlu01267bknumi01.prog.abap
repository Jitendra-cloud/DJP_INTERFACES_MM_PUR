*----------------------------------------------------------------------*
***INCLUDE ZDLU01267I01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  LEAVE_TRANSACTION_0100  INPUT
*&---------------------------------------------------------------------*
*       The Cancel button is clicked (the red X)
*----------------------------------------------------------------------*
MODULE leave_transaction_0100 INPUT.

  CALL FUNCTION 'DEQUEUE_EVVEKPE'
    EXPORTING
      mode_vekp = 'E'
      mandt     = sy-mandt
      venum     = gs_zvekp-venum.

  CASE ok_code.
    WHEN 'CANC'.
      CLEAR ok_code.
      LEAVE PROGRAM.
    WHEN 'EXIT'.
      CLEAR ok_code.
      LEAVE TO SCREEN 0.
  ENDCASE.

ENDMODULE.                 " LEAVE_TRANSACTION_0100  INPUT
*eject
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       If execute, then retrieve data, validate and display
*       if no errors. Navigate back to calling program when the
*       "BACK" key is pressed.
*
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.

  ok_code = sy-ucomm.

  CASE ok_code.

* Execute button is clicked after user enters required information
    WHEN 'ONLI'.

      PERFORM retrieve_data.  "Retrieve data based on selection screen

* Make copy of db values to compare against when saving.
      gs_old_zvekp = gs_zvekp.
      CALL SCREEN '0200'.     "Call List Screen of possible batches

    WHEN 'BACK'.
      CLEAR ok_code.
      LEAVE PROGRAM.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0100  INPUT

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0200 INPUT.

  ok_code = sy-ucomm.

  CASE ok_code.

*   Set screen 0200 mode based on user's action

    WHEN 'BACK'.
      CALL FUNCTION 'DEQUEUE_EVVEKPE'
        EXPORTING
          mode_vekp = 'E'
          mandt     = sy-mandt
          venum     = gs_zvekp-venum.
      LEAVE TO SCREEN '0100'.

*   User clicked to Confirm his/her selection
    WHEN 'SAVE'.

      PERFORM validate_confirmation.
      PERFORM save_confirmation.
      CALL FUNCTION 'DEQUEUE_EVVEKPE'
        EXPORTING
          mode_vekp = 'E'
          mandt     = sy-mandt
          venum     = gs_zvekp-venum.
      CLEAR ok_code.
      LEAVE TO SCREEN '0100'.
  ENDCASE.

  PERFORM validate_confirmation.
ENDMODULE.                 " USER_COMMAND_0200  INPUT

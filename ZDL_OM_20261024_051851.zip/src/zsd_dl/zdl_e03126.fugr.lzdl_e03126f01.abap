*----------------------------------------------------------------------*
***INCLUDE LZDL_E03126F01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  GET_DUP_INFO
*&---------------------------------------------------------------------*
*       Retrieve Delivery Information based on the BOL
*----------------------------------------------------------------------*
*      -->P_BATCH  text
*----------------------------------------------------------------------*
FORM get_dup_info USING    pt_batch TYPE zdl_uniqueid_tab.

  CONSTANTS: lc_assigned_to_inbound TYPE vpobj  VALUE '03',
             " Object indicator
             lc_non_assigned        TYPE vpobj VALUE '12'.
  "Non-Assigned HU


  CLEAR: gt_likp, gt_lips, gt_vekp, gt_obj.

* Read Delivery data using bill of lading number
  SELECT vbeln           " Delivery Number
         bolnr           " Bill of landing number
    FROM likp
    INTO TABLE gt_likp
    FOR ALL ENTRIES IN pt_batch
    WHERE bolnr = pt_batch-bolnr.
  IF sy-subrc = 0.
    SORT gt_likp BY vbeln.
*   Read Delivery Item data
    SELECT vbeln
           posnr         " Delivery number
           matnr         " Material Number
           lichn         " Vendor batch
           vgbel         " Purchase Order Number
    FROM lips
    INTO TABLE gt_lips
    FOR ALL ENTRIES IN gt_likp
    WHERE vbeln = gt_likp-vbeln.
    IF sy-subrc = 0.
      SORT gt_lips BY vbeln matnr lichn.
*     Do convertion for object key
      LOOP AT gt_likp INTO gs_likp.
        CLEAR: gs_obj.
        MOVE gs_likp-vbeln TO gs_obj-object.
        APPEND gs_obj TO gt_obj.
      ENDLOOP.
*     Read Handling unit header data
      SELECT venum         " Handling Unit internal number
             exidv         " handling unit external number
             inhalt        " Vendor Unit id
             vpobj         " Object type
             vpobjkey      " Object Key
        FROM vekp
        INTO TABLE gt_vekp
        FOR ALL ENTRIES IN gt_obj
        WHERE ( vpobj = lc_assigned_to_inbound OR
                vpobj = lc_non_assigned )
          AND vpobjkey = gt_obj-object.
    ENDIF.

  ENDIF.

ENDFORM.                    " GET_DUP_INFO
*&---------------------------------------------------------------------*
*&      Form  CHECK_DUP
*&---------------------------------------------------------------------*
*       Determine if any identical BOL / Material / Vendor Batches
*       already exist in SAP. If so, we need to set flag gv_dup so that
*       we will not generate a new Batch. If a PO was passed in then
*       use that in the Duplicate check.
*----------------------------------------------------------------------*
*      <--P_GV_DUP  text
*----------------------------------------------------------------------*
FORM check_dup USING ps_batch STRUCTURE  zdl_uniqueid.

  gv_dup = gc_false.

* If a BOL was passed into this function module then proceed
  IF ps_batch-bolnr IS NOT INITIAL.
*   Determine if there are any duplicate BOL's in the system
    LOOP AT gt_likp INTO gs_likp WHERE bolnr = ps_batch-bolnr.
*     BOL is a match. Determine if the same Material / Vendor Batch
*     exists already in sap. If so we do NOT want to generate
      READ TABLE gt_lips INTO gs_lips
        WITH KEY vbeln = gs_likp-vbeln  "Delivery
                 matnr = ps_batch-matnr "Material
                 lichn = ps_batch-exidv "Vend Batch
        BINARY SEARCH.
*     If a duplicate was found then set flag and exit
      IF sy-subrc = 0.
*         Begin BCB03
*         If a PO was passed in on the table, compare it
        IF ps_batch-vgbel IS NOT INITIAL.
*           If the PO (ie from what was entered on the Manual ASN
*           screen and passed in the Table structure of this func)
*           matches the Delivery Item PO then the Vendor Batch is a
*           duplicate and we'll need to generate another SAP batch
*           instead of using the existing SAP batch that corresponds
*           to the Vendor Batch
          IF ps_batch-vgbel = gs_lips-vgbel.
            gv_dup = gc_true.
            EXIT.
          ENDIF.
        ELSE.
*           If a PO was NOT passed in on the table then the Dup check
*           only applies to the BOL / Material / Vendor Batch
          gv_dup = gc_true.
          EXIT.
        ENDIF.
*         End BCB03
      ENDIF.
    ENDLOOP.
  ENDIF.

ENDFORM.                    " CHECK_DUP
*&---------------------------------------------------------------------*
*&      Form  DETERMINE_WHETHER_TO_USE_VB
*&---------------------------------------------------------------------*
*       Determine whether to use the passed in Vendor Batch based on
*       entries in table ZDL_FIELDS.
*----------------------------------------------------------------------*
*      -->P_IT_BATCH_LIFNR  text
*      <--P_LV_USE_VB  text
*----------------------------------------------------------------------*
FORM determine_whether_to_use_vb
             USING    pv_first_two_bytes TYPE char2   "1st 2 bytes of vb
                      pv_lifnr           TYPE elifn   "Vendor
             CHANGING pv_use_vb          TYPE boolean.

  DATA: ls_zdlfields TYPE zdl_fields.

* If the relevant record found in ZDL_FIELDS then use the Vendor Batch
* passed in
  SELECT SINGLE * FROM zdl_fields INTO ls_zdlfields
    WHERE category = 'E03261_BATCH'
      AND fieldname = pv_first_two_bytes
      AND sign      = 'I'
      AND optn      = 'EQ'
      AND lowval    = pv_lifnr.
  IF sy-subrc = 0.
    pv_use_vb = gc_true.
  ENDIF.

ENDFORM.                    " DETERMINE_WHETHER_TO_USE_VB
*&---------------------------------------------------------------------*
*&      Form  Generate_unit_id
*&---------------------------------------------------------------------*
*       This routine is used to generate a sequantial number based on
*       system date.
*----------------------------------------------------------------------*
*  -->  P_WS_BATCH_NUM      Previous Batch number Stored in a table
*  <--  WS_ID               Generated new batch/unitid number
*----------------------------------------------------------------------*
FORM generate_unit_id USING    p_ws_batch_num TYPE zcharg_d
                      CHANGING ws_id.

*--------Constants Declaration-----------------------------------------*
  CONSTANTS: c_flag     TYPE char1 VALUE 'X',          " Flag value
             c_object06 TYPE nrobj VALUE 'ZDL_UNIT06',
             " Number range object
             c_object07 TYPE nrobj VALUE 'ZDL_UNITID',
             " Number range object
             c_number   TYPE nrnr  VALUE '01',         " Number sequence
             c_zz       TYPE char2 VALUE 'ZZ',         " value ZZ
             c_a        TYPE char1 VALUE 'A'.          " value A

*--------Variable Declaration------------------------------------------*
  DATA: ws_unitid   TYPE char07,                " 7 digit Sequntial number
        ws_unitid06 TYPE char6,                 " 6 digit Sequntial number
        ws_alpha    TYPE sy-abcde,              " Alphabets
        ws_offset   TYPE i,                     " Offset value
        ws_char     TYPE char1,                 " single character
        ws_flag     TYPE char1,                 " flag value
        ws_year     TYPE gjahr.                 " Year

*Clear all variables
  CLEAR: ws_unitid,
         ws_unitid06,
         ws_alpha,
         ws_offset,
         ws_char,
         ws_flag,
         ws_year.

  ws_alpha  = sy-abcde.                " Move Alphabets into variable
  ws_unitid = p_ws_batch_num+3(7).     " Move Sequential Number

*check whether the number reached maximum level or contains any
*alphabets
  IF ws_unitid+0(1) CA ws_alpha OR ws_unitid = '9999999'.

    ws_year = sy-datum+0(4).          " Move year only
*   check for current year
    IF p_ws_batch_num+2(1) <> ws_year+3(1).
      ws_flag = c_flag.
    ENDIF.
*if the year matches, call function 'NUMBER_GET_NEXT' to generate a
*sequantial number
    IF ws_flag <> c_flag.
      CALL FUNCTION 'NUMBER_GET_NEXT'
        EXPORTING
          nr_range_nr             = c_number
          object                  = c_object06
        IMPORTING
          number                  = ws_unitid06
        EXCEPTIONS
          interval_not_found      = 1
          number_range_not_intern = 2
          object_not_found        = 3
          quantity_is_0           = 4
          quantity_is_not_1       = 5
          interval_overflow       = 6
          buffer_overflow         = 7
          OTHERS                  = 8.
      IF sy-subrc = 0.
        IF ws_unitid06 = '000001'.
          IF ws_unitid = '9999999'.
            CONCATENATE c_zz ws_year+3(1) c_a ws_unitid06 INTO ws_id.
          ELSE.
            FIND  ws_unitid+0(1) IN ws_alpha MATCH OFFSET ws_offset.
            ws_offset = ws_offset + 1.
            ws_char = ws_alpha+ws_offset(1).
            CONCATENATE c_zz ws_year+3(1) ws_char ws_unitid06 INTO ws_id
            .
          ENDIF.
        ELSE.
          CONCATENATE p_ws_batch_num+0(4) ws_unitid06 INTO ws_id.
        ENDIF.
      ELSE.
        RAISE number_range_not_found.
      ENDIF.
    ENDIF.
  ENDIF.

*If the year does not matches,start generating sequential  number from
*the begining
  IF ws_flag = c_flag OR
    ( ws_unitid < '9999999' AND ws_unitid+0(1) NA ws_alpha ).
*   Current year
    ws_year = sy-datum+0(4).
*   Call function to generate a Sequential number
    CALL FUNCTION 'NUMBER_GET_NEXT'
      EXPORTING
        nr_range_nr             = c_number
        object                  = c_object07
        toyear                  = ws_year
      IMPORTING
        number                  = ws_unitid
      EXCEPTIONS
        interval_not_found      = 1
        number_range_not_intern = 2
        object_not_found        = 3
        quantity_is_0           = 4
        quantity_is_not_1       = 5
        interval_overflow       = 6
        buffer_overflow         = 7
        OTHERS                  = 8.
    IF sy-subrc = 0.
      CONCATENATE c_zz ws_year+3(1) ws_unitid INTO ws_id.
      CLEAR ws_flag.
    ELSE.
      RAISE number_range_not_found.
    ENDIF.
  ENDIF.
ENDFORM.                    " Generate_unit_id

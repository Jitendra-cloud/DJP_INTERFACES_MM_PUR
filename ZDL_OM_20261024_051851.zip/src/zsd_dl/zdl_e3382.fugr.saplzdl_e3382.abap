*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E3382TOP.                     " Global Data
  INCLUDE LZDL_E3382UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E3382F...                     " Subprograms
* INCLUDE LZDL_E3382O...                     " PBO-Modules
* INCLUDE LZDL_E3382I...                     " PAI-Modules

INCLUDE LZDL_E3382SUB.

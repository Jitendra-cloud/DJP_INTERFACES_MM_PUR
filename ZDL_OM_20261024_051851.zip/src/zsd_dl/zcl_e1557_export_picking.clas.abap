class ZCL_E1557_EXPORT_PICKING definition
  public
  final
  create public .

*"* public components of class ZCL_E1557_EXPORT_PICKING
*"* do not include other source files here!!!
public section.

*  types:
*    BEGIN OF ty_charg_cnt,
*  venum TYPE vekp-venum,
**      exidv TYPE vekp-exidv,
*  charg TYPE vekp-charg,
*  UNVEL TYPE VEPO-UNVEL,  "Lower-level handling unit
*  matnr TYPE vepo-matnr,
*END OF ty_charg_cnt .
  constants GC_TRUE type FLAG value 'X' ##NO_TEXT.
  class-data GO_APPLOG type ref to ZCL_CA_APPLOGGING .
  class-data C_POSNV_0 type POSNR_VON value '0' ##NO_TEXT.
  class-data C_POSNV_8 type VBTYP_N value '8' ##NO_TEXT.
  class-data C_POSNV_DELI type VBTYP_V value 'J' ##NO_TEXT.
  class-data GC_01 type VPOBJ value '01' ##NO_TEXT.
  class-data GC_03 type VPOBJ value '03' ##NO_TEXT.
  class-data LV_ICON_NAME type CHAR20 .
  class-data LV_ICON type STRING .
  class-data GV_METRIC_IND type ZSDE3607_METRIC_INDICATOR .
  class-data LS_CHARG_CNT type ZDL_E1557_LT_CHARG_CNT .

  class-methods CLASS_CONSTRUCTOR .
  class-methods VALIDATE_BOOKNUM
    importing
      !IV_BOOKNUM type ZZBOOKNUM optional
      !IV_BOOKDOC type ZSD_BOOK_BOOKDOC optional
    exporting
      !ET_BOOK_ITM type ZDL_E1557_SALES_ORDER
      !EV_BOOK_DATA type ZSD_DL_BOOK_INFO
      !EV_METRIC_IND type ZSDE3607_METRIC_INDICATOR .
  class-methods GET_CONTAINERS
    importing
      !IV_BOOKDOC type ZSD_BOOK_BOOKDOC
    exporting
      !EV_BOOKING_TYPE type CHAR01
      !ET_CONTAINER type ZSD_DL_E1557_CONTAINER_DISPLAY .
  class-methods VALIDATE_DELIVERY
    importing
      !IT_VALID type ZSD_DL_E1557_DELIVERY_DISPLAY
      !IT_DEMAND type ZDL_E1557_DEMAND
    exporting
      !EV_SUBRC type SY-SUBRC
      !ET_DEMAND type ZDL_E1557_DEMAND .
  class-methods REFRESH_LOG .
  class-methods GET_LHU_CONTAINER
    importing
      !IT_CONTAINER type ZSD_DL_E1557_CONTAINER_DISPLAY
      !IT_DEMAND type ZDL_E1557_DEMAND
      !IS_BOOK_INFO type ZSD_DL_BOOK_INFO
    exporting
      !EV_SUBRC type SY-SUBRC
      !ET_SUPPLY_WARNING type ZDL_E1557_SUPPLY_WARNING
      !ET_DEMAND_WARNING type ZDL_E1557_DEMAND_WARNING
      !ET_SUPPLY type ZDL_E1557_SUPPLY
      !ET_CONTAINER_ROLLUP type ZDL_E1557_MATCH_CHU
      !ET_MATCH_BATCH type ZDL_E1557_MATCH .
  class-methods GET_DELIVERIES
    importing
      !IV_BOOKNUM type ZZBOOKNUM
      !IT_BOOK_ITM type ZDL_E1557_SALES_ORDER
    exporting
      !ET_LIKP type ZSD_DL_E1557_DELIVERY_DISPLAY
      !ET_DEMAND type ZDL_E1557_DEMAND
      !EV_TKNUM type TKNUM .
  class-methods ALLOCATE_SUPPLY
    importing
      !IT_DEMAND type ZDL_E1557_DEMAND
      !IT_MATCH_DUPLI type ZDL_E1557_MATCH_DUPLI
      !IT_DEMAND_WARNING type ZDL_E1557_DEMAND_WARNING optional
    exporting
      !ET_MATCH_DUPLI type ZDL_E1557_MATCH_DUPLI
      !ET_DEMAND_WARNING type ZDL_E1557_DEMAND_WARNING .
  class-methods CALCULATE_WEIGHTS
    importing
      !IT_MATCH_BATCH type ZDL_E1557_MATCH_LINE
    exporting
      !ET_MATCH_BATCH type ZDL_E1557_MATCH_LINE .
  class-methods BUILD_PICK_IDOC
    importing
      !IT_IDOC type ZDL_E1557_IDOC
    exporting
      !ET_ERROR type ZDL_E1557_REPORT .
  class-methods METHOD_UPDATE_DELIVERY
    importing
      !IT_HU_EXIDV type ZDL_E1557_PACK
      !IT_VBELN type VBELN_VL
    returning
      value(RV_SUBBRC) type SY-SUBRC .
  class-methods TOLERANCE_WARNING
    importing
      !IT_IDOC type ZDL_E1557_IDOC
      !IT_DEMAND_WARNING type ZDL_E1557_DEMAND_WARNING
    exporting
      !ET_TOLERANCE_WARNING type ZDL_E1557_TOLERANCE_WARNING
      !ES_IDOC_LINE type ZDL_E1557_IDOC_LINE .
  class-methods GET_SUPPLY_BULK
    importing
      !IT_DEMAND_VALID type ZDL_E1557_DEMAND
      !IS_BOOK_INFO type ZSD_DL_BOOK_INFO
    exporting
      !ET_MATCH_BATCH type ZDL_E1557_MATCH
      !ET_MATCH_DUPLI type ZDL_E1557_MATCH_DUPLI
      !ET_DEMAND_WARNING type ZDL_E1557_DEMAND_WARNING
      !ET_SUPPLY type ZDL_E1557_SUPPLY .
  class-methods CONSO_SUPPLY_BULK
    importing
      !IT_MATCH_BATCH type ZDL_E1557_MATCH optional
      !IT_MATCH_DUPLI type ZDL_E1557_MATCH_DUPLI optional
    exporting
      !ET_MATCH_LHU type ZDL_E1557_MATCH_LHU .
  class-methods GET_MESSAGE
    returning
      value(RT_MESSAGES) type ZCA_MESSAGE_TAB .
  class-methods GET_BB_MSG .
  class-methods INBOUND_IDOC_ZDL_FF_SHPMNT
    importing
      !IT_IDOC type ZDL_E1557_DELIVERY_IDOC optional
      !IV_FRT_FORWARDER type ZSD_BOOK_HDR-FRT_FORWARDER
      !IV_BOOKNUM type LIKP-ZZBOOKNUM
      !IV_BOOKDOC type ZSD_BOOK_HDR-BOOKDOC
      !IV_DDATE type SY-DATUM
      !IT_IDOC_CONT type ZSD_DL_E1557_CONTAINER_DISPLAY optional
      !IT_CHARG_CNT type ZDL_E1557_CHARG_CNT optional
    exporting
      !ET_ERROR type ZDL_E1557_REPORT
      value(EV_MESSAGE) type CHAR100
    changing
      !IT_SUPPLY type ZDL_E1557_SUPPLY optional .
  class-methods FIND_DELIVERIES
    importing
      !IT_SALES_ORDER type ZDL_E1557_SALES_ORDER
      !IV_PLANT_CODE type ZSD_BOOK_HDR-PLANT_CODE
      !IV_STGLOC type ZSD_BOOK_HDR-STGLOC
    exporting
      !ET_DEL type ZDL_E1557_T_DELIVERY
      !ET_DELIVERY_VALID type ZSD_DL_E1557_DELIVERY_DISPLAY
      !ET_DEMAND type ZDL_E1557_DEMAND
      !ET_VEKP type ZDL_E1557_T_VEKP .
protected section.
*"* protected components of class ZCL_E1557_EXPORT_PICKING
*"* do not include other source files here!!!

  class-methods HANDLE_MESSAGE .
private section.
*"* private components of class ZCL_E1557_EXPORT_PICKING
*"* do not include other source files here!!!

  class-data GT_USAPP type TT_USAPP .
  class-data GV_DATA type CHAR18 .

  class-methods GET_USER_REF
    exporting
      !ET_USAPP type TT_USAPP .
  class-methods BUILD_SUPPLY_WARNING
    importing
      !IT_SUPPLY type ZDL_E1557_SUPPLY
      !IT_CONTAINER type ZSD_DL_E1557_CONTAINER_DISPLAY
    exporting
      !ET_SUPPLY_WARNING type ZDL_E1557_SUPPLY_WARNING
    changing
      !CT_MATCH_BATCH type ZDL_E1557_MATCH .
  class-methods PROGRESS_INDICTOR
    importing
      !IV_MESSAGE type CHAR100
      !IV_PERCENT type I .
  class-methods GET_ICON .
ENDCLASS.



CLASS ZCL_E1557_EXPORT_PICKING IMPLEMENTATION.


method allocate_supply .
************************************************************************
* In this method it_match_dupli table contains records at batch level
* and those batches assigned at delivery header . Reason for populating
* this table is the batches matched to delivery can be assigned to two
* or more line items and this method will  distribute those batches
* among competing delivery lines. In case any delivery line item could
* not find a batch because there are'nt enough to satisfy all the
* delivery line items then those line items will be added to demand
* warning to display to user.
************************************************************************
  types : begin of tt_demand_allocate,
           vbeln type vbeln_vl,
           posnr type posnr ,
           matnr type  matnr,
           lfimg type lfimg ,
           ntgew type ntgew_15,
           demand type lfimg,
           vrkme  type vrkme ,
           uebto type uebto,
           untto type untto,
           vgbel type vgbel,
           vgpos type vgpos,
           flag  type char01,
           werks type werks_d,
          end of tt_demand_allocate.

  data : lt_demand_allocate type  table of tt_demand_allocate,
         ls_demand_allocate type tt_demand_allocate,
         ls_match_dupli type zdl_e1557_match_dupli_lines,
         ls_demand type zdl_e1557_demand_line,
         lt_demand_warning type zdl_e1557_demand_warning,
         ls_demand_warning type zdl_e1557_demand_warning_line,
         lv_new_uom type meins.

  refresh et_match_dupli.
  lt_demand_warning = it_demand_warning.



  loop at it_match_dupli into ls_match_dupli.
    clear lv_new_uom.
    lv_new_uom = ls_match_dupli-vemeh.
*Populate a temporary  table  lt_demand_allocate with the demand that is
*competing where a demand column will be  updated as we allocate
*batches to that line item .
    at new matnr.
      refresh lt_demand_allocate.
      loop at it_demand into ls_demand
                              where   vbeln = ls_match_dupli-vbeln
                              and     matnr = ls_match_dupli-matnr.

        clear ls_demand_allocate.
        move-corresponding ls_demand to ls_demand_allocate.
        ls_demand_allocate-demand = ls_demand-ntgew.
*This flag is to feel if at least one batch assigned to that demand line
*or not .
        ls_demand_allocate-flag = 'X'.
        append ls_demand_allocate to lt_demand_allocate.
      endloop.
*Sort the table by demand column so that higher requirement will be on
*the top line .
      sort lt_demand_allocate by demand descending.
    endat.

    clear ls_demand_allocate.
    read table lt_demand_allocate into ls_demand_allocate index 1.

    move ls_demand_allocate-posnr to ls_match_dupli-posnr.
    move ls_demand_allocate-lfimg to ls_match_dupli-lfimg.
    move ls_demand_allocate-vrkme to ls_match_dupli-vrkme.
    move ls_demand_allocate-uebto to ls_match_dupli-uebto.
    move ls_demand_allocate-untto to ls_match_dupli-untto.
* This is the batch record assigned to a delivery line item .
    append  ls_match_dupli to et_match_dupli.
*  Batch assigned to this demand line
    if not ls_demand_allocate-flag is initial.
      clear     ls_demand_allocate-flag.
    endif.
* Adjust the demand of delivery line before assigning further batches .
    ls_demand_allocate-demand =
*    ls_demand_allocate-demand - ls_match_dupli-nt_vemng_lbs.
     ls_demand_allocate-demand - ls_match_dupli-nt_vemng_raw.

    modify lt_demand_allocate from ls_demand_allocate index 1.
    sort lt_demand_allocate by demand descending.

* At the end of all the delivery line items that are competing for
* batches of particular material update the demand warning table if
* that  demand line item  was not assigned with at least one batch .
    at end of matnr.
      loop at lt_demand_allocate into ls_demand_allocate
                                 where flag = 'X'.

        ls_demand_warning-matnr = ls_demand_allocate-matnr.
        ls_demand_warning-werks = ls_demand_allocate-werks.
        ls_demand_warning-vbeln = ls_demand_allocate-vbeln.
        ls_demand_warning-posnr = ls_demand_allocate-posnr.
        ls_demand_warning-vgbel = ls_demand_allocate-vgbel.
        ls_demand_warning-vgpos = ls_demand_allocate-vgpos.
        ls_demand_warning-lfimg = ls_demand_allocate-lfimg.
        ls_demand_warning-uebto = ls_demand_allocate-uebto.
        ls_demand_warning-untto = ls_demand_allocate-untto.
        ls_demand_warning-vrkme = ls_demand_allocate-vrkme.
        ls_demand_warning-mess_type = 'BTS'.
        lv_icon_name = 'ICON_SYSTEM_HELP'.
        call function 'ICON_CREATE'
          exporting
            name       = lv_icon_name
            add_stdinf = ' '
          importing
            result     = lv_icon.
        ls_demand_warning-help = lv_icon.

        append ls_demand_warning to lt_demand_warning.
      endloop.
    endat.
  endloop.
  et_demand_warning = lt_demand_warning.
endmethod.


METHOD build_pick_idoc .
*******************************************************************
* This method will Pick  all deliveries coming through the
* table IT_IDOC . This table contain all the matched records at
* Batch level . At this time all Handling units are validated
* Delivery line items validated and all batches are matched
* to delivery line item .
******************************************************************

  DATA : lt_idoc TYPE zdl_e1557_idoc,
         ls_idoc TYPE zdl_e1557_idoc_line,
         lt_hu  TYPE zdl_e1557_pack,
         ls_hu TYPE hum_rehang_hu,
         lv_status TYPE edi_status,
         lv_subrc TYPE sy-subrc,
         ls_error TYPE zdl_e1557_report_line,
         lv_message TYPE char100,
         idoc_e1vpdlh          TYPE  e1vpdlh ,
         idoc_e1vpdli          TYPE  e1vpdli ,
         lt_control_rec_40     TYPE TABLE OF edi_dc40,
         ls_control_rec_40     TYPE edi_dc40,
         lt_data_rec_40        TYPE TABLE OF edi_dc40,
         ls_data_rec_40        TYPE edi_dc40,
         lt_idoc_data          TYPE  TABLE OF edi_dd40,
         ls_idoc_data          TYPE  edi_dd40,
         ls_master_idoc_control        TYPE edi_dc40,
         lt_master_idoc_control TYPE TABLE OF edidc,
         ws_segnum             TYPE  idocdsgnum,
         lv_char_kalab(15)      TYPE  c,
         lv_char_vemng(15)      TYPE  c,
         idoc_num TYPE edi_docnum,
         error_appl TYPE edi_errflg,
         lv_logsys             TYPE   logsys.   "Logical system

  FIELD-SYMBOLS : <ls_idoc> TYPE zdl_e1557_idoc_line.

  lt_idoc = it_idoc.
*  Build the control record
  ls_master_idoc_control-direct = '2'.             "Direction -inbound
  ls_master_idoc_control-mestyp = 'SDPICK'.
  ls_master_idoc_control-idoctyp = 'SDPIID01'.
  CONCATENATE sy-sysid 'CLNT' sy-mandt INTO lv_logsys.
  ls_master_idoc_control-sndprt = 'US'.        "partner type
  ls_master_idoc_control-sndprn = lv_logsys.   "partner number
  ls_master_idoc_control-sndpor = 'TRFC'.
  ls_master_idoc_control-sndpfc = 'ZF'.     "partner function <<MC001
  ls_master_idoc_control-rcvprt = 'US'.
  ls_master_idoc_control-rcvprn = lv_logsys.

* Progress Indicator
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = 'Building the Idocs for Picking'(040)
      iv_percent = 100.

  LOOP AT lt_idoc ASSIGNING <ls_idoc>.
* Internal table lt_idoc may contain multiple deliveries along with
* batches assigned to line items . Here program need to create one IDOC
* per delivery and post it.
* so following control to break at change on delivery and update header
* record
*
    AT NEW vbeln.
      REFRESH : lt_idoc_data, lt_hu.
      CLEAR :   idoc_e1vpdlh, ls_idoc_data.
      idoc_e1vpdlh-vbeln_vl  = <ls_idoc>-vbeln .
      idoc_e1vpdlh-vbeln     = <ls_idoc>-vbeln .
      idoc_e1vpdlh-komue     = 'X' .
      ls_idoc_data-segnam     = 'E1VPDLH'.
      ls_idoc_data-sdata      = idoc_e1vpdlh.
      APPEND ls_idoc_data TO lt_idoc_data.
    ENDAT.
*  update batch records assigned to delivery line item
    CLEAR : idoc_e1vpdli.
    idoc_e1vpdli-vbeln_vl = <ls_idoc>-vbeln.
    idoc_e1vpdli-posnr_vl = <ls_idoc>-posnr.
    idoc_e1vpdli-vbeln    = <ls_idoc>-vbeln .
    idoc_e1vpdli-posnn    = <ls_idoc>-posnr .
*    idoc_e1vpdli-meins    = <ls_idoc>-vemeh .
     idoc_e1vpdli-meins    = <ls_idoc>-nt_vemeh_raw .
*    idoc_e1vpdli-gewei    = <ls_idoc>-vemeh .
     idoc_e1vpdli-gewei    = <ls_idoc>-gr_vemeh_raw .
    idoc_e1vpdli-charg    = <ls_idoc>-charg.
    idoc_e1vpdli-matnr    = <ls_idoc>-matnr .
*
*    clear lv_char_vemng .
*    MOVE <ls_idoc>-vemng TO lv_char_vemng .
*    SHIFT lv_char_vemng LEFT DELETING LEADING space.
*    idoc_e1vpdli-pikmg    = lv_char_vemng .
*    idoc_e1vpdli-brgew    = lv_char_vemng .
*    idoc_e1vpdli-ntgew    = lv_char_vemng .
*
    clear lv_char_vemng .
    MOVE <ls_idoc>-nt_vemng_raw TO lv_char_vemng .
    SHIFT lv_char_vemng LEFT DELETING LEADING space.
    idoc_e1vpdli-pikmg    = lv_char_vemng .
    idoc_e1vpdli-ntgew    = lv_char_vemng .
*
    clear lv_char_vemng .
    MOVE <ls_idoc>-gr_vemng_raw TO lv_char_vemng .
    SHIFT lv_char_vemng LEFT DELETING LEADING space.
    idoc_e1vpdli-brgew    = lv_char_vemng .
*
*   Update the record to IDOC table
    ls_idoc_data-segnam    = 'E1VPDLI'.
    ls_idoc_data-sdata     = idoc_e1vpdli.
    APPEND ls_idoc_data TO lt_idoc_data.
*  Need to prepare a table for packing using
*  Delivery update table . When updating this table populate
*  with container information for containers and lower level
*  handling units for break bulk
    CLEAR ls_hu.
    IF NOT <ls_idoc>-uevel IS INITIAL.  " Container
      MOVE:   <ls_idoc>-uxidv TO ls_hu-top_hu_external,
              <ls_idoc>-uevel TO ls_hu-top_hu_internal.
    ELSE.     "  Break Bulk
      MOVE:   <ls_idoc>-exidv TO ls_hu-top_hu_external,
              <ls_idoc>-venum TO ls_hu-venum ,
              <ls_idoc>-vepos TO ls_hu-vepos ,
              <ls_idoc>-charg TO ls_hu-charg .
    ENDIF.
    APPEND ls_hu TO lt_hu .
*  At the end of delivery prepare and fire IDOC
    AT END OF vbeln.
      CLEAR : idoc_num, lv_status.
      CONCATENATE  'Building idoc for delivery'(041)
                    <ls_idoc>-vbeln   INTO lv_message
                    SEPARATED BY space.
*     Progress Indicator
      CALL METHOD zcl_e1557_export_picking=>progress_indictor
        EXPORTING
          iv_message = lv_message
          iv_percent = 50.
*     Idoc creation and posting
      CALL FUNCTION 'IDOC_INBOUND_SINGLE'
        EXPORTING
          pi_idoc_control_rec_40        = ls_master_idoc_control
          pi_do_commit                  = 'X'
        IMPORTING
          pe_idoc_number                = idoc_num
          pe_error_prior_to_application = error_appl
        TABLES
          pt_idoc_data_records_40       = lt_idoc_data
        EXCEPTIONS
          idoc_not_saved                = 1
          OTHERS                        = 2.
*   Get the IDOC status to feel if we need to pack are not .
      IF sy-subrc = 0.
        SELECT SINGLE status
          INTO lv_status FROM edidc
         WHERE docnum = idoc_num.
        IF lv_status = '53'.
          CLEAR lv_message.
          CONCATENATE 'idoc'
                      idoc_num
                      'succesfully created for delivery'(042)
                      <ls_idoc>-vbeln INTO lv_message
                      SEPARATED BY space.

          CALL METHOD zcl_e1557_export_picking=>progress_indictor
            EXPORTING
              iv_message = lv_message
              iv_percent = 100.

          SORT lt_hu BY top_hu_external.
          DELETE ADJACENT DUPLICATES FROM lt_hu COMPARING
          top_hu_external.
          CALL METHOD zcl_e1557_export_picking=>method_update_delivery
            EXPORTING
              it_hu_exidv = lt_hu
              it_vbeln    = <ls_idoc>-vbeln
            RECEIVING
              rv_subbrc   = lv_subrc.
          IF lv_subrc = 0.
            ls_error-excp_status = '3'.
            ls_error-vbeln = <ls_idoc>-vbeln.
            ls_error-idoc_number = idoc_num.
            ls_error-pick_status = 'SUCCESSFUL'(050).
            ls_error-pack_status = 'SUCCESSFUL'(050).
            APPEND ls_error TO et_error.
            CLEAR ls_error.
          ELSE.
            ls_error-excp_status = '1'.
            ls_error-vbeln = <ls_idoc>-vbeln.
            ls_error-idoc_number = idoc_num.
            ls_error-pick_status = 'SUCCESSFUL'(050).
            ls_error-pack_status = 'UNSUCCESSFUL'(051).
            APPEND ls_error TO et_error.
            CLEAR ls_error.
          ENDIF.
        ELSE.
          CLEAR lv_message.
          CONCATENATE 'Error while creating idoc for'(043)
                      <ls_idoc>-vbeln INTO lv_message
                      SEPARATED BY space.

          CALL METHOD zcl_e1557_export_picking=>progress_indictor
            EXPORTING
              iv_message = lv_message
              iv_percent = 100.

          ls_error-excp_status = '1'.
          ls_error-vbeln = <ls_idoc>-vbeln.
          ls_error-idoc_number = idoc_num.
          ls_error-pick_status = 'UNSUCCESSFUL'(051).
          ls_error-pack_status = 'UNSUCCESSFUL'(051).
          APPEND ls_error TO et_error.
          CLEAR ls_error.
        ENDIF.
      ENDIF.
    ENDAT.
  ENDLOOP.
ENDMETHOD.


METHOD build_supply_warning .
************************************************************************
* This method will observe the supply that has problem then those
* exceptions will be transferred into supply warning table and delete
* all the batches  handling units and containers from the table where
* those batches are assigned to a delivery line .
************************************************************************
  DATA :   lv_vbeln TYPE vbeln_vl ,
           lv_vbeln_vl TYPE vbeln_vl ,
           lv_string TYPE string,
           ls_container TYPE zsd_dl_e1557_container,
           ls_supply_warning TYPE zdl_e1557_supply_warning_line,
           split_flag TYPE c.

  FIELD-SYMBOLS :  <ls_supply>  TYPE zdl_e1557_supply_line.
*
* check for the supply warnings
  LOOP AT it_supply ASSIGNING <ls_supply> .
    lv_vbeln_vl = <ls_supply>-vbeln_dl .
    AT NEW uevel.
      CLEAR : lv_vbeln , split_flag ,
              lv_string , ls_container.
      READ TABLE it_container INTO ls_container
                 WITH KEY venum = <ls_supply>-uevel.
      lv_vbeln = lv_vbeln_vl .
      lv_string = lv_vbeln_vl.
    ENDAT.
*    There is no delivery line with this material
    IF <ls_supply>-process_flag = space.
      CLEAR ls_supply_warning.
      ls_supply_warning-uxidv  = ls_container-exidv.
      ls_supply_warning-exidv  = <ls_supply>-exidv.
      ls_supply_warning-matnr  = <ls_supply>-matnr.
      ls_supply_warning-charg  = <ls_supply>-charg.
      ls_supply_warning-mess   =
                    'Delivery not found for this Material & Batch : '.

*      CONCATENATE 'Delivery not found for this Material & Batch : '
*                  <ls_supply>-matnr
*                  <ls_supply>-charg
*      INTO ls_supply_warning-mess SEPARATED BY space.
      ls_supply_warning-mess_type = 'ST1'.
      lv_icon_name = 'ICON_SYSTEM_HELP'.
      CALL FUNCTION 'ICON_CREATE'
        EXPORTING
          name       = lv_icon_name
          add_stdinf = ' '
        IMPORTING
          RESULT     = lv_icon.
      ls_supply_warning-help = lv_icon.
*     Put it in supply warning
      APPEND ls_supply_warning TO et_supply_warning.
      CLEAR ls_supply_warning.
*      Need to delete all the Hus and containe from the matched bucket
      DELETE  ct_match_batch WHERE uevel = <ls_supply>-uevel.
    ENDIF.
*   There is no stock for this batch
    IF <ls_supply>-process_flag = 'NS'.
      CLEAR ls_supply_warning.
      ls_supply_warning-uxidv  = ls_container-exidv.
      ls_supply_warning-exidv  = <ls_supply>-exidv.
      ls_supply_warning-matnr  = <ls_supply>-matnr.
      ls_supply_warning-charg  = <ls_supply>-charg.
      ls_supply_warning-mess =
              'Stock not avilable for this Material & Batch : '.
*      CONCATENATE 'Stock not avilable for this Material & Batch : '
**                  <ls_supply>-matnr
**                  <ls_supply>-charg
*      INTO ls_supply_warning-mess SEPARATED BY space.
      ls_supply_warning-mess_type = 'ST2'.
      lv_icon_name = 'ICON_SYSTEM_HELP'.
      CALL FUNCTION 'ICON_CREATE'
        EXPORTING
          name       = lv_icon_name
          add_stdinf = ' '
        IMPORTING
          RESULT     = lv_icon.
      ls_supply_warning-help = lv_icon.

*     Put it in supply warning
      APPEND ls_supply_warning TO et_supply_warning.
      CLEAR ls_supply_warning.
*      Need to delete all the Hus and container from the matched bucket
      DELETE  ct_match_batch WHERE uevel = <ls_supply>-uevel.
    ENDIF.
*   There is a mismatch on plant or storage location of this batch
*   from Booking number's plant or storage location .
    IF <ls_supply>-process_flag = 'MM'.
      CLEAR ls_supply_warning.
      ls_supply_warning-uxidv  = ls_container-exidv.
      ls_supply_warning-exidv  = <ls_supply>-exidv.
      ls_supply_warning-matnr  = <ls_supply>-matnr.
      ls_supply_warning-charg  = <ls_supply>-charg.
      ls_supply_warning-mess =
'Plant and/or storage location of inventory does not match booking '.
      ls_supply_warning-mess_type = 'ST3'.

      lv_icon_name = 'ICON_SYSTEM_HELP'.
      CALL FUNCTION 'ICON_CREATE'
        EXPORTING
          name       = lv_icon_name
          add_stdinf = ' '
        IMPORTING
          RESULT     = lv_icon.
      ls_supply_warning-help = lv_icon.

*     Put it in supply warning
      APPEND ls_supply_warning TO et_supply_warning.
      CLEAR ls_supply_warning.
*      Need to delete all the Hus and containe from the matched bucket
      DELETE  ct_match_batch WHERE uevel = <ls_supply>-uevel.
    ENDIF.
*check for batches from a container split between multiple deliveries .
    IF <ls_supply>-vbeln_dl <> lv_vbeln
        AND <ls_supply>-vbeln_dl <>  space
                     AND lv_vbeln <>  space.
      IF lv_string IS INITIAL.
        CONCATENATE lv_vbeln <ls_supply>-vbeln_dl INTO lv_string
                            SEPARATED BY space.
      ELSE.
        CONCATENATE lv_string <ls_supply>-vbeln_dl INTO lv_string
                              SEPARATED BY space.
      ENDIF.
      IF split_flag IS INITIAL.
        split_flag = 'X'.
      ENDIF.
    ENDIF.
    lv_vbeln = <ls_supply>-vbeln_dl.
*    At the end of the container if a situation araise that batches are
*    distributed across deliveries give a supply warning
    AT END OF uevel.
      IF  split_flag = 'X'.
        CLEAR split_flag.
        ls_supply_warning-uxidv  = ls_container-exidv.
        CONCATENATE 'Container handlings units are associated to'
                    'multiple deliveries '
*                    lv_string
          INTO ls_supply_warning-mess SEPARATED BY space.
        ls_supply_warning-mess_type = 'ST4'.
        lv_icon_name = 'ICON_SYSTEM_HELP'.
        CALL FUNCTION 'ICON_CREATE'
          EXPORTING
            name       = lv_icon_name
            add_stdinf = ' '
          IMPORTING
            RESULT     = lv_icon.
        ls_supply_warning-help = lv_icon.

*       Put it in supply warning
        APPEND ls_supply_warning TO et_supply_warning.
        CLEAR ls_supply_warning.
*       Need to delete all the Hus and containe from the matched bucket
        DELETE  ct_match_batch WHERE uevel = <ls_supply>-uevel.
      ENDIF.
    ENDAT.
  ENDLOOP.
ENDMETHOD.


METHOD calculate_weights .
***********************************************************************
* This method is used to populate the Gross weight in imperial units ,
* Gross weight in Metric units  , Net weight in imperial units and net
* weight in Metric units  at batch level
***********************************************************************
***************Comment old code Start - 10/12/2009*********************
*  DATA: lv_cuobj_bm TYPE cuobj_bm,
*        lv_class    TYPE klasse_d,
*        lv_clint    TYPE clint.
*
*  DATA : it_out TYPE TABLE OF conf_out .
*  CONSTANTS : lc_unit_lb TYPE vrkme VALUE 'LB',
*              lc_unit_kg TYPE vrkme VALUE 'KG',
*              lc_conv_factor TYPE f VALUE '2.2046'.
*
** Convertion of Gross weight based on VEKP-gewei_max
** - This record is at batch level but
** Gross weight information is picked from VEKP table .
*
*  CASE it_match_batch-gewei_max .
*    WHEN lc_unit_lb.   " Gross weight in LBS
*      et_match_batch-gr_vemng_lbs = it_match_batch-gr_vemng_lbs.
*      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*        EXPORTING
*          input                = et_match_batch-gr_vemng_lbs
*          round_sign           = ' '
*          unit_in              = 'LB'
*          unit_out             = 'KG'
*        IMPORTING
*          output               = et_match_batch-gr_vemng_kgs
*        EXCEPTIONS
*          conversion_not_found = 01
*          division_by_zero     = 02
*          input_invalid        = 03
*          output_invalid       = 04
*          overflow             = 05
*          units_missing        = 06
*          unit_in_not_found    = 07
*          unit_out_not_found   = 08.
*
*    WHEN lc_unit_kg.   " Gross weight in KGs
*      et_match_batch-gr_vemng_kgs = it_match_batch-gr_vemng_lbs .
*      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*        EXPORTING
*          input                = et_match_batch-gr_vemng_kgs
*          round_sign           = ' '
*          unit_in              = 'KG'
*          unit_out             = 'LB'
*        IMPORTING
*          output               = et_match_batch-gr_vemng_lbs
*        EXCEPTIONS
*          conversion_not_found = 01
*          division_by_zero     = 02
*          input_invalid        = 03
*          output_invalid       = 04
*          overflow             = 05
*          units_missing        = 06
*          unit_in_not_found    = 07
*          unit_out_not_found   = 08.
*
**  There will be a situation of space because this method is
**  Called in a loop of supply at batch level and gross weight is
**  Picked at header level of HU from VEKP so we will update only to
**  first batch of HU and rest of records will have their gross weight
**  column  zero .
*    WHEN space.
*      CLEAR : et_match_batch-gr_vemng_kgs,
*              et_match_batch-gr_vemng_lbs.
** When the gross weight unit is not LBS or KGS then convert the
** alternate  UOM to LBS and then to KGS .
*    WHEN OTHERS.
*      CALL FUNCTION 'Z_CONVERT_TO_ALT_UOM'
*        EXPORTING
*          material            = it_match_batch-matnr
*          curr_uom            = it_match_batch-gewei_max
*          curr_qty            = it_match_batch-gr_vemng_lbs
*          new_uom             = lc_unit_lb
*        IMPORTING
*          new_qty             = et_match_batch-gr_vemng_lbs
*        EXCEPTIONS
*          curr_uom_not_found  = 1
*          new_uom_not_found   = 2
*          no_parameters_found = 3
*          OTHERS              = 4.
*      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*        EXPORTING
*          input                = et_match_batch-gr_vemng_lbs
*          round_sign           = ' '
*          unit_in              = 'LB'
*          unit_out             = 'KG'
*        IMPORTING
*          output               = et_match_batch-gr_vemng_kgs
*        EXCEPTIONS
*          conversion_not_found = 01
*          division_by_zero     = 02
*          input_invalid        = 03
*          output_invalid       = 04
*          overflow             = 05
*          units_missing        = 06
*          unit_in_not_found    = 07
*          unit_out_not_found   = 08.
*
*  ENDCASE.
*
** Net Weight Calculation based on VEPO-VEMEH ( Unit of measure at batch
** record )
*  CASE it_match_batch-vemeh .
*    WHEN lc_unit_lb. " Net weight in LBS
*      et_match_batch-nt_vemng_lbs = it_match_batch-vemng.
*
*      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*        EXPORTING
*          input                = et_match_batch-nt_vemng_lbs
*          round_sign           = ' '
*          unit_in              = 'LB'
*          unit_out             = 'KG'
*        IMPORTING
*          output               = et_match_batch-nt_vemng_kgs
*        EXCEPTIONS
*          conversion_not_found = 01
*          division_by_zero     = 02
*          input_invalid        = 03
*          output_invalid       = 04
*          overflow             = 05
*          units_missing        = 06
*          unit_in_not_found    = 07
*          unit_out_not_found   = 08.
*
*    WHEN lc_unit_kg.  " Net weight in KGS
*      et_match_batch-nt_vemng_kgs = it_match_batch-vemng.
*
*      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*        EXPORTING
*          input                = et_match_batch-nt_vemng_kgs
*          round_sign           = ' '
*          unit_in              = 'KG'
*          unit_out             = 'LB'
*        IMPORTING
*          output               = et_match_batch-nt_vemng_lbs
*        EXCEPTIONS
*          conversion_not_found = 01
*          division_by_zero     = 02
*          input_invalid        = 03
*          output_invalid       = 04
*          overflow             = 05
*          units_missing        = 06
*          unit_in_not_found    = 07
*          unit_out_not_found   = 08.
*
*    WHEN OTHERS.
**  When the net weight unit is not LBS or KGS then convert the
**  Alternate
**  UOM to LBS and then to KGS .
*      CALL FUNCTION 'Z_CONVERT_TO_ALT_UOM'
*        EXPORTING
*          material            = it_match_batch-matnr
*          curr_uom            = it_match_batch-vemeh
*          curr_qty            = it_match_batch-vemng
*          new_uom             = lc_unit_lb
*        IMPORTING
*          new_qty             = et_match_batch-nt_vemng_lbs
*        EXCEPTIONS
*          curr_uom_not_found  = 1
*          new_uom_not_found   = 2
*          no_parameters_found = 3
*          OTHERS              = 4.
** Simple Conversion
*      CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
*        EXPORTING
*          input                = et_match_batch-nt_vemng_lbs
*          round_sign           = ' '
*          unit_in              = 'LB'
*          unit_out             = 'KG'
*        IMPORTING
*          output               = et_match_batch-nt_vemng_kgs
*        EXCEPTIONS
*          conversion_not_found = 01
*          division_by_zero     = 02
*          input_invalid        = 03
*          output_invalid       = 04
*          overflow             = 05
*          units_missing        = 06
*          unit_in_not_found    = 07
*          unit_out_not_found   = 08.
*
*  ENDCASE.
***************Comment old code End - 10/12/2009***********************
***********************************************************************
***********************************************************************
*-- Start -  " CR#09415
  DATA : lt_batch_in TYPE STANDARD TABLE OF zcharg,
         lt_batch_out TYPE TABLE OF zbatch_out,
         lt_zberror TYPE STANDARD TABLE OF zberror,
         ls_batch_in TYPE zcharg,
         ls_batchval TYPE zbatch_val,
         ls_batch_out  LIKE LINE OF lt_batch_out.
*         ls_match_batch TYPE zdl_e1557_match_line.

  CLEAR : ls_batch_in , ls_batch_out.
  REFRESH : lt_batch_in , lt_batch_out , lt_zberror.

  ls_batch_in-matnr =  it_match_batch-matnr.
  ls_batch_in-charg =  it_match_batch-charg.
  ls_batch_in-werks =  it_match_batch-werks.
  APPEND ls_batch_in TO lt_batch_in.


  CALL FUNCTION 'ZDL_E04516_WEIGHT_DIMEN_CAL'
    TABLES
      batch_in       = lt_batch_in
      batch_out      = lt_batch_out
      batch_error    = lt_zberror
    EXCEPTIONS
      plant_required = 1
      OTHERS         = 2.

  IF sy-subrc <> 0.
    REFRESH lt_batch_out.
  ENDIF.

  CLEAR ls_batch_out.

  READ TABLE lt_batch_out INTO ls_batch_out
                          WITH KEY matnr = it_match_batch-matnr
                                   charg =  it_match_batch-charg.

  LOOP AT ls_batch_out-batch_val INTO ls_batchval.
    CASE ls_batchval-val_type.
      WHEN 'GR'.
        et_match_batch-gr_vemng_raw = ls_batchval-value.
        et_match_batch-gr_vemeh_raw = ls_batchval-unit.
      WHEN 'NR'.
        et_match_batch-nt_vemng_raw = ls_batchval-value.
        et_match_batch-nt_vemeh_raw = ls_batchval-unit.
      WHEN 'GM'.
        IF gv_metric_ind = 'Y'.
          et_match_batch-gr_vemng_display = ls_batchval-value.
          et_match_batch-gr_vemeh_display = ls_batchval-unit.
        ENDIF.
      WHEN 'NM' .
        IF gv_metric_ind = 'Y'.
          et_match_batch-nt_vemng_display = ls_batchval-value.
          et_match_batch-nt_vemeh_display = ls_batchval-unit.
        ENDIF.
      WHEN 'GI'.
        IF gv_metric_ind NE 'Y'.
          et_match_batch-gr_vemng_display = ls_batchval-value.
          et_match_batch-gr_vemeh_display = ls_batchval-unit.
        ENDIF.
      WHEN 'NI'.
        IF gv_metric_ind NE 'Y'.
          et_match_batch-nt_vemng_display = ls_batchval-value.
          et_match_batch-nt_vemeh_display = ls_batchval-unit.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDLOOP.
*-- End -    " CR#09415



























ENDMETHOD.


  method CLASS_CONSTRUCTOR .
 DATA:
        ls_profile TYPE bal_s_prof,
        ls_fcat    type bal_s_fcat.

*// Get the display profile
  CALL FUNCTION 'BAL_DSP_PROFILE_NO_TREE_GET'
    IMPORTING
      e_s_display_profile = ls_profile.

  ls_profile-no_toolbar = gc_true.
  ls_profile-cwidth_opt = 'A'.


  TRY.
      CREATE OBJECT go_applog
        EXPORTING
          ib_subscreen               = gc_true
          is_profile                 = ls_profile.
    CATCH zcx_ca_applog_init_failure .
  ENDTRY.

endmethod.


METHOD conso_supply_bulk .
*********************************************************************
* This method will roll up the matched records to handling unit level
* to display on pick screen . Batch records for which there is competing
* Demand will also get rolled up
**********************************************************************
  DATA : ls_match_batch TYPE zdl_e1557_match_line,
         ls_match_dupli TYPE zdl_e1557_match_dupli_lines,
         ls_match_lhu TYPE zdl_e1557_match_lhu_line,
         ls_idoc_line TYPE zdl_e1557_idoc_line,
         lv_tabix TYPE sy-tabix,
         lv_lfimg TYPE lfimg                     ,
         lv_uebto  TYPE uebto                    ,
         lv_untto  TYPE untto                    ,
         lv_hus TYPE i.

*Consolidate the match batch table by rolling up to handling unit level.
  LOOP AT it_match_batch INTO ls_match_batch.
    CLEAR : lv_tabix, lv_lfimg, lv_uebto, lv_untto.
    lv_tabix = sy-tabix.
* Following fields need to be transfered as is and can't sum it up
* because those are at delivery line item level and records in table
* are at batch level
    lv_lfimg = ls_match_batch-lfimg.
    lv_uebto = ls_match_batch-uebto.
    lv_untto = ls_match_batch-untto.

*  At end of handling unit roll up the records
    AT END OF venum.
      READ TABLE it_match_batch INTO ls_match_batch INDEX lv_tabix.
      SUM.
      MOVE-CORRESPONDING ls_match_batch TO ls_match_lhu.
      MOVE  lv_lfimg TO ls_match_lhu-lfimg.
      MOVE  lv_uebto TO ls_match_lhu-uebto.
      MOVE   lv_untto TO ls_match_lhu-untto.
      APPEND ls_match_lhu TO et_match_lhu.
**     Lock the HU
*      CALL FUNCTION 'ENQUEUE_EVVEKPE'
*        EXPORTING
*          mode_vekp      = 'E'
*          mandt          = sy-mandt
*          venum          = ls_match_batch-venum
*          x_venum        = ' '
*          _scope         = '2'
*          _wait          = ' '
*          _collect       = ' '
*        EXCEPTIONS
*          foreign_lock   = 1
*          system_failure = 2
*          OTHERS         = 3.
    ENDAT.

  ENDLOOP.

* Consolidate the match batch table where demand lines competing to same
* MTS Material by rolling up to handling unit level.
  LOOP AT it_match_dupli INTO ls_match_dupli.
    CLEAR : lv_tabix, lv_lfimg, lv_uebto, lv_untto.
    lv_tabix = sy-tabix.
    lv_lfimg = ls_match_batch-lfimg.
    lv_uebto = ls_match_batch-uebto.
    lv_untto = ls_match_batch-untto.

    AT END OF venum.
      READ TABLE it_match_dupli INTO ls_match_dupli INDEX lv_tabix.
      SUM.
      MOVE-CORRESPONDING ls_match_dupli TO ls_match_lhu.
      MOVE  lv_lfimg TO ls_match_lhu-lfimg.
      MOVE  lv_uebto TO ls_match_lhu-uebto.
      MOVE   lv_untto TO ls_match_lhu-untto.
      APPEND ls_match_lhu TO et_match_lhu.
**     Lock the HU
*      CALL FUNCTION 'ENQUEUE_EVVEKPE'
*        EXPORTING
*          mode_vekp      = 'E'
*          mandt          = sy-mandt
*          venum          = ls_match_dupli-venum
*          x_venum        = ' '
*          _scope         = '2'
*          _wait          = ' '
*          _collect       = ' '
*        EXCEPTIONS
*          foreign_lock   = 1
*          system_failure = 2
*          OTHERS         = 3.
    ENDAT.

  ENDLOOP.

  IF et_match_lhu IS INITIAL.
    MESSAGE e000 WITH 'No Supply Demand Match'.
  ENDIF.

  SORT et_match_lhu BY vbeln ASCENDING
                       posnr DESCENDING
                       exidv ASCENDING .

ENDMETHOD.


  METHOD find_deliveries.
    TYPES:
      BEGIN OF ty_vekp,
        venum TYPE vekp-venum,
        exidv TYPE vekp-exidv,
        charg TYPE vekp-charg,
        unvel TYPE vepo-unvel,  "Lower-level handling unit
        matnr TYPE vepo-matnr,
      END OF ty_vekp.

    DATA:
      gt_demand      TYPE zdl_e1557_demand,
      gt_demand_vbap TYPE zdl_e1557_demand,
      gs_demand_vbap TYPE zdl_e1557_demand_line,
      gs_demand      TYPE zdl_e1557_demand_line,
      lt_demand_vbap TYPE zdl_e1557_demand,
      gt_demand_mchb TYPE zdl_e1557_demand,
      ls_sales_order TYPE ZDL_E1557_SALES_ORDER_DISPLAY,

      lt_vekp_unvel  TYPE STANDARD TABLE OF  ty_vekp,  "
      ls_vekp        TYPE ty_vekp,  "
      gs_vekp        TYPE ty_vekp,  "

      lt_charg_cnt   TYPE zdl_e1557_charg_cnt,  "
      ls_charg_cnt   TYPE zdl_e1557_lt_charg_cnt,  "

      ls_batch_out   TYPE  zbatch_out,  "  Batch OUTPUT

      lt_batch_in    TYPE STANDARD TABLE OF  zcharg,  "  Batch INPUT TABLE
      lt_batch_out   TYPE STANDARD TABLE OF  zbatch_out,  "  Batch OUTPUT
      lt_zberror     TYPE STANDARD TABLE OF  zberror,  " Errors IN Batch.

      lt_batch_val   TYPE STANDARD TABLE OF zbatch_val,
      ls_batch_val   TYPE zbatch_val,
      lt_container   TYPE zsd_dl_e1557_container_display,
      lt_mska        TYPE STANDARD TABLE OF mska,
      ls_mska        TYPE mska,
      gs_del         TYPE zdl_e1557_delivery.

    SELECT
      vbeln  "Sales Document
    posnr  "Document Item
    sobkz  "Special Stock Indicator
    matnr
    werks
    vgbel
    vgpos
    lgort
    ntgew
    gewei
    zz_metric_ind
    INTO CORRESPONDING FIELDS OF TABLE gt_demand
    FROM vbap
    FOR ALL ENTRIES IN it_sales_order
    WHERE vbeln = it_sales_order-vbeln  "Sales Document
    AND posnr = it_sales_order-posnr  "Document Item
    AND sobkz IN ('E', 'W', '').
    gt_demand_vbap = gt_demand.
    lt_demand_vbap = gt_demand_vbap.

    "keep only E & W = MTO
    DELETE lt_demand_vbap WHERE sobkz = space.

    IF lt_demand_vbap IS NOT INITIAL.
      SELECT
      vbeln  "Sales Document
      posnr  "Document Item
      sobkz  "Special Stock Indicator
      matnr
      charg
      werks
      lgort
      INTO CORRESPONDING FIELDS OF TABLE et_demand
      FROM mska
      FOR ALL ENTRIES IN lt_demand_vbap
      WHERE vbeln = lt_demand_vbap-vbeln  "Sales Document
      AND posnr = lt_demand_vbap-posnr  "Document Item
      AND werks = iv_plant_code
      AND lgort = iv_stgloc
      AND matnr = lt_demand_vbap-matnr
      AND kalab > 0.
    ENDIF.

    "keep only blank = MTS
    DELETE gt_demand_vbap WHERE sobkz <> space.

    IF gt_demand_vbap IS NOT INITIAL.
      SELECT
      matnr
      charg
      INTO CORRESPONDING FIELDS OF TABLE gt_demand_mchb
      FROM mchb
      FOR ALL ENTRIES IN gt_demand_vbap
      WHERE werks = iv_plant_code
      AND lgort = iv_stgloc
      AND matnr = gt_demand_vbap-matnr
      AND clabs > 0.

      IF gt_demand_mchb IS NOT INITIAL.
        MOVE-CORRESPONDING gt_demand_mchb TO et_demand.
        READ TABLE it_sales_order INTO ls_sales_order
          INDEX 1 TRANSPORTING zz_metric_ind.
      ENDIF.
    ENDIF.

    IF et_demand IS NOT INITIAL.

*Get all lower level handling units packed into the containers from
*VEPO based on UEVEL Link
      SELECT
      vepo~venum
      vekp~exidv
      vepo~charg
      vepo~unvel
      INTO TABLE et_vekp
      FROM vepo INNER JOIN vekp
      ON vepo~venum = vekp~venum
      FOR ALL ENTRIES IN et_demand
      WHERE vepo~charg = et_demand-charg.

      lt_vekp_unvel = et_vekp.

      MOVE-CORRESPONDING et_demand TO lt_batch_in.

*        There IS a situation WHERE the booking can be entered FOR
*        plant 9201 AND storage location HU01 but
*        the containers/batches are IN 9201/HU03.
*        WHEN this happens we DO NOT GET ANY weights BACK ON the
*          confirmation SCREEN.  Then have an error MESSAGE that says
*          ‘No inventory found FOR plant XXXX storage location XXXX.

      IF lt_batch_in IS INITIAL.
        MESSAGE e000(zsd_dl) WITH
        'No inventory found for plant'(052) iv_plant_code
        'storage location'(053) iv_stgloc.
        RETURN.
      ENDIF.

      "get gross and net weight
      CALL FUNCTION 'ZDL_E04516_WEIGHT_DIMEN_CAL'
        TABLES
          batch_in       = lt_batch_in
          batch_out      = lt_batch_out
          batch_error    = lt_zberror
        EXCEPTIONS
          plant_required = 1
          OTHERS         = 2.
      SORT lt_batch_out BY matnr charg.
      SORT et_demand BY charg.
      SORT et_vekp BY venum.

      LOOP AT et_vekp INTO ls_vekp.

        gs_vekp = ls_vekp.
        AT NEW venum.


          READ TABLE et_demand INTO gs_demand
            WITH KEY charg = gs_vekp-charg.

          MOVE-CORRESPONDING gs_demand TO gs_del.

          gs_del-uxidv = gs_vekp-exidv.

        ENDAT.  "for  at NEW venum.


        gs_del-no_of_units =  gs_del-no_of_units + 1. "Batches


        READ TABLE lt_batch_out INTO ls_batch_out
            WITH KEY matnr = gs_demand-matnr
            charg = gs_vekp-charg
            BINARY SEARCH.

        IF sy-subrc = 0.

          lt_batch_val = ls_batch_out-batch_val.

          READ TABLE gt_demand INTO gs_demand_vbap
          WITH KEY vbeln = gs_demand-vbeln.

          "for MTS orders , assign SO Metric Indicator
          IF gs_demand_vbap-vbeln IS INITIAL.
            gs_demand_vbap-zz_metric_ind = ls_sales_order-zz_metric_ind.
          endif.

*          IF gs_demand_vbap-zz_metric_ind = 'Y'. " E0VK9A0RLO KMADDE1 06/28/17
***  Metric Indicator = 'N' display Quantity and UOM in LB " E0VK9A0RLO KMADDE1 06/28/17
          IF gs_demand_vbap-zz_metric_ind = 'N'. " E0VK9A0RLO KMADDE1 06/28/17

            READ TABLE lt_batch_val INTO ls_batch_val
            WITH KEY val_type = 'GI'.
            IF sy-subrc = 0.
              gs_del-gr_vemng_display = gs_del-gr_vemng_display + ls_batch_val-value.
              gs_del-gr_vemeh_display = ls_batch_val-unit.
            ENDIF.

            READ TABLE lt_batch_val INTO ls_batch_val
            WITH KEY val_type = 'NI'.
            IF sy-subrc = 0.
              gs_del-nt_vemng_display = gs_del-nt_vemng_display + ls_batch_val-value.
              gs_del-nt_vemeh_display = ls_batch_val-unit.
            ENDIF.

*          ELSEIF gs_demand_vbap-zz_metric_ind = 'N'. " E0VK9A0RLO KMADDE1 06/28/17
***  Metric Indicator = 'Y' display Quantity and UOM in KG " E0VK9A0RLO KMADDE1 06/28/17
          ELSEIF gs_demand_vbap-zz_metric_ind = 'Y'. " E0VK9A0RLO KMADDE1 06/28/17

            READ TABLE lt_batch_val INTO ls_batch_val
            WITH KEY val_type = 'GM'.
            IF sy-subrc = 0.
              gs_del-gr_vemng_display = gs_del-gr_vemng_display + ls_batch_val-value.
              gs_del-gr_vemeh_display = ls_batch_val-unit.
            ENDIF.

            READ TABLE lt_batch_val INTO ls_batch_val
            WITH KEY val_type = 'NM'.
            IF sy-subrc = 0.
              gs_del-nt_vemng_display = gs_del-nt_vemng_display + ls_batch_val-value.
              gs_del-nt_vemeh_display = ls_batch_val-unit.
            ENDIF.

          ENDIF.

          CLEAR: lt_batch_val, ls_batch_val, ls_batch_out.

        ENDIF.  "for READ TABLE lt_batch_out

        AT END OF venum.
          APPEND gs_del TO et_del.
          APPEND gs_del TO et_delivery_valid.
          CLEAR: gs_del, gs_vekp, ls_vekp.
        ENDAT.
      ENDLOOP.  "for LOOP AT et_vekp

    ENDIF.  "for  IF et_demand IS NOT INITIAL.

  ENDMETHOD.


  METHOD get_bb_msg.
    DATA : lv_str TYPE string.

    MESSAGE i504  INTO lv_str .
    "  Handle message
    zcl_e1557_export_picking=>handle_message( ).
    go_applog->log_update_subscreen( ).
  ENDMETHOD.


METHOD get_containers .
************************************************************************
* Determine if the booking entered is a break bulk booking or
* Container booking by accessing records in the table zdlu01267_vekp
* Get all the details like seal signi from the table zdlu01267_vekp
************************************************************************
  DATA : lv_str TYPE string.
  DATA : ls_container TYPE zsd_dl_e1557_container .
* This is a select basically getting higher level Handling units
* of supply bucket in the scope of the booking number entered .
  SELECT  zdlu01267_vekp~signi  vekp~exidv
          zdlu01267_vekp~venum  zdlu01267_vekp~seal
          vekp~CHARG
      INTO TABLE et_container   FROM zdlu01267_vekp
      INNER JOIN vekp
         ON  zdlu01267_vekp~venum = vekp~venum
      WHERE    bookdoc = iv_bookdoc
         AND ( vekp~vpobj <> gc_01 AND vekp~vpobj <> gc_03 )
         AND   vekp~hu_lgort = 'X'.
* Lock containers .
  LOOP AT et_container INTO ls_container.
    CALL FUNCTION 'ENQUEUE_EVVEKPE'
      EXPORTING
        mode_vekp      = 'E'
        mandt          = sy-mandt
        venum          = ls_container-venum
        x_venum        = ' '
        _scope         = '2'
        _wait          = ' '
        _collect       = ' '
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
  ENDLOOP.



*  If there is no hit then the booking entered should be a break
*  bulk booking otherwise a container booking .
  IF sy-subrc <> 0 .
    ev_booking_type = 'B'.
    MESSAGE i504  INTO lv_str .
  ELSE.
    MESSAGE i506 INTO lv_str .
  ENDIF.
*  Handle message
  zcl_e1557_export_picking=>handle_message( ).
  go_applog->log_update_subscreen( ).
ENDMETHOD.


METHOD get_deliveries .
************************************************************************
* In this method demand bucket will be populated by getting the
* deliveries from LIPS and VBUP.Matching booking information and items
*  are accessed to get shipment information , status and
* delivery tables VTTK VTTP picking status at item level . Method will
* check and make sure all deliveries derived from booking has the same
* shipment attached to it. Also will check if shipment  load start and
* load end is completed . Also picking status of delivery should be A .
************************************************************************

  TYPES : BEGIN OF tt_vstel,
           vbeln TYPE vbeln ,
           vstel TYPE vstel,
          END OF tt_vstel.

  DATA :   lt_likp TYPE zsd_dl_e1557_delivery_display,
           ls_likp TYPE zsd_dl_e1557_delivery,
           lt_demand TYPE zdl_e1557_demand,
           ls_demand TYPE zdl_e1557_demand_line,
           lt_demand_temp TYPE zdl_e1557_demand,
           lt_vstel TYPE TABLE OF tt_vstel,
           ls_vstel LIKE LINE OF lt_vstel,
           lv_stlbg  TYPE stblg ,
           lv_string TYPE string,
           lv_lins TYPE i,
           lv_sttrg TYPE sttrg,
           lv_message TYPE char100.

* Progress bar indicator
  CONCATENATE 'Getting delivery data for booking'(034)
               iv_booknum  INTO lv_message SEPARATED BY space.
* Progress indication
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = lv_message
      iv_percent = 70.

* Retrive the demand at delivery line item level . Make an inner join
*with VTTP to get the shipment to which deliveries are attached and VBUP
* to get the delivery picking status .
  SELECT lips~vbeln lips~posnr lips~sobkz lips~matnr
            lips~charg lips~vgbel lips~vgpos lips~werks
             lips~lgort lips~lfimg lips~vrkme lips~meins
            lips~uebto lips~untto lips~bestq lips~sonum
            vttp~tknum lips~ntgew INTO TABLE lt_demand FROM vbup
          INNER JOIN lips ON lips~vbeln = vbup~vbeln AND
                             lips~posnr = vbup~posnr
          INNER JOIN vttp ON lips~vbeln = vttp~vbeln
*                             FOR ALL entries IN lt_likp
                             FOR ALL entries IN it_book_itm
*               WHERE vbup~vbeln = lt_likp-vbeln
                WHERE lips~vgbel = it_book_itm-vbeln
                AND   lips~vgpos = it_book_itm-posnr
                AND   vbup~kosta = 'A'.
*  Check return code
  IF sy-subrc <> 0 .
    MESSAGE e000 WITH 'No deliveries found to pick'(054)
                      'for this booking document number'(015).
    RETURN.
  ENDIF.

* Check If deliveries connected with this booking number have multiple
* shipments .
  lt_demand_temp[] = lt_demand[].
  SORT lt_demand_temp BY tknum.
  DELETE ADJACENT DUPLICATES FROM lt_demand_temp COMPARING tknum.
  DESCRIBE TABLE lt_demand_temp LINES lv_lins.
  IF lv_lins > 1 .
    MESSAGE e000 WITH 'More than one shipment associated with'(016)
                      'the booking document number'(017).
    RETURN.
  ELSE.
    READ TABLE lt_demand_temp INTO ls_demand INDEX 1.
    ev_tknum = ls_demand-tknum.
  ENDIF.

*Check for load start and load end , Error message if any one of load
*start or
* Load end is not set in the shipment .
  SELECT SINGLE sttrg stlbg
    INTO (lv_sttrg,lv_stlbg) FROM vttk
                  WHERE tknum = ev_tknum.
  IF lv_sttrg LT '4' OR  lv_stlbg <> 'X'.    " 4 = Loading_end
    CONCATENATE 'Please set shipment'(035)
                 ev_tknum
            INTO lv_string SEPARATED BY space.
    MESSAGE e000 WITH   lv_string
                        'load status indicators before picking'(036)
                        'deliveries for booking'(037)
                        iv_booknum.
  ENDIF.

*********************************************************************
* sort the deliveries to be displayed along with sale order and
* shipping point
********************************************************************
  REFRESH : lt_demand_temp.
  lt_demand_temp[] =  lt_demand[].
  SORT lt_demand_temp BY vbeln.
  DELETE ADJACENT DUPLICATES FROM lt_demand_temp COMPARING vbeln.
  SELECT  vbeln vstel FROM likp
       INTO TABLE lt_vstel
    FOR ALL ENTRIES IN lt_demand_temp
    WHERE vbeln = lt_demand_temp-vbeln.
  LOOP AT lt_demand_temp INTO ls_demand.
    ls_likp-vbeln = ls_demand-vbeln.
    ls_likp-vgbel = ls_demand-vgbel.
    READ TABLE lt_vstel INTO ls_vstel WITH KEY vbeln = ls_demand-vbeln.
    IF sy-subrc = 0 .
      ls_likp-vstel = ls_vstel-vstel.
    ENDIF.
    APPEND ls_likp TO lt_likp.

  ENDLOOP.
* Move deliveries and demand to output tables .
  et_likp[] = lt_likp[].
  et_demand[] = lt_demand[].
ENDMETHOD.


method GET_ICON .
endmethod.


METHOD get_lhu_container .
************************************************************************
* This is a very important method triggered only during container
* booking This method will get all the supply at batch level meaning
* lower level handling units from VEPO based on containers selection by
* user. Also in this method demand and supply  will be matched , demand
* warnings captured , supply warnings evaluated and demand algorithm
* will run on handling units that need to be assigned to multiple
* delivery lines and matched finally records rolled to container level.
************************************************************************
**************
* Types
  TYPES :   BEGIN OF tt_vepo,
           venum  TYPE  venum     ,
           vepos  TYPE  vepos     ,
           unvel  TYPE  unvel     ,
           matnr  TYPE  matnr     ,
           charg  TYPE  charg_d   ,
           werks  TYPE  werks_d   ,
           lgort  TYPE  lgort_d   ,
           exidv  TYPE  exidv     ,
           mto_mts_flag TYPE char1,
           vbeln TYPE vbeln       ,
           posnr TYPE posnr       ,
          END OF tt_vepo.
* Data
  DATA : lt_vepo TYPE TABLE OF tt_vepo,
         lt_unvel TYPE TABLE OF tt_vepo,
         ls_unvel TYPE tt_vepo,
         lt_supply TYPE zdl_e1557_supply,
         ls_supply TYPE zdl_e1557_supply_line,
         lv_string TYPE string,
         lv_weight_flag TYPE c,
         lv_matnr TYPE matnr ,
         lt_demand TYPE zdl_e1557_demand ,
         ls_demand TYPE zdl_e1557_demand_line,
         lv_demand_flg TYPE char1,
         lt_demand_warning TYPE  zdl_e1557_demand_warning,
         ls_demand_warning TYPE zdl_e1557_demand_warning_line,
         lt_supply_warning TYPE zdl_e1557_supply_warning,
         ls_supply_warning TYPE zdl_e1557_supply_warning_line,
         lt_match_batch TYPE zdl_e1557_match,
         ls_match_batch TYPE  zdl_e1557_match_line,
         lt_match_dupli TYPE zdl_e1557_match_dupli,
         lt_match_dupli_temp TYPE zdl_e1557_match_dupli,
         ls_match_dupli TYPE  zdl_e1557_match_dupli_lines,
         lt_match_lhu TYPE zdl_e1557_match_lhu ,
         ls_match_lhu TYPE zdl_e1557_match_lhu_line,
         lt_match_chu TYPE zdl_e1557_match_chu   ,
         ls_match_chu TYPE zdl_e1557_match_chu_line,
         ls_container TYPE zsd_dl_e1557_container,
         lv_hus TYPE i                           ,
         lv_lfimg TYPE lfimg                     ,
         lv_uebto  TYPE uebto                    ,
         lv_untto  TYPE untto                    ,
         lv_tabix TYPE sy-tabix                 ,
         lv_error TYPE char01                    ,
         lv_subrc TYPE sy-subrc ,
          lv_vbeln TYPE vbeln_vl .

* progress indicator
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = 'Getting the supply'(028)
      iv_percent = 30.
*
* Get all Supply based on Booking Number , retreive all the higher level
* handling units from  VEPO based on container numbers  derived from
* booking number .
  SELECT venum vepos unvel
      FROM vepo INTO TABLE lt_vepo
          FOR ALL ENTRIES IN it_container
               WHERE venum = it_container-venum.
  IF sy-subrc <> 0.
    MESSAGE e000 WITH  'No higher level handling units'(026)
                       'are available for the selected containers'(027).
*    ev_subrc = 1 .
    RETURN.
  ENDIF.
* Get all lower level handling units packed into the containers from
* VEPO based on UEVEL Link
  SELECT vepo~venum vepo~vepos vepo~matnr
           vepo~charg vepo~werks vepo~vemng
           vepo~vemeh vepo~lgort vekp~exidv
           vekp~uevel vekp~brgew vekp~ntgew
            vekp~gewei_max
      INTO CORRESPONDING FIELDS OF TABLE lt_supply
      FROM vepo INNER JOIN vekp
          ON vepo~venum = vekp~venum
            FOR ALL entries IN lt_vepo
                 WHERE vepo~venum = lt_vepo-unvel
                  AND vekp~status = '0020' .
  IF sy-subrc <> 0 .
    MESSAGE e000 WITH  'No lower level handling units'(029)
                       'are available for the selected containers'(030).
*    ev_subrc = 1 .
    RETURN.
  ENDIF.
*  Supply table lt_supply populated above
  REFRESH : lt_demand_warning, lt_match_batch,  lt_match_dupli,
            et_supply_warning.
*  Transfer demand to local table
  lt_demand = it_demand.
*
* Progress indicator
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = 'Matching Demand and Supply'(032)
      iv_percent = 60.
*
  SORT lt_supply BY matnr uevel venum .
* Loop is to match the demand and supply demand is delivery line items
* Supply is batches . We will assign the batches to appropriate delivery
* line items  in the following loop .
  LOOP AT lt_demand INTO ls_demand.
* Following flag is used if at least one batch is assigned to a delivery
* line .
    lv_demand_flg = 'X'.
    IF ls_demand-dupli_mts_flag <> 'Y'.
* This branch of code will be triggered for MTO demand lines and
* MTS demand lines with space or X .
      LOOP AT lt_supply INTO ls_supply
                       WHERE matnr = ls_demand-matnr AND
                             ( process_flag = space OR
                                       process_flag = 'NS' ).

* Process the gross weight at Hu header level but the supply bucket is
* at batch level    .
        AT NEW venum.
          lv_weight_flag = 'X'.
        ENDAT.
* Plant or Storabe location of Handling unit is not matching from
* booking storage location , plant
        IF  ls_supply-werks <> is_book_info-plant_code OR
             ls_supply-lgort <> is_book_info-stgloc .
          ls_supply-process_flag = 'MM'. " Storage location mis match
          ls_supply-vbeln_dl = ls_demand-vbeln.
          MODIFY lt_supply FROM ls_supply.
          CONTINUE.
        ENDIF.
        IF ls_demand-sobkz  <> space.  " MTO
* check in table mska for unrestricted stock for the batch
          SELECT SINGLE kalab
              INTO  ls_match_batch-stock FROM mska
               WHERE vbeln = ls_demand-vgbel AND
                     posnr = ls_demand-vgpos AND
                     matnr = ls_supply-matnr AND
                     werks = ls_supply-werks AND
*                    lgort = ls_supply-lgort AND   "E0VK971513
                     charg = ls_supply-charg AND
                     kalab > 0.
        ELSE.     " MTS
* check in table mchb for unrestricted stock for the batch
          SELECT SINGLE  clabs
          INTO ls_match_batch-stock FROM mchb
            WHERE matnr = ls_supply-matnr AND
                  werks = ls_supply-werks AND
*                 lgort = ls_supply-lgort AND       "E0VK971513
                  charg = ls_supply-charg AND
                  clabs > 0.
        ENDIF.
        IF sy-subrc <> 0.
* There is no stock for this batch so mark it for further process
* Program need to eliminate all batches of this Hu from supply match
* Also eliminate all Hus and container from supply bucket.
          ls_supply-process_flag = 'NS'. " no stock error code
          ls_supply-vbeln_dl = ls_demand-vbeln.
          MODIFY lt_supply FROM ls_supply.
          CONTINUE.
        ELSE.
* populate table gt_match_batch indicating that there has been a match
* b/w demand and supply
          ls_match_batch-vbeln = ls_demand-vbeln.
          ls_match_batch-matnr = ls_demand-matnr.
          ls_match_batch-werks = ls_supply-werks.
          ls_match_batch-charg = ls_supply-charg.
          ls_match_batch-vemng = ls_supply-vemng.
          ls_match_batch-vemeh = ls_supply-vemeh.
          ls_match_batch-lgort = ls_supply-lgort.
          ls_match_batch-lfimg = ls_demand-lfimg.
          ls_match_batch-vrkme = ls_demand-vrkme.
          ls_match_batch-uebto = ls_demand-uebto.
          ls_match_batch-untto = ls_demand-untto.
          ls_match_batch-no_of_units = 1.
          ls_match_batch-venum = ls_supply-venum.
          ls_match_batch-vepos = ls_supply-vepos.
          ls_match_batch-exidv = ls_supply-exidv.
          ls_match_batch-uevel = ls_supply-uevel.

          CLEAR ls_container.
          READ TABLE it_container INTO ls_container WITH KEY
                                      venum = ls_supply-uevel.
          ls_match_batch-signi = ls_container-signi.
          ls_match_batch-uxidv = ls_container-exidv.
          ls_match_batch-seal = ls_container-seal.
* Weight calculation and conversion
          IF NOT lv_weight_flag IS INITIAL.
            ls_match_batch-gr_vemng_lbs = ls_supply-brgew.
            ls_match_batch-gewei_max = ls_supply-gewei_max.
            CLEAR lv_weight_flag.
          ELSE.
            CLEAR : ls_match_batch-gr_vemng_lbs,
                    ls_match_batch-gewei_max.
          ENDIF.
* Weight Conversion
          CALL METHOD zcl_e1557_export_picking=>calculate_weights
            EXPORTING
              it_match_batch = ls_match_batch
            IMPORTING
              et_match_batch = ls_match_batch.

          IF ls_demand-dupli_mts_flag = 'X'.
            CLEAR ls_match_dupli.
            ls_match_batch-posnr = space.
            MOVE-CORRESPONDING ls_match_batch TO ls_match_dupli.

            APPEND ls_match_dupli TO lt_match_dupli.
            CLEAR ls_match_dupli.
          ELSE.
            ls_match_batch-posnr = ls_demand-posnr.
            APPEND ls_match_batch TO lt_match_batch.
            CLEAR ls_match_batch.
          ENDIF.
* Modify supply record with success code.
          ls_supply-process_flag = 'SS'.    " succesfully assigned
          ls_supply-vbeln_dl = ls_demand-vbeln.
          ls_supply-uxidv    =  ls_container-exidv.
          MODIFY lt_supply FROM ls_supply.
* Clear demand flag atleast one batch attached
          CLEAR lv_demand_flg.
        ENDIF.
      ENDLOOP.
* Code branches here for Subsequent MTS demand lines and we can continue
* with out assignment as demand algorithm will take care of assignment
      .
    ELSE.
      CONTINUE.
    ENDIF.
* See if demand flag = 'X' populate the warning table because there is
* none assigned to this delivery line .
    IF lv_demand_flg = 'X'.
      CLEAR ls_demand_warning.
      ls_demand_warning-matnr = ls_demand-matnr.
      ls_demand_warning-werks = ls_demand-werks.
      ls_demand_warning-vbeln = ls_demand-vbeln.
      ls_demand_warning-posnr = ls_demand-posnr.
      ls_demand_warning-vgbel = ls_demand-vgbel.
      ls_demand_warning-vgpos = ls_demand-vgpos.
      ls_demand_warning-lfimg = ls_demand-lfimg.
      ls_demand_warning-uebto = ls_demand-uebto.
      ls_demand_warning-untto = ls_demand-untto.
      ls_demand_warning-vrkme = ls_demand-vrkme.
      IF ls_demand-sobkz <> space.
        ls_demand_warning-mess_type = 'ATO'. "(MTO)
      ELSE.
        ls_demand_warning-mess_type = 'ATS'. "(MTS)
      ENDIF.
* setting the icon
      lv_icon_name = 'ICON_SYSTEM_HELP'.
      CALL FUNCTION 'ICON_CREATE'
        EXPORTING
          name       = lv_icon_name
          add_stdinf = ' '
        IMPORTING
          RESULT     = lv_icon.
      ls_demand_warning-help = lv_icon.

      APPEND ls_demand_warning TO lt_demand_warning.
    ENDIF.
  ENDLOOP.
* If any demand lines found that need to run demand algorithm  call the
* method allocate_supply
  IF lt_match_dupli IS NOT INITIAL.
    SORT lt_match_dupli BY vbeln ASCENDING
                           posnr ASCENDING
                           matnr ASCENDING
                           vemng DESCENDING
                           exidv ASCENDING.
    CALL METHOD zcl_e1557_export_picking=>allocate_supply
      EXPORTING
        it_demand         = lt_demand
        it_match_dupli    = lt_match_dupli
        it_demand_warning = lt_demand_warning
      IMPORTING
        et_match_dupli    = lt_match_dupli_temp
        et_demand_warning = lt_demand_warning.

    SORT lt_match_dupli_temp BY vbeln posnr exidv .
* once the demand alogritham ran move the records to the match batch
* table
    LOOP AT lt_match_dupli_temp INTO ls_match_dupli.
      MOVE-CORRESPONDING ls_match_dupli TO ls_match_batch.
      ls_match_batch-mts_flag = 'X'.
      APPEND ls_match_batch TO lt_match_batch.
    ENDLOOP.
  ENDIF.

* Time to process all the supply exceptions found above when matching
* the demand and supply .
  SORT lt_supply BY uevel process_flag vbeln.

  CALL METHOD zcl_e1557_export_picking=>build_supply_warning
    EXPORTING
      it_supply         = lt_supply
      it_container      = it_container
    IMPORTING
      et_supply_warning = et_supply_warning
    CHANGING
      ct_match_batch    = lt_match_batch.

* progress indicator
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = 'Sending the data for the final output'(033)
      iv_percent = 100.

* Consolidate the table at venum and uxidv level On Pick screen
* deliveries and containers are shown at higher level Handling units
  CLEAR  : lv_hus.
  SORT lt_match_batch BY uxidv exidv matnr charg.
  LOOP AT lt_match_batch INTO ls_match_batch.
    lv_tabix = sy-tabix.
    lv_lfimg = ls_match_batch-lfimg.
    lv_uebto = ls_match_batch-uebto.
    lv_untto = ls_match_batch-untto.
*   Lower level handling unit roll up
    AT END OF venum.
      READ TABLE lt_match_batch INTO ls_match_batch INDEX lv_tabix.
      SUM.
      MOVE-CORRESPONDING ls_match_batch TO ls_match_lhu.
      MOVE  lv_lfimg TO ls_match_lhu-lfimg.
      MOVE  lv_uebto TO ls_match_lhu-uebto.
      MOVE   lv_untto TO ls_match_lhu-untto.
      APPEND ls_match_lhu TO lt_match_lhu.
      lv_hus = lv_hus + 1 .
    ENDAT.
*  Higher level handling unit roll up
    AT END OF uxidv.
      READ TABLE lt_match_batch INTO ls_match_batch INDEX lv_tabix.
      SUM.
      MOVE-CORRESPONDING ls_match_batch TO ls_match_chu.
      ls_match_chu-no_of_hus = lv_hus.
      APPEND ls_match_chu TO lt_match_chu.
      CLEAR lv_hus.
    ENDAT.
  ENDLOOP.

  SORT lt_match_chu BY vbeln uxidv.
  et_container_rollup = lt_match_chu.
  et_demand_warning = lt_demand_warning.
  et_match_batch = lt_match_batch.
  et_supply   = lt_supply.
* Message on No Supply Demand Match.
  IF lt_match_chu IS INITIAL.
    MESSAGE e505  INTO lv_string.
    zcl_e1557_export_picking=>handle_message( ).
  ENDIF.
  go_applog->log_update_subscreen( ).
ENDMETHOD.


method GET_MESSAGE .
 rt_messages = go_applog->GET_MESSAGES( )  .

endmethod.


METHOD get_supply_bulk .
************************************************************************
* In this method supply bucket will be populated and demand will be
* matched Batch match table to display on pick screen as well as
* matching the batches when demand is competing .
* When demand is competing un like in container booking
* Batches that are competing will be matched at header of demand and
* item number marked as 'TBD' and displayed on pick screen .
************************************************************************

  DATA :lv_demand_flag TYPE char01,
        lt_supply TYPE zdl_e1557_supply,
        ls_supply TYPE zdl_e1557_supply_line,
        lv_weight_flag TYPE c,
        lv_lock_flag TYPE c,
        ls_demand TYPE zdl_e1557_demand_line,
        ls_match_batch TYPE zdl_e1557_match_line,
        lt_match_batch TYPE zdl_e1557_match,
        lt_match_dupli TYPE zdl_e1557_match_dupli,
        ls_match_dupli TYPE zdl_e1557_match_dupli_lines,
        lt_demand_warning TYPE  zdl_e1557_demand_warning,
        ls_demand_warning TYPE zdl_e1557_demand_warning_line,
        ls_match_lhu TYPE zdl_e1557_match_lhu_line,
        lv_lfimg TYPE lfimg                     ,
        lv_uebto  TYPE uebto                    ,
        lv_untto  TYPE untto                    ,
        lv_tabix TYPE sy-tabix                 ,
        lv_mm_ns_flag TYPE c,
        lv_string TYPE string.

* progress indicator
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = 'Getting the supply'
      iv_percent = 30.

  LOOP AT it_demand_valid INTO ls_demand.
*  Table lt_supply will be filled with batches from VEPO
    REFRESH lt_supply.
* Data marking done on demand lines before hand if record is
* flagged X or Y  Means same MTS material exist on all those lines
* with X as the first  Y being sunsequent lines .
* If the record is flagged we don't have to assign any batches here and
* when Demand algorithm run on this data then batches will be assigned
* to these delivery lines .
    IF ls_demand-dupli_mts_flag = 'Y'.
      CONTINUE.
    ENDIF.
*  Following flag is used to sense if atleast one batch is attached to
*  Delivery line item .
    lv_demand_flag = 'X'.
*  The demand line is pointing  MTO
    IF ls_demand-sobkz NE space.          " MTO
*   select  batches from VEPO into the supply table from VEPO and VEKP
*   When populating gross weight and net weight for this supply record
*   at batch level net weight will come from VEPO
*   Gross weight is coming from VEKP and apply to all batches in that
*   handling unit .Please Observe that Gross weight is at
*   HU level information even the    records in  this table are at
*   batch level .
      SELECT   vp~venum vp~vepos vp~vemng
           vp~vemeh vp~charg vp~matnr
             vp~werks vp~lgort vk~exidv vk~uevel vk~brgew
         vk~ntgew vk~gewei_max
       INTO CORRESPONDING FIELDS OF TABLE lt_supply
        FROM vepo AS vp INNER JOIN vekp AS vk
        ON vp~venum = vk~venum
         INNER JOIN zsp_value
         ON vp~lgort = zsp_value~fieldvalue
        WHERE
                 vp~matnr = ls_demand-matnr
             AND vp~werks = ls_demand-werks
*             AND vp~bestq = ls_demand-bestq
             AND vp~sobkz = ls_demand-sobkz
               AND ( vk~vpobj <> '01' AND vk~vpobj <> '03' )
             AND vk~uevel = space
             AND vk~status = '0020'
             AND vk~hu_lgort EQ 'X'
             AND  zsp_value~pgrmid EQ 'ZSDE1558_PICKING'.
    ELSE.   " MTS
* select  batches from VEPO into the supply table from VEPO and VEKP
* When populating gross weight  and net weight for this supply record at
* batch level
* net weight will come from VEPO  Gross weight is coming from VEKP and
* apply to all  batches in that handling unit .
* Please Observe that Gross weight is at HU level information even the
* records in this table are at batch level .
      SELECT
        vp~venum vp~vepos vp~vemng vp~vemeh vp~charg
         vp~matnr vp~werks vp~lgort  vk~exidv vk~uevel
        vk~brgew vk~ntgew vk~gewei_max
         INTO CORRESPONDING FIELDS OF TABLE lt_supply
      FROM vepo AS vp
        INNER JOIN  vekp AS vk
      ON vp~venum = vk~venum
         INNER JOIN zsp_value
         ON vp~lgort = zsp_value~fieldvalue
                WHERE vp~matnr = ls_demand-matnr
                 AND  vp~werks = ls_demand-werks
                 AND  vp~bestq = ls_demand-bestq
                 AND  vp~sobkz = ls_demand-sobkz
                 AND ( vk~vpobj     NE '01'  AND
                      vk~vpobj     NE '03' )
                 AND vk~uevel = space
                 AND vk~status = '0020'
                 AND  vk~hu_lgort = 'X'
                 AND  zsp_value~pgrmid EQ 'ZSDE1558_PICKING'.
    ENDIF.

    CALL METHOD zcl_e1557_export_picking=>progress_indictor
      EXPORTING
        iv_message = 'Matching the supply to demand'
        iv_percent = 30.

* Matching the Demand and supply into match batch table or into
* ls_match_dupli  In case of competing demand lines
* ( Multiple MTS materials samedelivery )
    SORT lt_supply BY venum.
* Here remove from lt_supply all the batches that are consumed by the
* current demand
*  Meaning the batches that are in et_match_batch .
    LOOP AT lt_supply INTO ls_supply.
* A Flag lv_mm_ns_flag will be used to sense all batche records in a HU
* when there is a mismatch on Hu's storage location or plant with
* Booking's Storage location or Plant . Also this flag will be used if
* any of the batch don't have stock then we need to eliminate the full
* HU from supply available on pick screen .
      AT NEW venum.
        CLEAR lv_mm_ns_flag.
        lv_weight_flag = 'X'.
        lv_lock_flag = 'X'.
*     Lock the HU
        CALL FUNCTION 'ENQUEUE_EVVEKPE'
          EXPORTING
            mode_vekp      = 'E'
            mandt          = sy-mandt
            venum          = ls_supply-venum
            x_venum        = ' '
            _scope         = '2'
            _wait          = ' '
            _collect       = ' '
          EXCEPTIONS
            foreign_lock   = 1
            system_failure = 2
            OTHERS         = 3.

      ENDAT.
*  Locking HU
      IF lv_lock_flag = 'X'.
        APPEND ls_supply TO et_supply.
        CLEAR : lv_lock_flag.
      ENDIF.
* There is no need of processing any more batches of a HU when either
* one of the batch mismatched the storage location or plant or any one
* batch has no stock .
* If this situation araise then all batches from that HU need to be
* removed from scope and that Hu need to be removed from assigning to
* any delivery line item .
      IF lv_mm_ns_flag = 'X'.
        CONTINUE.
      ENDIF.
* This logic will skip the batches already confirmed to any demand lines
      READ TABLE et_match_batch INTO ls_match_batch WITH KEY
                            charg = ls_supply-charg .
      IF sy-subrc = 0.
        CLEAR : ls_match_batch.
        CONTINUE.
      ENDIF.
* See if the storage location and plant of the batch match with
* Booking's plant and SL .
      IF  ls_supply-werks <> is_book_info-plant_code OR
        ls_supply-lgort <> is_book_info-stgloc  .
        lv_mm_ns_flag = 'X'.
* Delete all previously matched records in case of failure
        IF ls_demand-dupli_mts_flag = 'X'.
          DELETE et_match_dupli WHERE venum = ls_supply-venum.
        ELSE.
          DELETE et_match_batch WHERE venum = ls_supply-venum.
        ENDIF.
        CONTINUE.
      ENDIF.
* If Demand line is an MTO get the unrestricted stock from MSKA
* Otherwise get the stock from MCHB
      IF ls_demand-sobkz = 'E'.  "NE space.          " MTO
        SELECT SINGLE kalab INTO
           ls_match_batch-stock FROM mska
            WHERE matnr = ls_supply-matnr
          AND   werks = ls_supply-werks
          AND   charg = ls_supply-charg
         AND  lgort = ls_supply-lgort    "E0VK971513
          AND  vbeln = ls_demand-vgbel
          AND    posnr = ls_demand-vgpos
          AND  kalab > 0.
      ELSEif ls_demand-sobkz = space.
        SELECT SINGLE clabs INTO    " MTS
          ls_match_batch-stock
          FROM mchb
          WHERE matnr = ls_supply-matnr
          AND   werks = ls_supply-werks
          AND   charg = ls_supply-charg
         AND  lgort = ls_supply-lgort   "E0VK971513
          AND  clabs > 0.
      ENDIF.
      IF sy-subrc <> 0 .
        lv_mm_ns_flag = 'X'.
        IF ls_demand-dupli_mts_flag = 'X'.
          DELETE et_match_dupli WHERE venum = ls_supply-venum.
        ELSE.
          DELETE et_match_batch WHERE venum = ls_supply-venum.
        ENDIF.
        CONTINUE.
      ENDIF.
      ls_match_batch-vbeln = ls_demand-vbeln.
      ls_match_batch-posnr = ls_demand-posnr.
      ls_match_batch-matnr = ls_demand-matnr.
      ls_match_batch-lfimg = ls_demand-lfimg.
      ls_match_batch-vrkme = ls_demand-vrkme.
      ls_match_batch-uebto = ls_demand-uebto.
      ls_match_batch-untto = ls_demand-untto.
      ls_match_batch-werks = ls_supply-werks.
      ls_match_batch-charg = ls_supply-charg.
      ls_match_batch-vemng = ls_supply-vemng.
      ls_match_batch-vemeh = ls_supply-vemeh.
      ls_match_batch-lgort = ls_supply-lgort.
      ls_match_batch-venum = ls_supply-venum.
      ls_match_batch-vepos = ls_supply-vepos.
      ls_match_batch-exidv = ls_supply-exidv.
      ls_match_batch-uevel = ls_supply-uevel.
      ls_match_batch-no_of_units = 1.
* Move the gross weight and UOM of handling unit into first batch
* record In that handling unit and move zero to subsequent batch records
* of the same Handling unit
      IF NOT lv_weight_flag IS INITIAL.
        " Flag will be set at new handling unit .
        ls_match_batch-gr_vemng_lbs = ls_supply-brgew.
        ls_match_batch-gewei_max = ls_supply-gewei_max.
        CLEAR lv_weight_flag.
      ELSE.
        CLEAR : ls_match_batch-gr_vemng_lbs,
                ls_match_batch-gewei_max.
      ENDIF.
*  Run the following method to get  grossweight and net weight in
*  Imperial units and KGS
      CALL METHOD zcl_e1557_export_picking=>calculate_weights
        EXPORTING
          it_match_batch = ls_match_batch
        IMPORTING
          et_match_batch = ls_match_batch.
*  In case of multiple demand lines of same MTS material
*  divert data to run demand  Algorithm
      IF ls_demand-dupli_mts_flag = 'X'.
        CLEAR    ls_match_batch-posnr.
        WRITE 'TBD' TO ls_match_batch-posnr.
        MOVE-CORRESPONDING  ls_match_batch TO ls_match_dupli.
        APPEND ls_match_dupli TO et_match_dupli.
        CLEAR : ls_match_batch,
                ls_match_dupli,
                lv_demand_flag.
      ELSE.
        APPEND ls_match_batch TO et_match_batch.
        CLEAR : ls_match_batch,
                lv_demand_flag.
      ENDIF.
    ENDLOOP.

* if No batch is attached to the demand line populate the warning table
    IF lv_demand_flag = 'X'.
      ls_demand_warning-matnr = ls_demand-matnr.
      ls_demand_warning-werks = ls_demand-werks.
      ls_demand_warning-vbeln = ls_demand-vbeln.
      ls_demand_warning-posnr = ls_demand-posnr.
      ls_demand_warning-vgbel = ls_demand-vgbel.
      ls_demand_warning-vgpos = ls_demand-vgpos.
      ls_demand_warning-lfimg = ls_demand-lfimg.
      ls_demand_warning-uebto = ls_demand-uebto.
      ls_demand_warning-untto = ls_demand-untto.
      ls_demand_warning-vrkme = ls_demand-vrkme.
      IF ls_demand-sobkz <> space.
        ls_demand_warning-mess_type = 'ATO'.
      ELSE.
        ls_demand_warning-mess_type = 'ATS'.
      ENDIF.
      lv_icon_name = 'ICON_SYSTEM_HELP'.
      CALL FUNCTION 'ICON_CREATE'
        EXPORTING
          name       = lv_icon_name
          add_stdinf = ' '
        IMPORTING
          RESULT     = lv_icon.
      ls_demand_warning-help = lv_icon.
      APPEND ls_demand_warning TO et_demand_warning.
    ENDIF.
  ENDLOOP.
* Warning If There are no Handling Units attached to the demand line
  IF et_match_dupli IS INITIAL AND
     et_match_batch IS INITIAL.
    MESSAGE e000 WITH 'No Supply Demand Match' INTO lv_string.
    zcl_e1557_export_picking=>handle_message( ).
  ENDIF.
  go_applog->log_update_subscreen( ).
ENDMETHOD.


method get_user_ref .

  field-symbols: <ls_usapp> like line of gt_usapp.

* get object from the table usaff
  select objkey
       from usapplref
      into table et_usapp
    where bname = sy-uname and
          objtype = 'LFA1'  .

endmethod.


method HANDLE_MESSAGE .

  DATA:
    ls_context  TYPE bal_s_cont,
    ls_msg  TYPE bal_s_msg,
    ls_extra TYPE zdl_e1557_log.

  ls_msg = go_applog->get_message_buffer( ).
  ls_extra-data = gv_data.

  ls_context-tabname   = 'ZDL_E1557_LOG'.
  ls_context-value     = ls_extra.
  ls_msg-context       = ls_context.

  TRY.
      CALL METHOD go_applog->log_message_add
        EXPORTING
          is_msg = ls_msg.
    CATCH zcx_ca_applog_log_not_found .
    CATCH zcx_ca_applog .
  ENDTRY.

endmethod.


METHOD inbound_idoc_zdl_ff_shpmnt .
*******************************************************************
* This method will Pick  all deliveries coming through the
* table IT_IDOC . This table contain all the matched records at
* Batch level . At this time all Handling units are validated
* Delivery line items validated and all batches are matched
* to delivery line item .
******************************************************************

  DATA : lt_idoc                TYPE zdl_e1557_delivery_idoc, "zdl_e1557_idoc,
         ls_idoc                TYPE zdl_e1557_idoc_line,
         ls_supply              TYPE zdl_e1557_supply_line,
*         lt_hu  TYPE zdl_e1557_pack,
*         ls_hu TYPE hum_rehang_hu,
         lv_status              TYPE edi_status,
         lv_subrc               TYPE sy-subrc,
         ls_error               TYPE zdl_e1557_report_line,

         idoc_e1edt20           TYPE e1edt20,
         idoc_e1edl24           TYPE e1edl24,
         idoc_e1edl20           TYPE e1edl20,
         idoc_e1edt10           TYPE e1edt10,
         ls_idoc_cont           TYPE zsd_dl_e1557_container,
         ls_idoc_del            TYPE zdl_e1557_delivery,

         lt_idoc_data           TYPE  TABLE OF edi_dd40,
         ls_idoc_data           TYPE  edi_dd40,
         ls_master_idoc_control TYPE edi_dc40,
         lt_master_idoc_control TYPE TABLE OF edidc,
         ws_segnum              TYPE  idocdsgnum,
         lv_char_kalab(15)      TYPE  c,
         lv_char_vemng(15)      TYPE  c,
         idoc_num               TYPE edi_docnum,
         error_appl             TYPE edi_errflg,
         lv_logsys              TYPE   logsys.   "Logical system

*  FIELD-SYMBOLS : <ls_idoc> TYPE zdl_e1557_delivery. "zdl_e1557_idoc_line.
**INBOUND_IDOC_
  lt_idoc = it_idoc.
*  Build the control record
  ls_master_idoc_control-direct = '2'.             "Direction -inbound
  ls_master_idoc_control-mestyp = 'ZDL_FF_SHPMNT '.
  ls_master_idoc_control-idoctyp = 'SHPMNT05'.
  CONCATENATE sy-sysid 'CLNT' sy-mandt INTO lv_logsys.

  "partner type - profile vendor-ie. freight forwarder
  ls_master_idoc_control-sndprt = 'LI'.

  "Partner Profile Number (partner number of Freight Forwarder from
  "booking with leading 0’s…..10 digit field) Should be partner number
  "that was entered on selection screen. ZSD_BOOK_HDR-FRT_FORWARDER
  ls_master_idoc_control-sndprn = iv_frt_forwarder. ".   "partner number

  ls_master_idoc_control-sndpor = 'LIA0001001'. "send port
  ls_master_idoc_control-sndpfc = 'ZF'. "partner function partner role for freight forwarder
  ls_master_idoc_control-rcvprt = 'LI'. "partner profile vendor-ie. freight forwarder
  ls_master_idoc_control-rcvprn = lv_logsys.
  ls_master_idoc_control-credat = sy-datlo  . "Created on
  ls_master_idoc_control-cretim = sy-timlo  . "Created at
* Progress Indicator
  CALL METHOD zcl_e1557_export_picking=>progress_indictor
    EXPORTING
      iv_message = 'Building the Idocs for Freight Forward Shipment'(039)
      iv_percent = 100.

*  IDOC Segments:
*
*  The E1EDT20-TKNUM will be populated WITH the booking document
*  AND FIELD E1EDT20-TPBEZ will be populated WITH the booking
*  confirmation NUMBER.
  ls_idoc_data-segnam = 'E1EDT20'.
  idoc_e1edt20-tpbez = iv_booknum.
  idoc_e1edt20-tknum = iv_bookdoc.
  ls_idoc_data-sdata = idoc_e1edt20.
  APPEND ls_idoc_data TO lt_idoc_data.

*Segment E1EDT10 with QUALF = 5, date should be filled out with the
*screen Date and time as system local Time
  ls_idoc_data-segnam = 'E1EDT10'.
  idoc_e1edt10-qualf = '005'. "IDOC Qualifier: Date (Shipment)
  idoc_e1edt10-iedd = iv_ddate. "Actual finish: Execution (date)

***  Begin of changes by kmadde1 on 5/16/2017 E0VK9A0QMJ
*  idoc_e1edt10-iedz = sy-uzeit.  "Actual finish: Execution (time)
  idoc_e1edt10-iedz = SY-TIMLO.  "Actual finish: Execution (time)
*** End of changes by kmadde1 on 5/16/2017 E0VK9A0QMJ
  idoc_e1edt10-TZONE_END = SY-ZONLO.
  ls_idoc_data-sdata = idoc_e1edt10.
  APPEND ls_idoc_data TO lt_idoc_data.

*Segment E1EDL20 will be populated with the booking document:
  ls_idoc_data-segnam = 'E1EDL20'.
  idoc_e1edl20-vbeln = iv_bookdoc.
  ls_idoc_data-sdata = idoc_e1edl20.
  APPEND ls_idoc_data TO lt_idoc_data.

*segments E1EDL24 will be populated with the containers and
*seal numbers for container shipments and batch information for
*breakbulk shipments:

* Internal table lt_idoc may contain multiple deliveries along with
* batches assigned to line items . Here program need to create one IDOC
* per delivery and post it.
* so following control to break at change on delivery and update header
* record

  IF it_idoc_cont IS NOT INITIAL.

    "this is container

    LOOP AT it_idoc_cont INTO ls_idoc_cont.
      ls_idoc_data-segnam = 'E1EDL24'.
      ls_idoc_data-segnam = 'E1EDL24'.
      idoc_e1edl24-usr02 = ls_idoc_cont-signi.  "Container ID
      idoc_e1edl24-usr03 = ls_idoc_cont-seal. "Seal Number
      ls_idoc_data-sdata = idoc_e1edl24.
      APPEND ls_idoc_data TO lt_idoc_data.

    ENDLOOP.    "LOOP AT it_idoc_cont

  ELSEIF it_idoc IS NOT INITIAL.

    "this is breakbulk

*    SORT it_supply BY charg.
*    DELETE ADJACENT DUPLICATES FROM it_supply COMPARING charg.
    LOOP AT lt_idoc INTO ls_idoc_del.
      ls_idoc_data-segnam = 'E1EDL24'.
      idoc_e1edl24-posnr = '000010'.
      idoc_e1edl24-matnr = ls_idoc_del-matnr.

*LFIMG always =1 in both cases
      idoc_e1edl24-lfimg = '1'.

*BreakBulk Example: CHARG and USR01 = batch number
*Break Bulk Example for bundle: (difference is CHARG = batch number
*USR01=bundle number
      idoc_e1edl24-charg = ls_idoc_del-charg.

      "•  If VEKP-UEVEL is blank, then this handling unit is not nested
      "within a higher-level handling unit.  That means it is not
      "in a container and is therefore a breakbulk bundle.
      "  VEKP-EXIDV is the bundle number.  It always matches one of
      "the batch numbers included in the bundle.
      READ TABLE it_charg_cnt INTO ls_charg_cnt
          WITH KEY charg = ls_idoc_del-charg.
*          BINARY SEARCH TRANSPORTING unvel.
      IF ls_charg_cnt-unvel IS INITIAL.
        idoc_e1edl24-usr01 = ls_idoc_del-UXIDV.
      ELSE.
        idoc_e1edl24-usr01 = ls_idoc_del-charg.
      ENDIF.

      ls_idoc_data-sdata = idoc_e1edl24.
      APPEND ls_idoc_data TO lt_idoc_data.

    ENDLOOP.    "LOOP AT it_idoc

  ENDIF. "if it_idoc_cont IS NOT INITIAL.


****  At the end of delivery prepare and fire IDOC
  CLEAR : idoc_num, lv_status.
*      CONCATENATE  'Building idoc for delivery'(055)
*                    <ls_idoc>-vbeln   INTO lv_message
*                    SEPARATED BY space.
  ev_message = 'Building idoc...'(055).

*     Idoc creation and posting
  CALL FUNCTION 'IDOC_INBOUND_SINGLE'
    EXPORTING
      pi_idoc_control_rec_40        = ls_master_idoc_control
      pi_do_commit                  = 'X'
    IMPORTING
      pe_idoc_number                = idoc_num
      pe_error_prior_to_application = error_appl
    TABLES
      pt_idoc_data_records_40       = lt_idoc_data
    EXCEPTIONS
      idoc_not_saved                = 1
      OTHERS                        = 2.
*   Get the IDOC status to display back.
  IF sy-subrc = 0.
    SELECT SINGLE status
      INTO lv_status FROM edidc
     WHERE docnum = idoc_num.
    IF lv_status = '53'.
      CLEAR ev_message.
      CONCATENATE 'IDoc'
                  idoc_num
                  'succesfully created... '(056)
*                      <ls_idoc>-vbeln
                  INTO ev_message
                  SEPARATED BY space.
    ELSE.
      CLEAR ev_message.
      CONCATENATE 'IDoc'
                  idoc_num
                  'processed with status'
                  lv_status
                  INTO ev_message
                  SEPARATED BY space.
*      ev_message = 'Error while creating idoc...'(057).
*      CALL METHOD zcl_e1557_export_picking=>progress_indictor
*        EXPORTING
*          iv_message = lv_message
*          iv_percent = 100.

*      ls_error-excp_status = '1'.
**          ls_error-vbeln = <ls_idoc>-vbeln.
*      ls_error-idoc_number = idoc_num.
*      ls_error-pick_status = 'UNSUCCESSFUL'(051).
*      ls_error-pack_status = 'UNSUCCESSFUL'(051).
*      APPEND ls_error TO et_error.
*      CLEAR ls_error.
    ENDIF.
  ELSE.
    ev_message = 'Error while creating idoc...'(057).
  ENDIF.


ENDMETHOD.


METHOD method_update_delivery .
*******************************************************************
* This method will be trigered after Pick IDOC Process successfully
* This method will use Ws_delivery_update to pack the Hus after Picking
**********************************************************************
  DATA:
      ls_vbkok  TYPE  vbkok , " delivery header data to be changed
      l_subrc   TYPE  sysubrc .
*  Delivery
  ls_vbkok-vbeln_vl = it_vbeln .
  ls_vbkok-komue    = 'X' .

  CALL FUNCTION 'HU_PACKING_REFRESH'.

  CALL FUNCTION 'SERIAL_INTTAB_REFRESH'.
* it_hu_exidv contains all packing information .
  CALL FUNCTION 'WS_DELIVERY_UPDATE'
    EXPORTING
      vbkok_wa                 = ls_vbkok
      commit                   = 'X'
      delivery                 = it_vbeln
      if_database_update       = '1'
      if_error_messages_send_0 = 'X'
    TABLES
      it_handling_units        = it_hu_exidv
    EXCEPTIONS
      error_message            = 1.
  rv_subbrc = sy-subrc.
ENDMETHOD.


method PROGRESS_INDICTOR .
    CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
      EXPORTING
        TEXT       = IV_MESSAGE
        PERCENTAGE = IV_PERCENT
      EXCEPTIONS
        OTHERS     = 1.
endmethod.


method REFRESH_LOG .
 go_applog->refresh_log( )  .
 go_applog->log_update_subscreen( ).
endmethod.


METHOD tolerance_warning .
************************************************************************
* Screen 0650 is designed to prompt user when the picked quantity
* assigned to a delivery line item is over or under the tolerance
* limits for that delivery line .
* This method will build the warning table for display
************************************************************************
  DATA :  lv_llfimg TYPE lfimg,
          lv_hlfimg TYPE lfimg,
          lv_vemng TYPE lfimg,
          lv_tabix TYPE sy-tabix,
          lv_no_of_units TYPE i ,
          lv_gr_vemng_lbs TYPE labst,
          lv_gr_vemng_display TYPE labst,
          lv_nt_vemng_lbs TYPE labst,
          lv_nt_vemng_display TYPE labst,
          lv_gr_vemng_kgs TYPE labst,
          lv_nt_vemng_kgs TYPE labst,
          ls_idoc_line TYPE zdl_e1557_idoc_line,
          ls_idoc_line_temp TYPE zdl_e1557_idoc_line,
          ls_tolerance_warning TYPE zdl_e1557_tolerance_warning_li.

  FIELD-SYMBOLS: <fsi> TYPE lfimg ,
                 <ls_demand_warning> TYPE zdl_e1557_demand_warning_line.
  REFRESH et_tolerance_warning.

  CLEAR :    lv_no_of_units  ,
             lv_gr_vemng_lbs ,
             lv_gr_vemng_display ,
             lv_nt_vemng_lbs ,
             lv_nt_vemng_display ,
             lv_gr_vemng_kgs ,
             lv_nt_vemng_kgs .

* Internal table it_idoc contains all batches selected by user after
* pick screen with no errors , Now all those batches which will go to a
* delivery line need to be added and compared to the upper limit and
* lower limit of that delivery line .
  LOOP AT it_idoc  INTO ls_idoc_line .
    CLEAR ls_idoc_line_temp .
    ls_idoc_line_temp = ls_idoc_line.
    lv_tabix = sy-tabix.
* Following information computed to display on information screen
    lv_no_of_units  = lv_no_of_units + ls_idoc_line-no_of_units.
*    lv_gr_vemng_lbs = lv_gr_vemng_lbs + ls_idoc_line-gr_vemng_lbs.
    lv_gr_vemng_display
          = lv_gr_vemng_display + ls_idoc_line-gr_vemng_display.
    lv_nt_vemng_display
          = lv_nt_vemng_display + ls_idoc_line-nt_vemng_display.
*    lv_nt_vemng_lbs = lv_nt_vemng_lbs + ls_idoc_line-nt_vemng_lbs.
*    lv_gr_vemng_kgs = lv_gr_vemng_kgs + ls_idoc_line-gr_vemng_kgs.
*    lv_nt_vemng_kgs = lv_nt_vemng_kgs + ls_idoc_line-nt_vemng_kgs.

    AT END OF posnr.
* Calculate the upper limit that can be assigned in the field lv_hlfimg
* and Lower limit that can be assigned in the field lv_llfimg . These
* things need to be calculated only once per line item and the loop is
* at batch level so this control level at new delivery line item .
      CLEAR : ls_tolerance_warning,
              lv_llfimg,
              lv_hlfimg.
      lv_llfimg = ls_idoc_line_temp-lfimg * ( 1 -
      ls_idoc_line_temp-untto / 100 )  .  " Lower limit
      lv_hlfimg = ls_idoc_line_temp-lfimg * ( 1 +
      ls_idoc_line_temp-uebto / 100 ).   " Higher Limit
*   Decide if warning is needed and populate the tolerance warning table
      SUM.

      IF ls_idoc_line_temp-vrkme <> ls_idoc_line_temp-vemeh.

        CLEAR : lv_vemng.
        lv_vemng = ls_idoc_line-vemng.

*    ASSIGN ls_idoc_line-vemng TO <fsi>.  " Picking Quantity
*    write <fsi> to lv_vemng.
        CALL FUNCTION 'Z_CONVERT_TO_ALT_UOM'
          EXPORTING
            material            = ls_idoc_line_temp-matnr
            curr_uom            = ls_idoc_line_temp-vemeh
            curr_qty            = lv_vemng
            new_uom             = ls_idoc_line_temp-vrkme
          IMPORTING
            new_qty             = lv_vemng
          EXCEPTIONS
            curr_uom_not_found  = 1
            new_uom_not_found   = 2
            no_parameters_found = 3
            OTHERS              = 4.

        ls_idoc_line-vemng = lv_vemng .
      ENDIF.
      IF ls_idoc_line-vemng < lv_llfimg  OR
         ls_idoc_line-vemng > lv_hlfimg.
        ls_tolerance_warning-vbeln = ls_idoc_line-vbeln.
        ls_tolerance_warning-posnr = ls_idoc_line-posnr.
        ls_tolerance_warning-vemng = ls_idoc_line-vemng.
        ls_tolerance_warning-lfimg_l = lv_llfimg.
        ls_tolerance_warning-lfimg_h = lv_hlfimg.
        ls_tolerance_warning-matnr = ls_idoc_line_temp-matnr.
        ls_tolerance_warning-vrkme = ls_idoc_line_temp-vrkme.
        APPEND ls_tolerance_warning TO et_tolerance_warning.
        CLEAR ls_tolerance_warning.
      ENDIF.
    ENDAT.

    AT LAST.
* For Information screen
    es_idoc_line-no_of_units =   lv_no_of_units.
    es_idoc_line-gr_vemng_display =  lv_gr_vemng_display.
    es_idoc_line-gr_vemeh_display =  ls_idoc_line_temp-gr_vemeh_display.
    es_idoc_line-nt_vemng_display =  lv_nt_vemng_display.
    es_idoc_line-nt_vemeh_display =  ls_idoc_line_temp-nt_vemeh_display.
*      es_idoc_line-gr_vemng_lbs =  lv_gr_vemng_lbs.
*      es_idoc_line-nt_vemng_lbs =  lv_nt_vemng_lbs.
*      es_idoc_line-gr_vemng_kgs =  lv_gr_vemng_kgs.
*      es_idoc_line-nt_vemng_kgs =  lv_nt_vemng_kgs.
    ENDAT.

  ENDLOOP.
  LOOP AT  it_demand_warning ASSIGNING <ls_demand_warning>.
    CLEAR :   ls_tolerance_warning,
              lv_llfimg,
              lv_hlfimg.
    lv_llfimg = <ls_demand_warning>-lfimg * ( 1 -
    <ls_demand_warning>-untto / 100 )  .  " Lower limit
    lv_hlfimg = <ls_demand_warning>-lfimg * ( 1 +
    <ls_demand_warning>-uebto / 100 ).   " Higher Limit
*
    ls_tolerance_warning-vbeln = <ls_demand_warning>-vbeln.
    ls_tolerance_warning-posnr = <ls_demand_warning>-posnr.
    ls_tolerance_warning-vemng = 0.
    ls_tolerance_warning-lfimg_l = lv_llfimg.
    ls_tolerance_warning-lfimg_h = lv_hlfimg.
    ls_tolerance_warning-matnr = <ls_demand_warning>-matnr.
    ls_tolerance_warning-vrkme = <ls_demand_warning>-vrkme.
    APPEND ls_tolerance_warning TO et_tolerance_warning.
    CLEAR ls_tolerance_warning.
  ENDLOOP.
ENDMETHOD.


METHOD validate_booknum .
***********************************************************************
*  Booking validation and user authorization
***********************************************************************
  DATA : lv_booknum    TYPE zzbooknum,
         lv_str        TYPE string,
         lv_frt        TYPE zsd_book_frtfwd,
         lt_usapp      TYPE tt_usapp,
         ls_usapp      LIKE LINE OF lt_usapp,
         lv_bookdoc    TYPE zsd_book_bookdoc,
         lv_stgloc     TYPE zsd_book_stgloc,
         lv_plant_code TYPE zsd_book_plant_code,
         lv_stmshpline TYPE zsd_dl_book_info-stmshpline,
         lv_count      TYPE i,
         ls_book_itm   TYPE zdl_e1557_sales_order_display,  " CR#09415
         lv_metric_ind TYPE c,                              " CR#09415
         lv_warn       TYPE c VALUE 'N'.                    " CR#09415

  CONSTANTS : lc_yes TYPE c VALUE 'Y'.                      " CR#09415

* Check in zsd_book_hdr  if both booking confirmation number and
* booking document number is valid
  IF iv_booknum IS NOT INITIAL AND
     iv_bookdoc IS NOT INITIAL.
***** Begin of comments by kmadde1 on 5/23/2017 E0VK9A0QMJ
*    SELECT SINGLE bookdoc
*                  booknum
*                  frt_forwarder
*                  stgloc
*                  plant_code
*                  stmshpline    "Booking - Steamship line
*           FROM zsd_book_hdr
*           INTO (lv_bookdoc ,lv_booknum ,lv_frt,lv_stgloc,lv_plant_code,
*                 lv_stmshpline)
*         WHERE booknum = iv_booknum AND
*               bookdoc = iv_bookdoc AND
*               plant_code LIKE '92%'.
*    IF sy-subrc <> 0 .
*      MESSAGE e000 WITH 'Invalid booking confirmation number'(001)
*                        'or booking document number'(002).
*      RETURN.
*    ENDIF.
***** End of comments by kmadde1 on 5/23/2017 E0VK9A0QMJ

***** Begin of changes by kmadde1 on 5/23/2017 E0VK9A0QMJ
* Replace the code to check all the plant with type = 'PORT' in table ZPLANT
* instead of checking only for plants which falls under '92**'

    SELECT SINGLE a~bookdoc
                  a~booknum
                  a~frt_forwarder
                  a~stgloc
                  a~plant_code
                  a~stmshpline
                  INTO (lv_bookdoc ,lv_booknum ,lv_frt,lv_stgloc,lv_plant_code,
                        lv_stmshpline)
                  FROM zsd_book_hdr AS a
                  INNER JOIN zplant AS b
                  ON a~plant_code EQ b~werks
                 WHERE booknum = iv_booknum AND
                       bookdoc = iv_bookdoc AND
                          type = 'PORT'.
    IF sy-subrc <> 0 .
      MESSAGE e000 WITH 'Invalid booking confirmation number'(001)
                        'or booking document number'(002).
      RETURN.
    ENDIF.

***** End of changes by kmadde1 on 5/23/2017 E0VK9A0QMJ

* if only booking confirmation number is entered
* need to check if there are more then one number of booking documents
* associated with the same booking confirmation number. if so flag an
* error
  ELSEIF iv_booknum IS NOT INITIAL.

***** Begin of comments by kmadde1 on 5/23/2017 E0VK9A0QMJ
*    SELECT        bookdoc
*                  booknum
*                  frt_forwarder
*                  stgloc
*                  plant_code
*                  stmshpline    "Booking - Steamship line
*          FROM zsd_book_hdr
*        INTO (lv_bookdoc ,lv_booknum ,lv_frt,lv_stgloc,lv_plant_code,
*                 lv_stmshpline)
*        WHERE booknum = iv_booknum AND
*               plant_code LIKE '92%'.
*      lv_count = lv_count + 1 .
*      IF lv_count > 1 .
*        EXIT.
*      ENDIF.
*    ENDSELECT.
*    IF lv_count = 0 .
*      MESSAGE e000 WITH 'Invalid booking confirmation number'(003).
*      RETURN.
*    ELSEIF lv_count > 1 .
*      MESSAGE e513 WITH '. Please enter booking document number'(048).
*      RETURN.
*    ENDIF.
***** End of comments by kmadde1 on 5/23/2017 E0VK9A0QMJ

***** Begin of changes by kmadde1 on 5/23/2017 E0VK9A0QMJ
* Replace the code to check all the plant with type = 'PORT' in table ZPLANT
* instead of checking only for plants which falls under '92**'
    SELECT a~bookdoc
           a~booknum
           a~frt_forwarder
           a~stgloc
           a~plant_code
           a~stmshpline
           INTO (lv_bookdoc ,lv_booknum ,lv_frt,lv_stgloc,lv_plant_code,
                 lv_stmshpline)
           FROM zsd_book_hdr AS a
           INNER JOIN zplant AS b
           ON a~plant_code EQ b~werks
           WHERE booknum = iv_booknum AND
                    type = 'PORT'.
      lv_count = lv_count + 1 .
      IF lv_count > 1 .
        EXIT.
      ENDIF.
    ENDSELECT.
    IF lv_count = 0 .
      MESSAGE e000 WITH 'Invalid booking confirmation number'(003).
      RETURN.
    ELSEIF lv_count > 1 .
      MESSAGE e513 WITH '. Please enter booking document number'(048).
      RETURN.
    ENDIF.
***** End of changes by kmadde1 on 5/23/2017 E0VK9A0QMJ


* if only booking document number is entered
  ELSEIF iv_bookdoc IS NOT INITIAL.
***** Begin of comments by kmadde1 on 5/23/2017 E0VK9A0QMJ
*    SELECT SINGLE bookdoc
*                 booknum
*                 frt_forwarder
*                 stgloc
*                 plant_code
*                 stmshpline    "Booking - Steamship line
*          FROM zsd_book_hdr
*        INTO (lv_bookdoc ,lv_booknum ,lv_frt,lv_stgloc,lv_plant_code,
*                 lv_stmshpline)
*       WHERE bookdoc = iv_bookdoc AND
*               plant_code LIKE '92%'.
*    IF sy-subrc <> 0 .
*      MESSAGE e000 WITH 'Invalid booking document number'(004).
*      RETURN.
*    ENDIF.
***** End of comments by kmadde1 on 5/23/2017 E0VK9A0QMJ

***** Begin of changes by kmadde1 on 5/23/2017 E0VK9A0QMJ
* Replace the code to check all the plant with type = 'PORT' in table ZPLANT
* instead of checking only for plants which falls under '92**'
    SELECT SINGLE a~bookdoc
                 a~booknum
                 a~frt_forwarder
                 a~stgloc
                 a~plant_code
                 a~stmshpline
          FROM zsd_book_hdr AS a
          INNER JOIN zplant AS b
            ON a~plant_code EQ b~werks
          INTO (lv_bookdoc ,lv_booknum ,lv_frt,lv_stgloc,lv_plant_code,
                 lv_stmshpline)
       WHERE bookdoc = iv_bookdoc AND
               type = 'PORT'.
    IF sy-subrc <> 0 .
      MESSAGE e000 WITH 'Invalid booking document number'(004).
      RETURN.
    ENDIF.
***** End of changes by kmadde1 on 5/23/2017 E0VK9A0QMJ

  ELSE.
* if neither one is entered
    MESSAGE e000 WITH
    'Enter either booking confirmation number'(005)
                      'or booking document number'(006).
  ENDIF.

* check whether the user processing the booking is the freight forwarder
* assigned to the booking
  CALL METHOD zcl_e1557_export_picking=>get_user_ref
    IMPORTING
      et_usapp = lt_usapp.
*
  IF lt_usapp[] IS INITIAL.
    MESSAGE e000 WITH 'User not authorized to'(007)
    'process the booking confirmation'(008)
    iv_booknum.
  ELSE.
    READ TABLE lt_usapp INTO ls_usapp WITH KEY objkey = lv_frt.
    IF sy-subrc <> 0.
      MESSAGE e000 WITH 'User not authorized to'(009)
      'process the booking confirmation'(010)
      iv_booknum.
    ENDIF.
  ENDIF.

*-- Set Default value 'Y' to EV_METRIC_IND.
  MOVE 'Y' TO ev_metric_ind.                                " CR#09415

*-- Start  CR# 10/08/09 MYADAV
*-- Below SELECT Query modified to add Metric Indicator
* get the sales order  associated with this booking number from the
* table zsd_book_itm
*  SELECT  vbeln posnr FROM zsd_book_itm
*     INTO TABLE et_book_itm
*     WHERE  bookdoc = lv_bookdoc.

  SELECT a~vbeln a~posnr b~zz_metric_ind INTO TABLE et_book_itm
    FROM zsd_book_itm AS a INNER JOIN vbap AS b ON  a~vbeln = b~vbeln
    AND  a~posnr = b~posnr
    WHERE bookdoc = lv_bookdoc.
****    and STO_ACTIVE = 'X'.
*-- End  " CR#09415

  IF sy-subrc <> 0 .
    MESSAGE e000 WITH 'No sales order associated with  the'(044)
                      'entered booking document number'(049)
                      ' in table zsd_book_itm'(046).
    RETURN.
  ENDIF.

  CLEAR : ev_book_data .
* get the plant description
  SELECT SINGLE name1 FROM t001w
                INTO ev_book_data-plant_name
                WHERE werks =   lv_plant_code.
* get storge location
  SELECT SINGLE lgobe FROM t001l
                INTO ev_book_data-lgobe
                WHERE werks = lv_plant_code AND
                      lgort = lv_stgloc.

  ev_book_data-bookdoc = lv_bookdoc .
  ev_book_data-booknum = lv_booknum .
  ev_book_data-stgloc  = lv_stgloc.
  ev_book_data-plant_code = lv_plant_code.
  ev_book_data-frt_forwarder  = lv_frt.
  ev_book_data-stmshpline = lv_stmshpline.

*-- Start " CR#09415
*-- Check if all items has same value of Metric Indicator.
  LOOP AT et_book_itm INTO ls_book_itm.
    CLEAR : lv_metric_ind.
    lv_metric_ind = ls_book_itm-zz_metric_ind.
    AT FIRST.
      IF lv_metric_ind NE 'Y' AND lv_metric_ind NE 'N' .
        lv_warn = lc_yes.
        EXIT.
      ENDIF.
    ENDAT.

    IF lv_metric_ind NE ls_book_itm-zz_metric_ind.
      lv_warn = lc_yes.
      EXIT.
    ENDIF.

*    lv_metric_ind = ls_book_itm-zz_metric_ind.
    CLEAR ls_book_itm.
  ENDLOOP.

  IF lv_warn = lc_yes.
    MESSAGE w600 INTO lv_str .
*  Handle message
    zcl_e1557_export_picking=>handle_message( ).
    go_applog->log_update_subscreen( ).
  ELSE.
    ev_metric_ind = lv_metric_ind.
    gv_metric_ind = lv_metric_ind.
  ENDIF.
*-- End " CR#09415

ENDMETHOD.


METHOD validate_delivery .
************************************************************************
* In this method demand is marked X or Y on demand lines IF material is
* a MTS Material showing on Multiple demand lines of same delivery .
* A validation is made such that MTS material will not repeat across
* deliveries . A validation is made that no two demand lines will have
* the same account assignment .
* Locking is made at delivery so that information will not be changed
* after shown on pick screen
************************************************************************
  TYPES : BEGIN OF ts_matnr ,
            matnr TYPE matnr ,
            vbeln TYPE vbeln_vl,
          END OF ts_matnr,

          BEGIN OF ts_temp_asg,
            vbeln TYPE vbeln_vl,
            posnr TYPE posnr,
            vgbel TYPE vgbel ,
            vgpos  TYPE vgpos,
          END OF ts_temp_asg.

  DATA :  lt_matnr TYPE TABLE OF ts_matnr ,
          ls_matnr LIKE LINE OF lt_matnr,
          lt_temp_asg TYPE TABLE OF ts_temp_asg,
          ls_temp_asg LIKE LINE OF lt_temp_asg,
          lt_demand TYPE zdl_e1557_demand,
          lt_messages TYPE zca_message_tab,
          ls_messages TYPE zca_message_str,
          lv_string TYPE string ,
          lv_flag TYPE char01 ,
          lv_str TYPE string ,
          lv_matnr TYPE matnr ,
          lv_asg TYPE string,
          lv_tabix TYPE sy-tabix,
          lv_subrc TYPE sy-subrc,
          lv_msg TYPE string,
          lv_count TYPE i ,
          lv_count1 TYPE i ,
          lv_user   TYPE symsgv.

  FIELD-SYMBOLS : <ls_demand> LIKE LINE OF lt_demand,
                  <ls_matnr> LIKE LINE OF lt_matnr.

* The messages get duplicated  if we call the subscreen repeatedly. to
* take care of that we need to get the existing messages store it in a
* internal table and add it back to app log
  CALL METHOD zcl_e1557_export_picking=>get_message
    RECEIVING
      rt_messages = lt_messages.

  CALL METHOD zcl_e1557_export_picking=>refresh_log.

  LOOP AT lt_messages INTO ls_messages WHERE msgty = 'I'.
    CALL FUNCTION 'FORMAT_MESSAGE'
      EXPORTING
        id        = 'ZSD_DL'
        lang      = sy-langu
        no        = ls_messages-msgno
        v1        = sy-msgv1
        v2        = sy-msgv2
        v3        = sy-msgv3
        v4        = sy-msgv4
      IMPORTING
        msg       = lv_msg
      EXCEPTIONS
        not_found = 1
        OTHERS    = 2.
    IF sy-subrc <> 0.
    ENDIF.
    IF ls_messages-msgno = 504.
      MESSAGE i504  INTO lv_string.
    ELSE.
      MESSAGE i506  INTO lv_string.
    ENDIF.
    zcl_e1557_export_picking=>handle_message( ).
  ENDLOOP.


  lt_demand = it_demand.
  SORT lt_demand BY vbeln posnr matnr sobkz.

* check whether the delivery has been selected by the user
* from the selection screen
  LOOP AT lt_demand ASSIGNING <ls_demand>.
    lv_tabix = sy-tabix.
    READ TABLE it_valid WITH KEY vbeln = <ls_demand>-vbeln
       TRANSPORTING NO FIELDS.
    IF sy-subrc <> 0 .
      DELETE lt_demand WHERE vbeln = <ls_demand>-vbeln.
      CONTINUE.
    ELSE.
*****************************************************************
* there are 2 check for MTS materials
*  a) Material cannot be associated with multiple deliveries - we
*     are checking for that below outside this loop  and passing the
*     entries to a local table
******************************************************************
* send all mts material into another table .
      IF <ls_demand>-sobkz = space.
        ls_matnr-matnr = <ls_demand>-matnr.
        ls_matnr-vbeln = <ls_demand>-vbeln.
        APPEND ls_matnr TO lt_matnr.
        CLEAR ls_matnr.
*************************************************************
* b) we are checking to see if the material is being repeated
*    for different line items in same delivery . that is not an
*    error but we need to identify the same to be used later
*    for our demand alogrithan
*      There are 2 cases
*      1) when there is no repeation
*      2) any repeated occurence of a material within a delivery
*         as 'Y' and the first one as 'X'.
**************************************************************
        IF lv_matnr = <ls_demand>-matnr .
          lv_count1 = lv_count1 + 1 .
          IF lv_count1 = 1.
            lv_tabix = lv_tabix - 1 .
            <ls_demand>-dupli_mts_flag = 'X'.
            MODIFY  lt_demand  FROM <ls_demand>  INDEX  lv_tabix
                      TRANSPORTING   dupli_mts_flag.
            <ls_demand>-dupli_mts_flag = 'Y'.
          ELSE.
            <ls_demand>-dupli_mts_flag = 'Y' .
          ENDIF.
        ENDIF.
        lv_matnr = <ls_demand>-matnr.

      ELSE. " MTO Materials
* ***************************************************************
* There cannot be duplicate account asssignment b/w any delivery
* line items.we are passing all the account assignment into a
* delivery table and reading the internal table for any duplicate
* entries of account assignment. all duplicates are handled  by
* application log
**************************************************************

        READ TABLE lt_temp_asg  INTO ls_temp_asg
                                WITH KEY vgbel =  <ls_demand>-vgbel
                                         vgpos =  <ls_demand>-vgpos.
        IF sy-subrc <> 0 .
          ls_temp_asg-vbeln =  <ls_demand>-vbeln.
          ls_temp_asg-posnr =  <ls_demand>-posnr.
          ls_temp_asg-vgbel =  <ls_demand>-vgbel.
          ls_temp_asg-vgpos =  <ls_demand>-vgpos.
          APPEND ls_temp_asg  TO lt_temp_asg.
          CLEAR ls_temp_asg.
        ELSE.
          CONCATENATE <ls_demand>-vbeln
                      <ls_demand>-posnr
                      ls_temp_asg-vbeln
                      ls_temp_asg-posnr
                      INTO lv_asg SEPARATED BY space.

          MESSAGE e000 WITH  <ls_demand>-vgbel
                            <ls_demand>-vgpos
  'Duplicate Account assignment between'(021)
                             lv_asg
                 INTO lv_string .
          zcl_e1557_export_picking=>handle_message( ).
          lv_subrc = 1 .
        ENDIF.
      ENDIF.
* at end of vbeln
      AT END OF vbeln.
        CLEAR : lv_flag,
                lv_count1,
                lv_matnr,
                lv_tabix.
        CALL FUNCTION 'ENQUEUE_EVVBLKE'
          EXPORTING
            mode_likp      = 'E'
            mandt          = sy-mandt
            vbeln          = <ls_demand>-vbeln
            _scope         = '2'
          EXCEPTIONS
            foreign_lock   = 1
            system_failure = 2
            OTHERS         = 3.
* begin of change / nparchu / 09/24/2008 / TPR 2088
* As per users requirements , raise the error message at the pick level
* if delivery is being used by another user
        IF sy-subrc <> 0.
          WRITE  sy-msgv1 to lv_user.
          MESSAGE e000 WITH  'Deliveries'(052)
                             <ls_demand>-vbeln
                             'is currently being processed by user'(053)
                              lv_user
                 INTO lv_string .
          zcl_e1557_export_picking=>handle_message( ).
          lv_subrc = 1 .

        ENDIF.
* End of change / nparchu / 09/24/2008 / TPR 2088

      ENDAT.
    ENDIF.
  ENDLOOP.

******************************************************************
* delete duplicate entries and check for
  SORT lt_matnr BY  matnr vbeln.
  DELETE ADJACENT DUPLICATES FROM lt_matnr COMPARING  matnr vbeln.
  CLEAR : ls_matnr,
          lv_count.
********************************************************************

  LOOP AT lt_matnr ASSIGNING  <ls_matnr>.
    lv_count = lv_count + 1 .
    CONCATENATE  lv_str <ls_matnr>-vbeln INTO lv_str SEPARATED BY
space.

    AT END OF matnr.
      IF lv_count > 1 .
        MESSAGE e503 WITH   <ls_matnr>-matnr
                            lv_str
                 INTO lv_string .
        zcl_e1557_export_picking=>handle_message( ).
        lv_subrc = 1 .
      ENDIF.

      CLEAR : lv_count ,
              lv_string.
    ENDAT .
  ENDLOOP.

* if no errors then output the table
  IF lv_subrc = 0 .
    et_demand[] = lt_demand[].
  ELSE.
    ev_subrc = lv_subrc.
  ENDIF.

*update the subscreen wih new mssages
  go_applog->log_update_subscreen( ).

ENDMETHOD.
ENDCLASS.

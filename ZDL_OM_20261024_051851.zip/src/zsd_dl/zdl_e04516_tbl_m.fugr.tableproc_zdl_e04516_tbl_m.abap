*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDL_E04516_TBL_M
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDL_E04516_TBL_M    .

  PERFORM TABLEPROC.

ENDFUNCTION.

FUNCTION zsd_dl_e04982_get_order_notes.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IF_SHIPMENT) TYPE  TKNUM
*"     REFERENCE(IF_STOP) TYPE  TSNUM
*"     REFERENCE(PRIORITIZE_UNIQUE) TYPE  CHAR1 DEFAULT 'X'
*"  TABLES
*"      OT_TLINE_SUM STRUCTURE  TLINE OPTIONAL
*"      OT_TLINE_ALL STRUCTURE  TLINE OPTIONAL
*"      OT_DELIVERY TYPE  ZMOS_DELIVERIES_S OPTIONAL
*"      OT_TLINE_ADD STRUCTURE  TLINE OPTIONAL
*"  EXCEPTIONS
*"      INVALID_SHIPMENT_STOP
*"      INVALID_SHIPMENT_ITEM
*"      MISSING_DELIVERIES
*"      NO_BOL_TEXTS_EXIST
*"----------------------------------------------------------------------

  DATA: BEGIN OF t_vttp OCCURS 0,
          tknum LIKE vttp-tknum,
          tpnum LIKE vttp-tpnum,
          vbeln LIKE vttp-vbeln,
        END OF t_vttp.

  DATA: x_vtsp LIKE vtsp,
        t_vtsp LIKE vtsp OCCURS 0.

  DATA: x_lips LIKE lips,
        t_lips LIKE x_lips OCCURS 0.

  DATA: BEGIN OF x_line_sum,
          count    TYPE i,
          tdformat TYPE tdformat,
          tdline   TYPE tdline,
        END OF x_line_sum,
        t_line_sum LIKE x_line_sum OCCURS 0.

*Begin of changes...fadeeb..F01266
  TYPES: BEGIN OF tt_bol_text,
          vbeln TYPE vttp-vbeln,
          td_line TYPE tdline,
         END OF tt_bol_text.
  DATA: it_bol_text TYPE TABLE OF tt_bol_text,
        wa_bol_text TYPE tt_bol_text.
        "ws_bol_text-vbeln type vbeln.  5/2016 cleanup
  DATA: it_final TYPE tline OCCURS 0 WITH HEADER LINE,
        wa_final TYPE tline.
  DATA: lv_tabix TYPE sy-tabix,
        lv_vbeln(10) type c.
*End of changes..fadeeb..F01266

  DATA: x_line     LIKE tline,
        t_line_sub LIKE tline OCCURS 0.

  DATA: l_id     LIKE thead-tdid,
        l_name   LIKE thead-tdname,
        l_object LIKE thead-tdobject.

* Clear output tables
  REFRESH: ot_tline_sum,
           ot_tline_all,
           ot_tline_add.

  REFRESH t_vtsp.

  IF ot_delivery[] IS INITIAL.
    SELECT *
      FROM vtsp
      INTO TABLE t_vtsp
      WHERE tknum = if_shipment
        AND tsnum = if_stop.
    IF sy-subrc = 0.

      SORT t_vtsp BY tknum tpnum.
      DELETE ADJACENT DUPLICATES FROM t_vtsp
          COMPARING tknum
                    tpnum.

* Retrieve deliveries on the shipment
      REFRESH t_vttp.
      SELECT tknum
             tpnum
             vbeln
        FROM vttp
        INTO TABLE t_vttp
        FOR ALL ENTRIES IN t_vtsp
        WHERE tknum = t_vtsp-tknum
          AND tpnum = t_vtsp-tpnum.
      IF sy-subrc = 0.

        SORT t_vttp BY vbeln.
        DELETE ADJACENT DUPLICATES FROM t_vttp
          COMPARING vbeln.

* Retrieve Order numbers and types for selected deliveries
        REFRESH t_lips.
        SELECT *
          FROM lips
          INTO TABLE t_lips
          FOR ALL ENTRIES IN t_vttp
          WHERE vbeln = t_vttp-vbeln.
        IF sy-subrc = 0.

          SORT t_lips BY vgbel.
          DELETE ADJACENT DUPLICATES FROM t_lips COMPARING vgbel.

        ELSE.
          RAISE missing_deliveries.
        ENDIF.

      ELSE.
        RAISE invalid_shipment_item.
      ENDIF.

    ELSE.
      RAISE invalid_shipment_stop.
    ENDIF.

  ELSE.
    REFRESH t_lips.
    SELECT *
      FROM lips
      INTO TABLE t_lips
      FOR ALL ENTRIES IN ot_delivery
      WHERE vbeln = ot_delivery-vbeln.
    IF sy-subrc = 0.

      SORT t_lips BY vgbel.
      DELETE ADJACENT DUPLICATES FROM t_lips COMPARING vgbel.

    ELSE.
      RAISE missing_deliveries.
    ENDIF.

  ENDIF.

* At this point, we have a list of unique Order numbers in T_VTTP
* Retrieve all relevant BOL notes based on order type
  LOOP AT t_lips INTO x_lips.

* Determine where to get the texts from based on order doc. type
    CLEAR: l_id,
           l_object.
    CASE x_lips-vgtyp.
      WHEN 'C'.
        l_id     = 'ZBOL'.
        l_object = 'VBBK'.
      WHEN 'I'.
        l_id     = 'ZBOL'.
        l_object = 'VBBK'.
      WHEN 'V'.
        l_id     = 'F40'.
        l_object = 'EKKO'.
    ENDCASE.

    CLEAR l_name.
    l_name = x_lips-vgbel.

* Call function READ_TEXT to retrieve texts/notes
    REFRESH t_line_sub.
    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        id                      = l_id
        language                = sy-langu
        name                    = l_name
        object                  = l_object
      TABLES
        lines                   = t_line_sub
      EXCEPTIONS
        id                      = 1
        language                = 2
        name                    = 3
        not_found               = 4
        object                  = 5
        reference_check         = 6
        wrong_access_to_archive = 7
        OTHERS                  = 8.
    IF sy-subrc = 0.

* Count the number of times messages repeat, summing them by content
      CLEAR: x_line,
             x_line_sum.
      LOOP AT t_line_sub INTO x_line.
*  Begin of changes...fadeeb..F01266
* The below logic is to collect the texts and format it in the way that vbeln is prefixed to the text only
*  if it is a unique text else the vbeln is not prefixed.
        lv_tabix = sy-tabix.
        READ TABLE it_bol_text INTO wa_bol_text WITH KEY td_line = x_line-tdline.
        IF sy-subrc EQ 0.
          CLEAR  wa_bol_text-vbeln.
          MODIFY it_bol_text FROM wa_bol_text INDEX sy-tabix.
          MOVE wa_bol_text-td_line TO wa_final-tdline.
*     It_final is the table used to populate the texts without VBELN
*     above the ones which have the VBELN prefixed
           COLLECT wa_final INTO it_final.
        ELSE.
* Populate order number only for 1st line of text
          MOVE x_lips-vgbel TO wa_bol_text-vbeln.
          MOVE x_line-tdline TO wa_bol_text-td_line.
          APPEND wa_bol_text TO it_bol_text.
          CLEAR wa_bol_text.
        ENDIF.
* End of changes..fadeeb..F01266
        x_line_sum-count = 1.
        x_line_sum-tdformat = x_line-tdformat.
        x_line_sum-tdline = x_line-tdline.
        COLLECT x_line_sum INTO t_line_sum.
        CLEAR x_line_sum.

* Temporarily store all the original texts in order of appearance for
*    reference
        APPEND x_line TO ot_tline_all.
        CLEAR x_line.
      ENDLOOP. " at T_LIPS
    ENDIF.
  ENDLOOP.

* Begin of changes..fadeeb..F01266
* Populate the final table with texts without vbeln first
  LOOP AT it_final INTO wa_final.
    ot_tline_add-tdline = wa_final-tdline.
    APPEND ot_tline_add.
  ENDLOOP.

  LOOP AT it_bol_text INTO wa_bol_text.
* Populate the texts of all orders in the final table ot_tline_add.
    READ TABLE it_final INTO wa_final WITH KEY tdline = wa_bol_text-td_line.
    IF sy-subrc NE 0.
      IF wa_bol_text-vbeln IS NOT INITIAL and
        wa_bol_text-vbeln <> lv_vbeln.
        lv_vbeln = wa_bol_text-vbeln.
        SHIFT wa_bol_text-vbeln LEFT DELETING LEADING '0'.
        CONCATENATE '#' wa_bol_text-vbeln ';' wa_bol_text-td_line INTO wa_final-tdline.
        MOVE wa_final-tdline TO ot_tline_add-tdline.
      else.
        MOVE wa_bol_text-td_line TO ot_tline_add-tdline.
      ENDIF.
      APPEND ot_tline_add.
    ENDIF.
  ENDLOOP.
* End of changes...fadeeb..F01266
  DELETE ot_tline_add WHERE tdline IS INITIAL.

* T_LINE_SUM: Count of all the texts from every sales order attached
*   to the shipment
* T_LINE: All texts from every sales order attached to the shipment

* Display texts in order of
  IF NOT prioritize_unique IS INITIAL.
    SORT t_line_sum BY count ASCENDING.
  ENDIF.
  CLEAR x_line.
  LOOP AT t_line_sum INTO x_line_sum.
    x_line-tdformat = x_line_sum-tdformat.
    x_line-tdline   = x_line_sum-tdline.
    APPEND x_line TO ot_tline_sum.
    CLEAR x_line.
  ENDLOOP. " at t_line_sum

  IF   ot_tline_all[] IS INITIAL
   AND ot_tline_sum[] IS INITIAL.
    RAISE no_bol_texts_exist.
  ENDIF.

ENDFUNCTION.

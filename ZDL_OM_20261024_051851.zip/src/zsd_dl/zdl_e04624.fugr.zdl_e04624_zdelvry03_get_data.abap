FUNCTION zdl_e04624_zdelvry03_get_data.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IV_DOCNUM) TYPE  EDI_DOCNUM
*"  EXPORTING
*"     REFERENCE(ES_DATA) TYPE  ZDL_E04624_DATA
*"  EXCEPTIONS
*"      INVALID_IDOC
*"----------------------------------------------------------------------
* created 09/03/2010 for R18 March 2011
* created by Maureen Carter
* COR #E04624
* Description:  Read idoc ZDELVRY03_GR for specific fields needed for
*    the workflow error process.  Main use is for Trades GR
*-----------------------------------------------------------------------
* change history -


*-----------------------------------------------------------------------
  DATA :
         ls_edidc   TYPE edidc,
         lt_edidd   TYPE edidd_tt,
         ls_edidd   TYPE edidd,
         ls_e1edl20 TYPE e1edl20,
         ls_e1txth8 TYPE e1txth8,
         ls_e1edl24 TYPE e1edl24,
         ls_e1edl15 TYPE e1edl15,
         ls_e1edl37 TYPE e1edl37,
         ls_e1edl44 TYPE e1edl44,
         ls_data    TYPE zdl_e04624_data.

* Retrieve Idoc Control Record
  CALL FUNCTION 'EDI_DOCUMENT_OPEN_FOR_READ'
    EXPORTING
      document_number         = iv_docnum
      db_read_option          = 'Y'
    IMPORTING
      idoc_control            = ls_edidc
    EXCEPTIONS
      document_foreign_lock   = 1
      document_not_exist      = 2
      document_number_invalid = 3
      OTHERS                  = 4.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ENDIF.

* Retrieve Idoc Segment Data
  CALL FUNCTION 'EDI_SEGMENTS_GET_ALL'
    EXPORTING
      document_number         = iv_docnum
    TABLES
      idoc_containers         = lt_edidd
    EXCEPTIONS
      document_number_invalid = 1
      end_of_document         = 2
      OTHERS                  = 3.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ENDIF.

* Close Idoc after usage
  CALL FUNCTION 'EDI_DOCUMENT_CLOSE_READ'
    EXPORTING
      document_number   = iv_docnum
    EXCEPTIONS
      document_not_open = 1
      parameter_error   = 2
      OTHERS            = 3.
  IF sy-subrc <> 0.
    RAISE invalid_idoc.
    RETURN.
  ENDIF.

* Retrieve specific idoc information
  READ TABLE lt_edidd INTO ls_edidd WITH KEY segnam = 'E1TXTH8'.
  IF sy-subrc = 0.
  ENDIF.

  LOOP AT lt_edidd INTO ls_edidd.
    CASE ls_edidd-segnam.
      WHEN 'E1EDL20'.
        ls_e1edl20 = ls_edidd-sdata.
        ls_data-bolnr = ls_e1edl20-bolnr.  "bol
        ls_data-traid  = ls_e1edl20-traid. "transport id
*        ls_data-ipco = ls_e1edl20-vbeln.    "IPCO
      WHEN 'E1TXTH8'.
        ls_e1txth8 = ls_edidd-sdata.
        CASE ls_e1txth8-tdid.
          WHEN 'VEND'.
            ls_data-lifnr = ls_e1txth8-tdobname.    "legacy vendor
          WHEN 'GRAD'.
            ls_data-grade = ls_e1txth8-tdobname.    "grade
          WHEN 'VBAT'.
            ls_data-batch = ls_e1txth8-tdobname.    "batch#
          WHEN 'IPCO'.
            ls_data-ipco = ls_e1txth8-tdobname.     "ipco#
        ENDCASE.
      WHEN 'E1EDL24'.
        ls_e1edl24 = ls_edidd-sdata.
        ls_data-wgt = ls_e1edl24-lgmng.          "weight
        ls_data-wgt_uom = ls_e1edl24-meins.      "weight uom
      WHEN 'E1EDL15'.
        ls_e1edl15 = ls_edidd-sdata.
        IF ls_e1edl15-atnam = 'ROLL_WIDTH'.      "roll width
          ls_data-width = ls_e1edl15-atwrt.
        ENDIF.
      WHEN 'E1EDL37'.
        ls_e1edl37 = ls_edidd-sdata.
        ls_data-linealft = ls_e1edl37-laeng.     "linealfeet
      WHEN 'E1EDL44'.
        ls_e1edl44 = ls_edidd-sdata.
        ls_data-werks = ls_e1edl44-werks.        "plant
    ENDCASE.
  ENDLOOP.

* Format export structure of data
  es_data = ls_data.


ENDFUNCTION.

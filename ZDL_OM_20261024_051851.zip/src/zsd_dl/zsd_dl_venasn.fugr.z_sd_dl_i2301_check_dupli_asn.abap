function z_sd_dl_i2301_check_dupli_asn.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  EXPORTING
*"     REFERENCE(EX_FLAG) TYPE  FLAG
*"  TABLES
*"      IT_ASNINFO STRUCTURE  ZDL_ASNINFO
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"----------------------------------------------------------------------
* Programmer: Subba R Boyalla                     Date:  03/15/2005    *
*                                                                      *
* Description:  This function module is used to validate duplicate     *
*                BOL # against BOL/PO/Material/Unit id,                *
*                if the delivery is created for above parameters the   *
*                Funtion Module would return Delivery number with flag *
*                indicator                                             *
*                                                                      *
*                                                                      *
* Bruce C Ballehr    04/29/08  EDVK962009  / BCB01 / CR7631            *
*                                                                      *
*                              When checking a duplicate, we compare   *
*                              the following fields:                   *
*                              - BOL                                   *
*                              - PO                                    *
*                              - Material                              *
*                              - Vendor Batch                          *
*                                                                      *
*                              When retrieving HU's (to compare the    *
*                              Vendor Batch which is stored in field   *
*                              VEKP-INHALT) we only SELECT HU's that   *
*                              are assigned to an Inbound Delivery     *
*                              (VEKP-VPOBJ = '03'). We need to make    *
*                              sure a dup doesn't occur where the HU   *
*                              was part of an Inbound Delivery was     *
*                              already GR'd (VEKP-VPBOJ = '12) and the *
*                              HU is in an 'non assigned' status. In   *
*                              both cases (the '03' and '12) the value *
*                              in VEKP-VPOBJKEY is the Inbound         *
*                              Delivery.                               *
*                                                                      *
*                              NOTE: This logic is similar to logic in *
*                                    function module                   *
*                                    Z_DL_E03126_UNIT_ID_CHECK so if   *
*                                    changes are made to this logic    *
*                                    here then similar changes might   *
*                                    be needed in that function as     *
*                                    well.                             *
*                                                                      *
*Helena Malkowska 01/2021 2000012354 If it is 3PP PO then skip HU check*
*----------------------------------------------------------------------*
* Change History
*----------------------------------------------------------------------*

*Constant Declaration--------------------------------------------------*
  constants:  c_flag type flag   value 'X'.     " Flag Indicator
*             c_obj  TYPE char2  VALUE '03',    " Object indicator BCB01

* Begin BCB01
  constants:
    lc_assigned_to_inbound  type vpobj value '03', "Inbound
    lc_non_assigned         type vpobj value '12', "Non-Assigned HU
* End BCB01
***** 2000012354 - start
    lc_assigned_to_outbound type vpobj value '01'. "Outbound

data: lv_3pp  type abap_bool.
***** 2000012354 - end

*Variable Declaration--------------------------------------------------*
  data     v_index type sy-tabix.        " System Index

*-Types Declaration----------------------------------------------------*
* Types to store delivery #,item,material number and purchase order#
  types: begin of ty_lips,
           vbeln type vbeln_vl,
           posnr type posnr_vl,
           matnr type matnr,
           vgbel type vgbel,
        end of ty_lips.

* Types to store delivery number and bill of lading number
  types: begin of ty_likp,
           vbeln type vbeln_vl,
           bolnr type bolnr,
        end of ty_likp.

* Types to store handling unit number,vendor unit number and objects
  types: begin of ty_vekp,
         venum type venum,
         exidv type venum,
         inhalt type inhalt,
         vpobj  type vpobj,
         vpobjkey type vpobjkey,
        end of ty_vekp.

* Types to store convertion object
  types: begin of ty_obj,
           object type vpobjkey,
         end of ty_obj.

*------Internal Table Declaration-----------------------------------------*

*Internal Table to store Handling Unit data
  data int_vekp type standard table of ty_vekp initial size 0
                                            with header line.

*Internal table to store Delivery header data
  data int_likp type standard table of ty_likp initial size 0
                                            with header line.

*Internal table to store Delivery item data
  data int_lips type standard table of ty_lips initial size 0
                                             with header line.

*Internal table to store temp object convertion data
  data int_obj type standard table of ty_obj initial size 0
                                           with header line.

* Clear and re fresh all tables
  clear: int_likp,
         int_lips,
         int_vekp,
         int_obj,
         ex_flag.

  refresh: int_likp,
           int_lips,
           int_vekp,
           int_obj.

  if not it_asninfo[] is initial.
***** 2000012354 - start
    perform check_3pp_po tables it_asninfo using ex_flag lv_3pp.
    if lv_3pp = 'X'.
      return.
    endif.
***** 2000012354 - end
* Read Delivery data using bill of lading number
    select vbeln           " Delivery Number
           bolnr           " Bill of landing number
      from likp
      into table int_likp
      for all entries in it_asninfo
      where bolnr = it_asninfo-bolnr.
    if sy-subrc = 0.
*   Read Delivery Item data
      select vbeln
             posnr         " Delivery number
             matnr         " Material Number
             vgbel         " Purchase Order Numberr
      from lips
      into table int_lips
      for all entries in int_likp
      where vbeln = int_likp-vbeln.
      if sy-subrc = 0.
*     Do convertion for object key
        loop at int_likp.
          move int_likp-vbeln to int_obj-object.
          append int_obj.
        endloop.
*     Read Handling unit header data
        select venum         " Handling Unit internal number
               exidv         " handling unit external number
               inhalt        " Vendor Unit id
               vpobj         " Object type
               vpobjkey      " Object Key
          from vekp          " Handling Unit
          into table int_vekp
          for all entries in int_obj
*       Begin BCB01
          where ( vpobj = lc_assigned_to_inbound or
                  vpobj = lc_non_assigned )
            and vpobjkey = int_obj-object.
*          WHERE vpobj =  c_obj AND
*                vpobjkey = int_obj-object.
*       End BCB01
      endif.

      clear v_index.
*     Check all Bill of Lading numbers
      loop at it_asninfo.
        v_index =  sy-tabix.
*       There could be multiple delivery numbers per bill of lading
*       check all delivery number against material,delivery and PO
        loop at int_likp where bolnr = it_asninfo-bolnr.

          read table int_lips with key vbeln = int_likp-vbeln
                                       matnr = it_asninfo-matnr
                                       vgbel = it_asninfo-vgbel.
          if sy-subrc = 0.
            "Handling Unit Check
            read table int_vekp with key inhalt   = it_asninfo-inhalt
*                                          vpobj    = c_obj   "BCB01
                                         vpobjkey = int_lips-vbeln.
            if sy-subrc  = 0.
              ex_flag          = c_flag.
              it_asninfo-flag  = c_flag.
              it_asninfo-vbeln = int_likp-vbeln.
              modify it_asninfo index v_index transporting vbeln flag.
            endif.
          endif.
        endloop.
      endloop.
    endif.
  else.
    raise wrong_function_called.
  endif.
endfunction.

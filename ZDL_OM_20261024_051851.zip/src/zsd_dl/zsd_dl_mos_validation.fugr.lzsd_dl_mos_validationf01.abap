*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_MOS_VALIDATIONF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  POPULATE_T_ITINERARY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_T_ITINERARY  text
*      <--P_LV_IS_VTTS  text
*----------------------------------------------------------------------*
FORM populate_t_itinerary  TABLES   p_t_itinerary STRUCTURE gs_itinerary
                           USING    p_is_vtts TYPE vtts.

  CALL FUNCTION 'ZSD_DL_MOS_ITINERARY_VIEW'
    EXPORTING
      i_tknum                        = p_is_vtts-tknum
    TABLES
      t_itinerary                    = p_t_itinerary
    EXCEPTIONS
      invalid_input                  = 1
      shipment_not_found             = 2
      no_deliveries_found            = 3
      no_stages_on_shipment          = 4
      no_authority                   = 5
      deliveries_unassigned_to_stage = 6
      flex_multi_origin_not_allowed  = 7
      OTHERS                         = 8.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.


ENDFORM.                    " POPULATE_T_ITINERARY
*&---------------------------------------------------------------------*
*&      Form  GET_LIKP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_likp .

  SELECT vbeln  vstel btgew lgnum FROM likp INTO TABLE gt_likp
    FOR ALL ENTRIES IN gt_total_deliveries
    WHERE vbeln = gt_total_deliveries-vbeln.
  IF sy-subrc = 0 .
    SORT gt_likp BY vbeln.
    DELETE ADJACENT DUPLICATES FROM gt_likp COMPARING vbeln.
  ENDIF.

ENDFORM.                    " GET_LIKP
*&---------------------------------------------------------------------*
*&      Form  GET_LIPS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_lips .

  SORT gt_stage_deliveries BY vbeln.
  DELETE ADJACENT DUPLICATES FROM gt_stage_deliveries
       COMPARING vbeln.

* Retrieve all Delivery Line item information based on the Deliveries
* on this particular Stage
  SELECT a~vbeln "delivery
         a~posnr "delivery item
         a~matnr "material
         a~charg "batch
         a~zzlfimg "original quantity in sales uom
         a~lfimg   "current quantity in sales uom
         a~uecha "higher-level item of batch split item
         a~pstyv "item category BCB08 insert
         b~kosta "picking status
         b~pksta "packing status
    INTO TABLE gt_lips
    FROM lips AS a INNER JOIN vbup AS b
    ON a~vbeln = b~vbeln AND "delivery
       a~posnr = b~posnr "delivery item
    FOR ALL ENTRIES IN gt_stage_deliveries
    WHERE a~vbeln = gt_stage_deliveries-vbeln.

  DELETE gt_lips WHERE pstyv = gc_tatx.  "BCB08 insert

  SORT gt_lips BY vbeln posnr.

ENDFORM.                    " GET_LIPS
*&---------------------------------------------------------------------*
*&      Form  GET_LTAP
*&---------------------------------------------------------------------*
*       Get TO Item data based on the Delivery Items on the stage
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_ltap  USING ls_item_obj TYPE zdl_delivery_item_obj_s.

  TYPES: BEGIN OF lts_tanum,
           tanum TYPE tanum, "to number
         END OF lts_tanum.

  DATA :

    lt_tanum TYPE STANDARD TABLE OF lts_tanum,
    lv_lgnum TYPE lgnum.


* Retrieve the Warehouse for this Delivery / Item
  lv_lgnum = ls_item_obj-item_object->get_lgnum( ).

* Retrieve all TO's for this Delivery / Item
  lt_tanum = ls_item_obj-item_object->get_all_tanum( ).

* Retrieve relevant TO Item data for this Delivery Item
* CMS: 26481| Changed By: AMAOLE1| Changed On: 03/18/2014
* Performance Fix: Check if driver table LT_TANUM is initial
* before using selecting using FOR ALL ENTRIES statement
  IF lt_tanum[] IS NOT INITIAL.
    SELECT lgnum
           tanum
           tapos
           vbeln
           posnr
           kzdif
        FROM  ltap
        INTO TABLE gt_ltap
       FOR ALL ENTRIES IN lt_tanum
        WHERE lgnum = lv_lgnum
          AND tanum = lt_tanum-tanum.
  ENDIF.

ENDFORM.                    " GET_LTAP
*&---------------------------------------------------------------------*
*&      Form  GET_T336T
*&---------------------------------------------------------------------*
*       Get the Reason Code text for the Difference Indicators
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_t336t .

* Only perform if facility is a WM facility
  CHECK gv_facility = c_wm.

  CLEAR: gt_t336t.

* Retrieve all of the Difference reason descriptions
  SELECT lgnum
          kzdif "Difference indicator
          dtext "Reason code text
     FROM t336t
     INTO TABLE gt_t336t
     WHERE spras = sy-langu. "system language

ENDFORM.                                                    " GET_T336T
*&---------------------------------------------------------------------*
*&      Form  MOVE_DELIVERIES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM move_deliveries .

  DATA : ls_itinerary        TYPE zmos_itinerary,
         ls_stage_deliveries TYPE  ts_stage_deliveries,
         ls_total_deliveries TYPE ts_total_deliveries,
         ls_deliveries       TYPE LINE OF zmos_itinerary-deliveries.


  LOOP AT gt_itinerary INTO ls_itinerary.
*   Check if the stage being read  in the itinerary is greater
*   then the stage being send through BOl . if yes exit out the
*   itinerary loop.
    CHECK  ls_itinerary-seqnm  LE is_vtts-zz_stopnum_o   .

*   Get Total Deliveries
    LOOP AT ls_itinerary-deliveries INTO ls_deliveries.
*     if the stage is the stage being read in BOl move
*     the deliveries to the stage deliveries table
      IF ls_itinerary-seqnm EQ is_vtts-zz_stopnum_o.
        ls_stage_deliveries-vbeln = ls_deliveries-vbeln.
        ls_stage_deliveries-dstst = ls_deliveries-dstst.
        APPEND ls_stage_deliveries TO gt_stage_deliveries.
        CLEAR ls_stage_deliveries.
      ENDIF.
*     move the deliveries to the total deliveries table
      ls_total_deliveries-vbeln = ls_deliveries-vbeln.
      ls_total_deliveries-dstst = ls_deliveries-dstst.
      APPEND ls_total_deliveries TO gt_total_deliveries.
      CLEAR  ls_total_deliveries.
    ENDLOOP.
  ENDLOOP.

ENDFORM.                    " MOVE_DELIVERIES
*&---------------------------------------------------------------------*
*&      Form  PREPARE_ITEM_STATUS
*&---------------------------------------------------------------------*
*       Generate a table of Delivery Item status at the Delivery's
*       "Parent" Item level. Some items may be batch split and some may
*       not be.
*----------------------------------------------------------------------*
FORM prepare_item_status
       USING lt_item_obj TYPE zdl_delivery_item_obj_t."delivery item obj

  DATA :

    ls_item_status TYPE zdl_delivery_item_status,
    ls_item_obj    TYPE zdl_delivery_item_obj_s, "delivery item obj
    ls_picked_qty  TYPE zdl_delivery_item_open_qty_s, "pick qty struc
    ls_delv_qty    TYPE zdl_delivery_item_open_qty_s, "delivery qty str

    lt_lips        TYPE STANDARD TABLE OF ts_lips,
    ls_lips        TYPE ts_lips,

    lv_delv_qty    TYPE komng. "Delivery item qty


* Copy table of Delivery Item to a work table
  lt_lips[] = gt_lips[].

* Process each Delivery Item Parent.
  LOOP AT gt_lips INTO gs_lips WHERE uecha IS INITIAL.

    CLEAR: ls_item_status,
           lv_delv_qty.

    ls_item_status-stop_number = is_vtts-zz_stopnum_o.
    ls_item_status-vbeln = gs_lips-vbeln.
    ls_item_status-posnr = gs_lips-posnr.
    ls_item_status-matnr = gs_lips-matnr.
    ls_item_status-original_qty = gs_lips-zzlfimg. "original quantity

*   Retrieve Delivery Item Picking Quantity and Delivery Qty
    READ TABLE lt_item_obj INTO ls_item_obj
      WITH KEY vbeln = gs_lips-vbeln  "Delivery
               posnr = gs_lips-posnr. "Delivery item
    IF sy-subrc = 0.
*     Picking Qty
      ls_picked_qty = ls_item_obj-item_object->get_tot_picked_qty( ).
      ls_item_status-picked_qty = ls_picked_qty-in_vrkme."sales pick qty

*     SAP does a strange thing:
*     The Picked Qty in Sales UOM value will be blank on this return
*     structure if the Sales UOM is the same as the Base UOM. If this
*     occurs we need to just retrieve the Base Qty picked
      IF ls_picked_qty-in_vrkme IS INITIAL AND
         ls_picked_qty-vrkme = ls_picked_qty-meins.
        ls_item_status-picked_qty = ls_picked_qty-in_meins. "base qty
      ENDIF.

*     Delivery Item Qty
      ls_delv_qty = ls_item_obj-item_object->get_curr_delv_qty( ).
      lv_delv_qty = ls_delv_qty-in_vrkme."deliv item qty in sales uom

*     SAP does a strange thing:
*     The Qty in Sales UOM value will be blank on this return
*     structure if the Sales UOM is the same as the Base UOM. If this
*     occurs we need to just retrieve the Base Qty
      IF ls_delv_qty-in_vrkme IS INITIAL AND
         ls_delv_qty-vrkme = ls_delv_qty-meins.
        lv_delv_qty = ls_delv_qty-in_meins. "base qty
      ENDIF.
    ENDIF.

*   Filter our 0-picked Delivery Items: If both the Delivery Qty and
*   Picked Qty are 0 then this is considered 0-Picked.
    IF ls_item_status-picked_qty IS INITIAL AND
       lv_delv_qty IS INITIAL.
      CONTINUE.
    ENDIF.

*   Default Picking and Packing Status to 'Y' (Complete)
    ls_item_status-kosta = c_y.
    ls_item_status-pksta = c_y.

*   If this Parent is Batch Split
    LOOP AT lt_lips INTO ls_lips
      WHERE vbeln = gs_lips-vbeln  "Delivery
        AND uecha = gs_lips-posnr. "Parent Item

*     If Picking Status not Complete then set to 'N' (Not Complete)
      IF ls_lips-kosta NE c_complete. " 'C'
        ls_item_status-kosta = c_n.
      ENDIF.

*     If Packing Status not Complete then set to 'N' (Not Complete)
      IF ls_lips-pksta NE c_complete. " 'C'
        ls_item_status-pksta = c_n.
      ENDIF.
    ENDLOOP. " lt_lips - table of Parent delivery item info

*   If this Parent is NOT Batch Split --> use main table
    IF sy-subrc NE 0. "Not batch split

*     If the Picking status is Complete then set flag to 'Y'.
*     Otherwise, set flag to 'N'
      IF gs_lips-kosta = c_complete. " 'C'
        ls_item_status-kosta = c_y.
      ELSE.
        ls_item_status-kosta = c_n.
      ENDIF.

*     If the Packing status is Complete then set flag to 'Y'.
*     Otherwise, set flag to 'N'
      IF gs_lips-pksta = c_complete. " 'C'
        ls_item_status-pksta = c_y.
      ELSE.
        ls_item_status-pksta = c_n.
      ENDIF.
    ENDIF.

*   Only perform if facility is a WM facility
    IF gv_facility = c_wm.

*     Calculate the Difference in Original Qty vs. Picked Qty for each
*     Parent Delivery Item
      ls_item_status-difference = ls_item_status-original_qty -
                                  ls_item_status-picked_qty.

*     Retrieve TO Confirmed Indicator status for Parent Items
      PERFORM fill_to_confirmed_status
                               USING ls_item_obj "gs_lips
                               CHANGING ls_item_status.

*     Retrieve the Reason Code for Picking difference for Parnet Items
      PERFORM get_reason_code USING ls_item_obj "delivery item obj
                                    gs_lips
                           CHANGING ls_item_status.
    ENDIF.

*   Determine if the Delivery Line item has open quantity
    PERFORM check_item_open_qty
                             USING ls_item_obj "gs_lips
                             CHANGING ls_item_status.

*   Set various text fields and statuses based on the delivery item's
*   Picking and Packing indicators
    PERFORM set_text_fields CHANGING ls_item_status.

*   Build Delivery Item table at Parent Item level
    APPEND ls_item_status TO et_delivery_item_status.

  ENDLOOP. " gt_lips  - detailed table of delivery items

ENDFORM.                    " PREPARE_ITEM_STATUS
*&---------------------------------------------------------------------*
*&      Form  GET_FACILITY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_facility .

  DATA : ls_stage_deliveries TYPE ts_stage_deliveries,
         ls_likp             TYPE ts_likp,
         lv_werks            TYPE werks_d,
         lv_type             TYPE zzco_plant_type.

* read the first delivery of the stage
  READ TABLE gt_stage_deliveries INTO ls_stage_deliveries INDEX 1.
* get the vstel for tha tdelivery
  READ TABLE gt_likp INTO ls_likp
         WITH KEY vbeln = ls_stage_deliveries-vbeln.
  IF ls_likp-lgnum IS NOT INITIAL.
    gv_facility = 'WM'.
  ELSE.
    SELECT SINGLE werks FROM tvswz
                  INTO lv_werks
      WHERE vstel = ls_likp-vstel.
    IF sy-subrc = 0 .
      SELECT SINGLE type FROM zplant
             INTO lv_type
           WHERE werks = lv_werks.
      IF sy-subrc = 0 .
        gv_facility = lv_type.
      ENDIF.
    ENDIF.
  ENDIF.

  IF gv_facility IS INITIAL.
    RAISE facility_not_found.
  ENDIF.

ENDFORM.                    " GET_FACILITY
*&---------------------------------------------------------------------*
*&      Form  PREPARE_HEADER_STATUS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM prepare_header_status .

  DATA : ls_likp             TYPE ts_likp,
         ls_header_status    TYPE zdl_delivery_header_status,
         ls_item_status      TYPE zdl_delivery_item_status,

         ls_stage_deliveries TYPE ts_stage_deliveries.


* Process each Delivery
  LOOP AT gt_likp INTO ls_likp.

    CLEAR: ls_header_status.

*   Process the Deliveries for that stop .
    READ TABLE gt_stage_deliveries INTO ls_stage_deliveries
       WITH KEY vbeln = ls_likp-vbeln.
    IF sy-subrc = 0 .
      ls_header_status-vbeln = ls_likp-vbeln.
      ls_header_status-stop_number = is_vtts-zz_stopnum_o.
      ls_header_status-btgew = ls_likp-btgew.

*     Format the Picking Status
      READ TABLE et_delivery_item_status INTO ls_item_status
        WITH KEY vbeln = ls_stage_deliveries-vbeln "Delivery
                 kosta = 'N'. "Pick complete indicator
      IF sy-subrc = 0.
*       If any item for this Delivery is not completely picked
        ls_header_status-kosta = c_n.
      ELSE.
*       All items for this Delivery are completely picked
        ls_header_status-kosta = c_y.
      ENDIF.

*     Format the Packing Status
      READ TABLE et_delivery_item_status INTO ls_item_status
        WITH KEY vbeln = ls_stage_deliveries-vbeln "Delivery
                 pksta = 'N'. "Pack complete indicator
      IF sy-subrc = 0.
*       If any item for this Delivery is not completely packed
        ls_header_status-pksta = c_n.
      ELSE.
*       All items for this Delivery are completely packed
        ls_header_status-pksta = c_y.
      ENDIF.

*     Set Overall Status Text and Overall Status of Reference
      IF ls_header_status-kosta = c_y AND
         ls_header_status-pksta = c_y.
*       If the Delivery Item is fully picked and fully packed
        ls_header_status-overall_status = 'Complete'.
        ls_header_status-rfgsa = c_y.
      ELSE.
*       If the Delivery Item is neither completely picked nor
*       completely packed
        ls_header_status-overall_status = 'Not Complete'.
        ls_header_status-rfgsa = c_n.
      ENDIF.

      APPEND ls_header_status TO et_delivery_header_status.
    ENDIF.

*   Calcualte the Total Weight of all the Deliveries on the Stage
    gv_total_weight = gv_total_weight + ls_likp-btgew.

  ENDLOOP.

ENDFORM.                    " PREPARE_HEADER_STATUS
*&---------------------------------------------------------------------*
*&      Form  ship_header_status
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM ship_header_status .

  DATA : lv_magew TYPE magew_vekp,
         lv_gewei TYPE gewei.


  es_ship_header_status-tknum = is_vtts-tknum.
  es_ship_header_status-btgew = gv_total_weight.

  IF gv_total_weight IS NOT INITIAL.
    SELECT SINGLE magew
                  gewei
        FROM vekp
      INTO (lv_magew , lv_gewei)
      WHERE  vpobj = '04' AND  "assigned to a Shipment
             vpobjkey = is_vtts-tknum  AND
             vhart   = 'TPVS'.
    IF sy-subrc = 0 .

      es_ship_header_status-magew = lv_magew.
      es_ship_header_status-gewei = lv_gewei.
      IF gv_total_weight > lv_magew .
        es_ship_header_status-weight_status = c_n.
        es_ship_header_status-weight_status_text = 'Overweight'.
        es_ship_header_status-weight_english_error =
        'Vehicle Overweight'.
        IF es_ship_header_status-overall_shipment_message IS INITIAL.
          es_ship_header_status-overall_shipment_message =
            'Vehicle Overweight'.
          es_ship_header_status-overall_shipment_message_type = c_s.
        ENDIF.
      ELSE.
        es_ship_header_status-weight_status = c_y.
        es_ship_header_status-weight_status_text = 'Weight allowed'.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " ship_header_status
*&---------------------------------------------------------------------*
*&      Form  GET_REASON_CODE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LS_LIPS  text
*----------------------------------------------------------------------*
FORM get_reason_code  USING     ls_item_obj TYPE zdl_delivery_item_obj_s
                                ls_lips TYPE ts_lips
                       CHANGING ls_item_status TYPE
                       zdl_delivery_item_status.

  DATA :

    ls_ltap       TYPE ts_ltap,

    ls_t336t      TYPE  ts_t336t,

    lv_prev_kzdif TYPE lvs_kzdif,
    lv_multi_flag TYPE char1. "Multiple difference indicators per
  "Delivery Item TO's


* Only retrieve Reason Code if there's a difference between the
* original delivery item quantity and the delivery item picked quantity
  CHECK ls_item_status-difference IS NOT INITIAL.

  CLEAR: lv_multi_flag,
         lv_prev_kzdif.

* Get the corresponding TO item records for the Delivery items
  PERFORM get_ltap USING ls_item_obj. "delivery item obj

* Continue if TO's exist for the Delivery Item
  CHECK gt_ltap IS NOT INITIAL.

* Process all of the TO Items for the current Delivery / Parent Item
  LOOP AT gt_ltap INTO ls_ltap
    WHERE vbeln = ls_lips-vbeln
      AND posnr = ls_lips-posnr.

*   Begin BCB02 delete
**   Check if the Difference Indicator kzdif is same for all line items
*    IF sy-tabix > 1.
*      IF ls_ltap-kzdif <> lv_prev_kzdif.
*        lv_multi_flag = 'X'.
*        EXIT.
*      ENDIF.
*    ENDIF.
*    lv_prev_kzdif = ls_ltap-kzdif.
*   End BCB02 delete

*   Begin BCB02 insert
*   Ignore blank Difference Indicators
    IF ls_ltap-kzdif NE space.
*     If the Previous Diff Indicator has a value then compare it to the
*     Current Diff Indicator; Otherwise, if it is a Space then this is
*     the first Diff Indicator looped at that has a non-Space value
      IF lv_prev_kzdif NE space. "
        IF ls_ltap-kzdif <> lv_prev_kzdif.
          lv_multi_flag = 'X'.
          EXIT.
        ENDIF.
      ENDIF. "if previous diff indicator has a value
      lv_prev_kzdif = ls_ltap-kzdif. "format last diff ind with a val
    ENDIF. "If kzdif ne space
*   End BCB02 insert

  ENDLOOP.

* If diferrence indicator kzdif is same for all the line items of the
* delivery then get the reason code
  IF lv_multi_flag IS INITIAL.
    CLEAR ls_t336t.
    READ TABLE gt_t336t INTO ls_t336t
            WITH KEY lgnum = ls_ltap-lgnum
                     kzdif = ls_ltap-kzdif.
    IF sy-subrc = 0.
      ls_item_status-reason_code = ls_t336t-dtext.
    ENDIF.
  ELSE.
    ls_item_status-reason_code = '*'. "signifies that multiple exist
  ENDIF.

ENDFORM.                    " GET_REASON_CODE
*&---------------------------------------------------------------------*
*&      Form  FILL_TO_CONFIRMED_STATUS
*&---------------------------------------------------------------------*
*       Determine if the TO(s) for each Deliver Item is Confirmed or not
*----------------------------------------------------------------------*
*      -->LS_LIPS  text
*      <--LS_DELIVERY_ITEM_STATUS  text
*----------------------------------------------------------------------*
FORM fill_to_confirmed_status
         USING ls_item_obj TYPE zdl_delivery_item_obj_s
*                   ls_lips TYPE ts_lips
         CHANGING ls_delivery_item_status TYPE zdl_delivery_item_status.

  DATA :

    lt_tanum   TYPE TABLE OF tanum.

* Default TO Confirmed Indicator to Yes
  ls_delivery_item_status-to_confirmed = c_y.

* Retrieve any open TO's for this Delivery / Item
  lt_tanum = ls_item_obj-item_object->get_open_tanum( ).

  IF lt_tanum[] IS NOT INITIAL.
*   Open Transfer Order(s) exist to be picked. Set TO Confirmed to False
    ls_delivery_item_status-to_confirmed = c_n.

*   Since an Open TO exists for this Parent Item, we need to set this
*   Parent Item's Pick and Pack status to 'N'
    ls_delivery_item_status-kosta = c_n. "Picking status
    ls_delivery_item_status-pksta = c_n. "Packing status
  ENDIF.

ENDFORM.                    " FILL_TO_CONFIRMED_STATUS
*&---------------------------------------------------------------------*
*&      Form  PREPARE_SHIP_HU_STATUS
*&---------------------------------------------------------------------*
*       Determine whether Shipment Level HU's should exist and if they
*       are packed, with Delivery (Child) HU's properly
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM prepare_ship_hu_status
       USING lt_item_obj TYPE zdl_delivery_item_obj_t."delivery item obj

  DATA :

    lt_shiphu TYPE STANDARD TABLE OF gts_shiphu, "shipment hu table

    lt_xref   TYPE STANDARD TABLE OF gts_xref. "xref table


* Default Shipment HU status indicators to NO
  es_ship_header_status-shipment_hu_packing_required = c_n.
  es_ship_header_status-shipment_hu_packing_completed = c_n.

* Do not perform Shipment HU Status validation unless this is a WM
* scenario
  CHECK gv_facility = c_wm.

* Begin BCB01 insert
* Do not perform Shipment HU Status validation unless none of the Stage
* Deliveries are STO Deliveries
  CHECK gv_sto_deliveries = c_n.
* End BCB01 insert

* Retrieve Shipment HU information and build Ship/Deliv HU xref table
  PERFORM retrieve_shipment_hu_info USING lt_item_obj
                                    CHANGING lt_shiphu
                                             lt_xref.

* Validate Shipment HU's
  PERFORM validate_shipment_hu USING lt_shiphu
                                     lt_xref.

* Remove duplicate Shipment HU Status errors
  SORT et_shipment_hu_status.
  DELETE ADJACENT DUPLICATES FROM et_shipment_hu_status .

ENDFORM.                    " PREPARE_SHIP_HU_STATUS
*&---------------------------------------------------------------------*
*&      Form  RETRIEVE_SHIPMENT_HU_INFO
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM retrieve_shipment_hu_info
       USING lt_item_obj TYPE zdl_delivery_item_obj_t "delivery item obj
       CHANGING lt_shiphu TYPE tt_gts_shiphu
                 lt_xref   TYPE tt_gts_xref.

  TYPES:

    BEGIN OF lts_vekp,
      exidv  TYPE exidv, "hu
      status TYPE hu_status, "hu status
    END OF lts_vekp.


  DATA :

    lo_to_obj   TYPE REF TO zcl_wm_to,            "Transfer Order object

    lt_tanum    TYPE tt_tanum, "all confirmed TO's per deliv item

    ls_shiphu   TYPE gts_shiphu, "shipment hu structure

    ls_xref     TYPE gts_xref, "xref structure

    lt_vbplk    TYPE zdl_vbplk_tt, "HU header table data
    ls_vbplk    TYPE vbplk,    "HU header structure data

    lt_vbplp    TYPE zdl_vbplp_tt, "HU item table data
    ls_vbplp    TYPE vbplp,    "HU item structure data

    ls_item_obj TYPE zdl_delivery_item_obj_s, "delivery item obj

    lt_ltap     TYPE  tt_ltap, "TO item data table
    ls_ltap     TYPE  ltap,    "TO item data structure

    ls_likp     TYPE ts_likp,
    ls_ltak     TYPE ltak,

    lt_vekp     TYPE STANDARD TABLE OF lts_vekp,
    ls_vekp     TYPE lts_vekp,

    lv_tanum    TYPE tanum,  "TO number
    lv_status   TYPE hu_status. "HU status

  CLEAR: lt_xref.

* Process all Delivery Parent Item Objects (ie 000010; not 900001, etc)
  LOOP AT lt_item_obj INTO ls_item_obj.

    CLEAR: lt_tanum.

*   Retrieve only confirmed TO's for this Delivery / Item. If an open
*   TO exists for a Delivery / Item then LTAK-LZNUM should never be
*   populated.
    lt_tanum = ls_item_obj-item_object->get_conf_tanum( ).

*   Process the TO's if they exist
    IF lt_tanum IS NOT INITIAL.

*     Retrieve HU Header and Item information for the Parent
*     Level Delivery Item
*     Note: Returns HU's for the Parent Item level (ie 000010
*           which means it gets all Batch Split HUs if the
*           Parent Delivery Item is Batch Split).
      CLEAR: lt_vbplk.
      lt_vbplk = ls_item_obj-item_object->get_vbplk_data( ).
      CLEAR: lt_vbplp.
      lt_vbplp = ls_item_obj-item_object->get_vbplp_data( ).

*     If TO's exist for the Delivery Line, Create TO object
      LOOP AT lt_tanum INTO lv_tanum.

*       Retrieve Warehouse number
        CLEAR: ls_likp.
        READ TABLE gt_likp INTO ls_likp
          WITH KEY vbeln = ls_item_obj-vbeln.

*       Warehouse number exists
        IF ls_likp-lgnum IS NOT INITIAL.

*         Create TO Object if Delivery warehouse has a value
          FREE lo_to_obj. "Free the TO object
          CREATE OBJECT lo_to_obj
            EXPORTING
              iv_lgnum      = ls_likp-lgnum
              iv_tanum      = lv_tanum
            EXCEPTIONS
              invalid_input = 1
              no_data_found = 2
              OTHERS        = 3.
          IF sy-subrc = 0.

*           Retrieve TO Header LTAK data
            CLEAR ls_ltak.
            CALL METHOD lo_to_obj->get_ltak_data
              RECEIVING
                rs_ltak = ls_ltak.

*           If a Parent HU exists in field lznum then this Delivery
*           Item's HU should be packed into this Parent HU and
*           assigned to this Shipment
            IF ls_ltak-lznum IS NOT INITIAL.

*             Populate Unique table of Shipment HU's found in the TO
*             header field LTAK-LZNUM
              ls_shiphu-exidv = ls_ltak-lznum.
              ls_shiphu-kquit = ls_ltak-kquit.
              COLLECT ls_shiphu INTO lt_shiphu.

*             If at least one TO Header lznum has a value then we
*             consider Shipment HU packing to be required
              es_ship_header_status-shipment_hu_packing_required =
                c_y.

*             Retrieve TO Item LTAP data
              CLEAR: lt_ltap, ls_ltap.
              CALL METHOD lo_to_obj->get_ltap_data
                RECEIVING
                  rt_ltap = lt_ltap.

*             Retrieve Delivery Item info based on the Batch on this TO.
*             This item could be a Parent level delivery item that
*             contains a Batch (ie 000010) or at the
*             Batch Split Level (ie 900001)

*             Retrieve the Batch on the TO Item
              READ TABLE lt_ltap INTO ls_ltap INDEX 1. "TO item record

*             Retrieve the HU Item record based on the Batch
              READ TABLE lt_vbplp INTO ls_vbplp
               WITH KEY charg = ls_ltap-charg.
              IF sy-subrc = 0.

*               Retrieve External HU number
                READ TABLE lt_vbplk INTO ls_vbplk
                  WITH KEY venum = ls_vbplp-venum.

                IF sy-subrc = 0.
*                Build a Cross-Reference table of which Delivery Level
*                HU "should" be packed into which Shipment Level HU.
                  CLEAR: ls_xref.
                  ls_xref-pexidv = ls_ltak-lznum. "Ship HU on TO
                  ls_xref-cexidv = ls_vbplk-exidv. "Child HU for Ship HU
                  ls_xref-cvenum = ls_vbplk-venum. "Child HU for Ship HU
                  APPEND ls_xref TO lt_xref.
                ENDIF. "subrc check on lt_vbplk

              ENDIF. "subrc check on lt_vbplp
*
            ENDIF. "ls_ltak_lznum is not intial

          ELSE.
            CONTINUE. "process next TO
          ENDIF.

        ENDIF. "If warehouse is not blank

      ENDLOOP. "lt_tanum

      FREE lo_to_obj. "Free the last TO object

    ENDIF. "if lt_tanum is not blank

  ENDLOOP. "at lt_item_obj

  SORT lt_xref BY pexidv.

ENDFORM.                    " RETRIEVE_SHIPMENT_HU_INFO
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_SHIPMENT_HU
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_SHIPHU  text
*      -->P_LT_XREF  text
*----------------------------------------------------------------------*
FORM validate_shipment_hu  USING    lt_shiphu TYPE tt_gts_shiphu
                                    lt_xref   TYPE tt_gts_xref.

  DATA :

    lo_phu                TYPE REF TO zcl_dl_hu,  "Handling Unit object

    ls_shiphu             TYPE gts_shiphu, "shipment hu structure

    ls_xref               TYPE gts_xref, "xref structure

    lt_hu_hdr             TYPE hum_hu_header_t, "parent hu header table
    ls_hu_hdr             TYPE vekpvb,          "parent hu header structure

    lt_hu_itm             TYPE hum_hu_item_t, "parent hu item table
    ls_hu_itm             TYPE vepovb,        "parent hu item structure

    ls_shipment_hu_status TYPE zdl_shipment_hu_status, "Ship HU stat rec

    lv_error              TYPE char1,  "error flag

    lv_tabix              TYPE sytabix,
    lv_like_string        TYPE string,
    lv_char10             TYPE char10,
    lv_exidv              TYPE exidv.


  CONSTANTS:

    lc_confirmed TYPE char1 VALUE 'X',
    lc_deleted   TYPE hu_status VALUE '0060'.

*->Begin Chg: CD2000006420, DL RDC DSD Pack Performance/MAIELY/1242020
  IF lt_xref[] IS NOT INITIAL.
    SELECT exidv, status INTO TABLE @DATA(lt_invekp) FROM vekp
    FOR ALL ENTRIES IN @lt_xref
    WHERE ( exidv EQ @lt_xref-pexidv
         OR exidv EQ @lt_xref-cexidv )
      AND status NE @lc_deleted..
  ENDIF.
*-<End Chg: CD2000006420, DL RDC DSD Pack Performance/MAIELY/1242020

* Process each Shipment Level HU
  LOOP AT lt_shiphu INTO ls_shiphu.

    lv_tabix = sy-tabix. "keep index

    FREE lo_phu. "free previous Parent HU object

*   Create Parent HU object
    CREATE OBJECT lo_phu
      EXPORTING
        iv_exidv     = ls_shiphu-exidv "Parent ext HU
      EXCEPTIONS
        invalid_data = 1
        hu_not_found = 2
        OTHERS       = 3.
*   Error Scenario: Shipment Level HU does not exist
    IF sy-subrc <> 0.

*     This Shipment Level HU does not exist. If it's corresponding TO
*     has already been Confirmed AND no Child HU's point to this
*     Shipment Level HU then filter out / ignore this Shipment Level HU
      IF ls_shiphu-kquit = lc_confirmed.

*->Begin Chg: CD2000006420, DL RDC DSD Pack Performance/MAIELY/1242020
*       Determine if Child HU's exist for this Shipment Level HU.
*        lv_char10 = ls_shiphu-exidv. "strip off 1st 10 chars of Parent
*       Format the LIKE string
*        CONCATENATE lv_char10
*                    '%'
*          INTO lv_like_string.

*        SELECT SINGLE exidv INTO lv_exidv FROM vekp
*          WHERE exidv LIKE lv_like_string
*            AND status NE lc_deleted.

*        IF sy-subrc NE 0.
        DATA(ls_invekp) =
        VALUE #( lt_invekp[ exidv+0(10) = ls_shiphu-exidv ] OPTIONAL ).

        IF ls_invekp IS INITIAL.
*-<End Chg: CD2000006420, DL RDC DSD Pack Performance/MAIELY/1242020
*         Ship HU does not exist in system, the TO pointing to the Ship
*         HU is Confirmed but no Children exist in the system having the
*         first 10 bytes of the Parent HU. In this case we will remove
*         this Parent HU from the work tables then continue to the next
*         Shipment HU in the LOOP as we do not want to include this
*         Ship HU on the validation report
          DELETE lt_shiphu INDEX lv_tabix.
          DELETE lt_xref WHERE pexidv = ls_shiphu-exidv.
          CONTINUE.

        ELSE.

          CLEAR ls_invekp.                   "CD2000006420
*         The TO pointing to the Ship HU is Confirmed but Child HU's
*         exist in the system so we must give error that the Ship HU
*         does not exist
          PERFORM set_shiphu_status_missing USING ls_shiphu
                                         CHANGING ls_shipment_hu_status
                                                  es_ship_header_status.
          CONTINUE. "continue to next record
        ENDIF.

      ELSE.
*       The TO pointing to Ship HU is not Confirmed so give error that
*       the Ship HU does not exist
        PERFORM set_shiphu_status_missing USING ls_shiphu
                                       CHANGING ls_shipment_hu_status
                                                es_ship_header_status.
        CONTINUE. "continue to next record
      ENDIF.

    ENDIF. "if TO is confirmed for Shipment Level HU

*   Retrieve Parent HU header and item information
    CLEAR: lt_hu_hdr,
           lt_hu_itm.
    CALL METHOD lo_phu->get_hu_details
      IMPORTING
        et_hu_hdr = lt_hu_hdr  "hu header
        et_hu_itm = lt_hu_itm. "hu item
    SORT lt_hu_hdr BY exidv.
    SORT lt_hu_itm BY unvel. "Child HU

*   Validate this Parent HU is assigned to the current Shipment
    READ TABLE lt_hu_hdr INTO ls_hu_hdr
      WITH KEY exidv = ls_shiphu-exidv "Shipment HU
      BINARY SEARCH.
    IF ls_hu_hdr-vpobj = '04' AND ls_hu_hdr-vpobjkey = is_vtts-tknum.
    ELSE.
*     Parent HU is not assigned to the Shipment
      CLEAR: ls_shipment_hu_status.
      ls_shipment_hu_status-exidv = ls_shiphu-exidv. "Parent HU
      ls_shipment_hu_status-overall_status = 'Not assigned to shipment'.
      ls_shipment_hu_status-status = c_n.
      APPEND ls_shipment_hu_status TO et_shipment_hu_status.

*     Populate Overall Shipment Header Message & Type if
*     this is the FIRST error encountered
      IF es_ship_header_status-overall_shipment_message_type NE 'E'.
        CONCATENATE 'Shipment HU'
                    ls_shiphu-exidv  "Parent HU
                    'is not assigned to this Shipment'
         INTO es_ship_header_status-overall_shipment_message
         SEPARATED BY space.
        es_ship_header_status-overall_shipment_message_type = 'E'.
      ENDIF.

      CONTINUE.
    ENDIF.


*   Validate that the Shipment HU has all of the Delivery HU's, from
*   this particular Stage/Stop, packed into it based on what the
*   ltak-lznum dictated to us in terms of the Parent/Child HU
*   relationship.

    lv_error = c_n.
*   Process each Delivery Child HU for the Shipment HU looped at above
    LOOP AT lt_xref INTO ls_xref WHERE pexidv = ls_shiphu-exidv.

*     Check to see if this Child HU is actually packed into the Parent
*     HU based on the Parent HU info retrieved from SAP. Table
*     lt_hu_hdr will contain the Parent HU as well as the Child HU's
      READ TABLE lt_hu_itm INTO ls_hu_itm
        WITH KEY unvel = ls_xref-cvenum  "delivery/child hu
        BINARY SEARCH.

      IF sy-subrc NE 0.

        lv_error = c_y. "set error flag

*       Delivery/Child HU is not packed into the Parent HU
        CLEAR: ls_shipment_hu_status.
        ls_shipment_hu_status-exidv = ls_shiphu-exidv. "Parent HU
        ls_shipment_hu_status-overall_status = 'Not completely packed'.
        ls_shipment_hu_status-status = c_n.
        APPEND ls_shipment_hu_status TO et_shipment_hu_status.

*       Populate Overall Shipment Header Message & Type if
*       this is the FIRST error encountered
        IF es_ship_header_status-overall_shipment_message_type NE 'E'.
          CONCATENATE 'Shipment HU'
                      ls_shiphu-exidv  "Parent HU
                      'not completely packed'
           INTO es_ship_header_status-overall_shipment_message
           SEPARATED BY space.
          es_ship_header_status-overall_shipment_message_type = 'E'.
        ENDIF.

        EXIT. "Exit processing the Delivery Level child HU's after error

      ENDIF.
    ENDLOOP. "lt_xref

*   If all Delivery Level HU's packed into the Parent HU then generate
*   a success message for the Shipment Level HU
    IF lv_error = c_n.
      CLEAR: ls_shipment_hu_status.
      ls_shipment_hu_status-exidv = ls_shiphu-exidv. "Parent HU
      ls_shipment_hu_status-overall_status = 'Packed'.
      ls_shipment_hu_status-status = c_y.
      APPEND ls_shipment_hu_status TO et_shipment_hu_status.
    ENDIF.

  ENDLOOP. "lt_shiphu

  FREE lo_phu. "free the last Parent HU object

  CLEAR lt_invekp.  "CD2000006420

* Determine if all Shipment HU's are Packed. If so, set the Shipment
* Header indicator to 'Y'.
  READ TABLE et_shipment_hu_status INTO ls_shipment_hu_status
    WITH KEY status = c_n.
  IF sy-subrc NE 0.
*   All Shipment Level HU's are packed
    es_ship_header_status-shipment_hu_packing_completed = c_y.
  ENDIF.

ENDFORM.                    " VALIDATE_SHIPMENT_HU
*&---------------------------------------------------------------------*
*&      Form  CREATE_DELIVERY_OBJECTS
*&---------------------------------------------------------------------*
*       Create Delivery Item Objects for use throughout the rest of the
*       program
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM create_delivery_objects
        CHANGING lt_item_obj_all TYPE zdl_delivery_item_obj_t.

  DATA :

    lo_delivery         TYPE REF TO zcl_dl_delivery, "Delivery object

    lt_item_obj         TYPE zdl_delivery_item_obj_t, "delivery item obj

    ls_stage_deliveries TYPE ts_stage_deliveries.

* Begin BCB01 insert
  DATA:

    ls_likp             TYPE likp,
    lv_exclude_delivery TYPE char1,
    lv_fieldname        TYPE fieldname,
    lv_lowval           TYPE zsp_lowval.

  CONSTANTS:

   lc_lfart TYPE fieldname    VALUE 'LFART'.
* End BCB01 insert


  CLEAR: lt_item_obj_all.

* Process each Stage's Delivery
  LOOP AT gt_stage_deliveries INTO ls_stage_deliveries.

*   Create Delivery object
    FREE lo_delivery.
    CREATE OBJECT lo_delivery
      EXPORTING
        iv_vbeln     = ls_stage_deliveries-vbeln
        iv_pack_view = 'X'.

*   Begin BCB01 insert
*   Retrieve Delivery header info
    CALL METHOD lo_delivery->get_likp_data
      RECEIVING
        rs_likp = ls_likp.

*   Format key field
    lv_lowval = ls_likp-lfart.

*   Exclude deliveries from shipment packing which are of the type
*   specified in the control table ZDL_FIELDS for the report catgory WM_STO_DEL.
*   For example one of the deliveries that could be excluded would be type NL.

*   Determine if the HU's Delivery type is an STO
    CLEAR gs_zdlfields.
    READ TABLE gt_zdlfields INTO gs_zdlfields
      WITH KEY fieldname = lc_lfart
               lowval    = lv_lowval.
*   CMS: 25340| Changed By: AMAOLE1| Changed On: 08/30/2013
*   Do not set the global flag if any delivery is an STO delivery, the
*   global flag controls the packing of the entire shipment
*   Set local flag lv_exclude_delivery to exclude STO delivery & include other
*   deliveries like LF
    IF sy-subrc = 0.
*      gv_sto_deliveries = c_y.
      lv_exclude_delivery = c_y.
    ENDIF.
*   End BCB01 insert

*   Retrieve a table of Delivery Item objects for this Delivery (note,
*   this method returns ONLY the Parent Items; not Batch Split Items)
    CLEAR: lt_item_obj.
    CALL METHOD lo_delivery->get_item_objects
      RECEIVING
        et_item_obj = lt_item_obj.

    IF lv_exclude_delivery NE c_y.
*   Add all Delivery Item objects for the Stage to the same table
      APPEND LINES OF lt_item_obj TO lt_item_obj_all.
    ENDIF.

    CLEAR lv_exclude_delivery.
  ENDLOOP. "gt_stage_deliveries

ENDFORM.                    " CREATE_DELIVERY_OBJECTS
*&---------------------------------------------------------------------*
*&      Form  CHECK_ITEM_OPEN_QTY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LS_ITEM_OBJ  text
*      <--P_LS_ITEM_STATUS  text
*----------------------------------------------------------------------*
FORM check_item_open_qty
         USING ls_item_obj TYPE zdl_delivery_item_obj_s
         CHANGING ls_item_status TYPE zdl_delivery_item_status.

  DATA :

    ls_open_qty   TYPE zdl_delivery_item_open_qty_s.


* Only continue if the Picking Indicator is currently 'Y'
  CHECK ls_item_status-kosta = c_y. "Picking status


* Retrieve any open TO's for this Delivery / Item
  ls_open_qty = ls_item_obj-item_object->get_open_qty( ).

* If an open quantity exists for the Delivery Item Parent then set the
* Picking and Packing indicators to 'N'
  IF ls_open_qty-in_vrkme IS NOT INITIAL.
    ls_item_status-kosta = c_n. "Picking status
    ls_item_status-pksta = c_n. "Packing status
  ENDIF.

ENDFORM.                    " CHECK_ITEM_OPEN_QTY
*&---------------------------------------------------------------------*
*&      Form  SET_TEXT_FIELDS
*&---------------------------------------------------------------------*
*       Set various text message fields
*----------------------------------------------------------------------*
*      <--P_LS_ITEM_STATUS  text
*----------------------------------------------------------------------*
FORM set_text_fields
         CHANGING ls_item_status TYPE zdl_delivery_item_status.

* Set Overall Status Text and Overall Status of Reference
  IF ls_item_status-kosta = c_y AND
     ls_item_status-pksta = c_y.
*     If the Delivery Item is fully picked and fully packed
    ls_item_status-overall_status = 'Complete'.
    ls_item_status-rfgsa = c_y.
  ELSE.
*   If the Delivery Item either NOT fully picked OR fully packed
    ls_item_status-overall_status = 'Not Complete'.
    ls_item_status-rfgsa = c_n.
  ENDIF.

* Set English Error if not fully Picked
  IF ls_item_status-kosta = c_n.
    CONCATENATE ls_item_status-vbeln
                ls_item_status-posnr
                'needs picking'
    INTO ls_item_status-english_error
    SEPARATED BY space.

*   Set Shipement Header overall message if no error currently
*   exists in it
    IF es_ship_header_status-overall_shipment_message IS INITIAL.
      CONCATENATE ls_item_status-vbeln
                  ls_item_status-posnr
                  'needs picking'
      INTO es_ship_header_status-overall_shipment_message
      SEPARATED BY space.
      es_ship_header_status-overall_shipment_message_type = 'E'.
    ENDIF.
  ENDIF.

* Set English Error if not fully Packed
  IF ls_item_status-pksta = c_n.
    CONCATENATE ls_item_status-vbeln
                ls_item_status-posnr
                'needs packing'
    INTO ls_item_status-english_error
    SEPARATED BY space.

*   Set Shipement Header overall message if no error currently exists
*   in it
    IF es_ship_header_status-overall_shipment_message IS INITIAL.
      CONCATENATE ls_item_status-vbeln
                  ls_item_status-posnr
                  'needs packing'
      INTO es_ship_header_status-overall_shipment_message
      SEPARATED BY space.
      es_ship_header_status-overall_shipment_message_type = 'E'.
    ENDIF.
  ENDIF.

ENDFORM.                    " SET_TEXT_FIELDS
*&---------------------------------------------------------------------*
*&      Form  SET_SHIPHU_STATUS_MISSING
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LS_SHIPHU  text
*      <--P_LS_SHIPMENT_HU_STATUS  text
*      <--P_ES_SHIP_HEADER_STATUS  text
*----------------------------------------------------------------------*
FORM set_shiphu_status_missing
           USING    ls_shiphu TYPE gts_shiphu "shipment hu structure
           CHANGING ls_shipment_hu_status TYPE zdl_shipment_hu_status
                    es_ship_header_status TYPE  zdl_ship_header_status.


* Parent HU does not exist
  CLEAR: ls_shipment_hu_status.
  ls_shipment_hu_status-exidv = ls_shiphu-exidv. "Shipment HU
  ls_shipment_hu_status-overall_status = 'Does not exist'.
  ls_shipment_hu_status-status = c_n.
  APPEND ls_shipment_hu_status TO et_shipment_hu_status.

* Populate Overall Shipment Header Message & Type if
* this is the FIRST error encountered
  IF es_ship_header_status-overall_shipment_message_type NE 'E'.
    CONCATENATE 'Shipment HU'
                ls_shiphu-exidv  "Shipment HU
                'does not exist'
     INTO es_ship_header_status-overall_shipment_message
     SEPARATED BY space.
    es_ship_header_status-overall_shipment_message_type = 'E'.
  ENDIF.

ENDFORM.                    " SET_SHIPHU_STATUS_MISSING
*&---------------------------------------------------------------------*
*&      Form  GET_ZDL_FIELDS
*&---------------------------------------------------------------------*
*       Retrieve ZDL_FIELDS entries
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_zdl_fields .

  CONSTANTS: lc_sto_category TYPE zcatgory
                VALUE 'WM_STO_DEL'.

  DATA: ls_zdl_fields TYPE zdl_fields,
        lt_zdl_fields TYPE STANDARD TABLE OF zdl_fields.


* Only retrieve the values one time
  CHECK gt_zdlfields IS INITIAL.

  SELECT * FROM zdl_fields
    INTO TABLE gt_zdlfields
    WHERE category = lc_sto_category.

ENDFORM.                    " GET_ZDL_FIELDS

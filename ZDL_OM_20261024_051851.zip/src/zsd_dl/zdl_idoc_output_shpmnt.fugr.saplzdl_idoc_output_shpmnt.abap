*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_IDOC_OUTPUT_SHPMNTTOP.        " Global Data
  INCLUDE LZDL_IDOC_OUTPUT_SHPMNTUXX.        " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_IDOC_OUTPUT_SHPMNTF...        " Subprograms
* INCLUDE LZDL_IDOC_OUTPUT_SHPMNTO...        " PBO-Modules
* INCLUDE LZDL_IDOC_OUTPUT_SHPMNTI...        " PAI-Modules

INCLUDE LZDL_IDOC_OUTPUT_SHPMNTF01.

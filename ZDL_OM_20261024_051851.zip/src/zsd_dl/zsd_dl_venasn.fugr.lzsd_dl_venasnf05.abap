*----------------------------------------------------------------------*
***INCLUDE LZSD_DL_VENASNF05 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  convert_data_to_po1
*&---------------------------------------------------------------------*
*       EDVK946089
*----------------------------------------------------------------------*
*      <--gv_trades_asn  text
*----------------------------------------------------------------------*
FORM convert_data_to_po1  CHANGING gv_trades_asn1.

*-->Begin BCB02
  TYPES: BEGIN OF lts_po2item,
           ebeln  TYPE ebeln,  "po number
           matnr  TYPE matnr,  "material
           ebelp  TYPE ebelp,  "po item
         END OF lts_po2item.

  DATA: ls_po2item TYPE lts_po2item,
        lt_po2item TYPE STANDARD TABLE OF lts_po2item,

        ls_po1item TYPE lts_po2item,
        lt_po1item TYPE STANDARD TABLE OF lts_po2item,

        lv_tabix  TYPE sytabix.
*-->End BCB02

*--> Begin EDVK949032
  DATA: lv_diff   TYPE i,
        lv_length TYPE i.
*--> End   EDVK949032

  DATA: lv_24count  TYPE i.                                 "BCB10

  CONSTANTS:

    lc_thd      TYPE esart    VALUE 'THD'.   "po type THD is Trades


* Determine if all PO2 PO Types on the idoc are the Trades PO Type "THD"
* Validate all of the PO2's and PO1's to make sure they're valid PO
* numbers in SAP
  gv_trades_asn1 = gc_true.
  CLEAR: gs_tr_po_i, gt_tr_po_i[].
  LOOP AT gt_idoc_data INTO gs_idoc_data
    WHERE docnum  =  gs_idoc_ctrl-docnum
      AND ( segnam = gc_e1edl20 OR
            segnam = gc_e1edl24 OR
            segnam = gc_e1edl43 ).

    gv_tabix = sy-tabix.

    CASE gs_idoc_data-segnam.

      WHEN gc_e1edl20.
        gs_e1edl20 = gs_idoc_data-sdata. "format BOL into gs_e1edl20

      WHEN gc_e1edl24.
        gs_e1edl24 = gs_idoc_data-sdata.

*       Store pertinent E1EDL24 information
        gs_tr_po_i-l24_segnum = gs_idoc_data-segnum. "l24 seg nbr
        gs_tr_po_i-l24_tabix  = gv_tabix.                   "l24 index
        gs_tr_po_i-matnr      = gs_e1edl24-matnr.    "material BCB02

        lv_24count = lv_24count + 1.  "BCB10 count ASN Items

      WHEN gc_e1edl43.
        gs_e1edl43 = gs_idoc_data-sdata.

        IF gs_e1edl43-qualf = 'V'.  "signifies a PO doc number

*         Format Bill of Lading Number
          gs_tr_po_i-bolnr        = gs_e1edl20-bolnr.

*         Format PO number with leading 0's
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = gs_e1edl43-belnr
            IMPORTING
              output = gs_tr_po_i-ebeln. "PO2

*         Format PO Line item for Portal ASN's since this has a valid
*         value. Vendor ASN code will determine the PO Line item later
*         during sub_mat when the SAP Material is derived from the
*         AFPA code the Vendor sends.
          gs_tr_po_i-ebelp        = gs_e1edl43-posnr.

*-->Begin BCB02
*         Format PO2 Item Number. If ASN1 and it's NOT a Manual ASN do
*         not perform this here because if it matches one of those
*         criteria then the Material on the idoc, at this point, will
*         be the AFPA code and we will not have a valid hit on EKPO.
          IF gv_trades_asn1 = gc_true AND
             gs_idoc_ctrl-mestyp NE 'ZDL_PASN'.
*           DO not do the logic below
          ELSE.

*           Determine if PO2 Item Number has already been retrieved
            READ TABLE lt_po2item INTO ls_po2item
              WITH KEY ebeln = gs_tr_po_i-ebeln
                       matnr = gs_e1edl24-matnr
              BINARY SEARCH.
            lv_tabix = sy-tabix.

*           If retrieved from an earlier LOOP then use it
            IF sy-subrc EQ 0.
              gs_tr_po_i-ebelp2 = ls_po2item-ebelp.
            ELSE.
*             Retrieve PO2 Item Number
              SELECT SINGLE ebelp INTO gs_tr_po_i-ebelp2 FROM ekpo
                WHERE ebeln = gs_tr_po_i-ebeln
                  AND matnr = gs_e1edl24-matnr
                  AND loekz = space.
              IF sy-subrc EQ 0.
                ls_po2item-ebeln = gs_tr_po_i-ebeln.        "PO2 number
                ls_po2item-matnr = gs_e1edl24-matnr. "PO2 material
                ls_po2item-ebelp = gs_tr_po_i-ebelp2.       "PO2 item
*               Keeps sort order
                INSERT ls_po2item INTO lt_po2item INDEX lv_tabix.
              ELSE.
*               Item Number on EKPO not found for PO2 & Material &
                PERFORM sub_idoc_status_fill USING
                    c_idoc_status_error                     "status 51
                    gs_idoc_ctrl-docnum "idoc number
                    c_error                "status msg type
                    'ZSD_DL'              "message class
                    '169'                 "err msg
                    gs_tr_po_i-ebeln                        "msgv1
                    gs_e1edl24-matnr                        "msgv2
                    ' '                                     "msgv3
                    ' '                                     "msgv4
                    'CONVERT_DATA_TO_PO1'        "routid
                    gs_idoc_data-segnum   "seg num
                    ' '.                  "seg field
                RETURN. "leave subroutine
              ENDIF.
            ENDIF.
          ENDIF.
*-->End BCB02

*         Build a table of PO information
          gs_tr_po_i-l43_segnum   = gs_idoc_data-segnum. "l43 seg number
          gs_tr_po_i-l43_tabix    = gv_tabix.               "l43 index
          gs_tr_po_i-l43_psgnum   = gs_idoc_data-psgnum. "l43 parent seg
          APPEND gs_tr_po_i TO gt_tr_po_i.

        ENDIF.

    ENDCASE.

  ENDLOOP.

* Begin BCB10 insert
* If no E1EDL24 segments exist then generate an error and trigger
* workflow
  IF lv_24count < 1.
    gv_trigger_wf = gc_true.
*   TRD ASN: Vendor ASN missing lines
    PERFORM sub_idoc_status_fill USING
    c_idoc_status_error                                     "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '602'                   "err msg
        ' '                                                 "msgv1
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'CONVERT_DATA_TO_PO1'      "routid
        ' '                     "seg num
        ' '.                    "seg field
    RETURN.
  ENDIF.
* End BCB10 insert

* If no PO's exist on the idoc then it's not a Trades
  IF gt_tr_po_i[] IS INITIAL.
    gv_trades_asn1 = gc_false.
    gv_trades_asn2 = gc_false.
*   Begin BCB10 insert
*   Retrieve the first E1EDL24's index
    READ TABLE gt_idoc_data INTO gs_idoc_data
      WITH KEY segnam = gc_e1edl24.
    gv_trigger_wf = gc_true.
*   TRD ASN: PO missing on IDOC
    PERFORM sub_idoc_status_fill USING
        c_idoc_status_error                                 "status 51
        gs_idoc_ctrl-docnum     "idoc number
        c_error                 "status msg type
        'ZSD_DL'                "message class
        '604'                   "err msg
        ' '                                                 "msgv1
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        ' '                                                 "msgv4
        'CONVERT_DATA_TO_PO1'                            "routid
        gs_idoc_data-segnum                   "seg num of 1st E1EDL24
        ' '.                                       "seg field
*     End BCB10 insert
    RETURN.
  ENDIF.

* All plants on idoc are Trades plants. Now check the PO types for
* all PO2's on the idoc to see if they're all Trades PO types.
* Retrieve pertinent data from the PO Header table
  CLEAR: gs_tr_po_h, gt_tr_po_h[].
  SELECT ebeln         "market price po (PO2)
         bsart         "po type
         zz_trnpricepo "transfer price po (PO1)
         zz_ipco       "ipco number
         lifnr         "vendor
    FROM ekko
    INTO CORRESPONDING FIELDS OF TABLE gt_tr_po_h
    FOR ALL ENTRIES IN gt_tr_po_i
    WHERE ebeln = gt_tr_po_i-ebeln
      AND loekz NE 'X'.  "not marked for deletion
  IF sy-subrc = 0.
*   Merge PO Header data into main work detail table from the summary
*   internal table. We could have, for example, 3 PO's on the inbound
*   ASN that relate back to only 1 PO
*   line item (batch split scenario).
    SORT gt_tr_po_h BY ebeln.
    LOOP AT gt_tr_po_i INTO gs_tr_po_i.
      gv_tabix = sy-tabix.
      READ TABLE gt_tr_po_h INTO gs_tr_po_h
        WITH KEY ebeln      = gs_tr_po_i-ebeln     "PO2
         BINARY SEARCH.
      IF sy-subrc = 0.
*       If Trades PO Type THD format header fields into detail table
        IF gs_tr_po_h-bsart = lc_thd.
          gs_tr_po_i-bsart         = gs_tr_po_h-bsart.   "po type
          gs_tr_po_i-zz_ipco       = gs_tr_po_h-zz_ipco. "ipco
          gs_tr_po_i-lifnr         = gs_tr_po_h-lifnr.   "vendor

*         Format PO1 number with leading 0's
          IF NOT gs_tr_po_h-zz_trnpricepo IS INITIAL.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input  = gs_tr_po_h-zz_trnpricepo
              IMPORTING
                output = gs_tr_po_i-zz_trnpricepo.

*-->Begin BCB02
*           Format PO1 Item Number. If ASN1 and it's NOT a Manual ASN do
*           not perform this here because if it matches one of those
*           criteria then the Material on the idoc, at this point, will
*           be the AFPA code and we will not have a valid hit on EKPO.
            IF gv_trades_asn1 = gc_true AND
               gs_idoc_ctrl-mestyp NE 'ZDL_PASN'.
*             DO not do the logic below
            ELSE.
*             Determine if PO1 Item Number has already been retrieved
              READ TABLE lt_po1item INTO ls_po1item
                WITH KEY ebeln = gs_tr_po_i-zz_trnpricepo  "PO1
                         matnr = gs_tr_po_i-matnr          "Material
                BINARY SEARCH.
              lv_tabix = sy-tabix.

*             If retrieved from an earlier LOOP then use it
              IF sy-subrc EQ 0.
                gs_tr_po_i-ebelp = ls_po1item-ebelp.
              ELSE.
*               Retrieve PO1 Item Number
                SELECT SINGLE ebelp INTO gs_tr_po_i-ebelp FROM ekpo
                  WHERE ebeln = gs_tr_po_i-zz_trnpricepo "PO1
                    AND matnr = gs_tr_po_i-matnr
                    AND loekz = space.
                IF sy-subrc EQ 0.
                  ls_po1item-ebeln = gs_tr_po_i-zz_trnpricepo. "PO1
                  ls_po1item-matnr = gs_tr_po_i-matnr. "PO1 material
                  ls_po1item-ebelp = gs_tr_po_i-ebelp.      "PO1 item
*                 Keeps sort order
                  INSERT ls_po1item INTO lt_po1item INDEX lv_tabix.
                ELSE.
*                 Item Number on EKPO not found for PO1 & Material &
                  PERFORM sub_idoc_status_fill USING
                      c_idoc_status_error                   "status 51
                      gs_idoc_ctrl-docnum "idoc number
                      c_error                "status msg type
                      'ZSD_DL'              "message class
                      '168'                 "err msg
                      gs_tr_po_i-zz_trnpricepo              "msgv1
                      gs_tr_po_i-matnr                      "msgv2
                      ' '                                   "msgv3
                      ' '                                   "msgv4
                      'CONVERT_DATA_TO_PO1'        "routid
                      gs_idoc_data-segnum   "seg num
                      ' '.                  "seg field
                  RETURN. "leave subroutine
                ENDIF.
              ENDIF.
            ENDIF.
*-->End BCB02

*           Update main detail work table
            MODIFY gt_tr_po_i FROM gs_tr_po_i INDEX gv_tabix
              TRANSPORTING bsart zz_ipco lifnr zz_trnpricepo
                           ebelp. "PO1 Item                  "BCB02

          ELSE.
*           PO1 number is blank on EKKO for PO2 &
            PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum     "idoc number
                c_error                 "status msg type
                'ZSD_DL'                "message class
                '000'                   "err msg
                text-131                                    "msgv1
                gs_tr_po_i-ebeln                            "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                'convert_data_to_po1'                          "routid
                gs_tr_po_i-l43_segnum                   "E1EDL43 seg num
                'BELNR'.                                   "seg field

            gv_trades_asn1 = gc_false.
            RETURN.
          ENDIF.

        ELSE.
*         PO type is not the Trades PO Type THD so exit
          gv_trades_asn1 = gc_false.
          RETURN. "leave subroutine
        ENDIF.
      ELSE.
*       Begin BCB10 insert
        IF gv_trades_asn1 = gc_false OR  "not Trades ASN1
          ( gv_trades_asn1 = gc_true AND " is Trades ASN1 but it's a
            gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN
*       End BCB10 insert
*       Invalid PO2 number & in E1EDL43-BELNR
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum     "idoc number
              c_error                 "status msg type
              'ZSD_DL'                "message class
              '000'                   "err msg
              text-121                                      "msgv1
              gs_tr_po_i-ebeln                              "msgv2
              text-122                                      "msgv3
              ' '                                           "msgv4
              'convert_data_to_po1'                          "routid
              gs_tr_po_i-l43_segnum                     "E1EDL43 seg num
              'BELNR'.                                   "seg field
*       Begin BCB10 insert
        ELSE.
*         Invalid PO2; generate the error using the PO2 value
          gv_trigger_wf = gc_true.
*         TRD ASN: PO & not in SAP
          PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum      "idoc number
            c_error                  "status msg type
            'ZSD_DL'                 " message class
            '603'                    " err msg
            gs_tr_po_i-ebeln                                " msgv1 PO2
            ' '                                             "msgv2
            ' '                                             "msgv3
            gs_tr_po_i-ebeln                                "msgv4 PO2
            'CONVERT_DATA_TO_PO1'                         " routid
            gs_tr_po_i-l43_segnum                     "E1EDL43 seg num
            'BELNR'.                                      "seg field
        ENDIF.
*       End BCB10 insert
        gv_trades_asn1 = gc_false.
        RETURN.
      ENDIF.
    ENDLOOP.
  ELSE.
*   All PO's on idoc are invalid. Retrieve first PO E1EDL43 segment info
*   and generate error:
    READ TABLE gt_tr_po_i INTO gs_tr_po_i INDEX 1.

*   Begin BCB10 insert
    IF gv_trades_asn1 = gc_false OR  "not Trades ASN1
      ( gv_trades_asn1 = gc_true AND " is Trades ASN1 but it's a
        gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN
*   End BCB10 insert

*     Invalid PO2 number & in E1EDL43-BELNR
      PERFORM sub_idoc_status_fill USING
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          text-121                                          "msgv1
          gs_tr_po_i-ebeln                                  "msgv2
          text-122                                          "msgv3
          ' '                                               "msgv4
          'convert_data_to_po1'                          "routid
          gs_tr_po_i-l43_segnum                     "E1EDL43 seg num
          'BELNR'.                                   "seg field
      gv_trades_asn1 = gc_false.
*   Begin BCB10 insert
    ELSE.
*     Invalid PO2; generate the error using the PO2 value
      gv_trigger_wf = gc_true.
*     TRD ASN: PO & not in SAP
      PERFORM sub_idoc_status_fill USING
      c_idoc_status_error                                   "status 51
        gs_idoc_ctrl-docnum      "idoc number
        c_error                  "status msg type
        'ZSD_DL'                 " message class
        '603'                    " err msg
        gs_tr_po_i-ebeln                                    " msgv1 PO2
        ' '                                                 "msgv2
        ' '                                                 "msgv3
        gs_tr_po_i-ebeln                                    "msgv4 PO2
      'CONVERT_DATA_TO_PO1'                         " routid
      gs_tr_po_i-l43_segnum                     "E1EDL43 seg num
      'BELNR'.                                      "seg field
    ENDIF.
*   End BCB10 insert

    RETURN. "leave subroutine
  ENDIF.

* Use Transfer Price PO (also known as PO1) to retrieve the purch org
* field. This is the box plant code.
  CLEAR: gs_tr_po_h, gt_tr_po_h[].
  SELECT ebeln         "po1
         ekorg         "purch org
    FROM ekko
    INTO CORRESPONDING FIELDS OF TABLE gt_tr_po_h
    FOR ALL ENTRIES IN gt_tr_po_i
    WHERE ebeln = gt_tr_po_i-zz_trnpricepo  "lookup by PO1
      AND loekz NE 'X'.  "not marked for deletion

* Merge PO1 Purchase Org into into main work detail table. This also
* validates the PO1 associated with the PO2 has it's own valid EKKO
* record
  SORT gt_tr_po_h BY ebeln.
  LOOP AT gt_tr_po_i INTO gs_tr_po_i.
    gv_tabix = sy-tabix.
    READ TABLE gt_tr_po_h INTO gs_tr_po_h
      WITH KEY ebeln      = gs_tr_po_i-zz_trnpricepo     "PO1
       BINARY SEARCH.
    IF sy-subrc = 0.
      gs_tr_po_i-ekorg   =     gs_tr_po_h-ekorg. "Purch org
      MODIFY gt_tr_po_i FROM gs_tr_po_i INDEX gv_tabix
        TRANSPORTING ekorg.
    ELSE.
*     Begin BCB10 insert
      IF gv_trades_asn1 = gc_false OR  "not Trades ASN1
        ( gv_trades_asn1 = gc_true AND " is Trades ASN1 but it's a
          gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN
*     End BCB10 insert

*     Invalid PO1 & for PO2 &
        PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '000'                   "err msg
            text-132                                        "msgv1
            gs_tr_po_i-zz_trnpricepo                        "msgv2
            text-126                                        "msgv3
            gs_tr_po_i-ebeln                                "msgv4
            'convert_data_to_po1'                          "routid
            gs_tr_po_i-l43_segnum                     "E1EDL43 seg num
            'BELNR'.                                   "seg field

*     Begin BCB10 insert
      ELSE.
*       Invalid PO2; generate the error using the PO2 value
        gv_trigger_wf = gc_true.
*       TRD ASN: PO & not in SAP
        PERFORM sub_idoc_status_fill USING
        c_idoc_status_error                                 "status 51
          gs_idoc_ctrl-docnum      "idoc number
          c_error                  "status msg type
          'ZSD_DL'                 " message class
          '603'                    " err msg
          gs_tr_po_i-ebeln                                  " msgv1 PO2
          ' '                                               "msgv2
          ' '                                               "msgv3
          gs_tr_po_i-ebeln                                  "msgv4 PO2
        'CONVERT_DATA_TO_PO1'                         " routid
        gs_tr_po_i-l43_segnum                     "E1EDL43 seg num
        'BELNR'.                                      "seg field
        gv_trades_asn1 = gc_false.
      ENDIF.
*     End BCB10 insert
      RETURN.
    ENDIF.
  ENDLOOP.


* Validate there is at least one PO per Delivery Line item on idoc
  SORT gt_tr_po_i BY l43_psgnum. "Parent segment number of E1EDL43

  gt_tr_po_h[] = gt_tr_po_i[].
  SORT gt_tr_po_h BY l24_segnum.

  LOOP AT gt_tr_po_h INTO gs_tr_po_h.
*   Each E1EDL24 idoc segment number should have a corresponding
*   E1EDL43 parent segment number.
    READ TABLE gt_tr_po_i INTO gs_tr_po_i
      WITH KEY l43_psgnum = gs_tr_po_h-l24_segnum
      BINARY SEARCH.
    IF sy-subrc NE 0.
*     Begin BCB10 insert
      IF gv_trades_asn1 = gc_false OR  "not Trades ASN1
        ( gv_trades_asn1 = gc_true AND " is Trades ASN1 but it's a
          gs_idoc_ctrl-mestyp = 'ZDL_PASN' ). "Manual ASN
*     End BCB10 insert
*       PO segment E1EDL43 does not exist for delivery item segment
*       E1EDL24
        PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '000'                   "err msg
            text-120                                        "msgv1
            ' '                                             "msgv2
            ' '                                             "msgv3
            ' '                                             "msgv4
            'CONVERT_DATA_TO_PO1'                            "routid
            gs_tr_po_h-l24_segnum                           "seg num
            ' '.                                       "seg field
*     Begin BCB10 insert
      ELSE.
        gv_trigger_wf = gc_true.
*       TRD ASN: PO missing on IDOC
        PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '604'                   "err msg
            ' '                                             "msgv1
            ' '                                             "msgv2
            ' '                                             "msgv3
            ' '                                             "msgv4
            'CONVERT_DATA_TO_PO1'                            "routid
            gs_tr_po_h-l24_segnum                           "seg num
            ' '.                                       "seg field
      ENDIF.
*     End BCB10 insert
      RETURN.  "leave subroutine
    ENDIF.
  ENDLOOP.


* Replace the Market Price PO (PO2) with the Transfer Price PO (PO1)
* in the idoc in field E1EDL43-BELNR where E1EDL43-QUALF = 'V' (means
* this is a purchase order document).
  SORT gt_tr_po_i BY l43_segnum. "Segment number of E1EDL43
  LOOP AT gt_idoc_data INTO gs_idoc_data
      WHERE   docnum  =  gs_idoc_ctrl-docnum
        AND   segnam  =  gc_e1edl43.

    gv_tabix = sy-tabix.

    gs_e1edl43 = gs_idoc_data-sdata.

    IF gs_e1edl43-qualf = 'V'.

      READ TABLE gt_tr_po_i INTO gs_tr_po_i
        WITH KEY l43_segnum = gs_idoc_data-segnum
        BINARY SEARCH.
      IF sy-subrc = 0.
        gs_e1edl43-belnr = gs_tr_po_i-zz_trnpricepo.
        gs_e1edl43-posnr = gs_tr_po_i-ebelp. "PO1 Item  BCB02
        gs_idoc_data-sdata = gs_e1edl43.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
          TRANSPORTING sdata.
      ENDIF.

    ENDIF.

  ENDLOOP.


* For Terre Haute and Georgetown, replace the rerieved IPCO number from
* EKKO with the IPCO stored in segment-field E1EDL41-BSTNR where
* E1EDL41-QUALI = '002'.
  CHECK gs_idoc_ctrl-mestyp = 'ZDL_NONOMD_ASN'. "Terre Haute & G'town
  CLEAR: gv_tabix.
  SORT gt_tr_po_i BY l43_tabix. "Table index of E1EDL43

  LOOP AT gt_idoc_data INTO gs_idoc_data
      WHERE   docnum  =  gs_idoc_ctrl-docnum
        AND   segnam  =  gc_e1edl43
         OR   segnam  =  gc_e1edl41.

    IF gs_idoc_data-segnam = gc_e1edl43.

      gs_e1edl43 = gs_idoc_data-sdata.

      IF gs_e1edl43-qualf = 'V'.

*       Store index of PO number segment
        gv_tabix = sy-tabix.

      ENDIF.

    ELSE.

      gs_e1edl41 = gs_idoc_data-sdata.

      IF gs_e1edl41-quali = '002'.

*       Retrieve proper gt_tr_po_i index
        READ TABLE gt_tr_po_i INTO gs_tr_po_i
          WITH KEY l43_tabix = gv_tabix
          BINARY SEARCH.

*       Set the IPCO to the Idoc value
*--> Begin EDVK949032
*       Store only the rightmost 5 bytes
*       gs_tr_po_i-zz_ipco = gs_e1edl41-bstnr.

        SHIFT gs_e1edl41-bstnr LEFT DELETING LEADING space.
        gs_tr_po_i-zz_ipco = gs_e1edl41-bstnr.

*       Determine length of the IPCOB value
        lv_length = strlen( gs_tr_po_i-zz_ipco ).

*       If the value is greater than 5 bytes then take the last 5 bytes
        IF lv_length > 5.
          lv_diff = lv_length - 5.
          gs_tr_po_i-zz_ipco = gs_tr_po_i-zz_ipco+lv_diff(5).
        ENDIF.
*--> End   EDVK949032

*       Update the main work table with the Terre Haute / Georgetown
*       IPCO so it will be stored on ZDL_TRADES instead of the IPCO
*       from table EKKO for PO2.
        MODIFY gt_tr_po_i FROM gs_tr_po_i INDEX sy-tabix
          TRANSPORTING zz_ipco.
      ENDIF.

    ENDIF.

  ENDLOOP.

ENDFORM.                    " convert_data_to_po1
*EJECT
*&---------------------------------------------------------------------*
*&      Form  convert_data_to_po2
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM convert_data_to_po2 .

  TYPES:

*      PO segment
         BEGIN OF lty_l43,
           segnum  TYPE  idocdsgnum,  "idoc segment number
           ebeln   TYPE  ebeln,       "PO
           ebelp   TYPE  ebelp,       "PO item
         END OF lty_l43,

*      HU Info segment
         BEGIN OF lty_l37,
           exidv  TYPE exidv,  "HU external number
         END OF lty_l37.

*-->Begin BCB02
  TYPES: BEGIN OF lts_po2item,
           ebeln  TYPE ebeln,  "po number
           matnr  TYPE matnr,  "material
           ebelp  TYPE ebelp,  "po item
         END OF lts_po2item.

  DATA: ls_po2item TYPE lts_po2item,
        lt_po2item TYPE STANDARD TABLE OF lts_po2item,

        lv_tabix2  TYPE sytabix.
*-->End BCB02

  DATA:

*      PO segment
         lt_l43 TYPE STANDARD TABLE OF lty_l43,
         ls_l43 TYPE lty_l43,

*      HU Info
         lt_l37 TYPE STANDARD TABLE OF lty_l37,
         ls_l37 TYPE lty_l37.

  DATA:

         lv_tabix   TYPE  sytabix.  "Current row index work var

  DATA:  lv_venum TYPE venum.                               "BCB05

* Build two internal tables: One containing E1EDL43 info and one
* containing E1EDL37 info. The indexes of each table will correspond to
* each other. For example, the PO/PO Line Item on the E1EDL43 segment
* (ie sy-tabix of 2 on the l43 internal table) will be associated with a
* delivery line associated with the HU from the l37 internal table with
* sy-tabix of 2.
* The reason for this is that the SAME PO and PO Line Item can feed into
* multiple deliveries OR even the same Delivery but different delivery
* line items. We need to a way to get to the true delivery and true line
* delivey line item.
  LOOP AT gt_idoc_data INTO gs_idoc_data
      WHERE   docnum  =  gs_idoc_ctrl-docnum
        AND   ( segnam = gc_e1edl43 OR
                segnam = gc_e1edl37 ).

    gv_tabix = sy-tabix.

    CASE gs_idoc_data-segnam.

      WHEN gc_e1edl43.
        gs_e1edl43 = gs_idoc_data-sdata.

        IF gs_e1edl43-qualf = 'V'.
          ls_l43-segnum = gs_idoc_data-segnum.
          ls_l43-ebeln  = gs_e1edl43-belnr.
          ls_l43-ebelp  = gs_e1edl43-posnr.
          APPEND ls_l43 TO lt_l43.
        ENDIF.

      WHEN gc_e1edl37.
        gs_e1edl37 = gs_idoc_data-sdata.

        ls_l37-exidv = gs_e1edl37-exidv.
        APPEND ls_l37 TO lt_l37.

    ENDCASE.

  ENDLOOP.


* 1) Convert plant on idoc to PO2's plant 8530 on segment E1EDL24.
* 2) Replace the Transfer Price PO (PO1) with the Market Price PO (PO2)
* in the idoc in field E1EDL43-BELNR where E1EDL43-QUALF = 'V' (means
* this is a purchase order document).
  CLEAR: gt_tr_po_h[].
*-->CMS29286 E0VK9A0IEH 01/20/2016 SMITHAI
*--Get Correct Inbound Delivery 1 number.
  LOOP AT gt_idoc_data INTO gs_idoc_data WHERE
          docnum  = gs_idoc_ctrl-docnum  AND
          segnam  = gc_e1edl20.

    gs_e1edl20 = gs_idoc_data-sdata.
    DATA(lv_delivery_1) = gs_e1edl20-vbeln.
    CLEAR: gs_e1edl20, gs_idoc_data.
  ENDLOOP.
*<--CMS29286 E0VK9A0IEH 01/20/2016 SMITHAI
  LOOP AT gt_idoc_data INTO gs_idoc_data
      WHERE   docnum  =  gs_idoc_ctrl-docnum
        AND   ( segnam = gc_e1edl24 OR segnam = gc_e1edl43 ).

    gv_tabix = sy-tabix.

    IF gs_idoc_data-segnam = gc_e1edl24.

      gs_e1edl24 = gs_idoc_data-sdata.
      gs_e1edl24-werks = gc_8530.
      gs_idoc_data-sdata = gs_e1edl24.
      MODIFY gt_idoc_data FROM gs_idoc_data
        INDEX sy-tabix
        TRANSPORTING sdata.

    ELSE.  "PO segment E1EDL43

      gs_e1edl43 = gs_idoc_data-sdata.

      IF gs_e1edl43-qualf = 'V'.

        CLEAR: gs_tr_po_h.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = gs_e1edl43-belnr
          IMPORTING
            output = gs_tr_po_h-zz_trnpricepo. "PO1

*       Determine what index of the E1EDL43 entry is in the work table
        READ TABLE lt_l43 INTO ls_l43
          WITH KEY segnum = gs_idoc_data-segnum.
        lv_tabix = sy-tabix.

*       Determine corresponding Handling Unit
        READ TABLE lt_l37 INTO ls_l37 INDEX lv_tabix.

*       Begin BCB05
*       If this is Trades OMD scenario where this is the process of the
*       ASN 2 generating the Inbound Deliver 2, then this is the Final
*       Idoc (message code equals 'V2F'). The previous 'IND' individual
*       receipt idocs have deleted the HU's which means a VEKP record
*       still exists with a status of '0060' (deleted) but the VEPO
*       record was physically deleted. In order to retrieve the Inbound
*       Delivery 1, we cannot use the SELECT / INNER JOIN statement
*       anymore. We need to go through doc flow now. This will work for
*       a Trades Non OMD scenario as well.


*       SELECT SINGLE c~vbeln INTO gs_tr_po_h-ib_delivery_1 "Inb Deliv 1
*        FROM vepo AS a
*          INNER JOIN vekp AS b ON a~venum = b~venum "int HU
*          INNER JOIN lips AS c ON a~vbeln = c~vbeln"ibd 1
*                              AND a~posnr = c~posnr "item
*          WHERE b~exidv = ls_l37-exidv       "external HU
*            AND c~vgbel = gs_tr_po_h-zz_trnpricepo  "PO1
*            AND c~vgpos = gs_e1edl43-posnr.         "PO1 line item

*** NEW OLD STUFF
**       Retrieve internal HU number
*        CLEAR: lv_venum.
*        SELECT SINGLE venum INTO lv_venum FROM vekp
*          WHERE exidv = ls_l37-exidv.
*
**       Retrieve Delivery 1 from doc flow table
*        SELECT SINGLE vbelv INTO gs_tr_po_h-ib_delivery_1 FROM vbfa
*          WHERE vbeln = lv_venum          "Internal HU
*            AND vbtyp_n = 'X'             "HU relationship
*            AND vbtyp_v = '7'.            "Doc is a Delivery

*** NEW NEW STUFF
*       Retrieve Delivery 1
*-->CMS29286 E0VK9A0IEH 01/20/2016 SMITHAI
*        SELECT SINGLE vpobjkey INTO gs_tr_po_h-ib_delivery_1
*          FROM vekp WHERE exidv = ls_l37-exidv.
        gs_tr_po_h-ib_delivery_1 = lv_delivery_1.
*<--CMS29286 E0VK9A0IEH 01/20/2016 SMITHAI
*       End BCB05

*       Determine if this IB1/PO1 combo has been added to the work table
        READ TABLE gt_tr_po_h INTO gs_tr_po_h
          WITH KEY ib_delivery_1 = gs_tr_po_h-ib_delivery_1 "IB Deliv 1
                   zz_trnpricepo = gs_tr_po_h-zz_trnpricepo. "PO1

        IF sy-subrc NE 0.

*         Grab corresponding PO2 for this PO1 & Inbound Delivery 1 from
*         Trades table
*--> Begin EDVK949484
*         Retrieve the inbound delivery 2 to validate that it doesn't
*         already exist.
*          SELECT SINGLE po2 INTO gs_tr_po_h-ebeln FROM zdl_trades
          SELECT SINGLE po2
                        ib_delivery_2
          INTO (gs_tr_po_h-ebeln, gs_tr_po_h-ib_delivery_2)
          FROM zdl_trades
*--> End EDVK949484
            WHERE ib_delivery_1 = gs_tr_po_h-ib_delivery_1  "IB Deliv 1
              AND po1           = gs_tr_po_h-zz_trnpricepo. "PO1

*         Store unique IB1/PO1/PO2 combo into internal table
          APPEND gs_tr_po_h TO gt_tr_po_h.

        ENDIF.

*       Update the idoc with PO2
        gs_e1edl43-belnr = gs_tr_po_h-ebeln.  "PO2

*-->Begin BCB02
*       Determine if PO2 Item Number has already been retrieved
        READ TABLE lt_po2item INTO ls_po2item
          WITH KEY ebeln = gs_tr_po_h-ebeln
                   matnr = gs_e1edl24-matnr
          BINARY SEARCH.
        lv_tabix2 = sy-tabix.

*       If retrieved from an earlier LOOP then use it
        IF sy-subrc EQ 0.
          gs_e1edl43-posnr = ls_po2item-ebelp.
        ELSE.

*         Retrieve PO2 Item Number
          SELECT SINGLE ebelp INTO gs_e1edl43-posnr FROM ekpo
            WHERE ebeln = gs_tr_po_h-ebeln
              AND matnr = gs_e1edl24-matnr
              AND loekz = space.

          IF sy-subrc EQ 0.
            ls_po2item-ebeln = gs_tr_po_h-ebeln.            "PO2 number
            ls_po2item-matnr = gs_e1edl24-matnr. "PO2 material
            ls_po2item-ebelp = gs_e1edl43-posnr.            "PO2 item
*           Keeps sort order
            INSERT ls_po2item INTO lt_po2item INDEX lv_tabix2.
          ELSE.
*           Item Number on EKPO not found for PO2 & Material &
            PERFORM sub_idoc_status_fill USING
                c_idoc_status_error                         "status 51
                gs_idoc_ctrl-docnum "idoc number
                c_error                "status msg type
                'ZSD_DL'              "message class
                '169'                 "err msg
                gs_tr_po_h-ebeln                            "msgv1
                gs_e1edl24-matnr                            "msgv2
                ' '                                         "msgv3
                ' '                                         "msgv4
                'CONVERT_DATA_TO_PO2'        "routid
                gs_idoc_data-segnum   "seg num
                ' '.                  "seg field
            RETURN. "leave subroutine
          ENDIF.
        ENDIF.
*-->End BCB02
        gs_idoc_data-sdata = gs_e1edl43.
        MODIFY gt_idoc_data FROM gs_idoc_data INDEX gv_tabix
          TRANSPORTING sdata.

      ENDIF.

    ENDIF.

  ENDLOOP.

*--> Begin EDVK949484
* Validate that the Inbound Delivery 2 does not already exist for
* the key to ZDL_TRADES which is: Inbound 1 and PO1.  If so,
* generate an error.
  LOOP AT gt_tr_po_h INTO gs_tr_po_h WHERE ib_delivery_2 NE space.

    SELECT SINGLE vbeln INTO gs_tr_po_h-ib_delivery_2 FROM likp
      WHERE vbeln = gs_tr_po_h-ib_delivery_2.
    IF sy-subrc = 0.
      gv_ib2_exists = gc_true.
      RETURN.
    ENDIF.

  ENDLOOP.
*--> End EDVK949484

ENDFORM.                    " convert_data_to_po2
*EJECT
*&---------------------------------------------------------------------*
*&      Form  retrieve_trades_asn1_info
*&---------------------------------------------------------------------*
*       EDVK946089
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM retrieve_trades_asn1_info .

*-->Begin BCB02
  TYPES: BEGIN OF lts_po2item,
           ebeln  TYPE ebeln,  "po number
           matnr  TYPE matnr,  "material
           ebelp  TYPE ebelp,  "po item
         END OF lts_po2item.

  DATA: ls_po2item TYPE lts_po2item,
        lt_po2item TYPE STANDARD TABLE OF lts_po2item,

        ls_po1item TYPE lts_po2item,
        lt_po1item TYPE STANDARD TABLE OF lts_po2item,

        ls_tr_po_i TYPE gty_tr_po,

        lv_tabix  TYPE sytabix.
*-->End BCB02


  SORT gt_tr_po_i BY l24_tabix      "index of E1EDL24 segment
                     zz_trnpricepo. "PO1

* For Vendor ASN's (including Terre Haute and Georgetown but excluding
* Portal ASN's) retrieve Purchase Order Line Item and merge into
* main work table.
  IF NOT gs_idoc_ctrl-mestyp = 'ZDL_PASN'. "DO NOT do for Portal ASN's
    LOOP AT gt_mbhp_tab.
      READ TABLE gt_tr_po_i INTO gs_tr_po_i
        WITH KEY l24_tabix     = gt_mbhp_tab-24tabix "idx of E1EDL24 seg
                 zz_trnpricepo = gt_mbhp_tab-ebeln "use PO1 transf pr po
        BINARY SEARCH.
      IF sy-subrc = 0.
        gs_tr_po_i-ebelp = gt_mbhp_tab-ebelp.
        MODIFY gt_tr_po_i FROM gs_tr_po_i INDEX sy-tabix
          TRANSPORTING ebelp.   "po line item
      ENDIF.
    ENDLOOP.
  ENDIF.

* Retrieve corresponding Plant for PO1
  CLEAR: gt_tr_po_h[].
  SELECT ebeln         "po1
         ebelp         "po item
         werks         "Plant
    FROM ekpo
    INTO CORRESPONDING FIELDS OF TABLE gt_tr_po_h
    FOR ALL ENTRIES IN gt_tr_po_i
    WHERE ebeln = gt_tr_po_i-zz_trnpricepo  "lookup by PO1
      AND ebelp = gt_tr_po_i-ebelp          "PO1's line item
      AND loekz = space.  "not marked for deletion

* Merge PO Item data into main work table.
  LOOP AT gt_tr_po_h INTO gs_tr_po_h.
    LOOP AT gt_tr_po_i INTO gs_tr_po_i
        WHERE zz_trnpricepo = gs_tr_po_h-ebeln
          AND ebelp         = gs_tr_po_h-ebelp.
      gv_tabix = sy-tabix.
      gs_tr_po_i-werks   =    gs_tr_po_h-werks.             "PO1 plant
      MODIFY gt_tr_po_i FROM gs_tr_po_h INDEX gv_tabix
        TRANSPORTING werks.
    ENDLOOP.
  ENDLOOP.

*-->Begin BCB02
** Retrieve corresponding Sales Order number for each line of the PO2
*  CLEAR: gt_tr_po_h[].
*  SELECT ebeln       "PO2
*         ebelp
*         vbeln       "Sales Order
*         vbelp       "Sales Order line item
*    FROM ekkn
*    INTO CORRESPONDING FIELDS OF TABLE gt_tr_po_h
*    FOR ALL ENTRIES IN gt_tr_po_i
*    WHERE ebeln = gt_tr_po_i-ebeln  "lookup by PO2
*      AND ebelp = gt_tr_po_i-ebelp  "PO1 & PO2 line item is same
*      AND loekz NE 'X'.  "not marked for deletion
*
** Merge SO Item data into main work table.
*  LOOP AT gt_tr_po_h INTO gs_tr_po_h.
*    LOOP AT gt_tr_po_i INTO gs_tr_po_i
*        WHERE ebeln         = gs_tr_po_h-ebeln
*          AND ebelp         = gs_tr_po_h-ebelp.
*      gv_tabix           =     sy-tabix.
*      gs_tr_po_i-vbeln   =     gs_tr_po_h-vbeln. "SO
*      gs_tr_po_i-vbelp   =     gs_tr_po_h-vbelp. "SO item
*      MODIFY gt_tr_po_i FROM gs_tr_po_i INDEX gv_tabix
*        TRANSPORTING vbeln vbelp.
*    ENDLOOP.
*  ENDLOOP.

* Format PO2 Item Number if it's ASN1 and it's NOT a Manual ASN
* because if it matches one of those criteria then the Material
* on the idoc, at this point, will be the AFPA code and we will
* not have a valid hit on EKPO.
  IF gv_trades_asn1 = gc_true AND
     gs_idoc_ctrl-mestyp NE 'ZDL_PASN'.

    LOOP AT gt_tr_po_i INTO gs_tr_po_i.

      gv_tabix = sy-tabix.

*     Retrieve SAP Material Number after conversion from AFPA Code
      READ TABLE gt_mbhp_tab
        WITH KEY ebeln = gs_tr_po_i-zz_trnpricepo "PO1
                 43tabix = gs_tr_po_i-l43_tabix.  "Index of E1EDL43 seg
      IF sy-subrc = 0.
        gs_tr_po_i-matnr = gt_mbhp_tab-nmatnr.    "Format SAP material
      ENDIF.

*     Determine if PO2 Item Number has already been retrieved
      READ TABLE lt_po2item INTO ls_po2item
        WITH KEY ebeln = gs_tr_po_i-ebeln    "PO2
                 matnr = gs_tr_po_i-matnr    "SAP material
        BINARY SEARCH.
      lv_tabix = sy-tabix.

*     If retrieved from an earlier LOOP then use it
      IF sy-subrc EQ 0.
        gs_tr_po_i-ebelp2 = ls_po2item-ebelp. "Format PO2 item
      ELSE.
*       Retrieve PO2 Item Number
        SELECT SINGLE ebelp INTO gs_tr_po_i-ebelp2 FROM ekpo
          WHERE ebeln = gs_tr_po_i-ebeln   "PO2
            AND matnr = gs_tr_po_i-matnr   "SAP material
            AND loekz = space.
        IF sy-subrc EQ 0.
          ls_po2item-ebeln = gs_tr_po_i-ebeln.              "PO2 number
          ls_po2item-matnr = gs_tr_po_i-matnr.  "PO2 material
          ls_po2item-ebelp = gs_tr_po_i-ebelp2.             "PO2 item
*         Keeps sort order
          INSERT ls_po2item INTO lt_po2item INDEX lv_tabix.
        ELSE.
*         Item Number on EKPO not found for PO2 & Material &
          PERFORM sub_idoc_status_fill USING
              c_idoc_status_error                           "status 51
              gs_idoc_ctrl-docnum "idoc number
              c_error                "status msg type
              'ZSD_DL'              "message class
              '169'                 "err msg
              gs_tr_po_i-ebeln                              "msgv1
              gs_tr_po_i-matnr                              "msgv2
              ' '                                           "msgv3
              ' '                                           "msgv4
              'RETRIEVE_TRADES_ASN1_INFO'        "routid
              gs_idoc_data-segnum   "seg num
              ' '.                  "seg field
          RETURN. "leave subroutine
        ENDIF.
      ENDIF.

*     Update main detail work table with PO2 Item and SAP Material
      MODIFY gt_tr_po_i FROM gs_tr_po_i INDEX gv_tabix
        TRANSPORTING ebelp2                                 "PO2 Item
                     matnr.  "SAP Material

    ENDLOOP.
  ENDIF.


* Retrieve corresponding Sales Order number for each line of the PO2
  LOOP AT gt_tr_po_i INTO gs_tr_po_i.
    lv_tabix = sy-tabix.

*   If SO and SO Item were already retrieved for PO2 and PO2 item use it
    READ TABLE gt_tr_po_i INTO ls_tr_po_i
      WITH KEY ebeln  = gs_tr_po_i-ebeln    "PO2
               ebelp2 = gs_tr_po_i-ebelp2.                  "PO2 item
    IF sy-subrc = 0 AND NOT ls_tr_po_i-vbeln IS INITIAL.
      gs_tr_po_i-vbeln = ls_tr_po_i-vbeln.  "Sales Order
      gs_tr_po_i-vbelp = ls_tr_po_i-vbelp.  "Sales Order item
    ELSE.
*     Retrieve it
      SELECT SINGLE vbeln   "Sales Order
                    vbelp   "Sales Order item
        INTO (gs_tr_po_i-vbeln, "SO
              gs_tr_po_i-vbelp) "SO item
        FROM ekkn
        WHERE ebeln = gs_tr_po_i-ebeln  "PO2
          AND ebelp = gs_tr_po_i-ebelp2                     "PO2 item
          AND loekz = space.            "not blocked, locked, deleted
    ENDIF.

*    Update item level work table with SO and SO Item
    IF NOT gs_tr_po_i-vbeln IS INITIAL.
      MODIFY gt_tr_po_i FROM gs_tr_po_i
        INDEX lv_tabix
        TRANSPORTING vbeln vbelp.
    ENDIF.
  ENDLOOP.
*-->End BCB02

* Convert plant on idoc to PO1's plant instead of PO2's plant of 8530
  LOOP AT gt_tr_po_i INTO gs_tr_po_i.
    READ TABLE gt_idoc_data INTO gs_idoc_data
      INDEX gs_tr_po_i-l24_tabix.
    gs_e1edl24 = gs_idoc_data-sdata.
    gs_e1edl24-werks = gs_tr_po_i-werks.
    gs_idoc_data-sdata = gs_e1edl24.
    MODIFY gt_idoc_data FROM gs_idoc_data
      INDEX gs_tr_po_i-l24_tabix
      TRANSPORTING sdata.
  ENDLOOP.

ENDFORM.                    " retrieve_trades_asn1_info
*EJECT
*&---------------------------------------------------------------------*
*&      Form  update_zdl_trades_table
*&---------------------------------------------------------------------*
*       EDVK946089
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM update_zdl_trades_table .

  TYPES:  BEGIN OF ty_trades.
          INCLUDE STRUCTURE zdl_trades.
  TYPES:  END OF ty_trades.

  DATA:  ls_trades  TYPE ty_trades,
         lt_trades  TYPE STANDARD TABLE OF ty_trades.

  CLEAR: gt_trades.  "BCB11 insert

  IF gv_trades_asn1 = gc_true.

*   Build internal table of ZDL_TRADES
    LOOP AT gt_tr_po_i INTO gs_tr_po_i.
      CLEAR: ls_trades.

      ls_trades-mandt     = sy-mandt.
      ls_trades-ib_delivery_1 = gv_inb_vbeln.     "Inb Delivery 1 (PO1)
      ls_trades-po1       = gs_tr_po_i-zz_trnpricepo. "PO1 - Transfer pr
      ls_trades-po2       = gs_tr_po_i-ebeln.     "PO1 - Market Price
      ls_trades-ipco      = gs_tr_po_i-zz_ipco.   "IPCO number
      ls_trades-lifnr     = gs_tr_po_i-lifnr.     "Vendor
      ls_trades-werks     = gs_tr_po_i-ekorg.     "Box Plant is stored
      " in PO1 Purch Org
      ls_trades-sales_ord = gs_tr_po_i-vbeln.     "Sales order
      ls_trades-bolnr     = gs_tr_po_i-bolnr.     "Bill of Lading

      ls_trades-erdat     = sy-datum.             "Creation date
      APPEND ls_trades TO lt_trades.

    ENDLOOP.

*   Sort internal table by the key of ZDL_TRADES
    SORT lt_trades BY ib_delivery_1
                      po1.

*   Compress internal table by key of ZDL_TRADES
    DELETE ADJACENT DUPLICATES FROM lt_trades COMPARING ib_delivery_1
                                                        po1.
*   Update ZDL_TRADES. Since this is the last step for Trades ASN1, the
*   records will either be there (if we're in reprocess mode where the
*   previous attempt to add the records failed) or they won't (the first
*   time run of the idoc). Either way, the MODIFY statement below will
*   work for both scenarios.
    MODIFY zdl_trades FROM TABLE lt_trades.
    IF sy-subrc NE 0.
*     Error updating table ZDL_TRADES
      PERFORM sub_idoc_status_fill USING
          c_idoc_status_error                               "status 51
          gs_idoc_ctrl-docnum     "idoc number
          c_error                 "status msg type
          'ZSD_DL'                "message class
          '000'                   "err msg
          text-124                                          "msgv1
          ' '                                               "msgv2
          ' '                                               "msgv3
          ' '                                               "msgv4
          'UPDATE_ZDL_TRADES_TABLE'                     "routid
          ' '                                           "seg num
          ' '.                                          "seg field
*   Begin BCB11 insert
*   If Trades 1 then populate the Global ZDL_TRADES table so function
*   module ZDL_I02301_RETRIEVE_ASN_DATA has access to it. This may be
*   needed in the future.
    ELSE.
      gt_trades = lt_trades.
*   End BCB11 insert
    ENDIF.

  ELSE.

*   For Trades ASN2 processing, update ZDL_TRADES with the Inbound
*   Delivery 2 number
    LOOP AT gt_tr_po_h INTO gs_tr_po_h.

*     Lock the record prior to updating it
      PERFORM lock_zdl_trades USING gs_tr_po_h-ib_delivery_1
                                    gs_tr_po_h-zz_trnpricepo.
      IF gv_idoc_error = gc_true.
        RETURN.  "leave subroutine
      ENDIF.

*     Update the Inbound Delivery 2 number
      UPDATE zdl_trades SET ib_delivery_2 = gv_inb_vbeln
        WHERE ib_delivery_1 = gs_tr_po_h-ib_delivery_1
          AND po1           = gs_tr_po_h-zz_trnpricepo.
      IF sy-subrc NE 0.
*       Cannot update ZDL_TRADES for IB1 PO1 & &
        PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '000'                   "err msg
            text-134                                        "msgv1
            gs_tr_po_h-ib_delivery_1                        "msgv2
            gs_tr_po_h-zz_trnpricepo                        "msgv3
            ' '                                             "msgv4
            'LOCK_ZDL_TRADES'       "routid
            ' '                       "seg num
            ' '.                      "seg field
        RETURN. "leave subroutine
      ENDIF.

*     Unlock the record
      CALL FUNCTION 'DEQUEUE_EZDL_TRADES'
        EXPORTING
          mode_zdl_trades = 'X'
          mandt           = sy-mandt
          ib_delivery_1   = gs_tr_po_h-ib_delivery_1
          po1             = gs_tr_po_h-zz_trnpricepo.

    ENDLOOP.

  ENDIF.

ENDFORM.                    " update_zdl_trades_table
*&---------------------------------------------------------------------*
*&      Form  lock_zdl_trades
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LS_TRADES_IB_DELIVERY_1  text
*      -->P_LS_TRADES_PO1  text
*----------------------------------------------------------------------*
FORM lock_zdl_trades  USING    p_ib_delivery_1  "inb deliv
                               p_po1.           "po1

  DATA: lv_count TYPE i,
        lv_locked TYPE boolean.

  lv_count = 0.
  lv_locked = gc_false.

  WHILE lv_locked = gc_false.
    lv_count = lv_count + 1.
    CALL FUNCTION 'ENQUEUE_EZDL_TRADES'
      EXPORTING
        mode_zdl_trades = 'X'
        mandt           = sy-mandt
        ib_delivery_1   = p_ib_delivery_1
        po1             = p_po1
      EXCEPTIONS
        foreign_lock    = 1
        system_failure  = 2
        OTHERS          = 3.

    IF sy-subrc = 0.  "record locked for update
      lv_locked = gc_true.

    ELSE. "record not locked for update - retry

*     Attempt to lock the ZDL_TRADES record for up to 30 secs
      IF lv_count > 30.
*       Cannot lock ZDL_TRADES for IB1 PO1 & &
        PERFORM sub_idoc_status_fill USING
            c_idoc_status_error                             "status 51
            gs_idoc_ctrl-docnum     "idoc number
            c_error                 "status msg type
            'ZSD_DL'                "message class
            '000'                   "err msg
            text-133                                        "msgv1
            p_ib_delivery_1                                 "msgv2
            p_po1                                           "msgv3
            ' '                                             "msgv4
            'LOCK_ZDL_TRADES'       "routid
            ' '                       "seg num
            ' '.                      "seg field
        RETURN. "leave subroutine
      ELSE.
        WAIT UP TO 1 SECONDS.
      ENDIF.
    ENDIF.

  ENDWHILE.

ENDFORM.                    " lock_zdl_trades
*&---------------------------------------------------------------------*
*&      Form  SEND_TRADES_ASN1_OUTPUT
*&---------------------------------------------------------------------*
*       Trigger ZCTA output (outbound ASN idoc: ZDL_CTA_DELVRY)
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM send_trades_asn1_output .

  CONSTANTS     : lc_kappl_e1         TYPE  kappl    VALUE 'E1',
                  lc_kschl_zcta       TYPE  kschl    VALUE 'ZCTA',
                  lc_nacha_6          TYPE na_nacha VALUE '6',
                  lc_vstat_1          TYPE na_vstat VALUE '1',
                  lc_not_processed  TYPE  na_vstat VALUE '0'.


* Submit an asynchronous function that will process AFTER this entire
* idoc function module completes. This way, table ZDL_TRADES will have
* been updated and the processing of the ZCTA output for the Inbound
* Delivery will be able to read the record in ZDL_TRADES and add the
* additional segments that we add in the outbound ASN user exits via
* I02639.
  CALL FUNCTION 'ZDL_TRIGGER_OUTPUT_COND'
    STARTING NEW TASK 'ZDL_I02301_OUTPUT'
    DESTINATION 'NONE'
    EXPORTING
      iv_kappl       = lc_kappl_e1
      iv_objky       = gv_inb_vbeln
      iv_kschl       = lc_kschl_zcta
      iv_vstat       = lc_not_processed.

ENDFORM.                    " SEND_TRADES_ASN1_OUTPUT
*&---------------------------------------------------------------------*
*&      Form  GET_ZDL_FIELDS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_LT_ZDL_FIELDS  text
*----------------------------------------------------------------------*
FORM get_zdl_fields  CHANGING pv_weight TYPE lfimg
                              pv_truck TYPE days
                              pv_rail TYPE days.

  CLEAR:pv_weight,pv_truck,pv_rail.

  SELECT * INTO TABLE @DATA(lt_zdl_fields) FROM zdl_fields
                       WHERE category EQ 'I02387'.

  READ TABLE lt_zdl_fields INTO DATA(lw_zdl_fields)
                           WITH KEY fieldname = 'WEIGHT'.

  IF sy-subrc = 0.
    pv_weight = lw_zdl_fields-lowval.
  ENDIF.

  CLEAR lw_zdl_fields.
  READ TABLE lt_zdl_fields INTO lw_zdl_fields
                           WITH KEY fieldname = 'TRUCK'.

  IF sy-subrc = 0.
    pv_truck = lw_zdl_fields-lowval.
  ENDIF.

  CLEAR lw_zdl_fields.
  READ TABLE lt_zdl_fields INTO lw_zdl_fields
                           WITH KEY fieldname = 'RAIL'.

  IF sy-subrc = 0.
    pv_rail = lw_zdl_fields-lowval.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&  Include           LZSDR6452_FUNCTIONSUBS                           *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  GET_SALES_CHARS
*&---------------------------------------------------------------------*
*       Get Sales Order or Purchase Order characteristics
*   depending on the referencing document
*----------------------------------------------------------------------*
form get_sales_chars tables lpt_config_si structure conf_out
                      using lp_vgbel like lips-vgbel
                            lp_vgpos like lips-vgpos
                            lp_vgtyp like lips-vgtyp.

* Sales Document Types
  constants: c_sales_order           type vgtyp value 'C',
             c_sales_order_no_charge type vgtyp value 'I',
             c_sales_order_returns   type vgtyp value 'H',
             c_purch_order           type vgtyp value 'V'.

  data: l_config_obj type cuobj.

  refresh lpt_config_si[].

  case lp_vgtyp.
    when c_sales_order or
         c_sales_order_no_charge or
         c_sales_order_returns.
*** Get Sales Order LI Characteristics
      clear l_config_obj.
      select single cuobj
        from vbap
        into l_config_obj
       where vbeln = lp_vgbel
         and posnr = lp_vgpos.

    when c_purch_order.
*** Get Purchase Order LI Characteristics
      clear l_config_obj.
      select single cuobj
        from ekpo
        into l_config_obj
       where ebeln = lp_vgbel
         and ebelp = lp_vgpos.
  endcase.
  if sy-subrc = 0.

    refresh lpt_config_si.
    call function 'VC_I_GET_CONFIGURATION_IBASE'
      exporting
        instance           = l_config_obj
      tables
        configuration      = lpt_config_si[]
      exceptions
        instance_not_found = 1.
    if sy-subrc = 0.
      sort lpt_config_si by atnam.
      delete adjacent duplicates
          from lpt_config_si comparing atnam.
    endif. " CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'
  endif. "   SELECT SINGLE cuobj FROM vbap

endform.                    "GET_SALES_CHARS

*&---------------------------------------------------------------------*
*&      Form  get_material_chars
*&---------------------------------------------------------------------*
*       Get material characteristics
*----------------------------------------------------------------------*
*      -->GT_CONFIG_M[]  Material Characteristics table
*      -->LP_MATNR       Material
*----------------------------------------------------------------------*
form get_material_chars  tables lpt_config_m structure conf_out
                          using lp_matnr like lips-matnr
                                lp_werks like lips-werks.

  data: x_marc  like marc,
        x_t460a like t460a.

  refresh gt_config_m[].

  clear x_marc.
  select single *
    from marc
    into x_marc
     where matnr = lp_matnr
       and werks = lp_werks.

  clear x_t460a.
  select single *
    from t460a
    into x_t460a
    where werks = x_marc-werks
      and sobsl = x_marc-sobsl.

  if sy-subrc = 0.
    clear x_marc.
    select single *
      from marc
      into x_marc
       where matnr = lp_matnr
         and werks = x_t460a-wrk02.
  endif.

  check not x_marc-cuobj is initial.

  refresh lpt_config_m.
  call function 'VC_I_GET_CONFIGURATION_IBASE'
    exporting
      instance           = x_marc-cuobj
    tables
      configuration      = lpt_config_m[]
    exceptions
      instance_not_found = 1.
  if sy-subrc = 0.
    sort lpt_config_m by atnam.
    delete adjacent duplicates
        from lpt_config_m comparing atnam.
  endif. " CALL FUNCTION 'VC_I_GET_CONFIGURATION_IBASE'

endform.                    " get_material_chars

*&---------------------------------------------------------------------*
*&      Form  READ_CHAR_NO_FORMAT
*&---------------------------------------------------------------------*
*       Reads 2 global internal tables gt_config_1
*   gt_config_2 for the first available matching characteristic:
*   p_characteristic
*----------------------------------------------------------------------*
*      <--GX_CONFIG         Characteristic data
*      -->P_CHARACTERISTIC  Characteristic name
*----------------------------------------------------------------------*
form read_char_no_format tables   gt_config_1  structure conf_out
                                  gt_config_2  structure conf_out
                            using p_characteristic like conf_out-atnam
                         changing gx_config    like conf_out.

  data: lx_config_1 type conf_out,
        lx_config_2 type conf_out.

  clear: lx_config_1,
         lx_config_2,
         gx_config.
  clear gt_config_1.
  read table gt_config_1 into lx_config_1 with key
    atnam = p_characteristic
    binary search.
  if sy-subrc <> 0.
    clear gt_config_2.
    read table gt_config_2 into lx_config_2 with key
      atnam = p_characteristic
      binary search.
    if sy-subrc <> 0.
      clear gx_config.
      exit.
    else.
      gx_config = lx_config_2.
    endif. " READ TABLE gt_config_2
  else.
    gx_config = lx_config_1.
  endif. " READ TABLE gt_config_1

endform.  " READ_CHAR_NO_FORMAT

*&---------------------------------------------------------------------*
*&      Form  convert_to_target_uom
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PF_MATNR      text
*      -->PF_MENGE_IN   text
*      -->PF_MEINS_IN   text
*      -->PF_MENGE_OUT  text
*      -->PF_MEINS_OUT  text
*----------------------------------------------------------------------*
form convert_to_target_uom
  using    pf_matnr     type matnr
           pf_menge_in
           pf_meins_in  type meins
           pf_meins_out type meins
  changing pf_menge_out.

  data: l_gsmng_in type gsmng,
        lv_new_qty type mseg-menge,
        lv_con_factor type zuom-zcfac,
        l_gsmng_out type gsmng.

  clear: l_gsmng_in,
         l_gsmng_out.

  l_gsmng_in = pf_menge_in.
  l_gsmng_out = pf_menge_out.

* now convert the qty
  if pf_meins_in = pf_meins_out.
    pf_menge_out = pf_menge_in.
  elseif pf_meins_in = 'KAR'.
    clear : lv_con_factor ,  lv_new_qty .
    call function 'Z_CONVERT_TO_ALT_UOM'
      exporting
        material   = pf_matnr
        curr_uom   = pf_meins_in
        curr_qty   = l_gsmng_in
        new_uom    = pf_meins_out
      importing
        new_qty    = lv_new_qty
        con_factor = lv_con_factor.
    if sy-subrc =  0 .
      pf_menge_out = lv_con_factor.
    endif.
  else.
    call function 'MATERIAL_UNIT_CONVERSION'
      exporting
        input                = l_gsmng_in
        kzmeinh              = 'X'
        matnr                = pf_matnr
        meinh                = pf_meins_in
        meins                = pf_meins_out
        type_umr             = '3'
      importing
        output               = l_gsmng_out
      exceptions
        conversion_not_found = 1
        input_invalid        = 2
        material_not_found   = 3
        meinh_not_found      = 4
        meins_missing        = 5
        no_meinh             = 6
        output_invalid       = 7
        overflow             = 8
        others               = 9.
    if sy-subrc = 0.
      pf_menge_out = l_gsmng_out.
    endif.
  endif.

endform.                    "convert_to_target_uom

*&---------------------------------------------------------------------*
*&      Form  GET_CARTONS_PER_PALLET
*&---------------------------------------------------------------------*
*       Retrieve or Calculate Cartons per Pallet
*----------------------------------------------------------------------*
*      -->G_CARTONS_PER_PALLET  text
*----------------------------------------------------------------------*
form get_cartons_per_pallet    using lp_matnr type matnr
                            changing g_cartons_per_pallet
                                              like conf_out-atwrt.

  data: l_wt_pal type f,
        l_wt_ctn type f.

  clear: g_cartons_per_pallet.

* Check if CARTONS_PER_PALLET exists
  clear gx_config.
  perform read_char_no_format tables gt_config_si
                                     gt_config_m
                               using zsdc_cartons_per_pallet
                            changing gx_config.
  if not gx_config-atwrt is initial.
    g_cartons_per_pallet = gx_config-atwrt.
  else.

* Calculate Cartons/Pallet using the Alternate Unit of Measure
*   to convert Weight of 1 Carton into LBS, Weight of 1 Pallet into
*   LBS, then dividing for ratio
    perform convert_to_target_uom
      using    lp_matnr
               1
               'PAL'
               'LBS'
      changing l_wt_pal.

    perform convert_to_target_uom
      using    lp_matnr
               1
               'CTN'
               'LBS'
      changing l_wt_ctn.

    if not l_wt_ctn is initial.
      g_cartons_per_pallet = l_wt_pal / l_wt_ctn.
    else.
      g_cartons_per_pallet = 0.
    endif.

  endif.

endform.                    "GET_CARTONS_PER_PALLET
*&---------------------------------------------------------------------*
*&      Form  POPULATE_DELIVERY_ITEM
*&---------------------------------------------------------------------*
*       Populate the X_LIPS (Delivery Item) structure
*----------------------------------------------------------------------*
*      <-->P_X_LIPS  Delivery Item
*----------------------------------------------------------------------*
form populate_delivery_item    using ip_vbeln type vbeln
                                     ip_posnr type posnr
                            changing is_lips  type lips
                                      x_lips  structure lips.

  clear x_lips.

  if is_lips is initial.
    if not ( ip_vbeln is initial
          or ip_posnr is initial ).
      select single *
        from lips
        into x_lips
        where vbeln = ip_vbeln
          and posnr = ip_posnr.
      is_lips = x_lips.
    else.
      if not ( is_lips-vbeln is initial
            or is_lips-posnr is initial ).
        select single *
          from lips
          into x_lips
          where vbeln = is_lips-vbeln
            and posnr = is_lips-posnr.
        is_lips = x_lips.
      endif.
    endif.
    if sy-subrc <> 0.
      raise bad_delivery.
    endif.
  else.
* Assume the calling program has populated LIPS correctly
    x_lips = is_lips.
  endif.

endform.                    " POPULATE_DELIVERY_ITEM
*&---------------------------------------------------------------------*
*&      Form  GET_TOTAL_CARTONS
*&---------------------------------------------------------------------*
*       Determine total cartons on Delivery Item
*----------------------------------------------------------------------*
*      -->P_X_LIPS_LFIMG  text
*      -->P_X_LIPS_VRKME  text
*      <--P_G_TOTAL_CARTONS  text
*      <--P_CLEAR  text
*      <--P_G_TOTAL_PALLETS  text
*----------------------------------------------------------------------*
form get_total_cartons  using    lp_lfimg type lfimg
                                 lp_vrkme type vrkme
                                 lp_matnr type matnr
                        changing g_total_cartons.

  data: l_carton_wt type f,
        l_total_lbs type lfimg.

  clear g_total_cartons.

  case lp_vrkme.

    when c_uom_carton.
      g_total_cartons = lp_lfimg.

    when c_uom_karton.
      g_total_cartons = lp_lfimg.

    when others.
* Calculate the Delivery Qty in Cartons by dividing the delivery
*    quantity in LBS by (individual) Carton Gross Weight in LBS

* In the rare case that the UOM is not Cartons or LB, convert
*  it to LB
      clear l_total_lbs.
      if lp_vrkme <> c_uom_lbs.

        perform convert_to_target_uom
          using    lp_matnr
                   lp_lfimg
                   lp_vrkme
                   c_uom_lbs
          changing l_total_lbs.

      else.
        l_total_lbs = lp_lfimg.
      endif.

* Check Gross Carton Weight (Characteristic)
      perform read_char_no_format tables gt_config_si
                                         gt_config_m
                                   using 'CARTON_GROSS_WEIGHT'
                                changing gx_config.
      l_carton_wt = gx_config-atwrt.

      if l_carton_wt is initial.

* Determine the individual carton weight from the default material
*   master conversion data
        perform convert_to_target_uom
          using    lp_matnr
                   1
                   'KAR'
                   c_uom_lbs
          changing l_carton_wt.

      endif.

      if l_carton_wt is initial.
        raise unknown_carton_weight.
      endif.

      if not l_total_lbs is initial.
        g_total_cartons = l_total_lbs / l_carton_wt.
      else.
        g_total_cartons = 0.
      endif.

  endcase.

* Assumption: Round up for partial cartons because it is better to
*   have one extra label than be one label short.
*  g_total_cartons = ceil( g_total_cartons ).
*  Change to make the total number of cartons same as  commont units
*  Function module .
  g_total_cartons = floor( g_total_cartons + 1 / 2 ).
  if g_total_cartons lt '1'.
    g_total_cartons = 1.
  endif.
endform.                    " GET_TOTAL_CARTONS

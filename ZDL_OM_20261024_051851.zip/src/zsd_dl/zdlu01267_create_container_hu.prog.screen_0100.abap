process before output.
  module status_0100.
*
process after input.

  module leave_transaction_0100 at exit-command .

  chain.

    field: zdlu01267_0100-signi,   "container id
           zdlu01267_0100-seal,    "seal id
           zdlu01267_0100-werks,   "plant
           zdlu01267_0100-lgort,   "storage location
           zdlu01267_0100-con_size,"container size
           zdlu01267_0100-tare_wgt, "tare weight
           zdlu01267_0100-booknum, "book confirmation number
           zdlu01267_0100-use_booknum, "checkbox to use book num
           zdlu01267_0100-vbeln,   "sales order
           zdlu01267_0100-posnr    "sales order item
      module user_command_0100.

  endchain.

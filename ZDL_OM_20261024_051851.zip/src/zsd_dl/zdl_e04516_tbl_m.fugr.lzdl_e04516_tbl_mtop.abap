*---------------------------------------------------------------------*
*    generated viewmaintenance function pool top
*---------------------------------------------------------------------*
FUNCTION-POOL ZDL_E04516_TBL_M           MESSAGE-ID SV.

  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDL_E04516_TBL_MT00                    . "view rel. data dcl.

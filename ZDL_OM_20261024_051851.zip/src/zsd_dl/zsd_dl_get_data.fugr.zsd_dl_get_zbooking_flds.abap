FUNCTION zsd_dl_get_zbooking_flds.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(IF_VBELN) TYPE  VBELN_VA
*"     REFERENCE(IF_POSNR) TYPE  POSNR_VA OPTIONAL
*"  EXPORTING
*"     REFERENCE(ES_ZSD_BOOK_HDR) TYPE  ZSD_BOOK_HDR
*"  TABLES
*"      ET_ZSD_BOOK_ITM STRUCTURE  ZSD_BOOK_ITM OPTIONAL
*"  CHANGING
*"     REFERENCE(ES_ZSD_BOOK_ITM) TYPE  ZSD_BOOK_ITM OPTIONAL
*"     REFERENCE(EF_STO_FLAG) TYPE  CHAR1 OPTIONAL
*"  EXCEPTIONS
*"      MISSING_BOOKING_HEADER
*"      MISSING_BOOKING_ITEM
*"----------------------------------------------------------------------

  CONSTANTS: c_x VALUE 'X'.

  TABLES: zsd_book_hdr,
          zsd_book_itm,
          ekko.

  DATA: x_ekkn LIKE ekkn,
        t_ekkn LIKE ekkn OCCURS 0.

  DATA: t_zsd_book_itm LIKE zsd_book_itm OCCURS 0.

  CLEAR ef_sto_flag.

* If a Sales Document Item is specified, return a ZSD_BOOK_ITEM booking
*  data line item (optionally) and its header line:
  IF NOT if_posnr IS INITIAL.

    CLEAR: zsd_book_itm.
* First, try with Sales Order Number
    SELECT SINGLE *
      FROM zsd_book_itm
      INTO zsd_book_itm
     WHERE vbeln = if_vbeln
       AND posnr = if_posnr.
    IF sy-subrc <> 0.

* Sales Order Number was unsuccessful, so try mapping from
*    Purchase Order
      CLEAR ekko.
      SELECT SINGLE *
        FROM ekko
        INTO ekko
       WHERE ebeln = if_vbeln.
      IF sy-subrc = 0.

        ef_sto_flag = c_x.

        CLEAR: zsd_book_itm.
        SELECT SINGLE *
          FROM zsd_book_itm
          INTO zsd_book_itm
         WHERE vbeln = ekko-zzvbeln
           AND posnr = ekko-zzposnr.
        IF sy-subrc <> 0.

* Sales Order and Purchase Order were unsuccessful, so try mapping
*  from Account Assignment in Purchasing Document
          CLEAR t_ekkn.
          SELECT *
            FROM ekkn
            INTO TABLE t_ekkn
           WHERE ebeln = if_vbeln
             AND ebelp = if_posnr.
          IF sy-subrc = 0.

            ef_sto_flag = c_x.

* Take the first Account Assignment with a populated Sales Order
            SORT t_ekkn BY vbeln vbelp.
            DELETE t_ekkn WHERE vbeln IS INITIAL.
            DELETE t_ekkn WHERE vbelp IS INITIAL.
            IF NOT t_ekkn IS INITIAL.
              CLEAR x_ekkn.
              READ TABLE t_ekkn INTO x_ekkn INDEX 1.
            ENDIF.

            CLEAR: zsd_book_itm.
            SELECT SINGLE *
              FROM zsd_book_itm
              INTO zsd_book_itm
             WHERE vbeln = x_ekkn-vbeln
               AND posnr = x_ekkn-vbelp.

          ENDIF. " SELECT FROM EKKN
        ELSE.
          ef_sto_flag = c_x.
        ENDIF. " SELECT FROM zsd_book_itm
      ENDIF. " SELECT FROM EKKO
    ENDIF. " SELECT FROM zsd_book_itm

************************************************************************
* Otherwise, if only the header was specified, return the booking header
*  and, optionally, a table of booking line items in ET_ZSD_BOOK_ITM
* Also populate ES_ZSD_BOOK_ITM with the first line item for consistency
  ELSE.

    CLEAR: t_zsd_book_itm.
* First, try with Sales Order Number
    SELECT *
      FROM zsd_book_itm
      INTO TABLE t_zsd_book_itm
     WHERE vbeln = if_vbeln.
    IF sy-subrc <> 0.

* Sales Order Number was unsuccessful, so try mapping from
*    Purchase Order
      CLEAR ekko.
      SELECT SINGLE *
        FROM ekko
        INTO ekko
       WHERE ebeln = if_vbeln.
      IF sy-subrc = 0.

* MTS STO
        ef_sto_flag = c_x.

        CLEAR: t_zsd_book_itm.
        SELECT *
          FROM zsd_book_itm
          INTO TABLE t_zsd_book_itm
         WHERE vbeln = ekko-zzvbeln.
        IF sy-subrc <> 0.

* Sales Order and Purchase Order were unsuccessful, so try mapping
*  from Account Assignment in Purchasing Document
          CLEAR t_ekkn.
          SELECT *
            FROM ekkn
            INTO TABLE t_ekkn
           WHERE ebeln = if_vbeln.
          IF sy-subrc = 0.

* MTO STO
            ef_sto_flag = c_x.

* Take the first Account Assignment with a populated Sales Order
            SORT t_ekkn BY vbeln.
            DELETE t_ekkn WHERE vbeln IS INITIAL.
            IF NOT t_ekkn IS INITIAL.
              CLEAR x_ekkn.
              READ TABLE t_ekkn INTO x_ekkn INDEX 1.
            ENDIF.

            CLEAR: t_zsd_book_itm.
            SELECT *
              FROM zsd_book_itm
              INTO TABLE t_zsd_book_itm
             WHERE vbeln = x_ekkn-vbeln.

          ENDIF. " SELECT FROM EKKN
        ENDIF. " SELECT FROM zsd_book_itm
      ENDIF. " SELECT FROM EKKO
    ENDIF. " SELECT FROM zsd_book_itm

  ENDIF.

*---------------------------------------------------------------------*
* Move data into output structures:

  IF      zsd_book_itm   IS INITIAL
    AND t_zsd_book_itm[] IS INITIAL.
    CLEAR ef_sto_flag.
    RAISE missing_booking_item.
  ELSE.

* Put booking items in output table, and if there is only one,
*  append it to the table
    SORT t_zsd_book_itm BY bookdoc bookitm.
    et_zsd_book_itm[] = t_zsd_book_itm[].
    IF  et_zsd_book_itm[] IS INITIAL.
      APPEND zsd_book_itm TO et_zsd_book_itm.
    ENDIF.

* Put the first Item record from the table into the structure,
*   which should always be populated at this point.
    CLEAR: es_zsd_book_itm.
    IF zsd_book_itm IS INITIAL.
      READ TABLE t_zsd_book_itm INTO zsd_book_itm INDEX 1.
    ENDIF.
    es_zsd_book_itm = zsd_book_itm.

* Retrieve and output header
    CLEAR: zsd_book_hdr.
    SELECT SINGLE *
       FROM zsd_book_hdr
       INTO zsd_book_hdr
       WHERE bookdoc = zsd_book_itm-bookdoc.
    IF sy-subrc <> 0.
      CLEAR ef_sto_flag.
      RAISE missing_booking_header.
    ELSE.
      CLEAR es_zsd_book_hdr.
      es_zsd_book_hdr = zsd_book_hdr.
    ENDIF. " SELECT FROM zsd_book_hdr

  ENDIF.

ENDFUNCTION.

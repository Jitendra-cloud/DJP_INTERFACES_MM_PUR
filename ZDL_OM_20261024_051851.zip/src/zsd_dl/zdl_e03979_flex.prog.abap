*&---------------------------------------------------------------------*
*&  Include           ZDL_E03979_FLEX                                  *
*&---------------------------------------------------------------------*
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT (C) 2007 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2007, 20nn                                 **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
*----------------------------------------------------------------------*

*if sy-uname eq 'DMOHAME'. break-point. endif.

  data: gt_old_vttk           type vttkvb.
  field-symbols: <gt_new_vttk> type vttkvb.
  data:         gt_new_vtts   type vttsvb.
  types: begin of plant_cust,
         werks                type werks_d,
         kunnr                type kunnr_wk,
         end of plant_cust.

  data: gt_fields             type table of zdl_fields,
        gs_fields             type zdl_fields,
        gt_xvttk              type table of vttkvb,
        gs_xvttk              type vttkvb,
        gt_xvtts              type table of vttsvb,
        gs_xvtts              type  vttsvb,
        gt_xvttp              type table of vttpvb,
        gs_xvttp              type  vttpvb,
        gt_xvtsp              type  table of vtspvb,
        gs_xvtsp              type  vtspvb,
*        gt_itinerary type table of zmos_itinerary,
*        gs_itinerary type zmos_itinerary,
        gt_tvswz              type table of tvswz,
        gs_zdl_fped_loc       type zdl_fped_loc,
        gt_cust               type table of plant_cust.

  data: gv_v2_tpp             type c,
        gv_cpu_shipment_type  type c,
        gv_vsart              type versart,
        gv_vsgrp              type vsgrp,
        gv_spart              type spart,
        gv_ktokd              type ktokd,
        gv_fields_low         type zsp_lowval,
        gv_mos_ind            type zsd_dl_multi_origin_shpmnt_ind.

  constants :
    gc_z_v2_ship_type_name type tvarvc-name value 'Z_V2_SHIP_TYPE',
    gc_fields_name         type zdl_fields-fieldname value 'Z_V2_TPP',
    gc_fields_category     type zdl_fields-category  value 'E03979',
    gc_z_v2_ship_type      type zdl_fields-fieldname
                           value 'Z_V2_SHIP_TYPE',

    gc_vsgrp_zcpu          type vsgrp       value 'ZCPU',
    gc_tdlnr_9             type tdlnr       value '0000000009',
    gc_vsart_zg            type versart     value 'ZG',
    gc_vsbed_cp            type vsbed       value 'CP',
    gc_blank_date          type dplbg       value '00000000',
    gc_spart_13            type spart       value '13',
    gc_ktokd_zicc          type ktokd       value 'ZICC',
    gc_ktokd_zwhs          type ktokd       value 'ZWHS',
    gc_sttrg_1             type sttrg       value 1,
    gc_sttrg_2             type sttrg       value 2,
    gc_f                   type zdl_fped_loc-z_flex_ind
                                            value 'F',
    gc_b                   type zdl_fped_loc-z_flex_ind
                                            value 'B'.
  do 1 times. "IP Standard

  loop at i_xvttk assigning <gt_new_vttk>.
    if ( <gt_new_vttk>-sttrg eq gc_sttrg_1 or
      <gt_new_vttk>-sttrg eq gc_sttrg_2 ).
      if gt_fields[] is initial.
* Select the V2 Transportation Planning points.
        select  *
          into  table gt_fields
          from  zdl_fields
          where category  eq gc_fields_category
          and   fieldname in (gc_fields_name, gc_z_v2_ship_type).
      endif.
    endif.

* Determine if the shipment is V2 shipment or not.
    clear: gv_v2_tpp, gv_cpu_shipment_type, gs_fields.

    read table gt_fields into gs_fields
         with  key lowval = <gt_new_vttk>-tplst.
    if sy-subrc = 0.  "V2 Transportation planning point.
       gv_v2_tpp = 'X'.
    else.    "Not a V2 shipment, no validations necessary. Continue
       continue.
    endif.

* Determine if the Shipment type is CPU shipment type
    clear: gv_vsart, gv_vsgrp.
    select  single vsart into gv_vsart
      from  tvtk
      where shtyp = <gt_new_vttk>-shtyp.
    select  single vsgrp into gv_vsgrp
      from  t173
      where vsart = gv_vsart.
    if gv_vsgrp = gc_vsgrp_zcpu.
       gv_cpu_shipment_type = 'X'.
    endif.

    case <gt_new_vttk>-sdabw.
      when 'FLEX'.

*  Begin of V2 Flexible shipment validations
*  On a V2 Flexible Shipment, if the Shipment Status is  1 or 2
*  do the following validations
        if ( <gt_new_vttk>-sttrg eq gc_sttrg_1 or
           <gt_new_vttk>-sttrg eq gc_sttrg_2 ).
* Validation1: Validate the shipment type
          clear gs_fields.
          read table gt_fields into gs_fields
             with key category  = 'E03979'
                      fieldname = gc_z_v2_ship_type

                      sign      = 'I'
                      optn      = 'EQ'
                      lowval    = <gt_new_vttk>-SHTYP.
          if sy-subrc <> 0.
            message e001(ZDL_FLEX).
          endif.
* CPU and Non CPU Shipment Type validations
          if  gv_cpu_shipment_type = 'X'.  "CPU Shipment Type
* CPU Shipment type validations
* Validate that the Forwarding agent for a CPU Ship type
            if <gt_new_vttk>-tdlnr <> gc_tdlnr_9.
              message e002(ZDL_FLEX).
            endif.
* Validate that the Shipment type for a CPU Ship type
            if <gt_new_vttk>-vsart <> gc_vsart_zg.
              message e003(ZDL_FLEX).
            endif.
* Validate that the Shipping Condition for a CPU Ship type
            if <gt_new_vttk>-vsbed <> gc_vsbed_cp.
              message e004(ZDL_FLEX).
            endif.

          else.    " Non CPU Shipment type
* NON CPU Shipment type validations
* Validate that the Forwarding agent is not blank for non CPU Ship type
            if <gt_new_vttk>-tdlnr is initial.
              message e005(ZDL_FLEX).
            endif.
* Validate that Shipment Type is not blank for non CPU Ship type.
            if <gt_new_vttk>-vsart is initial.
              message e006(ZDL_FLEX).
            endif.
* Validate that Shipping condition is not blank for non CPU Ship type.
            if <gt_new_vttk>-vsbed is initial.
              message e007(ZDL_FLEX).
            endif.
          endif.
* Validate Route
          if <gt_new_vttk>-route is initial.
            message e008(ZDL_FLEX).
          endif.
* Validate Planned Load start date
          if <gt_new_vttk>-dplbg is initial or
             <gt_new_vttk>-dplbg = gc_blank_date.
            message e009(ZDL_FLEX).
          endif.
* Validate Planned Load end date
          if <gt_new_vttk>-dplen is initial or
             <gt_new_vttk>-dplen = gc_blank_date.
            message e010(ZDL_FLEX).
          endif.
* Validate Planned Shipment Start date
          if <gt_new_vttk>-dptbg is initial or
             <gt_new_vttk>-dptbg = gc_blank_date.
            message e011(ZDL_FLEX).
          endif.
* Validate Planned Shipment End date
          if <gt_new_vttk>-dpten is initial or
             <gt_new_vttk>-dpten = gc_blank_date.
            message e012(ZDL_FLEX).
          endif.

* Populate the current shipment data to call the stage to stop FM

          refresh: gt_xvttk, gt_xvtts, gt_xvttp, gt_xvtsp.
          append <gt_new_vttk> to gt_xvttk.
          loop at i_xvtts into gs_xvtts
                  where tknum =  <gt_new_vttk>-tknum.
            append gs_xvtts to gt_xvtts.
          endloop.
          loop at i_xvttp into gs_xvttp
                  where tknum =  <gt_new_vttk>-tknum.
            append gs_xvttp to gt_xvttp.
          endloop.
          loop at i_xvtsp into gs_xvtsp
                  where tknum =  <gt_new_vttk>-tknum.
            append gs_xvtsp to gt_xvtsp.
          endloop.
* Check if stages exist
          if gt_xvtts[] is initial.
            message e013(ZDL_FLEX).
          endif.
* Check if delievries exist ( Deliveries can not be assigned)
          if gt_xvttp[] is not initial.
            message e018(ZDL_FLEX).
          endif.

* Check if Multi Origin Shipment ( Can not be a MOS)
          clear: gv_mos_ind. " gt_itinerary.
*          refresh:  gt_itinerary.
          call function 'ZSD_DL_MOS_ITINERARY_VIEW'
*           EXPORTING
*            I_TKNUM         =  <gt_new_vttk>-tknum
           importing
             e_mos_ind       = gv_mos_ind
           tables
             t_vttk          = gt_xvttk
             t_vtts          = gt_xvtts
             t_vttp          = gt_xvttp
             t_vtsp          = gt_xvtsp
*             t_itinerary     = gt_itinerary
           exceptions
             invalid_input                        = 1
             shipment_not_found                   = 2
             no_deliveries_found                  = 3
             no_stages_on_shipment                = 4
             no_authority                         = 5
             deliveries_unassigned_to_stage       = 6
             FLEX_MULTI_ORIGIN_NOT_ALLOWED        = 7
             others                               = 8
                    .
          if sy-subrc = 0.
            if gv_mos_ind = 2 or gv_mos_ind = 4.
              message e019(ZDL_FLEX).
            endif.
          elseif sy-subrc = 7.
            message e025(ZDL_FLEX).
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
          endif.
* Validate the departure point and destination point on every stage
          loop at gt_xvtts into gs_xvtts.
            clear gv_ktokd.
            if gs_xvtts-vstel is initial and
               gs_xvtts-kunna is initial.
*--Error:Departure Point missing - Cannot create Flex Shipment
              message e015(ZDL_FLEX).
            endif.

            if gs_xvtts-kunnz is initial.
*--Error: Departure point not a valid (V2) departure point
*--Error: Invalid Destination Point on Stage - Cannot create FLEX shipment
              message e021(ZDL_FLEX).
            else.
** Check the destination point account group is ZICC,ZWHS
*              if gs_xvtts-vstez is not initial.
** Select the plant of the Departure point
*                refresh: gt_tvswz, gt_cust.
*
*                select * into table gt_tvswz
*                         from tvswz
*                         where vstel = gs_xvtts-vstez.
*                if gt_tvswz[] is not initial.
*                  select werks kunnr into table gt_cust
*                           from t001w
*                           for all entries in gt_tvswz
*                           where werks = gt_tvswz-werks.
*                endif.
                if gt_cust[] is not initial.
                   select ktokd up to 1 rows into (gv_ktokd)
                     from kna1
                      for all entries in gt_cust
                    where kunnr = gt_cust-kunnr
                     and  ktokd in (gc_ktokd_zicc, gc_ktokd_zwhs).
                  endselect.
                  if gv_ktokd is initial.
*Error: Invalid Destination Point on Stage - Cannot create FLEX shipment
                    message e021(ZDL_FLEX).
                  endif.

                endif.
*              elseif gs_xvtts-kunnz is not initial.
                select single ktokd into gv_ktokd
                         from kna1
                         where kunnr = gs_xvtts-kunnz
                         and  ktokd in (gc_ktokd_zicc, gc_ktokd_zwhs).
                if gv_ktokd is initial.
*--Error:Invalid Destination Point on Stage - Cannot create FLEX shipment
                  message e021(ZDL_FLEX).
                endif.
*              endif.
            endif.
          endloop.
* Validate the Departure point on the first stage
          sort gt_xvtts by tsrfo.
          read table gt_xvtts into gs_xvtts index 1.
* Select the plant of the Shipping point
          clear gs_zdl_fped_loc.
          select * up to 1 rows from zdl_fped_loc
            into gs_zdl_fped_loc
            where vstel = gs_xvtts-vstel
            and z_flex_ind in (gc_f, gc_b).
          endselect.
          if gs_zdl_fped_loc-z_flex_ind is initial.
*--Error: Invalid Departure Point on Stage - Cannot create FLEX shipment
             message e016(ZDL_FLEX).
          endif.

        endif.   " V2 TPP, Planned or Checked in Status

      when others.
* Non Flex validations.
* Validate if the FLEX indicator has been changed.
        clear gt_old_vttk.
        read table i_yvttk into gt_old_vttk
                   with key tknum =  <gt_new_vttk>-tknum.
        if gt_old_vttk-sdabw = 'FLEX'.
          message e017(ZDL_FLEX).
        endif.
*  On a V2 Non Flexible Shipment, if the Shipment Status is  1 or 2
*  do the following validations
        if gv_v2_tpp = 'X' and
          ( <gt_new_vttk>-sttrg eq gc_sttrg_1 or
           <gt_new_vttk>-sttrg eq gc_sttrg_2 ).
          if gv_cpu_shipment_type = 'X'.  "CPU Shipment Type
* CPU Shipment type validations
* Validate that the Forwarding agent for a CPU Ship type
            if <gt_new_vttk>-tdlnr <> gc_tdlnr_9.
              message e002(ZDL_FLEX).
            endif.
* Validate that the Shipment type for a CPU Ship type
            if <gt_new_vttk>-vsart <> gc_vsart_zg.
              message e003(ZDL_FLEX).
            endif.
* Validate that the Shipping Condition for a CPU Ship type
            if <gt_new_vttk>-vsbed <> gc_vsbed_cp.
*--Error:Enter Valid Shipping Condition for CPU Shipment
              message e004(ZDL_FLEX).
            endif.
          else.     "Non CPU Shipment Type
* Validate that the Forwarding agent is not blank for non CPU Ship type
            if <gt_new_vttk>-tdlnr is initial.
*--Error:Enter Valid Forwarding Agent
              message e005(ZDL_FLEX).
            endif.
          endif.
*Check if deliveries exist ( (V2) Non-Flex Shipments require deliveries)
          clear gs_xvttp.
          refresh gt_xvttp.
          read table i_xvttp into gs_xvttp
                         with key tknum =  <gt_new_vttk>-tknum.
          if sy-subrc <> 0.
*--Error:(V2) Non-Flex Shipments require deliveries
            message e023(ZDL_FLEX).
          endif.

        endif.
    endcase.

  endloop.
 enddo.

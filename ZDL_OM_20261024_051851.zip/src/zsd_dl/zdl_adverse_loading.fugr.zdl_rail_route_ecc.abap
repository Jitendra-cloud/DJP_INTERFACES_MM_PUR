FUNCTION zdl_rail_route_ecc.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IR_PLND_SHP_DATE) TYPE  PIQ_SELOPT_T
*"  EXPORTING
*"     REFERENCE(ET_ADVERSE_ROUT) TYPE  ZDLE11462_LT_RAIL_ROUTE_T
*"  TABLES
*"      I_T_SELECT TYPE  SRSC_S_IF_SIMPLE-T_SELECT OPTIONAL
*"      I_T_FIELDS TYPE  SRSC_S_IF_SIMPLE-T_FIELDS OPTIONAL
*"----------------------------------------------------------------------

  TYPES: BEGIN OF t_cond,
           knumh TYPE knumh,
           kappl TYPE kappl,
           kschl TYPE kschl,
           vstel TYPE vstel,
           vsbed TYPE vsbed,
           kunwe TYPE kunwe,
           zip   TYPE /saprgx/cstvnd_zip10,
           datbi TYPE kodatbi,
           datab TYPE kodatab,
         END OF t_cond.

  TYPES: BEGIN OF t_rail_route.
           INCLUDE TYPE zdle11462_lt_rail_route.
           TYPES: knumh TYPE knumh,
         END OF t_rail_route.

  TYPES: t_kappl TYPE RANGE OF kappl.
  TYPES: t_kschl TYPE RANGE OF kschl.

  DATA: lr_kappl TYPE t_kappl.
  DATA: lr_kschl TYPE t_kschl.
  DATA: lr_valid_date TYPE RANGE OF sy-datum.

  DATA: lt_cond TYPE SORTED TABLE OF t_cond
        WITH NON-UNIQUE KEY knumh.
  DATA: lt_rail_route TYPE STANDARD TABLE OF t_rail_route.

  REFRESH lt_rail_route[].

* Fill the ranges
  LOOP AT i_t_select INTO DATA(ls_select).

    CASE ls_select-fieldnm.
      WHEN 'KAPPL'.
        lr_kappl = VALUE #( ( sign   = ls_select-sign
                              option = ls_select-option
                              low    = ls_select-low
                              high   = ls_select-high ) ).

      WHEN 'KSCHL'.
        lr_kschl = VALUE #( ( sign = ls_select-sign
                              option = ls_select-option
                              low    = ls_select-low
                              high   = ls_select-high ) ).
    ENDCASE.
  ENDLOOP.


  lr_valid_date = VALUE #( ( sign   = 'I'
                             option = 'BT'
                             low    = '00010101'
                             high   = '99991231' ) ).

* Select Data
  SELECT
    knumh,
    kappl,
    kschl,
    vstel,
    @space AS vsbed,
    kunwe,
    cstvnd_zip10,
    datbi,
    datab
  FROM kot2911
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
      AND datab IN @lr_valid_date
      AND datbi IN @lr_valid_date

  UNION

  SELECT
    knumh,
    kappl,
    kschl,
    vstel,
    @space AS vsbed,
    kunwe,
    cstvnd_zip5,
    datbi,
    datab
  FROM kot2909
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
      AND datab IN @lr_valid_date
      AND datbi IN @lr_valid_date

  UNION

  SELECT
    knumh,
    kappl,
    kschl,
    vstel,
    vsbed,
    kunwe,
    @space AS zip,
    datbi,
    datab
  FROM kot2902
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
      AND datab IN @lr_valid_date
      AND datbi IN @lr_valid_date

  UNION

  SELECT
    knumh,
    kappl,
    kschl,
    vstel,
    @space AS vsbed,
    kunwe,
    @space AS zip,
    datbi,
    datab
  FROM kot2907
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
      AND datab IN @lr_valid_date
      AND datbi IN @lr_valid_date

  UNION

  SELECT
    knumh,
    kappl,
    kschl,
    @space AS vstel,
    vsbed,
    @space AS kunwe,
    @space AS zip,
    datbi,
    datab
  FROM kot2908
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
      AND datab IN @lr_valid_date
      AND datbi IN @lr_valid_date

        UNION

  SELECT
    knumh,
    kappl,
    kschl,
    vstel,
    @space AS vsbed,
    @space AS kunwe,
    @space AS zip,
    datbi,
    datab
  FROM kot2910
    WHERE kappl IN @lr_kappl[]
      AND kschl IN @lr_kschl[]
      AND datab IN @lr_valid_date
      AND datbi IN @lr_valid_date

  INTO TABLE @lt_cond.


  "Get Condition Record Header/Items
  IF lt_cond[] IS NOT INITIAL.

    SELECT
      kondh~knumh,
      kondp~kposn,
      kondh~kotabnr,
      kondh~kappl,
      kondh~kschl,
      kondp~route,
      tvro~tdlnr,
      tvro~routid,
      kondp~serv_preference,
      kondp~non_compliance
    FROM /saprgx/kond2 AS kondh
      JOIN /saprgx/kond2p AS kondp ON kondh~knumh = kondp~knumh
      JOIN tvro ON kondp~route = tvro~route
    INTO CORRESPONDING FIELDS OF TABLE @lt_rail_route
      FOR ALL ENTRIES IN @lt_cond
    WHERE kondh~knumh = @lt_cond-knumh.

  ENDIF.

  LOOP AT lt_rail_route ASSIGNING FIELD-SYMBOL(<ls_rail_route>).

    DATA(ls_cond) =
     VALUE #( lt_cond[ knumh = <ls_rail_route>-knumh ] OPTIONAL ).

    "Ship-to-Party
    <ls_rail_route>-kunwe = ls_cond-kunwe.

    "Shp Pt/Rec Pt
    <ls_rail_route>-vstel = ls_cond-vstel.

    "Shp cond
    <ls_rail_route>-vsbed = ls_cond-vsbed.

    "SAP Route
    <ls_rail_route>-routid4 =
      substring_to( val = <ls_rail_route>-routid sub = ` ` ).

    <ls_rail_route>-routid4 = condense( <ls_rail_route>-routid4 ).

    WRITE: <ls_rail_route>-routid4
      TO <ls_rail_route>-routid4 RIGHT-JUSTIFIED.

    "Get Route Desc
    SELECT SINGLE bezei FROM tvrot INTO <ls_rail_route>-bezei
      WHERE spras = sy-langu AND route = <ls_rail_route>-route.

    "Get Postal code
    <ls_rail_route>-pstlz = ls_cond-zip.

    "Valid From
    <ls_rail_route>-datab = ls_cond-datab.
    "Valid to
    <ls_rail_route>-datbi = ls_cond-datbi.

  ENDLOOP.

  SORT lt_rail_route BY kotabnr datab knumh serv_preference.

*  e_t_data[] = CORRESPONDING #( lt_rail_route ).
  et_adverse_rout = CORRESPONDING #( lt_rail_route ).

ENDFUNCTION.

FUNCTION zdl_trigger_output_cond.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(IV_KAPPL) TYPE  SNA_KAPPL
*"     VALUE(IV_OBJKY) TYPE  NA_OBJKEY
*"     VALUE(IV_KSCHL) TYPE  SNA_KSCHL
*"     VALUE(IV_VSTAT) TYPE  NA_VSTAT
*"----------------------------------------------------------------------

  TABLES: nast.

  DATA: lv_rcode TYPE sysubrc,
        ls_nast  TYPE nast.


* Ensure the processing of the calling program has finished updating
  WAIT UP TO 7 SECONDS.

* Retrieve unprocessed output condition NAST record for this object
  SELECT * UP TO 1 ROWS
        FROM  nast
        INTO  ls_nast
        WHERE kappl EQ iv_kappl  AND
              objky EQ iv_objky  AND
              kschl EQ iv_kschl  AND
              spras EQ sy-langu  AND
              vstat EQ iv_vstat.
  ENDSELECT.

  IF sy-subrc =  0.
    nast = ls_nast.

*   Trigger the output
    PERFORM einzelnachricht_screen(rsnast00) USING lv_rcode.
    IF lv_rcode EQ 0.
*     Store the output log in the Delivery Output
      PERFORM protocol_store(rsnast00) USING nast-kappl
                                             nast-kschl
                                    CHANGING nast-cmfpnr.
*     Update the NAST record as processed
      PERFORM nast_update(rsnast00) USING lv_rcode.
    ENDIF.
    COMMIT WORK. "required so that idoc makes it to the tRFC Queue
  ENDIF.

ENDFUNCTION.

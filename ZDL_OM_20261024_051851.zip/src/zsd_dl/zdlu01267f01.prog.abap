*----------------------------------------------------------------------*
***INCLUDE ZSDU01267F01 .
*----------------------------------------------------------------------*
***********************************************************************
**             C O M P A N Y   C O N F I D E N T I A L               **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
***********************************************************************
**           COPYRIGHT (C) 2003 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                           **
**             REVISIONS COPYRIGHT (C) 2007, 20nn                    **
**                    by INTERNATIONAL PAPER                         **
*_____________________________________________________________________*
* Report Name: ZSDU01267_CREATE_CONTAINER_HU         Date: 04/16/2007 *
* Programmer : Bruce Ballehr                                          *
*_____________________________________________________________________*
* Description :                                                       *
*   This program will allow the user to either create a Container     *
*   Handling Unit or re-issue a Container Tally.                      *
*_____________________________________________________________________*
* Change History:                                                     *
*   Programmer       Date     Req. #            Action                *
* ===============  ========  =========  ==============================*
* Bruce Ballehr    04/16/07  EDEK907765 Initial creation              *
* Kishor Thakur    09/04/07  EDEK909275 Modified to get SKIDS &       *
*                                       PALLETS characteristics       *
* Maureen Carter   04/2015   CR#13267   add container size            *
*                                       remove dead code              *
* L. Phillips     05/2016   SOLAS      add tare weight to screens     *
*                                      and input to create cont. FM.  *
***********************************************************************
*&---------------------------------------------------------------------*
*&      Form  validate_0100
*&---------------------------------------------------------------------*
*       Validate Selection Screen
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_0100 .

  DATA: lv_venum    TYPE venum,    "Internal HU
        lv_exidv    TYPE exidv,    "External HU

        lv_werks    TYPE werks_d,  "Plant work field
        lv_vbeln    TYPE vbeln_va, "Sales Order

        lv_con_size TYPE zsd_book_csz_cfg-con_size.  "container size

  CLEAR: gr_matnr,   "clear material range
         gt_matnr[]. "clear table of Sales Order materials

* Determine if Container Id and Seal Number already exist
  SELECT SINGLE venum INTO lv_venum FROM zdlu01267_vekp
    WHERE signi = zdlu01267_0100-signi
      AND seal  = zdlu01267_0100-seal.
  IF sy-subrc = 0.
    SELECT SINGLE exidv INTO lv_exidv FROM vekp
      WHERE venum = lv_venum.
    IF sy-subrc = 0.
*     Container Id and Seal Number already exist on Container HU &
      MESSAGE e009 WITH lv_exidv.
    ELSE.
*     Internal HU number & exists in VEKP but not table zdlu01267_VEKP
      MESSAGE e010 WITH lv_venum.
    ENDIF.
  ENDIF.


* Determine if Container Size is valid
  SELECT SINGLE con_size INTO lv_con_size FROM zsd_book_csz_cfg
    WHERE con_size = zdlu01267_0100-con_size.
  IF sy-subrc <> 0.
*     Invalid Container Size &
    MESSAGE e023 WITH lv_con_size.
  ENDIF.

** Validate Plant and Storage Location
* removed dead code 4/2015

* Ensure user has authority to the Plant entered on the selection screen
  AUTHORITY-CHECK OBJECT 'M_MSEG_WWA'
           ID 'ACTVT' FIELD '01'           "create mode
           ID 'WERKS' FIELD zdlu01267_0100-werks.  "plant
  IF sy-subrc NE 0.
*   No authority for plant &.
    MESSAGE e032 WITH zdlu01267_0100-werks.
  ENDIF.

* Validate user does not enter a Sales Order Item without a Sales Order
  IF zdlu01267_0100-posnr IS NOT INITIAL AND
     zdlu01267_0100-vbeln IS INITIAL.
*   Cannot enter a Sales Order Item without a Sales Order
    MESSAGE e011.
  ENDIF.

* Validate user does not enter a Sales Order or Sales Order Item if the
* checkbox on the Selection Screen is not checked (Wilmington scenario)
  IF zdlu01267_0100-use_booknum IS INITIAL.
    IF zdlu01267_0100-posnr IS NOT INITIAL OR
       zdlu01267_0100-vbeln IS NOT INITIAL.
*     Sales Order information entered will not be used to retrieve SO
*     Stock
      MESSAGE w012.
    ENDIF.
  ENDIF.

* Validate Sales Order / SO Item if entered. Retrieve Material info
* for later use
  IF zdlu01267_0100-vbeln IS NOT INITIAL.

    IF zdlu01267_0100-posnr IS NOT INITIAL.
*     Get the Material number for the SO entered
      SELECT matnr INTO TABLE gt_matnr FROM vbap
        WHERE vbeln EQ zdlu01267_0100-vbeln
          AND posnr EQ zdlu01267_0100-posnr.
      IF sy-subrc NE 0.
*       Invalid Sales Order and Item combination
        MESSAGE e016.
      ENDIF.

    ELSE.
*     Get all Material numbers for the SO entered
      SELECT DISTINCT matnr INTO TABLE gt_matnr FROM vbap
        WHERE vbeln EQ zdlu01267_0100-vbeln.
      IF sy-subrc NE 0.
*       Invalid Sales Order
        MESSAGE e017.
      ENDIF.
    ENDIF.

  ENDIF.

ENDFORM.                    " validate_0100
*&---------------------------------------------------------------------*
*&      Form  retrieve_data
*&---------------------------------------------------------------------*
*       Retrieve data based on Selection Screen parameters
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM retrieve_data .

  TYPE-POOLS: zsdc.

  TYPES:

*   Booking item info
    BEGIN OF lts_book_itm,
      vbeln TYPE zsd_book_vbeln, "SO
      posnr TYPE zsd_book_posnr, "SO item
    END OF lts_book_itm,

*   HU header info
    BEGIN OF lts_vekp,
      venum  TYPE venum,   "internal HU
      exidv  TYPE exidv,   "external HU
      vpobj  TYPE vpobj,   "assignment status of HU
      uevel  TYPE uevel,   "upper level Parent HU
      status TYPE hu_status, "HU status
    END OF lts_vekp,

*   HU item info
    BEGIN OF lts_vepo,
      venum TYPE venum,   "internal HU
      charg TYPE charg_d, "batch
      vemng TYPE vemng,   "HU qty in base
      vemeh TYPE vemeh,   "HU qty uom
    END OF lts_vepo,

*   Material descriptions
    BEGIN OF lts_makt,
      matnr TYPE matnr,   "material
      maktx TYPE maktx,   "mateial desc
    END OF lts_makt,

*   Material Group
    BEGIN OF lts_matkl,
      matnr TYPE matnr,   "material
      matkl TYPE matkl,   "material group
    END OF lts_matkl,

*   PO header
    BEGIN OF lts_ekko,
      ebeln   TYPE ebeln, "PO num
      zzvbeln TYPE zsde3483_vbeln,
      zzposnr TYPE zsde3483_posnr,
    END OF lts_ekko,

*   PO history
    BEGIN OF lts_ekbe,
      belnr TYPE mblnr,   "material document
      buzei TYPE mblpo,   "material doc item
      ebeln TYPE ebeln,   "po number
    END OF lts_ekbe,

*   Delivery item
    BEGIN OF lts_lips,
      matnr TYPE matnr,   "material
      charg TYPE charg_d, "batch
      vbeln TYPE vbeln_vl, "sto delivery
    END OF lts_lips,

*   Batch stock
    BEGIN OF lts_mchb,
      matnr TYPE matnr,   "material
      charg TYPE charg_d, "batch
    END OF lts_mchb,

* Changes for  Skid & Carton
*   Material Group
    BEGIN OF lts_matgrp,
      fieldname TYPE fieldname,   " Fieldname
      lowval    TYPE zsp_lowval,  "material group
    END OF lts_matgrp,

* sales order partners
    BEGIN OF lts_vbpa,
      vbeln TYPE vbeln,
      parvw TYPE parvw,
      kunnr TYPE kunnr,
    END OF lts_vbpa,

* sales order metric indicator
    BEGIN OF lts_vbak_met_ind,
      vbeln         TYPE vbeln,
      zz_metric_ind TYPE zz_metric_indicator,
    END OF lts_vbak_met_ind.




  DATA:

*   Booking item info
    lt_book_itm       TYPE STANDARD TABLE OF lts_book_itm,
    ls_book_itm       TYPE lts_book_itm,

*   HU header info
    lt_vekp           TYPE STANDARD TABLE OF lts_vekp,
    ls_vekp           TYPE lts_vekp,

*   HU item info
    lt_vepo           TYPE STANDARD TABLE OF lts_vepo,
    ls_vepo           TYPE lts_vepo,

*   Batch characteristics
    lt_classification TYPE STANDARD TABLE OF conf_out,
    ls_classification TYPE conf_out,

*   Material descriptions
    lt_makt           TYPE STANDARD TABLE OF lts_makt,
    ls_makt           TYPE lts_makt,

*   Material descriptions
    lt_matkl          TYPE STANDARD TABLE OF lts_matkl,
    ls_matkl          TYPE lts_matkl,

*   PO header
    lt_ekko           TYPE STANDARD TABLE OF lts_ekko,
    ls_ekko           TYPE lts_ekko,

*   PO history
    lt_ekbe           TYPE STANDARD TABLE OF lts_ekbe,
    ls_ekbe           TYPE lts_ekbe,

*   Delivery item
    lt_lips           TYPE STANDARD TABLE OF lts_lips,
    ls_lips           TYPE lts_lips,

*   Batch stock
    lt_mchb           TYPE STANDARD TABLE OF lts_mchb,
    ls_mchb           TYPE lts_mchb,

*   Material groups for different characteristics read
    lt_matgrp         TYPE STANDARD TABLE OF lts_matgrp,
    ls_matgrp         TYPE lts_matgrp,

* sales order partners
    lt_vbpa           TYPE STANDARD TABLE OF lts_vbpa,
    ls_vbpa           TYPE lts_vbpa,

* sales order metric indicator
    lt_vbak_met_ind   TYPE STANDARD TABLE OF lts_vbak_met_ind,
    ls_vbak_met_ind   TYPE lts_vbak_met_ind.

  DATA:

    lv_tabix        TYPE  sytabix,
    lv_hold_matnr   TYPE  matnr,
    lv_hold_kunag   TYPE  kunag,  "sold-to
    lv_hold_kunwe   TYPE  kunwe,  "ship-to
    lv_hold_met_ind TYPE  zz_metric_indicator.


  CONSTANTS:

*   HU is in unassigned mode
    lc_unassigned TYPE  vpobj     VALUE '12',

*   HU status of deleted
    lc_deleted    TYPE  hu_status VALUE '0060'.


  RANGES:

    lr_vbeln FOR zdlu01267_0100-vbeln, "Sales Order
    lr_posnr FOR zdlu01267_0100-posnr, "Sales Order item

    lr_matkl FOR zdl_fields-fieldname. "range of Bale Pulp Mater grps

***********************************************************************
* MACRO: get_value_from_zdl_fields
*   removed dead code 4/2015


* Put up message - retrieving data
  CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
    EXPORTING
      text = text-002.

* Populate Ranges for Sales Order and Sales Order Item if necessary
  IF zdlu01267_0100-vbeln IS NOT INITIAL.  "Sales Order
    lr_vbeln-sign   = 'I'.
    lr_vbeln-option = 'EQ'.
    lr_vbeln-low    = zdlu01267_0100-vbeln.
    APPEND lr_vbeln.
*   Only format SO item of SO has a value
    IF zdlu01267_0100-posnr IS NOT INITIAL. "Sales Order item
      lr_posnr-sign   = 'I'.
      lr_posnr-option = 'EQ'.
      lr_posnr-low    = zdlu01267_0100-posnr.
      APPEND lr_posnr.
    ENDIF.
  ENDIF.

* Retrieve Booking Document(s) based on Book Conf Num entered as
* well as the Plant entered on the selection screen
  SELECT bookdoc INTO TABLE gt_book_hdr FROM zsd_book_hdr
    WHERE booknum    = zdlu01267_0100-booknum
      AND plant_code = zdlu01267_0100-werks.
  IF sy-subrc NE 0.
*   Booking Confirmation Number not found on table ZSD_BOOK_HDR for
*   Plant &
    MESSAGE e013 WITH zdlu01267_0100-werks.
  ELSEIF sy-dbcnt > 1.
*  If multiple Booking Documents exist for the same Booking Conf Num
*  in the same Plant then use the Booking Document with the greatest
*  Book Doc number
    SORT gt_book_hdr BY bookdoc DESCENDING. "Latest book doc in 1st row
    DELETE gt_book_hdr FROM 2 TO sy-dbcnt.  "delete 2nd row on
  ENDIF.
  READ TABLE gt_book_hdr INTO gs_book_hdr INDEX 1. "Store data in struc

* Retrieve SO information from Booking Document if user specified to use
* Sales Order info the retrieval of stock records.
  CLEAR: gv_booking_vbeln.
  IF zdlu01267_0100-use_booknum = gc_true.
    SELECT vbeln   "Sales Order
           posnr   "SO Item
      INTO TABLE lt_book_itm
      FROM zsd_book_itm
      WHERE bookdoc = gs_book_hdr-bookdoc  "booking document from hdr
        AND vbeln  IN lr_vbeln             "sel screen Sales Order
        AND posnr  IN lr_posnr.            "sel screen Sales Order Item
    IF sy-subrc NE 0.
*     No Booking Item info found on ZSD_BOOK_ITM for Book Conf Num and
*     SO info
      MESSAGE e018.
    ENDIF.

* Otherwise, if this is a Wilmington type scenario where Batch Stock
* is NOT tied to a Sales Order, retrieve the Sales Order from the
* Booking Confirmation number. We'll need to pass it to the 'create
* container' function module so the print program can determine the
* partners of the sales order to issue the Container Tally output.
  ELSE.
    SELECT vbeln INTO gv_booking_vbeln FROM zsd_book_itm
      WHERE bookdoc = gs_book_hdr-bookdoc  "booking document from hdr
        AND vbeln  IN lr_vbeln             "sel screen Sales Order
        AND posnr  IN lr_posnr.            "sel screen Sales Order Item
      EXIT.
    ENDSELECT.
  ENDIF.

* If we're using Sales Order information from the Booking
* Document then store those associated Material numbers in a table.
  CLEAR: lv_hold_matnr.
  IF lt_book_itm[] IS NOT INITIAL.
    SELECT DISTINCT matnr INTO TABLE gt_matnr FROM vbap
      FOR ALL ENTRIES IN lt_book_itm
      WHERE vbeln = lt_book_itm-vbeln.
  ENDIF.

* Populate Material Range using Material(s) from EITHER Sales Order(s)
* from the Booking Document OR the Sales Order specified on the
* selection screen. The range will allow for better performance on the
* SELECT statements
  IF gt_matnr[] IS NOT INITIAL.
    LOOP AT gt_matnr INTO gs_matnr.
      gr_matnr-sign   = 'I'.
      gr_matnr-option = 'EQ'.
      gr_matnr-low    = gs_matnr-matnr.
    ENDLOOP.
  ENDIF.

* Retrieve Batch info for MTO Materials from Sales Order Stock if user
* specifed to use Sales Order info as a filter
  CLEAR: gt_alv[].
  IF zdlu01267_0100-use_booknum = gc_true AND
     lt_book_itm[] IS NOT INITIAL.
    IF  zdlu01267_0100-lgort IS NOT INITIAL.
      SELECT matnr  "material
             charg  "batch
             vbeln  "so
             posnr  "so item
             werks  "Plant
             lgort  "Storage Location
        INTO CORRESPONDING FIELDS OF TABLE gt_alv
        FROM mska
        FOR ALL ENTRIES IN lt_book_itm
        WHERE matnr IN gr_matnr
          AND werks = zdlu01267_0100-werks
          AND lgort = zdlu01267_0100-lgort
          AND vbeln = lt_book_itm-vbeln
          AND posnr = lt_book_itm-posnr
          AND ( kalab > 0  OR              "valuated stock / unrestr use
                kains > 0 ).               "stock in qual insp
    ELSE.
      SELECT matnr  "material
             charg  "batch
             vbeln  "so
             posnr  "so item
             werks  "Plant
             lgort  "Storage Location
        INTO CORRESPONDING FIELDS OF TABLE gt_alv
        FROM mska
        FOR ALL ENTRIES IN lt_book_itm
        WHERE matnr IN gr_matnr
          AND werks = zdlu01267_0100-werks
*         AND lgort = zdlu01267_0100-lgort
          AND vbeln = lt_book_itm-vbeln
          AND posnr = lt_book_itm-posnr
          AND ( kalab > 0  OR              "valuated stock / unrestr use
                kains > 0 ).               "stock in qual insp
    ENDIF.

  ELSE.
*   User specified to NOT use Sales Order as a filter
    IF  zdlu01267_0100-lgort IS NOT INITIAL.
      SELECT matnr  "material
             charg  "batch
             vbeln  "so
             posnr  "so item
             werks  "Plant
             lgort  "Storage Location
        INTO CORRESPONDING FIELDS OF TABLE gt_alv
        FROM mska
        WHERE matnr IN gr_matnr
          AND werks = zdlu01267_0100-werks
          AND lgort = zdlu01267_0100-lgort
          AND vbeln IN lr_vbeln
          AND posnr IN lr_posnr
          AND ( kalab > 0  OR              "valuated stock / unrestr use
                kains > 0 ).               "stock in qual insp
    ELSE.
      SELECT matnr  "material
         charg  "batch
         vbeln  "so
         posnr  "so item
         werks  "Plant
         lgort  "Storage Location
    INTO CORRESPONDING FIELDS OF TABLE gt_alv
    FROM mska
    WHERE matnr IN gr_matnr
      AND werks = zdlu01267_0100-werks
*       AND lgort = zdlu01267_0100-lgort
      AND vbeln IN lr_vbeln
      AND posnr IN lr_posnr
      AND ( kalab > 0  OR              "valuated stock / unrestr use
            kains > 0 ).               "stock in qual insp
    ENDIF.
  ENDIF.


* Retrieve Batch info for MTS Materials from Batch Stock using Sales
* Order info as a filter
  IF zdlu01267_0100-use_booknum = gc_true AND
     lt_book_itm[] IS NOT INITIAL.
*   Get all PO numbers based on the Sales Order info from the Booking
    SELECT ebeln
           zzvbeln
           zzposnr
      INTO TABLE lt_ekko FROM ekko
      FOR ALL ENTRIES IN lt_book_itm
      WHERE zzvbeln = lt_book_itm-vbeln
        AND zzposnr = lt_book_itm-posnr
        AND loekz   = space.
    IF sy-subrc = 0.
      SORT lt_ekko BY ebeln.
*     Select all STO deliveries from purchase order history table
      SELECT belnr  "material document number
             buzei  "item in material document
             ebeln  "po number
      INTO TABLE lt_ekbe FROM ekbe
        FOR ALL ENTRIES IN lt_ekko
        WHERE ebeln = lt_ekko-ebeln
          AND vgabe   = '8'.                 "Type STO Delivery
      IF sy-subrc = 0.
        SORT lt_ekbe BY belnr.
*       Get all batches from the delivery line item table associated
*       with the PO history table
        SELECT matnr  "material
               charg  "batch
               vbeln  "sto delivery
          INTO TABLE lt_lips FROM lips
          FOR ALL ENTRIES IN lt_ekbe
          WHERE vbeln = lt_ekbe-belnr
            AND matnr IN gr_matnr.    "material range
        IF sy-subrc = 0.
          DELETE lt_lips WHERE charg IS INITIAL.
          SORT lt_lips BY matnr charg.
*         Confirm physical inventory exists. Only keep those batches
*         with stock
          IF zdlu01267_0100-lgort IS NOT INITIAL.
            SELECT matnr
                   charg
              INTO TABLE lt_mchb FROM mchb
              FOR ALL ENTRIES IN lt_lips
              WHERE matnr = lt_lips-matnr         "material
                AND werks = zdlu01267_0100-werks  "plant
                AND lgort = zdlu01267_0100-lgort  "sloc
                AND charg = lt_lips-charg         "batch
                AND ( clabs   > 0  OR   "Valuated stock/unrestr use
                      cinsm   > 0 ).    "Stock in Qual Inspection
          ELSE.
            SELECT matnr
              charg
         INTO TABLE lt_mchb FROM mchb
         FOR ALL ENTRIES IN lt_lips
         WHERE matnr = lt_lips-matnr         "material
           AND werks = zdlu01267_0100-werks  "plant
*             AND lgort = zdlu01267_0100-lgort  "sloc
           AND charg = lt_lips-charg         "batch
           AND ( clabs   > 0  OR   "Valuated stock/unrestr use
                 cinsm   > 0 ).    "Stock in Qual Inspection
          ENDIF.

          IF sy-subrc = 0.
*           Start building ALV Grid data
            LOOP AT lt_mchb INTO ls_mchb.
              READ TABLE lt_lips INTO ls_lips
                WITH KEY matnr = ls_mchb-matnr
                         charg = ls_mchb-charg
                BINARY SEARCH.
              IF sy-subrc = 0.
                READ TABLE lt_ekbe INTO ls_ekbe
                  WITH KEY belnr = ls_lips-vbeln
                  BINARY SEARCH.
                IF sy-subrc = 0.
                  READ TABLE lt_ekko INTO ls_ekko
                    WITH KEY ebeln = ls_ekbe-ebeln.
                  IF sy-subrc = 0.
                    CLEAR: gs_alv.
                    gs_alv-vbeln = ls_ekko-zzvbeln.
                    gs_alv-posnr = ls_ekko-zzposnr.
                    gs_alv-matnr = ls_mchb-matnr.
                    gs_alv-charg = ls_mchb-charg.
                    APPEND gs_alv TO gt_alv.
                  ENDIF.

                ENDIF.

              ENDIF.

            ENDLOOP.

          ENDIF.

        ENDIF.

      ENDIF.

    ENDIF.

  ELSE.
*   Retrieve Batch info for MTS Materials from Batch Stock using
*   Sales Order info as a filter
    IF zdlu01267_0100-lgort IS NOT INITIAL.
      SELECT matnr    "Material
             charg    "Batch
             werks    "Plant
             lgort    "Storage Location
        APPENDING CORRESPONDING FIELDS OF TABLE gt_alv
        FROM mchb
        WHERE matnr  IN gr_matnr
          AND werks   = zdlu01267_0100-werks "Plant
          AND lgort   = zdlu01267_0100-lgort "Stor loc
          AND lvorm   = space                "not deleted
          AND ( clabs   > 0  OR              "Valuated stock/unrestr use
                cinsm   > 0 ).               "Stock in Qual Inspection
    ELSE.
      SELECT matnr    "Material
             charg    "Batch
             werks    "Plant
             lgort    "Storage Location
   APPENDING CORRESPONDING FIELDS OF TABLE gt_alv
   FROM mchb
   WHERE matnr  IN gr_matnr
     AND werks   = zdlu01267_0100-werks "Plant
*       AND lgort   = zdlu01267_0100-lgort "Stor loc
     AND lvorm   = space                "not deleted
     AND ( clabs   > 0  OR              "Valuated stock/unrestr use
           cinsm   > 0 ).               "Stock in Qual Inspection
    ENDIF.
  ENDIF.

* Filter out any entries without a Batch. An entry may not have a batch
* because there was no inventory
  DELETE gt_alv WHERE charg IS INITIAL.

  CLEAR: lt_vepo[].
  CLEAR: lt_vekp[].

* Retrieve HU item information
  IF gt_alv[] IS NOT INITIAL.
    SORT gt_alv BY matnr charg.
    IF zdlu01267_0100-lgort IS NOT INITIAL.
      SELECT venum   "internal HU
             charg   "batch
             vemng   "hu qty
             vemeh   "hu uom
        INTO TABLE lt_vepo FROM vepo
        FOR ALL ENTRIES IN gt_alv
        WHERE matnr = gt_alv-matnr
          AND werks = zdlu01267_0100-werks
          AND lgort = zdlu01267_0100-lgort
          AND charg = gt_alv-charg.
    ELSE.
      SELECT venum   "internal HU
        charg   "batch
        vemng   "hu qty
        vemeh   "hu uom
   INTO TABLE lt_vepo FROM vepo
   FOR ALL ENTRIES IN gt_alv
   WHERE matnr = gt_alv-matnr
     AND werks = zdlu01267_0100-werks
*    AND lgort = zdlu01267_0100-lgort
     AND charg = gt_alv-charg.
    ENDIF.

*   Retrieve HU header info
    IF lt_vepo[] IS NOT INITIAL.
      SORT gt_alv BY venum.
      SELECT venum   "internal HU
             exidv   "external hu
             vpobj   "HU object assignment
             uevel   "parent hu
             status  "HU status
        INTO TABLE lt_vekp FROM vekp
        FOR ALL ENTRIES IN lt_vepo
        WHERE venum = lt_vepo-venum.
      SORT lt_vekp BY venum.
    ENDIF.
  ENDIF.

* Merge HU information into work table
  SORT lt_vepo BY charg.
  LOOP AT gt_alv INTO gs_alv.
    lv_tabix = sy-tabix.
*   Retrieve HU item information
    READ TABLE lt_vepo INTO ls_vepo WITH KEY charg = gs_alv-charg
      BINARY SEARCH.
    IF sy-subrc = 0.
      READ TABLE lt_vekp INTO ls_vekp WITH KEY venum = ls_vepo-venum
        BINARY SEARCH.
      IF sy-subrc = 0.

        IF ls_vekp-status =  lc_deleted    OR   "HU status is deleted
           ls_vekp-vpobj  NE lc_unassigned OR   "HU must be unassigned
           ls_vekp-uevel IS NOT INITIAL. "HU has a parent HU

*         If HU is in a deleted status or is already in a Container
*         then remove the record
          DELETE gt_alv INDEX lv_tabix.

        ELSE.
          gs_alv-venum = ls_vepo-venum. "internal hu
          gs_alv-exidv = ls_vekp-exidv. "external hu
          gs_alv-vemng = ls_vepo-vemng. "hu qty
          gs_alv-vemeh = ls_vepo-vemeh. "hu qty uom
          gs_alv-uevel = ls_vekp-uevel. "parent hu
          MODIFY gt_alv FROM gs_alv INDEX lv_tabix
            TRANSPORTING venum exidv vemng vemeh uevel.
        ENDIF.

      ELSE.
*       No corresponding HU header (should never happen)
        DELETE gt_alv INDEX lv_tabix.
      ENDIF.

    ELSE.
*     No HU Item exists for Batch so delete
      DELETE gt_alv INDEX lv_tabix.
    ENDIF.
  ENDLOOP.

* If no Batch information exists after SELECTion and filtering then
* display error
  IF gt_alv[] IS INITIAL.
*   Invalid selection criteria. No data was retrieved.
    MESSAGE e015.
  ENDIF.

* Retrieve associated Material Group for each material
  SORT gt_alv BY matnr.
  SELECT DISTINCT matnr  "material
                  matkl  "material group
    INTO TABLE lt_matkl
    FROM mara
    FOR ALL ENTRIES IN gt_alv
    WHERE matnr = gt_alv-matnr.
  SORT lt_matkl BY matnr.

  lr_matkl-sign   =  'I'.
  lr_matkl-option =  'EQ'.
  lr_matkl-low =  gc_skid.  "SKIDS
  APPEND lr_matkl.
  lr_matkl-low = gc_bales.  "Bales
  APPEND lr_matkl.
  lr_matkl-low = gc_carton. "Carton
  APPEND lr_matkl.
  CLEAR lr_matkl.

  SELECT fieldname
         lowval
  INTO TABLE lt_matgrp
  FROM zdl_fields
  WHERE category = 'F01316'
  AND   fieldname IN lr_matkl.


* Determine the UNITS for each ALV item
  CLEAR: lv_hold_matnr.
  LOOP AT gt_alv INTO gs_alv.
    lv_tabix = sy-tabix.

*   Determine material group for the current material
    IF gs_alv-matnr NE lv_hold_matnr.
      READ TABLE lt_matkl INTO ls_matkl WITH KEY matnr = gs_alv-matnr
        BINARY SEARCH.
    ENDIF.
    lv_hold_matnr = gs_alv-matnr.

    READ TABLE lt_matgrp INTO ls_matgrp WITH KEY lowval = ls_matkl-matkl.
    IF sy-subrc <> 0.
      gs_alv-units = 1.
      MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                           TRANSPORTING units.
    ELSE.
*     Retrieve Batch Characteristic for Bale Pulp to format UNITS
      CALL FUNCTION 'VB_BATCH_VALUES_FOR_OUTPUT'
        EXPORTING
          material               = gs_alv-matnr
          plant                  = zdlu01267_0100-werks
          batch                  = gs_alv-charg
          language               = sy-langu
        TABLES
          classification         = lt_classification
        EXCEPTIONS
          no_classification_data = 1
          OTHERS                 = 2.
      IF sy-subrc NE 0.
*       Batch Characteristics do not exist for Material/Batch so remove
*       the record
        DELETE gt_alv INDEX lv_tabix.
      ELSE.
        SORT lt_classification BY atnam.
*Read characteristics for Bales
        CASE ls_matgrp-fieldname.

          WHEN gc_bales.

*       Check for characteristic BALES_PER_BATCH
            READ TABLE lt_classification INTO ls_classification
                WITH KEY atnam = zsdc_bales_per_batch
                BINARY SEARCH.
            IF sy-subrc = 0.
              gs_alv-units = ls_classification-atwrt.
              MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                TRANSPORTING units.
            ELSE.
*         Default 0 into the UNITS field
              gs_alv-units = 0.
              MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                TRANSPORTING units.
            ENDIF. "read of lt_classification for bales

          WHEN gc_skid.

* Check for SKID characteristic
            READ TABLE lt_classification INTO ls_classification
                WITH KEY atnam = zsdc_packages_per_unit
                                          BINARY SEARCH.
            IF sy-subrc = 0.
              gs_alv-units = ls_classification-atwrt.
              MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                TRANSPORTING units.
            ELSE.
*         Default 0 into the UNITS field
              gs_alv-units = 0.
              MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                TRANSPORTING units.
            ENDIF. "read of lt_classification

          WHEN gc_carton.

* Check for SKID characteristic
            READ TABLE lt_classification INTO ls_classification
                WITH KEY atnam = zsdc_cartons_per_pallet
                                          BINARY SEARCH.
            IF sy-subrc = 0.
              gs_alv-units = ls_classification-atwrt.
              MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                TRANSPORTING units.
            ELSE.
*         Default 0 into the UNITS field
              gs_alv-units = 0.
              MODIFY gt_alv FROM gs_alv INDEX lv_tabix
                TRANSPORTING units.
            ENDIF. "read of lt_classification
        ENDCASE.

      ENDIF. "subrc check on function VB_BATCH...
    ENDIF.  "if bale pulp material group

  ENDLOOP.

* Retrieve SAP Material Description
  SELECT DISTINCT matnr   "material
                  maktx   "material desc
    INTO TABLE lt_makt
    FROM makt
    FOR ALL ENTRIES IN gt_alv
    WHERE matnr = gt_alv-matnr
      AND spras = sy-langu.
  SORT lt_makt BY matnr.

* Merge Material Description into work table
  LOOP AT gt_alv INTO gs_alv.
    lv_tabix = sy-tabix.
    READ TABLE lt_makt INTO ls_makt WITH KEY matnr = gs_alv-matnr
      BINARY SEARCH.
    IF sy-subrc = 0.
      gs_alv-maktx = ls_makt-maktx.
      MODIFY gt_alv FROM gs_alv INDEX lv_tabix
        TRANSPORTING maktx.
    ENDIF.
  ENDLOOP.

* Determine Bundled Rolls
  PERFORM determine_bundled_rolls.


* collect sold-to and ship-to for each sales order
  IF NOT gt_alv IS INITIAL.
    SELECT vbeln parvw kunnr FROM vbpa INTO TABLE lt_vbpa
      FOR ALL ENTRIES IN gt_alv
      WHERE vbeln = gt_alv-vbeln
        AND ( parvw = 'AG'               "sold-to
              OR parvw = 'WE' ).         "ship-to
    SORT lt_vbpa BY vbeln parvw.
  ENDIF.

* collect metric indicator from each sales order
  IF NOT gt_alv IS INITIAL.
    SELECT vbeln zz_metric_ind FROM vbak INTO TABLE lt_vbak_met_ind
      FOR ALL ENTRIES IN gt_alv
      WHERE vbeln = gt_alv-vbeln.
    SORT lt_vbak_met_ind BY vbeln.
  ENDIF.

* add partners and met indicator to the output
  LOOP AT gt_alv INTO gs_alv.
    lv_tabix = sy-tabix.
    IF NOT gs_alv-vbeln IS INITIAL.
      READ TABLE lt_vbpa INTO ls_vbpa
           WITH KEY vbeln = gs_alv-vbeln
                    parvw = 'AG'       "sold_to
           BINARY SEARCH.
      IF sy-subrc = 0.
        gs_alv-kunnr = ls_vbpa-kunnr.
      ENDIF.
      READ TABLE lt_vbpa INTO ls_vbpa
           WITH KEY vbeln = gs_alv-vbeln
                    parvw = 'WE'       "sold_to
           BINARY SEARCH.
      IF sy-subrc = 0.
        gs_alv-kunwe = ls_vbpa-kunnr.
      ENDIF.
      READ TABLE lt_vbak_met_ind INTO ls_vbak_met_ind
           WITH KEY vbeln = gs_alv-vbeln
           BINARY SEARCH.
      IF sy-subrc = 0.
        gs_alv-zz_metric_ind = ls_vbak_met_ind-zz_metric_ind.
      ENDIF.
      MODIFY gt_alv FROM gs_alv INDEX lv_tabix.
    ENDIF.
  ENDLOOP.

  CLEAR: lt_vbpa,
         lt_vbak_met_ind.

* Perform initial Sort on data
  SORT gt_alv BY vbeln
                 posnr
                 matnr
                 charg.

ENDFORM.                    " retrieve_data
*&---------------------------------------------------------------------*
*&      Form  display_alv
*&---------------------------------------------------------------------*
*       Display the ALV Grid
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM display_alv .

* Create Container object if it doesn't exist
  IF go_grid IS INITIAL.

*   Create custom screen container control object
    CREATE OBJECT go_container
      EXPORTING
        container_name = go_custom_control.

    IF sy-subrc = 0.

*     Create Handling Events Object
      CREATE OBJECT go_event_handler.

*     Create the ALV Grid object and associate it with the custom screen
*     container control object
      CREATE OBJECT go_grid
        EXPORTING
          i_parent = go_container.

      IF sy-subrc = 0.

*       Register Handler Methods
        SET HANDLER go_event_handler->handle_double_click FOR go_grid.


*       Prepare the field catalog for the ALV Grid
        PERFORM prepare_field_catalog CHANGING gt_fieldcat.

*       Prepare the layout structure for the ALV Grid
        PERFORM prepare_layout CHANGING gs_layout.

*       Display the ALV Grid for the first time with all of the
*       retrieved data based on the Selection Screen parms
        CALL METHOD go_grid->set_table_for_first_display
          EXPORTING
            is_variant                    = gv_is_variant
            i_save                        = 'A'
            "can save global and local
            is_layout                     = gs_layout   "layouts
            it_toolbar_excluding          = gt_exclude_toolbar
          CHANGING
            it_outtab                     = gt_alv
            it_fieldcatalog               = gt_fieldcat
          EXCEPTIONS
            invalid_parameter_combination = 1
            program_error                 = 2
            too_many_lines                = 3
            OTHERS                        = 4.

      ENDIF. "create alv grid

    ENDIF. "create custom container control

  ELSE.

*   Refresh ALV Grid for redisplay
    CALL METHOD go_grid->refresh_table_display.

*   If user had selected rows of grid then clicked BACK or CANC then
*   we want to preselect those same entries again for them
    IF gt_index_rows[] IS NOT INITIAL AND
      ( ok_code = 'BACK' OR ok_code = 'CANC' ).
      CALL METHOD go_grid->set_selected_rows
        EXPORTING
          it_index_rows = gt_index_rows.
      CLEAR: gt_index_rows[].
    ENDIF.

*   Send ALV Grid changes to the screen (refresh)
    CALL METHOD cl_gui_cfw=>flush.

  ENDIF. "create container

ENDFORM.                    " display_alv
*&---------------------------------------------------------------------*
*&      Form  prepare_field_catalog
*&---------------------------------------------------------------------*
*       Convert the ALV structure to the ALV field catalog structure.
*       Change the attributes of certain fields based on user
*       requirements.
*----------------------------------------------------------------------*
*      <--P_GT_FIELDCAT  text
*----------------------------------------------------------------------*
FORM prepare_field_catalog  CHANGING pt_fieldcat TYPE lvc_t_fcat.

  DATA: ls_fcat TYPE lvc_s_fcat.

* Format Z structure into proper layout of type lvc_t_fcat
  CALL FUNCTION 'LVC_FIELDCATALOG_MERGE'
    EXPORTING
      i_structure_name       = 'ZDLU01267_ALV_STRUCT1'
    CHANGING
      ct_fieldcat            = pt_fieldcat
    EXCEPTIONS
      inconsistent_interface = 1
      program_error          = 2
      OTHERS                 = 3.
  IF sy-subrc NE 0.
*   Error calling function LVC_FIELDCATALOG_MERGE
    MESSAGE e002.
  ENDIF.

  LOOP AT pt_fieldcat INTO ls_fcat.

    CASE ls_fcat-fieldname.

*-->  Optimize Columns

      WHEN 'MATNR'. "don't want to display all 18 bytes
        ls_fcat-col_opt = 'X'.
        MODIFY pt_fieldcat FROM ls_fcat.

      WHEN 'BUNDLED_ROLL_IND'.
        ls_fcat-col_opt = 'X'.
        ls_fcat-just    = 'C'.  "centered
        MODIFY pt_fieldcat FROM ls_fcat.

*-->  Column Description Changes

*     Give description to Units column
      WHEN 'UNITS'.
        ls_fcat-coltext = text-003. " 'Units'.
        MODIFY pt_fieldcat FROM ls_fcat.

*     Give good desc to Sales Order column
      WHEN 'VBELN'.
        ls_fcat-coltext = text-004. " 'Sales Order'.
        MODIFY pt_fieldcat FROM ls_fcat.

*     Give good desc to Sales Order Item column
      WHEN 'POSNR'.
        ls_fcat-coltext = text-005. " 'SO Item'.
        MODIFY pt_fieldcat FROM ls_fcat.

*     Give good desc to HU Qty column
      WHEN 'VEMNG'.
        ls_fcat-coltext = text-006. " 'HU Qty'.
        MODIFY pt_fieldcat FROM ls_fcat.

*     Give good desc to Base UOM column
      WHEN 'VEMEH'.
        ls_fcat-coltext = text-007. " 'BUoM'.
        ls_fcat-outputlen = 5.
        MODIFY pt_fieldcat FROM ls_fcat.

*-->  Hide Fields

*     Hide Internal HU number
      WHEN 'VENUM'.
        ls_fcat-no_out = 'X'.
        MODIFY pt_fieldcat FROM ls_fcat.

*     Hide Material Desc
      WHEN 'MAKTX'.
        ls_fcat-no_out = 'X'.
        MODIFY pt_fieldcat FROM ls_fcat.

*     Hide Parent HU
      WHEN 'UEVEL'.
        ls_fcat-no_out = 'X'.
        MODIFY pt_fieldcat FROM ls_fcat.

      WHEN 'WERKS'.
        ls_fcat-no_out = 'X'.
        MODIFY pt_fieldcat FROM ls_fcat.

    ENDCASE.

  ENDLOOP.

ENDFORM.                    " prepare_field_catalog
*&---------------------------------------------------------------------*
*&      Form  prepare_layout
*&---------------------------------------------------------------------*
*       Change ALV Grid attributes based on user requirements
*----------------------------------------------------------------------*
*      <--P_GS_LAYOUT  text
*----------------------------------------------------------------------*
FORM prepare_layout  CHANGING ps_layout TYPE lvc_s_layo.

* Set variant to report name for parm IS_VARIANT
  gv_is_variant-report = sy-repid.

* Set grid title
  ps_layout-grid_title = text-001. "Container Processing
*
* Allow for multiple Row selection
  ps_layout-sel_mode   = 'A'.  "Multiple rows with pushbuttons on left

* Always Hide these ALV toolbar buttons on the Standard Menu Control
* Refer to 'BUILD_COMPLETE_TOOLBAR' method of cl_gui_alv_grid
* for complete listing of mc_fc... menu icons
  CLEAR: gs_exclude_toolbar, gt_exclude_toolbar.
  gs_exclude_toolbar = cl_gui_alv_grid=>mc_fc_graph. "graph
  APPEND gs_exclude_toolbar TO gt_exclude_toolbar.
  gs_exclude_toolbar = cl_gui_alv_grid=>mc_fc_info.  "help
  APPEND gs_exclude_toolbar TO gt_exclude_toolbar.
  gs_exclude_toolbar = cl_gui_alv_grid=>mc_mb_export.  "export
  APPEND gs_exclude_toolbar TO gt_exclude_toolbar.
  gs_exclude_toolbar = cl_gui_alv_grid=>mc_mb_view.  "views
  APPEND gs_exclude_toolbar TO gt_exclude_toolbar.
  gs_exclude_toolbar = cl_gui_alv_grid=>mc_fc_print_back.  "print
  APPEND gs_exclude_toolbar TO gt_exclude_toolbar.

ENDFORM.                    " prepare_layout
*&---------------------------------------------------------------------*
*&      Form  create_container_hu
*&---------------------------------------------------------------------*
*       Create the Container Handling Unit
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM create_container_hu .

  DATA:

    lv_matnr        TYPE matnr,    "work field for material
    lv_bapi_message TYPE bapi_msg, "work field for bapi message

    lv_subrc        TYPE sysubrc.

  DATA:

*   Work table for generating unique HU number
    lt_hu             TYPE STANDARD TABLE OF zdl_uniqueid,
    ls_hu             TYPE zdl_uniqueid,

*   Structure of our Z table
    ls_zdlu01267_vekp TYPE zdlu01267_vekp.

  DATA:

*   Table of HUs to pack into Container HU
    lt_hus_to_pack    TYPE zdl_exidv_tab,
    ls_hus_to_pack    TYPE zdl_exidv,

*   Header Data for Creating a Handling Unit
    ls_headerproposal TYPE bapihuhdrproposal,

*   Item data for HU Item Creation
    lt_itemsproposal  TYPE STANDARD TABLE OF bapihuitmproposal,
    ls_itemsproposal  TYPE bapihuitmproposal,

*   Bapi Return Parameter
    lt_return         TYPE STANDARD TABLE OF bapiret2,
    ls_return         TYPE bapiret2.


  CONSTANTS:

*   Attributes of a Packaging Material for a Container HU
    lc_verp       TYPE mtart  VALUE 'VERP',
    lc_cont       TYPE vhiart VALUE 'CONT',

*   HU Status
    lc_planned_hu TYPE  hu_st_init   VALUE 'A'.
  "Physical Status of the Handling Unit


* Set global variable to indicate container was not yet created
  gv_container_created = gc_false.

  CLEAR: gv_container_exidv,
         gv_container_venum.

* Format table of sub HU's to pack
  CLEAR: lt_hus_to_pack[].
  LOOP AT gt_alv INTO gs_alv.
    ls_hus_to_pack-exidv = gs_alv-exidv.
    APPEND ls_hus_to_pack TO lt_hus_to_pack.
  ENDLOOP.

* Create the Container HU and Pack the sub HU's
  CALL FUNCTION 'ZDL_CREATE_CONTAINER'
    EXPORTING
      iv_signi                       = zdlu01267_0100-signi
      iv_seal                        = zdlu01267_0100-seal
      iv_size                        = zdlu01267_0100-con_size
      iv_booknum                     = zdlu01267_0100-booknum
      iv_bookdoc                     = gs_book_hdr-bookdoc
      iv_werks                       = zdlu01267_0100-werks
      iv_vbeln                       = gv_vbeln
      iv_tare                        = zdlu01267_0100-tare_wgt
      iv_uom                         = 'KG'
    IMPORTING
      ev_container_exidv             = gv_container_exidv
      ev_container_venum             = gv_container_venum
      ev_bapi_error_msg              = lv_bapi_message
    TABLES
      it_hus_to_pack                 = lt_hus_to_pack
      et_return                      = lt_return
    EXCEPTIONS
      error_retrieving_unique_exidv  = 1
      error_calling_unique_exidv     = 2
      no_container_packing_material  = 3
      bapi_hu_create_failed          = 4
      bapi_transaction_commit_failed = 5
      bapi_hu_pack_failed            = 6
      error_inserting_zdlu01267_vekp = 7
      error_retrieving_container     = 8
      handling_unit_locked           = 9
      invalid_hu_passed              = 10
      containerid_seal_already_exist = 11
      invalid_booking_number         = 12
      invalid_booking_document       = 13
      invalid_con_size               = 14
      OTHERS                         = 15.


  lv_subrc = sy-subrc.

  IF lv_subrc = 0.

*   Set global variable to indicate container was created
    gv_container_created = gc_true.

*   Set parameter id for Internal Container HU number (note, the EXIDV
*   External HU number does NOT have a parameter id).
    SET PARAMETER ID 'VEL' FIELD gv_container_venum.

*   Set success message
*   Container HU & successfully created
    MESSAGE s007 WITH gv_container_exidv.

  ELSE.

*   Grab return table for passed message variables
    READ TABLE lt_return INTO ls_return INDEX 1.

*   Issue the appropriate error message
    CASE lv_subrc.

      WHEN 1.
*       Function Z_DL_E03126_UNIT_ID_CHECK returned a blank Container HU
*       number
        MESSAGE e005.

      WHEN 2.
*       Error retrieving unique HU number from function
*       Z_DL_E03126_UNIT_ID_CHECK
        MESSAGE e006.

      WHEN 3.
*       No Container Packing Material exists on MARA
        MESSAGE e004.

      WHEN 4.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN 5.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN 6.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN 7.
*       Error inserting record into ZDLU01267_VEKP for HU &
        MESSAGE e008 WITH ls_return-message_v1.

      WHEN 8.
*       Error retrieving Container Internal HU Number from table VEKP
*       for HU &
        MESSAGE e019 WITH ls_return-message_v1. "External HU

      WHEN 9.
*       Handling Unit & is locked. Container not created.
        MESSAGE e020 WITH ls_return-message_v1. "External HU

      WHEN 10. "one of the HU's in lt_hus_to_pack is invalid
*       HU & is invalid. Does not exist in SAP.
        MESSAGE e021 WITH ls_return-message_v1. "External HU

      WHEN 11.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN 12.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN 13.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN 14.
        MESSAGE e000 WITH lv_bapi_message. "bapi error message

      WHEN OTHERS.
        MESSAGE e001. "error calling function module

    ENDCASE.

  ENDIF.

ENDFORM.                    " create_container_hu
*&---------------------------------------------------------------------*
*&      Form  exit_0200
*&---------------------------------------------------------------------*
*       User clicked Back or Cancel from screen 0200
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM exit_0200 .

  CASE gv_0200_mode.

    WHEN gc_list_selection.

*     Set ok code to CREATE so that the user ends up on screen 0100
*     with the selection screen fields available for input
      ok_code = 'CREATE'.

      LEAVE TO SCREEN 0100.

    WHEN gc_list_confirmation.

*     User was on List Confirmation viewing what had been selected.
*     User did not want to continue to create the Container so
*     clicked to go back to List Selection of screen 0200
      gv_0200_mode = gc_list_selection.

*     Redisplay the entire data set. Make sure all the entries the
*     user had selected are pre-selected for them.
      gt_alv[] = gt_alv_save[].

    WHEN gc_status.

*     User was on Create Container HU status screen after
*     successfully creating the Container HU.
*     User clicked back after either Creating the Container or
*     Printing the Tally. User will go back to the Main mode of
*     Screen 0100
      CLEAR: ok_code.

      LEAVE TO SCREEN 0100.

  ENDCASE.

ENDFORM.                                                    " exit_0200
*&---------------------------------------------------------------------*
*&      Form  confirm_0200
*&---------------------------------------------------------------------*
*       User selected records to add to the Container HU and clicked
*       the 'Confirm Selection'
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM confirm_0200 .

  DATA:

    lv_lines           TYPE i,
    lv_tabix           TYPE sytabix,
    lv_hold_vbeln      TYPE vbeln_va,
    lt_alv             TYPE STANDARD TABLE OF zdlu01267_alv_struct1,
    ls_alv             TYPE zdlu01267_alv_struct1,
    lv_soldto_hold     TYPE kunnr,
    lv_shipto_hold     TYPE kunnr,
    lv_metric_ind_hold TYPE zz_metric_indicator.


* Read index of selected rows
  REFRESH gt_index_rows.
  CALL METHOD go_grid->get_selected_rows
    IMPORTING
      et_index_rows = gt_index_rows.

  CALL METHOD cl_gui_cfw=>flush.

* User may accidentallyt select a Total row to be assigned to a
* Container HU. If this case happens then remove it from the table
* of selected row. Here is an example of what the internal table
* gt_index_rows would look like if the row of a summed up column was
* accidentally selected to be assigned to a container:
*     ROWTYPE              INDEX
*                          0000000001    "row 1 of ALV selected
*                          0000000004    "row 4 selected
*                          0000000005    "row 5 selected
*                          0000000007    "row 7 selected
*     T 0100 0000000001    0000000000    "Total row selected
  DELETE gt_index_rows WHERE rowtype IS NOT INITIAL.

* Validate at least one row was selected
  DESCRIBE TABLE gt_index_rows LINES lv_lines.
  IF lv_lines = 0.
*   You must select at least one line to continue
    MESSAGE e003.
  ENDIF.

* When sales order is available, check that we have only one sold-to, ship-to
* and metric indicator across the selected data.  Sales order may be blank.
  CLEAR: lv_soldto_hold,
         lv_shipto_hold,
         lv_metric_ind_hold.
  LOOP AT gt_index_rows INTO gs_selected_row.
    READ TABLE gt_alv INTO gs_alv INDEX gs_selected_row.
    IF sy-subrc = 0 AND ( NOT gs_alv-vbeln IS INITIAL ).
      IF lv_soldto_hold IS INITIAL.
        lv_soldto_hold = gs_alv-kunnr.
      ENDIF.
      IF lv_shipto_hold IS INITIAL.
        lv_shipto_hold = gs_alv-kunwe.
      ENDIF.
      IF lv_metric_ind_hold IS INITIAL.
        lv_metric_ind_hold = gs_alv-zz_metric_ind.
      ENDIF.
      IF lv_soldto_hold <> gs_alv-kunnr
        OR lv_shipto_hold <> gs_alv-kunwe
        OR lv_metric_ind_hold <> gs_alv-zz_metric_ind.
*     All selected Sold-to/Ship-to/MetricInd must be the same
        MESSAGE e035.
      ENDIF.
    ENDIF.
  ENDLOOP.

* Clear Confirmation table. This table will hold the records selected
* by the user.
  CLEAR: gt_alv_confirm[].

* Move each selected record into the Confirmation table
  LOOP AT gt_index_rows INTO gs_selected_row.
    lv_tabix = sy-tabix. "save index

    READ TABLE gt_alv INTO gs_alv INDEX gs_selected_row.
    IF sy-subrc = 0.

***** EOP - comment out to allow multiple sales orders per ZZHU
*     Confirm each selected record is part of same Sales Order
****      IF NOT gs_alv-vbeln IS INITIAL. "Transport# EDVK964434 TPR # 01460
****        IF ( lv_tabix NE 1 ) AND ( NOT lv_hold_vbeln IS INITIAL ).
****          IF gs_alv-vbeln NE lv_hold_vbeln.
*  All selected records must be from the same Sales Order
****            MESSAGE e022.
****          ENDIF.
****        ENDIF.
***       ENDIF.     "Transport# EDVK964434 TPR # 01460

      IF lv_hold_vbeln IS INITIAL.
        lv_hold_vbeln = gs_alv-vbeln.
      ENDIF.
      APPEND gs_alv TO gt_alv_confirm.

    ENDIF.
  ENDLOOP.

* If not the Wilmington scenario, where stock is not tied to a Sales
* Order, then we should have a Sales Order. Otherwise, use the Sales
* Order from the Booking Document
  IF gs_alv-vbeln IS NOT INITIAL.
    gv_vbeln = gs_alv-vbeln. "store Sales Order in global variable
  ELSE.
    gv_vbeln = gv_booking_vbeln. "store Book Doc Sales Order
  ENDIF.

* Save the data set that was retrieved. We do this because the user
* may select entries from this list, click to Confirm the entries, then
* back up because they forgot an entry or something. We'll need to
* redisplay the original list
  gt_alv_save[] = gt_alv[].

* Set the data to display equal to wat was selected. This data will
* display on the List Confirmation screen
  gt_alv[] = gt_alv_confirm[].

* If no errors occurred then set screen to List Confirmation mode
  gv_0200_mode = gc_list_confirmation.

ENDFORM.                    " confirm_0200
*&---------------------------------------------------------------------*
*&      Form  exit_0100
*&---------------------------------------------------------------------*
*       User clicked Back or Exit from Screen 0100
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM exit_0100 .

  CASE gv_0100_mode.

*   If on screen 0100 in Main Screen mode then leave the program
    WHEN gc_main_processing.

      LEAVE PROGRAM.

*   If on Selection Screen, go back to Main Processing Screen
    WHEN gc_selection_screen.

      gv_0100_mode = gc_main_processing.

      LEAVE TO SCREEN 0100.

  ENDCASE.

ENDFORM.                                                    " exit_0100
*&---------------------------------------------------------------------*
*&      Form  handle_double_click
*&---------------------------------------------------------------------*
*       Double-Click occurred on a Handling Unit in the ALV Grid. Place
*       the user in Transaction HUMO so they can display the details of
*       the Handling Unit they double-clcked on.
*----------------------------------------------------------------------*
*      -->P_E_ROW  text
*      -->P_E_COLUMN  text
*      -->P_ES_ROW_NO  text
*----------------------------------------------------------------------*
FORM handle_double_click  USING    i_row     TYPE lvc_s_row
                                   i_column  TYPE lvc_s_col
                                   is_row_no TYPE lvc_s_roid.


  DATA:

    lt_bdcdata    TYPE STANDARD TABLE OF bdcdata,
    ls_bdcdata    TYPE bdcdata,

    lt_bdcmsgcoll TYPE STANDARD TABLE OF bdcmsgcoll.


* If user double-clicks on a Handling Unit then take them into
* transaction HUMO
  READ TABLE gt_alv INTO gs_alv INDEX is_row_no-row_id.
  IF sy-subrc = 0 AND i_column-fieldname = 'EXIDV'.

*   Build BDC data for initial screen of Tcode HUMO

*   Screen 1
    CLEAR ls_bdcdata.
    ls_bdcdata-program = 'RHU_HELP'.
    ls_bdcdata-dynpro  = '1000'.
    ls_bdcdata-dynbegin = 'X'.
    APPEND ls_bdcdata TO lt_bdcdata.

*   Specify the HU the user dbl-clicked on
    CLEAR ls_bdcdata.
    ls_bdcdata-fnam    = 'SELEXIDV-LOW'.
    ls_bdcdata-fval    = gs_alv-exidv.
    APPEND ls_bdcdata TO lt_bdcdata.

*   Handling Units with cum material items radio button
    CLEAR ls_bdcdata.
    ls_bdcdata-fnam    = 'LSTAND'.
    ls_bdcdata-fval    = 'X'.
    APPEND ls_bdcdata TO lt_bdcdata.

*   Subscreen
    CLEAR ls_bdcdata.
    ls_bdcdata-fnam    = 'BDC_SUBSCR'.
    CONCATENATE 'RHU_HELP                                '
                '2010%_SUBSCREEN_ORDER_CRITERIA'
      INTO ls_bdcdata-fval.
    APPEND ls_bdcdata TO lt_bdcdata.

*   Execute button clicked
    CLEAR ls_bdcdata.
    ls_bdcdata-fnam    = 'BDC_OKCODE'.
    ls_bdcdata-fval    = '=ONLI'.
    APPEND ls_bdcdata TO lt_bdcdata.

*   Use the Call Trans method to get to the 2nd screen of HUMO. Mode 'E'
*   (error mode) will stop the user at the desired 2nd screen because we
*   have not provided anymore screen info so it thinks it's an error and
*   stops there to display to the user. The only issue may be that when
*   the user clicks the Back button, they do not come back to this
*   program first but to the 1st screen of HUMO. So, to get back to the
*   Container application, they will have to click 'Back' twice.
    CALL TRANSACTION 'HUMO' USING lt_bdcdata
                            MODE 'E'  "Online
                            MESSAGES INTO lt_bdcmsgcoll.

  ENDIF.

ENDFORM.                    " handle_double_click
*&---------------------------------------------------------------------*
*&      Form  determine_bundled_rolls
*&---------------------------------------------------------------------*
*       Determine if bundled rolls exist. If they do, delete the non-
*       primary rolls so that the HU will exist only once in the ALV
*       list. If a HU contains bundled rolls, mark the bundled rolls
*       indicator with an 'X'.
*
*       Example of ALV List with Bundled Rolls prior to this routine
*
*       Batch        HU
*       ----------   ----------
*       ZZ05070011   0505070011
*       ZZ05070012   0505070011
*       ZZ05070013   0505070011
*       ZZ05070014   0505070014
*
*       Example of ALV List with Bundled Rolls after this routine
*
*       Batch        Bundled RL Ind    HU
*       ----------   --------------    ----------
*       ZZ05070011        X            0505070011
*       ZZ05070014                     0505070014

*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM determine_bundled_rolls .

  DATA:

* ALV Grid field tables and structures
    lt_alv        TYPE STANDARD TABLE OF zdlu01267_alv_struct1,
    ls_alv        TYPE zdlu01267_alv_struct1,

    lv_hold_exidv TYPE  exidv,

    lv_br_tabix   TYPE  sytabix,

    lv_units      TYPE  i.


  SORT gt_alv BY exidv  "HU
                 charg. "Batch

* Determine of any duplicate HU's (bundled rolls) exist
  lt_alv[] = gt_alv[].
  DELETE ADJACENT DUPLICATES FROM lt_alv COMPARING exidv.

* If bundled rolls are present then continue
  CHECK sy-subrc = 0.

* Cycle through and determine which HU's have bundled rolls
  CLEAR: lv_hold_exidv.
  LOOP AT gt_alv INTO gs_alv.

*   Determine if current batch record has the same HU (bundled roll)
    IF gs_alv-exidv = lv_hold_exidv.
      lv_br_tabix = sy-tabix - 1. "calculate the first Batch of a Bnd RL
      lv_units = lv_units + 1.

*     Delete the record if the Batch/Roll is not the Primary for a
*     Bundled Roll scenario
      DELETE gt_alv INDEX sy-tabix.

*     Read the previous record where the HU's match
      READ TABLE gt_alv INTO ls_alv INDEX lv_br_tabix.
      IF sy-subrc = 0.

*       Update the Bundled Roll Indicator if not already set
        IF ls_alv-bundled_roll_ind IS INITIAL.
          ls_alv-bundled_roll_ind = 'X'.
          MODIFY gt_alv FROM ls_alv INDEX lv_br_tabix
            TRANSPORTING bundled_roll_ind.
        ENDIF.

*       Update the UNITS column
        ls_alv-units = lv_units.
        MODIFY gt_alv FROM ls_alv INDEX lv_br_tabix
          TRANSPORTING units.

      ENDIF.

    ELSE.
      lv_units = 1.
    ENDIF.

*   Save current HU
    lv_hold_exidv = gs_alv-exidv.

  ENDLOOP.

ENDFORM.                    " determine_bundled_rolls

*&---------------------------------------------------------------------*
*&  Include           LZSD_DL_ALERTSAPP                                *
*&---------------------------------------------------------------------*

**** See the following include for examples of implementing custom
***    function module wrappers of application logging objects
***    compliments of WRHENDR 08/13/2004
INCLUDE zca_applog_log_standard.

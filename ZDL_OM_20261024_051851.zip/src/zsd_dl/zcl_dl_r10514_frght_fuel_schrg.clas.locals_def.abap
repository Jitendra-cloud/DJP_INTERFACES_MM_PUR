*"* use this source file for any type of declarations (class
*"* definitions, interfaces or type declarations) you need for
*"* components in the private section
CLASS lcl_rail_frght_fuel_schrg DEFINITION DEFERRED.

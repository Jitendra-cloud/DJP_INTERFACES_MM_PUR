*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDL_E11734TOP.                    " Global Declarations
  INCLUDE LZDL_E11734UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDL_E11734F...                    " Subroutines
* INCLUDE LZDL_E11734O...                    " PBO-Modules
* INCLUDE LZDL_E11734I...                    " PAI-Modules
* INCLUDE LZDL_E11734E...                    " Events
* INCLUDE LZDL_E11734P...                    " Local class implement.
* INCLUDE LZDL_E11734T99.                    " ABAP Unit tests
  INCLUDE LZDL_E11734F00                          . " subprograms
  INCLUDE LZDL_E11734I00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

FUNCTION zsd_dl_u1165_trim_order_detail.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  TABLES
*"      ZT_TRIM_DETAILS STRUCTURE  ZST_TRIM_DETAILS
*"  EXCEPTIONS
*"      MISSING_INPUT
*"      NO_VALID_ITEMS_FOUND
*"----------------------------------------------------------------------
*&--------------------------------------------------------------------*
*& FUNCTION ZSD_DL_U1165_TRIM_ORDER_DETAIL                            *
***********************************************************************
**                                                                   **
**             C O M P A N Y   C O N F I D E N T I A L               **
**                                                                   **
**        This program is the property of International Paper.       **
**        Care should be taken to prevent its unauthorized use.      **
**                                                                   **
***********************************************************************
***********************************************************************
**                                                                   **
**                    COPYRIGHT (C) 2003 by                          **
**                     INTERNATIONAL PAPER                           **
**                                                                   **
**                     ALL RIGHTS RESERVED                           **
**                                                                   **
**                   REVISIONS COPYRIGHT (C)                         **
**                         2003, 20nn                                **
**                             by                                    **
**                     INTERNATIONAL PAPER                           **
***********************************************************************
*_____________________________________________________________________*
* FUNCTION ZSD_DL_U1165_TRIM_ORDER_DETAIL            Date: 10/05/2005 *
*                                                                     *
* SAP Name    :                                                       *
*                                                                     *
* Programmer  : Randall Wainwright                                    *
*                                                                     *
*_____________________________________________________________________*
* Description : Retrieves trim unit weight, trim total weight, unit of
*   measure, trim total units and machine number for a list of sales
*   order line items:
* Input:  ZST_TRIM_DETAILS-KDAUF
* Input:  ZST_TRIM_DETAILS-KDPOS
* Output: ZST_TRIM_DETAILS-ZTRIMUNIT_WT
* Output: ZST_TRIM_DETAILS-ZTRIMTOTL_WT
* Output: ZST_TRIM_DETAILS-ERFME
* Output: ZST_TRIM_DETAILS-ZTRIMTOTL_UNITS
* Output: ZST_TRIM_DETAILS-ZTRIMMACHINENUM
*---------------------------------------------------------------------*
*_____________________________________________________________________*
* Change History:                                                     *
*     Programmer        Date    Req. #            Action              *
* ==================  ========  ======  ==============================*
* Randall Wainwright  10/18/05  RLW02   Improve missing trim processing
***********************************************************************

  DATA: lt_resb_key LIKE zt_trim_details OCCURS 0 WITH HEADER LINE,
        lt_aufk_key LIKE t_resb OCCURS 0 WITH HEADER LINE.

* NCP orders processing records
  DATA: lt_ncp LIKE zt_trim_details OCCURS 0 WITH HEADER LINE.

  TYPES: BEGIN OF ty_objkey,
         objkey TYPE ibobjkey,
         END OF ty_objkey.
  DATA lt_objkey TYPE STANDARD TABLE OF ty_objkey WITH HEADER LINE INITIAL SIZE 0.

  TYPES: BEGIN OF ty_ibin,
         atwrt TYPE atwrt,
         objkey TYPE ibobjkey,
         END OF ty_ibin.
  DATA lt_ibin TYPE STANDARD TABLE OF ty_ibin WITH HEADER LINE INITIAL SIZE 0.


  IF zt_trim_details[] IS INITIAL.
    RAISE missing_input.
  ENDIF.

* Eliminate duplicates before performing SELECT
  lt_resb_key[] = zt_trim_details[].
  SORT lt_resb_key BY kdauf kdpos.
  DELETE ADJACENT DUPLICATES FROM lt_resb_key COMPARING kdauf kdpos.

* Select from RESB. Must utilize custom index.
*  SELECT rsnum
*         rspos
*         rsart
*         xloek
*         erfmg
*         erfme
*         aufnr
*         kdauf
*         kdpos
*         objnr
*         afpos
*    FROM resb
*    INTO TABLE t_resb
*    FOR ALL ENTRIES IN lt_resb_key
*    WHERE kdauf = lt_resb_key-kdauf
*      AND kdpos = lt_resb_key-kdpos.
*  IF sy-subrc = 0.
*
** SELECT against AUFK key field AUFNR, using discrete Order Numbers
*    lt_aufk_key[] = t_resb[].
*    SORT lt_aufk_key BY aufnr.
*    DELETE ADJACENT DUPLICATES FROM lt_aufk_key COMPARING aufnr.
*
*    SELECT aufnr
*           kdauf
*           kdpos
*           auart
*      FROM aufk
*      INTO TABLE t_aufk
*      FOR ALL ENTRIES IN lt_aufk_key
*      WHERE aufnr = lt_aufk_key-aufnr.
*    FREE lt_aufk_key.
*
** Only interested in trim orders (ignore package orders)
*    SORT t_aufk BY auart.
*    DELETE t_aufk WHERE auart <> c_trim_order.
*
** Combine AUFK filtered data with RESB into t_resb_aufk
*    SORT: t_resb BY aufnr,
*          t_aufk BY aufnr.
*    CLEAR t_resb.
*    LOOP AT t_resb.
*
** If there is no trim order type in AUFK: omit from the
**  t_resb_aufk internal table
*      IF NOT t_aufk-aufnr = t_resb-aufnr.
*        CLEAR t_aufk.
*        READ TABLE t_aufk WITH KEY
*          aufnr = t_resb-aufnr
*          BINARY SEARCH.
*      ENDIF.
*
*      IF NOT t_aufk IS INITIAL.
*        APPEND t_resb TO t_resb_aufk.
*      ENDIF.
*
*    ENDLOOP. " AT t_resb.

** Begin of Changes
*


  SELECT aufnr
         kdauf
         kdpos
         dauat
         krsnr
         krsps
    FROM afpo
    INTO TABLE t_aufk
  FOR ALL ENTRIES IN  lt_resb_key
  WHERE kdauf = lt_resb_key-kdauf
    AND kdpos = lt_resb_key-kdpos.
  IF sy-subrc = 0.

    t_aufk_pkg[] = t_aufk[].
    DELETE t_aufk_pkg WHERE auart = c_trim_order.
    perform get_orders_for_pkg.

    DELETE t_aufk WHERE auart <> c_trim_order.

    loop at int_afpo.
      t_aufk-aufnr = int_afpo-aufnr.
      t_aufk-auart = int_afpo-dauat.
      t_aufk-kRSNR = int_afpo-kRSNR.
      t_aufk-kRSPS = int_afpo-krsps.
      t_aufk-kdauf = int_afpo-vbeln.
      t_aufk-kdpos = int_afpo-posnr.
      append t_aufk.
    endloop.

    IF NOT t_aufk IS INITIAL.
      SELECT aufnr
              stat
              inact
         FROM znviauf2
         INTO TABLE int_jest
         FOR ALL ENTRIES IN t_aufk
         WHERE aufnr = t_aufk-aufnr.
      IF sy-subrc = 0.
        SORT int_jest BY aufnr stat inact.
        LOOP AT t_aufk.
          READ TABLE int_jest WITH KEY aufnr = t_aufk-aufnr
                                       stat = 'I0076'
                                       inact = ' ' BINARY SEARCH.
          IF sy-subrc = 0.
            DELETE t_aufk.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.
  ENDIF.

**  LOOP AT t_aufk.
**    CONCATENATE t_aufk-aufnr '0001' INTO lt_objkey-objkey.
**    APPEND lt_objkey.
**  ENDLOOP.
**
**  SELECT atwrt
**         objkey
**  FROM ibinval_sel_f
**   INTO TABLE lt_ibin
**  FOR ALL ENTRIES IN lt_objkey
**    WHERE atinn = 'PRIMARY_TRIM_NUMBER' AND
**          objtyp = 'AFPO' AND
**          objkey = lt_objkey-objkey.
**  IF sy-subrc = 0.
**
**
**
**  ENDIF.
*
*
  IF NOT t_aufk[] IS INITIAL.
    SELECT rsnum
           rspos
           rsart
           xloek
           erfmg
           erfme
           aufnr
           kdauf
           kdpos
           objnr
           afpos
      FROM resb
      APPENDING TABLE t_resb
      FOR ALL ENTRIES IN t_aufk
      WHERE rsnum = t_aufk-krsnr AND
            rspos = t_aufk-krsps.
  ENDIF.

   loop at t_resb.
      read table t_aufk with key krsnr = t_resb-rsnum
                                 krsps = t_resb-rspos.
    if sy-subrc = 0.
      t_resb-kdauf = t_aufk-kdauf.
      t_resb-kdpos = t_aufk-kdpos.
      MODIFY t_resb.
     endif.

    endloop.



  t_resb_aufk[] = t_resb[].

** End of changes

* At this point, t_resb_aufk contains the list of trim orders.
* Extracting the Trim Units, Trim unit weight and Total Trim now:
  IF NOT t_resb_aufk[] IS INITIAL.
    PERFORM process_trim TABLES t_sales_ord_out.
  ENDIF.
*  ENDIF. " SELECT from RESB

*  Extracting the Trim Units, Trim unit weight and Total Trim
*    for NCP orders
  lt_ncp[] = zt_trim_details[].
  PERFORM process_ncp TABLES lt_ncp.

*  Combines the Standard and NCP Trim Units, Trim unit weight and
*   Total Trim into Output table
  PERFORM process_combine TABLES lt_ncp
                                 t_sales_ord_out
                                 zt_trim_details.

  IF zt_trim_details[] IS INITIAL.
    RAISE no_valid_items_found.
  ENDIF.

ENDFUNCTION.

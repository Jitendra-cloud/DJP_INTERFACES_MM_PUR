FUNCTION z_dl_i10580_input_syvasn.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     VALUE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     VALUE(WORKFLOW_RESULT) LIKE  BDWF_PARAM-RESULT
*"     VALUE(APPLICATION_VARIABLE) LIKE  BDWF_PARAM-APPL_VAR
*"     VALUE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     VALUE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"      ERROR_PROCESSING_IDOC_FUNCTION
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(INPUT_METHOD) LIKE  BDWFAP_PAR-INPUTMETHD
*"     VALUE(MASS_PROCESSING) LIKE  BDWFAP_PAR-MASS_PROC
*"  EXPORTING
*"     VALUE(WORKFLOW_RESULT) LIKE  BDWF_PARAM-RESULT
*"     VALUE(APPLICATION_VARIABLE) LIKE  BDWF_PARAM-APPL_VAR
*"     VALUE(IN_UPDATE_TASK) LIKE  BDWFAP_PAR-UPDATETASK
*"     VALUE(CALL_TRANSACTION_DONE) LIKE  BDWFAP_PAR-CALLTRANS
*"  TABLES
*"      IDOC_CONTRL STRUCTURE  EDIDC
*"      IDOC_DATA STRUCTURE  EDIDD
*"      IDOC_STATUS STRUCTURE  BDIDOCSTAT
*"      RETURN_VARIABLES STRUCTURE  BDWFRETVAR
*"      SERIALIZATION_INFO STRUCTURE  BDI_SER
*"  EXCEPTIONS
*"      WRONG_FUNCTION_CALLED
*"      ERROR_PROCESSING_IDOC_FUNCTION
*======================================================================*
* CHANGE HISTORY:                                                      *
*Programmer|Date|Change Doc|Action                                     *
*======================================================================*
*AMAOLE1|05062021|Prgm logic is based on FM Z_SD_DL_I2301_INPUT_ZVASN  *
*FM Z_DL_I10580_INPUT_SYVASN works as a posting FM for Message Type    *
*ZDL_SYVASN & IDoc Type DELVRY03                                       *
*AMAOLE1|09122021|Pick ASN qty from segment E1EDL24-NTGEW instead of   *
*E1EDL24-LFIMG                                                         *
*Anil Lankapalli| 3/18/2022 | CD 2000000569 Comment out some logic     *
* where we get the characteristics from VC configuration instead pass  *
* the values directly through IDOC.                                    *
*======================================================================*
*            DO NOT SORT TABLE IDOC_DATA or GT_IDOC_DATA                *
*                   IT MESSES UP THE TABIX FIELDS                      *
*======================================================================*
*  IMPORTANT INTERNAL TABLES
*  GT_IDOC_DATA[] - Has the actually segments that are used after filtering
*  GT_MBHP_TAB[] - Has Material, batch, HU, PO & tabix for segments
*  GT_PO_DETAILS[] - PO, PO Item & Material (Multiple PO)
*  GT_MBPSV[] - Has all Batch characteristics
*  GT_L37[] - Used for creating HUs (Header level data)
*  GT_L44[] - Used for creating HUs (Item level data)
*  GT_HU[] - Used for assigning HUs deliveries
*======================================================================*
* PBOMMIR     25.Apr.2024       S0VK906981
* Considering the Startdard message and trigerring the usd ticket.
* Exsting priority change to 3
*======================================================================*

  PERFORM initialization.

  PERFORM get_zdl_fields.

* Get IDoc data and status records
  gt_idoc_data[]      =  idoc_data[].   "Idoc data table
  gt_idoc_status[]    =  idoc_status[]. "Idoc status table

* Check for message type and process the idoc.
  READ TABLE idoc_contrl INTO gs_idoc_ctrl INDEX 1.

  CASE gs_idoc_ctrl-mestyp.
    WHEN 'ZDL_SYVASN'.

      PERFORM process_idoc.

    WHEN OTHERS.
      "If any other message, raise an error message
      "Validation:IDoc type &1 cannot be processed by
      "FM Z_DL_I10580_INPUT_SYVASN
      MESSAGE e029(zdl) WITH gs_idoc_ctrl-mestyp
      RAISING wrong_function_called.
  ENDCASE.

  idoc_data[]   = gt_idoc_data[].
  idoc_status[] = gt_idoc_status[].

  IF gv_idoc_error EQ abap_true.
    RETURN.
  ENDIF.

  IF gt_hu IS INITIAL.
    RETURN.
  ENDIF.

  SORT gt_hu BY bolnr exidv.

  "Updates Table GT_DELIVERY_EXISTS
  "LIFEX is Outbound Delivery from IP
  PERFORM check_delivery_exists.

  IF gt_delivery_exists IS INITIAL.
    "CREATE DELIVERY(S)
    CALL FUNCTION '/SPE/IDOC_INPUT_DESADV1'
      EXPORTING
        input_method          = input_method
        mass_processing       = mass_processing
      TABLES
        idoc_contrl           = idoc_contrl[]
        idoc_data             = idoc_data[]
        idoc_status           = idoc_status[]
        return_variables      = return_variables
        serialization_info    = serialization_info
      EXCEPTIONS
        wrong_function_called = 1
        OTHERS                = 2.
    IF sy-subrc <> 0.

*SOC by PBOMMIR on 12.APr.2024 - S0VK906981
      PERFORM sub_idoc_status_fill USING
              c_idoc_status_error               "status 51
              gs_idoc_ctrl-docnum               "idoc number
              c_error                           "status msg type
              'E0'                  "message class
              '503'                 "err msg
              ' '                   "msgv1
              ' '                   "msgv2
              ' '                               "msgv3
              ' '                               "msgv4
              '/SPE/IDOC_INPUT_DESADV1'                               "routid
              ' '                               "seg num
              ' '.                              "seg field
*EOC by PBOMMIR on 12.APr.2024 - S0VK906981

      MESSAGE e503(e0) WITH '/SPE/IDOC_INPUT_DESADV1'(006)
        RAISING error_processing_idoc_function.
    ELSE.
      COMMIT WORK AND WAIT.
      gv_inb_vbeln_exists = gc_true.

      LOOP AT idoc_status INTO gs_idoc_status
          WHERE msgty = 'S'
            AND msgid = 'BORGR'
            AND msgno = '520'.

        APPEND VALUE #( vbeln = gs_idoc_status-msgv1 )
            TO gt_delivery_created.
      ENDLOOP.
    ENDIF.

    FREE MEMORY ID 'ZDL_SYVASN'.

    "Updates Table GT_DELIVERY_EXISTS
    PERFORM check_delivery_exists.

  ENDIF.

  IF gt_delivery_exists IS INITIAL.
    RETURN.
  ENDIF.

  "Updates table GT_ASSIGN
  PERFORM check_hu_assigned.

  IF gv_idoc_error = gc_true.
    idoc_status[] = gt_idoc_status[].
    RETURN.
  ENDIF.

  FREE MEMORY ID 'ZDL_SYVASN'.

  "By-pass handling unit assignment for Zero-pick deliveries
  "For Zero-pick deliveries LIKP-BTGEW will be zero
  LOOP AT gt_delivery_exists INTO DATA(ls_delivery) WHERE btgew IS NOT INITIAL.

    gv_inb_vbeln = ls_delivery-vbeln.

    "Check Inbound Delivery lock
    PERFORM check_delivery_lock.

    IF gv_idoc_error = gc_true.
      idoc_status[] = gt_idoc_status[].
      RETURN.
    ENDIF.

    "Assign the HU's to the Inbound Delivery
    PERFORM assign_hu_to_delivery.

    IF gv_idoc_error = gc_true.
      idoc_status[] = gt_idoc_status[].
      RETURN.
    ENDIF.

  ENDLOOP.

*Soc by PBOMMIR on 12.Apr.2024 - S0VK906981
  IF gv_idoc_error = abap_false.
    DATA(lt_idoc_status_t) = idoc_status[].
    DELETE lt_idoc_status_t WHERE msgid = 'ZDL'.
    IF lt_idoc_status_t[] IS NOT INITIAL.
      LOOP AT lt_idoc_status_t INTO DATA(ls_status_t) WHERE  status = 51.
        PERFORM sub_idoc_status_fill USING
                c_idoc_status_error               "status 51
                gs_idoc_ctrl-docnum               "idoc number
                c_error                           "status msg type
                ls_status_t-msgid                 "message class
                ls_status_t-msgno                 "err msg
                ls_status_t-msgv1                 "msgv1
                ls_status_t-msgv2                 "msgv2
                ' '                               "msgv3
                ' '                               "msgv4
                'STANDARD_MSG'                    "routid
                ' '                               "seg num
                ' '.                              "seg field
        DATA(lv_flg) = abap_true.
      ENDLOOP.
      IF lv_flg = abap_true.
        RETURN.
      ENDIF.
    ENDIF.
  ENDIF.
*Eoc by PBOMMIR on 12.Apr.2024 - S0VK906981

  PERFORM success_message.

  IF NOT gt_idoc_status[] IS INITIAL.
    idoc_status[] = gt_idoc_status[].
  ENDIF.

ENDFUNCTION.

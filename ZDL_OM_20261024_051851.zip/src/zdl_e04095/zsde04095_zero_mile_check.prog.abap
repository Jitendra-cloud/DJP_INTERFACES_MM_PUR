*&---------------------------------------------------------------------*
*&  Include  ZSDE04095_ZERO_MILE_CHECK
*&---------------------------------------------------------------------*
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2017 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: Zero Mile Check on Shipments                           *
*                                                                      *
* SAP Name    : ZSDE04095_ZERO_MILE_CHECK        Create Date: 01/17/17 *
*                                                                      *
* Programmer  : Amit Maole                       Last Update: 03/01/17 *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* Amit Maole          01/17/17  E0VK9A0O3W  CMS31411                   *
*                                                                      *
* Xavier Andrews      03/01/17  E0VK9A0OZX  CMS31619                   *
*                                                                      *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
 DATA: lv_lowval TYPE zsdomfld-lowval,
       lv_ort01  TYPE t001w-ort01.                          "CMS 31619

 IF komp-kznep = '$'.
   xkwert = 0.
   xkomv-kinak = 'X'.
   RETURN.
 ENDIF.

*Start CMS 31619 XANDREW 03/01/2017*
 IF komp-distz = 0.

   SELECT SINGLE ort01
     FROM t001w
     INTO lv_ort01
     WHERE werks = komk-werks.


   TRANSLATE: lv_ort01 TO UPPER CASE,
              komk-cstvnd_city TO UPPER CASE.

   CONDENSE: lv_ort01 NO-GAPS,
             komk-cstvnd_city NO-GAPS.

*If cities are the same, exit exclusion routine
   IF lv_ort01 = komk-cstvnd_city.
     RETURN.
   ENDIF.
 ENDIF.
*END CMS 31619 XANDREW

 SELECT SINGLE lowval FROM zsdomfld
 INTO lv_lowval
 WHERE category = 'E04095' AND
    fieldname = 'ZEROMILE' AND
    lowval = xkomv-kschl.

 CHECK sy-subrc EQ 0.
 IF komp-distz = 0.
   xkwert = 0.
   xkomv-kinak = 'X'.
 ENDIF.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZM9H
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZM9H                .

  PERFORM TABLEPROC.

ENDFUNCTION.

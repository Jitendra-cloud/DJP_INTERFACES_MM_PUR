class ZCL_MM_M01172 definition
  public
  final
  create public .

public section.

  class-data MV_COUNTER type I .

  methods CONSTRUCTOR .
  class-methods VALIDATE_COMPANY_CODE
    importing
      value(IV_BUKRS) type BUKRS
      value(IV_KSCHL) type KSCHL
    returning
      value(RV_FLAG) type BOOLEAN .
protected section.
private section.
ENDCLASS.



CLASS ZCL_MM_M01172 IMPLEMENTATION.


  method CONSTRUCTOR.
  endmethod.


  method VALIDATE_COMPANY_CODE.
    data: lv_value1 type ZVALUE_1,
          lv_value2 type ZVALUE_2.

    lv_value1 = iv_bukrs.
    lv_value2 = iv_kschl.
    select single value1 INTO @data(lv_bukrs) from zmmfld
      where key1 = 'M01172'
      AND   key2 = 'BUKRS'
      AND   value1 = @lv_value1
      AND   value2 = @lv_value2.
      if Sy-subrc IS INITIAL.
        rv_flag = abap_true.
      else.
        rv_flag = abap_false.
      endif.

  endmethod.
ENDCLASS.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3AL
*   generation date: 2003.05.12 at 14:57:33 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3AL                .

  PERFORM TABLEPROC.

ENDFUNCTION.

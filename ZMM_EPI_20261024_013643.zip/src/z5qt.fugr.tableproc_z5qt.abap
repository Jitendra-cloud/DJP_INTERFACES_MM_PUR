*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5QT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5QT                .

  PERFORM TABLEPROC.

ENDFUNCTION.

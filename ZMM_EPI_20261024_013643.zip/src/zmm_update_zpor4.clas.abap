*----------------------------------------------------------------------*
*       CLASS ZMM_UPDATE_ZPOR4 DEFINITION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS zmm_update_zpor4 DEFINITION
  PUBLIC
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF gty_columns  ,
                                  col             TYPE alsmex_tabline-col,
                                     excel_fieldname TYPE slis_fieldname,
                                     db_fieldname    TYPE slis_fieldname,
                                     inttype         TYPE inttype,
                                     convexit        TYPE dd03n-convexit,
                                    END OF gty_columns .
    TYPES:
      BEGIN OF ty_final,
                       key(10)      TYPE c,
                       pur_grp      TYPE zekgrp,
                       email_sender TYPE xubname,
                       note         TYPE znote,
              END OF ty_final .
    TYPES:
      BEGIN OF ty_error,
        key(10)      TYPE c,
        pur_grp      TYPE zekgrp,
        email_sender TYPE xubname,
        comment(120) TYPE c,
        END OF ty_error .
    TYPES:
      gt_excel_data1 TYPE STANDARD TABLE OF alsmex_tabline .
    TYPES gw_excel_data1 TYPE alsmex_tabline .
    TYPES:
      gt_missing1 TYPE STANDARD TABLE OF tline .
    TYPES:
      gw_missing1 TYPE LINE OF gt_missing1 .
    TYPES:
      ty_zpor4 TYPE STANDARD TABLE OF zpor4 .

    DATA:
      gt_zpor4 TYPE STANDARD TABLE OF zpor4 .
    DATA:
      gt_zpor41 TYPE STANDARD TABLE OF zpor4 .
    DATA gw_zpor4 TYPE zpor4 .
    DATA gw_ust04 TYPE ust04 .
    DATA gw_t024 TYPE t024 .
    DATA obj_tb TYPE REF TO data .
    DATA:
      gt_error TYPE STANDARD TABLE OF ty_error .
    DATA gw_error TYPE ty_error .
    DATA:
      gt_final TYPE STANDARD TABLE OF ty_final .
    DATA gw_final TYPE ty_final .
    DATA gw_missing TYPE gw_missing1 .
    TYPE-POOLS slis .
    DATA gw_fieldcat TYPE slis_fieldcat_alv .
    DATA lv_tabix LIKE sy-tabix .
    DATA gt_excel_data TYPE gt_excel_data1 .
    DATA:
      gw_excel_data LIKE LINE OF gt_excel_data .
    DATA:
      gt_columns TYPE STANDARD TABLE OF gty_columns .
    DATA gs_columns TYPE gty_columns .
    DATA ls_columns TYPE gty_columns .

    METHODS validate_file
      IMPORTING
        value(file_name) TYPE rlgrap-filename .
    METHODS read_table_fields
      IMPORTING
        !program_name TYPE sy-repid OPTIONAL
        !structure_name TYPE dd02l-tabname OPTIONAL
        !internal_tabname TYPE slis_tabname OPTIONAL
      EXPORTING
        !gt_db_fieldcat TYPE slis_t_fieldcat_alv
        !gt_fieldcat TYPE slis_t_fieldcat_alv .
    METHODS read_excel_data
      IMPORTING
        !file_name TYPE rlgrap-filename
        !gt_excel_fieldcat TYPE slis_t_fieldcat_alv
        !gt_fieldcat TYPE slis_t_fieldcat_alv
      EXPORTING
        !gt_excel_data LIKE gt_excel_data
        !gt_missing TYPE gt_missing1
        !gt_columns LIKE gt_columns .
    METHODS build_excel_data
      IMPORTING
        !gt_excel_data LIKE gt_excel_data
        !gt_columns LIKE gt_columns
      EXPORTING
        !gt_final LIKE gt_final .
    METHODS update_zpor4
      IMPORTING
        !gt_final LIKE gt_final
      EXPORTING
        !gt_error LIKE gt_error
        !gt_zpor41 LIKE gt_zpor41 .
protected section.

  constants GC_X type CHAR1 value 'X'. "#EC NOTEXT
  data LV_STR type STRING .
private section.
ENDCLASS.



CLASS ZMM_UPDATE_ZPOR4 IMPLEMENTATION.


METHOD build_excel_data.

  FIELD-SYMBOLS: <value> TYPE any .

  DATA : gv_struct(30) TYPE c VALUE 'GW_FINAL-'.

  CLEAR : gw_excel_data.

  LOOP AT gt_excel_data INTO gw_excel_data.

    lv_tabix = sy-tabix.

    AT NEW row.
      READ TABLE gt_excel_data INTO gw_excel_data INDEX lv_tabix.
    ENDAT.

    CHECK gw_excel_data-row > 1.

    CLEAR : gs_columns.

    READ TABLE gt_columns INTO gs_columns WITH KEY col = gw_excel_data-col.

    IF sy-subrc = 0.

      gv_struct+9 = gs_columns-db_fieldname.

      IF gv_struct = 'GW_FINAL-LANGU'.
        gv_struct = 'GW_FINAL-KEY'.
      ENDIF.

      IF gv_struct = 'GW_FINAL-ZEKGRP'.
        gv_struct  = 'GW_FINAL-PUR_GRP'.
      ENDIF.

      ASSIGN (gv_struct) TO <value>.

      IF <value> IS ASSIGNED.

        CASE gv_struct.

          WHEN 'GW_FINAL-KEY'.
            <value> = gw_excel_data-value.

          WHEN 'GW_FINAL-PUR_GRP'.

            TRANSLATE gw_excel_data-value TO UPPER CASE.
            <value> = gw_excel_data-value.

          WHEN 'GW_FINAL-EMAIL_SENDER'.

            TRANSLATE gw_excel_data-value TO UPPER CASE.

            <value> = gw_excel_data-value.

          WHEN 'GW_FINAL-NOTE'.
            <value> = gw_excel_data-value.

        ENDCASE.

      ENDIF.

    ENDIF.

    AT END OF row.
      CHECK NOT gw_final IS INITIAL.
      APPEND gw_final TO gt_final.
      CLEAR :  gw_final.
    ENDAT.

  ENDLOOP.

ENDMETHOD.


METHOD read_excel_data.

  CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
    EXPORTING
      filename                = file_name
      i_begin_col             = 1
      i_begin_row             = 1
      i_end_col               = 10
      i_end_row               = 4000
    TABLES
      intern                  = gt_excel_data
    EXCEPTIONS
      inconsistent_parameters = 1
      upload_ole              = 2
      OTHERS                  = 3.

  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.



  LOOP AT gt_excel_data INTO gw_excel_data WHERE row = 1.

    CLEAR :lv_tabix, gs_columns.

    TRANSLATE gw_excel_data-value TO UPPER CASE.

    READ TABLE gt_excel_fieldcat INTO gw_fieldcat
               WITH KEY fieldname = gw_excel_data-value.

    IF sy-subrc = 0.

      lv_tabix = sy-tabix.

      DATA : gw_field TYPE LINE OF slis_t_fieldcat_alv.

      READ TABLE gt_fieldcat INTO gw_field INDEX lv_tabix.

      gs_columns-col             = gw_excel_data-col.
      gs_columns-excel_fieldname = gw_excel_data-value.
      gs_columns-db_fieldname    = gw_field-fieldname.
      gs_columns-inttype         = gw_fieldcat-inttype.
*
      APPEND gs_columns TO gt_columns.

    ENDIF.

  ENDLOOP.

*  IF gt_columns IS NOT INITIAL.

  CLEAR : gs_columns .
  READ TABLE gt_columns INTO gs_columns
  WITH KEY excel_fieldname = 'KEY'.
***    KEY not found in the excel sheet
  IF sy-subrc <> 0.
    gw_missing-tdline = 'KEY'.
    APPEND gw_missing TO gt_missing.
  ENDIF.

  CLEAR : gs_columns .
  READ TABLE gt_columns INTO gs_columns
  WITH KEY excel_fieldname = 'PUR GRP'.
***    Purchase group not found in the excel sheet
  IF sy-subrc <> 0.
    gw_missing-tdline = 'PUR GRP'.
    APPEND gw_missing TO gt_missing.
  ENDIF.

  CLEAR : gs_columns .
  READ TABLE gt_columns INTO gs_columns
  WITH KEY excel_fieldname = 'USERID'.
***    User ID not found in the excel sheet
  IF sy-subrc <> 0.
    gw_missing-tdline = 'USERID'.
    APPEND gw_missing TO gt_missing.
  ENDIF.

*    CLEAR : gs_columns .
*    READ TABLE gt_columns INTO gs_columns
*    WITH KEY excel_fieldname = 'NOTE'.
****   NOTE not found in the excel sheet
*    IF sy-subrc <> 0.
*      gw_missing-tdline = 'NOTE'.
*      APPEND gw_missing TO gt_missing.
*    ENDIF.

*  ENDIF.

ENDMETHOD.


METHOD read_table_fields.

  DATA : gt_excel_fieldcat TYPE slis_t_fieldcat_alv,
           ls_fieldcat TYPE slis_fieldcat_alv.

  FIELD-SYMBOLS : <fs_table> TYPE ANY TABLE,
                 <fs_line>  TYPE any,
                 <fs_field> TYPE any.

  DATA : obj1 TYPE REF TO data.
  DATA : obj2 TYPE REF TO data.

  CALL FUNCTION 'REUSE_ALV_FIELDCATALOG_MERGE'
    EXPORTING
      i_program_name         = program_name
*     I_INTERNAL_TABNAME     = INTERNAL_TABNAME
      i_structure_name       = structure_name
*     I_CLIENT_NEVER_DISPLAY = 'X'
*     I_INCLNAME             =
*     I_BYPASSING_BUFFER     =
*     I_BUFFER_ACTIVE        =
    CHANGING
      ct_fieldcat            = gt_db_fieldcat[]
    EXCEPTIONS
      inconsistent_interface = 1
      program_error          = 2
      OTHERS                 = 3.

  IF sy-subrc <> 0.
* Implement suitable error handling here

    IF structure_name IS NOT INITIAL.
      MESSAGE e001 WITH structure_name.
    ENDIF.

    IF internal_tabname IS NOT INITIAL.
      MESSAGE e001 WITH internal_tabname.
    ENDIF.

  ENDIF.

  gt_fieldcat = gt_db_fieldcat[].

  CREATE DATA obj1 LIKE gt_db_fieldcat.

  ASSIGN obj1->* TO <fs_table>.

  IF <fs_table> IS ASSIGNED.

    <fs_table> = gt_db_fieldcat[].

    CREATE DATA obj2 LIKE LINE OF gt_db_fieldcat.

    ASSIGN obj2->* TO <fs_line>.

    IF <fs_line> IS ASSIGNED.

      LOOP AT <fs_table> ASSIGNING <fs_line>.

        ASSIGN COMPONENT 'FIELDNAME' OF STRUCTURE <fs_line> TO <fs_field>.

        IF <fs_field> IS ASSIGNED.

          IF <fs_field> CA '_'.
            REPLACE ALL OCCURRENCES OF '_' IN <fs_field> WITH ' '.
          ENDIF.

          IF <fs_field> = 'LANGU'.
            <fs_field>  = 'KEY'.
          ENDIF.

          IF <fs_field> = 'ZEKGRP'.
            <fs_field>  = 'PUR GRP'.
          ENDIF.

          IF <fs_field> = 'EMAILSENDER'.
            <fs_field>  = 'USERID'.
          ENDIF.

        ENDIF.

      ENDLOOP.

    ENDIF.

    gt_db_fieldcat[] =  <fs_table>.

  ENDIF.

ENDMETHOD.


METHOD update_zpor4.

  FIELD-SYMBOLS : <fs_table> TYPE ANY TABLE,
                  <fs_line>  TYPE any,
                  <fs_field> TYPE any.

*** update the table zpor4
  LOOP AT  gt_final INTO  gw_final.

**Check if the USER ID is maintined in the excel sheet.
    IF gw_final-email_sender IS NOT INITIAL.

      SELECT SINGLE * FROM ust04 INTO gw_ust04
                   WHERE bname = gw_final-email_sender.
**Check if the USER ID is maintined in the System.
      IF sy-subrc = 0.

        SELECT * FROM zpor4 INTO TABLE gt_zpor4
          WHERE zekgrp = gw_final-pur_grp.

*** Check if the record is maintained in the table zpor4
        IF sy-subrc = 0.

          SELECT  SINGLE * FROM t024 INTO gw_t024 WHERE ekgrp = gw_final-pur_grp.
*** Check if the record is maintained in the table T024

          IF sy-subrc = 0.

            CREATE DATA : obj_tb LIKE gt_zpor4.

            ASSIGN obj_tb->* TO <fs_table>.

            IF <fs_table> IS ASSIGNED.

              <fs_table> = gt_zpor4.

              LOOP AT <fs_table> ASSIGNING <fs_line>.
*** UserID.
                ASSIGN COMPONENT 'EMAIL_SENDER' OF STRUCTURE <fs_line> TO <fs_field>.

                IF <fs_field> IS ASSIGNED.
                  <fs_field> = gw_final-email_sender.
                ENDIF.
**** Note.
*                ASSIGN COMPONENT 'NOTE' OF STRUCTURE <fs_line> TO <fs_field>.
*
*                IF <fs_field> IS ASSIGNED.
*                  <fs_field> = gw_final-note.
*                ENDIF.

              ENDLOOP.

              gt_zpor4 = <fs_table>.

              LOOP AT gt_zpor4 INTO gw_zpor4.
                APPEND gw_zpor4 TO gt_zpor41.
                CLEAR : gw_zpor4.
              ENDLOOP.

            ENDIF.
*** Record not found in table T024
          ELSE.
            gw_error-key          = gw_final-key.
            gw_error-pur_grp      = gw_final-pur_grp.
            gw_error-email_sender = gw_final-email_sender.
            gw_error-comment      = text-001. " 'Record not found in T024'.
            APPEND gw_error TO gt_error.
            CLEAR : gw_error.
          ENDIF.

*** Record not found in table zpor4
        ELSE.
          gw_error-key          = gw_final-key.
          gw_error-pur_grp      = gw_final-pur_grp.
          gw_error-email_sender = gw_final-email_sender.
          gw_error-comment      = text-002." 'Record not found in ZPOR4'.
          APPEND gw_error TO gt_error.
          CLEAR : gw_error.
        ENDIF.

**Check if the USER ID is not maintined in the System.
      ELSE.
        gw_error-key          = gw_final-key.
        gw_error-pur_grp      = gw_final-pur_grp.
        gw_error-email_sender = gw_final-email_sender.
        gw_error-comment      = text-003." 'Invalid UserID'.
        APPEND gw_error TO gt_error.
        CLEAR : gw_error.
      ENDIF.

**if the USER ID is not maintined in the excel sheet.
    ELSE.
      gw_error-key          = gw_final-key.
      gw_error-pur_grp      = gw_final-pur_grp.
      gw_error-email_sender = gw_final-email_sender.
      gw_error-comment      = text-004." 'Missing UserID'.
      APPEND gw_error TO gt_error.
      CLEAR : gw_error.
    ENDIF.

  ENDLOOP.

  IF gt_error IS INITIAL.
*** Update the ZPOR4
    UPDATE zpor4 FROM TABLE gt_zpor41.

  ENDIF.

ENDMETHOD.


METHOD validate_file.


  lv_str = file_name.
***Verify the file exists
  IF cl_gui_frontend_services=>file_exist( lv_str ) <> gc_x.
    MESSAGE s000 WITH text-e02.
    CALL TRANSACTION sy-tcode.
  ENDIF.

ENDMETHOD.
ENDCLASS.

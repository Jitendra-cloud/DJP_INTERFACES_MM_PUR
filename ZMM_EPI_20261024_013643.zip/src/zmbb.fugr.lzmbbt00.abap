*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME03052_BEG_BAL................................*
DATA:  BEGIN OF STATUS_ZME03052_BEG_BAL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME03052_BEG_BAL              .
CONTROLS: TCTRL_ZME03052_BEG_BAL
            TYPE TABLEVIEW USING SCREEN '0200'.
*.........table declarations:.................................*
TABLES: *ZME03052_BEG_BAL              .
TABLES: ZME03052_BEG_BAL               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

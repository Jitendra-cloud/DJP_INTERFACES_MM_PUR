*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME00315_GL_SUBS................................*
DATA:  BEGIN OF STATUS_ZME00315_GL_SUBS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME00315_GL_SUBS              .
CONTROLS: TCTRL_ZME00315_GL_SUBS
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZVND2...........................................*
DATA:  BEGIN OF STATUS_ZVND2                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVND2                         .
CONTROLS: TCTRL_ZVND2
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZME00315_GL_SUBS              .
TABLES: *ZVND2                         .
TABLES: ZME00315_GL_SUBS               .
TABLES: ZVND2                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

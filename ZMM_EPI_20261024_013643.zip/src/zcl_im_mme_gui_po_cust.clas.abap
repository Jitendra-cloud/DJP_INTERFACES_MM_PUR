*----------------------------------------------------------------------*
*       CLASS ZCL_IM_MME_GUI_PO_CUST DEFINITION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
class ZCL_IM_MME_GUI_PO_CUST definition
  public
  final
  create public .

public section.
*"* public components of class ZCL_IM_MME_GUI_PO_CUST
*"* do not include other source files here!!!
  type-pools MMMFD .

  interfaces IF_EX_ME_GUI_PO_CUST .

  constants SUBSCREEN1 type MEPO_NAME value 'HEADSCREEN1'. "#EC NOTEXT
  constants SUBSCREEN2 type MEPO_NAME value 'ITEMSCREEN1'. "#EC NOTEXT
  constants SUBSCREEN3 type MEPO_NAME value 'HEADSCREEN2'. "#EC NOTEXT
  data SUBSCREEN4 type MEPO_NAME value 'HEADSCREEN3'. "#EC NOTEXT . " .
  constants SUBSCREEN5 type MEPO_NAME value 'ITEMSCREEN2'. "#EC NOTEXT

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: PUBLIC-SECTION
  constants SUBSCREEN6 type MEPO_NAME value 'HEADSCREEN6'. "#EC NOTEXT
protected section.
*"* protected components of class ZCL_IM_MME_GUI_PO_CUST
*"* do not include other source files here!!!
PRIVATE SECTION.

*"* private components of class ZCL_IM_MME_GUI_PO_CUST
*"* do not include other source files here!!!
  DATA dynp_data_pbo TYPE zmme02915 .
  DATA dynp_data_pai TYPE zmme02915 .
  DATA dynp_data_pbo2 TYPE zmme03026 .
  DATA dynp_data_pai2 TYPE zmme03026 .
  DATA dynp_data_pbo3 TYPE zmme03097 .
  DATA dynp_data_pai3 TYPE zmme03097 .
  DATA dynp_data_pbo4 TYPE zsde3049_trade_ord .
  DATA dynp_data_pai4 TYPE zsde3049_trade_ord .
  DATA dynp_data_pbo5 TYPE zmme04990 .
  DATA dynp_data_pai5 TYPE zmme04990 .

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: PRIVATE-SECTION
  DATA dynp_data_pbo6 TYPE ZMME02915_FIBER.
  DATA dynp_data_pai6 TYPE ZMME02915_FIBER.
ENDCLASS.



CLASS ZCL_IM_MME_GUI_PO_CUST IMPLEMENTATION.


method IF_EX_ME_GUI_PO_CUST~EXECUTE .
endmethod.


METHOD if_ex_me_gui_po_cust~map_dynpro_fields .

* J.Grabowiecki    08/2011   E0V 20000   Add field ZZ_CLAIM

* given the fieldcatalog of structure ZMME02915 we have to
* establish a mapping to metafields which are used for field selection
* purposes and error handling Standard definitions can be found in type
* pool MMMFD. It is important for customer fields to use integer
* constants above 90000000 for the metafield.
  FIELD-SYMBOLS: <mapping> LIKE LINE OF ch_mapping.
  LOOP AT ch_mapping ASSIGNING <mapping>.

    CASE <mapping>-fieldname.

      WHEN 'ZZ_TRACT_NAME'.    <mapping>-metafield = mmmfd_cust_01.
      WHEN 'ZZ_CERT_CLASS'.    <mapping>-metafield = mmmfd_cust_02.
      WHEN 'ZZ_FIBER_AGE_CAT'. <mapping>-metafield = mmmfd_cust_03.
      WHEN 'ZZ_INT_GATE_PASS'. <mapping>-metafield = mmmfd_cust_04.
      WHEN 'ZZ_TAID'.          <mapping>-metafield = mmmfd_cust_05.
      WHEN 'ZZ_BUSINESS_TYPE'. <mapping>-metafield = mmmfd_cust_06.
      WHEN 'ZZ_MASTER_NO'.     <mapping>-metafield = mmmfd_cust_07.
      WHEN 'ZDUMMY'.           <mapping>-metafield = mmmfd_cust_08.
      WHEN 'ZZ_NAME1'.         <mapping>-metafield = mmmfd_cust_09.
      WHEN 'ZZ_TELF1'.         <mapping>-metafield = mmmfd_cust_10.
      WHEN 'ZZ_SRVC_EMAIL'.    <mapping>-metafield = 90000010. "E0VK917081

*--Begin of change CMS 14331 - LMATHE1
      WHEN 'ZZ_CERT_TREEFARM'.  <mapping>-metafield = 90000016.
      WHEN 'ZZ_CERT_SFI'.       <mapping>-metafield = 90000017.
      WHEN 'ZZ_CERT_FSC'.       <mapping>-metafield = 90000018.
      WHEN 'ZZ_CERT_CSA'.       <mapping>-metafield = 90000019.
      WHEN 'ZZ_CERT_NUM_TF'.    <mapping>-metafield = 90000020.
      WHEN 'ZZ_CERT_NUM_SFI'.   <mapping>-metafield = 90000021.
      WHEN 'ZZ_CERT_NUM_FSC'.   <mapping>-metafield = 90000022.
      WHEN 'ZZ_CERT_NUM_CSA'.   <mapping>-metafield = 90000023.
      WHEN 'ZZ_LANDOWNER'.      <mapping>-metafield = 90000024.
      WHEN 'ZZ_ACRES'.          <mapping>-metafield = 90000025.
      WHEN 'ZZ_LATITUDE'.       <mapping>-metafield = 90000026.
      WHEN 'ZZ_LONGITUDE'.      <mapping>-metafield = 90000027.
      WHEN 'ZZ_CLAIM'.          <mapping>-metafield = 90000028. "20000
*--End of change CMS 14331 - LMATHE1

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
      WHEN 'ZZ_IPCO'.       <mapping>-metafield = 90000011.
      WHEN 'ZZ_TRNPRICEPO'. <mapping>-metafield = 90000012.
      WHEN 'ZZ_USAGE'.      <mapping>-metafield = 90000013.
      WHEN 'ZZ_CONTRACT'.   <mapping>-metafield = 90000014.
      WHEN 'ZZ_VSBED'.      <mapping>-metafield = 90000015.
*--End of change for<EDGE Trade Order process 03302006>> EDEK905044

*>> Begin of CR# 11169 Recovered Fiber
      WHEN 'ZZ_ZDIST'.      <mapping>-metafield = 90000029.
*>> End of CR# 11169 Recovered Fiber

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method MAP_DYNPRO_FIELDS| START
* FIBER INFORMATION TAB:
      WHEN 'ZZ_BALE_SOURCE'.  <mapping>-metafield = 90000030.
      WHEN 'ZZ_BALE_TYPE'.    <mapping>-metafield = 90000031.
      WHEN 'ZZ_FORM_TYPE'.    <mapping>-metafield = 90000032.
      WHEN 'ZZ_PICK_UP'.      <mapping>-metafield = 90000033.
      WHEN 'ZZ_VEH_TYPE'.     <mapping>-metafield = 90000034.
      WHEN 'ZZ_FRT_TERM'.     <mapping>-metafield = 90000035.
      WHEN 'ZZ_CONTRACT_END'. <mapping>-metafield = 90000036.
      WHEN 'ZZ_MASTER_ORD'.   <mapping>-metafield = 90000037.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method MAP_DYNPRO_FIELDS| END

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/09/14| Changed: Method MAP_DYNPRO_FIELDS| START
* EXTRAS TAB:
      WHEN 'ZZ_LWD'.          <mapping>-metafield = 90000038.
      WHEN 'ZZ_THRESHOLD'.    <mapping>-metafield = 90000039.
      WHEN 'ZZ_DEDUCTION'.    <mapping>-metafield = 90000040.
      WHEN 'ZZ_INDEX_NAME'.   <mapping>-metafield = 90000041.
      WHEN 'ZZ_INDEX_REGION'. <mapping>-metafield = 90000042.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/09/14| Changed: Method MAP_DYNPRO_FIELDS| END
*-->CMS29519 E0VK9A0HPB SMITHAI 12/22/2015
      WHEN 'ZZ_CBSCODE'.      <mapping>-metafield = 90000043.
*<--CMS29519 E0VK9A0HPB SMITHAI 12/22/2015
*-->CMS29838 E0VK9A0IWG SMITHAI 2/15/2016
      WHEN 'ZZ_OUTAGE'.       <mapping>-metafield = 90000044.
*<--CMS29838 E0VK9A0IWG SMITHAI 2/15/2016

*->Begin of CMS 33780/MAIELY/ARIBA PO Confirmation Changes
      WHEN 'ZZ_CONF_PART'.    <mapping>-metafield = 90000045.
      WHEN 'ZZ_CONF_UOM'.     <mapping>-metafield = 90000046.
      WHEN 'ZZ_CONF_PRICE'.   <mapping>-metafield = 90000047.
      WHEN 'ZZ_REASON_CD'.    <mapping>-metafield = 90000048.
*-<End of CMS 33780/MAIELY/ARIBA PO Confirmation Changes

    ENDCASE.

  ENDLOOP.

ENDMETHOD.


METHOD if_ex_me_gui_po_cust~subscribe .
  DATA: ls_subscriber LIKE LINE OF re_subscribers,
        ws_match TYPE zmmfld-key1,                          "E0VK917081
        ws_zmmfld(1) TYPE c.                                "E0VK917081

* we want to add a customer subscreen on the item detail tab
  CHECK im_application = 'PO'.
  IF im_element     = 'HEADER'.
*   each line in re_subscribers generates a subscreen. We add one
*   subscreen in this example
    CLEAR re_subscribers[].
*  the name is a unique identifier for the subscreen and defined in this
*  class definition
    ls_subscriber-name = subscreen1.
*   the dynpro number to use
    ls_subscriber-dynpro = '0001'.
*   the program where the dynpro can be found
    ls_subscriber-program = 'SAPLZ_MM_E02915'.
*   each subscreen needs his own DDIC-Structure
    ls_subscriber-struct_name = 'ZMME02915'.
*   ls_subscriber-struct_name = 'EKKO'.
*   a label can be defined
    ls_subscriber-label = text-001.
*   the position within the tabstrib can be defined
    ls_subscriber-position = 11.
*  the height of the screen can be defined here. Currently we suport two
*   screen sizes:
*   value <= 7 a sevel line subscreen
*   value > 7  a 16 line subscreen
    ls_subscriber-height = 7.
    APPEND ls_subscriber TO re_subscribers.

******(Begin)-E0VK917081***E3097***********************************
    CLEAR ws_zmmfld.
    ws_match = sy-uname.
    CALL FUNCTION 'Z_GET_MM_PARAMETER'
      EXPORTING
        p_key1     = 'ZME3097'
        p_key2     = 'USER_EXCEP'
        p_match    = ws_match
      IMPORTING
        avail_flag = ws_zmmfld.
    IF ws_zmmfld <> 'X'.
      CLEAR ls_subscriber.
      ls_subscriber-name = subscreen3.
      ls_subscriber-dynpro = '0001'.
      ls_subscriber-program = 'SAPLZ_MM_E03097'.
      ls_subscriber-struct_name = 'ZMME03097'.
      ls_subscriber-label = text-003.
      ls_subscriber-position = 12.
      ls_subscriber-height = 7.
      APPEND ls_subscriber TO re_subscribers.
    ENDIF.
******(End)-E0VK917081****E3097************************************

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
    CLEAR ls_subscriber.
    ls_subscriber-name = subscreen4.
    ls_subscriber-dynpro = '0001'.
    ls_subscriber-program = 'SAPLZSDE3049_TRADE_ORD'.
    ls_subscriber-struct_name = 'ZSDE3049_TRADE_ORD'.
    ls_subscriber-label = text-004.
    ls_subscriber-position = 13.
    ls_subscriber-height = 7.
    APPEND ls_subscriber TO re_subscribers.
*--End of change for<EDGE Trade Order process 03302006>> EDEK905044

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method SUBSCRIBE| START
    CLEAR ls_subscriber.
    ls_subscriber-name = subscreen6.
    ls_subscriber-dynpro = '0001'.
    ls_subscriber-program = 'SAPLZ_MM_E02915_FIBER'.
    ls_subscriber-struct_name = 'ZMME02915_FIBER'.
    ls_subscriber-label = text-006.
    ls_subscriber-position = 14.
    ls_subscriber-height = 7.
    APPEND ls_subscriber TO re_subscribers.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method SUBSCRIBE| END

  ELSEIF im_element = 'ITEM'.
*   each line in re_subscribers generates a subscreen. We add one
*   subscreen in this example
    CLEAR re_subscribers[].
*  the name is a unique identifier for the subscreen and defined in this
*   class definition
    ls_subscriber-name = subscreen2.
*   the dynpro number to use
    ls_subscriber-dynpro = '0001'.
*   the program where the dynpro can be found
    ls_subscriber-program = 'SAPLZ_MM_E03026'.
*   each subscreen needs his own DDIC-Structure
    ls_subscriber-struct_name = 'ZMME03026'.
*   ls_subscriber-struct_name = 'EKKO'.
*   a label can be defined
    ls_subscriber-label = text-002.
*   the position within the tabstrib can be defined
    ls_subscriber-position = 90.
*  the height of the screen can be defined here. Currently we suport two
*   screen sizes:
*   value <= 7 a sevel line subscreen
*   value > 7  a 16 line subscreen
    ls_subscriber-height = 7.
    APPEND ls_subscriber TO re_subscribers.
*
*>> Begin of CR# 11169 Recovered Fiber

*  the name is a unique identifier for the subscreen and defined in this
*   class definition
    CLEAR ls_subscriber.
    ls_subscriber-name = subscreen5.
*   the dynpro number to use
    ls_subscriber-dynpro = '0001'.
*   the program where the dynpro can be found
    ls_subscriber-program = 'SAPLZ_MM_E04990'.
*   each subscreen needs his own DDIC-Structure
    ls_subscriber-struct_name = 'ZMME04990'.
*   a label can be defined
    ls_subscriber-label = text-005.
*   the position within the tabstrib can be defined
    ls_subscriber-position = 91.
*  the height of the screen can be defined here. Currently we suport two
*   screen sizes:
*   value <= 7 a sevel line subscreen
*   value > 7  a 16 line subscreen
    ls_subscriber-height = 7.
    APPEND ls_subscriber TO re_subscribers.
*>> End of CR# 11169 Recovered Fiber
*
  ENDIF.
ENDMETHOD.


METHOD if_ex_me_gui_po_cust~transport_from_dynp .
*--------------------------------------------------------------------*
* system asks to read dynpro data
*--------------------------------------------------------------------*
  CASE im_name.

    WHEN subscreen1.

      CALL FUNCTION 'Z_MM_E02915_POP'
        IMPORTING
          ex_dynp_data = dynp_data_pai.

      IF dynp_data_pai NE dynp_data_pbo.
* something has changed therefor we have to notify the framework
* to transport data to the model
        re_changed = mmpur_yes.
      ENDIF.

    WHEN subscreen2.

      CALL FUNCTION 'Z_MM_E03026_POP'
        IMPORTING
          ex_dynp_data = dynp_data_pai2.

      IF dynp_data_pai2 NE dynp_data_pbo2.
* something has changed therefor we have to notify the framework
* to transport data to the model
        re_changed = mmpur_yes.
      ENDIF.

******(Begin)-E0VK917081***E3097************************************
    WHEN subscreen3.
      CALL FUNCTION 'Z_MM_E03097_POP'
        IMPORTING
          ex_dynp_data = dynp_data_pai3.

      IF dynp_data_pai3 NE dynp_data_pbo3.
        re_changed = mmpur_yes.
      ENDIF.
******(End)-E0VK917081***E3097************************************

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
    WHEN subscreen4.

      CALL FUNCTION 'Z_SDE3049_POP'
        IMPORTING
          ex_dynp_data = dynp_data_pai4.

      IF dynp_data_pai4 NE dynp_data_pbo4.
        re_changed = mmpur_yes.
      ENDIF.
*--End of change for<EDGE Trade Order process 03302006>>EDEK905044

*>> Begin CR# 11169 Recovered Fiber
    WHEN subscreen5.

      CALL FUNCTION 'Z_MM_E04990_POP'
        IMPORTING
          ex_dynp_data = dynp_data_pai5.

** something has changed therefor we have to notify the framework
** to transport data to the model
      re_changed = mmpur_yes.
*>> End CR# 11169 Recovered Fiber

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_FROM_DYNP| START
    WHEN subscreen6.
      CALL FUNCTION 'Z_MM_E02915_FIBER_POP'
        IMPORTING
          ex_dynp_data = dynp_data_pai6.

      IF dynp_data_pai6 NE dynp_data_pbo6.
        re_changed = mmpur_yes.
      ENDIF.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_FROM_DYNP| END

    WHEN OTHERS.

  ENDCASE.
ENDMETHOD.


METHOD if_ex_me_gui_po_cust~transport_from_model .
  DATA: l_header      TYPE REF TO if_purchase_order_mm,
        ls_mepoheader TYPE mepoheader,
        lv_zdist      TYPE zdist,                          " CR# 11169
        l_item        TYPE REF TO if_purchase_order_item_mm,
        l_memory_id   TYPE c LENGTH 18,
        ls_mepoitem   TYPE mepoitem.
*--------------------------------------------------------------------*
* system asks to transport data from the business logic into the view
*--------------------------------------------------------------------*
  CASE im_name.

    WHEN subscreen1.

* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.
* transport standard fields
      ls_mepoheader = l_header->get_data( ).
      EXPORT ekorg FROM ls_mepoheader-ekorg TO MEMORY ID 'EKORG'.
*      SET PARAMETER ID 'EKO' FIELD ls_mepoheader-ekorg.

* store info for later use
      MOVE-CORRESPONDING ls_mepoheader TO dynp_data_pbo.

    WHEN subscreen2.

* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_item im_model.
      CHECK NOT l_item IS INITIAL.

* transport standard fields
      ls_mepoitem = l_item->get_data( ).
      l_header     = l_item->get_header( ).
      ls_mepoheader = l_header->get_data( ).
      EXPORT ekorg FROM ls_mepoheader-ekorg TO MEMORY ID 'EKORG'.
* store info for later use
      MOVE-CORRESPONDING ls_mepoitem TO dynp_data_pbo2.

******(Begin)-E0VK917081***E3097************************************
    WHEN subscreen3.
      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.
      ls_mepoheader = l_header->get_data( ).
      SET PARAMETER ID 'EKO' FIELD ls_mepoheader-ekorg.
      MOVE-CORRESPONDING ls_mepoheader TO dynp_data_pbo3.
******(End)-E0VK917081****E3097*************************************

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
    WHEN subscreen4.
      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.
      ls_mepoheader = l_header->get_data( ).
      SET PARAMETER ID 'EKO_EDGE' FIELD ls_mepoheader-ekorg.
      MOVE-CORRESPONDING ls_mepoheader TO dynp_data_pbo4.
*--End of change for<EDGE Trade Order process 03302006>> EDEK905044

*>> Begin CR# 11169 Recovered Fiber
    WHEN subscreen5.


* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_item im_model.
      CHECK NOT l_item IS INITIAL.

*** Start CMS 33160 ALANKAP 3/29/2018 Grayout fields Index name and Index Region
      l_header     = l_item->get_header( ).
      ls_mepoheader = l_header->get_data( ).
      SET PARAMETER ID 'EKO' FIELD ls_mepoheader-ekorg.
*** End CMS 33160 ALANKAP 3/29/2018 Grayout fields Index name and Index Region

** store info for later use

      CONCATENATE sy-uname 'E04990' INTO l_memory_id.
      CONDENSE l_memory_id.
*>> Start of modification ALANKAP 03/15/2013 CMS 24158
** transport standard fields
      ls_mepoitem = l_item->get_data( ).

      lv_zdist    = ls_mepoitem-zz_zdist.
      MOVE lv_zdist TO dynp_data_pbo5-zz_zdist.
*      IMPORT zdist  TO lv_zdist FROM MEMORY ID l_memory_id.
*      IF sy-subrc IS INITIAL.
*        MOVE lv_zdist TO dynp_data_pbo5-zz_zdist.
*        FREE MEMORY ID l_memory_id.
*      ENDIF.
*>> End of modification ALANKAP 03/15/2013 CMS 24158
*>> End CR# 11169 Recovered Fiber

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/09/14| Changed: Method TRANSPORT_FROM_MODEL| START
      MOVE ls_mepoitem-zz_lwd          TO dynp_data_pbo5-zz_lwd.
      MOVE ls_mepoitem-zz_threshold    TO dynp_data_pbo5-zz_threshold.
      MOVE ls_mepoitem-zz_deduction    TO dynp_data_pbo5-zz_deduction.
      MOVE ls_mepoitem-zz_index_name   TO dynp_data_pbo5-zz_index_name.
      MOVE ls_mepoitem-zz_index_region TO dynp_data_pbo5-zz_index_region.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/09/14| Changed: Method TRANSPORT_FROM_MODEL| END
*->Begin of CMS 33780/MAIELY/ARIBA PO Confirmation Changes
      MOVE ls_mepoitem-zz_conf_part    TO dynp_data_pbo5-zz_conf_part.
      MOVE ls_mepoitem-zz_conf_uom     TO dynp_data_pbo5-zz_conf_uom.
      MOVE ls_mepoitem-zz_conf_price   TO dynp_data_pbo5-zz_conf_price.
      MOVE ls_mepoitem-zz_reason_cd    TO dynp_data_pbo5-zz_reason_cd.
*-<End of CMS 33780/MAIELY/ARIBA PO Confirmation Changes
*-->CMS29519 E0VK9A0HPB SMITHAI 12/31/2015
      EXPORT knttp FROM ls_mepoitem-knttp TO MEMORY ID 'KNTTP'.
      SELECT * INTO TABLE @DATA(gt_zmmfld) FROM zmmfld WHERE key1 EQ 'E10717' AND
                                                             key2 EQ 'CBS_CODE' AND
                                                             key3 EQ 'ACCT_ASSGN' AND
                                                           value1 EQ @ls_mepoitem-knttp.
      IF sy-subrc = 0.
        IF ls_mepoitem-zz_cbscode IS  INITIAL.
          SELECT SINGLE zz_cbscode FROM eban INTO ls_mepoitem-zz_cbscode WHERE
            banfn = ls_mepoitem-banfn AND
            bnfpo = ls_mepoitem-bnfpo.
        ENDIF.
        MOVE ls_mepoitem-zz_cbscode TO dynp_data_pbo5-zz_cbscode.
        REFRESH gt_zmmfld[].
      ELSE.
        CLEAR: ls_mepoitem-zz_cbscode, dynp_data_pbo5-zz_cbscode.
      ENDIF.
*<--CMS29519 E0VK9A0HPB SMITHAI 12/31/2015
*-->CMS29838 E0VK9A0IWG SMITHAI 2/15/2016
      EXPORT werks FROM ls_mepoitem-werks TO MEMORY ID 'REVNR_WERKS'.
      SELECT SINGLE zz_outage FROM eban INTO ls_mepoitem-zz_outage WHERE banfn = ls_mepoitem-banfn AND
                                                                         bnfpo = ls_mepoitem-bnfpo.
      IF sy-subrc = 0.
        MOVE ls_mepoitem-zz_outage TO dynp_data_pbo5-zz_outage.
      ELSE.
        MOVE ls_mepoitem-zz_outage TO dynp_data_pbo5-zz_outage.
      ENDIF.
*<--CMS29838 E0VK9A0IWG SMITHAI 2/15/2016
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_FROM_MODEL| START
    WHEN subscreen6.

      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.
      ls_mepoheader = l_header->get_data( ).
      SET PARAMETER ID 'EKO' FIELD ls_mepoheader-ekorg.
      MOVE-CORRESPONDING ls_mepoheader TO dynp_data_pbo6.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_FROM_MODEL| END

    WHEN OTHERS.
* ...
  ENDCASE.

ENDMETHOD.


METHOD if_ex_me_gui_po_cust~transport_to_dynp .
*--------------------------------------------------------------------*
* system asks to fill dynpro work area during PBO
*--------------------------------------------------------------------*
  CASE im_name.

    WHEN subscreen1.

      CALL FUNCTION 'Z_MM_E02915_PUSH'
        EXPORTING
          im_dynp_data = dynp_data_pbo.

    WHEN subscreen2.

      CALL FUNCTION 'Z_MM_E03026_PUSH'
        EXPORTING
          im_dynp_data = dynp_data_pbo2.

******(Begin)-E0VK917081***E3097************************************
    WHEN subscreen3.
      CALL FUNCTION 'Z_MM_E03097_PUSH'
        EXPORTING
          im_dynp_data = dynp_data_pbo3.
******(End)-E0VK917081****E3097*************************************

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
    WHEN subscreen4.

      CALL FUNCTION 'Z_SDE3049_PUSH'
        EXPORTING
          im_dynp_data = dynp_data_pbo4.
*--End of change for<EDGE Trade Order process 03302006>>EDEK905044

*>> Begin CR# 11169 Recovered Fiber
    WHEN subscreen5.

      CALL FUNCTION 'Z_MM_E04990_PUSH'
        EXPORTING
          im_dynp_data = dynp_data_pbo5.
*>> End CR# 11169 Recovered Fiber

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_TO_DYNP| START
    WHEN subscreen6.
      CALL FUNCTION 'Z_MM_E02915_FIBER_PUSH'
        EXPORTING
          im_dynp_data = dynp_data_pbo6.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_TO_DYNP| END
    WHEN OTHERS.
  ENDCASE.

ENDMETHOD.


METHOD if_ex_me_gui_po_cust~transport_to_model .

* J.Grabowiecki    08/2011   E0V 20000   Add field ZZ_CLAIM

  DATA: l_header      TYPE REF TO if_purchase_order_mm,
        ls_mepoheader TYPE mepoheader,
        l_item        TYPE REF TO if_purchase_order_item_mm,
        ls_mepoitem   TYPE mepoitem.
*--------------------------------------------------------------------*
* data have to be transported to business logic
*--------------------------------------------------------------------*
  CASE im_name.

    WHEN subscreen1.

* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.

      ls_mepoheader = l_header->get_data( ).

* standard fields changed?
      IF dynp_data_pbo-zz_tract_name NE dynp_data_pai-zz_tract_name OR
         dynp_data_pbo-zz_cert_class NE dynp_data_pai-zz_cert_class OR
         dynp_data_pbo-zz_fiber_age_cat
                                  NE dynp_data_pai-zz_fiber_age_cat OR
         dynp_data_pbo-zz_int_gate_pass
                                  NE dynp_data_pai-zz_int_gate_pass OR
         dynp_data_pbo-zz_taid    NE dynp_data_pai-zz_taid OR
         dynp_data_pbo-zz_business_type
                                  NE dynp_data_pai-zz_business_type OR
         dynp_data_pbo-zz_master_no NE dynp_data_pai-zz_master_no OR
*--Begin of change CMS 14331 - LMATHE1
         dynp_data_pbo-zz_cert_treefarm NE dynp_data_pai-zz_cert_treefarm OR
         dynp_data_pbo-zz_cert_sfi      NE dynp_data_pai-zz_cert_sfi      OR
         dynp_data_pbo-zz_cert_fsc      NE dynp_data_pai-zz_cert_fsc      OR
         dynp_data_pbo-zz_cert_csa      NE dynp_data_pai-zz_cert_csa      OR
         dynp_data_pbo-zz_cert_num_tf   NE dynp_data_pai-zz_cert_num_tf   OR
         dynp_data_pbo-zz_cert_num_sfi  NE dynp_data_pai-zz_cert_num_sfi  OR
         dynp_data_pbo-zz_cert_num_fsc  NE dynp_data_pai-zz_cert_num_fsc  OR
         dynp_data_pbo-zz_cert_num_csa  NE dynp_data_pai-zz_cert_num_csa  OR
         dynp_data_pbo-zz_landowner     NE dynp_data_pai-zz_landowner     OR
         dynp_data_pbo-zz_acres         NE dynp_data_pai-zz_acres         OR
         dynp_data_pbo-zz_latitude      NE dynp_data_pai-zz_latitude      OR
         dynp_data_pbo-zz_longitude     NE dynp_data_pai-zz_longitude     OR
         dynp_data_pbo-zz_claim         NE dynp_data_pai-zz_claim. "20000
*--End of change CMS 14331 - LMATHE1

* update standard fields
        ls_mepoheader-zz_tract_name = dynp_data_pai-zz_tract_name.
        ls_mepoheader-zz_cert_class = dynp_data_pai-zz_cert_class.
        ls_mepoheader-zz_fiber_age_cat = dynp_data_pai-zz_fiber_age_cat.
        ls_mepoheader-zz_int_gate_pass = dynp_data_pai-zz_int_gate_pass.
        ls_mepoheader-zz_taid = dynp_data_pai-zz_taid.
        ls_mepoheader-zz_business_type = dynp_data_pai-zz_business_type.
        ls_mepoheader-zz_master_no = dynp_data_pai-zz_master_no.
*--Begin of change CMS 14331 - LMATHE1
        ls_mepoheader-zz_cert_treefarm = dynp_data_pai-zz_cert_treefarm.
        ls_mepoheader-zz_cert_sfi      = dynp_data_pai-zz_cert_sfi.
        ls_mepoheader-zz_cert_fsc      = dynp_data_pai-zz_cert_fsc.
        ls_mepoheader-zz_cert_csa      = dynp_data_pai-zz_cert_csa.
        ls_mepoheader-zz_cert_num_tf   = dynp_data_pai-zz_cert_num_tf.
        ls_mepoheader-zz_cert_num_sfi  = dynp_data_pai-zz_cert_num_sfi.
        ls_mepoheader-zz_cert_num_fsc  = dynp_data_pai-zz_cert_num_fsc.
        ls_mepoheader-zz_cert_num_csa  = dynp_data_pai-zz_cert_num_csa.
        ls_mepoheader-zz_landowner     = dynp_data_pai-zz_landowner.
        ls_mepoheader-zz_acres         = dynp_data_pai-zz_acres.
        ls_mepoheader-zz_latitude      = dynp_data_pai-zz_latitude.
        ls_mepoheader-zz_longitude     = dynp_data_pai-zz_longitude.
        ls_mepoheader-zz_claim         = dynp_data_pai-zz_claim. "20000
*--End of change CMS 14331 - LMATHE1
        CALL METHOD l_header->set_data( ls_mepoheader ).

      ENDIF.

    WHEN subscreen2.

* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_item im_model.
      CHECK NOT l_item IS INITIAL.

      ls_mepoitem = l_item->get_data( ).

* standard fields changed?
      IF dynp_data_pbo2-zz_name1 NE dynp_data_pai2-zz_name1 OR
         dynp_data_pbo2-zz_telf1 NE dynp_data_pai2-zz_telf1.
* update standard fields
        ls_mepoitem-zz_name1 = dynp_data_pai2-zz_name1.
        ls_mepoitem-zz_telf1 = dynp_data_pai2-zz_telf1.
        CALL METHOD l_item->set_data( ls_mepoitem ).

      ENDIF.

*****(Begin)-E0VK917081***E3097************************************
    WHEN subscreen3.
* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.

      ls_mepoheader = l_header->get_data( ).

* standard fields changed?
      IF dynp_data_pbo3-zz_srvc_email NE dynp_data_pai3-zz_srvc_email.
* update standard fields
        ls_mepoheader-zz_srvc_email = dynp_data_pai3-zz_srvc_email.
        CALL METHOD l_header->set_data( ls_mepoheader ).
      ENDIF.
******(End)-E0VK917081****E3097*************************************

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
    WHEN subscreen4.

* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.

      ls_mepoheader = l_header->get_data( ).

* standard fields changed? & update standard fields
      IF dynp_data_pbo4-zz_ipco NE dynp_data_pai4-zz_ipco OR
         dynp_data_pbo4-zz_trnpricepo NE dynp_data_pai4-zz_trnpricepo OR
         dynp_data_pbo4-zz_usage NE dynp_data_pai4-zz_usage OR
         dynp_data_pbo4-zz_contract NE dynp_data_pai4-zz_contract OR
         dynp_data_pbo4-zz_vsbed NE dynp_data_pai4-zz_vsbed.
        ls_mepoheader-zz_ipco = dynp_data_pai4-zz_ipco.
        ls_mepoheader-zz_trnpricepo = dynp_data_pai4-zz_trnpricepo.
        ls_mepoheader-zz_usage = dynp_data_pai4-zz_usage.
        ls_mepoheader-zz_contract = dynp_data_pai4-zz_contract.
        ls_mepoheader-zz_vsbed = dynp_data_pai4-zz_vsbed.

        CALL METHOD l_header->set_data( ls_mepoheader ).
      ENDIF.
*--End of change for<EDGE Trade Order process 03302006>>EDEK905044

*>> Begin of CR# 11169 Recovered Fiber
    WHEN subscreen5.
* is it an item? im_model can be header or item.
      mmpur_dynamic_cast l_item im_model.
      CHECK NOT l_item IS INITIAL.
      ls_mepoitem = l_item->get_data( ).

* standard fields changed?

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/09/14| Changed: Method TRANSPORT_TO_MODEL| START
*      IF dynp_data_pai5-zz_zdist IS NOT INITIAL.
      IF ls_mepoitem-zz_zdist        NE dynp_data_pai5-zz_zdist OR
         ls_mepoitem-zz_lwd          NE dynp_data_pai5-zz_lwd OR
         ls_mepoitem-zz_threshold    NE dynp_data_pai5-zz_threshold OR
         ls_mepoitem-zz_deduction    NE dynp_data_pai5-zz_deduction OR
         ls_mepoitem-zz_index_name   NE dynp_data_pai5-zz_index_name OR
*------->CMS29519 E0VK9A0HPB SMITHAI 12/22/2015
         ls_mepoitem-zz_index_region NE dynp_data_pai5-zz_index_region OR
         ls_mepoitem-zz_cbscode      NE dynp_data_pai5-zz_cbscode OR
*<-------CMS29519 E0VK9A0HPB SMITHAI 12/22/2015
*-------->CMS29838 E0VK9A0IWG SMITHAI 02/15/2016
         ls_mepoitem-zz_outage      NE dynp_data_pai5-zz_outage OR "CMS33780
*<-------CMS29838 E0VK9A0IWG SMITHAI 02/15/2016
*->Begin of CMS33780/MAIELY/ARIBA PO Confirmation Changes
         ls_mepoitem-zz_conf_part   NE dynp_data_pai5-zz_conf_part OR
         ls_mepoitem-zz_conf_uom    NE dynp_data_pai5-zz_conf_uom OR
         ls_mepoitem-zz_conf_price  NE dynp_data_pai5-zz_conf_price OR
         ls_mepoitem-zz_reason_cd   NE dynp_data_pai5-zz_reason_cd.
*-<End of CMS33780/MAIELY/ARIBA PO Confirmation Changes
* update standard fields
        ls_mepoitem-zz_zdist = dynp_data_pai5-zz_zdist.

        ls_mepoitem-zz_lwd          = dynp_data_pai5-zz_lwd.
        ls_mepoitem-zz_threshold    = dynp_data_pai5-zz_threshold.
        ls_mepoitem-zz_deduction    = dynp_data_pai5-zz_deduction.
        ls_mepoitem-zz_index_name   = dynp_data_pai5-zz_index_name.
        ls_mepoitem-zz_index_region = dynp_data_pai5-zz_index_region.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/09/14| Changed: Method TRANSPORT_TO_MODEL| END
*->Begin of CMS33780/MAIELY/ARIBA PO Confirmation Changes
        ls_mepoitem-zz_conf_part   = dynp_data_pai5-zz_conf_part.
        ls_mepoitem-zz_conf_uom    = dynp_data_pai5-zz_conf_uom.
        ls_mepoitem-zz_conf_price  = dynp_data_pai5-zz_conf_price.
        ls_mepoitem-zz_reason_cd   = dynp_data_pai5-zz_reason_cd.
*-<End of CMS33780/MAIELY/ARIBA PO Confirmation Changes

*---->CMS29519 E0VK9A0HPB SMITHAI 12/22/2015
        SELECT * INTO TABLE @DATA(gt_zmmfld) FROM zmmfld WHERE key1 EQ 'E10717' AND
                                                               key2 EQ 'CBS_CODE' AND
                                                               key3 EQ 'ACCT_ASSGN' AND
                                                               value1 EQ @ls_mepoitem-knttp.
        IF sy-subrc = 0.
          ls_mepoitem-zz_cbscode = dynp_data_pai5-zz_cbscode.
          IF ls_mepoitem-zz_cbscode IS NOT INITIAL.
*       --Check for Special Character.
            DATA: regex   TYPE REF TO cl_abap_regex,
                  matcher TYPE REF TO cl_abap_matcher,
                  match   TYPE c LENGTH 1.
            CREATE OBJECT regex
              EXPORTING
                pattern     = '^\w+$'
                ignore_case = abap_true.

            matcher = regex->create_matcher( text = ls_mepoitem-zz_cbscode ).
            match = matcher->match( ).

            IF match IS INITIAL.
              MESSAGE w339(zm).
            ENDIF.
          ENDIF.
        ELSE.
          CLEAR: ls_mepoitem-zz_cbscode, dynp_data_pai5-zz_cbscode.
        ENDIF.
        REFRESH gt_zmmfld[].
*<----CMS29519 E0VK9A0HPB SMITHAI 12/22/2015
*---->CMS29838 E0VK9A0IWG SMITHAI 02/15/2016
        ls_mepoitem-zz_outage = dynp_data_pai5-zz_outage.
*<----CMS29838 E0VK9A0IWG SMITHAI 02/15/2016
        CALL METHOD l_item->set_data( ls_mepoitem ).
      ENDIF.
*      ENDIF.
*>> End of CR# 11169 Recovered Fiber

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_TO_MODEL| START
    WHEN subscreen6.

      mmpur_dynamic_cast l_header im_model.
      CHECK NOT l_header IS INITIAL.

      ls_mepoheader = l_header->get_data( ).

      IF dynp_data_pbo6-zz_bale_source  NE dynp_data_pai6-zz_bale_source OR
         dynp_data_pbo6-zz_bale_type    NE dynp_data_pai6-zz_bale_type OR
         dynp_data_pbo6-zz_form_type    NE dynp_data_pai6-zz_form_type OR
         dynp_data_pbo6-zz_pick_up      NE dynp_data_pai6-zz_pick_up OR
         dynp_data_pbo6-zz_veh_type     NE dynp_data_pai6-zz_veh_type OR
         dynp_data_pbo6-zz_frt_term     NE dynp_data_pai6-zz_frt_term OR
         dynp_data_pbo6-zz_contract_end NE dynp_data_pai6-zz_contract_end OR
         dynp_data_pbo6-zz_master_ord   NE dynp_data_pai6-zz_master_ord.


        ls_mepoheader-zz_bale_source = dynp_data_pai6-zz_bale_source.
        ls_mepoheader-zz_bale_type = dynp_data_pai6-zz_bale_type.
        ls_mepoheader-zz_form_type = dynp_data_pai6-zz_form_type.
        ls_mepoheader-zz_pick_up = dynp_data_pai6-zz_pick_up.
        ls_mepoheader-zz_veh_type = dynp_data_pai6-zz_veh_type.
        ls_mepoheader-zz_frt_term = dynp_data_pai6-zz_frt_term.
        ls_mepoheader-zz_contract_end = dynp_data_pai6-zz_contract_end.
        ls_mepoheader-zz_master_ord = dynp_data_pai6-zz_master_ord.

        CALL METHOD l_header->set_data( ls_mepoheader ).

      ENDIF.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method TRANSPORT_TO_MODEL| END

    WHEN OTHERS.

  ENDCASE.
ENDMETHOD.
ENDCLASS.

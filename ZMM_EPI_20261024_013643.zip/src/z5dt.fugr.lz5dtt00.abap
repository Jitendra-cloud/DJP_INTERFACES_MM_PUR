*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMIDAT..........................................*
DATA:  BEGIN OF STATUS_ZMIDAT                        .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMIDAT                        .
CONTROLS: TCTRL_ZMIDAT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMIDAT                        .
TABLES: ZMIDAT                         .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

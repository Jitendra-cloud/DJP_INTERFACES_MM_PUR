*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_APR_PLANTS..................................*
DATA:  BEGIN OF STATUS_ZMM_APR_PLANTS                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_APR_PLANTS                .
CONTROLS: TCTRL_ZMM_APR_PLANTS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_APR_PLANTS                .
TABLES: ZMM_APR_PLANTS                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

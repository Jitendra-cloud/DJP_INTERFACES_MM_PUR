*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZ1VNTOP.                          " Global Data
  INCLUDE LZ1VNUXX.                          " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZ1VNF...                          " Subprograms
* INCLUDE LZ1VNO...                          " PBO-Modules
* INCLUDE LZ1VNI...                          " PAI-Modules

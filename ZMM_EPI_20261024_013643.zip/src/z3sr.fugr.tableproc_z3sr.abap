*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3SR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3SR                .

  PERFORM TABLEPROC.

ENDFUNCTION.

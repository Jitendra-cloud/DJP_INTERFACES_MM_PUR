*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMMALT_VEN_MAIL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMMALT_VEN_MAIL     .

  PERFORM TABLEPROC.

ENDFUNCTION.

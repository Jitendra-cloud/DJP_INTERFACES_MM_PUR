*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME162_VAL_CLASS................................*
DATA:  BEGIN OF STATUS_ZME162_VAL_CLASS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME162_VAL_CLASS              .
CONTROLS: TCTRL_ZME162_VAL_CLASS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME162_VAL_CLASS              .
TABLES: ZME162_VAL_CLASS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZME1251_STOCKOUT
*   generation date: 2003.04.16 at 13:51:15 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZME1251_STOCKOUT   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

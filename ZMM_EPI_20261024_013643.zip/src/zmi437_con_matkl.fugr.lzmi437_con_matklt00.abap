*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMI437_CON_MATKL................................*
DATA:  BEGIN OF STATUS_ZMI437_CON_MATKL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMI437_CON_MATKL              .
CONTROLS: TCTRL_ZMI437_CON_MATKL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMI437_CON_MATKL              .
TABLES: ZMI437_CON_MATKL               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

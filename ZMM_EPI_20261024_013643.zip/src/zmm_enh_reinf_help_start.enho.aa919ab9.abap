"Name: \FU:HELP_START\SE:BEGIN\EI
ENHANCEMENT 0 ZMM_ENH_REINF_HELP_START.

******** CMS 32804 - HMALKOW - start ********
"Changes for Brazil REINF Service Codes
if ( SY-TCODE = 'ME21N' or SY-TCODE = 'ME22N' or SY-TCODE = 'ME23N' ) and
     help_infos-fieldname = 'USERF1_NUM' and
     help_infos-dynprofld = 'ESLL-USERF1_NUM' and
     help_infos-dynpprog  = 'SAPLMLSP'.

  data: lt_return type standard table of ddshretval.
  data: ls_return type ddshretval.

    select distinct
      value1 as Code,
      value7 as Description
    from zmmfld into table @data(lt_code)
    where key1 = 'BRAZIL' and
          key2 = 'U01286' and
          key3 = 'REINF_SRVC' and
          key4 = 'SERVICE_CODE'
    order by value1.


  call function 'F4IF_INT_TABLE_VALUE_REQUEST'
    exporting
      retfield     = 'CODE'
      dynpprog     = help_infos-dynpprog
      dynpnr       = help_infos-dynpro
      dynprofield  = help_infos-dynprofld
      value_org    = 'S'
      window_title = 'REINF Service Codes'
    tables
      value_tab   = lt_code
      return_tab  = lt_return
    exceptions
      others      = 1.

  if sy-subrc = 0 and lines( lt_return ) = 1.
    read table lt_return into ls_return index 1.
    selection = 'X'.
    select_value = ls_return-fieldval.
    exit.
  endif.

endif.

******** CMS 32804 - HMALKOW - end   ********
ENDENHANCEMENT.

FUNCTION FIELD_EXIT_BWARTWA_1.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(INPUT)
*"  EXPORTING
*"     REFERENCE(OUTPUT)
*"----------------------------------------------------------------------
SET PARAMETER ID 'BWA' FIELD INPUT.

 OUTPUT = INPUT.

ENDFUNCTION.

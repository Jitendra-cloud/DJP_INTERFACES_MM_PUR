class ZCL_ME_BAPI_PO_CUST definition
  public
  final
  create public .

public section.
*"* public components of class ZCL_ME_BAPI_PO_CUST
*"* do not include other source files here!!!

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_BAPI_PO_CREATE_02 .
protected section.
*"* protected components of class ZCL_ME_BAPI_PO_CUST
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_ME_BAPI_PO_CUST
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_ME_BAPI_PO_CUST IMPLEMENTATION.


  method IF_EX_ME_BAPI_PO_CREATE_02~EXTENSIONIN.
  endmethod.


  method IF_EX_ME_BAPI_PO_CREATE_02~EXTENSIONOUT.
  endmethod.


METHOD if_ex_me_bapi_po_create_02~inbound.
*** Start of modification CMS 23789 ALANKAP 01/17/2013
*** The below coding is done as part of SAP Note 1654724 Implementation
  CONSTANTS: c_key1           TYPE zkey1 VALUE 'ZME_BAPI_PO_CUST',
             c_a991_appl      TYPE zkey2 VALUE 'A991_APPL',
             c_a991_condition TYPE zkey2 VALUE 'A991_CONDITION',
             c_company        TYPE zkey2 VALUE 'COMPANY',
             c_doc_type       TYPE zkey2 VALUE 'DOC_TYPE',
             c_x              TYPE char1 VALUE 'X'.

  FIELD-SYMBOLS: <fs_itemx> TYPE bapimepoitemx,
                 <fs_item>  TYPE bapimepoitem.

  DATA: ls_a991     TYPE a991,
        lv_mwsk1    TYPE mwskz,
        lt_zmmfld   TYPE STANDARD TABLE OF zmmfld,
        ls_zmmfld   TYPE zmmfld,
        lv_doc_type TYPE esart,
        lv_company  TYPE bukrs,
        lv_kappl    TYPE kappl,
        lv_kschl    TYPE kscha.

  SELECT * INTO TABLE lt_zmmfld
           FROM zmmfld
           WHERE key1 = c_key1.
  IF sy-subrc EQ 0.
    CLEAR: ls_zmmfld, lv_kappl.
    READ TABLE lt_zmmfld INTO ls_zmmfld WITH KEY
                              key1 = c_key1
                              key2 = c_a991_appl.
    lv_kappl = ls_zmmfld-value1.
    CLEAR: ls_zmmfld, lv_kschl.
    READ TABLE lt_zmmfld INTO ls_zmmfld WITH KEY
                              key1 = c_key1
                              key2 = c_a991_condition.
    lv_kschl = ls_zmmfld-value1.
    CLEAR: ls_zmmfld, lv_company.
    READ TABLE lt_zmmfld INTO ls_zmmfld WITH KEY
                              key1 = c_key1
                              key2 = c_company.
    lv_company = ls_zmmfld-value1.
    CLEAR: ls_zmmfld, lv_doc_type.
    READ TABLE lt_zmmfld INTO ls_zmmfld WITH KEY
                              key1 = c_key1
                              key2 = c_doc_type.
    lv_doc_type = ls_zmmfld-value1.
  ENDIF.
  IF ch_poheader-doc_type = lv_doc_type
    AND ch_poheader-comp_code = lv_company.
    LOOP AT ch_item ASSIGNING <fs_item>.
      CLEAR: ls_a991, lv_mwsk1.
      SELECT SINGLE * INTO ls_a991 FROM a991
       WHERE kappl = lv_kappl
       AND   kschl = lv_kschl
       AND   werks =  <fs_item>-plant
       AND   datbi GT sy-datum.
      IF sy-subrc EQ 0.
        SELECT SINGLE mwsk1 INTO (lv_mwsk1)
               FROM konp
               WHERE knumh = ls_a991-knumh
               AND   kopos = '01'.
        IF sy-subrc EQ 0.
          <fs_item>-tax_code = lv_mwsk1.
          READ TABLE ch_itemx ASSIGNING <fs_itemx> WITH KEY
                               po_item = <fs_item>-po_item.
          IF sy-subrc EQ 0.
            <fs_itemx>-tax_code = c_x.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
    UNASSIGN: <fs_itemx>, <fs_item>.
  ENDIF.
*** End of modification CMS 23789 ALANKAP 01/17/2013
ENDMETHOD.


METHOD if_ex_me_bapi_po_create_02~map2e_extensionout.

ENDMETHOD.


METHOD if_ex_me_bapi_po_create_02~map2i_extensionin.
  FIELD-SYMBOLS: <fs_structure> TYPE any,
                 <fs_field> TYPE any.

  DATA: lv_length   TYPE i,
        lv_position TYPE i,
        lv_value    TYPE i,
        lv_type     TYPE c.

  CLEAR: lv_value, lv_position.
  ASSIGN ch_struc TO <fs_structure>.

  DO.
    ASSIGN COMPONENT sy-index OF STRUCTURE <fs_structure> TO <fs_field>.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.
    DESCRIBE FIELD <fs_field> TYPE lv_type.
    IF lv_type EQ 'P'.
      DESCRIBE FIELD <fs_field> OUTPUT-LENGTH lv_length.
    ELSE.
      DESCRIBE FIELD <fs_field> LENGTH lv_length IN CHARACTER MODE.
    ENDIF.

    lv_value    = lv_value + lv_length.
    lv_position = lv_value - lv_length.
    <fs_field>  = im_container+lv_position(lv_length).
  ENDDO.
  UNASSIGN: <fs_structure>, <fs_field>.

ENDMETHOD.


method IF_EX_ME_BAPI_PO_CREATE_02~OUTBOUND.

endmethod.


method IF_EX_ME_BAPI_PO_CREATE_02~PARTNERS_ON_ITEM_ACTIVE.
endmethod.


method IF_EX_ME_BAPI_PO_CREATE_02~TEXT_OUTPUT.
endmethod.


  method IF_EX_ME_BAPI_PO_CREATE_02~TOGGLE_ORDER_UNIT.
  endmethod.
ENDCLASS.

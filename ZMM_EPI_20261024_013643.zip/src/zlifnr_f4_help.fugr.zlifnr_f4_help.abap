FUNCTION zlifnr_f4_help.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  TABLES
*"      SHLP_TAB TYPE  SHLP_DESCT
*"      RECORD_TAB STRUCTURE  SEAHLPRES
*"  CHANGING
*"     REFERENCE(SHLP) TYPE  SHLP_DESCR
*"     REFERENCE(CALLCONTROL) TYPE  DDSHF4CTRL
*"----------------------------------------------------------------------

*callcontrol-step = 'SELONE' -> This step is only called for
*  collective search helps.
*callcontrol-step = 'PRESEL' -> This step allows you, to influence the
*  selection conditions before they are displayed
*callcontrol-STEP = 'SELECT' -> This step may be used to overtake the
*  data selection completely.
*callcontrol-step = 'DISP' -> This step may be used to overtake the
*  DATA selection completely.
*callcontrol-step = 'EXIT' -> To exit from the block.
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================   ========  ======  ==============================*
*  MAIELY              02/29/2016        CMS29992:Get vendor list      *
*                                        for OBJKY = LFA1              *
*______________________________________________________________________*
  TYPES : BEGIN OF ty_lifnr,
          lifnr TYPE belnr_d,
          END OF ty_lifnr.

  DATA : it_lifnr3 TYPE STANDARD TABLE OF ty_lifnr WITH HEADER
LINE.

  DATA: it_usapplref TYPE STANDARD TABLE OF usapplref WITH HEADER
LINE.

  DATA: g_type TYPE dd01v-datatype.
  DATA: g_string(10) TYPE c.

  IF callcontrol-step <> 'SELONE' AND
     callcontrol-step <> 'SELECT' AND
     callcontrol-step <> 'DISP'.
    EXIT.
  ENDIF.

  IF callcontrol-step = 'SELONE'.
    EXIT.
  ENDIF.

  IF callcontrol-step = 'SELECT'.


**** Start changes by kmaddel on 10/22/2015 CMS 29230  E0VK9A0FWG
      SELECT * FROM usapplref INTO TABLE it_usapplref
               UP TO callcontrol-maxrecords ROWS
               WHERE bname EQ sy-uname                      "CMS29992
                 AND objtype EQ 'LFA1'.                     "CMS29992

    LOOP AT it_usapplref.
      CLEAR g_type.

      g_string = it_usapplref-objkey.

      CALL FUNCTION 'NUMERIC_CHECK'
        EXPORTING
          string_in = g_string
        IMPORTING
          htype     = g_type.

*      IF g_type = 'NUMC'.                                  "CMS29992
      IF g_type = 'NUMC' OR g_type = 'CHAR'.                "CMS29992
        it_lifnr3-lifnr = it_usapplref-objkey.
        APPEND it_lifnr3.

      ENDIF.
**** End changes by kmaddel on 10/22/2015 CMS 29230  E0VK9A0FWG

    ENDLOOP.


    CALL FUNCTION 'F4UT_RESULTS_MAP'
      TABLES
        shlp_tab          = shlp_tab
        record_tab        = record_tab
        source_tab        = it_lifnr3
      CHANGING
        shlp              = shlp
        callcontrol       = callcontrol
      EXCEPTIONS
        illegal_structure = 1
        OTHERS            = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
    callcontrol-step = 'DISP'.
  ENDIF.

  IF callcontrol-step = 'DISP'.
    EXIT.
  ENDIF.

ENDFUNCTION.

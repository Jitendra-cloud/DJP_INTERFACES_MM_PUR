*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z2CW
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z2CW                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME00315_GL_SUBS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME00315_GL_SUBS    .

  PERFORM TABLEPROC.

ENDFUNCTION.

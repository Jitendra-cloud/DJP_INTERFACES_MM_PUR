*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMPROCOFF.......................................*
DATA:  BEGIN OF STATUS_ZMPROCOFF                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMPROCOFF                     .
CONTROLS: TCTRL_ZMPROCOFF
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMPROCOFF                     .
TABLES: ZMPROCOFF                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

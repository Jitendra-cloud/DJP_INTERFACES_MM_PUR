*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z2PS
*   generation date: 2003.05.12 at 15:12:31 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z2PS                .

  PERFORM TABLEPROC.

ENDFUNCTION.

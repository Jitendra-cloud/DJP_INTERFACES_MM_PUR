*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z2PS
*   generation date: 2003.05.12 at 15:12:31 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z2PS               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

class ZCL_MM_GST_INDIA_TAX definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_BADI_J_1IG_STO .
protected section.
private section.
ENDCLASS.



CLASS ZCL_MM_GST_INDIA_TAX IMPLEMENTATION.


  method IF_BADI_J_1IG_STO~CHANGE_BEFORE_DISPLAY.
  endmethod.


  METHOD if_badi_j_1ig_sto~change_before_post.


*   Export the AR document number to memory. It's being used
*   in the User Exit ZXFMCU08

    DATA: lv_ar_ref TYPE char14.

    lv_ar_ref+0(10) = t_bseg[ 1 ]-belnr.
    lv_ar_ref+10(4) = t_bseg[ 1 ]-gjahr.

    EXPORT lv_ar_ref = lv_ar_ref TO MEMORY ID 'APPM_AR_REF'.

  ENDMETHOD.


  METHOD if_badi_j_1ig_sto~change_tax_code.
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
*                                                                     **
**                    COPYRIGHT (C) 2017 by                           **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT (C)                          **
**                       20xx, 20xx, 20xx                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*----------------------------------------------------------------------*
* Program Name: Create REMIT data related CSV file     Date: 06/22/2017*
*                                                                      *
* Class Name  : ZCL_MM_GST_INDIA_TAX      Version: Draft               *
*                                                                      *
* Programmer  : Anil Lankapalli                Last Update: mm/dd/yy   *
*                                                                      *
*----------------------------------------------------------------------*
* This method will be used to populate the tax code from ZMMFLD table  *
*                                                                      *
* Class Name : ZCL_MM_GST_INDIA_TAX                                    *
* Method     : CHANGE_TAX_CODE                                         *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #            Action             *
* ===============  ==========   ========== ============================*
* Anil Lankapalli  06/22/2017   CMS 31995  Initial Development.        *
* Anil Lankapalli  07/05/2017   CMS 32226 Get the Tax code from        *
*                               ZMMFLD table                           *
*----------------------------------------------------------------------*
    DATA: lv_mwskz     TYPE zvalue_1.
    IF ch_mwskz IS INITIAL.
      SELECT SINGLE value1 INTO lv_mwskz
                   FROM zmmfld
                   WHERE key1 = 'E10995'
                   AND   key2 = 'J_1IG_INV'
                   AND   key3 = 'TAX_CODE'
                   AND   key4 = im_bseg-mwskz.
      IF sy-subrc IS INITIAL.
        ch_mwskz = lv_mwskz.
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.

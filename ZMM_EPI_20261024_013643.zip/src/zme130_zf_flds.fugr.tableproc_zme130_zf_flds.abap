*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME130_ZF_FLDS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME130_ZF_FLDS      .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 2002.09.04 at 10:50:16 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMPLTMATDESC....................................*
DATA:  BEGIN OF STATUS_ZMPLTMATDESC                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMPLTMATDESC                  .
CONTROLS: TCTRL_ZMPLTMATDESC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMPLTMATDESC                  .
TABLES: ZMPLTMATDESC                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

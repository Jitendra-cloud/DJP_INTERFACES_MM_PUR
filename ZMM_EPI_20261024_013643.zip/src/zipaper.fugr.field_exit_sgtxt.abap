FUNCTION field_exit_sgtxt.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(INPUT)
*"  EXPORTING
*"     REFERENCE(OUTPUT)
*"----------------------------------------------------------------------

  TABLES : mseg.

  DATA: v_pedido LIKE ekpo-ebeln,
        v_item   LIKE ekpo-ebelp,
        v_ebeln  LIKE ekpo-ebeln,
        v_lifnr  LIKE ekko-lifnr,
        v_ebelp  LIKE ekpo-ebelp,
        v_mblnr  LIKE mseg-mblnr,
        v_mjahr  LIKE mseg-mjahr,
        v_zeile  LIKE mseg-zeile,
        v_matnr  LIKE mseg-matnr,
        vl_matnr LIKE mseg-matnr,
        v_centro LIKE marc-werks,
        v_werks  LIKE marc-werks,
        v_movto  LIKE mseg-bwart,
        v_depo_e LIKE mseg-umlgo,
        v_depo_s LIKE mseg-lgort,
        v_mtart  LIKE mara-mtart.

* Busca Centro da Memória
  GET PARAMETER ID 'WRK' FIELD v_centro.

* Busca Tipo de Movimento da Memória
  GET PARAMETER ID 'BWA' FIELD v_movto.

* Busca Depósito Entrada
  GET PARAMETER ID 'LAG' FIELD v_depo_e.

* Busca Depósito Saída
  GET PARAMETER ID 'UMLG' FIELD v_depo_s.

* Busca Material da Memória
  GET PARAMETER ID 'MAT' FIELD v_matnr.

*  IF NOT v_matnr IS INITIAL.
*    vl_matnr = v_matnr.
*    SET PARAMETER ID 'MXX' FIELD vl_matnr.
*  ELSE.
*    GET PARAMETER ID 'MXX' FIELD vl_matnr.
*    v_matnr = vl_matnr.
*  ENDIF.

* Busca Doc. material
  GET PARAMETER ID 'MBN' FIELD v_mblnr.

* Busca Ano
  GET PARAMETER ID 'MJA' FIELD v_mjahr.

** Verifica se centro é válido
*check v_centro eq '0050'.

  IF v_matnr IS INITIAL.
    SELECT matnr
    INTO   (v_matnr)
    FROM   mseg
    WHERE  mblnr = v_mblnr  AND
           mjahr = v_mjahr  AND
           lgort = v_depo_s AND
           umlgo = v_depo_e.
    ENDSELECT.
  ENDIF.

*V_PEDIDO = INPUT.

* Verifica se o Centro é válido
  SELECT SINGLE werks
  INTO   (v_werks)
  FROM   ztmm002
  WHERE  werks = v_centro.
  CHECK sy-subrc IS INITIAL.

*
  CHECK NOT v_matnr IS INITIAL.
  SELECT mtart
  INTO   (v_mtart)
  FROM   mara
  WHERE  matnr = v_matnr.
  ENDSELECT.
*Change of code SREDDY2/32906/DEVK9A17YM
* Verifica Tipo de Material
*  CHECK v_mtart EQ 'TNPR' OR
*        v_mtart EQ 'NVBR' OR
*        v_mtart EQ 'MACH' OR
*        v_mtart EQ 'PKNG'.
  SELECT SINGLE mtart
    INTO   (v_mtart)
    FROM   ztmm005
    WHERE  mtart = v_mtart.
  CHECK sy-subrc IS INITIAL.

* Verifica Tipo de Movimento
  IF v_movto = '311'.

* Verifica Depósitos
    CHECK ( v_depo_s = '0004' OR v_depo_s = '0001' )
      AND ( v_depo_e = '0001' OR v_depo_e = '0004' ).

    SEARCH input FOR '/'.
    IF sy-subrc NE 0.
      MESSAGE e009(zspec) WITH 'Informar Pedido/Item separados por "/"'.
    ENDIF.

* Move pedido para variável.
    SPLIT input AT '/' INTO v_pedido v_item.

* Consiste pedido
    SELECT ebeln lifnr
    INTO   (v_ebeln, v_lifnr)
    FROM   ekko
    WHERE  ebeln = v_pedido.
    ENDSELECT.

*
    IF sy-subrc IS INITIAL.
* Consiste Item pedido

      SELECT ebeln ebelp
      INTO   (v_ebeln, v_ebelp)
      FROM   ekpo
      WHERE  ebeln = v_pedido AND
             ebelp = v_item   AND
             matnr = v_matnr.
      ENDSELECT.
*
      IF sy-subrc IS INITIAL.
        CONCATENATE v_pedido '/' v_item '/' v_lifnr INTO output.
      ELSE.
        MESSAGE e009(zspec) WITH
             'Material Não encontrado neste Pedido/Item!'
                                                v_pedido v_item v_matnr.
      ENDIF.
    ELSEIF input IS INITIAL.
      MESSAGE e009(zspec) WITH 'Preencher Número do Pedido ! '.
    ELSE.
      MESSAGE e009(zspec) WITH
                           'Não existe pedido para Material Indicado!'
                            v_matnr .
    ENDIF.

  ELSEIF v_movto = '312'.

    SEARCH input FOR '/'.
    IF sy-subrc NE 0.
      MESSAGE e009(zspec) WITH
                          'Entrar com um Documento de Material e Item'
                          '(Operação de Saída) separados por "/"'.
    ENDIF.

    SPLIT input AT '/' INTO v_mblnr v_zeile.

    SELECT SINGLE * FROM mseg INTO mseg WHERE mblnr = v_mblnr
                                        AND zeile = v_zeile.
    IF sy-subrc NE 0 OR v_zeile EQ '0000'.
      MESSAGE e009(zspec) WITH 'Documento/Item não encontrado'.

    ENDIF.

  ENDIF.

ENDFUNCTION.

"Name: \PR:SAPMM06E\EX:MM06EO0M_MODIFY_LOOP_01\EI
ENHANCEMENT 0 Z_ENH_DISABLE_TXZ01_IP_ME2122.
*-->Begin of CMS#28470 E0VK9A0CYT 6/11/2015 BR TXZ01 Chg SMITHAI
    DATA: gt_zmmfld TYPE STANDARD TABLE OF zmmfld,
          gc_e10563 TYPE C LENGTH 6 VALUE 'E10563',
          gc_ekorg  TYPE C LENGTH 5 VALUE 'EKORG',
          lv_maktx TYPE makt-maktx,
          lv_matnr TYPE matnr.

*---Check Screen Number for Enhancement
    IF ( sy-tcode EQ 'ME22' OR sy-tcode EQ 'ME21' ) AND sy-dynnr = '0120'.

*-----Check Purchase Organization for Brazil in ZMMFLD.
      SELECT * INTO TABLE gt_zmmfld FROM zmmfld WHERE key1 EQ gc_e10563 AND
                                                      key2 EQ gc_ekorg AND
                                                      value1 = ekko-ekorg.
      IF SY-SUBRC = 0.

*-------Check Plant / Material / P.Org combination exists.
        CLEAR lv_matnr.
        SELECT SINGLE a~matnr INTO lv_matnr FROM marc AS a INNER JOIN t024w AS b ON
          a~werks = b~werks WHERE
          a~matnr = ekpo-matnr AND
          b~werks = ekpo-werks AND
          b~ekorg = ekko-ekorg.

        IF sy-subrc = 0.

*---------Change TXZ01 Test.
          Clear lv_maktx.
          SELECT SINGLE MAKTX FROM MAKT INTO lv_maktx WHERE matnr = EKPO-MATNR AND
          spras = sy-langu.
          IF Sy-subrc = 0.
            IF EKPO-txz01 <> lv_maktx.
              EKPO-txz01 = lv_maktx.
              MESSAGE ID 'ZM' TYPE 'I' NUMBER '336' WITH EKPO-MATNR.
            ENDIF.
          ENDIF.

*---------Disable Input Field.
          LOOP AT SCREEN.
            IF SCREEN-NAME = 'EKPO-TXZ01'.
              SCREEN-INPUT = '0'.
              MODIFY SCREEN.
            ENDIF.
          ENDLOOP.

        ENDIF. "End of Plant / Material / Combination check.

      ENDIF. " End of ZMMFLD P.Org check.

    ENDIF. "End of Check for Screen / Sy-tcode.
*END OF<--- CMS#28470 E0VK9A0CYT 8/11/2015 BR TXZ01 Chg SMITHAI

ENDENHANCEMENT.

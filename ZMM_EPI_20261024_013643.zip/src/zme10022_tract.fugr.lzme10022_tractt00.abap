*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME10022_TRACT..................................*
DATA:  BEGIN OF STATUS_ZME10022_TRACT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME10022_TRACT                .
CONTROLS: TCTRL_ZME10022_TRACT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME10022_TRACT                .
TABLES: ZME10022_TRACT                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*&---------------------------------------------------------------------*
*&  Include           LZME3051_MGR_V2OPS                               *
*&---------------------------------------------------------------------*
tables: ZMMATLGRP_DESC.

types: begin of descrt,
         matkl type ZMMATLGRP_DESC-matkl,
         ZCOM_DESCR_KEY type ZMMATLGRP_DESC-ZCOM_DESCR_KEY,
         ZCOM_DESCRIPTION type ZMMATLGRP_DESC-ZCOM_DESCRIPTION,
       end of descrt.

data: dscr_buftab type sorted table of descrt WITH UNIQUE KEY matkl.

*&---------------------------------------------------------------------*
*&      Module  fill_descr  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE fill_descr OUTPUT.
  perform get_descr using extract+7(09).
ENDMODULE.                 " fill_descr  OUTPUT

*&--------------------------------------------------------------------*
*&      Form  get_descr
*&--------------------------------------------------------------------*
*       text
*---------------------------------------------------------------------*
*      -->PMATKL     text
*---------------------------------------------------------------------*
form get_descr using pmatkl.
  data: wa_dscr type descrt.

  read table dscr_buftab into wa_dscr with key matkl = pmatkl.
  if sy-subrc = 0.
    move-corresponding wa_dscr to ZMMATLGRP_DESC.
  else.
    select * from ZMMATLGRP_DESC where matkl = extract+7(09)
                  and spras = sy-langu order by zprimary descending.
      exit. "read only first, if primary exist it should be primary
    endselect.
    if sy-subrc = 0.
      move-corresponding ZMMATLGRP_DESC to wa_dscr.
      insert wa_dscr into table dscr_buftab.
    else.
      clear ZMMATLGRP_DESC.
    endif.
  endif.
endform.                    "get_descr

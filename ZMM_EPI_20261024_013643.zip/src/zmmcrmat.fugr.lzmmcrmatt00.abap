*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMCRMAT........................................*
DATA:  BEGIN OF STATUS_ZMMCRMAT                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMCRMAT                      .
CONTROLS: TCTRL_ZMMCRMAT
            TYPE TABLEVIEW USING SCREEN '0018'.
*.........table declarations:.................................*
TABLES: *ZMMCRMAT                      .
TABLES: ZMMCRMAT                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

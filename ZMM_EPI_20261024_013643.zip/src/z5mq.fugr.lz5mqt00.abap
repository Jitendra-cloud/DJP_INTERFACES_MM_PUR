*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMTERMS.........................................*
DATA:  BEGIN OF STATUS_ZMTERMS                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMTERMS                       .
CONTROLS: TCTRL_ZMTERMS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMTERMS                       .
TABLES: ZMTERMS                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

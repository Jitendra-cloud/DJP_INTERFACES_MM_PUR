*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZAMO
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZAMO                .

  PERFORM TABLEPROC.

ENDFUNCTION.

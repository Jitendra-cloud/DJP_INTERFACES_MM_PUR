*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z1ME
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z1ME                .

  PERFORM TABLEPROC.

ENDFUNCTION.

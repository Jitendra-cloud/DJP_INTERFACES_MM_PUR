*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3ZS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3ZS                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: YMM_HARBOR_RLSTK................................*
DATA:  BEGIN OF STATUS_YMM_HARBOR_RLSTK              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_YMM_HARBOR_RLSTK              .
CONTROLS: TCTRL_YMM_HARBOR_RLSTK
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *YMM_HARBOR_RLSTK              .
TABLES: YMM_HARBOR_RLSTK               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

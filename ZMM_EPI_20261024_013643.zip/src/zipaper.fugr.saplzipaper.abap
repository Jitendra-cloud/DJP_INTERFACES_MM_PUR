*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZIPAPERTOP.                       " Global Data
  INCLUDE LZIPAPERUXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZIPAPERF...                       " Subprograms
* INCLUDE LZIPAPERO...                       " PBO-Modules
* INCLUDE LZIPAPERI...                       " PAI-Modules

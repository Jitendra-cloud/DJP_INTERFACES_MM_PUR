*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMA3
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMA3                .

  PERFORM TABLEPROC.

ENDFUNCTION.

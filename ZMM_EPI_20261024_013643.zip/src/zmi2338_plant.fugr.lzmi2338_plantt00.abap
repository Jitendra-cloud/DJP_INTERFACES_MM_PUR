*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMI2338_PLANT...................................*
DATA:  BEGIN OF STATUS_ZMI2338_PLANT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMI2338_PLANT                 .
CONTROLS: TCTRL_ZMI2338_PLANT
            TYPE TABLEVIEW USING SCREEN '2000'.
*.........table declarations:.................................*
TABLES: *ZMI2338_PLANT                 .
TABLES: ZMI2338_PLANT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

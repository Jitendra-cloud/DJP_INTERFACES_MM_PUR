*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMCHARG........................................*
DATA:  BEGIN OF STATUS_ZMMCHARG                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMCHARG                      .
CONTROLS: TCTRL_ZMMCHARG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMMCHARG                      .
TABLES: ZMMCHARG                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

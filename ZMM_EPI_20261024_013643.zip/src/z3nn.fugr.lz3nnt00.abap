*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSNXT...........................................*
DATA:  BEGIN OF STATUS_ZSNXT                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSNXT                         .
CONTROLS: TCTRL_ZSNXT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSNXT                         .
TABLES: ZSNXT                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

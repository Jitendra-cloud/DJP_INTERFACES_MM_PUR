*----------------------------------------------------------------------*
*       CLASS ZCL_R10031_APPM_SMARTFORM DEFINITION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS zcl_r10031_appm_smartform DEFINITION
  PUBLIC
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_header,
        zpo_heading      TYPE char30,     " po Heading
        zpo_heading_cont TYPE char40,     " po Heading continued
        zpo_number       TYPE ebeln,       " PO Number
        zpo_date         TYPE char10,      " po Date
        zdate_format     TYPE char10,      " po Date format
        zpo_lifnr        TYPE lifnr,       " Account Number of Vendor or Creditor
        zs_name1         TYPE ad_name1,    " NAME 1
        zs_name2         TYPE ad_name2,    " NAME 2
        zs_str_suppl1    TYPE ad_strspp1,  " Street 2
        zs_str_suppl2    TYPE ad_strspp2,  " Street 3
        zs_street        TYPE ad_street,   "  Street
        zs_city1         TYPE ad_city1,    " City
        zs_post_code1    TYPE ad_pstcd1,   " postal code
        zs_landx50       TYPE landx50,     " Country Name (Max. 50 Characters)
        zs_verkf         TYPE everk,       " Responsible Salesperson at Vendor's Office
        zs_telf1         TYPE telf0,       " Vendor's Telephone Number
        zs_smtp_addr     TYPE ad_smtpadr,  " Vendor Email
        zbs_heading      TYPE c LENGTH 25, " Bill n ship to headin g
*             zBS_plant          TYPE ewerk,
*             zBS_stge_loc       TYPE lgort_d,
        zbs_comp_name    TYPE tdobname,   " company name
        zbs_name1        TYPE ad_name1,   " Name
        zbs_str_suppl1   TYPE ad_strspp1, " Street 2
        zbs_str_suppl2   TYPE ad_strspp2, " Street 3
        zbs_street       TYPE ad_street,  " Street
        zbs_city         TYPE ad_city1,   " City
        zbs_district     TYPE ad_city2,   " District
        zbs_postl_cod1   TYPE ad_pstcd1,  " postal code
        zbs_landx50      TYPE landx50,    " Country Name (Max. 50 Characters)
*             zbc_ekgrp          TYPE  zekgrp,    " prchase group
        zbc_contact      TYPE zzmcontact,
        zbc_phone1       TYPE  zphone1,   " Telephone
        zbc_phone2       TYPE  zphone2,   " Fax
        zbc_e_mail       TYPE  char40,    " Email
        zsup_ref         TYPE  tdline,     " Su
        zagreement       TYPE  konnr,     " Agreement
        zmo_disp         TYPE  tdline,     " MOde of Dispatch
        zfreight         TYPE  tdline,     " Freight
        zsh_incoterms1   TYPE  inco1,     " Incoterms (Part 1) Shippment terms
        zsh_incoterms2   TYPE   inco2,     " Incoterms (Part 2) Shippment terms
        zpayterm         TYPE  tdline,     " Payment terms
        zinsurance       TYPE char20,    " Insurance
      END OF ty_header .
    TYPES:
      BEGIN OF ty_lfa1,
        lifnr TYPE lifnr,       " Account Number of Vendor
        name1 TYPE name1_gp,    " Name 1
        ort01 TYPE ort01_gp,    " City
        ort02 TYPE ort02_gp,    " District
        pstlz TYPE pstlz,       " Postal Code
        regio TYPE regio,       " Region (State, Province, County)
        stras TYPE stras_gp,    " House number and street
        adrnr TYPE adrnr,       " ADDRESS NUMBER
        stceg TYPE stceg,       " VAT registration number
        land1 TYPE land1_gp,    " Country Key
      END OF ty_lfa1 .
    TYPES:
*
      BEGIN OF ty_lfm1,
        verkf TYPE everk, " Responsible salesperson at vendor SURESH
        telf1 TYPE telfe, " Vendor's telephone number"SURESH 2/11
        lifnr TYPE elifn, " Vendor Account Number
        ekorg TYPE ekorg, " Purchasing Organization
      END OF ty_lfm1 .
    TYPES:
*
      BEGIN OF ty_adrc,
        addrnumber TYPE ad_addrnum,  " ADDRESS NUMBER
        date_from  TYPE ad_date_fr,  " Date valid from
        nation     TYPE ad_nation,   " International address version ID
        name1      TYPE ad_name1,    " Name 1
        name2      TYPE ad_name2,    " Name 2
        city1      TYPE ad_city1,    " City
        city2      TYPE ad_city2,    " District
        post_code1 TYPE ad_pstcd1,   " City postal code
        post_code2 TYPE ad_pstcd2,    " Postal Code 2  "CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
        po_box     TYPE ad_pobx,                       "CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
        street     TYPE ad_street,   " Street
        str_suppl1 TYPE ad_strspp1,  " Street 2
        str_suppl2 TYPE ad_strspp2,  " Street 3
        str_suppl3 TYPE ad_strspp3,  " Steert 4 CMS27120
        country    TYPE land1,       " Country Key
        tel_number TYPE ad_tlnmbr1,  " TELEPHONE NUMBER
        fax_number TYPE ad_fxnmbr1,  " FAX
        house_num1 TYPE ad_hsnm1,    " House Number
      END OF ty_adrc .
    TYPES:
      BEGIN OF ty_adr6,
        addrnumber TYPE ad_addrnum,  " Address number
        persnumber TYPE ad_persnum,  " Person number
        date_from  TYPE ad_date_fr,  " Date valid from
        consnumber TYPE ad_consnum,  " Sequence number
        smtp_addr  TYPE ad_smtpadr,  " E-Mail Address
      END OF ty_adr6 .
    TYPES:
      BEGIN OF ty_t005t,
        spras   TYPE spras,         " Language Key
        land1   TYPE land1,         " Country Key
        landx50 TYPE landx50,       " Country Name
      END OF ty_t005t .
    TYPES:
      BEGIN OF ty_ekko2,
        zebeln TYPE ekko-ebeln,
        zspras TYPE ekko-spras,
      END OF ty_ekko2 .
    TYPES:
      BEGIN OF ty_ekpo2,
        zebeln TYPE ekpo-ebeln,
        zebelp TYPE ekpo-ebelp,
        ztxz01 TYPE ekpo-txz01,
      END OF ty_ekpo2 .
    TYPES:
      BEGIN OF ty_supplier,
        lifnr          TYPE lifnr,       " Account Number of Vendor or Creditor
        name1          TYPE ad_name1,    " NAME 1
        name2          TYPE ad_name2,    " NAME 2
        str_suppl1     TYPE ad_strspp1,  " Street 2
        str_suppl2     TYPE ad_strspp2,  " Street 3
        str_suppl3     TYPE ad_strspp3,  " Street 4
        street         TYPE ad_street,  " Street
        city1          TYPE ad_city1,    " City
        post_code1     TYPE ad_pstcd1,   " postal code
        land1          TYPE land1_gp,    "Country "CMS29471
        landx50        TYPE landx50,     " Country Name (Max. 50 Characters)
        verkf          TYPE everk,       " Responsible Salesperson at Vendor's Office
        telf1          TYPE telf0,       " Vendor's Telephone Number
        smtp_addr      TYPE ad_smtpadr,
        zs_supp_street TYPE  char140,
      END OF ty_supplier .
    TYPES:
      BEGIN OF ty_bill_ship,
        item       TYPE  ebelp,
        address    TYPE  ad_addrnum,
        zheading   TYPE c LENGTH 150,
        plant      TYPE ewerk,
        stge_loc   TYPE lgort_d,
        comp_name  TYPE tdobname,
        name1      TYPE ad_name1,   " Name
        str_suppl1 TYPE ad_strspp1, " Street 2
        str_suppl2 TYPE ad_strspp2, " Street 3
        street     TYPE ad_street,  " Street
        str_suppl3 TYPE ad_strspp3, " Street 3  "CMS27120
        city       TYPE ad_city1,   " City
        district   TYPE ad_city2,   " District
        postl_cod1 TYPE ad_pstcd1,  " postal code
        landx50    TYPE landx50,    " Country Name (Max. 50 Characters)
        zstatus    TYPE c LENGTH 1,
      END OF ty_bill_ship .
    TYPES:
      BEGIN OF ty_buy_detail,
        zekgrp   TYPE  zekgrp,  " prchase group
        zcontact TYPE zzmcontact,
        zphone1	 TYPE  zphone1, " Telephone
        zphone2	 TYPE  zphone2, " Fax
        e_mail   TYPE  char40,  " Email
      END OF ty_buy_detail .
    TYPES:
      BEGIN OF ty_esll,
        packno     TYPE packno,   "Package number
        introw     TYPE introw,   "Line Number CMS27120
        extrow     TYPE extrow,   "Line Number CMS27120
        del        TYPE del,      "Deletion Indicator
        srvpos      TYPE asnum,    " Activity Number
        ktext1     TYPE sh_text1, " Short Text
        menge      TYPE mengev,   " Quantity with Sign
        meins      TYPE meins,    " Base Unit of Measure
        peinh      TYPE epein,    " Price Unit
        netwr      TYPE snetwr,   " Net Value of Item
        sub_packno TYPE sub_packno,
        tbtwr      TYPE sbrtwr,   " Gross Price
        zchange    TYPE indicator,                          "CMS27120
      END OF ty_esll .

* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|START
    TYPES : BEGIN OF ty_asmd,
              asnum TYPE asnum, " Activity number
              taxim TYPE taxis, " Tax classification
            END OF ty_asmd.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|END

    TYPES:
      BEGIN OF ty_j_1imocomp,
        zj_1icstno TYPE j_1icstno, " Central Sales Tax Number
        zj_1ilstno TYPE j_1ilstno, " Local Sales Tax Number
        zj_1iexcd  TYPE j_1iexcd,  " ECC Number
        zj_1iexrg	 TYPE j_1iexrg,  " Excise Range
        zj_1iexdi  TYPE j_1iexdi,  " Excise Division
        zj_1iexco	 TYPE j_1iexco,  " Excise Commissionerate
      END OF ty_j_1imocomp .
    TYPES ty_ship_addr TYPE tline .
    TYPES:
*  types:
*    BEGIN OF ty_ship_addr.
*            INCLUDE STRUCTURE tline.
*    TYPES END OF ty_ship_addr .
*    DATA:
*      gt_read_text    TYPE STANDARD TABLE OF tline .
      gt_read_text1    TYPE STANDARD TABLE OF tline .
    TYPES:
      gt_header1       TYPE STANDARD TABLE OF zmm_r10031_smartform .
    TYPES:
      it_komv2         TYPE STANDARD TABLE OF komv .
    TYPES:
      it_konv          TYPE STANDARD TABLE OF konv .        "CMS29471
    TYPES:
      gt_somlreci1 TYPE STANDARD TABLE OF somlreci1 .
    TYPES gw_somlreci1 TYPE somlreci1 .
    TYPES:
      gt_sopcklsti1 TYPE STANDARD TABLE OF sopcklsti1 .
    TYPES:
      gt_solisti1   TYPE STANDARD TABLE OF solisti1 .
    TYPES:
      gt_solix      TYPE STANDARD TABLE OF solix .
    TYPES:
      gt_soparai1   TYPE STANDARD TABLE OF soparai1 .
    TYPES:
      gt_soparbi1 TYPE STANDARD TABLE OF soparbi1 .

* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|START
    TYPES: BEGIN OF ty_t685t,
             kappl TYPE t685t-kappl,
             kschl TYPE t685t-kschl,
             vtext TYPE t685t-vtext,
           END OF ty_t685t .

    DATA:
      it_t685t TYPE STANDARD TABLE OF ty_t685t .
    DATA lw_t685t TYPE ty_t685t.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|END

    DATA:
      lt_tline TYPE STANDARD TABLE OF tline .
    DATA lw_tline TYPE tline .
    DATA:
      lt_cdhdr TYPE STANDARD TABLE OF cdhdr .
    DATA lw_cdhdr TYPE cdhdr .
    DATA:
      lt_cdpos TYPE STANDARD TABLE OF cdpos .
    DATA lw_cdpos TYPE cdpos .
    DATA zpoheader TYPE ekko .
    DATA lt_total_basic TYPE kwert .
    DATA lt_total_basic1 TYPE konv-kwert .
    DATA lv_zsbc_total TYPE konv-kwert .
    DATA:
      ztext TYPE c LENGTH 150 .
    DATA:
      zs_supp_street1(180) TYPE c .                         "CMS27120
    DATA:
      zs_supp_name1(80) TYPE c .
    DATA:
      zpoitem          TYPE TABLE OF ekpo .
    DATA:
      zpoitem1          TYPE TABLE OF ekpo .
    DATA:
      zpoaddrdelivery  TYPE TABLE OF bapimepoaddrdelivery .
    DATA:
      zposchedule      TYPE TABLE OF bapimeposchedule .
    DATA:
      zpoaccount       TYPE TABLE OF bapimepoaccount .
    DATA:
      zpocondheader    TYPE TABLE OF bapimepocondheader .
    DATA:
      zpocond          TYPE TABLE OF bapimepocond .
    DATA:
      zpotextheader    TYPE TABLE OF bapimepotextheader .
    DATA:
      zpotextitem      TYPE TABLE OF bapimepotext .
    DATA:
      zpopartner       TYPE TABLE OF bapiekkop .
    DATA:
      zextensionout    TYPE TABLE OF bapiparex .
    DATA:
      gt_buy_detail   TYPE STANDARD TABLE OF ty_buy_detail .
    DATA:
      gt_bill_ship    TYPE STANDARD TABLE OF ty_bill_ship .
    DATA:
      gt_ship_addr    TYPE STANDARD TABLE OF tline .
    DATA gw_ship_addr TYPE tline .
    DATA:
      gt_bill_ship2    TYPE STANDARD TABLE OF ty_bill_ship .
    DATA:
      gt_bill_ship1   TYPE STANDARD TABLE OF ty_bill_ship .
    DATA:
      gt_twlad        TYPE STANDARD TABLE OF twlad .
    DATA:
      gt_adrc         TYPE STANDARD TABLE OF adrc .
    DATA:
      gt_t001w        TYPE STANDARD TABLE OF t001w .
    DATA:
      gt_t001l        TYPE STANDARD TABLE OF t001l .
    DATA:
      gt_supplier     TYPE STANDARD TABLE OF ty_supplier .
    DATA:
      lt_nast         TYPE STANDARD TABLE OF nast .
    DATA:
      lt_t005t        TYPE STANDARD TABLE OF t005t .
    DATA:
      gt_tdlines      TYPE STANDARD TABLE OF tline .
    DATA:
      gt_header       TYPE STANDARD TABLE OF zmm_r10031_smartform .
    DATA:
      gt_reg_office   TYPE STANDARD TABLE OF tline .
    DATA:
      gt_zmmfld       TYPE STANDARD TABLE OF zmmfld .
    DATA:
      lt_adrnr        TYPE STANDARD TABLE OF tline .
    DATA:
      gt_corp_office  TYPE STANDARD TABLE OF tline .
    DATA:
      gt_instructions TYPE STANDARD TABLE OF tline .
    DATA:
      gt_item         TYPE STANDARD TABLE OF zmm_r10031_smartform_item .
    DATA:
      it_komv1        TYPE STANDARD TABLE OF komv .
    DATA:
      lt_serv_mas     TYPE STANDARD TABLE OF  zmm_r10031_smartform_ser_mas .
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|START
    DATA: wa_asmd TYPE ty_asmd,
          it_asmd TYPE STANDARD TABLE OF ty_asmd.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|END
    DATA:
      lt_serv_mas1     TYPE STANDARD TABLE OF  ty_esll .
    DATA:
      lt_serv_mas2     TYPE STANDARD TABLE OF  ty_esll .
    DATA:
      gt_j_1imocomp   TYPE STANDARD TABLE OF ty_j_1imocomp .
    DATA:
      lt_ekko         TYPE STANDARD TABLE OF ekko .
    DATA:
      lt_temp_text    TYPE STANDARD TABLE OF tline .
    DATA:
      lt_konv         TYPE STANDARD TABLE OF konv .
    DATA:
      lt_tax          TYPE STANDARD TABLE OF zmm_r10031_smartform_tax .
    DATA:
      it_komv         TYPE STANDARD TABLE OF komv .
    DATA:
      gt_legal TYPE STANDARD TABLE OF tline .
    DATA gw_t001w TYPE t001w .
    DATA gw_adrc TYPE adrc .
    DATA gw_twlad TYPE twlad .
    DATA gw_t001l TYPE t001l .
    DATA gw_buy_detail TYPE ty_buy_detail .
    DATA gw_bill_ship TYPE ty_bill_ship .
    DATA wa_zpor4 TYPE zpor4 .
    DATA wa_t005x TYPE t005x .
    DATA gw_header TYPE zmm_r10031_smartform .
    DATA gw_supplier TYPE ty_supplier .
    DATA wa_t024 TYPE t024 .
    DATA lw_podelv TYPE bapimepoaddrdelivery .
    DATA lw_poitem TYPE ekpo .
    DATA wa_lfa1 TYPE ty_lfa1 .
    DATA wa_lfm1 TYPE ty_lfm1 .
    DATA wa_adr6 TYPE ty_adr6 .
    DATA lw_t005t TYPE t005t .
    DATA wa_t005t TYPE ty_t005t .
    DATA gw_dd07v TYPE dd07v .
    DATA wa_adrc TYPE ty_adrc .
    DATA gw_reg_office TYPE tline .
    DATA gw_zmmfld TYPE zmmfld .
    DATA wa_po_payterm TYPE tline .
    DATA wa_po_freight TYPE tline .
    DATA wa_po_disp TYPE tline .
    DATA wa_sup_ref TYPE tline .
    DATA lw_nast TYPE nast .                        "Change document items
    DATA gw_tdlines TYPE tline .
    DATA gw_corp_office TYPE tline .
    DATA gw_instructions TYPE tline .
    DATA lw_adrnr TYPE tline .
    DATA wa_t052u TYPE t052u .
    DATA lw_serv_mas TYPE zmm_r10031_smartform_ser_mas .
    DATA wa_komv1 TYPE komv .
    DATA gw_j_1imocomp TYPE ty_j_1imocomp .
    DATA gw_item TYPE zmm_r10031_smartform_item .
    DATA zw_poschedule TYPE bapimeposchedule .
    DATA zw_pocond TYPE bapimepocond .
    DATA zw_potextitem TYPE bapimepotext .
    DATA lw_temp_text TYPE bapimepotext .
    DATA lw_ekko TYPE ekko .
    DATA lw_konv TYPE konv .
    DATA lw_tax TYPE zmm_r10031_smartform_tax .
    DATA wa_t005 TYPE t005 .
    DATA iw_komv TYPE komv .
    DATA gw_bill_ship1 TYPE ty_bill_ship .
    DATA lw_serv_mas1 TYPE ty_esll .
    DATA lw_serv_mas2 TYPE ty_esll .
    DATA lw_ekpo TYPE ekpo .
    DATA:
      gt_dd07v  TYPE TABLE OF dd07v .
    DATA:
      gt_dd07v1 TYPE TABLE OF dd07v .
    DATA l_objectid TYPE cdhdr-objectid .
    DATA zname_text TYPE thead-tdname .
    DATA id TYPE thead-tdid .
    DATA name TYPE thead-tdname .
    DATA object TYPE thead-tdobject .
    DATA z_lines TYPE char10 .
    DATA zdate TYPE char12 .
    DATA zinsurance TYPE char20 .
    DATA zcount TYPE c .
    DATA:
      chg_count(3)  TYPE c .
    DATA:
      quat_count(3) TYPE c .
    DATA:
      per_count(3)  TYPE c .
    DATA:
      count(3)      TYPE c .
    DATA obj_itab TYPE REF TO data .
    DATA obj_wa TYPE REF TO data .
    DATA obj_field TYPE REF TO data .
    DATA o_data TYPE REF TO data .
    DATA d_service TYPE REF TO data .
    DATA o_data3 TYPE REF TO data .
    DATA o_data1 TYPE REF TO data .
    DATA zkwert1 TYPE konv-kwert .
    DATA zkwert2 TYPE konv-kwert .
    DATA zkwert3 TYPE konv-kwert .
    DATA zkbetr1 TYPE konv-kbetr .
    DATA zkbetr2 TYPE konv-kbetr .
    DATA zkbetr3 TYPE konv-kbetr .
    DATA zv_pf_kbetr TYPE konv-kbetr .
    DATA jmop_kwert TYPE kwert .
    DATA jmop_kbetr TYPE kbetr .
    DATA jmop_krech TYPE krech .
    DATA jaop_kwert TYPE kwert .
    DATA jaop_kbetr TYPE kbetr .
    DATA jaop_krech TYPE krech .
    DATA jsiq_kwert TYPE kwert .
    DATA jsiq_kbetr TYPE kbetr .
    DATA jsiq_krech TYPE krech .
    DATA jaiq_kwert TYPE kwert .
    DATA jaiq_kbetr TYPE kbetr .
    DATA jaiq_krech TYPE krech .
    DATA jmiq_kwert TYPE kwert .
    DATA jmiq_kbetr TYPE kbetr .
    DATA jmiq_krech TYPE krech .
    DATA jsoq_kwert TYPE kwert .
    DATA jsoq_kbetr TYPE kbetr .
    DATA jsoq_krech TYPE krech .
    DATA jaoq_kwert TYPE kwert .
    DATA jaoq_kbetr TYPE kbetr .
    DATA jaoq_krech TYPE krech .
    DATA jmoq_kwert TYPE kwert .
    DATA jmoq_kbetr TYPE kbetr .
    DATA jmoq_krech TYPE krech .
    DATA jsip_kwert TYPE kwert .
    DATA jsip_kbetr TYPE kbetr .
    DATA jsip_krech TYPE krech .
    DATA jaip_kwert TYPE kwert .
    DATA jaip_kbetr TYPE kbetr .
    DATA jaip_krech TYPE krech .
    DATA jmip_kwert TYPE kwert .
    DATA jmip_kbetr TYPE kbetr .
    DATA jmip_krech TYPE krech .
    DATA jsop_kwert TYPE kwert .
    DATA jsop_kbetr TYPE kbetr .
    DATA jsop_krech TYPE krech .
    DATA jec1_kwert TYPE kwert .
    DATA jec1_kbetr TYPE kbetr .
    DATA jec1_krech TYPE krech .
    DATA jec2_kwert TYPE kwert .
    DATA jec2_kbetr TYPE kbetr .
    DATA jec2_krech TYPE krech .
    DATA jsep_kwert TYPE kwert .
    DATA jsep_kbetr TYPE kbetr .
    DATA jsep_krech TYPE krech .
    DATA jsei_kwert TYPE kwert .
    DATA jsei_kbetr TYPE kbetr .
    DATA jsei_krech TYPE krech .
    DATA jipc_kwert TYPE kwert .
    DATA jipc_kbetr TYPE kbetr .
    DATA jipc_krech TYPE krech .
    DATA jvrd_kwert TYPE kwert .
    DATA jvrd_kbetr TYPE kbetr .
    DATA jvrd_krech TYPE krech .
    DATA jser_kwert TYPE kwert .
    DATA jser_kbetr TYPE kbetr .
    DATA jser_krech TYPE krech .
    DATA jvrn_kwert TYPE kwert .
    DATA jvrn_kbetr TYPE kbetr .
    DATA jvrn_krech TYPE krech .
    DATA jec3_kwert TYPE kwert .
    DATA jec3_kbetr TYPE kbetr .
    DATA jec3_krech TYPE krech .
    DATA zsvd_kwert TYPE kwert .
    DATA zsvd_kbetr TYPE kbetr .
    DATA zsvd_krech TYPE krech .
    DATA jsv2_kwert TYPE kwert .
    DATA jsv2_kbetr TYPE kbetr .
    DATA jsv2_krech TYPE krech .
    DATA jse1_kwert TYPE kwert .
    DATA jse1_kbetr TYPE kbetr .
    DATA jse1_krech TYPE krech .
    DATA zec3_kwert TYPE kwert .
    DATA zec3_kbetr TYPE kbetr .
    DATA zec3_krech TYPE krech .
    DATA jec4_kwert TYPE kwert .
    DATA jec4_kbetr TYPE kbetr .
    DATA jec4_krech TYPE krech .
    DATA zse1_kwert TYPE kwert .
    DATA zse1_kbetr TYPE kbetr .
    DATA zse1_krech TYPE krech .
    DATA jse2_kwert TYPE kwert .
    DATA jse2_kbetr TYPE kbetr .
    DATA jse2_krech TYPE krech .
    DATA zkschl TYPE kschl .
    DATA zkwert TYPE kwert .
    DATA zkbetr TYPE kbetr .
    DATA zkrech TYPE krech .
    DATA zkrech1 TYPE krech .
    DATA sshc_kwert TYPE kwert .
    DATA sshc_kbetr TYPE kbetr .
    DATA sec_kwert TYPE kwert .
    DATA sec_kbetr TYPE kbetr .
    DATA exd_kbetr TYPE kbetr .
    DATA exd_kwert TYPE kwert .
    DATA exd_kwert1 TYPE kwert .
    DATA ser_tax_kbetr TYPE kbetr .
    DATA ser_tax_kwert TYPE kwert .
    DATA cst_kbetr TYPE kbetr .
    DATA cst_kwert TYPE kwert .
    DATA sed_kbetr TYPE kbetr .
    DATA sed_kwert TYPE kwert .
    DATA ed_kbetr TYPE kbetr .
    DATA ed_kwert TYPE kwert .
    DATA ed_kwert1 TYPE kwert .
    DATA vat_kbetr TYPE kbetr .
    DATA vat_kwert TYPE kwert .
    DATA l_calculation_type TYPE komv-ksteu VALUE 'B' ##NO_TEXT.
    DATA lw_comm_head_i TYPE komk .
    DATA lw_comm_item_i TYPE komp .
    DATA lw_comm_head_e TYPE komk .
    DATA lw_comm_item_e TYPE komp .
    DATA gt_read_text TYPE gt_read_text1 .
    DATA zebeln TYPE ebeln .
    DATA gw_eket TYPE eket .
    DATA lang TYPE thead-tdspras .
    DATA gw_read_text TYPE tline .
    DATA:
      zhouse_street(70) TYPE c .
    DATA ztotal_tax TYPE komv-kwert .
    DATA ztotal_tax1 TYPE komv-kwert .
    DATA lv_pf TYPE konv-kwert .
    DATA lv_pf1 TYPE konv-kwert .
    DATA:
      gt_po_end_msg TYPE STANDARD TABLE OF tline .
    DATA gw_po_end_msg TYPE tline .
    DATA:
      gt_po_header TYPE STANDARD TABLE OF tline .
    DATA gw_po_header TYPE tline .
    DATA:
      lt_po_total TYPE STANDARD TABLE OF zstru_po_table .
    DATA lw_po_total TYPE zstru_po_table .
    DATA:
      zlines(10) TYPE c .
    DATA zlang1 TYPE thead-tdspras .
    DATA:
      lv_count TYPE c LENGTH 1 VALUE 0 ##NO_TEXT.
    DATA d_bill TYPE REF TO data .
    DATA:
      zname(132) TYPE c .
    DATA lv_cdobjectv TYPE cdobjectv .
    DATA lv_cdobjectv1 TYPE cdobjectv .
    DATA lv_cdtabkey TYPE cdtabkey .
    DATA zser_total TYPE konv-kwert .
    DATA jser2_kwert TYPE kwert .
    DATA jser2_kbetr TYPE kbetr .
    DATA zsbc_kwert TYPE kwert .
    DATA zsbc_kbetr TYPE kbetr .
    DATA zv_discount TYPE kwert .
    DATA lv_tot_discount TYPE konv-kwert .
    DATA lv_unit_price TYPE konv-kwert .
    DATA lw_taxim TYPE mlan-taxim .
    DATA jiug_kwert TYPE kwert .
    DATA ztotal_gsttax TYPE komv-kwert .

    METHODS get_final
      IMPORTING
        !ebeln          TYPE ebeln
        !kschl          TYPE kschl OPTIONAL
      EXPORTING
        !gt_final       TYPE gt_header1
      CHANGING
        !cv_output_type TYPE char01
        !cv_print_type  TYPE rsmpe-func .
    METHODS read_text
      IMPORTING
        !zid           TYPE tdid
        !zname         TYPE thead-tdname
        !zobject       TYPE thead-tdobject
      EXPORTING
        !gt_read_text1 TYPE gt_read_text1 .
    METHODS tax_cond
      IMPORTING
        !zkschl     TYPE kscha
        !zkrech     TYPE krech
        !zitab      TYPE it_komv2
        !zcount     TYPE char3
      EXPORTING
        !kwert      TYPE kwert
        !kbetr      TYPE kbetr
        !chng_count TYPE char3 .
    METHODS tax_cond1
      IMPORTING
        !zkschl TYPE kscha
        !zitab  TYPE it_komv2
      EXPORTING
        !kwert  TYPE kwert
        !kbetr  TYPE kbetr .
    METHODS read_text1
      IMPORTING
        !zid           TYPE tdid
        !zname         TYPE thead-tdname
        !zobject       TYPE thead-tdobject
        !zlang         TYPE thead-tdspras
      EXPORTING
        !gt_read_text1 TYPE gt_read_text1 .
    METHODS ship_to
      IMPORTING
        !gw_adrc      TYPE adrc
      EXPORTING
        !gw_bill_ship TYPE ty_bill_ship
        !gt_ship_addr TYPE zread_text .
    METHODS send_email
      IMPORTING
        VALUE(document_data) TYPE sodocchgi1 OPTIONAL
        VALUE(put_in_outbox) TYPE sonv-flag OPTIONAL
        VALUE(commit_work)   TYPE sonv-flag OPTIONAL
        VALUE(packing_list)  TYPE gt_sopcklsti1 OPTIONAL
        VALUE(object_header) TYPE gt_solisti1 OPTIONAL
        VALUE(contents_bin)  TYPE gt_solisti1 OPTIONAL
        !contents_txt        TYPE gt_solisti1 OPTIONAL
        !contents_hex        TYPE gt_solix OPTIONAL
        !object_para         TYPE gt_soparai1 OPTIONAL
        !object_parb         TYPE gt_soparbi1 OPTIONAL
        !receivers           TYPE gt_somlreci1 OPTIONAL
        !sender              TYPE soextreci1-receiver
        !sender_address_type TYPE soextreci1-adr_typ OPTIONAL
      EXPORTING
        !sent_to_all         TYPE sonv-flag
        !new_object_id       TYPE sofolenti1-object_id
        !sender_id           TYPE soudk .
protected section.
private section.

  methods GET_DISCOUNT
    importing
      !ZV_POITEM type EBELP
      !ZKONV type IT_KONV
    exporting
      !KWERT type KWERT .
ENDCLASS.



CLASS ZCL_R10031_APPM_SMARTFORM IMPLEMENTATION.


  METHOD get_discount.

    DATA lv_kwert TYPE kwert.

    CLEAR lv_kwert.
    SELECT * INTO TABLE @DATA(lt_zmmfld) FROM zmmfld
                                         WHERE key1 EQ 'R10031'
                                           AND key2 EQ 'DISC'.


    LOOP AT lt_zmmfld INTO DATA(lw_zmmfld) WHERE value1 IS NOT INITIAL.

      READ TABLE zkonv INTO DATA(lw_lkonv)
                WITH KEY kposn = zv_poitem
                         kschl = lw_zmmfld-value1+0(4).

      IF sy-subrc EQ 0.
        lv_kwert = lv_kwert + lw_lkonv-kwert.
      ENDIF.

    ENDLOOP.

    kwert = lv_kwert.

  ENDMETHOD.


METHOD get_final.
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* Punjaala A          05/25/2017 CMS 31821 APPM India GST Changes      *
*                                applied due to new GST Law            *
* Punjaala A          07/05/2017 CMS 32224 APPM India GST GSTIN        *
*                                number printing changes in smartform  *
* ==================================================================== *


  CONSTANTS:lc_cama(1) TYPE c VALUE ', ',                   "CMS27120
            lc_cama2(2) TYPE c VALUE ',,',                  "CMS27120
            lc_hyphen(1) TYPE c VALUE '-'.                  "CMS27120

  FIELD-SYMBOLS : <fs_bill_ship> TYPE ANY TABLE,
                  <fw_bill_ship> TYPE any,
                  <fi_bill_ship> TYPE any,
                  <fs_serv_mas1> TYPE ty_esll.

  FIELD-SYMBOLS : <fs_b1> TYPE ANY TABLE,
                  <fw_b1> TYPE any,
                  <fc_bl> TYPE any.

  DATA:lw_zmmmail_porg TYPE zmmmail_porg,
       lv_sname1 TYPE adrc-name1,
       lv_ztotal_value(15) TYPE p DECIMALS 2,               "CMS27120
       lv_street(61) TYPE c,                                "CMS27120
       lv_suppl1(41) TYPE c,                                "CMS27120
       lv_suppl2(41) TYPE c,                                "CMS27120
       lw_tserv_mas TYPE zmm_r10031_smartform_ser_mas,      "CMS27120
       lv_tabix TYPE sy-tabix.                              "CMS27120

* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|START
  DATA: lv_gstrel_flag(1)  TYPE c,
        lv_gstin           TYPE J_1BBRANCH-gstin.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|END

  DATA lt_nast TYPE STANDARD TABLE OF nast.                 "CMS27120

  SELECT SINGLE * FROM ekko INTO zpoheader WHERE ebeln = ebeln.

*** get the line items which are not deleted. LOEKZ NE 'L'.
  SELECT * FROM ekpo INTO TABLE zpoitem WHERE ebeln = ebeln
                                          AND loekz <> 'L'.
***  PURCHASE ORDER TITLE.
  l_objectid = zpoheader-ebeln.


*->Begin of Change

*-Get NAST entry to validate the N:New PO Output/ C:Change PO Output
*- R:Reprint Output
  CLEAR lt_nast.
  SELECT * FROM nast INTO TABLE lt_nast
          WHERE kappl  = 'EF'       " Application for message conditions
            AND objky  = l_objectid " Object key
            AND kschl   = kschl.    " Message type

  IF cv_output_type IS INITIAL AND cv_print_type IS INITIAL.

*    SELECT * FROM nast INTO TABLE lt_nast
*    WHERE kappl  = 'EF'       AND  " Application for message conditions
*          objky  = l_objectid AND  " Object key
*          kschl   = kschl.          " Message type  "CMS27120
*        vstat  = '1'        AND           " Processing status of message "CMS27120
*        aende  = 'X'.

    CLEAR lw_nast.
    READ TABLE lt_nast INTO lw_nast WITH KEY objky = l_objectid
                                             vstat = '0'.

    IF lw_nast-aende EQ 'X'.
      cv_output_type ='C'.
    ELSE.
      cv_output_type ='N'.
    ENDIF.
  ENDIF.

*  IF sy-subrc <> 0.
  CASE cv_output_type.

    WHEN 'N'.
      gw_header-zpo_heading      =  text-001. " 'Purchase Order'.
gw_header-zpo_heading_cont =  text-002. "'Purchase Order ( Continued )'.
    WHEN 'C'.
      gw_header-zpo_heading      = text-003. " 'Changed Purchase Order'.
gw_header-zpo_heading_cont = text-004. " 'Changed Purchase Order ( Continued )'.

    WHEN 'R'.
      gw_header-zpo_heading      =  text-001. " 'Purchase Order'.
gw_header-zpo_heading_cont =  text-002. "'Purchase Order ( Continued )'.
  ENDCASE.

  IF cv_print_type EQ 'TOUT'.
    CONCATENATE gw_header-zpo_heading text-040
    INTO gw_header-zpo_heading SEPARATED BY lc_hyphen.
  ENDIF.

*    IF lv_print_option IS NOT INITIAL.
*      CONCATENATE text-001 lv_print_option INTO gw_header-zpo_heading
*      SEPARATED BY lc_hyphen.
*    ELSE.
*      gw_header-zpo_heading      =  text-001. " 'Purchase Order'.
*    ENDIF.
*
*gw_header-zpo_heading_cont =  text-002. "'Purchase Order ( Continued )'.
*
*  ELSE.
*
**** Change Exists.
*    gw_header-zpo_heading      = text-003. " 'Changed Purchase Order'.
*gw_header-zpo_heading_cont = text-004. " 'Changed Purchase Order ( Continued )'.

*  ENDIF.
*-<End of Changes CMS27120

********************************* PO Number ***********************
  gw_header-zpo_number = zpoheader-ebeln.
  gw_header-zpo_lifnr  = zpoheader-lifnr.
  gw_header-zs_waers = zpoheader-waers.                     "CMS29711

***********************  Supplier data ***************************
** LIFNR Master (General Section)
  SELECT SINGLE lifnr     " Account Number of LIFNR
                name1                                       " Name 1
                ort01     " City
                ort02     " District
                pstlz     " Postal Code
                regio     " Region (State, Province, County)
                stras     " House number and street
                adrnr     " ADDRESS NUMBER
                stceg     " VAT registration number
                land1     " Country Key
           FROM lfa1
           INTO wa_lfa1
          WHERE lifnr = zpoheader-lifnr.

  gw_header-zs_vlands = wa_lfa1-land1.                      "CMS29711

  SELECT addrnumber    " ADDRESS NUMBER
         date_from     " Date valid from
         nation        " International address version ID
         name1         " Name 1
         name2         " Name 2
         city1         " City
         city2         " District
         post_code1    " City postal code
         post_code2    "CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
         po_box        "CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
         street        " Street
         str_suppl1                                         " Street 2
         str_suppl2                                         " Street 3
         str_suppl3                                         " Street 4
         country       " Country Key
         tel_number    " TELF1 NUMBER
         fax_number    " FAX
         house_num1    " house number
         FROM adrc
         INTO  wa_adrc
         WHERE addrnumber = wa_lfa1-adrnr.

  ENDSELECT.

  MOVE-CORRESPONDING wa_adrc TO gw_supplier .

** country name
  SELECT SINGLE spras        " sprasage Key
                land1        " Country Key
                landx50      " Country Name
           FROM t005t
          INTO  wa_t005t
          WHERE spras = zpoheader-spras
          AND   land1 = wa_lfa1-land1.



  CLEAR : zs_supp_street1, zs_supp_name1.

*->Begin of Change CMS27120
  IF wa_adrc-str_suppl1 IS NOT INITIAL.
    CONCATENATE wa_adrc-str_suppl1 lc_cama INTO lv_suppl1.
  ENDIF.

  IF wa_adrc-str_suppl2 IS NOT INITIAL.
    CONCATENATE wa_adrc-str_suppl2 lc_cama INTO lv_suppl2.
  ENDIF.

  IF wa_adrc-street IS NOT INITIAL.
    CONCATENATE wa_adrc-street lc_cama INTO lv_street.
*-->CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
  ELSEIF wa_adrc-po_box IS NOT INITIAL.
    CONCATENATE 'PO Box:' wa_adrc-po_box lc_cama INTO lv_street.
    If wa_adrc-post_code2 IS NOT INITIAL.
      gw_supplier-post_code1 = wa_adrc-post_code2.
    ENDIF.
  ELSEIF wa_adrc-po_box IS INITIAL.
    MOVE 'No Street or PO Box available,' TO lv_street.
*<--CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
  ENDIF.


  CONCATENATE lv_suppl1 lv_suppl2 lv_street
              wa_adrc-str_suppl3 INTO zs_supp_street1
              SEPARATED BY space.

  SHIFT zs_supp_street1 LEFT DELETING LEADING space.
*-<End of Change CMS27120

  CONCATENATE wa_adrc-name1 wa_adrc-name2
         INTO zs_supp_name1 SEPARATED BY space.             "CMS27120

  gw_supplier-landx50 = wa_t005t-landx50.

** LIFNR master record purchasing organization data
  SELECT SINGLE verkf  " Responsible salesperson at LIFNR
                telf1  " LIFNR's TELF1 number"
                lifnr  " LIFNR Account Number
                ekorg  " Purchasing Organization
                FROM lfm1
                INTO wa_lfm1
                WHERE lifnr = zpoheader-lifnr
                AND ekorg	  = zpoheader-ekorg.

*** ATTN
  IF zpoheader-verkf IS INITIAL.
    gw_supplier-verkf = wa_lfm1-verkf.
  ELSE.
    gw_supplier-verkf = zpoheader-verkf.
  ENDIF.

*** Phone Number
  IF zpoheader-telf1 IS INITIAL.
    gw_supplier-telf1 = wa_lfm1-telf1.
  ELSE.
    gw_supplier-telf1 = zpoheader-telf1.
  ENDIF.


*->Begin Of Change CMS27172
  CLEAR lw_zmmmail_porg.
  SELECT SINGLE * INTO lw_zmmmail_porg FROM zmmmail_porg
                                   WHERE purchase_org EQ zpoheader-ekorg
                                     AND active EQ 'X'.

  IF lw_zmmmail_porg-active EQ 'X'.

    SELECT SINGLE alternate_vendor_email INTO gw_supplier-smtp_addr
    FROM zmmalt_ven_mail WHERE purchase_org EQ zpoheader-ekorg
                           AND vendor_number EQ zpoheader-lifnr.

    IF gw_supplier-smtp_addr IS INITIAL.
*->End Of Change   CMS27172
** E-Mail Addresses (Business Address Services)
      SELECT SINGLE addrnumber      " Address number
                    persnumber      " Person number
                    date_from       " Date valid from
                    consnumber      " Sequence number
                    smtp_addr       " E-Mail Address
                    INTO wa_adr6
                    FROM adr6
                    WHERE addrnumber = wa_lfa1-adrnr.
*** E-Mail
      IF sy-subrc EQ 0.
        gw_supplier-smtp_addr = wa_adr6-smtp_addr.
      ENDIF.
    ENDIF.

*->Begin Of Change CMS27172
  ELSE.

** E-Mail Addresses (Business Address Services)
    SELECT SINGLE addrnumber      " Address number
                  persnumber      " Person number
                  date_from       " Date valid from
                  consnumber      " Sequence number
                  smtp_addr       " E-Mail Address
                  INTO wa_adr6
                  FROM adr6
                  WHERE addrnumber = wa_lfa1-adrnr.
*** E-Mail
    IF sy-subrc EQ 0.
      gw_supplier-smtp_addr = wa_adr6-smtp_addr.
    ENDIF.

  ENDIF.
*-<End Of Change CMS27172

  APPEND gw_supplier TO gt_supplier.

  gw_header-zs_name1        =    gw_supplier-name1.      " NAME 1
  gw_header-zs_name2        =    gw_supplier-name2.      " NAME 2
  gw_header-zs_str_suppl1   =    gw_supplier-str_suppl1. " Street 2
  gw_header-zs_str_suppl2   =    gw_supplier-str_suppl2. " Street 3
gw_header-zs_str_suppl3   =    gw_supplier-str_suppl3. " Street 4 CMS27120
  gw_header-zs_street       =    gw_supplier-street.     "  Street
  gw_header-zs_city1        =    gw_supplier-city1.      " City
  gw_header-zs_post_code1   =    gw_supplier-post_code1. " postal code
gw_header-zs_landx50      =    gw_supplier-landx50.    " Country Name (Max. 50 Characters)
gw_header-zs_verkf        =    gw_supplier-verkf .     " Responsible Salesperson at LIFNR's Office
gw_header-zs_telf1        =    gw_supplier-telf1.      " LIFNR's TELF1 Number
  gw_header-zs_smtp_addr    =    gw_supplier-smtp_addr.  " Email
  gw_header-zs_supp_street  =    zs_supp_street1.
  gw_header-zs_supp_name    =    zs_supp_name1.
***************************** PO date *************************
  SET COUNTRY wa_lfa1-land1.

*->Begin of Change CMS27120
  CALL FUNCTION 'CONVERSION_EXIT_IDATE_OUTPUT'
    EXPORTING
      input         = zpoheader-bedat
   IMPORTING
     output         = zdate.

  IF zdate+0(1) CA sy-abcde.
    CONCATENATE zdate+0(3) zdate+3(2) zdate+5(4) INTO zdate
                SEPARATED BY space.
  ELSE.
    CONCATENATE zdate+0(2) zdate+2(3) zdate+5(4) INTO zdate
                SEPARATED BY space.
  ENDIF.

*  SELECT SINGLE * FROM t005x INTO wa_t005x
*           WHERE land = wa_lfa1-land1.
*
*  CALL FUNCTION 'DD_DOMA_GET'
*    EXPORTING
*      domain_name   = 'XUDATFM'
*      langu         = sy-langu " default  SY-LANGU
*      withtext      = 'X'
*    TABLES
*      dd07v_tab_a   = gt_dd07v
*      dd07v_tab_n   = gt_dd07v1
*    EXCEPTIONS
*      illegal_value = 1
*      op_failure    = 2
*      OTHERS        = 3.
*
*  IF gt_dd07v IS NOT INITIAL.
*    READ TABLE gt_dd07v INTO gw_dd07v
*           WITH KEY domvalue_l = wa_t005x-datfm.
*    IF sy-subrc <> 0.
*
*    ENDIF.
*  ENDIF.

  gw_header-zpo_date = zdate.
*  gw_header-zdate_format = gw_dd07v-ddtext.  "CMS27012
*->End of Change CMS27120


  SELECT * FROM t005t INTO TABLE lt_t005t.

  SELECT * FROM t001w INTO TABLE gt_t001w.

  SELECT * FROM twlad INTO TABLE gt_twlad.

  SELECT * FROM t001l INTO TABLE gt_t001l.

SELECT SINGLE * FROM ekko INTO lw_ekko WHERE ebeln = zpoheader-ebeln. "CMS27120

  SELECT * FROM konv INTO TABLE lt_konv WHERE knumv = lw_ekko-knumv.

  IF zpoitem[] IS NOT INITIAL.                              "CMS27120
    SELECT  packno  "Package number
            introw  "Line Number CMS27120
            extrow  "Line Number CMS27120
               del  "Deletion Indicator CMS27120
            srvpos  " Activity Number
            ktext1  " Short Text
            menge   " Quantity with Sign
            meins   " Base Unit of Measure
            peinh   " Price Unit
            netwr   " Net Value of Item
            sub_packno
            tbtwr   " Gross Price
            INTO CORRESPONDING FIELDS OF TABLE lt_serv_mas2
            FROM esll
            FOR ALL ENTRIES IN zpoitem
            WHERE packno EQ zpoitem-packno
              AND    del EQ space.
    IF sy-subrc EQ 0.
      SELECT  packno  "Package number
              introw  "Line Number CMS27120
              extrow  "Line Number CMS27120
                 del  "Deletion Indicator CMS27120
              srvpos  " Activity Number
              ktext1  " Short Text
              menge   " Quantity with Sign
              meins   " Base Unit of Measure
              peinh   " Price Unit
              netwr   " Net Value of Item
              sub_packno
              tbtwr   " Gross Price
              INTO CORRESPONDING FIELDS OF TABLE lt_serv_mas1
              FROM esll
              FOR ALL ENTRIES IN lt_serv_mas2
              WHERE packno EQ lt_serv_mas2-sub_packno
                AND    del EQ space.
    ENDIF.

* CMS31821|ChangedBy:APUNJAA|ChangedOn:06082017|START
* Read the Tax classification based on activity number
    SELECT asnum taxim
         INTO TABLE it_asmd
          FROM asmd
         FOR ALL ENTRIES IN lt_serv_mas1
           WHERE asnum = lt_serv_mas1-srvpos.

    CLEAR wa_asmd.

* Read only the first line item to determine the Tax classfication of service activity.
* Always business maintains and ensures services under same tax category
    LOOP AT it_asmd INTO wa_asmd.
      EXIT.
    ENDLOOP.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:06082017|END

  ENDIF.                                                    "CMS27120

  REFRESH gt_bill_ship.

  SORT lt_nast BY kappl objky kschl spras datvr DESCENDING
                                          uhrvr DESCENDING.
  DELETE ADJACENT DUPLICATES FROM lt_nast COMPARING
                                    kappl objky kschl spras.

*->Begin of CMS29471/MAIELY for SBC
  READ TABLE zpoitem INTO lw_poitem WITH KEY pstyp = '9'.

  IF sy-subrc EQ 0 AND wa_lfa1-land1 EQ 'IN'.
    gw_header-zs_sbc = 'X'.
  ENDIF.
*-<End of CMS29471/MAIELY for SBC

  LOOP AT zpoitem INTO lw_poitem.

*****************************  Ship to address **************

    lv_cdobjectv = zpoheader-ebeln.
    lv_cdobjectv1 = lw_poitem-packno.

    IF cv_output_type EQ 'C'.                               "CMS27120

      CLEAR lw_nast.
      READ TABLE lt_nast INTO lw_nast WITH KEY objky = zpoheader-ebeln
                                               vstat = '1'.

*-Check Line item Changes/Service Number Changes
      REFRESH lt_cdhdr.
      SELECT *  FROM cdhdr INTO TABLE lt_cdhdr
                       WHERE ( objectclas EQ 'EINKBELEG'
                            OR objectclas EQ 'MM_SERVICE' )
                         AND ( objectid   EQ lv_cdobjectv
                            OR objectid   EQ lv_cdobjectv1 )
*-->CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
                    AND   udate      GT lw_nast-datvr.  " Processing date
*                   AND   utime      GT lw_nast-uhrvr. " Processing time
      IF sy-subrc <> 0.
      SELECT *  FROM cdhdr INTO TABLE lt_cdhdr
                       WHERE ( objectclas EQ 'EINKBELEG'
                            OR objectclas EQ 'MM_SERVICE' )
                         AND ( objectid   EQ lv_cdobjectv
                            OR objectid   EQ lv_cdobjectv1 )
                    AND   udate      EQ lw_nast-datvr  " Processing date
                    AND   utime      GE lw_nast-uhrvr. " Processing time
      ENDIF.

*     IF sy-subrc = 0.
      IF lt_cdhdr[] IS NOT INITIAL.
*<--CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
        SELECT * FROM cdpos INTO TABLE lt_cdpos
        FOR ALL ENTRIES IN lt_cdhdr
                        WHERE   objectclas EQ lt_cdhdr-objectclas
                          AND   objectid   EQ lt_cdhdr-objectid
                          AND   changenr   EQ lt_cdhdr-changenr
                          AND ( tabname    EQ 'EKPO'
                             OR tabname    EQ 'ESLL'        "CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
                             OR tabname    EQ 'EINKBELEG' )."CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI

        LOOP AT lt_cdpos INTO lw_cdpos.
*------->CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
          IF lw_cdhdr-objectclas NE 'MM_SERVICE' AND
             ( lw_cdpos-tabname EQ 'EKPO' OR lw_cdpos-tabname EQ 'ESLL' ).
*<-------CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
            CHECK:lw_cdpos-tabkey+3(10) EQ lw_poitem-ebeln,
                  lw_cdpos-tabkey+13(6) EQ lw_poitem-ebelp.
          ENDIF.
*-------->CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
          IF lw_cdhdr-objectclas NE 'MM_SERVICE' AND
             ( lw_cdpos-tabname EQ 'EINKBELEG' ).
            CHECK:lw_cdpos-tabkey+0(10) EQ lw_poitem-ebeln,
                  lw_cdpos-tabkey+10(6) EQ lw_poitem-ebelp.
          ENDIF.
*<--------CMS30340 E0VK9A0LBZ 07/19/2016 SMITHAI
          gw_item-zstatus = 'X'.
          gw_item-zstatus_desc = 'CHANGED Purchase Order Line'(st2).
          gw_bill_ship-zstatus = 'X'.
          EXIT.

        ENDLOOP.

*->Begin Of change/CMS29471/If Output type is 'C' then check status eq 'X'
        IF cv_output_type EQ 'C'.
          CHECK gw_item-zstatus EQ 'X'.
        ENDIF.
*-<End Of change/CMS29471/If Output type is 'C' then check status eq 'X'

*-delete the service numbers which does not have a change
        LOOP AT lt_serv_mas1 ASSIGNING <fs_serv_mas1>.

          lv_tabix = sy-tabix.

        CONCATENATE sy-mandt <fs_serv_mas1>-packno <fs_serv_mas1>-introw
               INTO lv_cdtabkey.

          READ TABLE lt_cdpos INTO lw_cdpos WITH KEY
                                         objectid = lv_cdobjectv1
                                         tabname = 'ESLL'
                                         tabkey = lv_cdtabkey.

          IF sy-subrc NE 0.
            <fs_serv_mas1>-zchange = 'N'.
          ENDIF.

        ENDLOOP.

      ENDIF.

    ENDIF.                                                  "CMS27120

    CLEAR : zname_text.

    CONCATENATE text-005 zpoheader-ekorg INTO  zname_text
    SEPARATED BY '-'.

    REFRESH : gt_read_text.
    id      = text-031. " 'ST'..
    name    = zname_text.
    object  = text-032.

    REFRESH gt_read_text.

    CALL METHOD me->read_text
      EXPORTING
        zid           = id      " Text ID
        zname         = name    " TDIC text name
        zobject       = object  " Texts: Application Object
      IMPORTING
        gt_read_text1 = gt_read_text.

    READ TABLE gt_read_text INTO gw_read_text INDEX 1.

    IF sy-subrc = 0.
      gw_bill_ship-comp_name = gw_read_text-tdline.
    ENDIF.

*    READ TABLE gt_t001w INTO gw_t001w WITH KEY werks = lw_poitem-werks. "CMS27120

*    gw_bill_ship-name1   = gw_t001w-name1.                              "CMS27120
    gw_bill_ship-name1   = gw_adrc-name1.                   "CMS27120

    IF  sy-subrc = 0.
     READ TABLE gt_t001l INTO gw_t001l WITH  KEY werks = lw_poitem-werks
                                                lgort = lw_poitem-lgort.

      IF sy-subrc = 0.
*CONCATENATE  text-006 gw_t001w-name1 text-007 gw_t001l-lgort '-' "Ship to address for & Location  "CMS27120
*gw_t001l-lgobe text-039 INTO ztext SEPARATED BY space.                                            "CMS27120
        ztext = text-006.                                   "CMS27120

        gw_bill_ship-zheading   = ztext.

      ENDIF.

    ENDIF.

    IF lw_poitem-adrnr IS NOT INITIAL.
      CLEAR : gw_adrc.
SELECT SINGLE * FROM adrc INTO gw_adrc WHERE addrnumber = lw_poitem-adrnr.

      IF  sy-subrc = 0.

        REFRESH gt_ship_addr.                               "CMS27120

        CALL METHOD me->ship_to
          EXPORTING
            gw_adrc      = gw_adrc
          IMPORTING
            gw_bill_ship    = gw_bill_ship                  "CMS27120
            gt_ship_addr    = gt_ship_addr.                 "CMS27120

        CLEAR : gw_adrc.

      ENDIF.

    ELSEIF lw_poitem-adrn2 IS NOT INITIAL.
      CLEAR : gw_adrc.

SELECT SINGLE * FROM adrc INTO gw_adrc WHERE addrnumber = lw_poitem-adrn2.

      IF  sy-subrc = 0.

        REFRESH gt_ship_addr.                               "CMS27120

        CALL METHOD me->ship_to
          EXPORTING
            gw_adrc      = gw_adrc
          IMPORTING
            gw_bill_ship    = gw_bill_ship                  "CMS27120
            gt_ship_addr    = gt_ship_addr.                 "CMS27120

        CLEAR : gw_adrc.
      ENDIF.

    ELSEIF lw_poitem-werks IS NOT INITIAL.

*** Plant or storage Address.

      READ TABLE gt_twlad INTO gw_twlad WITH KEY werks = lw_poitem-werks
                                                lgort = lw_poitem-lgort.

      IF sy-subrc = 0.
*** Storage Location
        CLEAR : gw_adrc.
SELECT SINGLE * FROM adrc INTO gw_adrc WHERE addrnumber = gw_twlad-adrnr.

        IF sy-subrc = 0.
*
*          CALL METHOD me->ship_to
*            EXPORTING
*              gw_adrc      = gw_adrc
*            IMPORTING
*              gw_bill_ship = gw_bill_ship
*              gw_ship_to_addr = gw_ship_to_addr.
*

          REFRESH gt_ship_addr.                             "CMS27120

          CALL METHOD me->ship_to
            EXPORTING
       gw_adrc      =  gw_adrc   " Addresses (Business Address Services)
     IMPORTING
       gw_bill_ship =  gw_bill_ship
       gt_ship_addr =  gt_ship_addr.   " Ship To Address - Line Item

          CLEAR : gw_adrc.

        ENDIF.

      ELSE.

*** Plant address
     READ TABLE gt_t001w INTO gw_t001w WITH KEY werks = lw_poitem-werks.

        IF  sy-subrc = 0.

          CLEAR : gw_adrc,lv_sname1.                        "CMS27120
SELECT SINGLE * FROM adrc INTO gw_adrc WHERE addrnumber = gw_t001w-adrnr.

          IF  sy-subrc = 0.

            lv_sname1 = gw_adrc-name1.                      "CMS27120

            REFRESH gt_ship_addr.                           "CMS27120

            CALL METHOD me->ship_to
              EXPORTING
                gw_adrc      = gw_adrc
              IMPORTING
                gw_bill_ship = gw_bill_ship
                gt_ship_addr = gt_ship_addr.

            CLEAR : gw_adrc.

          ENDIF.
        ENDIF.
      ENDIF.

    ENDIF.

    APPEND gw_bill_ship TO  gt_bill_ship.
    APPEND gw_bill_ship TO  gt_bill_ship1.

    gw_item-zship_to_addr = gt_bill_ship.
    gw_item-zship_addr    = gt_ship_addr.                   "CMS27120

    CLEAR : gw_bill_ship.
    REFRESH gt_bill_ship.

*********************************************************************************
***********************************  Item Details ******************************
** MATNR
    gw_item-zmaterial = lw_poitem-matnr.
** WERKS
    gw_item-zplant = lw_poitem-werks.
** Storage Location
    gw_item-zstge_loc = lw_poitem-lgort.
** Purchase Order                           "CMS27120
    gw_item-zpo_number = lw_poitem-ebeln.                   "CMS27120
** Item
    gw_item-zitem = lw_poitem-ebelp.
** Short desctiption
    gw_item-zshort_text = lw_poitem-txz01.

** Package Number
    gw_item-zpackno = lw_poitem-packno.                     "CMS27120

    IF lw_poitem-pstyp <> 9.

** Quantity
      IF lw_poitem-menge IS NOT INITIAL.
        gw_item-zquantity = lw_poitem-menge.
      ENDIF.

** UoM
      IF lw_poitem-meins IS NOT INITIAL.
        gw_item-zuom  =  lw_poitem-meins.
      ENDIF.

** Unit Price
      CLEAR : lw_konv.
      READ TABLE lt_konv INTO lw_konv  WITH KEY kposn = lw_poitem-ebelp
                                                kschl = 'PBXX'.

      IF lw_konv-kbetr IS INITIAL.
        CLEAR : lw_konv.
       READ TABLE lt_konv INTO lw_konv  WITH KEY kposn = lw_poitem-ebelp
                                                 kschl = 'PB00'.
        IF sy-subrc = 0.

      IF lw_konv-kbetr IS NOT INITIAL AND  lw_konv-kpein IS NOT INITIAL.
            gw_item-zunit_price = lw_konv-kbetr / lw_konv-kpein.
          ENDIF.

        ENDIF.

      ELSE .

      IF lw_konv-kbetr IS NOT INITIAL AND  lw_konv-kpein IS NOT INITIAL.
          gw_item-zunit_price = lw_konv-kbetr / lw_konv-kpein.
        ENDIF.

      ENDIF.

** Total Value
      CLEAR : lw_konv.

      READ TABLE lt_konv INTO lw_konv  WITH KEY knumv = zpoheader-knumv
                                                kposn = lw_poitem-ebelp
                                                kschl = 'PBXX'.
      IF sy-subrc = 0.
        gw_item-ztotal_value    =  lw_konv-kwert.
      ENDIF.

      READ TABLE lt_konv INTO lw_konv  WITH KEY knumv = zpoheader-knumv
                                                kposn = lw_poitem-ebelp
                                                kschl = 'PB00'.
      IF sy-subrc = 0.
        gw_item-ztotal_value    =  lw_konv-kwert.
      ENDIF.
    ENDIF.

** Total Basic Value
    IF lw_konv-kwert IS NOT INITIAL.

      lt_total_basic = lw_konv-kwert.

      lt_total_basic1 = lt_total_basic1 + lt_total_basic.

      CLEAR : lt_total_basic.

    ENDIF.

** Delivery date
    SELECT SINGLE * FROM eket INTO gw_eket WHERE ebeln = lw_poitem-ebeln
                                            AND ebelp = lw_poitem-ebelp.

    IF sy-subrc = 0.

*->Begin of Change CMS27120
      SET COUNTRY wa_lfa1-land1.
*      WRITE gw_eket-eindt TO gw_item-zdelivery.
*---->CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
*-----Use GR Delivery Date if following condition is satisfied.
      SELECT SINGLE value1 from zmmfld into @data(lv_value1) where key1 = 'R10031' AND
                                                                   key2 = 'LEWED'  AND
                                                                   key3 = 'EKORG'  AND
                                                                 value1 = @zpoheader-ekorg.
      If sy-subrc = 0 AND lw_poitem-lewed IS NOT INITIAL.
        gw_eket-eindt = lw_poitem-lewed.
      Endif.
*<----CMS 29744 E0VK9A0IPA 01/29/2016 SMITHAI
      CALL FUNCTION 'CONVERSION_EXIT_IDATE_OUTPUT'
        EXPORTING
           input         = gw_eket-eindt
        IMPORTING
           output        = gw_item-zdelivery.

      IF gw_item-zdelivery+0(1) CA sy-abcde.
        CONCATENATE gw_item-zdelivery+0(3) gw_item-zdelivery+3(2)
                    gw_item-zdelivery+5(4) INTO gw_item-zdelivery
                    SEPARATED BY space.
      ELSE.
        CONCATENATE gw_item-zdelivery+0(2) gw_item-zdelivery+2(3)
                    gw_item-zdelivery+5(4) INTO gw_item-zdelivery
                    SEPARATED BY space.
      ENDIF.
*->End of Change CMS27120

    ENDIF.

** PO ITEM TEXT
*    IF lw_poitem-matnr IS NOT INITIAL.             "CMS27120/MAIELY    "CMS 30076

      CLEAR : zname_text.
      CONCATENATE   zpoheader-ebeln lw_poitem-ebelp INTO  zname_text.

*->Begin of comment/CMS27120/MAIELY
      id      = 'F03'.
      name    = zname_text.
      object  = 'EKPO'.
      zlang1 = zpoheader-spras.

      REFRESH gt_read_text .

      CALL METHOD me->read_text1
        EXPORTING
          zid           = id     " Text ID
          zname         = name     " Name
          zobject       = object    " Texts: Application Object
          zlang         = zlang1
        IMPORTING
          gt_read_text1 = gt_read_text.

      IF gt_read_text IS NOT INITIAL.
        lt_temp_text = gt_read_text.
      ENDIF.

      IF lt_temp_text IS NOT INITIAL.
        DELETE lt_temp_text WHERE tdline EQ space.
        APPEND LINES OF lt_temp_text TO gw_item-zpotextitem.
      ENDIF.
*-<End of comment/CMS27120/MAIELY

      id      = 'F01'.
      name    = zname_text.
      object  = 'EKPO'.
      zlang1 = zpoheader-spras.

      REFRESH gt_read_text .

      CALL METHOD me->read_text1
        EXPORTING
          zid           = id     " Text ID
          zname         = name     " Name
          zobject       = object    " Texts: Application Object
          zlang         = zlang1
        IMPORTING
          gt_read_text1 = gt_read_text.

      IF gt_read_text IS NOT INITIAL.
        lt_temp_text = gt_read_text.
      ELSE.

        CLEAR :  zlang1.
        zlang1 = text-034. " 'EN'..

        REFRESH gt_read_text .

        CALL METHOD me->read_text1
          EXPORTING
            zid           = id     " Text ID
            zname         = name     " Name
            zobject       = object    " Texts: Application Object
            zlang         = zlang1
          IMPORTING
            gt_read_text1 = gt_read_text.

        lt_temp_text = gt_read_text.

      ENDIF.

      IF lt_temp_text IS NOT INITIAL.

*->Begin of change/CMS27120/MAIELY
*      DELETE lt_temp_text WHERE tdline EQ space.
*
*      CREATE DATA : o_data  LIKE lt_temp_text.
*
*      FIELD-SYMBOLS : <fs_text> TYPE ANY TABLE,
*                      <fw_text> TYPE any,
*                      <fc_text> TYPE any.
*
*      ASSIGN o_data->* TO <fs_text>.
*
*      IF  <fs_text> IS ASSIGNED.
*        <fs_text> = lt_temp_text.
*        gw_item-zpotextitem = <fs_text>.
*      ENDIF.
        DELETE lt_temp_text WHERE tdline EQ space.
        APPEND LINES OF lt_temp_text TO gw_item-zpotextitem.
*-<End of change/CMS27120/MAIELY

      ENDIF.

*  ENDIF.                                   "CMS27120/MAIELY       "CMS 30076

*********************************** (P & F) ***********************************
*ZMM_R10031_SMARTFORM_TAX

    CLEAR : zcount,lw_tax.

    CLEAR : lw_konv ,zkwert1,zkbetr1,zkwert2,zkbetr2,zkwert3,zkbetr3,
            zv_pf_kbetr.
** ZPFP
    READ TABLE lt_konv INTO lw_konv  WITH KEY kposn = lw_poitem-ebelp
                                              kschl = 'ZPFP'
                                              krech = 'A'.

IF sy-subrc = 0 AND lw_konv-kwert NE 0 AND lw_konv-kbetr NE 0. "CMS29471
      zcount = zcount + 1 .
  lw_tax-zspec_char        = text-018. " '%'.. " only for A    "CMS29471
      zkwert1 = lw_konv-kwert.
      zkbetr1 = lw_konv-kbetr.
    ENDIF.

** ZPFV
    READ TABLE lt_konv INTO lw_konv  WITH KEY kposn = lw_poitem-ebelp
                                              kschl = 'ZPFV'
                                              krech = 'B'.

IF sy-subrc = 0 AND lw_konv-kwert NE 0 AND lw_konv-kbetr NE 0. "CMS29471
      zcount = zcount + 1 .
 lw_tax-zspec_char        = text-017. " '**'.. " only for A    "CMS29471
      zkwert2 = lw_konv-kwert.
      zkbetr2 = lw_konv-kbetr.
    ENDIF.

** ZPFQ
    READ TABLE lt_konv INTO lw_konv  WITH KEY kposn = lw_poitem-ebelp
                                              kschl = 'ZPFQ'
                                              krech = 'C'.

IF sy-subrc = 0 AND lw_konv-kwert NE 0 AND lw_konv-kbetr NE 0. "CMS29471
      zcount = zcount + 1 .
 lw_tax-zspec_char        = text-017. " '**'.. " only for A    "CMS29471
      zkwert3 = lw_konv-kwert. " not inital
      zkbetr3 = lw_konv-kbetr.
    ENDIF.

    CASE zcount.

      WHEN 1.
*        CLEAR :lw_tax.                           "CMS27120
        lw_tax-ztax_description = text-008.

*->Begin of comment CMS29471
*        IF  lw_konv-krech = 'A' AND lw_konv-kwert GT 0.
*          lw_tax-zspec_char        = text-018. " '%'.. " only for A
*        ELSE.
*          lw_tax-zspec_char        = text-017. " '**'.. " only for A
*        ENDIF.
*-<End of comment CMS29471

*->Begin of Change CMS29471/MAIELY/12212015
*        IF  lw_konv-krech = 'A' .
*          lw_tax-zunit_pric        = lw_konv-kbetr / 10.
*        ENDIF.
        IF zkbetr1 IS NOT INITIAL.
          zv_pf_kbetr = zkbetr1 / 10.
        ELSEIF zkbetr2 IS NOT INITIAL.
          zv_pf_kbetr = zkbetr2 / 10.
        ELSEIF zkbetr3 IS NOT INITIAL.
          zv_pf_kbetr = zkbetr3 / 10.
        ENDIF.

        IF zv_pf_kbetr IS NOT INITIAL.
          lw_tax-zunit_pric = zv_pf_kbetr.
        ENDIF.
*-<End of Change CMS29471/MAIELY/12212015


        lv_ztotal_value = zkwert1 + zkwert2 + zkwert3.      "CMS27120
        lw_tax-ztotal_value = lv_ztotal_value.              "CMS27120

        IF lw_tax-zunit_pric = 0 AND  lw_tax-ztotal_value = 0 .
          CLEAR :  lw_tax.
        ENDIF.

      WHEN 2.
*        CLEAR :lw_tax.                                    "CMS27120
        lw_tax-ztax_description = text-008.

*->Begin of comment CMS29471
*        IF  lw_konv-krech = 'A' AND lw_konv-kwert GT 0.
*          lw_tax-zspec_char        = text-018. " '%'.. " only for A
*        ELSE.
*          lw_tax-zspec_char        = text-017. " '**'.. " only for A
*        ENDIF.
*-<End of comment CMS29471

        lw_tax-zunit_pric        = ' '.

        lv_ztotal_value = zkwert1 + zkwert2 + zkwert3.      "CMS29471
        lw_tax-ztotal_value = lv_ztotal_value.              "CMS29471

      WHEN 3.
*        CLEAR :lw_tax.                                    "CMS27120
        lw_tax-ztax_description  = text-008.
*        lw_tax-zspec_char        = text-017. " '**'..     "CMS29471
        lw_tax-zunit_pric        = ' '.

        lv_ztotal_value = zkwert1 + zkwert2 + zkwert3.      "CMS29471
        lw_tax-ztotal_value = lv_ztotal_value.              "CMS29471

        IF lw_tax-ztotal_value = 0 .
          CLEAR :  lw_tax.
        ENDIF.

      WHEN OTHERS.
*        CLEAR :lw_tax.                                   "CMS27120
*        IF lw_tax-zunit_pric = 0.                        "CMS29471
*          CLEAR : lw_tax-zspec_char.                     "CMS29471
*          lw_tax-zspec_char        = text-017. " '**'..  "CMS29471
*        ENDIF.                                           "CMS29471

    ENDCASE.

    IF lw_tax-ztotal_value <> 0.
      APPEND lw_tax TO lt_tax.
    ENDIF.

**** Total P & F.
    CLEAR : lv_pf.

    lv_pf = zkwert1 + zkwert2 + zkwert3.
    lv_pf1 = lv_pf + lv_pf1.

*********************************** TAX ***********************************
    SELECT SINGLE land1      " Country key
                  kalsm      " Procedure
                  FROM t005
                  INTO CORRESPONDING FIELDS OF wa_t005
                  WHERE land1 = zpoheader-lands.            "CMS29471

    IF sy-subrc EQ 0.

      lw_comm_head_i-aland = zpoheader-lands.               "CMS29471
      lw_comm_head_i-bukrs = zpoheader-bukrs.
      lw_comm_head_i-hwaer = zpoheader-waers.
      lw_comm_head_i-waerk = zpoheader-waers.
      lw_comm_head_i-lifnr = zpoheader-lifnr.
      lw_comm_head_i-kappl = 'TX'.
      lw_comm_head_i-kalsm = wa_t005-kalsm.
      lw_comm_head_i-prsdt = zpoheader-aedat.
      lw_comm_head_i-txjcd = lw_poitem-txjcd.
      lw_comm_head_i-ekorg = zpoheader-ekorg.
      lw_comm_head_i-mwskz = lw_poitem-mwskz.
      lw_comm_item_i-kposn = lw_poitem-ebelp.
      lw_comm_item_i-matnr = lw_poitem-matnr.
      lw_comm_item_i-werks = lw_poitem-werks.
      lw_comm_item_i-matkl = lw_poitem-matkl.
      lw_comm_item_i-meins = lw_poitem-meins.
      lw_comm_item_i-mglme = lw_poitem-menge.
      lw_comm_item_i-kursk_dat = zpoheader-aedat.

      CLEAR lw_ekpo.
      READ TABLE zpoitem INTO lw_ekpo
                         WITH KEY ebeln = zpoheader-ebeln
                                  ebelp = lw_poitem-ebelp.
      IF sy-subrc = 0.
        lw_comm_item_i-netwr = lw_ekpo-netwr.
        lw_comm_item_i-wrbtr = lw_ekpo-netwr.
        lw_comm_item_i-netpr = lw_ekpo-netwr.
        lw_comm_item_i-mtart = lw_ekpo-mtart.
      ENDIF.

      lw_comm_item_i-mwskz = lw_poitem-mwskz.
      lw_comm_item_i-mwsbp = lw_konv-kwert.

      REFRESH it_komv.

      CALL FUNCTION 'PRICING'
        EXPORTING
          calculation_type = 'B'
          comm_head_i      = lw_comm_head_i
          comm_item_i      = lw_comm_item_i
        IMPORTING
          comm_head_e      = lw_comm_head_e
          comm_item_e      = lw_comm_item_e
        TABLES
          tkomv            = it_komv.

    ENDIF.


* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|START
* Below changes are carried out as part of India GST project
* Read each PO Line item Material to determine whether is it relevance to
* India GST based on tax indicator( 0 or 2 for GST) field from the
* Material master level.

* verify the Tax indicator for Material against each line item
*    IF lw_poitem-matnr IS NOT INITIAL.
    CLEAR: lw_tax,ztotal_gsttax.
    SELECT SINGLE taxim INTO lw_taxim
      FROM mlan
       WHERE matnr = lw_poitem-matnr
        AND aland = 'IN'.

* Determine following items
* 1) Not service PO line item, that means material exists at PO line item level
* 2) Tax Indicator either '0' or '2'
    IF  lw_poitem-matnr IS NOT INITIAL AND
       ( lw_taxim EQ '0' OR  lw_taxim EQ '1' OR lw_taxim EQ '2').

      lv_gstrel_flag = 'X'.

* Service PO Changes, No
    ELSEIF lw_poitem-matnr IS INITIAL AND lw_poitem-pstyp = '9'
       AND ( wa_asmd-taxim EQ '0' OR wa_asmd-taxim EQ '1' OR wa_asmd-taxim EQ '2' ) .

      lv_gstrel_flag = 'X'.

    ENDIF.

* If at all purchase order related to GST then go through with below logic
    IF lv_gstrel_flag = 'X'..
      CLEAR lv_gstrel_flag.
      DELETE it_komv WHERE kntyp NE 'D' OR kwert = '0.00'.
      REFRESH:it_t685t.
      SELECT kappl kschl vtext
        INTO TABLE it_t685t
         FROM t685t
          FOR ALL ENTRIES IN it_komv
            WHERE kschl = it_komv-kschl.

      LOOP AT it_komv INTO wa_komv1.
        CLEAR :lw_tax ,lw_t685t.
        READ TABLE it_t685t INTO lw_t685t WITH KEY kschl = wa_komv1-kschl.
        IF sy-subrc EQ 0 AND wa_komv1-kbetr = 0.
          lw_tax-ztax_description =  lw_t685t-vtext.
          lw_tax-zspec_char        = text-017.  "'**'..
        ELSE.
          lw_tax-ztax_description =  lw_t685t-vtext.
          lw_tax-zspec_char        = text-018.  "'%'.
        ENDIF.

        IF wa_komv1-kbetr IS NOT INITIAL.
          lw_tax-zunit_pric        = wa_komv1-kbetr / 10.
        ENDIF.

        IF wa_komv1-kwert IS NOT INITIAL.
          lw_tax-ztotal_value      = wa_komv1-kwert.
        ENDIF.

* Total GST tax value
        ztotal_gsttax = ztotal_gsttax + wa_komv1-kwert.

        APPEND lw_tax TO lt_tax.
        CLEAR lw_tax.
      ENDLOOP.
    ELSE.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|END
**************************Excise Duty**************************

**  Rate Type = %
    CLEAR : count.
    CLEAR : chg_count.
    CLEAR : zkwert, zkbetr.

** JMOP
    zkschl = 'JMOP'.
    zkrech1 = 'A'.
    count   = 0.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jmop_kwert,
            jmop_kbetr.


    jmop_kwert = zkwert.
    jmop_kbetr = zkbetr.

** JAOP
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JAOP'.
    zkrech1 = 'A'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR :  jaop_kwert,
             jaop_kbetr.


    jaop_kwert = zkwert.
    jaop_kbetr = zkbetr.

** JSOP
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JSOP'.
    zkrech1 = 'A'.
    count   = chg_count.

    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jsop_kwert,
            jsop_kbetr.

    jsop_kwert = zkwert.
    jsop_kbetr = zkbetr.

** JMIP
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JMIP'.
    zkrech1 = 'A'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jmip_kwert,
            jmip_kbetr.

    jmip_kwert = zkwert.
    jmip_kbetr = zkbetr.

** JAIP
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JAIP'.
    zkrech1 = 'A'.
    count   = chg_count.

    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR :jaip_kwert,
           jaip_kbetr.

    jaip_kwert = zkwert.
    jaip_kbetr = zkbetr.

** JSIP
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JSIP'.
    zkrech1 = 'A'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jsip_kwert,
            jsip_kbetr.

    jsip_kwert = zkwert.
    jsip_kbetr = zkbetr.

    per_count = chg_count.

**** Rate Type = Qty
** JMOQ
    CLEAR : count.
    CLEAR : chg_count.
    CLEAR : zkwert, zkbetr.

    zkschl = 'JMOQ'.
    zkrech1 = 'C'.
    count   = 0.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jmoq_kwert,
            jmoq_kbetr.

    jmoq_kwert = zkwert.
    jmoq_kbetr = zkbetr.

** JAOQ
    CLEAR : count.
    CLEAR : zkwert, zkbetr.
    zkschl = 'JAOQ'.
    zkrech1 = 'C'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jaoq_kwert,
            jaoq_kbetr.

    jaoq_kwert = zkwert.
    jaoq_kbetr = zkbetr.

** JSOQ
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JSOQ'.
    zkrech1 = 'C'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jsoq_kwert,
            jsoq_kbetr.

    jsoq_kwert = zkwert.
    jsoq_kbetr = zkbetr.

** JMIQ
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JMIQ'.
    zkrech1 = 'C'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR :jmiq_kwert,
           jmiq_kbetr.

    jmiq_kwert = zkwert.
    jmiq_kbetr = zkbetr.

** JAIQ
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JAIQ'.
    zkrech1 = 'C'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR :jaiq_kwert,
           jaiq_kbetr.

    jaiq_kwert = zkwert.
    jaiq_kbetr = zkbetr.

** JSIQ
    CLEAR : zkwert, zkbetr.
    CLEAR : count.
    zkschl = 'JSIQ'.
    zkrech1 = 'C'.
    count   = chg_count.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = zkrech1    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jsiq_kwert,
            jsiq_kbetr.

    jsiq_kwert = zkwert.
    jsiq_kbetr = zkbetr.

    quat_count = chg_count.

exd_kwert =  jsip_kwert + jaip_kwert + jmip_kwert + jsop_kwert + jaop_kwert + jmop_kwert +
jmiq_kwert + jaoq_kwert + jsoq_kwert + jmiq_kwert + jaiq_kwert + jsiq_kwert.

    exd_kwert1 =  exd_kwert +  exd_kwert1.

* Count is used to know the condition types.
* A and C are equal in count.
    IF per_count EQ 0 AND quat_count EQ 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-009. " 'Excise Duty'.
      lw_tax-zspec_char        = text-017. " '**'..
      lw_tax-zunit_pric        = ' '.

      IF exd_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = exd_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.

    ENDIF.

* A is greater than count 0 and C equal to count 0
    IF per_count GT 0 AND quat_count EQ 0.
      CLEAR :lw_tax.
exd_kbetr =  jsip_kbetr + jaip_kbetr + jmip_kbetr + jsop_kbetr + jaop_kbetr + jmop_kbetr.

      lw_tax-ztax_description = text-009. " 'Excise Duty'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF exd_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = exd_kbetr.
      ENDIF.

      IF exd_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = exd_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.

    ENDIF.

* A is equal to count 0 and C is greater than count 0
    IF  per_count EQ 0 AND quat_count GT 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-009. " "'Excise Duty'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF exd_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = exd_kbetr.
      ENDIF.

      IF exd_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = exd_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.

    ENDIF.

* A and C greater than count 0
    IF per_count GT 0 AND quat_count GT 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-009. "'Excise Duty'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF exd_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = exd_kbetr.
      ENDIF.

      IF exd_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = exd_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.

    ENDIF.

    CLEAR : per_count, quat_count.
************************** Education Cess **********************
** JEC1
    CLEAR : zkwert, zkbetr.
    zkschl = 'JEC1'.
    CALL METHOD me->tax_cond1
      EXPORTING
        zkschl = zkschl
        zitab  = it_komv
      IMPORTING
        kwert  = zkwert
        kbetr  = zkbetr.

    CLEAR : jec1_kwert,
            jec1_kbetr.

    jec1_kwert = zkwert.
    jec1_kbetr = zkbetr.

** JEC2
    CLEAR : zkwert, zkbetr.
    zkschl = 'JEC2'.
    CALL METHOD me->tax_cond1
      EXPORTING
        zkschl = zkschl
        zitab  = it_komv
      IMPORTING
        kwert  = zkwert
        kbetr  = zkbetr.

    CLEAR : jec2_kwert,
            jec2_kbetr.

    jec2_kwert = zkwert.
    jec2_kbetr = zkbetr.

    ed_kbetr = jec1_kbetr + jec2_kbetr.
    ed_kwert = jec1_kwert + jec2_kwert.
    ed_kwert1 = ed_kwert + ed_kwert1.


    IF ed_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-010. "'Edu Cess'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF ed_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = ed_kbetr.
      ENDIF.

      IF ed_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = ed_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ELSE.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-010. "'Edu Cess'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF ed_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = ed_kbetr.
      ENDIF.

      IF ed_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = ed_kwert.
      ENDIF.


      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ENDIF.
********************Secondary Higher Education Cess*************
** JSEP
    CLEAR : zkwert, zkbetr.
    zkschl = 'JSEP'.
    CALL METHOD me->tax_cond1
      EXPORTING
        zkschl = zkschl
        zitab  = it_komv
      IMPORTING
        kwert  = zkwert
        kbetr  = zkbetr.

    CLEAR: jsep_kwert,
           jsep_kbetr.

    jsep_kwert = zkwert.
    jsep_kbetr = zkbetr.


** JSEI
    CLEAR : zkwert, zkbetr.
    zkschl = 'JSEI'.
    CALL METHOD me->tax_cond1
      EXPORTING
        zkschl = zkschl
        zitab  = it_komv
      IMPORTING
        kwert  = zkwert
        kbetr  = zkbetr.

    CLEAR : jsei_kwert,
            jsei_kbetr.

    jsei_kwert = zkwert.
    jsei_kbetr = zkbetr.

    sed_kbetr = jsep_kbetr + jsei_kbetr.
    sed_kwert = jsep_kwert + jsei_kwert.

    IF sed_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-011. "'SHE Cess'.
      lw_tax-zspec_char        = text-017. " text-017. " '**'..

      IF sed_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = sed_kbetr.
      ENDIF.

      IF sed_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = sed_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ELSE.
      CLEAR :lw_tax.

      lw_tax-ztax_description = text-011. "'SHE Cess'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF sed_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = sed_kbetr.
      ENDIF.

      IF sed_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = sed_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ENDIF.
************************Central sales Tax***********************

** JIPC
    zkschl = 'JIPC'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jipc_kwert,
            jipc_kbetr.

    jipc_kwert = zkwert.
    jipc_kbetr = zkbetr.


    IF jipc_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-012. "'CST'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF jipc_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = jipc_kbetr.
      ENDIF.

      IF jipc_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = jipc_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ELSE.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-012. "'CST'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF jipc_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = jipc_kbetr.
      ENDIF.

      IF jipc_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = jipc_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ENDIF.

**************************Value Added Tax***********************
** JVRD
    zkschl = 'JVRD'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jvrd_kwert,
            jvrd_kbetr.

    jvrd_kwert = zkwert.
    jvrd_kbetr = zkbetr.

** JVRN
    zkschl = 'JVRN'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'    " Calculation type for condition
        zitab      = it_komv
        zcount     = count    " 3-Byte field
      IMPORTING
        kwert      = zkwert   " Condition value
        kbetr      = zkbetr   " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jvrn_kwert,
            jvrn_kbetr.

    jvrn_kwert = zkwert.
    jvrn_kbetr = zkbetr.


    vat_kbetr =  jvrd_kbetr + jvrn_kbetr .
    vat_kwert = jvrd_kwert + jvrn_kwert.

    IF  vat_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-013. " 'VAT'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF vat_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = vat_kbetr.
      ENDIF.

      IF vat_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = vat_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ELSE.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-013. " 'VAT'.
      lw_tax-zspec_char        = text-018. " '%'..
      lw_tax-zunit_pric        = vat_kbetr.
      lw_tax-ztotal_value      = vat_kwert.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ENDIF.

* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|START
  ENDIF.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:05252017|END
****************************Service Tax**************************

** JSVD
    zkschl = 'JSVD'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jser_kwert,
            jser_kbetr.

    jser_kwert = zkwert.
    jser_kbetr = zkbetr.

*->Begin of Ins MAIELY/08122015 CMS29471
    zkschl = 'JSER'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jser2_kwert,
            jser2_kbetr.

    jser2_kwert = zkwert.
    jser2_kbetr = zkbetr.

    zkschl = 'ZSBC'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : zsbc_kwert,
            zsbc_kbetr.

    zsbc_kwert = zkwert.
    zsbc_kbetr = zkbetr.
*-<End of Ins MAIELY/08122015 CMS29471

** JSV2
    zkschl = 'JSV2'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jsv2_kwert,
            jsv2_kbetr.

    jsv2_kwert = zkwert.
    jsv2_kbetr  = zkbetr.

** ZSVD
    zkschl = 'ZSVD'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : zsvd_kwert,
            zsvd_kbetr.

    zsvd_kwert = zkwert.
    zsvd_kbetr = zkbetr.

ser_tax_kbetr  =  jser_kbetr + jsv2_kbetr + zsvd_kbetr + jser2_kbetr. "CMS29471
ser_tax_kwert  =  jser_kwert + jsv2_kwert + zsvd_kwert + jser2_kwert. "CMS29471

    IF ser_tax_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-014. " 'Service Tax'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF ser_tax_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = ser_tax_kbetr.
      ENDIF.

      IF ser_tax_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = ser_tax_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ELSE.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-014. " 'Service Tax'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF ser_tax_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = ser_tax_kbetr.
      ENDIF.

      IF ser_tax_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = ser_tax_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ENDIF.

************************Service Education Cess******************

** JEC3
    zkschl = 'JEC3'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jec3_kwert,
            jec3_kbetr.

    jec3_kwert = zkwert.
    jec3_kbetr = zkbetr.

** JEC4
    zkschl = 'JEC4'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : jec4_kwert,
            jec4_kbetr.

    jec4_kwert = zkwert.
    jec4_kbetr = zkbetr.

** ZEC3
    zkschl = 'ZEC3'.
    CLEAR : zkwert, zkbetr.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : zec3_kwert,
            zec3_kbetr.

    zec3_kwert = zkwert.
    zec3_kbetr = zkbetr.

    IF jec3_kbetr IS NOT INITIAL.
      IF  jec4_kbetr IS NOT INITIAL.
        IF zec3_kbetr IS NOT INITIAL.

          IF ( jec3_kbetr = jec4_kbetr AND
             jec3_kbetr = zec3_kbetr AND
             jec4_kbetr = zec3_kbetr ).

            sec_kbetr = jec3_kbetr.

          ENDIF.

        ELSE.
          IF jec3_kbetr IS NOT INITIAL AND
             jec4_kbetr IS NOT INITIAL.
            IF jec3_kbetr EQ  jec4_kbetr.
              sec_kbetr = jec3_kbetr.
            ENDIF.
          ELSE.
            IF jec3_kbetr IS NOT INITIAL AND
               jec4_kbetr IS INITIAL.
              sec_kbetr = jec3_kbetr.
            ENDIF.
            IF jec3_kbetr IS INITIAL AND
               jec4_kbetr IS NOT INITIAL.
              sec_kbetr = jec4_kbetr.
            ENDIF.
          ENDIF.

        ENDIF.

      ELSE.

        IF jec3_kbetr IS NOT INITIAL AND
           zec3_kbetr IS NOT INITIAL.
          IF jec3_kbetr EQ  zec3_kbetr.
            sec_kbetr = jec3_kbetr.
          ENDIF.
        ELSE.
          IF jec3_kbetr IS NOT INITIAL AND
             zec3_kbetr IS INITIAL.
            sec_kbetr = jec3_kbetr.
          ENDIF.
          IF jec3_kbetr IS INITIAL AND
             zec3_kbetr IS NOT INITIAL.
            sec_kbetr = zec3_kbetr.
          ENDIF.
        ENDIF.

      ENDIF.

    ELSE.

      IF  jec4_kbetr IS NOT INITIAL AND
          zec3_kbetr IS NOT INITIAL.

        IF jec4_kbetr EQ zec3_kbetr.
          sec_kbetr = jec4_kbetr.
        ENDIF.

      ELSE.

        IF jec4_kbetr IS NOT INITIAL AND
           zec3_kbetr IS INITIAL.

          sec_kbetr = jec4_kbetr.
        ENDIF.

        IF  jec4_kbetr IS INITIAL AND
            zec3_kbetr IS NOT INITIAL.
          sec_kbetr = zec3_kbetr.
        ENDIF.

      ENDIF.
    ENDIF.


    sec_kwert = jec3_kwert + jec4_kwert + zec3_kwert.

    IF sec_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-015. "'Service Edu Cess'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF sec_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = sec_kbetr.
      ENDIF.

      IF sec_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = sec_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ELSE.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-015. "'Service Edu Cess'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF sec_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = sec_kbetr.
      ENDIF.

      IF sec_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = sec_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.

    ENDIF.
*************Service Secondary Higher Education Cess*************
** JSE1
    zkschl = 'JSE1'.
    CLEAR : zkwert, zkbetr.
*    PERFORM tax_cond3 USING zkschl it_komv CHANGING zkwert zkbetr zkrech.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR :  jse1_kwert,
             jse1_kbetr.

    jse1_kwert = zkwert.
    jse1_kbetr = zkbetr.


** JSE2
    zkschl = 'JSE2'.
    CLEAR : zkwert, zkbetr.
*    PERFORM tax_cond3 USING zkschl it_komv CHANGING zkwert zkbetr zkrech.
    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl       " Condition Type
        zkrech     = 'A'          " Calculation type for condition
        zitab      = it_komv
        zcount     = count        " 3-Byte field
      IMPORTING
        kwert      = zkwert       " Condition value
       kbetr      = zkbetr       " Rate (condition amount or percentage)
       chng_count = chg_count.   " 3-Byte field

    CLEAR : jse2_kwert,
            jse2_kbetr.

    jse2_kwert = zkwert.
    jse2_kbetr = zkbetr.

** ZSE1
    zkschl = 'ZSE1'.
    CLEAR : zkwert, zkbetr.
*    PERFORM tax_cond3 USING zkschl it_komv CHANGING zkwert zkbetr zkrech.

    CALL METHOD me->tax_cond
      EXPORTING
        zkschl     = zkschl    " Condition Type
        zkrech     = 'A'       " Calculation type for condition
        zitab      = it_komv
        zcount     = count     " 3-Byte field
      IMPORTING
        kwert      = zkwert    " Condition value
        kbetr      = zkbetr    " Rate (condition amount or percentage)
        chng_count = chg_count.   " 3-Byte field

    CLEAR : zse1_kwert,
            zse1_kbetr.

    zse1_kwert = zkwert.
    zse1_kbetr = zkbetr.

    IF jse1_kbetr IS NOT INITIAL.
      IF jse2_kbetr IS NOT INITIAL.
        IF zse1_kbetr IS NOT INITIAL.
          IF ( jse1_kbetr = jse2_kbetr AND
              jse1_kbetr = zse1_kbetr AND
              jse2_kbetr = zse1_kbetr ).

            sshc_kbetr = jse1_kbetr.
          ENDIF.
        ELSE.

          IF jse1_kbetr IS NOT INITIAL AND
            jse2_kbetr IS NOT INITIAL.

            IF jse1_kbetr EQ jse2_kbetr.
              sshc_kbetr = jse1_kbetr.
            ENDIF.

          ELSE.

            IF jse1_kbetr IS NOT INITIAL AND
               jse2_kbetr IS INITIAL.
              sshc_kbetr = jse1_kbetr.
            ENDIF.

            IF jse1_kbetr IS INITIAL
               AND jse2_kbetr IS NOT INITIAL.
              sshc_kbetr = jse2_kbetr.
            ENDIF.

          ENDIF.

        ENDIF.

      ELSE.

        IF jse1_kbetr IS NOT INITIAL AND
           zse1_kbetr IS NOT INITIAL.

          IF jse1_kbetr EQ zse1_kbetr.
            sshc_kbetr = jse1_kbetr.
          ENDIF.

        ELSE.

          IF jse1_kbetr IS NOT INITIAL AND
             zse1_kbetr IS INITIAL.
            sshc_kbetr = jse1_kbetr.
          ENDIF.

          IF jse1_kbetr IS INITIAL
             AND zse1_kbetr IS NOT INITIAL.
            sshc_kbetr = zse1_kbetr.
          ENDIF.

        ENDIF.

      ENDIF.

    ELSE.

      IF jse2_kbetr IS NOT INITIAL
         AND zse1_kbetr IS NOT INITIAL.

        IF jse2_kbetr EQ zse1_kbetr.
          sshc_kbetr = jse2_kbetr.
        ENDIF.

      ELSE.

        IF jse2_kbetr IS NOT INITIAL
          AND zse1_kbetr IS INITIAL.
          sshc_kbetr = jse2_kbetr.
        ENDIF.

        IF jse2_kbetr IS INITIAL
           AND zse1_kbetr IS NOT INITIAL.
          sshc_kbetr = zse1_kbetr.
        ENDIF.

      ENDIF.
    ENDIF.

    sshc_kwert = jse1_kwert + jse2_kwert + zse1_kwert.

    IF sshc_kbetr = 0.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-016. " 'Service SHE Cess'.
      lw_tax-zspec_char        = text-017. " '**'..

      IF sshc_kbetr IS NOT INITIAL.
        lw_tax-zunit_pric        = sshc_kbetr.
      ENDIF.

      IF sshc_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = sshc_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.

    ELSE.
      CLEAR :lw_tax.
      lw_tax-ztax_description = text-016. " 'Service SHE Cess'.
      lw_tax-zspec_char        = text-018. " '%'..

      IF sshc_kbetr IS NOT INITIAL .
        lw_tax-zunit_pric        = sshc_kbetr.
      ENDIF.

      IF sshc_kwert IS NOT INITIAL.
        lw_tax-ztotal_value      = sshc_kwert.
      ENDIF.

      APPEND lw_tax TO lt_tax.
      CLEAR lw_tax.
    ENDIF.


    DELETE lt_tax WHERE  ztotal_value IS INITIAL.

*->Begin of Change/CMS29471/Discount calculation
    CLEAR:zv_discount,lv_tot_discount,lv_unit_price.

    CALL METHOD me->get_discount
      EXPORTING
        zv_poitem  = lw_poitem-ebelp
        zkonv      = lt_konv
      IMPORTING
        kwert      = zv_discount.  " discount value

    IF zv_discount IS NOT INITIAL.
      lv_tot_discount = gw_item-ztotal_value + zv_discount.
      lt_total_basic1 = lt_total_basic1 + zv_discount.
      gw_item-ztotal_value = lv_tot_discount.
    ENDIF.

    IF gw_item-zquantity IS NOT INITIAL.
      lv_unit_price = gw_item-ztotal_value / gw_item-zquantity.
      gw_item-zunit_price = lv_unit_price.
    ENDIF.
*-<End of Change/CMS29471/Discount calculation

*
************************* Final tax table ***********************

    CREATE DATA : o_data1 LIKE lt_tax.

    FIELD-SYMBOLS : <fs_tax> TYPE ANY TABLE.


    ASSIGN o_data1->* TO <fs_tax>.

    IF <fs_tax> IS ASSIGNED.

      <fs_tax> = lt_tax.
      gw_item-ztax_details = <fs_tax>.

    ENDIF.

    REFRESH lt_tax.

*** Total Tax
    CLEAR :  ztotal_tax .

    ztotal_tax = exd_kwert +  ed_kwert + sed_kwert +  jipc_kwert +
                 vat_kwert + ser_tax_kwert + sec_kwert + sshc_kwert +
* CMS31821|ChangedBy:APUNJAA|ChangedOn:06072017|START
                 ztotal_gsttax.
* CMS31821|ChangedBy:APUNJAA|ChangedOn:06072017|END


    ztotal_tax1 = ztotal_tax1 + ztotal_tax.
******************************** Service Master Table ******************

    IF lw_poitem-pstyp = 9.

READ TABLE lt_serv_mas2 INTO lw_serv_mas2 WITH KEY packno = lw_poitem-packno.

      IF sy-subrc = 0.

*        DATA : sub_packno1  TYPE sub_packno.     "CMS27120
*        sub_packno1 = lw_serv_mas1-sub_packno.   "CMS27120
        LOOP AT lt_serv_mas1 INTO lw_serv_mas1
                      WHERE packno =  lw_serv_mas2-sub_packno "CMS27120
                        AND zchange = space.                "CMS27120

          lw_serv_mas-zpo_number = lw_poitem-ebeln.
          lw_serv_mas-zitem = lw_poitem-ebelp.
          lw_serv_mas-zpackno = lw_poitem-packno.
          lw_serv_mas-zsrvpos = lw_serv_mas1-srvpos.
          lw_serv_mas-zsubpackno = lw_serv_mas2-sub_packno.
          lw_serv_mas-zchange = lw_serv_mas1-zchange.       "CMS27120

** Service Quantity
          IF lw_serv_mas1-ktext1 IS NOT INITIAL.
            lw_serv_mas-zktext1 = lw_serv_mas1-ktext1.
          ENDIF.

** Service Quantity
          IF lw_serv_mas1-menge IS NOT INITIAL.
            lw_serv_mas-zquantity = lw_serv_mas1-menge.
          ENDIF.
** Service UOM
          IF lw_serv_mas1-meins IS NOT INITIAL.
            lw_serv_mas-zuom = lw_serv_mas1-meins.
          ENDIF.

** Service Unit price
IF lw_serv_mas1-tbtwr IS   NOT INITIAL AND lw_serv_mas1-peinh IS NOT INITIAL.
      lw_serv_mas-zunit_price = lw_serv_mas1-tbtwr / lw_serv_mas1-peinh.
          ENDIF.
** Service Total Value
          lw_serv_mas-ztotal_value = lw_serv_mas1-netwr .
          zser_total = zser_total  +  lw_serv_mas-ztotal_value.
* Service activity long text

*->Begin of CMS27120
          CLEAR lw_tserv_mas.
          READ TABLE lt_serv_mas INTO lw_tserv_mas WITH KEY
                                      zitem = lw_poitem-ebelp
                                      zsrvpos = lw_serv_mas1-srvpos.

          IF sy-subrc NE 0.
*-<End of CMS27120

            id      = 'LTXT'.
            name    = lw_serv_mas1-srvpos.
            object  = 'ASMD'.
            lang = zpoheader-spras.

            IF lang IS INITIAL.
              lang = text-034. " 'EN'..
            ENDIF.

            REFRESH : gt_read_text.

            CALL METHOD me->read_text1
              EXPORTING
                zid           = id   " Text ID
                zname         = name   " Name
                zobject       = object   " Texts: Application Object
                zlang         = lang
              IMPORTING
                gt_read_text1 = gt_read_text.

            IF gt_read_text IS NOT INITIAL.
              DATA:lw_read_text LIKE LINE OF gt_read_text,
                   lw_wserv_mas TYPE zlong_txt_service_s.
              LOOP AT gt_read_text INTO lw_read_text.
                lw_wserv_mas-zpo_number = lw_poitem-ebeln.
                lw_wserv_mas-zitem = lw_poitem-ebelp.
                lw_wserv_mas-zsrvpos = lw_serv_mas1-srvpos.
                lw_wserv_mas-tdformat = lw_read_text-tdformat.
                lw_wserv_mas-tdline = lw_read_text-tdline.
                APPEND lw_wserv_mas TO lw_serv_mas-zlong_text.
              ENDLOOP.
            ENDIF.

          ENDIF.                                            "CMS27120

          APPEND lw_serv_mas TO lt_serv_mas.

          CLEAR : lw_serv_mas.
        ENDLOOP.

        gw_item-ztotal_value = zser_total.

        lv_zsbc_total = lv_zsbc_total +  zsbc_kwert.        "CMS29471

        lt_total_basic1 = lt_total_basic1 + zser_total.     "CMS29471

        CLEAR :zser_total.

        CREATE DATA : d_service LIKE lt_serv_mas.

        FIELD-SYMBOLS : <fs_ser_mast> TYPE ANY TABLE.

        ASSIGN d_service->* TO <fs_ser_mast>.

        IF <fs_ser_mast> IS ASSIGNED.

          <fs_ser_mast> = lt_serv_mas.

          REFRESH lt_serv_mas.

          gw_item-zservice_master = <fs_ser_mast>.

        ENDIF.
      ENDIF.

    ENDIF.

*************************** PO changed Text ****************************
    IF lw_nast-aende EQ 'X'.

      CLEAR : zname_text.
      CONCATENATE  text-019 zpoheader-ekorg INTO  zname_text
         SEPARATED BY '-'.

      REFRESH : gt_read_text.

      id      = text-031. " 'ST'..
      name    = zname_text.
      object  = text-032.

      REFRESH gt_read_text.

      CALL METHOD me->read_text
        EXPORTING
          zid           = id        " Text ID
          zname         = name      " TDIC text name
          zobject       = object    " Texts: Application Object
        IMPORTING
          gt_read_text1 = gt_read_text.

      gw_item-zpo_changed = gt_read_text.

    ENDIF.

****************************** Material Description *******************


    IF lw_poitem-matnr IS NOT INITIAL AND
       gw_item-zpotextitem IS INITIAL.            "CMS 30076

      id      = 'BEST'.
      name    = lw_poitem-matnr.
      object  = 'MATERIAL'.

      lang = zpoheader-spras.

      IF lang IS INITIAL.
        lang = text-034. " text-034. " 'EN'..
      ENDIF.

      REFRESH : gt_read_text.

      CALL METHOD me->read_text1
        EXPORTING
          zid           = id   " Text ID
          zname         = name   " Name
          zobject       = object   " Texts: Application Object
          zlang         = lang
        IMPORTING
          gt_read_text1 = gt_read_text.

      IF gt_read_text IS INITIAL.

        REFRESH : gt_read_text.
        CLEAR : gw_read_text.

        id      = 'GRUN'.
        name    = lw_poitem-matnr.
        object  = 'MATERIAL'.

        lang = zpoheader-spras.

        IF lang IS INITIAL.
          lang = text-034. " 'EN'..
        ENDIF.

*        REFRESH : gt_read_text.

        CALL METHOD me->read_text1
          EXPORTING
            zid           = id   " Text ID
            zname         = name   " Name
            zobject       = object   " Texts: Application Object
            zlang         = lang
          IMPORTING
            gt_read_text1 = gt_read_text.

        IF gt_read_text IS INITIAL.

*->Begin of comment/CMS27120/MAIELY
*          REFRESH : gt_read_text.
*          CLEAR : gw_read_text.
*
*          gw_read_text-tdline  = lw_poitem-txz01.
*
*          APPEND  gw_read_text TO gt_read_text.
*          CLEAR : gw_read_text.
*
*          gw_item-zmatnr_descr = gt_read_text.
*->End of comment/CMS27120/MAIELY

        ELSE.
          gw_item-zmatnr_descr = gt_read_text.
        ENDIF.

      ELSE.

        gw_item-zmatnr_descr = gt_read_text.
      ENDIF.

      APPEND  gw_read_text TO gt_read_text.
      CLEAR : gw_read_text.

    ELSE.

*->Begin of Comment CMS27120/MAIELY
*      REFRESH : gt_read_text.
*      CLEAR : gw_read_text.
*
*      APPEND  gw_read_text TO gt_read_text.

*      gw_item-zmatnr_descr = gt_read_text.
*-<End of Comment CMS27120/MAIELY

    ENDIF.
************************* Final Item table *****************************
*->Begin of Change CMS27120
*    APPEND gw_item TO gt_item.
    IF cv_output_type EQ 'C'.
      IF gw_item-zstatus EQ 'X'.
        APPEND gw_item TO gt_item.
      ENDIF.
    ELSE.
      APPEND gw_item TO gt_item.
    ENDIF.
*-<Endof Change CMS27120

    IF lw_nast-aende EQ 'X'.
      DELETE gt_item WHERE zstatus <> 'X'.
    ENDIF.

    CLEAR : gw_item.

*************CST TIN ECC RANGE DIVISION COMMISSIONERATE ************

    SELECT SINGLE j_1icstno " Central Sales Tax Number
           j_1ilstno " Local Sales Tax Number
           j_1iexcd  " ECC Number
           j_1iexrg	 " Excise Range
           j_1iexdi  " Excise Division
           j_1iexco	 " Excise Commissionerate
           FROM j_1imocomp
           INTO  gw_j_1imocomp
           WHERE bukrs EQ zpoheader-bukrs  AND
                 werks EQ lw_poitem-werks.

    gw_header-zj_1icstno = gw_j_1imocomp-zj_1icstno.
    gw_header-zj_1ilstno = gw_j_1imocomp-zj_1ilstno.
    gw_header-zj_1iexcd  = gw_j_1imocomp-zj_1iexcd.
    gw_header-zj_1iexrg  = gw_j_1imocomp-zj_1iexrg.
    gw_header-zj_1iexdi  = gw_j_1imocomp-zj_1iexdi.
    gw_header-zj_1iexco  = gw_j_1imocomp-zj_1iexco.
************************************************************************

* CMS31821|ChangedBy:APUNJAA|ChangedOn:06262017|START
* Changes to display GSTIN Number Instead CST/TIN and ECC in the smartform

* CMS 32224|ChangedBy:APUNJAA|ChangedOn:06262017|START
   IF gw_t001w-j_1bbranch is INITIAL.
     SELECT SINGLE j_1bbranch INTO gw_t001w-j_1bbranch
       FROM t001w
         WHERE werks = lw_poitem-werks.
   ENDIF.
* CMS 32224|ChangedBy:APUNJAA|ChangedOn:06262017|END

    CLEAR: gw_header-gstin, lv_gstin.
      SELECT SINGLE gstin
        FROM J_1BBRANCH
        INTO lv_gstin
          WHERE bukrs = zpoheader-bukrs
            AND branch = gw_t001w-j_1bbranch.

    gw_header-gstin = lv_gstin.
* CMS 32224|ChangedBy:APUNJAA|ChangedOn:06262017|END

  ENDLOOP.

  IF cv_output_type EQ 'C'.                                 "CMS27120
    DELETE gt_item WHERE zstatus EQ space.                  "CMS27120
  ENDIF.                                                    "CMS27120



  gw_header-zitem_data = gt_item .

******************************** Instructions *************************
  REFRESH : gt_instructions,
            gt_read_text.
  CLEAR : zname_text.

*->Begin of Change CMS27120
  SORT zpoitem BY ebelp.

  CLEAR lw_poitem.
  READ TABLE zpoitem INTO lw_poitem INDEX 1.

  IF lw_poitem-pstyp = '9'.
    CONCATENATE  text-041 zpoheader-ekorg INTO  zname_text
                 SEPARATED BY '-'.
*-<End of Change CMS27120
  ELSE.
    CONCATENATE  text-020 zpoheader-ekorg INTO  zname_text
                 SEPARATED BY '-'.
  ENDIF.                                                    "CMS27120

  id      = text-031. " 'ST'..
  name    = zname_text.
  object  = text-032.

  REFRESH gt_read_text.

  CALL METHOD me->read_text
    EXPORTING
      zid           = id    " Text ID
      zname         = name    " TDIC text name
      zobject       = object    " Texts: Application Object
    IMPORTING
      gt_read_text1 = gt_read_text.

  gt_instructions = gt_read_text.

  gw_header-zinstructions = gt_instructions.

************************** Buyer Contact Details **********************
  IF NOT zpoheader-ekgrp IS INITIAL.

    SELECT SINGLE zekgrp
                  contact
                  zphone1
                  zphone2
                  e_mail
                  FROM zpor4
                  INTO CORRESPONDING FIELDS OF wa_zpor4
                  WHERE zekgrp = zpoheader-ekgrp.

    IF ( wa_zpor4-zekgrp IS INITIAL OR wa_zpor4-contact IS  INITIAL ).

      SELECT SINGLE ekgrp      " Purchasing group
                    eknam      " Description of purchasing group
                    tel_number " TELF1 no.: dialling code+number
                    telfx      " Fax number of purchasing (buyer) group
                    smtp_addr  " E-Mail Address
                    FROM t024
                    INTO CORRESPONDING FIELDS OF wa_t024
                    WHERE ekgrp = zpoheader-ekgrp.

      gw_buy_detail-zekgrp   = wa_t024-ekgrp.      " prchase group
      gw_buy_detail-zcontact = wa_t024-eknam.      " Buyer
      gw_buy_detail-zphone1  = wa_t024-tel_number. " TELF1
      gw_buy_detail-zphone2  = wa_t024-telfx .     " Fax
      gw_buy_detail-e_mail   = wa_t024-smtp_addr.  " Email

      APPEND gw_buy_detail TO gt_buy_detail.

    ELSE.

      gw_buy_detail-zekgrp   = wa_zpor4-zekgrp.     " prchase group
      gw_buy_detail-zcontact = wa_zpor4-contact.    " Buyer
      gw_buy_detail-zphone1  = wa_zpor4-zphone1.    " TELF1
      gw_buy_detail-zphone2  = wa_zpor4-zphone2 .   " Fax
      gw_buy_detail-e_mail   = wa_zpor4-e_mail.     " Email

      APPEND gw_buy_detail TO gt_buy_detail.

    ENDIF.

  ENDIF.

  READ TABLE gt_buy_detail INTO gw_buy_detail INDEX 1.

  IF sy-subrc = 0.

    gw_header-zbc_contact  = gw_buy_detail-zcontact.
    gw_header-zbc_ekgrp    = gw_buy_detail-zekgrp.
    gw_header-zbc_phone1   = gw_buy_detail-zphone1.
    gw_header-zbc_phone2   = gw_buy_detail-zphone2.
    gw_header-zbc_e_mail   = gw_buy_detail-e_mail.

  ENDIF.

************************ Supplier Reference ****************************
  REFRESH : gt_read_text.
  CLEAR : wa_sup_ref.

  id      = 'F16'.
  name    = zpoheader-ebeln..
  object  = text-036. " 'EKKO'..

** BEGIN CMS 30076. JHUNSUC. 03/11/2016 **
  zlang1  = zpoheader-spras.

  CALL METHOD read_text1
    EXPORTING
      zid           = id   " Text ID
      zname         = name    " Name
      zobject       = object    " Texts: Application Object
      zlang         = zlang1
    IMPORTING
      gt_read_text1 = gt_read_text.

  IF gt_read_text IS NOT INITIAL.
    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.
  ELSE.

    id      = 'F06'.
    name    = zpoheader-ebeln.
    object  = text-036. " 'EKKO'..
    zlang1  = text-034. " 'EN'..

    CALL METHOD read_text1
      EXPORTING
        zid           = id   " Text ID
        zname         = name   " Name
        zobject       = object    " Texts: Application Object
        zlang         = zlang1
      IMPORTING
        gt_read_text1 = gt_read_text.

    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.


  ENDIF.

*  REFRESH gt_read_text.
*
*  CALL METHOD me->read_text
*    EXPORTING
*      zid           = id    " Text ID
*      zname         = name    " TDIC text name
*      zobject       = object    " Texts: Application Object
*    IMPORTING
*      gt_read_text1 = gt_read_text.

** END CMS 30076 **

  READ TABLE gt_read_text INTO wa_sup_ref INDEX 1.
  IF sy-subrc = 0.

    gw_header-zsup_ref = wa_sup_ref-tdline.

  ENDIF.

*********************** KONNR Reference ****************************
gw_header-zagreement = zpoheader-konnr. "Number of Principal Purchase KONNR
*********************** Mode of Dispatch ********************************
  REFRESH : gt_read_text.
  CLEAR : wa_po_disp.

  id      = 'F06'.
  name    = zpoheader-ebeln..
  object  = text-036. " 'EKKO'..

** BEGIN CMS 30076. JHUNSUC. 03/11/2016 **
  zlang1  = zpoheader-spras.

  CALL METHOD read_text1
    EXPORTING
      zid           = id   " Text ID
      zname         = name    " Name
      zobject       = object    " Texts: Application Object
      zlang         = zlang1
    IMPORTING
      gt_read_text1 = gt_read_text.

  IF gt_read_text IS NOT INITIAL.
    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.
  ELSE.

    id      = 'F06'.
    name    = zpoheader-ebeln.
    object  = text-036. " 'EKKO'..
    zlang1  = text-034. " 'EN'..

    CALL METHOD read_text1
      EXPORTING
        zid           = id   " Text ID
        zname         = name   " Name
        zobject       = object    " Texts: Application Object
        zlang         = zlang1
      IMPORTING
        gt_read_text1 = gt_read_text.

    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.


  ENDIF.



*  REFRESH gt_read_text.
*
*  CALL METHOD me->read_text
*    EXPORTING
*      zid           = id    " Text ID
*      zname         = name    " TDIC text name
*      zobject       = object    " Texts: Application Object
*    IMPORTING
*      gt_read_text1 = gt_read_text.


** END CMS 30076

  READ TABLE gt_read_text INTO wa_po_disp INDEX 1.
  IF sy-subrc = 0.
    gw_header-zmo_disp = wa_po_disp-tdline+0(59).           "CMS29471
  ENDIF.

******************************* Frieght *********************************
  REFRESH : gt_read_text.
  CLEAR :  wa_po_freight.

  id      = 'F05'.
  name    = zpoheader-ebeln.
  object  = text-036. " 'EKKO'..

** BEGIN CMS 30076. JHUNSUC. 03/11/2016 **
  zlang1  = zpoheader-spras.

  CALL METHOD read_text1
    EXPORTING
      zid           = id   " Text ID
      zname         = name    " Name
      zobject       = object    " Texts: Application Object
      zlang         = zlang1
    IMPORTING
      gt_read_text1 = gt_read_text.

  IF gt_read_text IS NOT INITIAL.
    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.
  ELSE.

    id      = 'F05'.
    name    = zpoheader-ebeln.
    object  = text-036. " 'EKKO'..
    zlang1  = text-034. " 'EN'..

    CALL METHOD read_text1
      EXPORTING
        zid           = id   " Text ID
        zname         = name   " Name
        zobject       = object    " Texts: Application Object
        zlang         = zlang1
      IMPORTING
        gt_read_text1 = gt_read_text.

    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.


  ENDIF.

*  PERFORM read_text1 USING id name object CHANGING gt_read_text.
*  REFRESH gt_read_text.
*
*  CALL METHOD me->read_text
*    EXPORTING
*      zid           = id    " Text ID
*      zname         = name    " TDIC text name
*      zobject       = object    " Texts: Application Object
*    IMPORTING
*      gt_read_text1 = gt_read_text.
*
** END CMS 30076 **
  READ TABLE gt_read_text INTO wa_po_freight INDEX 1.



  IF sy-subrc = 0 .
    gw_header-zfreight =  wa_po_freight-tdline.
  ENDIF.

***************************** Shipment terms ***************************

  gw_header-zsh_incoterms1 = zpoheader-inco1.
  gw_header-zsh_incoterms2 = zpoheader-inco2+0(22).         "CMS27120

***************************** Payment Terms ****************************
  CLEAR :gw_zmmfld.

  SELECT SINGLE *
         FROM zmmfld
         INTO gw_zmmfld
         WHERE key1   = text-035 AND " 'R10031' AND
               key2   = 'ZTERM'  AND
               value1 = zpoheader-zterm.

  IF sy-subrc = 0.

    REFRESH : gt_read_text.
    CLEAR :  wa_po_payterm.

    id      = 'F07'.
    name    = zpoheader-ebeln..
    object  = text-036. " text-036. " 'EKKO'..

** BEGIN CMS 30076. JHUNSUC. 03/11/2016 **
  zlang1  = zpoheader-spras.

  CALL METHOD read_text1
    EXPORTING
      zid           = id   " Text ID
      zname         = name    " Name
      zobject       = object    " Texts: Application Object
      zlang         = zlang1
    IMPORTING
      gt_read_text1 = gt_read_text.

  IF gt_read_text IS NOT INITIAL.
    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.
  ELSE.

    id      = 'F07'.
    name    = zpoheader-ebeln.
    object  = text-036. " 'EKKO'..
    zlang1  = text-034. " 'EN'..

    CALL METHOD read_text1
      EXPORTING
        zid           = id   " Text ID
        zname         = name   " Name
        zobject       = object    " Texts: Application Object
        zlang         = zlang1
      IMPORTING
        gt_read_text1 = gt_read_text.

    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.


  ENDIF.

*    REFRESH gt_read_text.

*    CALL METHOD me->read_text
*      EXPORTING
*        zid           = id      " Text ID
*        zname         = name    " TDIC text name
*        zobject       = object  " Texts: Application Object
*      IMPORTING
*        gt_read_text1 = gt_read_text.

** END CMS 30076 **

    READ TABLE gt_read_text INTO wa_po_payterm INDEX 1.

    IF sy-subrc = 0 .
      gw_header-zpayterm =  wa_po_payterm-tdline.
    ENDIF.

  ELSE.

    SELECT SINGLE * FROM t052u INTO wa_t052u
      WHERE spras = text-034 AND "zpoheader-spras "CMS 30076
            zterm = zpoheader-zterm.

    IF sy-subrc = 0.
      gw_header-zpayterm = wa_t052u-text1.
    ENDIF.

  ENDIF.
***************************** Insurance ********************************
  CLEAR :gw_zmmfld.

  SELECT SINGLE * FROM zmmfld
           INTO gw_zmmfld
           WHERE key1   = text-035 AND " 'R10031' AND
                 key2   = 'INCO1'  AND
                 value1 = zpoheader-inco1.

  IF sy-subrc = 0.
    zinsurance = gw_zmmfld-value2.
  ELSE.
    MOVE text-033 TO zinsurance.
  ENDIF.

  gw_header-zinsurance = zinsurance.

********************** Registered Office ************************

  CLEAR :   gw_reg_office.
  REFRESH : gt_read_text,  gt_reg_office.
  CLEAR : zname_text.
  CONCATENATE text-021 zpoheader-ekorg INTO  zname_text
               SEPARATED BY '-'.

  id      = text-031. " 'ST'..
  name    = zname_text.
  object  = text-032.

  REFRESH gt_read_text.

  CALL METHOD me->read_text
    EXPORTING
      zid           = id    " Text ID
      zname         = name    " TDIC text name
      zobject       = object    " Texts: Application Object
    IMPORTING
      gt_read_text1 = gt_read_text.

  gt_reg_office = gt_read_text.

  gw_header-zreg_office = gt_reg_office.

********************** Co-Operate Office ************************
  REFRESH : gt_read_text, gt_corp_office.
  CLEAR   : gw_corp_office.

  CLEAR : zname_text.

  CONCATENATE text-022 zpoheader-ekorg INTO  zname_text
               SEPARATED BY '-'.

  id      = text-031. " 'ST'..
  name    = zname_text.
  object  = text-032.

  REFRESH gt_read_text.

  CALL METHOD me->read_text
    EXPORTING
      zid           = id    " Text ID
      zname         = name    " TDIC text name
      zobject       = object    " Texts: Application Object
    IMPORTING
      gt_read_text1 = gt_read_text.

  gt_corp_office = gt_read_text.

  gw_header-zcorp_office = gt_corp_office.

********************* Legal Name *******************************
  CLEAR : zname_text.

  CONCATENATE  text-005 zpoheader-ekorg INTO  zname_text
  SEPARATED BY '-'.

  id      = text-031. " 'ST'..
  name    = zname_text.
  object  = text-032.

  REFRESH : gt_read_text, gt_legal.

  CALL METHOD me->read_text
    EXPORTING
      zid           = id    " Text ID
      zname         = name    " TDIC text name
      zobject       = object    " Texts: Application Object
    IMPORTING
      gt_read_text1 = gt_read_text.

  gt_legal = gt_read_text.

  gw_header-zlegal_name = gt_legal.

********************** PO Header Text ************************

  REFRESH : gt_read_text, gt_po_header.
  CLEAR   : gw_po_header.

  id      = 'F01'.
  name    = zpoheader-ebeln.
  object  = text-036. " 'EKKO'..
  zlang1 = zpoheader-spras.

  CALL METHOD read_text1
    EXPORTING
      zid           = id   " Text ID
      zname         = name    " Name
      zobject       = object    " Texts: Application Object
      zlang         = zlang1
    IMPORTING
      gt_read_text1 = gt_read_text.

  IF gt_read_text IS NOT INITIAL.
    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.
  ELSE.

    id      = 'F01'.
    name    = zpoheader-ebeln.
    object  = text-036. " 'EKKO'..
    zlang1  = text-034. " 'EN'..

    CALL METHOD read_text1
      EXPORTING
        zid           = id   " Text ID
        zname         = name   " Name
        zobject       = object    " Texts: Application Object
        zlang         = zlang1
      IMPORTING
        gt_read_text1 = gt_read_text.

    gt_po_header = gt_read_text.
    gw_header-zheader_text = gt_po_header.

  ENDIF.

*->CMS29744 E0VK9A0IOY 01/28/2016 SMITHAI
*--Format Header Text and Replace '<(>&<)>' with an '&'.
  LOOP AT gw_header-zheader_text INTO data(wa_tline).
   REPLACE ALL OCCURRENCES OF '<(>&<)>' IN wa_tline-tdline WITH '&'.
   MODIFY gw_header-zheader_text FROM wa_tline.
  ENDLOOP.
*<-CMS29744 E0VK9A0IOY 01/28/2016 SMITHAI
********************** PO End Message ************************

  REFRESH : gt_read_text, gt_po_end_msg.
  CLEAR   : gw_po_end_msg.

  IF lw_nast-aende EQ 'X'. " PO changed
    CLEAR : zname_text.
    CONCATENATE text-023 zpoheader-ekorg INTO  zname_text
       SEPARATED BY '-'.

    id      = text-031. " 'ST'..
    name    = zname_text.
    object  = text-032.

    CALL METHOD me->read_text
      EXPORTING
        zid           = id   " Text ID
        zname         = name     " TDIC text name
        zobject       = object    " Texts: Application Object
      IMPORTING
        gt_read_text1 = gt_read_text.

    gw_header-zend_msg = gt_read_text.

  ELSE. " PO NOT changed
    CLEAR : zname_text.
    CONCATENATE text-024 zpoheader-ekorg INTO  zname_text
       SEPARATED BY '-'.

    id      = text-031. " text-031. " 'ST'..
    name    = zname_text.
    object  = text-032.

    CALL METHOD me->read_text
      EXPORTING
        zid           = id   " Text ID
        zname         = name     " TDIC text name
        zobject       = object    " Texts: Application Object
      IMPORTING
        gt_read_text1 = gt_read_text.

    gw_header-zend_msg = gt_read_text.

  ENDIF.

************************  PO Totals ********************************

  lw_po_total-zunit_price   = '-----------'.
  lw_po_total-ztotal_value  = '-----------'.
  APPEND lw_po_total TO lt_po_total.

** Total Basic
  lw_po_total-zname         = text-027. " 'Total Basic'.
  lw_po_total-zunit_price   = zpoheader-waers.
  lw_po_total-ztotal_value  = lt_total_basic1.
  gw_header-ztotal_basic = lw_po_total-ztotal_value .
  APPEND lw_po_total TO lt_po_total.

** Total P & F
  lw_po_total-zname         = text-028. " 'Total P&F'.
  lw_po_total-zunit_price   = zpoheader-waers.
  lw_po_total-ztotal_value  = lv_pf1 .
  gw_header-ztotal_pf = lv_pf1.
  APPEND lw_po_total TO lt_po_total.

** Total Tax
  lw_po_total-zname         = text-029. " 'Total Tax'.
  lw_po_total-zunit_price   = zpoheader-waers.
  lw_po_total-ztotal_value  = ztotal_tax1.
  gw_header-ztotal_tax = ztotal_tax1.
  APPEND lw_po_total TO lt_po_total.

** Grand total.
  lw_po_total-zname         = text-030. " 'Grand Total'.
  lw_po_total-zunit_price   = zpoheader-waers.
*  lw_po_total-ztotal_value  = lv_pf1  + ztotal_tax1 + lt_total_basic1. "CMS27120
  CLEAR lv_ztotal_value.                                    "CMS27120
  lv_ztotal_value  = lv_pf1  + ztotal_tax1 + lt_total_basic1 "CMS29471
                     + lv_zsbc_total.                       "CMS29471

  gw_header-zsbc_total = lv_zsbc_total.                     "CMS29471

*  gw_header-zgrand_total = lw_po_total-ztotal_value.              "CMS27120
  gw_header-zgrand_total = lv_ztotal_value.

  APPEND lw_po_total TO lt_po_total.

  gw_header-zunit_price = zpoheader-waers.

  CLEAR : lw_po_total.

  gw_header-zpo_total = lt_po_total.
*******************************  Ship To Address **********************
*** At header level which tells the PO is for the single or multiple ship to address.

  SORT gt_bill_ship1 BY plant stge_loc address .

DELETE ADJACENT DUPLICATES FROM gt_bill_ship1 COMPARING address plant stge_loc.

  CLEAR : zlines.

  IF lw_nast-aende EQ 'X'.

    DELETE gt_bill_ship1 WHERE zstatus <> 'X'.

  ENDIF.

  DESCRIBE TABLE gt_bill_ship1 LINES zlines.
  CREATE DATA : d_bill LIKE gt_bill_ship1.

  IF zlines = 1 .
**** Single plant address
    ASSIGN d_bill->* TO <fs_b1>.

    IF <fs_b1> IS ASSIGNED.

      <fs_b1> = gt_bill_ship1 .

      gw_header-zbs_heading1 = text-026.                    "CMS27120

*->Begin of Change CMS27120
*      CONCATENATE  gw_t001w-name1 text-007 gw_t001l-lgort '-'
      IF gw_t001l-lgort IS INITIAL.
        zname = lv_sname1.
      ELSE.
        CONCATENATE lv_sname1 text-007 gw_t001l-lgort '-'
                    gw_t001l-lgobe  INTO zname SEPARATED BY space.
      ENDIF.
*-<End of Change CMS27120

      LOOP AT  <fs_b1> ASSIGNING <fw_b1>.

        ASSIGN COMPONENT 'ZHEADING' OF STRUCTURE  <fw_b1> TO <fc_bl>.

        IF <fc_bl> IS ASSIGNED.
          .
          <fc_bl> =  zname.

          gt_bill_ship1 = <fs_b1>.
        ENDIF.

      ENDLOOP.

    ENDIF.

  ELSE.

***** Multiple address
    ASSIGN d_bill->* TO <fs_b1>.

    IF <fs_b1> IS ASSIGNED.

      <fs_b1> = gt_bill_ship1 .

*      CONCATENATE text-037  text-038  INTO zname SEPARATED BY space. "CMS27120
      zname = text-026.                                     "CMS27120

*->Begin of Comment CMS27120
*      LOOP AT  <fs_b1> ASSIGNING <fw_b1>.
*
*        ASSIGN COMPONENT 'ZHEADING' OF STRUCTURE  <fw_b1> TO <fc_bl>.
*
*        IF <fc_bl> IS ASSIGNED.
*
*       REPLACE ALL OCCURRENCES OF 'Ship to address' IN <fc_bl> WITH ' '.
*REPLACE ALL OCCURRENCES OF 'appears at the end of the order' IN <fc_bl> WITH ' '.
*
*          SHIFT <fc_bl> LEFT DELETING LEADING ' '.
*
*          gt_bill_ship1 = <fs_b1>.
*        ENDIF.
*
*      ENDLOOP.
*-<End of Comment CMS27120

    ENDIF.

    gw_header-zbs_heading1 = zname.

  ENDIF.

  gw_header-zship_to = gt_bill_ship1.

  gw_header-zbill_to_text = text-sp2.                       "CMS27120


****************************  Bill To Address *************************
  CLEAR : zname_text.

  CONCATENATE text-025 zpoheader-ekorg INTO  zname_text
     SEPARATED BY '-'.

  id      = text-031. " 'ST'..
  name    = zname_text.
  object  = text-032. " text-032.

  REFRESH gt_read_text .

  CALL METHOD me->read_text
    EXPORTING
      zid           = id     " Text ID
      zname         = name   " TDIC text name
      zobject       = object " Texts: Application Object
    IMPORTING
      gt_read_text1 = gt_read_text.

  IF gt_read_text IS NOT INITIAL.
    gw_header-zbill_to_addr = gt_read_text.

  ELSE.
*** If the bill to address is not found in the Standard Text


    CLEAR : gw_bill_ship.
    READ TABLE  gt_bill_ship1 INTO  gw_bill_ship INDEX 1.

    IF sy-subrc = 0.

      gw_header-zbill_to_text = text-sp1.                   "CMS27120

      REFRESH lt_tline.
      CLEAR : lw_tline.

      lw_tline-tdline = gw_bill_ship-comp_name.             "CMS27120
      APPEND lw_tline TO lt_tline.                          "CMS27120

      lw_tline-tdline = gw_bill_ship-name1.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-str_suppl1.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-str_suppl2.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-street.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-city.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-district.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-postl_cod1.
      APPEND lw_tline TO lt_tline.

      lw_tline-tdline = gw_bill_ship-landx50.
      APPEND lw_tline TO lt_tline.

      DELETE  lt_tline WHERE tdline EQ space.
      gw_header-zbill_to_addr = lt_tline.

      REFRESH lt_tline.
      CLEAR : lw_tline.


    ENDIF.

  ENDIF.

**************************** Final Table ******************************
  APPEND gw_header TO gt_final.
**************************** Final Table ******************************
ENDMETHOD.


METHOD read_text.

  REFRESH gt_read_text.

  CALL FUNCTION 'READ_TEXT'
   EXPORTING
    client                        = sy-mandt
     id                            = zid
     language                      = sy-langu
     name                          = zname
     object                        = zobject
*     ARCHIVE_HANDLE                = 0
*     LOCAL_CAT                     = ' '
*   IMPORTING
*     HEADER                        =
*     OLD_LINE_COUNTER              =
   TABLES
     lines                         = gt_read_text
  EXCEPTIONS
    id                            = 1
    language                      = 2
    name                          = 3
    not_found                     = 4
    object                        = 5
    reference_check               = 6
    wrong_access_to_archive       = 7
    OTHERS                        = 8
           .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.


ENDMETHOD.


METHOD read_text1.


  REFRESH gt_read_text.

  CALL FUNCTION 'READ_TEXT'
   EXPORTING
    client                        = sy-mandt
     id                            = zid
     language                      = zlang
     name                          = zname
     object                        = zobject
*     ARCHIVE_HANDLE                = 0
*     LOCAL_CAT                     = ' '
*   IMPORTING
*     HEADER                        =
*     OLD_LINE_COUNTER              =
   TABLES
     lines                         = gt_read_text
  EXCEPTIONS
    id                            = 1
    language                      = 2
    name                          = 3
    not_found                     = 4
    object                        = 5
    reference_check               = 6
    wrong_access_to_archive       = 7
    OTHERS                        = 8
           .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.




ENDMETHOD.


METHOD send_email.

  CALL FUNCTION 'ZSEND_EMAIL'
    EXPORTING
      document_data                    = document_data
     put_in_outbox                    = 'X'
     commit_work                      = 'X'
     sender_address                   = sender
*    SENDER_ADDRESS_TYPE              =
*  IMPORTING
*    SENT_TO_ALL                      =
*    NEW_OBJECT_ID                    =
    TABLES
     packing_list                     = packing_list
     object_header                    = object_header
    contents_bin                     = contents_bin
    contents_txt                     = contents_txt
*    CONTENTS_HEX                     =
*    OBJECT_PARA                      =
*    OBJECT_PARB                      =
     receivers                        = receivers
   EXCEPTIONS
     too_many_receivers               = 1
     document_not_sent                = 2
     document_type_not_exist          = 3
     operation_no_authorization       = 4
     parameter_error                  = 5
     x_error                          = 6
     enqueue_error                    = 7
     OTHERS                           = 8
            .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDMETHOD.


METHOD ship_to.

  DATA:lv_cnt TYPE n VALUE 0,
       lw_ship_addr TYPE LINE OF zread_text.

  gw_bill_ship-plant     = lw_poitem-werks.
  gw_bill_ship-stge_loc  = lw_poitem-lgort.
  gw_bill_ship-item      = lw_poitem-ebelp.

  gw_bill_ship-name1       = gw_adrc-name1.                 "CMS27120
  gw_bill_ship-address     = gw_adrc-addrnumber.
  gw_bill_ship-str_suppl1  = gw_adrc-str_suppl1.
  gw_bill_ship-str_suppl2  = gw_adrc-str_suppl2.
  gw_bill_ship-str_suppl3  = gw_adrc-str_suppl3.            "CMS277120

  IF gw_adrc-house_num1 IS NOT INITIAL.
CONCATENATE gw_adrc-house_num1 ' ' gw_adrc-street INTO zhouse_street SEPARATED BY space.
    gw_bill_ship-street     = zhouse_street.
  ELSE.
    gw_bill_ship-street     = gw_adrc-street.
  ENDIF.

  gw_bill_ship-city       = gw_adrc-city1.
  gw_bill_ship-district   = gw_adrc-city2.
  gw_bill_ship-postl_cod1 = gw_adrc-post_code1.

  READ TABLE lt_t005t INTO lw_t005t  WITH  KEY land1 = gw_adrc-country
                                               spras = zpoheader-spras.
  IF sy-subrc = 0.
    gw_bill_ship-landx50 = lw_t005t-landx50.
  ENDIF.

*-Ship-to Address
  IF gw_adrc-name1 IS NOT INITIAL OR gw_adrc-addrnumber IS NOT INITIAL
     OR gw_adrc-str_suppl1 IS NOT INITIAL OR
        gw_adrc-str_suppl2 IS NOT INITIAL OR
        gw_adrc-str_suppl3 IS NOT INITIAL.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = text-006.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Name1 one address from ADRC
  IF gw_adrc-name1 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-name1.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Street1 from ADRC
  IF gw_adrc-str_suppl1 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-str_suppl1.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Street2 from ADRC
  IF gw_adrc-str_suppl2 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-str_suppl2.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Street3 from ADRC
  IF gw_adrc-str_suppl3 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-str_suppl3.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Street from ADRC
  IF gw_adrc-house_num1 IS NOT INITIAL.
    CONCATENATE gw_adrc-house_num1 ' ' gw_adrc-street INTO zhouse_street
    SEPARATED BY space.
    IF zhouse_street IS NOT INITIAL.
      lv_cnt = lv_cnt + 1.
      lw_ship_addr-tdformat = lv_cnt.
      lw_ship_addr-tdline = zhouse_street.
      APPEND lw_ship_addr TO gt_ship_addr.
    ENDIF.
  ELSE.
    IF gw_adrc-street IS NOT INITIAL.
      lv_cnt = lv_cnt + 1.
      lw_ship_addr-tdformat = lv_cnt.
      lw_ship_addr-tdline = gw_adrc-street.
      APPEND lw_ship_addr TO gt_ship_addr.
    ENDIF.
  ENDIF.

*-City1 from ADRC
  IF gw_adrc-city1 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-city1.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-City2 from ADRC
  IF gw_adrc-city2 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-city2.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Postal Code1 from ADRC
  IF gw_adrc-post_code1 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = gw_adrc-post_code1.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

*-Land1 from ADRC
  READ TABLE lt_t005t INTO lw_t005t  WITH  KEY land1 = gw_adrc-country
                                               spras = zpoheader-spras.
  IF lw_t005t-landx50 IS NOT INITIAL.
    lv_cnt = lv_cnt + 1.
    lw_ship_addr-tdformat = lv_cnt.
    lw_ship_addr-tdline = lw_t005t-landx50.
    APPEND lw_ship_addr TO gt_ship_addr.
  ENDIF.

ENDMETHOD.


METHOD tax_cond.


  CLEAR : wa_komv1.

  READ TABLE it_komv INTO wa_komv1
            WITH KEY kschl = zkschl.

  IF sy-subrc EQ 0.

    IF zkrech = wa_komv1-krech.

      kwert = wa_komv1-kwert.
      kbetr = wa_komv1-kbetr / 10.

      chng_count = zcount + 1.

    ENDIF.

  ENDIF.

ENDMETHOD.


METHOD tax_cond1.


  CLEAR: wa_komv1.

  READ TABLE it_komv INTO wa_komv1
               WITH KEY kschl =  zkschl.

  IF sy-subrc EQ 0.
    kbetr = wa_komv1-kbetr / 10.
    kwert = wa_komv1-kwert.
  ENDIF.



ENDMETHOD.
ENDCLASS.

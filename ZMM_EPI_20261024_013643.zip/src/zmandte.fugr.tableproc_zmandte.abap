*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMANDTE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMANDTE             .

  PERFORM TABLEPROC.

ENDFUNCTION.

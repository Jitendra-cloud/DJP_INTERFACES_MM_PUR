*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3SY
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3SY                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME10022_DEST
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME10022_DEST       .

  PERFORM TABLEPROC.

ENDFUNCTION.

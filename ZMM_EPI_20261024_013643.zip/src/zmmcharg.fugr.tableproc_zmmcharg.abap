*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMMCHARG
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMMCHARG            .

  PERFORM TABLEPROC.

ENDFUNCTION.

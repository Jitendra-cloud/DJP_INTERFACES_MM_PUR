*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 02/27/2003 at 15:55:49 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMEXCESLOSTOPP..................................*
DATA:  BEGIN OF STATUS_ZMEXCESLOSTOPP                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMEXCESLOSTOPP                .
CONTROLS: TCTRL_ZMEXCESLOSTOPP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMEXCESLOSTOPP                .
TABLES: ZMEXCESLOSTOPP                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z2MV
*   generation date: 2003.04.16 at 13:38:45 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z2MV               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

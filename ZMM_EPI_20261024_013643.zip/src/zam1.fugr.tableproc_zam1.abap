*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZAM1
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZAM1                .

  PERFORM TABLEPROC.

ENDFUNCTION.

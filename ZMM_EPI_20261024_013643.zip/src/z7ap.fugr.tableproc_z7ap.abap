*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z7AP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z7AP                .

  PERFORM TABLEPROC.

ENDFUNCTION.

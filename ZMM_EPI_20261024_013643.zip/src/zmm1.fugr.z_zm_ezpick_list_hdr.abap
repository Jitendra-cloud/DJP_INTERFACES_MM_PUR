FUNCTION Z_ZM_EZPICK_LIST_HDR.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(MODE_ZPICK_LIST_HDR) TYPE  ENQMODE DEFAULT 'E'
*"     VALUE(CLIENT) TYPE  ZPICK_LIST_HDR-CLIENT DEFAULT SY-MANDT
*"     VALUE(PICKTYPE) TYPE  ZPICK_LIST_HDR-PICKTYPE OPTIONAL
*"     VALUE(AUFNR) TYPE  ZPICK_LIST_HDR-AUFNR OPTIONAL
*"     VALUE(RSNUM) TYPE  ZPICK_LIST_HDR-RSNUM OPTIONAL
*"     VALUE(PLANT) TYPE  ZPICK_LIST_HDR-PLANT OPTIONAL
*"     VALUE(X_PICKTYPE) DEFAULT SPACE
*"     VALUE(X_AUFNR) DEFAULT SPACE
*"     VALUE(X_RSNUM) DEFAULT SPACE
*"     VALUE(X_PLANT) DEFAULT SPACE
*"     VALUE(_SCOPE) DEFAULT '3'
*"     VALUE(_SYNCHRON) DEFAULT SPACE
*"     VALUE(_COLLECT) TYPE  DDENQCOLL DEFAULT ' '
*"----------------------------------------------------------------------
* Generated function module for lock object EZPICK_LIST_HDR
* Please do not modify or copy this function module
* See ABAP Help for information on the SAP lock concept
* for key word 'ENQUEUE'


DATA: __seqta_tab TYPE SEQTA OCCURS 01 WITH HEADER LINE,
      __scope TYPE DDENQSCOPE,
      __synchron TYPE DDENQSYNC.
__synchron = _synchron.
__scope = _scope.


DATA: BEGIN OF %a_ZPICK_LIST_HDR,
*       Lock argument for table ZPICK_LIST_HDR
            CLIENT TYPE ZPICK_LIST_HDR-CLIENT,
            PICKTYPE TYPE ZPICK_LIST_HDR-PICKTYPE,
            AUFNR TYPE ZPICK_LIST_HDR-AUFNR,
            RSNUM TYPE ZPICK_LIST_HDR-RSNUM,
            PLANT TYPE ZPICK_LIST_HDR-PLANT,
      END OF %a_ZPICK_LIST_HDR.
* Initialization of lock argument:
CALL 'C_ENQ_WILDCARD' ID 'HEX0' FIELD %a_ZPICK_LIST_HDR.


* Assignment of lock parameters to lock fields:

IF NOT CLIENT IS INITIAL.
   MOVE CLIENT TO:
        %a_ZPICK_LIST_HDR-CLIENT.
ENDIF.

IF NOT PICKTYPE IS INITIAL OR
   NOT x_PICKTYPE IS INITIAL.
   MOVE PICKTYPE TO:
        %a_ZPICK_LIST_HDR-PICKTYPE.
ENDIF.

IF NOT AUFNR IS INITIAL OR
   NOT x_AUFNR IS INITIAL.
   MOVE AUFNR TO:
        %a_ZPICK_LIST_HDR-AUFNR.
ENDIF.

IF NOT RSNUM IS INITIAL OR
   NOT x_RSNUM IS INITIAL.
   MOVE RSNUM TO:
        %a_ZPICK_LIST_HDR-RSNUM.
ENDIF.

IF NOT PLANT IS INITIAL OR
   NOT x_PLANT IS INITIAL.
   MOVE PLANT TO:
        %a_ZPICK_LIST_HDR-PLANT.
ENDIF.


* Fill the lock table:

__seqta_tab-gname = 'ZPICK_LIST_HDR'.
__seqta_tab-gmode = MODE_ZPICK_LIST_HDR.
__seqta_tab-garg = %a_ZPICK_LIST_HDR.
APPEND __seqta_tab.


* Lock assigned:
PERFORM send_enqueue(saplsena)
        TABLES __seqta_tab
        USING '2' __scope ' ' __synchron 'EZPICK_LIST_HDR' _collect.




ENDFUNCTION.

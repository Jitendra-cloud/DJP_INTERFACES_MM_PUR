*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z3PP
*   generation date: 2003.05.12 at 14:50:33 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z3PP               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

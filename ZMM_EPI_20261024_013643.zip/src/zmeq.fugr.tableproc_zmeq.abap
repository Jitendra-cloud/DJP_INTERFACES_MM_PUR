*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMEQ
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMEQ                .

  PERFORM TABLEPROC.

ENDFUNCTION.

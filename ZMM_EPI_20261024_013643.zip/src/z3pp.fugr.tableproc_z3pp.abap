*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3PP
*   generation date: 2003.05.12 at 14:50:33 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3PP                .

  PERFORM TABLEPROC.

ENDFUNCTION.

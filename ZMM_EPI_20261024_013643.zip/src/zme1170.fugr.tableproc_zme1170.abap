*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME1170
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME1170             .

  PERFORM TABLEPROC.

ENDFUNCTION.

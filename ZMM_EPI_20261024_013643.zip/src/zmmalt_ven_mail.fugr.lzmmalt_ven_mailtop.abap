FUNCTION-POOL ZMMALT_VEN_MAIL            MESSAGE-ID SV.

* INCLUDE LZMMALT_VEN_MAILD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMMALT_VEN_MAILT00                     . "view rel. data dcl.

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZMI437_CON_WERKS
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZMI437_CON_WERKS   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

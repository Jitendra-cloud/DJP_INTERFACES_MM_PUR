*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMDM2998
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMDM2998            .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z2SR
*   generation date: 06/17/2003 at 16:33:13 by user HRGOMEZ
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z2SR                .

  PERFORM TABLEPROC.

ENDFUNCTION.

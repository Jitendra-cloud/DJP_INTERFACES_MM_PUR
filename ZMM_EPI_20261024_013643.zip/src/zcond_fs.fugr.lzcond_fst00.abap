*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCOND_FS........................................*
DATA:  BEGIN OF STATUS_ZCOND_FS                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCOND_FS                      .
CONTROLS: TCTRL_ZCOND_FS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCOND_FS                      .
TABLES: ZCOND_FS                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZM5P
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZM5P                .

  PERFORM TABLEPROC.

ENDFUNCTION.

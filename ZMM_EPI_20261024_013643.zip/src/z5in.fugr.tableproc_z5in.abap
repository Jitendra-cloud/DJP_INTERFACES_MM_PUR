*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5IN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5IN                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME1170_DOCS_B2B................................*
DATA:  BEGIN OF STATUS_ZME1170_DOCS_B2B              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME1170_DOCS_B2B              .
CONTROLS: TCTRL_ZME1170_DOCS_B2B
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME1170_DOCS_B2B              .
TABLES: ZME1170_DOCS_B2B               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

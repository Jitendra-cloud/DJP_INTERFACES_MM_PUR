"Name: \PR:SAPLMLSL\FO:MODIFY_SCREEN\SE:END\EI
ENHANCEMENT 0 ZMM_ESYL051_PR_FIELD_CHANGES.
*Begin of changes mkasina/S0VK907604/ 2000001885
*need to grey out multiple documen type and plant in limits tab.
*Grey out overal all limit, expected value and No limit fields in limits tab
IF ( sy-tcode = 'ME51N' OR sy-tcode = 'ME52N' OR sy-tcode = 'ME53N' OR sy-tcode = 'ME54N' ).
  DATA:gv_bsart TYPE bsart.
  DATA : gv_werks TYPE char20.
  IMPORT gv_bsart TO gv_bsart FROM  MEMORY ID 'LV_DOCTYP'.
  IMPORT gv_werks TO gv_werks FROM  MEMORY ID 'LV_PLANT'.
  IF gv_werks(2) = 'FL' .
    gv_werks = 'FL'.
  endif .

  IF gv_bsart  IS NOT INITIAL and gv_werks is NOT INITIAL .
    CONSTANTS : lv_key1 TYPE char20 value 'SERVICEPR',
                lv_key2 TYPE char20 VALUE 'BSART',
                lv_key3 TYPE char20 VALUE 'PSTYP',
                lv_key4 TYPE char20 VALUE 'WERKS',
                lv_value3 TYPE char20 VALUE 'D'.
      data :    lv_value2 TYPE char20,
                lv_value4 TYPE char20.
             lv_value2 = gv_bsart.

    SELECT * FROM zmmfld INTO TABLE @DATA(lt_zmmfld)
             WHERE key1 = @lv_key1
             AND   key2 = @lv_key2
             AND   key3 = @lv_key3
             AND   key4 = @lv_key4
             AND   value2 = @lv_value2
             AND   value3 = @lv_value3
             AND   value4 = @gv_werks.
    IF sy-subrc = 0 .
      LOOP AT SCREEN.
        IF screen-name  = 'ESUH-SUMLIMIT'   OR
           screen-name  = 'ESUH-COMMITMENT' OR
           screen-name  = 'ESUH-SUMNOLIM'.
          screen-input = 0.
          MODIFY SCREEN.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDIF.

*End of changes mkasina/S0VK907604/ 2000001885
ENDENHANCEMENT.

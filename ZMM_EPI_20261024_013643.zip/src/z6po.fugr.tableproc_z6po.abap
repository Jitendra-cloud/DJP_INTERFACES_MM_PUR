*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z6PO
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z6PO                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMBATCHR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMBATCHR            .

  PERFORM TABLEPROC.

ENDFUNCTION.

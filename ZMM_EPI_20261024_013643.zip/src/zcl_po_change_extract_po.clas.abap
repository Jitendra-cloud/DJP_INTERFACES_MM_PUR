class ZCL_PO_CHANGE_EXTRACT_PO definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ty_open_po,
          werks type ekpo-werks,
          ebeln type ekpo-ebeln,
          ebelp type ekpo-ebelp,
          loekz type ekpo-loekz,
          elikz type ekpo-elikz,
          erekz type ekpo-erekz,
          newgl type ekkn-sakto,
          sakto type ekkn-sakto,
    END OF ty_open_po .
  types:
    BEGIN OF ty_pochg_xls,
          ebeln type ekpo-ebeln,
          ebelp(10), "type ekpo-ebelp,
          newgl type ekkn-sakto,
          sakto type ekkn-sakto,
    END OF ty_pochg_xls .
  types:
    BEGIN OF ty_pochg_unx,
          ebeln type ekpo-ebeln,
          space1(1),
          ebelp(5), "type ekpo-ebelp,
          space2(1),
          newgl type ekkn-sakto,
          space3(1),
          sakto type ekkn-sakto,
    END OF ty_pochg_unx .

  data:
    IT_OPEN_PO type STANDARD TABLE OF ty_open_po .
  data:
    IT_ZMMFLD  type TABLE OF zmmfld .
  data:
    IT_T001W   TYPE TABLE OF t001w .
  data:
    IT_POCHG_XLS type TABLE OF ty_pochg_xls .
  data WA_POCHG_UNX type TY_POCHG_UNX .

  methods CONSTRUCTOR .
  methods EXTRACT_OPEN_PURCHASE_ORDERS
    importing
      !IV_WERKS type RSELOPTION
      !IV_EBELN type RSELOPTION
      !IV_EBELP type RSELOPTION
      !IV_SAKTO type RSELOPTION
      !IV_BSTYP type RSELOPTION .
  methods REPLACE_WITH_NEW_GL .
protected section.
private section.
ENDCLASS.



CLASS ZCL_PO_CHANGE_EXTRACT_PO IMPLEMENTATION.


  METHOD constructor.
    REFRESH: it_t001w, it_zmmfld.
*---Select Plants/Branches data.
    SELECT * FROM t001w INTO TABLE it_t001w.
    SORT it_t001w BY werks.
*---Select zmmfld info.
    SELECT * FROM zmmfld INTO TABLE it_zmmfld WHERE
                                            key1 = 'C10120'.
    SORT it_zmmfld BY key1 key2 key3.
  ENDMETHOD.


  METHOD extract_open_purchase_orders.
*---Select Open PO Items.
    SELECT ekpo~werks
           ekko~ebeln
           ekpo~ebelp
           ekpo~loekz
           ekpo~elikz
           ekpo~erekz
           ekkn~sakto
           INTO CORRESPONDING FIELDS OF TABLE it_open_po
      FROM ekpo
      INNER JOIN ekko ON ( ekpo~ebeln = ekko~ebeln )
      INNER JOIN ekkn ON ( ekpo~ebeln = ekkn~ebeln AND
                           ekpo~ebelp = ekkn~ebelp )
      WHERE ( ekpo~werks IN iv_werks
        AND   ekpo~ebeln IN iv_ebeln
        AND   ekpo~ebelp IN iv_ebelp
        AND   ekkn~sakto IN iv_sakto
        AND   ekpo~loekz EQ space          "Deletion Indicator in Purchasing Document
        AND   ekpo~elikz EQ space          "Delivery Completed" Indicator
        AND   ekpo~erekz EQ space          "Final Invoice Indicator
        AND   ekko~bstyp IN iv_bstyp ).    "Document Category.
*         AND   ekko~bsart IN s_bsart
*         AND   ekko~bsart NE 'UB'         " Purch doc type

  ENDMETHOD.


  METHOD replace_with_new_gl.
    DATA: wa_t001w     LIKE LINE OF it_t001w,
          wa_zmmfld    LIKE LINE OF it_zmmfld,
          wa_open_po   LIKE LINE OF it_open_po,
          wa_pochg_xls LIKE LINE OF it_pochg_xls.

    FIELD-SYMBOLS:  <fs_open_po> LIKE LINE OF it_open_po.

    LOOP AT it_open_po ASSIGNING <fs_open_po>.
      SHIFT <fs_open_po>-sakto LEFT DELETING LEADING '0'.

      CLEAR wa_t001w.
      READ TABLE it_t001w  INTO wa_t001w WITH KEY werks = <fs_open_po>-werks.
      IF wa_t001w-land1 = 'US'.
        CLEAR wa_zmmfld.
        READ TABLE it_zmmfld INTO wa_zmmfld WITH KEY key1 = 'C10120'
                                                     key2 = <fs_open_po>-sakto
                                                     key3 = wa_t001w-land1.
        IF sy-subrc = 0.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = wa_zmmfld-value1
            IMPORTING
              output = <fs_open_po>-newgl.
        ENDIF.
      ELSE.
        CLEAR wa_zmmfld.
        READ TABLE it_zmmfld INTO wa_zmmfld WITH KEY key1 = 'C10120'
                                                     key2 = <fs_open_po>-sakto.
        IF sy-subrc = 0.
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = wa_zmmfld-value2
            IMPORTING
              output = <fs_open_po>-newgl.
        ENDIF.
      ENDIF.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <fs_open_po>-sakto
        IMPORTING
          output = <fs_open_po>-sakto.
    ENDLOOP.

*---Add Header.
    REFRESH it_pochg_xls[].
    CLEAR wa_pochg_xls.
    wa_pochg_xls-ebeln = 'PO Number'.
    wa_pochg_xls-ebelp = 'Item'.
    wa_pochg_xls-newgl = 'New GL Acc'.
    wa_pochg_xls-sakto = 'Old GL Acc'.
    APPEND wa_pochg_xls TO it_pochg_xls.

*---Create table for xls output.
    LOOP AT it_open_po INTO wa_open_po.
      MOVE-CORRESPONDING wa_open_po TO wa_pochg_xls.
      APPEND wa_pochg_xls TO it_pochg_xls.
      CLEAR wa_pochg_xls.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

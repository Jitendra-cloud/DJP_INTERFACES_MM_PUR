*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5MQ
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5MQ                .

  PERFORM TABLEPROC.

ENDFUNCTION.

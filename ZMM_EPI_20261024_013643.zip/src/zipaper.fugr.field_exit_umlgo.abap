FUNCTION FIELD_EXIT_UMLGO.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(INPUT)
*"  EXPORTING
*"     REFERENCE(OUTPUT)
*"----------------------------------------------------------------------
SET PARAMETER ID 'UMLG' FIELD INPUT.

OUTPUT = INPUT.

ENDFUNCTION.

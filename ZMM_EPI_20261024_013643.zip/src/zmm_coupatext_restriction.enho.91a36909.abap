"Name: \PR:SAPLMEGUI\TY:LCL_LONGTEXT_VIEW\ME:TRANSPORT_FROM_MODEL\SE:END\EI
ENHANCEMENT 0 ZMM_COUPATEXT_RESTRICTION.
* BOC by NBUSINE #S0VK912622 #2000002804 #SCTASK0092817
" Disable fields coupa-IDHeader, Coupa Status & Coupa-IDItem
" at PO creation & change if user not belongs valid usergroups
" or ZMMFLD

DATA: lt_coupatext TYPE MMPUR_T_TEXTLINES,
              ls_coupatext TYPE LINE OF MMPUR_T_TEXTLINES,
              s_coupauser TYPE RANGE OF xubname,
              ls_coupauser LIKE LINE OF s_coupauser,
              lv_bname TYPE xubname,
              ls_coupazmmfld TYPE zmmfld.

        CONSTANTS: lccoupa TYPE ZKEY1 VALUE 'ZCOUPA_PO_USER',
                   c_system TYPE XUCLASS VALUE 'IT-SYSTEM',
                   c_systemjob TYPE xuclass VALUE 'IT-SYSTEMJOB',
                   c_firefighter TYPE xuclass VALUE 'FIREFIGHTER'.

        ls_coupauser-sign = 'I'.
          ls_coupauser-option = 'EQ'.

    "Get entries from ZMMFLD
    SELECT * FROM zmmfld INTO ls_coupazmmfld
      WHERE key1 = lccoupa.
      ls_coupauser-low = ls_coupazmmfld-value1.
      APPEND ls_coupauser TO s_coupauser.
      ls_coupauser-low = ls_coupazmmfld-value2.
      APPEND ls_coupauser TO s_coupauser.
      ls_coupauser-low = ls_coupazmmfld-value3.
      APPEND ls_coupauser TO s_coupauser.
      ls_coupauser-low = ls_coupazmmfld-value4.
      APPEND ls_coupauser TO s_coupauser.
      ls_coupauser-low = ls_coupazmmfld-value5.
      APPEND ls_coupauser TO s_coupauser.
      ls_coupauser-low = ls_coupazmmfld-value6.
      APPEND ls_coupauser TO s_coupauser.
      ls_coupauser-low = ls_coupazmmfld-value7.
      APPEND ls_coupauser TO s_coupauser.
    ENDSELECT.

    DELETE s_coupauser[] WHERE low = space.

      LOOP AT lt_texttypes ASSIGNING <text_type> WHERE ( tdid = 'F60' OR tdid = 'F11' OR tdid = 'F70' ).

      CLEAR: lv_bname, ls_coupazmmfld, ls_coupauser, s_coupauser[].
"Get entries from USR02 for user groups
      SELECT SINGLE bname FROM USR02 INTO lv_bname WHERE bname = sy-uname AND
                                                                   class in (c_system,
                                                                             c_systemjob,
                                                                             c_firefighter).
        IF sy-subrc <> 0.

    CLEAR: ls_coupauser.
    READ TABLE s_coupauser INTO ls_coupauser with key low = sy-uname.
    IF sy-subrc <> 0.
     <text_type>-displaymode = 'X'.
     ENDIF.

     CALL FUNCTION 'MMPUR_TEXT_EXP_SUBSCREEN'
      EXPORTING
        im_textobject = l_tdobject
        im_language   = l_language
      TABLES
        imt_texttypes = lt_texttypes
        imt_textlines = lt_all_lines.

     ENDIF.
     ENDLOOP.
* EOC by NBUSINE #S0VK912622 #2000002804 #SCTASK0092817
ENDENHANCEMENT.

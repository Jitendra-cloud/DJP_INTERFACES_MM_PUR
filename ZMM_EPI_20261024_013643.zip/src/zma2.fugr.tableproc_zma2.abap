*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMA2
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMA2                .

  PERFORM TABLEPROC.

ENDFUNCTION.

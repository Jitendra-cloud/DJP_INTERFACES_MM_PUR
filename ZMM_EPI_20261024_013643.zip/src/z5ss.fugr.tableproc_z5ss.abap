*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5SS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5SS                .

  PERFORM TABLEPROC.

ENDFUNCTION.

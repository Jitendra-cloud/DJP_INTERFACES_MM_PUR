*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z7VN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z7VN                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCOND_FS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCOND_FS            .

  PERFORM TABLEPROC.

ENDFUNCTION.

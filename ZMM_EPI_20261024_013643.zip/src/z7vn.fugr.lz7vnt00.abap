*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZVNXT...........................................*
DATA:  BEGIN OF STATUS_ZVNXT                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVNXT                         .
CONTROLS: TCTRL_ZVNXT
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZVRQM...........................................*
DATA:  BEGIN OF STATUS_ZVRQM                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVRQM                         .
CONTROLS: TCTRL_ZVRQM
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZVNXT                         .
TABLES: *ZVRQM                         .
TABLES: ZVNXT                          .
TABLES: ZVRQM                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z2MN
*   generation date: 2003.05.12 at 14:52:14 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z2MN                .

  PERFORM TABLEPROC.

ENDFUNCTION.

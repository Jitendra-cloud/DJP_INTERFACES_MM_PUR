*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZR1086_LOFT_PRTS................................*
DATA:  BEGIN OF STATUS_ZR1086_LOFT_PRTS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZR1086_LOFT_PRTS              .
CONTROLS: TCTRL_ZR1086_LOFT_PRTS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZR1086_LOFT_PRTS              .
TABLES: ZR1086_LOFT_PRTS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

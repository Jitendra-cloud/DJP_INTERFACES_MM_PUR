class ZCL_IM_MME_PROCESS_PO_CUST definition
  public
  final
  create public .

public section.
*"* public components of class ZCL_IM_MME_PROCESS_PO_CUST
*"* do not include other source files here!!!
  type-pools MMMFD .

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ME_PROCESS_PO_CUST .

  data ZERROR_FLAG type STRING .
  data ZZ_SRVC_EMAIL type STRING .
protected section.
*"* protected components of class ZCL_IM_MME_PROCESS_PO_CUS
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_MME_PROCESS_PO_CUST
*"* do not include other source files here!!!

  class-data GV_CLM_FLAG type ABAP_BOOL .

  class-methods VALIDATION_GCF
    importing
      value(IS_MEPOHEADER) type MEPOHEADER optional
      value(IS_MEPOITEM) type MEPOITEM optional
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM optional .
  class-methods VALIDATE_DOC_TYPE_GCF
    importing
      !IS_MEPOHEADER type MEPOHEADER .
  class-methods VALIDATE_RETRUN_DIV_GCF
    importing
      !IS_MEPOHEADER type MEPOHEADER
      !IS_MEPOITEM type MEPOITEM
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
ENDCLASS.



CLASS ZCL_IM_MME_PROCESS_PO_CUST IMPLEMENTATION.


method IF_EX_ME_PROCESS_PO_CUST~CHECK .
* New code Inserted by SRAMASA 07/25/2006 -CMS#6069 -Start "E0VK920751
INCLUDE mm_messages_mac. "useful macros for message handling
IF zerror_flag = 'X'.
  mmpur_metafield 90000010.
  mmpur_message 'E' '38' '000' text-011 ' ' ' ' ' '.
ENDIF.
* New code Inserted by SRAMASA 07/25/2006 -CMS#6069 -End   "E0VK920751
endmethod.


method IF_EX_ME_PROCESS_PO_CUST~CLOSE .

************************************************************************
**************** F L E X I B L E -- S H I P P I N G ********************
************************************************************************
*----------------------------------------------------------------------*
* Anand Dhumbala 04/01/2008
* Sunil Paleru   04/01/2008 EDEK911668  STO Close for Flexible Shipments
*
* PRAGUPA        06/23/2008 EDEK912214    V2 Rollback                  *
*----------------------------------------------------------------------*
*** This Method/Code will be called once the STO changes are complete and
*** before opening the next STO.
** Refreshing the Memory ID's

* Begin of V2 Rollback By PRAGUPA 06/23/2008 EDEK912214
*  DELETE FROM MEMORY ID 'STO_CLOSE'.
*  DELETE FROM MEMORY ID 'STO_CLOSE1'.
* End of V2 Rollback By PRAGUPA 06/23/2008 EDEK912214

endmethod.


METHOD if_ex_me_process_po_cust~fieldselection_header .
  FIELD-SYMBOLS: <fs> LIKE LINE OF ch_fieldselection.
  DATA         :  fstatus(1) TYPE c.

* This is a dummy field that we are setting the attribute for.
  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
             KEY metafield = mmmfd_cust_08.
  IF sy-subrc IS INITIAL.
    <fs>-fieldstatus = '*'. " Display
  ENDIF.

***(Begin)-E0VK917081***E3097************************************
  CLEAR fstatus.
  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
             KEY metafield = 90000010.
  IF sy-subrc IS INITIAL.
    MOVE <fs>-fieldstatus TO fstatus.
    IF fstatus IS INITIAL.
      <fs>-fieldstatus = '.'.
    ENDIF.
  ENDIF.
***(End)-E0VK917081****E3097*************************************

*--Begin of change<EDGE Trade Order process 03302006>> EDEK905044
*--chaged to edit fields for 90000013,90000015>>EDVK947650>>06292006

  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
                                KEY metafield = 90000011.
  IF sy-subrc IS INITIAL.
    <fs>-fieldstatus = '*'.
  ENDIF.

  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
                                KEY metafield = 90000012.
  IF sy-subrc IS INITIAL.
    <fs>-fieldstatus = '*'.
  ENDIF.

  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
                                KEY metafield = 90000013.
  IF sy-subrc IS INITIAL.
    IF <fs>-fieldstatus IS INITIAL.
      <fs>-fieldstatus = '.'.
    ENDIF.
  ENDIF.

  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
                                KEY metafield = 90000014.
  IF sy-subrc IS INITIAL.
    <fs>-fieldstatus = '*'.
  ENDIF.

  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
                                KEY metafield = 90000015.
  IF sy-subrc IS INITIAL.
    IF <fs>-fieldstatus IS INITIAL.
      <fs>-fieldstatus = '.'.
    ENDIF.
  ENDIF.
*--End of change for<EDGE Trade Order process 03302006>>EDEK905044

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method FIELDSELECTION_HEADER| START
  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
                                KEY metafield = 90000030.
  IF sy-subrc IS INITIAL.
    IF <fs>-fieldstatus IS INITIAL.
      <fs>-fieldstatus = '.'.
    ENDIF.
  ENDIF.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/02/14| Changed: Method FIELDSELECTION_HEADER| END

ENDMETHOD.


method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_HEADER_REFKEYS .
endmethod.


METHOD if_ex_me_process_po_cust~fieldselection_item .
  FIELD-SYMBOLS: <fs> LIKE LINE OF ch_fieldselection.

* This is a dummy field that we are setting the attribute for.
  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
             KEY metafield = mmmfd_cust_08.
  IF sy-subrc IS INITIAL.
    <fs>-fieldstatus = '*'. " Display
  ENDIF.

* Begin CR# 11169 Recovered Fiber
  READ TABLE ch_fieldselection ASSIGNING <fs> WITH TABLE
           KEY metafield = 90000029.
  IF sy-subrc IS INITIAL.
    <fs>-fieldstatus = '*'. " Display
  ENDIF.
* End CR# 11169 Recovered Fiber

ENDMETHOD.


method IF_EX_ME_PROCESS_PO_CUST~FIELDSELECTION_ITEM_REFKEYS .
endmethod.


method IF_EX_ME_PROCESS_PO_CUST~INITIALIZE .
* New code Inserted by SRAMASA 07/25/2006 -CMS#6069 -Start "E0VK920751
   CLEAR zerror_flag.
   CALL FUNCTION 'MEPOBADIEX_INIT'.
* New code Inserted by SRAMASA 07/25/2006 -CMS#6069 -End   "E0VK920751
endmethod.


method IF_EX_ME_PROCESS_PO_CUST~OPEN .
* New code Inserted by SRAMASA 07/25/2006 -CMS#6069 -Start "E0VK920751
  DATA: ls_mepoheader TYPE mepoheader.
*---------------------------------------------------------------------*
* read customer data
*---------------------------------------------------------------------*
* this has to be done when we open a persistent object
  CHECK im_trtyp EQ 'V' OR im_trtyp EQ 'A'.

  ls_mepoheader = im_header->get_data( ).

* read customer data from database
  CALL FUNCTION 'MEPOBADIEX_OPEN'
    EXPORTING
      im_ebeln = ls_mepoheader-ebeln.
* New code Inserted by SRAMASA 07/25/2006 -CMS#6069 -End   "E0VK920751

endmethod.


METHOD if_ex_me_process_po_cust~post .

************************************************************************
**************** F L E X I B L E -- S H I P P I N G ********************
************************************************************************
*----------------------------------------------------------------------*
* Anand Dhumbala 04/01/2008
* Sunil Paleru   04/01/2008 EDEK911668  STO Close for Flexible Shipments
*PRAGUPA        05/29/2008 EDEK912214  Added the code in separate
*include
*                                       ZDL_FLEX_STO_CLOSE_METH_POST
*
* PRAGUPA        06/23/2008 EDEK912214    V2 Rollback                  *
*----------------------------------------------------------------------*
*This Method/Code will be called only once for a STO change, while
*saving
* This include program has code for STO close during ME22n.
* This include program imports the date/time set in the method
* "PROCESS_ITEM", Calculates the Time Delay for the Idoc to be sent
* and updates the NAST table

* Begin of V2 Rollback By PRAGUPA 06/23/2008 EDEK912214
*  Include ZDL_FLEX_STO_CLOSE_METH_POST.
* End of V2 Rollback By PRAGUPA 06/23/2008 EDEK912214

*-Below Class/method is used to implement any development to distinguish
*-different inventory developments / MAIELY / 10172018
  CALL METHOD zcl_me_process_po_cust=>process_post
    EXPORTING
      im_ebeln  = im_ebeln
      im_header = im_header.

ENDMETHOD.


METHOD if_ex_me_process_po_cust~process_account .
*---------------------------------------------------------------------
* Change History:                                                      *
*  Programmer        Date        Req.#     Action                      *
* =================  ========== ========== ============================*
* J.Grabowiecki     03/2014 E0V 26320   Validate Cost Center/GL Account*
*                                       in ZCECV                       *
* APUNJAA           03/10/2017  31393   Accounting tab changes for     *
*                                       Unload Point, Profit ctr,      *
*                                       Business area                  *
*---------------------------------------------------------------------

*---------------------------------------------------------------------
* E0V 26320-start
  INCLUDE mm_messages_mac.

  DATA: ls_acct TYPE mepoaccounting.
  DATA: ls_head TYPE mepoheader.

  ls_acct = im_account->get_data( ).
  ls_head = im_account->get_item( )->get_header( )->get_data( ).

  IF ls_acct-kostl IS NOT INITIAL AND
     ls_acct-sakto IS NOT INITIAL.

    CALL FUNCTION 'ZMM_VALIDATE_CC_ACCT'
      EXPORTING
        i_kokrs = ls_acct-kokrs
        i_kostl = ls_acct-kostl
        i_hkont = ls_acct-sakto
        i_bsart = ls_head-bsart
      EXCEPTIONS
        invalid = 1
        OTHERS  = 2.

    IF sy-subrc <> 0.
      mmpur_message 'E' 'Z1' '016'
                    ls_acct-sakto ls_acct-kostl '' ''.
    ENDIF.
  ENDIF.
* E0V 26320-end
*---------------------------------------------------------------------

* CMS31393|ChangedBy:APUNJAA|ChangedOn:03102017|START
*->ARIBA PO INBOUND CHANGES

  DATA : t_po_accountdata  TYPE TABLE OF /arba/popush_csv_accdata,
         wa_po_accountdata TYPE /arba/popush_csv_accdata,
         t_accountdata     TYPE TABLE OF /arba/po_account_info, "/ARBA/PO_ACCOUNTS_INFO_T,
         wa_accountdata    TYPE /arba/po_account_info.

  CLEAR: wa_po_accountdata, wa_accountdata.
* Import header data
  DATA(ls_ariba_mepoheader)
     = im_account->get_item( )->get_header( )->get_data( ).

* Import CSV strcture wiht addtional fields
  IMPORT t_po_accountdata_mem TO t_po_accountdata FROM MEMORY ID 'ARIBA_CSV_ACCTDATA'.
  IMPORT t_accountdata_mem  TO t_accountdata FROM MEMORY ID 'ARIBA_CSV_ACCTDATACHG'.

  DATA(ls_ariba_acct) = im_account->get_data( ).

  IF ls_ariba_mepoheader-bsart EQ 'P2P' AND sy-cprog = '/ARBA/CR_BAPI_PO_CREATE1'.
* read the relevant line item from the CSV strcture for Unloading point
    READ TABLE t_po_accountdata INTO wa_po_accountdata WITH KEY erporderid = ls_ariba_mepoheader-unsez
                                                                   po_item = ls_acct-ebelp.
    IF sy-subrc EQ 0.
* map the unloading point
      ls_ariba_acct-ablad = wa_po_accountdata-cus_unloadingpoint.
      ls_ariba_acct-gsber = wa_po_accountdata-cus_ipbusinessarea.
      ls_ariba_acct-prctr = wa_po_accountdata-cus_ipprofitcenter.
    ENDIF.
*    ls_ariba_acct-ablad = 'Dummy Unload Point'.
    CALL METHOD im_account->set_data( ls_ariba_acct ).
  ENDIF.

  IF ls_ariba_mepoheader-bsart EQ 'P2P' AND sy-cprog = '/ARBA/CR_BAPI_PO_CHANGE'.
* read the relevant line item from the CSV strcture for Unloading point
    READ TABLE t_accountdata INTO wa_accountdata WITH KEY itemonreq = ls_acct-ebelp.
    IF sy-subrc EQ 0.
* map the unloading point
      ls_ariba_acct-ablad = wa_accountdata-cus_unloadingpoint.
      ls_ariba_acct-gsber = wa_accountdata-cus_ipbusinessarea.
      ls_ariba_acct-prctr = wa_accountdata-cus_ipprofitcenter.
    ENDIF.
*    ls_ariba_acct-ablad = 'Dummy Unload Point'.
    CALL METHOD im_account->set_data( ls_ariba_acct ).
  ENDIF.

* CMS31393|ChangedBy:APUNJAA|ChangedOn:03102017|START
ENDMETHOD.


METHOD if_ex_me_process_po_cust~process_header .
* Change History:                                                      *
*     Programmer      Date    Req. #            Action                 *
* ============== ========  ======     =================================*
* SMITHAI        8/16/2016 E0VK9A0LTI CMS30768: Retrieve Chg Service   *
*                                     Email CMS30067                   *
* Helena Malkowska 02/2018 E0V 33261  Project RFSCOP
*----------------------------------------------------------------------*


  CONSTANTS: lc_zmmfld_e10164 TYPE zmmfld-key1 VALUE 'E10164',
             lc_zmmfld_r03563 TYPE zmmfld-key1 VALUE 'R03563',
             lc_zmmfld_bukrs  TYPE zmmfld-key1 VALUE 'BUKRS',
             lc_contract      TYPE zmmfld-key1 VALUE 'CONTRACT',
             lc_numeric       TYPE zmmfld-key1 VALUE 'NUMERIC',
             lc_char          TYPE datatype_d VALUE 'CHAR',
             lc_numc          TYPE datatype_d VALUE 'NUMC',
             lc_zmmfld_knttp  TYPE zmmfld-key1 VALUE 'KNTTP',
             lc_zmmfld_e10814 TYPE zmmfld-key1 VALUE 'E10814', "CMS 30771
             lc_tps           TYPE datatype_d VALUE 'TPS'.  "CMS 30771

  TYPES: BEGIN OF tt_zmmfld,
           value1 TYPE zmmfld-value1,
         END OF tt_zmmfld.

*
  DATA: lt_zmmfld_bukrs TYPE TABLE OF tt_zmmfld,
        lt_zmmfld_knttp TYPE TABLE OF tt_zmmfld,
        lt_zmmfld_ekorg TYPE TABLE OF tt_zmmfld,
        ls_zmmfld       TYPE tt_zmmfld.


  DATA: ls_mepoheader TYPE mepoheader,
        ls_tbsg       TYPE tbsg,
        w_prstat      TYPE zmtaid-z_prstat,
        lt_po_items   TYPE purchase_order_items,
        ls_po_item    TYPE mepoitem,
        lv_bstkd      TYPE bstkd,
        lv_vbeln      TYPE vbeln,
        lt_textlines  TYPE mmpur_t_textlines,
        ls_textline   LIKE LINE OF lt_textlines.


  DATA : w_left(9)     TYPE c,
         w_right(9)    TYPE c,
         w_dec(1)      TYPE c,
         w_compare(13) TYPE c.
  DATA : w_decimal(9) TYPE c,
         w_latitude   TYPE p DECIMALS 4,
         w_longitude  TYPE p DECIMALS 4,
         w_length     TYPE i.

  DATA : lv_treefarm TYPE mepoheader-zz_claim  VALUE 'TREE FARM',
         lv_sfi      TYPE mepoheader-zz_claim  VALUE 'SFI',
         lv_fsc      TYPE mepoheader-zz_claim  VALUE 'FSC',
*        lv_tree_fsc TYPE mepoheader-zz_claim  VALUE 'FSC/Tree F',
         lv_tree_fsc TYPE mepoheader-zz_claim  VALUE 'FSC/ATFS',
         lv_fsc_sfi  TYPE mepoheader-zz_claim  VALUE 'FSC/SFI',
*        lv_fsc_mix  TYPE mepoheader-zz_claim  VALUE 'FSC Mixed',
         lv_fsc_mix  TYPE mepoheader-zz_claim  VALUE 'FSC MIX',
         lv_fsc_100  TYPE mepoheader-zz_claim  VALUE 'FSC 100%'.


  FIELD-SYMBOLS:
           <ls_po_item> TYPE purchase_order_item.


  INCLUDE mm_messages_mac. "useful macros for message handling
*---------------------------------------------------------------------

* here we check customers data
*---------------------------------------------------------------------
  ls_mepoheader = im_header->get_data( ).

  EXPORT ekorg FROM ls_mepoheader-ekorg TO MEMORY ID 'EKORG'.
*  SET PARAMETER ID 'EKO' FIELD ls_mepoheader-ekorg.

*** CR12715 - Copy Customer PO # From SO to PO - begin***
  CLEAR: lv_bstkd, lt_zmmfld_bukrs, ls_zmmfld.
* Check company code is 'NL02'
  SELECT value1 FROM zmmfld INTO TABLE lt_zmmfld_bukrs WHERE
  key1 = lc_zmmfld_e10164
  AND key2 = lc_zmmfld_bukrs.
  IF NOT lt_zmmfld_bukrs IS INITIAL.
    READ TABLE lt_zmmfld_bukrs INTO ls_zmmfld
    WITH KEY value1 = ls_mepoheader-bukrs.
  ENDIF.
  IF ( ls_mepoheader-bukrs = ls_zmmfld-value1 )
    AND ( NOT ls_zmmfld-value1 IS INITIAL ).
    lt_po_items   = im_header->get_items( ).
    LOOP AT lt_po_items ASSIGNING <ls_po_item>.
* If it is not first item exit from the loop
      IF sy-tabix <> '1'.
        EXIT.
      ENDIF.
      ls_po_item  = <ls_po_item>-item->get_data( ).

* Check company code as V
      CLEAR: lt_zmmfld_knttp, ls_zmmfld, ls_zmmfld, lv_vbeln.
      SELECT value1 FROM zmmfld INTO TABLE lt_zmmfld_knttp WHERE
      key1 = lc_zmmfld_e10164
      AND key2 = lc_zmmfld_knttp.
      IF NOT lt_zmmfld_knttp IS INITIAL.
        READ TABLE lt_zmmfld_knttp INTO ls_zmmfld
        WITH KEY value1 = ls_po_item-knttp.
      ENDIF.
* validation
      IF ( ls_po_item-knttp = ls_zmmfld-value1 ) AND
         ( NOT ls_zmmfld-value1 IS INITIAL ) AND
        ( ls_po_item-banfn <> '0' OR
          ls_po_item-banfn <> '' ) AND
        ( ls_po_item-bnfpo <> '0' OR
          ls_po_item-bnfpo <> '' ).
        SELECT SINGLE vbeln INTO lv_vbeln
        FROM vbep WHERE banfn = ls_po_item-banfn
                  AND   bnfpo = ls_po_item-bnfpo.
        IF ( sy-subrc = 0 ) AND ( NOT lv_vbeln IS INITIAL ).
          SELECT SINGLE bstkd INTO lv_bstkd
          FROM vbkd WHERE vbeln = lv_vbeln.
        ENDIF.
* If customer purchase order number is available
* save it in header text
        IF NOT lv_bstkd IS INITIAL.
          ls_textline-tdobject  = 'TEXT'.
          ls_textline-tdid      = 'ST'.
          ls_textline-tdformat  = 'SP'.
          CONCATENATE 'Customer PO Number:' lv_bstkd INTO
          ls_textline-tdline SEPARATED BY space.
          APPEND ls_textline TO lt_textlines.
          im_header->if_longtexts_mm~set_text( im_tdid = 'F01'
                                              im_textlines = lt_textlines ).
          IF sy-subrc <> 0.
            mmpur_metafield 90000020.
            mmpur_message 'W' '38' '000' TEXT-060 '' '' ''.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.
**** CR12715 - Copy Customer PO # From SO to PO - end *****

  IF ls_mepoheader-loekz NE 'D'.
*   We need to validate that the TAID entered
*   is correct.
    IF NOT ls_mepoheader-zz_taid IS INITIAL.
      SELECT SINGLE z_prstat
        INTO w_prstat
        FROM zmtaid
       WHERE z_taid = ls_mepoheader-zz_taid.
*     If we do not find the TAID or if PRSTAT
*     does not equal A we will generate an error.
      IF sy-subrc NE 0 OR
         w_prstat NE 'A'.
        mmpur_metafield mmmfd_cust_05.
*        mmpur_message_forced 'E' '38' '000' text-001
        mmpur_message 'E' '38' '000' TEXT-001
                             ls_mepoheader-zz_taid TEXT-002 ''.
      ENDIF.
    ENDIF.
  ENDIF.

  IF NOT ls_mepoheader-zz_cert_num_tf IS INITIAL.
    IF ls_mepoheader-zz_cert_treefarm IS INITIAL.
      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.
    ENDIF.
  ENDIF.

  IF NOT ls_mepoheader-zz_cert_num_sfi IS INITIAL.
    IF ls_mepoheader-zz_cert_sfi IS INITIAL.
      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.
    ENDIF.
  ENDIF.

  IF NOT ls_mepoheader-zz_cert_num_fsc IS INITIAL.
    IF ls_mepoheader-zz_cert_fsc       IS INITIAL.
      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.
    ENDIF.
  ENDIF.

  IF NOT ls_mepoheader-zz_cert_num_csa IS INITIAL.
    IF ls_mepoheader-zz_cert_csa       IS INITIAL.
      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.
    ENDIF.
  ENDIF.

  IF NOT ls_mepoheader-zz_claim IS INITIAL.
    IF ls_mepoheader-zz_landowner IS INITIAL.
      mmpur_metafield 90000024.
      mmpur_message 'E' '38' '000' TEXT-058 '' '' ''.
    ENDIF.
  ENDIF.


*  IF NOT ( ls_mepoheader-zz_claim IS INITIAL AND ls_mepoheader-zz_landowner IS INITIAL ).
  IF NOT ls_mepoheader-zz_claim IS INITIAL AND NOT ls_mepoheader-zz_landowner IS INITIAL.

    IF ls_mepoheader-zz_cert_treefarm NE 'X' AND
    ls_mepoheader-zz_cert_sfi         NE 'X' AND
    ls_mepoheader-zz_cert_fsc         NE 'X' AND
    ls_mepoheader-zz_cert_csa         NE 'X'.

      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

    ENDIF.
  ENDIF.

  IF ls_mepoheader-zz_cert_treefarm = 'X' AND
     ls_mepoheader-zz_cert_sfi      = 'X' AND
     ls_mepoheader-zz_cert_fsc      = 'X' AND
     ls_mepoheader-zz_cert_csa      = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_treefarm = 'X' AND
         ls_mepoheader-zz_cert_sfi      = 'X' AND
         ls_mepoheader-zz_cert_fsc      = 'X' .

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_sfi      = 'X' AND
         ls_mepoheader-zz_cert_fsc      = 'X' AND
         ls_mepoheader-zz_cert_csa      = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_treefarm = 'X' AND
         ls_mepoheader-zz_cert_fsc      = 'X' AND
         ls_mepoheader-zz_cert_csa      = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_treefarm   = 'X' AND
           ls_mepoheader-zz_cert_sfi      = 'X' AND
           ls_mepoheader-zz_cert_csa      = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_treefarm   = 'X' AND
         ls_mepoheader-zz_cert_csa        = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_sfi   = 'X' AND
         ls_mepoheader-zz_cert_csa   = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_fsc   = 'X' AND
        ls_mepoheader-zz_cert_csa   = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

  ELSEIF ls_mepoheader-zz_cert_treefarm   = 'X' AND
      ls_mepoheader-zz_cert_sfi           = 'X'.

    mmpur_metafield 90000020.
    mmpur_message 'E' '38' '000' TEXT-056 '' '' ''.

* Start of changes - CMS 14331 - LMATHE1
*  IF ls_mepoheader-zz_cert_treefarm = 'X'.
*    IF NOT ls_mepoheader-zz_cert_num_tf IS INITIAL.
*      CALL METHOD im_header->set_data( ls_mepoheader ).
*    ELSE.
*      mmpur_metafield 90000020.
*      mmpur_message 'E' '38' '000' text-017 '' '' ''.
*    ENDIF.
*  ENDIF.
*For Dual Certification Selection
  ELSEIF ls_mepoheader-zz_cert_treefarm = 'X' AND
         ls_mepoheader-zz_cert_fsc      = 'X' .

    IF ls_mepoheader-zz_cert_num_tf IS INITIAL.
      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-017 '' '' ''.
    ENDIF.

    IF ls_mepoheader-zz_cert_num_fsc IS INITIAL.
      mmpur_metafield 90000022.
      mmpur_message 'E' '38' '000' TEXT-054 '' '' ''.
    ENDIF.

    IF ls_mepoheader-zz_claim EQ lv_tree_fsc.
      CALL METHOD im_header->set_data( ls_mepoheader ).
    ELSE.
      IF ls_mepoheader-zz_claim IS INITIAL.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
      ELSE.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-051 '' '' ''.
      ENDIF.
    ENDIF.

  ELSEIF   ls_mepoheader-zz_cert_sfi = 'X' AND
           ls_mepoheader-zz_cert_fsc = 'X' .

    IF ls_mepoheader-zz_cert_num_sfi IS INITIAL.
      mmpur_metafield 90000020.
      mmpur_message 'E' '38' '000' TEXT-053 '' '' ''.
    ENDIF.

    IF ls_mepoheader-zz_cert_num_fsc IS INITIAL.
      mmpur_metafield 90000022.
      mmpur_message 'E' '38' '000' TEXT-054 '' '' ''.
    ENDIF.

    IF ls_mepoheader-zz_claim EQ lv_fsc_sfi.
      CALL METHOD im_header->set_data( ls_mepoheader ).
    ELSE.
      IF ls_mepoheader-zz_claim IS INITIAL.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
      ELSE.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-051 '' '' ''.
      ENDIF.
    ENDIF.

*Start of Change - CR-11349
  ELSEIF ls_mepoheader-zz_cert_treefarm = 'X'.

*    IF NOT ( ls_mepoheader-zz_cert_num_tf IS INITIAL AND ls_mepoheader-zz_claim IS INITIAL ).
    IF NOT ls_mepoheader-zz_cert_num_tf IS INITIAL AND NOT ls_mepoheader-zz_claim IS INITIAL .

      IF ls_mepoheader-zz_claim EQ lv_treefarm.
        CALL METHOD im_header->set_data( ls_mepoheader ).
      ELSE.

        IF ls_mepoheader-zz_claim IS INITIAL.
          mmpur_metafield 90000028.
          mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
        ELSE.
          mmpur_metafield 90000028.
          mmpur_message 'E' '38' '000' TEXT-051 '' '' ''.
        ENDIF.
      ENDIF.
    ELSE.
      IF ls_mepoheader-zz_cert_num_tf IS INITIAL.
        mmpur_metafield 90000020.
        mmpur_message 'E' '38' '000' TEXT-017 '' '' ''.
      ENDIF.
      IF ls_mepoheader-zz_claim IS INITIAL.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
      ENDIF.
    ENDIF.
*    ENDIF.

*IF ls_mepoheader-zz_cert_sfi = 'X' .
*    IF NOT ls_mepoheader-zz_cert_num_sfi IS INITIAL.
*      CALL METHOD im_header->set_data( ls_mepoheader ).
*    ELSE.
*      mmpur_metafield 90000021.
*      mmpur_message 'E' '38' '000' text-018 '' '' ''.
*    ENDIF.
*  ENDIF.


  ELSEIF ls_mepoheader-zz_cert_sfi = 'X' .

* IF NOT ( ls_mepoheader-zz_cert_num_sfi IS INITIAL AND ls_mepoheader-zz_claim IS INITIAL ).
    IF NOT ls_mepoheader-zz_cert_num_sfi IS INITIAL AND NOT ls_mepoheader-zz_claim IS INITIAL.

      IF ls_mepoheader-zz_claim EQ lv_sfi.
        CALL METHOD im_header->set_data( ls_mepoheader ).
      ELSE.

        IF ls_mepoheader-zz_claim IS INITIAL.
          mmpur_metafield 90000028.
          mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
        ELSE.
          mmpur_metafield 90000028.
          mmpur_message 'E' '38' '000' TEXT-051 '' '' ''.
        ENDIF.
      ENDIF.
    ELSE.
      IF ls_mepoheader-zz_cert_num_sfi IS INITIAL.
        mmpur_metafield 90000021.
        mmpur_message 'E' '38' '000' TEXT-053 '' '' ''.
      ENDIF.
      IF ls_mepoheader-zz_claim IS INITIAL.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
      ENDIF.
    ENDIF.
*    ENDIF.


*   IF ls_mepoheader-zz_cert_fsc = 'X' .
*    IF NOT ls_mepoheader-zz_cert_num_fsc IS INITIAL.
*      CALL METHOD im_header->set_data( ls_mepoheader ).
*    ELSE.
*      mmpur_metafield 90000022.
*      mmpur_message 'E' '38' '000' text-019 '' '' ''.
*    ENDIF.
*  ENDIF.

  ELSEIF ls_mepoheader-zz_cert_fsc = 'X' .
* IF NOT ( ls_mepoheader-zz_cert_num_fsc IS INITIAL AND ls_mepoheader-zz_claim IS INITIAL ).
    IF NOT ls_mepoheader-zz_cert_num_fsc IS INITIAL AND NOT ls_mepoheader-zz_claim IS INITIAL.


      IF ls_mepoheader-zz_claim EQ lv_fsc_mix OR ls_mepoheader-zz_claim EQ lv_fsc_100.
        CALL METHOD im_header->set_data( ls_mepoheader ).
      ELSE.

        IF ls_mepoheader-zz_claim IS INITIAL.
          mmpur_metafield 90000028.
          mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
        ELSE.
          mmpur_metafield 90000028.
          mmpur_message 'E' '38' '000' TEXT-051 '' '' ''.
        ENDIF.
      ENDIF.
    ELSE.
      IF ls_mepoheader-zz_cert_num_fsc IS INITIAL.
        mmpur_metafield 90000022.
        mmpur_message 'E' '38' '000' TEXT-054 '' '' ''.
      ENDIF.
      IF ls_mepoheader-zz_claim IS INITIAL.
        mmpur_metafield 90000028.
        mmpur_message 'E' '38' '000' TEXT-050 '' '' ''.
      ENDIF.
    ENDIF.
*ENDIF.


  ELSEIF ls_mepoheader-zz_cert_csa = 'X' .

    IF NOT ls_mepoheader-zz_claim IS INITIAL.
      mmpur_metafield 90000028.
      mmpur_message 'E' '38' '000' TEXT-057 '' '' ''.
    ENDIF.

    IF NOT ls_mepoheader-zz_cert_num_csa IS INITIAL.
      CALL METHOD im_header->set_data( ls_mepoheader ).
    ELSE.
      mmpur_metafield 90000023.
      mmpur_message 'E' '38' '000' TEXT-020 '' '' ''.
    ENDIF.
*    ENDIF.

  ENDIF.
*** Start Commented By DBANSOD : CMS 16205
*  IF NOT ls_mepoheader-zz_landowner IS INITIAL .
*    IF ls_mepoheader-zz_landowner CA '0123456789'.
*
*      mmpur_metafield 90000024.
*      mmpur_message 'E' '38' '000' text-021 '' '' ''.
*
*    ENDIF.
*  ENDIF.
*** End Commented By DBANSOD : CMS 16205

  SELECT SINGLE dcpfm INTO w_dec FROM usr01 WHERE bname = sy-uname.

  IF w_dec = 'X'.
    w_dec = '.'.
  ELSE.
    w_dec = ','.
  ENDIF.

  CONCATENATE '0123456789-' w_dec ' ' INTO w_compare.


  IF NOT ls_mepoheader-zz_latitude IS INITIAL .

    CONDENSE ls_mepoheader-zz_latitude NO-GAPS.

    IF ls_mepoheader-zz_latitude NA '1234567890'.
      mmpur_metafield 90000026.
      mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
    ENDIF.


    SPLIT ls_mepoheader-zz_latitude AT '-' INTO w_left w_right.
    IF w_right IS NOT INITIAL AND w_left IS NOT INITIAL.
      mmpur_metafield 90000026.
      mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
    ENDIF.

    IF ls_mepoheader-zz_latitude CO w_compare.

      SPLIT ls_mepoheader-zz_latitude AT w_dec INTO w_left w_right.

      IF w_right CA w_dec.
        mmpur_metafield 90000026.
        mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
      ENDIF.

      IF w_right CA '-' AND w_left CA '-'.
        mmpur_metafield 90000026.
        mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
      ENDIF.

      MOVE w_right TO w_decimal.

      w_length = strlen( w_decimal ).

      IF w_right CA '-'.
        w_length = w_length - 1.
      ENDIF.

      IF w_length > 4.
        mmpur_metafield 90000026.
        mmpur_message 'E' '38' '000' TEXT-025 '' '' ''.
      ENDIF.

    ELSE.

      mmpur_metafield 90000026.
      mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.

    ENDIF.

    MOVE ls_mepoheader-zz_latitude TO w_latitude.


    IF w_latitude LT -90 OR w_latitude GT 90.

      mmpur_metafield 90000026.
      mmpur_message 'E' '38' '000' TEXT-022 '' '' ''.

    ENDIF.

    WRITE w_latitude TO ls_mepoheader-zz_latitude.
    CALL METHOD im_header->set_data( ls_mepoheader ).

  ENDIF.

  CLEAR : w_left, w_right, w_decimal, w_length.

  IF NOT ls_mepoheader-zz_longitude IS INITIAL .

    CONDENSE ls_mepoheader-zz_longitude NO-GAPS.

    IF ls_mepoheader-zz_longitude NA '1234567890'.
      mmpur_metafield 90000027.
      mmpur_message 'E' '38' '000' TEXT-024'' '' ''.
    ENDIF.

    SPLIT ls_mepoheader-zz_longitude AT '-' INTO w_left w_right.
    IF w_right IS NOT INITIAL AND w_left IS NOT INITIAL.
      mmpur_metafield 90000027.
      mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
    ENDIF.

    IF ls_mepoheader-zz_longitude CO w_compare.

      SPLIT ls_mepoheader-zz_longitude AT w_dec INTO w_left w_right.

      IF w_right CA w_dec.
        mmpur_metafield 90000027.
        mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
      ENDIF.

      IF w_right CA '-' AND w_left CA '-'.
        mmpur_metafield 90000026.
        mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.
      ENDIF.

      MOVE w_right TO w_decimal.

      w_length = strlen( w_decimal ).

      IF w_right CA '-'.
        w_length = w_length - 1.
      ENDIF.

      IF w_length > 4.
        mmpur_metafield 90000027.
        mmpur_message 'E' '38' '000' TEXT-025 '' '' ''.
      ENDIF.

    ELSE.

      mmpur_metafield 90000027.
      mmpur_message 'E' '38' '000' TEXT-024 '' '' ''.

    ENDIF.

    MOVE ls_mepoheader-zz_longitude TO w_longitude.


    IF w_longitude LT -180 OR w_longitude GT 180.

      mmpur_metafield 90000027.
      mmpur_message 'E' '38' '000' TEXT-023 '' '' ''.

    ENDIF.

    WRITE w_longitude TO ls_mepoheader-zz_longitude.
    CALL METHOD im_header->set_data( ls_mepoheader ).
  ENDIF.

* End of changes - CMS 14331 - LMATHE1

******(Begin)-E0VK917081***E3097************************************
  DATA: BEGIN OF r_werks,
          ebelp TYPE ekpo-ebelp,
          werks TYPE ekpo-werks,
          email TYPE ekko-zz_srvc_email,
        END OF r_werks.

  DATA: l_po_item       TYPE REF TO if_purchase_order_item_mm,
        ls_mepoitem     TYPE STANDARD TABLE OF mepoitem
                                  INITIAL SIZE 0,
        lt_items        TYPE purchase_order_items,
        ls_item         LIKE LINE OF lt_items,
        int_werks       LIKE STANDARD TABLE OF r_werks
                              INITIAL SIZE 0,
        ws_werks        LIKE LINE OF int_werks,
        w_mepoitem      TYPE mepoitem,
        w_srvc_email    TYPE zmemail_loc-zemail,
        w_zipnet        TYPE zmipaperdir-zipnet,
*      w_error_flag(1)  TYPE c,
        w_wepos         TYPE ekpo-wepos,
        w_ebelp         TYPE ekpo-ebelp,
        ws_match        TYPE zmmfld-key1,
        ws_zmmfld(1)    TYPE c,
        w_werks         TYPE ekpo-werks,
        w_email_flag(1).

***Validate User with MM parameter table************
  ws_match = sy-uname.
  CALL FUNCTION 'Z_GET_MM_PARAMETER'
    EXPORTING
      p_key1     = 'ZME3097'
      p_key2     = 'USER_EXCEP'
      p_match    = ws_match
    IMPORTING
      avail_flag = ws_zmmfld.
  IF ws_zmmfld <> 'X'.
***Validate User with MM parameter table************

*---------------------------------------------------------------------
* here we check customers data
*---------------------------------------------------------------------
* CLEAR w_error_flag.
    ls_mepoheader = im_header->get_data( ).

* Get item objects from header
    CALL METHOD im_header->get_items
      RECEIVING
        re_items = lt_items.

* Get all line item
    CLEAR ls_mepoitem. REFRESH ls_mepoitem.
    LOOP AT lt_items INTO ls_item.
      l_po_item  = ls_item-item.
      w_mepoitem = l_po_item->get_data( ).
      APPEND w_mepoitem TO ls_mepoitem.
    ENDLOOP.

* Fill plant range with line items
    CLEAR : int_werks, w_mepoitem. REFRESH : int_werks.
    LOOP AT ls_mepoitem INTO w_mepoitem WHERE werks <> ' '.
      r_werks-ebelp    = w_mepoitem-ebelp.
      r_werks-werks    = w_mepoitem-werks.
      APPEND r_werks TO int_werks.
    ENDLOOP.
    CHECK NOT int_werks[] IS INITIAL.
    SORT int_werks BY ebelp.

*    call METHOD validate_clm_e10271
*    EXPORTING
*      is_mepoheader = ls_mepoheader " Purchase Order Header Data
*      is_mepoitem   = ls_mepoitem   " Purchase Order Item
*    .

    IF gv_clm_flag EQ abap_false. "CD 2000003643
* While Purchase Requist drag and drop
      CLEAR : w_mepoitem, w_srvc_email.
      IF ls_mepoheader-zz_srvc_email IS INITIAL.
        LOOP AT ls_mepoitem INTO w_mepoitem WHERE banfn <> ' '.
          SELECT SINGLE zz_srvc_email INTO w_srvc_email
          FROM eban WHERE banfn = w_mepoitem-banfn AND
                          bnfpo = w_mepoitem-bnfpo.
          IF sy-subrc =  0.
            ls_mepoheader-zz_srvc_email = w_srvc_email.
            CALL METHOD im_header->set_data( ls_mepoheader ).
            EXIT.
          ENDIF.
        ENDLOOP.
      ENDIF.

*If there are multiple lines on the PO, with multiple plants, the
*program should check WERKS on all lines
      CLEAR : w_srvc_email, w_werks.
      LOOP AT int_werks INTO ws_werks.
        SELECT SINGLE zemail zwerks INTO (w_srvc_email, w_werks)
        FROM zmemail_loc WHERE zwerks = ws_werks-werks
                                AND zprogram EQ 'ZME3097'.
        IF sy-subrc = 0.
* If ANY line has WERKS in ZMEMAIL_LOC
          w_email_flag = 'X'.
        ENDIF.
      ENDLOOP.

      CLEAR : zerror_flag.
* cannot use Service Payment Report email.
      IF w_email_flag <> 'X'.
        IF NOT ls_mepoheader-zz_srvc_email IS INITIAL.
          zerror_flag = 'X'.
          CALL METHOD im_header->invalidate( ).
          mmpur_metafield 90000010.
          mmpur_message 'E' '38' '000' TEXT-006
                             ws_werks-werks TEXT-008 TEXT-009.
        ENDIF.
      ENDIF.

      IF w_email_flag EQ 'X'.
        LOOP AT int_werks INTO ws_werks.
          CLEAR : w_srvc_email, w_werks.
* Check for entries in zmemail_loc tables
* Verify GR indicator is space
          SELECT SINGLE zemail zwerks INTO (w_srvc_email, w_werks)
          FROM zmemail_loc WHERE zwerks = ws_werks-werks
                                     AND zprogram EQ 'ZME3097'.
          IF ( sy-subrc = 0 ).
* Check line item GR Value
            READ TABLE ls_mepoitem  WITH KEY wepos = ' '
                                             werks = ws_werks-werks
                                             ebelp = ws_werks-ebelp
                                    INTO w_mepoitem.
            IF ( sy-subrc = 0 ).
* Check header email value , if initial display error
              IF ls_mepoheader-zz_srvc_email IS INITIAL.
* Code inserted LMATHEW CMS8060 E03097 - Start

                TRANSLATE w_mepoitem-afnam TO UPPER CASE.

                SELECT SINGLE zipnet INTO zz_srvc_email
                       FROM zmipaperdir
                       WHERE znetid = w_mepoitem-afnam(8).
                IF sy-subrc = 0.
*                ls_mepoheader-zz_srvc_email = zz_srvc_email.
                  ls_mepoheader-zz_srvc_email = zz_srvc_email.
                  CALL METHOD im_header->set_data( ls_mepoheader ).

                  mmpur_message 'W' '38' '000' TEXT-006
                                      ws_werks-werks TEXT-015 TEXT-016.
*                MESSAGE w000(38) WITH text-006
*                    ws_werks-werks text-015 text-016.
                ELSE.
* Code inserted LMATHEW CMS8060 E03097 - End
                  zerror_flag = 'X'.
* Parameter set to update item table
                  CALL METHOD im_header->invalidate( ).
                  mmpur_metafield 90000010.
                  mmpur_message 'E' '38' '000' TEXT-006
                                      ws_werks-werks TEXT-007 ''.
* Code inserted LMATHEW CMS8060 E03097 - Start
                ENDIF.
* Code inserted LMATHEW CMS8060 E03097 - End

* requires email address for Service Payment Report email.
              ENDIF. "ls_mepoheader-zz_srvc_email
            ENDIF.     "sy-subrc = 0
          ENDIF.      "sy-subrc = 0
          CLEAR : w_zipnet, w_srvc_email, w_werks.
        ENDLOOP.
      ENDIF.

* Validate z_srvc_email with zmipaperdir table
      IF zerror_flag NE 'X'.
        IF NOT ls_mepoheader-zz_srvc_email IS INITIAL.
          SELECT SINGLE zipnet INTO w_zipnet FROM zmipaperdir
          WHERE zipnet EQ ls_mepoheader-zz_srvc_email.
          IF sy-subrc NE 0.
*    w_error_flag = 'X'.
            zerror_flag = 'X'.
            CALL METHOD im_header->invalidate( ).
*    SET PARAMETER ID 'ZME3097_FLAG' FIELD w_error_flag.
            mmpur_metafield 90000010.
            mmpur_message  'E' '38' '000' TEXT-010 '' '' ''.
          ENDIF. "sy-subrc NE 0
        ENDIF.   "ls_mepoheader-zz_srvc_email IS INITIAL
      ENDIF.    "w_error_flag NE 'X'
    ENDIF.
  ENDIF.     "ws_zmmfld = 'X'
******(End)-E0VK917081****E3097*************************************

* New code Inserted by SRAMASA 10/06/2006 -CMS#6069- Start "E0VK922725
** PO field validation alternatives
*  IF ( ls_mepoheader-bsart eq 'FIBS' or
*       ls_mepoheader-bsart eq 'GWR'  or
*       ls_mepoheader-bsart eq 'GWS'  or
*       ls_mepoheader-bsart eq 'GWV'  or
*       ls_mepoheader-bsart eq 'NB'   or
*       ls_mepoheader-bsart eq 'PAC'  or
*       ls_mepoheader-bsart eq 'UB' ) and
*     ( ls_mepoheader-ekorg eq 'FS1A' or
*       ls_mepoheader-ekorg eq 'FS2A' or
*       ls_mepoheader-ekorg eq 'FS5A' or
*       ls_mepoheader-ekorg eq 'FS8A' or
*       ls_mepoheader-ekorg eq 'FS9A' or
*       ls_mepoheader-ekorg eq 'RF01' ).
**If Validity start [EKKO_KDATB] = NULL, “Enter Validity Start Date.”
*       if ls_mepoheader-KDATB is initial.
**    SET PARAMETER ID 'ZME3097_FLAG' FIELD w_error_flag.
*          mmpur_metafield 90000010.
*          mmpur_message  'E' '38' '000' text-012 '' '' ''.
*       endif.
**Validity end [EKKO_KDATE] = NULL, “Enter Validity End Date.”
*       if ls_mepoheader-KDATE is initial.
**    SET PARAMETER ID 'ZME3097_FLAG' FIELD w_error_flag.
*          mmpur_metafield 90000010.
*          mmpur_message  'E' '38' '000' text-013 '' '' ''.
*       endif.
*
**Latest GR Date [EKPO_LEWED] = NULL, “Enter Latest GR Date.”
*       loop at ls_mepoitem INTO w_mepoitem where LEWED is initial.
*       if w_mepoitem-LEWED is initial.
**    SET PARAMETER ID 'ZME3097_FLAG' FIELD w_error_flag.
*          mmpur_metafield 90000010.
*          mmpur_message  'E' '38' '000' text-014 '' '' ''.
*          exit.
*       endif.
*      endloop.
*  ENDIF.
* New code Inserted by SRAMASA 10/06/2006 -CMS#6069- End   "E0VK922725
*-->>>>>>>>begin of chg:<E3049>>>>Trade Order Process>>EDEK905044>--

*--check the order for third party order type

*Start of CMS 30771 by XANDREW

  DATA:lv_usage          TYPE ekko-zz_usage,
       lv_vsbed          TYPE ekko-zz_vsbed,
       lv_kunnr          TYPE ekko-zz_trdsh,
       lv_string_in(200) TYPE c,
       lv_htype          TYPE datatype_d. "dd01v-datatype.

  CLEAR:lv_usage,lv_vsbed, lv_kunnr.

  IF ls_mepoheader-bsart EQ 'THD'.
    SELECT SINGLE value1 FROM zmmfld
      INTO @DATA(lv_thd)
      WHERE key1 = 'E10814' AND
            value1 = @ls_mepoheader-bsart.
    IF sy-subrc EQ 0.

*** Start of modification by ALANKAP on 8/10/2015 CMS 28794
      SELECT value1 FROM zmmfld INTO TABLE lt_zmmfld_ekorg WHERE
        key1 = lc_zmmfld_e10164
        AND key2 = lc_zmmfld_bukrs.
*** End of modification by ALANKAP on 8/10/2015 CMS 28794
*--loop through the purchase order item
      LOOP AT ls_mepoitem INTO w_mepoitem WHERE NOT banfn IS INITIAL.

*--get sales order data for the purchase requisition data
        SELECT SINGLE vbak~bstnk vbak~ihrez vbak~abrvw vbak~zz_ipco
        vbak~vsbed vbak~kunnr
        INTO (ls_mepoheader-zz_trnpricepo, ls_mepoheader-zz_contract,
              lv_usage, ls_mepoheader-zz_ipco, lv_vsbed, lv_kunnr)
        FROM vbak
        INNER JOIN ebkn ON ebkn~vbeln = vbak~vbeln
                   WHERE ebkn~banfn = w_mepoitem-banfn
                     AND ebkn~bnfpo = w_mepoitem-bnfpo.

        IF NOT ls_mepoheader-zz_contract IS INITIAL.
          lv_string_in = ls_mepoheader-zz_contract.
          CALL FUNCTION 'NUMERIC_CHECK'
            EXPORTING
              string_in  = lv_string_in
            IMPORTING
              string_out = lv_string_in
              htype      = lv_htype.
          IF lv_htype EQ lc_char.
            SELECT SINGLE value1 INTO ls_mepoheader-ekorg FROM zmmfld
                 WHERE key1 = lc_zmmfld_r03563
                   AND key2 = lc_contract
                   AND key3 = ls_mepoheader-zz_contract+0(2).
          ELSEIF lv_htype EQ lc_numc.
            SELECT SINGLE value1 INTO ls_mepoheader-ekorg FROM zmmfld
                 WHERE key1 = lc_zmmfld_r03563
                   AND key2 = lc_contract
                   AND key3 = lc_numeric.
          ENDIF.
        ENDIF.
*** End of modification by ALANKAP on 8/10/2015 CMS 28794


        IF ls_mepoheader-zz_usage IS INITIAL.
          ls_mepoheader-zz_usage = lv_usage.
        ENDIF.

        IF ls_mepoheader-zz_vsbed IS INITIAL.
          ls_mepoheader-zz_vsbed = lv_vsbed.
        ENDIF.
* << Trades Shipto Population from VBAK
        IF ls_mepoheader-zz_trdsh IS INITIAL.
          ls_mepoheader-zz_trdsh = lv_kunnr.
        ENDIF.
* >>
*--if found sales data then set mepoheader Trades Tab data
        IF sy-subrc EQ 0.
          CALL METHOD im_header->set_data( im_data = ls_mepoheader ).
          EXIT.
        ENDIF.

      ENDLOOP.

    ENDIF.

*Business requirements state that if BSART and EKORG combo exist, then
* do following actions
  ELSE.  "CMS 30771 XANDREW
    SELECT SINGLE value1 FROM zmmfld
      INTO @DATA(lv_zmmfld)
      WHERE key1 = 'E10814' AND
            value1 = @ls_mepoheader-bsart AND
            value2 = @ls_mepoheader-ekorg.

    IF sy-subrc EQ 0.

      LOOP AT ls_mepoitem INTO w_mepoitem WHERE NOT banfn IS INITIAL.

*--get sales order data for the purchase requisition data
        SELECT SINGLE vbak~ihrez vbak~abrvw
        INTO ( ls_mepoheader-zz_contract, lv_usage )
        FROM vbak
        INNER JOIN ebkn ON ebkn~vbeln = vbak~vbeln
                   WHERE ebkn~banfn = w_mepoitem-banfn
                     AND ebkn~bnfpo = w_mepoitem-bnfpo.

        IF NOT ls_mepoheader-zz_contract IS INITIAL.
          lv_string_in = ls_mepoheader-zz_contract.
          CALL FUNCTION 'NUMERIC_CHECK'
            EXPORTING
              string_in  = lv_string_in
            IMPORTING
              string_out = lv_string_in
              htype      = lv_htype.
*CMS 30771
* If record is found when compared to ZMMFLD based on below values,
* read the header information into the BADI
          SELECT * FROM zmmfld
            INTO TABLE @DATA(ls_zmmfld_ekorg)
            WHERE key1 = @lc_zmmfld_e10814 AND
                  value1 = @lc_tps AND
                  value2 = @ls_mepoheader-ekorg.
        ENDIF.

        IF ls_mepoheader-zz_usage IS INITIAL.
          ls_mepoheader-zz_usage = lv_usage.
        ENDIF.

*If KEY1, VALUE1, and VALUE2 record exists zmmfld then set mepoheader
* Trades Tab data
        IF sy-subrc EQ 0.
          CALL METHOD im_header->set_data( im_data = ls_mepoheader ).
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.

*-->>>>>>>>End of chg:<E3049>>>>Trade Order Process>>>EDEK905044>>--
*End of CMS 30771 changes

*---Common method to be used to implement any future development
***Helena Malkowska PROCESS_HEADER CMS 33261 - E11017 - begin
  zcl_me_process_po_cust=>process_header( im_header = im_header ).
***Helena Malkowska PROCESS_HEADER CMS 33261 - E11017 - end
*  ENDIF.
ENDMETHOD.


METHOD if_ex_me_process_po_cust~process_item .
*---------------------------------------------------------------------
* Change History:                                                      *
*  Programmer        Date        Req.#     Action                      *
* =================  ========== ========== ============================*
* Change History (as of 2/2007)
* Maureen Carter     02/07/2007            Need to populate rail route
*                                          on STOs for R8 V2 tpr17342
*
* W. Mitzner         10/22/2007 EDEK909916 Calculate Gross Weight Ratio
*                                          = Gross Weight / Net Weight
*                                          CR06775
*
* PRAGUPA            05/29/2008 EDEK912214 Added the STO CLOSE code in
*                                          separate include
*                                          ZDL_FLEX_STO_CLOSE_PROC_ITEM
*
* PRAGUPA            06/23/2008 EDEK912214    V2 Rollback             *
*
* ALANKAP            09/23/2013 E0VK9A02FV CMS 25380 Added a validation
* to restrict the changes on the PO when the STO or Sales order to be “
* in the process of transportation plan” for a longer period of time.
*
* SMITHAI            08/11/2015 E0VK9A0DWQ CMS 28470:Brazil TXZ01 Enhancement.
*-----------------------------------------------------------------------
* Helena Malkowska   06/2014    26813      Change the goods receipt
*                                          indicator to default OFF when
*                                          a service is planned from
*                                          within the work order
* Helena Malkowska   08/2015    28781      Logic for turning off the
*                                          goods receipt indicator should
*                                          be disabled for EMEA
* APUNJAA            03/10/2017 31393      Following fields are mapped from Ariba.
*                                          Tax Code
*                                          GR Indicator
*                                          GR based IR indicator
*                                          moved to zcl_me_process_po_cust=>process_item
* Helena Malkowska   02/2018    E0V 33184  Move the logic related to E03049
*                                          to method PROCESS_RFSCOP_ITEM
*                                          of class ZCL_ME_PROCESS_PO_CUST
* John William      3/11/2019  E0VK9A14TP  This new functionality will need
*                                       to be executed whenever a Purchase
*                                       Order is created or changed.When this
*                                       happens, it will need to do a series of
*                                       checks to see if the user is attempting
*                                       to create a STO (stock transport order)
*                                       where the supplying and receiving plants
*                                       are in different company codes.  If this
*                                       is an STO, and the supplying and receiving
*                                       plants are in different company codes, the
*                                       system will need to issue an error – which will
*                                       not allow the user to proceed with saving the Purchase Order.
* Anil Lankapalli   9/3/2019  CD 2000003643 Contract Labor Management (CLM) project
*                             The item category “D” should be required
*                             at the time of PO creation.
*                             The GR flag on the “Delivery” tabs should
*                             be set to active. This will turn on the
*                             flag on the “Invoice” tab for “GR-Bsd IV”
* Naresh Busineni  12/Apr/24      Added validation to enable GR indicator for Nymolla (7825)
*  (NBUSINE)      TR: S0VK906995  Plant when requisition created via work order
*  Charm id: 2000001733
*  Task id: SCTASK0046248
*-----------------------------------------------------------------------


  DATA: ls_mepoheader TYPE mepoheader,
        im_header     TYPE REF TO if_purchase_order_mm,
        ls_mepoitem   TYPE mepoitem,   "cr09989  wcr
*        ls_mepoitem TYPE STANDARD TABLE OF mepoitem
*                              INITIAL SIZE 0,
        ls_tbsg       TYPE tbsg,
        w_prstat      TYPE zmtaid-z_prstat,
        w_chkrec      TYPE zmmchkrec.
  INCLUDE mm_messages_mac. "useful macros for message handling

*-->>>Begin of chg:WMITZNE:<E3967>>Gross Wt Ratio>CR06775>>EDEK909916>--
  DATA: lv_vbeln_co TYPE vbeln_co,
        lv_vbelp_co TYPE posnr_co,
        lv_brgew    TYPE brgew_ap,
        lv_ntgew    TYPE ntgew_ap.

  CLEAR: lv_vbeln_co,          "SO Num
         lv_vbelp_co,          "SO Line
         lv_brgew,             "Gross Weight
         lv_ntgew.             "Net Weight
*-->>>End of chg:WMITZNE:<E3967>>Gross Wt Ratio>CR06775>>EDEK909916>--

  DATA: wa_zdl_supply_drivn TYPE zdl_supply_drivn,
        wa_yekpo            TYPE ekpo,
        lt_ekpv_new         TYPE ekpv,
        lv_vsbed            TYPE vsbed,
        lv_vstel            TYPE vstel,
        lv_eindt            TYPE eindt.
  DATA: lt_ct_data TYPE ztp_gfu_planning_status_tab,
        wa_ct_data TYPE ztp_gfu_planning_status_str.

*---------------------------------------------------------------------

* here we check customers data
*---------------------------------------------------------------------

  ls_mepoitem   = im_item->get_data( ).
  im_header     = im_item->get_header( ).
  ls_mepoheader = im_header->get_data( ).
  EXPORT ekorg FROM ls_mepoheader-ekorg TO MEMORY ID 'EKORG'.

* Start of change JWILL68 CD#2000000573 3/11/2019
  validation_gcf(
    EXPORTING
      is_mepoheader = ls_mepoheader " Purchase Order Header Data
      is_mepoitem   = ls_mepoitem   " Purchase Order Item
      im_item       = im_item ).    " PO Item External View
* End of change JWILL68 CD#2000000573 3/11/2019

* Start of modification ALANKAP 9/18/2013 CMS 25380
* CMS 26320 included ME23N in the if condition
*  IF sy-tcode EQ 'ME22N' AND
*     ls_mepoheader-bstyp EQ 'F' AND
*     ls_mepoheader-reswk IS NOT INITIAL.

  IF ( sy-tcode EQ 'ME22N' OR sy-tcode EQ 'ME23N' OR
    ( sy-tcode EQ 'ME21N' AND NOT ls_mepoheader-ebeln IS INITIAL ) ) AND
      ls_mepoheader-bstyp EQ 'F' AND
      ls_mepoheader-reswk IS NOT INITIAL.

    lt_ekpv_new = im_item->get_shipping_data( ).
    SELECT SINGLE vstel vsbed INTO (lv_vstel,lv_vsbed) FROM ekpv
            WHERE ebeln = ls_mepoitem-ebeln
            AND   ebelp = ls_mepoitem-ebelp.

    SELECT SINGLE * INTO
           wa_yekpo FROM ekpo
           WHERE ebeln = ls_mepoitem-ebeln
           AND   ebelp = ls_mepoitem-ebelp.

    SELECT SINGLE eindt INTO lv_eindt FROM eket
           WHERE ebeln = ls_mepoitem-ebeln
           AND   ebelp = ls_mepoitem-ebelp.

    SELECT SINGLE * INTO wa_zdl_supply_drivn FROM
           zdl_supply_drivn
           WHERE locno = ls_mepoheader-reswk
            AND  matkl = wa_yekpo-matkl
            AND z_supply_driven = 'Y'.
    IF sy-subrc EQ 0.
      IF ( wa_yekpo-matnr NE ls_mepoitem-matnr ) OR
         ( wa_yekpo-werks NE ls_mepoitem-werks ) OR
         ( wa_yekpo-menge NE ls_mepoitem-menge ) OR
         ( lv_eindt NE ls_mepoitem-eindt ) OR
         ( lv_vsbed NE lt_ekpv_new-vsbed ) OR
         ( lv_vstel NE lt_ekpv_new-vstel ) OR
         ( wa_yekpo-elikz NE ls_mepoitem-elikz ) OR
         ( wa_yekpo-loekz NE ls_mepoitem-loekz ).

        wa_ct_data-order_number = wa_yekpo-ebeln.
        wa_ct_data-item_number  = wa_yekpo-ebelp.
        wa_ct_data-is_sto  = 'X'.
        APPEND wa_ct_data TO lt_ct_data.

        CALL FUNCTION 'Z_TP_CHECK_GFU_PLANNING_STATUS'
          CHANGING
            ct_data = lt_ct_data
* EXCEPTIONS
*           RFC_ERROR_OCCURED       = 1
*           OTHERS  = 2
          .
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ELSE.
          LOOP AT lt_ct_data INTO wa_ct_data.
            IF wa_ct_data-gfu_planned = 'X'.
              mmpur_message 'E' 'ZM' '332' ls_mepoitem-ebeln
                   ls_mepoitem-ebelp TEXT-059 ''.
              EXIT.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
* End of modification ALANKAP 9/18/2013 CMS 25380

* Get Receipient name and Phone number for reference PO from Pur Req.
  IF ls_mepoitem-zz_name1 IS INITIAL.
    IF ls_mepoitem-banfn <>  ' ' AND
       ls_mepoitem-bnfpo <>  ' ' .

      SELECT SINGLE zz_name1 zz_telf1 zz_recnum1
             FROM eban
             INTO (ls_mepoitem-zz_name1 ,
                    ls_mepoitem-zz_telf1 ,
                    ls_mepoitem-zz_recnum1 )
             WHERE banfn = ls_mepoitem-banfn
             AND   bnfpo = ls_mepoitem-bnfpo.
      IF sy-subrc = 0.
        CALL METHOD im_item->set_data( ls_mepoitem ).
      ENDIF.
    ENDIF.
  ENDIF.
*
  IF ls_mepoheader-loekz NE 'D'.
*    IF ls_mepoitem-zz_name1 IS INITIAL.
**     We need to make sure the user has
**     to fill in the recipient name
*      SELECT SINGLE *
*        INTO w_chkrec
*        FROM zmmchkrec
*       WHERE bukrs = ls_mepoheader-bukrs
*         AND bsart = ls_mepoheader-bsart
*         AND ekorg = ls_mepoheader-ekorg.
*      IF sy-subrc = 0.
*        mmpur_metafield mmmfd_cust_09.
*        mmpur_message 'E' '38' '000' text-005
*                             '' '' ''.
*      ENDIF.
*    ELSE.
    IF NOT ls_mepoitem-zz_name1 IS INITIAL.

      IF ls_mepoheader-ekorg IS INITIAL.
*        CLEAR: ls_mepoitem-zz_name1,
*               ls_mepoitem-zz_telf1.
*        im_item->set_data( ls_mepoitem ).
        mmpur_metafield mmmfd_cust_09.
        mmpur_message 'E' '38' '000' TEXT-003
                             TEXT-004 '' ''.
      ELSE.
        SELECT SINGLE z_telf1
          INTO ls_mepoitem-zz_telf1
          FROM zmmrecipient
         WHERE zwerks = ls_mepoheader-ekorg
           AND zlang  = sy-langu
           AND z_name1 = ls_mepoitem-zz_name1.
        IF sy-subrc = 0.
          CALL METHOD im_item->set_data( ls_mepoitem ).
        ELSE.
*          CLEAR: ls_mepoitem-zz_name1,
*                 ls_mepoitem-zz_telf1.
*          im_item->set_data( ls_mepoitem ).
          mmpur_metafield mmmfd_cust_09.
          mmpur_message 'E' '38' '000' TEXT-005
                               '' '' ''.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

*** hmalkow - E0V 33184 - lines below commented out
*** this logic has been moved to class ZCL_ME_PROCESS_PO_CUST
*** method PROCESS_RFSCOP_ITEM

**-->>>>>>begin of chg:MAIEL:<E3049>>>>Trade Order Process>>EDVK947650>--
*
*  DATA: lv_vbeln      TYPE vbak-vbeln,
*        lv_update_thd TYPE char01.    "wcr  CR09989
*
**--check the order for third party order type
*  IF ls_mepoheader-bsart = 'THD'.
*
**--get sales order data for the purchase requisition data
*    CLEAR: lv_vbeln,
*           lv_update_thd.             "wcr  CR09989
**--get the sales order number for the purchase req
*    SELECT SINGLE vbak~vbeln INTO lv_vbeln
*    FROM vbak
*    INNER JOIN ebkn ON ebkn~vbeln = vbak~vbeln
*               WHERE ebkn~banfn = ls_mepoitem-banfn
*                 AND ebkn~bnfpo = ls_mepoitem-bnfpo.
*
*    IF sy-subrc EQ 0.
*
*      IF ls_mepoitem-schpr IS INITIAL.   "wcr   CR09989
*        ls_mepoitem-schpr = 'X'.         "wcr  CR09989
*        lv_update_thd = 'X'.             "wcr  CR09989
*      ENDIF.                             "wcr  CR09989
*
**--bring the SH from Sales Order to Customer on PO Item
*      SELECT SINGLE kunnr INTO ls_mepoitem-kunnr
*      FROM vbpa WHERE vbeln = lv_vbeln
*      AND parvw = 'WE'.
*
**--if found update sales data then set mepoitem-customer.no
*      IF sy-subrc EQ 0.
*        lv_update_thd = 'X'.         "wcr  CR09989
*      ENDIF.                         "wcr  CR09989
*
*      IF lv_update_thd = 'X'.        "wcr  CR09989
*        CALL METHOD im_item->set_data( ls_mepoitem ).
*      ENDIF.
*
*    ENDIF.
*
*  ENDIF.
*
**-->>>>>>>>End of chg:<E3049>>>>Trade Order Process>>>EDVK947650>>--

*** hmalkow - E0V 33184 - end lines commented out

*-->>>>>>>>begin of chg:>>>>RGX change 2/2/2007>>>>>>>>>>>>>>>---

* INCLUDE manually added 2/2/2007 per oss note for R08I
*    from Jim Whipple and Phil Mattox
* Issue - need to populate rail route on STOs V2 tpr 17342
*
* IF added to exclude the NBs by Maureen Carter per Jim W
  IF ls_mepoheader-bsart <> 'NB'.
    INCLUDE /saprgx/im_me_process_po_cust.
  ENDIF.

*-->>>>>>>>>>end of chg:>>>>RGX change 2/2/2007>>>>>>>>>>>>>>>---


*-->>>Begin of chg:WMITZNE:<E3967>>Gross Wt Ratio>CR06775>>EDEK909916>--

*------  When PO Type is 'UB'  ----------------------------------------*
  IF ls_mepoheader-bsart = 'UB'.
*------  EKKN - Select Sales Order and Line Item Number  --------------*
    SELECT SINGLE vbeln vbelp
             INTO (lv_vbeln_co, lv_vbelp_co)
             FROM ekkn
            WHERE ebeln = ls_mepoitem-ebeln
              AND ebelp = ls_mepoitem-ebelp.
*------  VBAP - Select Gross Weight and Net Weight of the Item  -------*
    IF sy-subrc = 0.
      SELECT SINGLE brgew ntgew
             INTO (lv_brgew, lv_ntgew)
             FROM vbap
            WHERE vbeln = lv_vbeln_co
              AND posnr = lv_vbelp_co.
*------  Calculate Gross Weight Ratio  --------------------------------*
      IF sy-subrc = 0.
        IF lv_ntgew <> 0.
          ls_mepoitem-brgew = ( lv_brgew / lv_ntgew ). "Gross Wt Ratio
        ELSE.
          ls_mepoitem-brgew = 1.                       "Default to 1
        ENDIF.

*------ Change ls_mepoitem with new Gross Weight Ratio  ---------------*
        CALL METHOD im_item->set_data( ls_mepoitem ).
      ENDIF.
    ENDIF.
  ENDIF.

*-->>>End of chg:WMITZNE:<E3967>>Gross Wt Ratio>CR06775>>EDEK909916>--

************************************************************************
**************** F L E X I B L E -- S H I P P I N G ********************
************************************************************************
* Anand Dhumbala 03/31/2008
* Sunil Paleru   03/31/2008       STO Close for Flexible Shipments
*---------------------------------------------------------------------
** This Method/Code is called once, for everytime a line item data
** is changed in a STO.
** This include program has code for STO close during ME22n.
** This include program Exports Flag which in turn will be imported in
** POST method.Flag is set when Flex Indicator is changed to 'X'
** and ERDAT & ERUHR fields are updated.

* Begin of V2 Rollback By PRAGUPA 06/23/2008 EDEK912214
*  Include ZDL_FLEX_STO_CLOSE_PROC_ITEM.
* End of V2 Rollback By PRAGUPA 06/23/2008 EDEK912214

**********************************************************************
* GOODS RECEIPT INDICATOR FOR SERVICE FROM WORK ORDER
* Helena Malkowska   06/2014    CMS 26813
**********************************************************************
*** Start of modification 9/3/2019 ALANKAP CD 2000003643

  IF ZCL_ME_PROCESS_PO_CUST=>GV_CLM_FLAG EQ abap_false.     " #CD3643

* 26813 hmalkow - start

    DATA: ls_zmmfld TYPE zmmfld.
    DATA: r_zmmfld  TYPE RANGE OF zmmfld-value1.
    DATA: s_zmmfld  LIKE LINE OF r_zmmfld.

    DATA: l_steus TYPE afvc-steus.
    DATA: l_ebeln TYPE ekpo-ebeln.

*** 28781 hmalkow - start
    DATA: r_werks  TYPE RANGE OF t001w-werks.
    DATA: s_werks  LIKE LINE OF r_werks.
*** 28781 hmalkow - end

*BOC by NBUSINE #S0VK906995 #2000001733 #SCTASK0046248
    DATA: r_powerks TYPE RANGE OF zmmfld-value1,
          s_powerks LIKE LINE OF r_powerks.

    s_powerks-sign = 'I'.
    s_powerks-option = 'EQ'.

    SELECT SINGLE * FROM zmmfld INTO @DATA(ls_zmmpo) WHERE key1 = 'ZMM_PO' AND key2 = 'WO'.
    IF sy-subrc = 0.
      s_powerks-low = ls_zmmpo-value1.
      APPEND s_powerks TO r_powerks.
    ENDIF.
*EOC by NBUSINE #S0VK906995 #2000001733 #SCTASK0046248

    DATA: BEGIN OF ls_ebkn,
            banfn TYPE ebkn-banfn,
            bnfpo TYPE ebkn-bnfpo,
            zebkn TYPE ebkn-zebkn,
            aufpl TYPE ebkn-aufpl,
            aplzl TYPE ebkn-aplzl,
          END OF ls_ebkn.

    s_zmmfld-sign = 'I'.
    s_zmmfld-option = 'EQ'.

    "Get entries from ZMMFLD
    SELECT * FROM zmmfld INTO ls_zmmfld
      WHERE key1 = 'E10271' AND key2 = 'TCODE'.
      s_zmmfld-low = ls_zmmfld-value1.
      APPEND s_zmmfld TO r_zmmfld.
    ENDSELECT.

*** 28781 hmalkow - start
    "Get range for EMEA werks
    s_werks-sign = 'I'.
    s_werks-option = 'EQ'.

    "Get entries from ZMMFLD
    SELECT * FROM zmmfld INTO ls_zmmfld
      WHERE key1 = 'E10271' AND key2 = 'WERKS'.
      s_werks-low = ls_zmmfld-value1.
      APPEND s_werks TO r_werks.
      s_werks-low = ls_zmmfld-value2.
      APPEND s_werks TO r_werks.
      s_werks-low = ls_zmmfld-value3.
      APPEND s_werks TO r_werks.
      s_werks-low = ls_zmmfld-value4.
      APPEND s_werks TO r_werks.
      s_werks-low = ls_zmmfld-value5.
      APPEND s_werks TO r_werks.
      s_werks-low = ls_zmmfld-value6.
      APPEND s_werks TO r_werks.
      s_werks-low = ls_zmmfld-value7.
      APPEND s_werks TO r_werks.
    ENDSELECT.

    DELETE r_werks[] WHERE low = space.

*** 28781 hmalkow - end

    IF ( r_zmmfld[] IS NOT INITIAL ) AND ( sy-tcode IN r_zmmfld ).

      "Get PO item
      ls_mepoitem  = im_item->get_data( ).

*** 28781 hmalkow - start
      "check if it is EMEA werks
      IF ( r_werks[] IS INITIAL ) OR
         ( ls_mepoitem-werks NOT IN r_werks ).
*** 28781 hmalkow - end

        "Check if it is new PO item
        SELECT SINGLE ebeln FROM ekpo INTO l_ebeln
          WHERE ebeln = ls_mepoitem-ebeln AND
                ebelp = ls_mepoitem-ebelp.

        "It is new PO line & Account Assignment Category = 'F'
        IF ( sy-subrc <> 0 ) AND ( ls_mepoitem-knttp = 'F' ).

          "Get routing number of operations in the order from EBKN
          SELECT
                 banfn
                 bnfpo
                 zebkn
                 aufpl_ord
                 aplzl_ord
            UP TO 1 ROWS
            FROM ebkn INTO ls_ebkn
            WHERE banfn = ls_mepoitem-banfn AND
                  bnfpo = ls_mepoitem-bnfpo.
          ENDSELECT.

          IF sy-subrc = 0.
            "Check if Requsition was created from Work Order
            SELECT SINGLE steus
              FROM afvc INTO l_steus
              WHERE aufpl = ls_ebkn-aufpl
                AND aplzl = ls_ebkn-aplzl
                AND steus = 'PM02'.

            IF ( sy-subrc = 0 ) AND ( ls_mepoitem-wepos IS NOT INITIAL ).

* Added below line validation to enable GR indicator only for Nymolla (7825) plant.
              IF r_powerks[] IS NOT INITIAL AND ls_mepoitem-werks IN r_powerks. "Added line by NBUSINE #S0VK906995 #2000001733 #SCTASK0046248
                "do nothing                                                 "Added line by NBUSINE #S0VK906995 #2000001733 #SCTASK0046248
              ELSE.
                "clear GR indicator
                ls_mepoitem-wepos = space.
                im_item->set_data( ls_mepoitem ).
              ENDIF.                             "Added line by NBUSINE #S0VK906995 #2000001733 #SCTASK0046248
            ENDIF.

          ENDIF.
        ENDIF.
      ENDIF.                                                 "28781 hmalkow

    ENDIF.
* 26813 hmalkow - end
  ENDIF. "  #CD3643

* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/19/14| Changed: Method SUBSCRIBE| START
  IF ls_mepoitem-zz_lwd IS NOT INITIAL AND ls_mepoitem-zz_threshold IS INITIAL
  AND ls_mepoitem-zz_deduction IS INITIAL.

    mmpur_metafield '90000039'.
    mmpur_message 'E' '38' '000' TEXT-061 TEXT-062 '' ''.

  ELSEIF ls_mepoitem-zz_lwd IS NOT INITIAL AND ls_mepoitem-zz_threshold IS NOT INITIAL
  AND ls_mepoitem-zz_deduction IS INITIAL.

    mmpur_metafield '90000040'.
    mmpur_message 'E' '38' '000' TEXT-063 TEXT-062 '' ''.

  ELSEIF ls_mepoitem-zz_lwd IS NOT INITIAL AND ls_mepoitem-zz_threshold IS INITIAL
  AND ls_mepoitem-zz_deduction IS NOT INITIAL.

    mmpur_metafield '90000039'.
    mmpur_message 'E' '38' '000' TEXT-064 TEXT-062 '' ''.

  ELSEIF ls_mepoitem-zz_lwd IS INITIAL AND ls_mepoitem-zz_threshold IS NOT INITIAL
  AND ls_mepoitem-zz_deduction IS INITIAL.

    mmpur_metafield '90000038'.
    mmpur_message 'E' '38' '000' TEXT-065 TEXT-062 '' ''.

  ELSEIF ls_mepoitem-zz_lwd IS INITIAL AND ls_mepoitem-zz_threshold IS NOT INITIAL
  AND ls_mepoitem-zz_deduction IS NOT INITIAL.

    mmpur_metafield '90000038'.
    mmpur_message 'E' '38' '000' TEXT-066 TEXT-062 '' ''.

  ELSEIF ls_mepoitem-zz_lwd IS INITIAL AND ls_mepoitem-zz_threshold IS INITIAL
  AND ls_mepoitem-zz_deduction IS NOT INITIAL.

    mmpur_metafield '90000038'.
    mmpur_message 'E' '38' '000' TEXT-067 TEXT-062 '' ''.

* CMS : 33160 Commented by ALANKAP on 3/23/2018 - Start

**  ELSEIF ls_mepoitem-zz_index_name IS INITIAL AND ls_mepoitem-zz_index_region IS NOT INITIAL.
**
**    mmpur_metafield '90000041'.
**    mmpur_message 'E' '38' '000' text-068 text-062 '' ''.
**
**  ELSEIF ls_mepoitem-zz_index_name IS NOT INITIAL AND ls_mepoitem-zz_index_region IS INITIAL.
**
**    mmpur_metafield '90000042'.
**    mmpur_message 'E' '38' '000' text-069 text-062 '' ''.
** CMS : 33160 Commented by ALANKAP on 3/23/2018 - End
*
  ENDIF.
* CMS: 26809| Changed By: AMAOLE1| Changed On: 06/19/14| Changed: Method SUBSCRIBE| END
*--------------------------------------------------------------------------------------------*
* implement BADI to capture changes in PO Line Items ( ME21N/22N/23N)
* when user hit “SAVE” without doing any check / hitting "ENTER" on PO line item.
*--------------------------------------------------------------------------------------------*
*BEGIN OF---> CMS#28470 E0VK9A0CYT 8/10/2015 BR TXZ01 Chg SMITHAI
  DATA: gt_zmmfld TYPE STANDARD TABLE OF zmmfld,
        gc_e10563 TYPE c LENGTH 6 VALUE 'E10563',
        gc_ekorg  TYPE c LENGTH 5 VALUE 'EKORG'.

  DATA: lv_maktx TYPE makt-maktx,
        lv_matnr TYPE matnr.
*-----Check Screen Number for Enhancement
  IF ( sy-tcode EQ 'ME21N' OR sy-tcode EQ 'ME22N'  OR sy-tcode EQ 'ME23N' ).
*-----Check Purchase Organization for Brazil in ZMMFLD.
    SELECT * INTO TABLE gt_zmmfld FROM zmmfld WHERE key1 EQ gc_e10563 AND
                                                    key2 EQ gc_ekorg AND
                                            value1 = ls_mepoheader-ekorg.
    IF sy-subrc = 0.
*  -----Check Plant / Material / P.Org combination exists.
      CLEAR lv_matnr.
      SELECT SINGLE a~matnr INTO lv_matnr FROM marc AS a INNER JOIN t024w AS b ON
      a~werks = b~werks WHERE
      a~matnr = ls_mepoitem-matnr AND
      b~werks = ls_mepoitem-werks AND
      b~ekorg = ls_mepoheader-ekorg.

      IF sy-subrc = 0.
*  -----Change TXZ01 Test.
        CLEAR lv_maktx.
        SELECT SINGLE maktx FROM makt INTO lv_maktx WHERE matnr = ls_mepoitem-matnr AND
        spras = sy-langu.
        IF sy-subrc = 0.
          IF ls_mepoitem-txz01 <> lv_maktx.
            ls_mepoitem-txz01 = lv_maktx.
            im_item->set_data( ls_mepoitem ).
            MESSAGE ID 'ZM' TYPE 'I' NUMBER '336' WITH ls_mepoitem-matnr.
          ENDIF.
        ENDIF.
      ENDIF. "End of Plant / Material / Combination check.
    ENDIF." End of ZMMFLD P.Org check.
  ENDIF. "End of Check for Screen / Sy-tcode.
*END OF<--- CMS#28470 E0VK9A0CYT 8/10/2015 BR TXZ01 Chg SMITHAI

*-Common method to be used to implement any future development
*-Mallik Aiely/02052018/ PROCESS_ITEM
  CALL METHOD zcl_me_process_po_cust=>process_item
    EXPORTING
      im_item = im_item.
ENDMETHOD.


METHOD if_ex_me_process_po_cust~process_schedule .
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
************************************************************************
**            COPYRIGHT (C) 2005 by INTERNATIONAL PAPER               **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                         2005, 200nn                                **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
************************************************************************
*______________________________________________________________________*
* METHOD IF_EX_ME_PROCESS_PO_CUST~PROCESS_SCHEDULE    Date: 10/28/2005 *
* Programmer  : Charles M. Ramey                                       *
*______________________________________________________________________*
* Description :                                                        *
*  Function to change calculate the number of slots that will be used  *
* by a given product and quantity.  This is necessary for TP/VS to     *
* be able to optimize the schedule line.  This is a compliment to the  *
* CDP code (written for Sales orders and Deliveries) to calculate      *
* slots for STOs.                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ===============  ==========  ==========   ===========================*
* Anand Dhumbala   06/13/2006  EDVK947206   Validation against table   *
*                                           ZDL_SUPPLY_DRIVN.          *
*______________________________________________________________________*
************************************************************************
* External Calls                                                       *
*  Function Modules:                                                   *
*      ZSD_DL_E03240_CALC_STO_SLOTS - calculates the number of slots   *
*______________________________________________________________________*



  DATA: ls_mepoheader    TYPE mepoheader,
        ls_mepoitem      TYPE mepoitem,
        ls_meposched     TYPE meposchedule,
        ls_prevsched     TYPE meposchedule,
        im_header        TYPE REF TO if_purchase_order_mm,
        im_item          TYPE REF TO if_purchase_order_item_mm.

  DATA: wa_vsbed         TYPE vsbed,
        wa_werks         TYPE empfw,
        wa_cuobj         TYPE cuobj,
        wa_call_func     TYPE c,
        zz_slots         TYPE  /gcds04/os_slots,
        zz_slots_unit    TYPE  /gcds04/os_slots_unit,
        zz_slots_pr_unit TYPE  char20,
        l_mtart          TYPE mtart,
        l_matnr          TYPE matnr,
        l_locno          TYPE char20.

  CONSTANTS: lc_supply_driven value 'Y'.

  DATA: hdr_ref  TYPE REF TO if_message_obj_mm,
        hdr_obj TYPE REF TO cl_po_header_handle_mm.

* get information from the Header, Item and Schedule lines
  ls_meposched  = im_schedule->get_data( ).
  IF NOT ls_meposched-ebeln IS INITIAL.
    im_schedule->get_previous_data( IMPORTING ex_data = ls_prevsched
                                    EXCEPTIONS OTHERS = 1 ).
    im_item       = im_schedule->get_item( ).
    ls_mepoitem   = im_item->get_data( ).
    im_header     = im_item->get_header( ).
    ls_mepoheader = im_header->get_data( ).

* check to make sure this is a PO that we want to calculate slots for
*  - is an STO and is not DCI'd or marked for deletion
*  - is not an MRO or Reject material
    CLEAR wa_call_func.
    IF ls_mepoheader-bsart = 'UB'.
      IF ls_mepoitem-loekz IS INITIAL.
        IF ls_mepoitem-elikz IS INITIAL.
          SELECT SINGLE mtart INTO l_mtart
             FROM zmaprmatyp
            WHERE mtart = ls_mepoitem-mtart.
          IF sy-subrc NE 0.
            SELECT SINGLE matnr INTO l_matnr
               FROM zsd_dl_no_sto
              WHERE matnr = ls_mepoitem-matnr AND
                    werks = ls_mepoitem-werks.
            IF sy-subrc NE 0.
              SELECT SINGLE matnr INTO l_matnr
                 FROM zsd_dl_no_sto
                WHERE matnr = ls_mepoitem-matnr AND
                      werks = space.
              IF sy-subrc NE 0.
* Start of changes by Anand Dhumbala - 06/13/2006
* To validate if the Order relates to MTS Supply Driven or not.If it is
* Supply Driven related then we turn off the SLOTS configuration so that
* the SLOTS will not show up in TPVS. This is done by checking the
* 'Location From' and 'Material Group' against the custom table
* 'ZDL_SUPPLY_DRIVN',if an entry is found then it is Supply Driven order
                select single locno
                              from zdl_supply_drivn
                              into l_locno
                              where locno = ls_mepoheader-reswk
                                and matkl = ls_mepoitem-matkl
                                and z_supply_driven = lc_supply_driven.
                IF sy-subrc NE 0.
* End of changes by Anand Dhumbala - 06/13/2006
                  wa_call_func = 'Y'.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    CHECK wa_call_func = 'Y'.

* if STO is not attached to a Sales Order - get info from STO
*   else pull the necessary data from VBAP
    IF ls_mepoitem-disub_vbeln IS INITIAL.
      wa_werks = ls_mepoheader-reswk.
      wa_cuobj = ls_mepoitem-cuobj.
    ELSE.
      SELECT SINGLE werks cuobj INTO (wa_werks, wa_cuobj)
        FROM vbap
       WHERE vbeln = ls_mepoitem-disub_vbeln.
    ENDIF.

    SELECT SINGLE vsbed INTO wa_vsbed
      FROM ekpv
      WHERE ebeln = ls_mepoitem-ebeln
        AND ebelp = ls_mepoitem-ebelp.

* if a quantity change has occurred (update or has been split) then
* calculate the number of slots
    IF ls_meposched-menge NE ls_prevsched-menge.
      CALL FUNCTION 'ZSD_DL_E03240_CALC_STO_SLOTS'
        EXPORTING
          i_vsbed                  = wa_vsbed
          i_plant                  = wa_werks
          i_cuobj                  = wa_cuobj
          i_menge                  = ls_meposched-menge
        IMPORTING
          e_slots                  = zz_slots
          e_slots_unit             = zz_slots_unit
          e_slots_per_unit         = zz_slots_pr_unit
        EXCEPTIONS
          configuration_object_req = 1
          no_unit_weight           = 2
          no_roll_width            = 3
          no_car_height            = 4
          OTHERS                   = 5.
      IF sy-subrc IS INITIAL.
        MOVE zz_slots         TO ls_meposched-zz_slots.
        MOVE zz_slots_unit    TO ls_meposched-zz_slots_unit.
        MOVE zz_slots_pr_unit TO ls_meposched-zz_slots_pr_unit.
        CALL METHOD im_schedule->set_data( ls_meposched ).

* We need to setup a reference to the header object (PO_HEADER_HANDLE).
* Then we need to "cast" the reference value to get the actual object
* so we can get to the Object's attributes.  We will need to modify the
* FOR_BAPO attribute  so that the schedule line update will occur even
* if called from a BAPI such as BAPI_PO_CHANGE (as in the split).
        hdr_ref  = im_item->if_message_obj_mm~get_parent( ).
        CATCH SYSTEM-EXCEPTIONS move_cast_error = 4.
          MOVE hdr_ref ?TO hdr_obj.
          IF sy-subrc IS INITIAL.
            IF hdr_obj->for_bapi EQ 'X'.
              hdr_obj->for_bapi = ' '.
            ENDIF.
          ENDIF.
        ENDCATCH.

      ENDIF.
    ENDIF.
  ENDIF.

endmethod.


  METHOD validate_doc_type_gcf.

* Validation 1.
*Context:  This check is determining that a Purchase Order
*is being created or changed based off of transaction codes
*which perform those functions.
*    CHECK sy-tcode = 'ME21N' OR
*          sy-tcode = 'ME22N' OR
*          sy-tcode = 'ME23N' OR
*          sy-tcode = 'ME27'  OR
*          sy-tcode = 'ME21'  OR
*          sy-tcode = 'ME22'  OR
*          sy-tcode = 'ME23'.


* Validation 2.
*Context:  The ‘T’ for BSAKZ is a designation on the Purchase
*Order control field which states that the purchase order is
*of type ‘STO’.  There are multiple STO purchase order document
*types, so this will allow us to determine the ‘STO’ type regardless
*of the document type.
    CHECK is_mepoheader-bsakz = 'T'.

* Validation 3.
*Context:  Ensuring that the Purchase Order has a Supplying Plant
*defined ensures that the document is complete and allows for the
*next set of checks, dependent on the Supplying Plant.  Existing
*checks will generate an error if attempting to save without a Supplying Plant.
    CHECK is_mepoheader-reswk <> space.

* Validation 4.
*Context:  By taking the Supplying Plant code and retrieving the
*company code it is associated with, we can then compare that to the
*company code for the receiving plant on the line item. We only need
*to look at the first line item as all line items on the document would
*be for the same company code, otherwise it currently will give an error.

*Read Valuation area table.
    SELECT SINGLE bukrs
      INTO @DATA(lv_bukrs)
      FROM t001k
      WHERE bwkey = @is_mepoheader-reswk.
* Sy-subrc check is not required.
    IF lv_bukrs <> is_mepoheader-bukrs.
      MESSAGE e000(zsd_dl) WITH TEXT-070
                                is_mepoheader-lifnr
                                TEXT-071
                                is_mepoheader-eq_werks.
    ENDIF.
  ENDMETHOD.


  METHOD validate_retrun_div_gcf.
* Validation 1.
*Context:  This check is determining that a Purchase Order is being
*created or changed based off of transaction codes which perform those
* functions
*    CHECK sy-tcode = 'ME21N' OR
*          sy-tcode = 'ME22N' OR
*          sy-tcode = 'ME23N' OR
*          sy-tcode = 'ME27'  OR
*          sy-tcode = 'ME21'  OR
*          sy-tcode = 'ME22'  OR
*          sy-tcode = 'ME23'.

* Validation 2.
*Context:Since these Purchase Orders will be intercompany, we can
*check if the vendor has been established as an
*ICC (International Paper Locations) vendor.
    SELECT SINGLE ktokk,
                  vbund
      FROM lfa1
      INTO ( @DATA(lv_ktokk),
             @DATA(lv_vbund) )
      WHERE lifnr = @is_mepoheader-lifnr.
    IF sy-subrc = 0 AND
       lv_ktokk <> 'ICC'.
      RETURN.
    ENDIF.

* Validation 3.
*Context:  Intercompany STO’s are not allowed – which will give a
*hard error if a Purchase Order is attempted to be created/changed
*as an STO document type for intercompany uses
    IF is_mepoheader-bsakz = 'T'.
      RETURN.
    ENDIF.

* Validation 4.
*Context:  For each line item on this Purchase Order, we need to
*ensure there is an associated sales order.  Without the sales order,
*the returns scenario does not apply.  The assumption is that the SPART
*field is populated if this purchase order is created in reference to a sales
*order.
    DATA(ls_ekpv_new) = im_item->get_shipping_data( ).
    IF ls_ekpv_new-spart = space.
      RETURN.
    ENDIF.
*    IF im_item->get_shipping_data( )-spart IS INITIAL.
*      RETURN.
*    ENDIF.

* Validation 5.
*Context:  For each line item, check if the company code differs from that
*of the vendor. If the two company codes do not match, this will ensure that
*we are dealing specifically with intercompany purchase orders.
    IF is_mepoitem-bukrs = lv_vbund(4).
      RETURN.
    ENDIF.

* Validation 6.
*Context:  The ‘Division’ field will need to be pulled from the material master
*as opposed to being populated by the header plant.  Naturally, this required
*the Purchase Order line item to have a material number.
    IF is_mepoitem-matnr = space.
      RETURN.
    ENDIF.

* Validation 7.
*Context: The goal is to determine if the ‘Division’ field on the Purchase Order
*Line Item is equal to the ‘Division’ field on the Purchase Order Line Item
*Material Master.
    SELECT SINGLE spart
      FROM mara
      INTO @DATA(lv_spart)
      WHERE matnr = @is_mepoitem-matnr.
* here no need to check sy-subrc
    IF lv_spart = ls_ekpv_new-spart.
      RETURN.
    ENDIF.

* Update the ‘Division’ field on the Purchase Order Line Item
    ls_ekpv_new-spart = lv_spart.
    CALL METHOD im_item->set_shipping_data( ls_ekpv_new ).
  ENDMETHOD.


  METHOD validation_gcf.
************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2019 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: VALIDATION_GCF                                         *
*                                                                      *
* SAP Name    : GCF VALIDATION                   Create Date: 03/14/19 *
*                                                                      *
* Programmer  : John Leo William                 Last Update: 03/14/19 *
*                                                                      *
*______________________________________________________________________*
* Description :                                                        *
*                                                                      *
*    This Method contains validation method for GCF object only        *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* John Leo William    03/14/19   CD#2000000573                                     *
*                                                                      *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
*Inventory U10180 STO Document Type Intercompany
    validate_doc_type_gcf( is_mepoheader = is_mepoheader ).

* Inventory U10181 Intercompany Returns Divisions
*    validate_retrun_div_gcf(
*      EXPORTING
*        is_mepoheader = is_mepoheader " Purchase Order Header Data
*        is_mepoitem   = is_mepoitem   " Purchase Order Item
*        im_item       = im_item ).    " PO Item External View
  ENDMETHOD.
ENDCLASS.

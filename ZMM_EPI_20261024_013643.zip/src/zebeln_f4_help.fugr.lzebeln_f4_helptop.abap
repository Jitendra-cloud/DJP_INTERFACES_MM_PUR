FUNCTION-POOL ZEBELN_F4_HELP.               "MESSAGE-ID ..

* INCLUDE LZEBELN_F4_HELPD...                " Local class definition

"Name: \TY:CL_TABLE_VIEW_MM\ME:MODIFY_SCREEN_TC_LINE\SE:END\EI
ENHANCEMENT 0 Z_ENH_DISABLE_TXZ01_IP_ME2122N.
*BEGIN OF---> CMS#28470 E0VK9A0CYT 8/10/2015 BR TXZ01 Chg SMITHAI

    DATA: gt_zmmfld TYPE STANDARD TABLE OF zmmfld,
          gc_e10563 TYPE C LENGTH 6 VALUE 'E10563',
          gc_ekorg  TYPE C LENGTH 5 VALUE 'EKORG'.

    DATA: l_header     TYPE REF TO cl_po_header_handle_mm,
          l_mepoheader TYPE mepoheader,
          l_item       TYPE REF TO cl_po_item_handle_mm,
          l_mepoitem   TYPE mepoitem.

    DATA: l_model   TYPE REF TO if_model_mm,
          wa_items  LIKE LINE OF items.

    DATA: lv_maktx TYPE makt-maktx,
          lv_matnr TYPE matnr.
*-----Check Screen Number for Enhancement
    IF ( sy-tcode EQ 'ME22N' OR sy-tcode EQ 'ME21N' OR sy-tcode EQ 'ME23N' ) AND sy-dynnr = '1211'.

*-----Define dyn cast.
      DEFINE mmpur_dynamic_cast.
        CATCH system-EXCEPTIONS move_cast_error = 1.
        &1 ?= &2.
        endcatch.
        IF sy-subrc = 1.
          CLEAR: &1.
        ENDIF.
      END-OF-DEFINITION.
*-----Read Item Reference from Current line of Table Control
      CLEAR: wa_items, l_model.
      READ TABLE ITEMS INTO wa_items INDEX <TC>-CURRENT_LINE.
      IF sy-subrc = 0.
        l_model = wa_items-model.
      ENDIF.
*-----Get Header Data.
      IF NOT my_model IS INITIAL.
        mmpur_dynamic_cast l_header my_model.
        CALL METHOD l_header->get_data( IMPORTING ex_data = l_mepoheader ).
      ELSE.
        CLEAR l_mepoheader.
      ENDIF.
*-----Get Current Item Data..
      IF NOT l_model IS INITIAL.
        mmpur_dynamic_cast l_item l_model.
        CALL METHOD l_item->get_data( IMPORTING ex_data = l_mepoitem ).
      ELSE.
        CLEAR l_mepoitem.
      ENDIF.
*-----Check Purchase Organization for Brazil in ZMMFLD.
      SELECT * INTO TABLE gt_zmmfld FROM zmmfld WHERE key1 EQ gc_e10563 AND
                                                      key2 EQ gc_ekorg AND
                                                      value1 = l_mepoheader-ekorg.
      IF SY-SUBRC = 0.
*  -----Check Plant / Material / P.Org combination exists.
        Clear lv_matnr.
        SELECT SINGLE a~matnr INTO lv_matnr FROM marc AS a INNER JOIN t024w AS b ON
        a~werks = b~werks WHERE
        a~matnr = l_mepoitem-matnr AND
        b~werks = l_mepoitem-werks AND
        b~ekorg = l_mepoheader-ekorg.

        IF sy-subrc = 0.
*  -----Change TXZ01 Test.
          Clear lv_maktx.
          SELECT SINGLE MAKTX FROM MAKT INTO lv_maktx WHERE matnr = l_mepoitem-matnr AND
                spras = sy-langu.
          IF Sy-subrc = 0.
            IF l_mepoitem-txz01 <> lv_maktx.

              l_mepoitem-txz01 = lv_maktx.
              CALL METHOD l_item->set_data( EXPORTING im_data = l_mepoitem  ).
              MESSAGE ID 'ZM' TYPE 'I' NUMBER '336' WITH l_mepoitem-matnr.
            ENDIF.
          ENDIF.
*  -----Disable Input Field.
          LOOP AT SCREEN.
            IF SCREEN-NAME = 'MEPO1211-TXZ01'.
              SCREEN-INPUT = '0'.
              MODIFY SCREEN.
            ENDIF.
          ENDLOOP.
        ENDIF. "End of Plant / Material / Combination check.

      ENDIF." End of ZMMFLD P.Org check.
      CLEAR: l_header, l_mepoheader, l_item, l_mepoitem, l_model.

    ENDIF. "End of Check for Screen / Sy-tcode.
*END OF<--- CMS#28470 E0VK9A0CYT 8/10/2015 BR TXZ01 Chg SMITHAI

ENDENHANCEMENT.

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z2SR
*   generation date: 06/17/2003 at 16:33:13 by user HRGOMEZ
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z2SR               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

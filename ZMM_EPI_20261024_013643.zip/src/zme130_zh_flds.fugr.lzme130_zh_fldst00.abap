*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME130_ZH_FLDS..................................*
DATA:  BEGIN OF STATUS_ZME130_ZH_FLDS                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME130_ZH_FLDS                .
CONTROLS: TCTRL_ZME130_ZH_FLDS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME130_ZH_FLDS                .
TABLES: ZME130_ZH_FLDS                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

class ZCL_MM_RFSCOP definition
  public
  final
  create public .

public section.

  class-methods GET_MILES
    importing
      !IV_LIFNR type LIFNR
      !IV_RESWK type WERKS_D
      !IV_WERKS type WERKS_D
      !IV_EVERS type EVERS
    exporting
      value(EV_ZZ_ZDIST) type ZDIST
      value(EV_MEINS) type BSTME
    returning
      value(RV_DISTANCE_DETERMINED) type SELKZ
    exceptions
      SHIPPING_TYPE_NOT_FOUND
      NO_PLANT_AND_VENDOR
      NO_RECEIVING_PLANT .
  class-methods GET_ZMMFLD_VALUES
    importing
      !IV_KEY1 type ANY optional
      !IV_KEY2 type ANY optional
      !IV_KEY3 type ANY optional
      !IV_KEY4 type ANY optional
      !IV_KEY5 type ANY optional
      !IV_SEQ_KEY type ZSEQ_KEY optional
      !IV_VALUE1 type ANY optional
      !IV_VALUE2 type ANY optional
      !IV_VALUE3 type ANY optional
      !IV_VALUE4 type ANY optional
      !IV_VALUE5 type ANY optional
      !IV_VALUE6 type ANY optional
      !IV_VALUE7 type ANY optional
      !IV_UP_TO_ROWS type NUM default 0
      !IV_TYPE type CHAR1 default 'T'
    exporting
      value(ES_ZMMFLD) type ZMMFLD
      value(ET_ZMMFLD) type ANY TABLE
    returning
      value(RV_SELECTED) type CHAR1
    exceptions
      BAD_FORMAT_OF_EXPORTING_TABLE
      BAD_FORMAT_OF_EXPORTING_RANGE
      CONVERSION_ERROR .
  class-methods VENDOR_IS_BLOCKED
    importing
      !IV_VENDOR type LIFNR
      !IV_EKORG type EKORG
      !IV_BUKRS type BUKRS
    exporting
      !EV_MSGID type SYMSGID
      !EV_MSGTY type SYMSGTY
      !EV_MSGNO type SYMSGNO
      !EV_MSGV1 type SYMSGV
      !EV_MSGV2 type SYMSGV
      !EV_MSGV3 type SYMSGV
      !EV_MSGV4 type SYMSGV
    returning
      value(RV_BLOCKED) type CHAR1 .
  class-methods GET_DEFAULT_VARIANT
    returning
      value(RV_VARIANT) type BOOLEAN .
protected section.
private section.

  class-methods GET_MESSAGE_TYPE
    importing
      !IV_MSGNO type SYMSGNO
    returning
      value(RV_MSGTY) type SYMSGTY .
ENDCLASS.



CLASS ZCL_MM_RFSCOP IMPLEMENTATION.


  METHOD get_default_variant.
    DATA: lv_var     TYPE rsvar-variant.
* Initialize returning variable
    CLEAR rv_variant.
    lv_var = |{ 'U_' }{ sy-uname }|.
    CALL FUNCTION 'RS_SUPPORT_SELECTIONS'
      EXPORTING
        report               = sy-cprog    " Report Name
        variant              = lv_var      " Variant Name
      EXCEPTIONS
        variant_not_existent = 1
        variant_obsolete     = 2
        OTHERS               = 3.
    IF sy-subrc <> 0.
      CLEAR lv_var.
      GET PARAMETER ID sy-tcode FIELD lv_var.
      CALL FUNCTION 'RS_SUPPORT_SELECTIONS'
        EXPORTING
          report               = sy-cprog    " Report Name
          variant              = lv_var      " Variant Name
        EXCEPTIONS
          variant_not_existent = 1
          variant_obsolete     = 2
          OTHERS               = 3.
      IF sy-subrc = 0.
        rv_variant = abap_true.
      ENDIF.
    ELSEIF sy-subrc = 0.
      rv_variant = abap_true.
    ENDIF.
  ENDMETHOD.


  method get_message_type.
    data: ls_zmmfld type zmmfld.

    if zcl_mm_rfscop=>get_zmmfld_values(
                                     exporting
                                       iv_key1 = 'E11017'
                                       iv_key2 = 'RFSCOP'
                                       iv_key3 = 'MESSAGES'
                                       iv_key4 = 'ZMM_RFSCOP'
                                       iv_key5 = iv_msgno
                                       iv_type = 'S'
                                     importing
                                       es_zmmfld = ls_zmmfld ) = 'X'.
      rv_msgty = ls_zmmfld-value1.
    endif.
  endmethod.


  method get_miles.

    data: ls_zmmfld type zmmfld.
    data: lv_disttype            type /sapdds/cdxprocd-distance_type.
    data: ls_departure_address   type addr1_val.
    data: ls_destination_address type addr1_val.
    data: lv_distance            type vttsvb-distz.
    data: lv_distance_unit       type vttsvb-medst.
    data: lt_distance_data type /sapdds/bapi_t_distance_data.
    data: lt_bapi_return type standard table of bapiret2.

    "Get the Distance Type (HHG – House Hold Goods for Truck or RAIL)
    if zcl_mm_rfscop=>get_zmmfld_values( exporting
                                            iv_key1 = 'E11117'
                                            iv_key2 = 'RFSCOP'
                                            iv_key3 = 'SHIP_INSTRUCTION'
                                            iv_key4 = iv_evers
                                            iv_type = 'S'
                                            iv_up_to_rows = 1
                                importing es_zmmfld = ls_zmmfld ) = 'X'.

      if iv_lifnr is not initial.
        select single * from lfa1 into @data(ls_lfa1)
          where lifnr = @iv_lifnr.
        if sy-subrc = 0.
          ls_departure_address-city1 = ls_lfa1-ort01.
          ls_departure_address-post_code1 = ls_lfa1-pstlz.
          ls_departure_address-region = ls_lfa1-regio.
          ls_departure_address-country = ls_lfa1-land1.
        endif.
      else.
        if iv_reswk is not initial.
          select single * from t001w into @data(ls_t001w)
            where werks = @iv_reswk.
          if sy-subrc = 0.
            ls_departure_address-city1 = ls_t001w-ort01.
            ls_departure_address-post_code1 = ls_t001w-pstlz.
            ls_departure_address-region = ls_t001w-regio.
            ls_departure_address-country = ls_t001w-land1.
          endif.
        else.
          "Enter Plant or Vendor
          message e002(zmm_rfscop) raising no_plant_and_vendor.
        endif.
      endif.

      if iv_werks is not initial.
        select single * from t001w into @data(ls_rt001w)
            where werks = @iv_werks.
        if sy-subrc = 0.
          ls_destination_address-city1 = ls_rt001w-ort01.
          ls_destination_address-post_code1 = ls_rt001w-pstlz.
          ls_destination_address-region = ls_rt001w-regio.
          ls_destination_address-country = ls_rt001w-land1.
        endif.
      else.
        "Enter Receiving Plant
        message e003(zmm_rfscop) raising no_receiving_plant.
      endif.

      lv_disttype = ls_zmmfld-value1.

      call function 'ZSDI02529_DETERMINE_STG_DIST'
        exporting
          i_disttype                  = lv_disttype
          i_departure_address         = ls_departure_address
          i_destination_address       = ls_destination_address
       importing
          e_distance                  = lv_distance
          e_distance_unit             = lv_distance_unit
          e_distance_determined       = rv_distance_determined
       tables
          lt_distance_data            = lt_distance_data
          lt_bapi_return              = lt_bapi_return.

      if sy-subrc = 0.
        ev_zz_zdist = lv_distance.
        ev_meins = lv_distance_unit.
      endif.

    else.

      "Shipping type &1 not found in ZMMFLD
      message w001(zmm_rfscop) with iv_evers
        raising shipping_type_not_found.

    endif.


  endmethod.


  method get_zmmfld_values.

    data: ls_zmmfld type zmmfld.
    data: lo_struct_zmmfld type ref to cl_abap_structdescr.
    data: lo_struct_ep type ref to cl_abap_structdescr.
    data: lt_comp_zmmfld type abap_component_tab.
    data: ls_comp_zmmfld type abap_componentdescr.
    data: lt_comp_ep type abap_component_tab.
    data: lv_where_cond type string.
    data: lt_zmmfld type table of zmmfld.
    field-symbols: <lv_p> type any.
    field-symbols: <lv_field> type any.
    data: lv_field type string.
    data: lo_lt type ref to data.
    data: lo_ls type ref to data.
    data: lv_i(1) type n.
    field-symbols <lt_ep> type standard table.
    field-symbols <ls_ep> type any.

    lo_struct_zmmfld ?=
        cl_abap_typedescr=>describe_by_data( ls_zmmfld ).
    lt_comp_zmmfld = lo_struct_zmmfld->get_components( ).

    if et_zmmfld is supplied.

      create data lo_lt like et_zmmfld.
      create data lo_ls like line of et_zmmfld.

      assign lo_lt->* to <lt_ep>.
      assign lo_ls->* to <ls_ep>.

      lo_struct_ep ?= cl_abap_typedescr=>describe_by_data( <ls_ep> ).
      lt_comp_ep = lo_struct_ep->get_components( ).

      case iv_type.

        when 'T'.

          if lt_comp_zmmfld[] <> lt_comp_ep.
            raise bad_format_of_exporting_table.
          endif.

        when 'R'.

          "check if it is range
          if not ( ( line_exists( lt_comp_ep[ 1 ] )
                   and lt_comp_ep[ 1 ]-name = 'SIGN' )
             and ( line_exists( lt_comp_ep[ 2 ] )
                   and lt_comp_ep[ 2 ]-name = 'OPTION' )
             and ( line_exists( lt_comp_ep[ 3 ] )
                   and lt_comp_ep[ 3 ]-name = 'LOW' )
             and ( line_exists( lt_comp_ep[ 4 ] )
                   and lt_comp_ep[ 4 ]-name = 'HIGH' ) ).

            raise bad_format_of_exporting_range.
          endif.

      endcase.
    endif.

    "Building WHERE condition for SELECT
    loop at lt_comp_zmmfld into ls_comp_zmmfld where name <> 'MANDT'.

      lv_field = 'iv_' && ls_comp_zmmfld-name.
      assign (lv_field) to <lv_field>.

      if <lv_field> is not initial.

        if lv_where_cond is not initial.
          lv_where_cond = lv_where_cond && ` and `.
        endif.

        lv_where_cond = lv_where_cond && ls_comp_zmmfld-name &&
                        ` = '` && <lv_field> && `'`.
      endif.
    endloop.

    "Select records with WHERE condition lv_where_cond
    if iv_up_to_rows = 1 or iv_type = 'S'. "first record

      select * from zmmfld up to 1 rows into table lt_zmmfld
        where (lv_where_cond).

    elseif iv_up_to_rows <> 0. "iv_up_to_rows records

      select * from zmmfld up to @iv_up_to_rows rows
        into table @lt_zmmfld where (lv_where_cond).

    else. "all records for condition lv_where_cond

      select * from zmmfld
        into table @lt_zmmfld where (lv_where_cond).

    endif.

    "Append records from ZMMFLD to export parameters:
    "S-Structure, T-Table, R-Range
    if lt_zmmfld[] is not initial.
      rv_selected = 'X'.

      case iv_type.
        when 'S'. "Structure

          "read table lt_zmmfld index 1 into es_zmmfld.
          es_zmmfld = lt_zmmfld[ 1 ].

        when 'T'. "Table

          if et_zmmfld is supplied.

            loop at lt_zmmfld into ls_zmmfld.

              if <ls_ep> is not initial.
                <ls_ep> = ls_zmmfld.
                append <ls_ep> to <lt_ep>.
              endif.
            endloop.
          endif.

        when 'R'. "Range

          if et_zmmfld is supplied.

            loop at lt_zmmfld into ls_zmmfld.
              lv_i = 0.
              do 5 times. "Value1, Value2, ..., Value5
                lv_i = lv_i + 1.
                lv_field = 'LS_ZMMFLD-VALUE' && lv_i.
                assign (lv_field) to <lv_field>.
                if <lv_field> is not initial.

                  assign component 1 of structure <ls_ep> to <lv_p>.
                  <lv_p> = 'I'.
                  assign component 2 of structure <ls_ep> to <lv_p>.
                  <lv_p> = 'EQ'.
                  assign component 3 of structure <ls_ep> to <lv_p>.
                  if sy-subrc = 0.
                    try.
                        <lv_p> = <lv_field>.
                      catch cx_sy_conversion_error.
                        raise conversion_error.
                    endtry.
                  endif.

                  if <ls_ep> is not initial.
                    append <ls_ep> to <lt_ep>.
                  endif.

                endif.
              enddo.
            endloop.

            et_zmmfld = <lt_ep>.
          endif.
      endcase.
    endif.


    if et_zmmfld is supplied.
      if et_zmmfld[] is initial.
        "No records selected
        clear: rv_selected.
      endif.
    endif.

  endmethod.


  method vendor_is_blocked.

    select single
      lifnr,
      loevm,
      sperr,
      sperm
    from lfa1 into @data(ls_lfa1) where lifnr = @iv_vendor.

    select single
      lifnr,
      loevm,
      sperm
    from lfm1 into @data(ls_lfm1) where lifnr = @iv_vendor
                                    and ekorg = @iv_ekorg.

    select single
      lifnr,
      loevm,
      sperr
    from lfb1 into @data(ls_lfb1) where lifnr = @iv_vendor
                                    and bukrs = @iv_bukrs.

    ev_msgid = 'ZMM_RFSCOP'.

    if ls_lfa1-loevm = 'X'.
      "--- Goods supplier &1 centrally delete flagged
      rv_blocked = 'X'.
      ev_msgno = 011.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.

    elseif ls_lfb1-loevm = 'X'.
      "--- Goods supplier &1 delete flagged for company code &2
      rv_blocked = 'X'.
      ev_msgno = 012.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.
      ev_msgv2 =  iv_bukrs.

    elseif ls_lfm1-loevm = 'X'.
      "--- Goods supplier &1 delete flagged for Purchase organization &2
      rv_blocked = 'X'.
      ev_msgno = 013.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.
      ev_msgv2 =  iv_ekorg.

    elseif ls_lfa1-sperr = 'X'.
      "--- Goods supplier &1 centrally blocked
      rv_blocked = 'X'.
      ev_msgno = 014.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.

    elseif ls_lfb1-sperr = 'X'.
      "--- Goods supplier &1 blocked for company code &2
      rv_blocked = 'X'.
      ev_msgno = 015.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.
      ev_msgv2 =  iv_bukrs.

    elseif ls_lfa1-sperm = 'X'.
      "--- Goods supplier &1 blocked for all purchase organizations
      rv_blocked = 'X'.
      ev_msgno = 016.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.

    elseif ls_lfm1-sperm = 'X'.
      "--- Goods supplier &1 blocked for Purchase organization &2
      rv_blocked = 'X'.
      ev_msgno = 017.
      ev_msgty = get_message_type( ev_msgno ).
      ev_msgv1 =  iv_vendor.
      ev_msgv2 =  iv_ekorg.
    endif.

  endmethod.
ENDCLASS.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMBB
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMBB                .

  PERFORM TABLEPROC.

ENDFUNCTION.

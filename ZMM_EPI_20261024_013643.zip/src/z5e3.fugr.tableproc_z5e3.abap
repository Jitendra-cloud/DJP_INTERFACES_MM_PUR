*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5E3
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5E3                .

  PERFORM TABLEPROC.

ENDFUNCTION.

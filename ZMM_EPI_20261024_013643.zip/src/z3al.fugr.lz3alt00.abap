*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 2003.05.12 at 14:57:33 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMM_AVG_LEADTIME................................*
DATA:  BEGIN OF STATUS_ZMM_AVG_LEADTIME              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_AVG_LEADTIME              .
CONTROLS: TCTRL_ZMM_AVG_LEADTIME
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_AVG_LEADTIME              .
TABLES: ZMM_AVG_LEADTIME               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

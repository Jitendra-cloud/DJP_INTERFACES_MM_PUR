*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMWRK...........................................*
DATA:  BEGIN OF STATUS_ZMWRK                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMWRK                         .
CONTROLS: TCTRL_ZMWRK
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMWRK                         .
TABLES: ZMWRK                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

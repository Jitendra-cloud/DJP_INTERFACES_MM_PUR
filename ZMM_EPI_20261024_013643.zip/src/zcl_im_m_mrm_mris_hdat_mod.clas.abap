class ZCL_IM_M_MRM_MRIS_HDAT_MOD definition
  public
  final
  create public .

*"* public components of class ZCL_IM_M_MRM_MRIS_HDAT_MOD
*"* do not include other source files here!!!
public section.

  interfaces IF_EX_MRM_MRIS_HDAT_MODIFY .
protected section.
*"* protected components of class ZCL_IM_M_MRM_MRIS_HDAT_MOD
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_M_MRM_MRIS_HDAT_MOD
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_M_MRM_MRIS_HDAT_MOD IMPLEMENTATION.


METHOD if_ex_mrm_mris_hdat_modify~mris_headerdata_modify .

  CALL FUNCTION 'Z_MM_BADI_MRIS_HDAT_MOD'
    EXPORTING
      i_rbkpv           = i_rbkpv
      ti_frseg          = ti_frseg
    IMPORTING
      f_rbkpv_is_change = e_rbkpv_is_change
      f_change          = e_change.

ENDMETHOD.
ENDCLASS.

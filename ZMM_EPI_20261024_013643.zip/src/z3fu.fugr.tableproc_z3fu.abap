*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3FU
*   generation date: 2003.05.12 at 15:02:05 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3FU                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMTYP...........................................*
DATA:  BEGIN OF STATUS_ZMTYP                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMTYP                         .
CONTROLS: TCTRL_ZMTYP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMTYP                         .
TABLES: ZMTYP                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

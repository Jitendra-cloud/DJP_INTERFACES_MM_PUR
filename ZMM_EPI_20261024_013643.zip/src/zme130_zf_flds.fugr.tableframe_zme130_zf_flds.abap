*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZME130_ZF_FLDS
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZME130_ZF_FLDS     .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3MV
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3MV                .

  PERFORM TABLEPROC.

ENDFUNCTION.

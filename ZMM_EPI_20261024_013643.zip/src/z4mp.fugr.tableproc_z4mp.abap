*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z4MP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z4MP                .

  PERFORM TABLEPROC.

ENDFUNCTION.

FUNCTION-POOL Z7VN                       MESSAGE-ID SV.

  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZ7VNT00                                . "view rel. data dcl.

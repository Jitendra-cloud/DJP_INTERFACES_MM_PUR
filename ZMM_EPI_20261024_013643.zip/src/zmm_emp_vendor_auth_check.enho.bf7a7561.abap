"Name: \PR:RMKKVZ00\FO:DISPLAY_RESULTS\SE:BEGIN\EI
ENHANCEMENT 0 ZMM_EMP_VENDOR_AUTH_CHECK.
DATA : lv_empl TYPE lfa1-ktokk VALUE 'EMPL',
       lr_even TYPE RANGE OF lifnr.

    AUTHORITY-CHECK OBJECT 'F_LFA1_GRP'
                    ID 'ACTVT' FIELD '03'
                    ID 'KTOKK' FIELD lv_empl.
    IF sy-subrc <> 0.
      DATA(lv_auth_empl) = abap_true.
      APPEND VALUE #( sign   = 'I'
                      option = 'CP'
                      low    = 'E*' ) TO lr_even.
    ENDIF.

 IF lv_auth_empl IS NOT INITIAL.
   DELETE it_lief WHERE lifnr in lr_even.
   data(gv_emplflg) = abap_true.
  ENDIF.

   IF it_lief[] is INITIAL and  gv_emplflg = abap_true.
    clear:gv_emplflg.
    MESSAGE 'You dont have authorization(F_LFA1_GRP) to check EMPL Vendors' TYPE 'I'.
    leave list-processing.
   ENDIF.

  IF  gv_emplflg = abap_true.
    clear:gv_emplflg.
    MESSAGE 'You dont have authorization(F_LFA1_GRP) to check EMPL Vendors' TYPE 'I'.
  ENDIF.

ENDENHANCEMENT.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZM9W
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZM9W                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z2BR
*   generation date: 2003.04.16 at 13:39:40 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z2BR                .

  PERFORM TABLEPROC.

ENDFUNCTION.

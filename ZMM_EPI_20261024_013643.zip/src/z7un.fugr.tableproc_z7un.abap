*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z7UN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z7UN                .

  PERFORM TABLEPROC.

ENDFUNCTION.

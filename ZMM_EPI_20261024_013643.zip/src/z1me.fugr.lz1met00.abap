*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME735UOM.......................................*
DATA:  BEGIN OF STATUS_ZME735UOM                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME735UOM                     .
CONTROLS: TCTRL_ZME735UOM
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME735UOM                     .
TABLES: ZME735UOM                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

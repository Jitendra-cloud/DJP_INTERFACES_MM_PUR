*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 06/17/2003 at 16:33:13 by user HRGOMEZ
*---------------------------------------------------------------------*
*...processing: ZMNXT...........................................*
DATA:  BEGIN OF STATUS_ZMNXT                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMNXT                         .
CONTROLS: TCTRL_ZMNXT
            TYPE TABLEVIEW USING SCREEN '0002'.
*...processing: ZMSTKREQ........................................*
DATA:  BEGIN OF STATUS_ZMSTKREQ                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMSTKREQ                      .
CONTROLS: TCTRL_ZMSTKREQ
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMNXT                         .
TABLES: *ZMSTKREQ                      .
TABLES: ZMNXT                          .
TABLES: ZMSTKREQ                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

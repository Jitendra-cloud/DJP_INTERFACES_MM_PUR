*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMCL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMCL                .

  PERFORM TABLEPROC.

ENDFUNCTION.

FUNCTION-POOL ZME10022_TICKETS           MESSAGE-ID SV.

* INCLUDE LZME10022_TICKETSD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZME10022_TICKETST00                    . "view rel. data dcl.

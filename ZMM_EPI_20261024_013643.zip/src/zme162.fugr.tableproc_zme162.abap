*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME162
*   generation date: 2003.05.12 at 15:52:49 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME162              .

  PERFORM TABLEPROC.

ENDFUNCTION.

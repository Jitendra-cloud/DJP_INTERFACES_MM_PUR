*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME10022_TICKETS................................*
DATA:  BEGIN OF STATUS_ZME10022_TICKETS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME10022_TICKETS              .
CONTROLS: TCTRL_ZME10022_TICKETS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME10022_TICKETS              .
TABLES: ZME10022_TICKETS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

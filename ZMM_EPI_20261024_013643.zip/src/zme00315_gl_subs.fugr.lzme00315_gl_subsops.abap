*&---------------------------------------------------------------------*
*&  Include           LZME00315_GL_SUBSOPS                             *
*&---------------------------------------------------------------------*
TYPES: BEGIN OF CCDESCRT,
         KOSTL TYPE CSKT-KOSTL,
         KTEXT TYPE CSKT-KTEXT,
       END OF CCDESCRT.

TYPES: BEGIN OF ACDESCRT,
         SAKNR TYPE SKAT-SAKNR,
         TXT20 TYPE SKAT-TXT20,
       END OF ACDESCRT.

DATA: CCDSCR_BUFTAB TYPE SORTED TABLE OF CCDESCRT WITH UNIQUE KEY KOSTL.
DATA: ACDSCR_BUFTAB TYPE SORTED TABLE OF ACDESCRT WITH UNIQUE KEY SAKNR.

DATA: CC_DSCR TYPE CSKT-KTEXT,
      CA_DSCR TYPE SKAT-TXT20,
      SA_DSCR TYPE SKAT-TXT20.
*&---------------------------------------------------------------------*
*&      Module  fill_descr  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE FILL_DESCR OUTPUT.
  PERFORM GET_DESCR.
ENDMODULE.                 " fill_descr  OUTPUT

*&--------------------------------------------------------------------*
*&      Form  get_descr
*&--------------------------------------------------------------------*
FORM GET_DESCR.
  DATA: WA_CC TYPE CCDESCRT,
        WA_AC TYPE ACDESCRT.

  READ TABLE CCDSCR_BUFTAB INTO WA_CC WITH KEY KOSTL = EXTRACT+7(10).
  IF SY-SUBRC = 0.
    CC_DSCR = WA_CC-KTEXT.
  ELSE.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF WA_CC FROM CSKT
        WHERE KOSTL = EXTRACT+7(10) AND SPRAS = SY-LANGU AND
              KOKRS = 'IPUS' AND DATBI >= SY-DATUM.
    IF SY-SUBRC = 0.
      CC_DSCR = WA_CC-KTEXT.
      INSERT WA_CC INTO TABLE CCDSCR_BUFTAB.
    ELSE.
      CLEAR CC_DSCR.
    ENDIF.
  ENDIF.

  READ TABLE ACDSCR_BUFTAB INTO WA_AC WITH KEY SAKNR = EXTRACT+17(10).
  IF SY-SUBRC = 0.
    CA_DSCR = WA_AC-TXT20.
  ELSE.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF WA_AC FROM SKAT
        WHERE SAKNR = EXTRACT+17(10) AND SPRAS = SY-LANGU AND
              KTOPL = 'IPGL'.
    IF SY-SUBRC = 0.
      CA_DSCR = WA_AC-TXT20.
      INSERT WA_AC INTO TABLE ACDSCR_BUFTAB.
    ELSE.
      CLEAR CA_DSCR.
    ENDIF.
  ENDIF.

  READ TABLE ACDSCR_BUFTAB INTO WA_AC WITH KEY SAKNR = EXTRACT+27(10).
  IF SY-SUBRC = 0.
    SA_DSCR = WA_AC-TXT20.
  ELSE.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF WA_AC FROM SKAT
        WHERE SAKNR = EXTRACT+27(10) AND SPRAS = SY-LANGU AND
              KTOPL = 'IPGL'.
    IF SY-SUBRC = 0.
      SA_DSCR = WA_AC-TXT20.
      INSERT WA_AC INTO TABLE ACDSCR_BUFTAB.
    ELSE.
      CLEAR SA_DSCR.
    ENDIF.
  ENDIF.
ENDFORM.                    "get_descr

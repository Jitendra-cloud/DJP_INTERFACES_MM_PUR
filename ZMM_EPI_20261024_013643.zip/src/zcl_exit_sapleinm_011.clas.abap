class ZCL_EXIT_SAPLEINM_011 definition
  public
  final
  create public .

public section.

  methods EXIT_SAPLEINM_011
    importing
      !IS_DEKKO type EKKO
      !IS_DPEKKO type PEKKO
      !IS_CONTROL_RECORD_OUT type EDIDC
      !IS_DOBJECT type NAST
    changing
      !CT_DEKPO type MEOUT_T_UEKPO
      !CT_DPEKPO type MMPR_PEKPO
      !CT_DEKET type MMPR_UEKET
      !CT_DESLL type TAB_ML_ESLL
      !CT_DINT_EDIDD type EDIDD_TT .
  PROTECTED SECTION.
private section.

  methods BUILD_ECM_PO_I10533
    importing
      !IS_DEKKO type EKKO
      !IS_CONTROL_RECORD_OUT type EDIDC
    changing
      !CT_DEKPO type MEOUT_T_UEKPO
      !CT_DINT_EDIDD type EDIDD_TT .
ENDCLASS.



CLASS ZCL_EXIT_SAPLEINM_011 IMPLEMENTATION.


  METHOD build_ecm_po_i10533.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_EXIT_SAPLEINM_011            Create Date: 09/17/2020 *
* Method:       BUILD_ECM_PO_I10533                                    *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Method to be used for the ECM IDOC generation          *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020              Build ECM outbound PO IDOC *
************************************************************************
    CONSTANTS: lc_po_ecm_chg TYPE edi_mestyp VALUE 'ZMM_PO_ECM_CHG',
               lc_po_ecm_cr  TYPE edi_mestyp VALUE 'ZMM_PO_ECM_CR'.
    IF is_control_record_out-mestyp = lc_po_ecm_chg OR
       is_control_record_out-mestyp = lc_po_ecm_cr.
      DATA(lo_ecm_idoc) = NEW zcl_mm_i10533_exit( is_ekko = is_dekko ).

      lo_ecm_idoc->build_ecm_po_idoc(
      EXPORTING
          is_ekko = is_dekko
        CHANGING
          ct_edidd = ct_dint_edidd[]
          ct_ekpo  = ct_dekpo[]
      ).
    ENDIF.
  ENDMETHOD.


  METHOD exit_sapleinm_011.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_EXIT_SAPLEINM_011            Create Date: 09/17/2020 *
* Method:       EXIT_SAPLEINM_011                                      *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Common Method to be used for the future development in *
* EXIT_SAPLEINM_011 .                                                  *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020              Common user eixt           *
************************************************************************
    build_ecm_po_i10533(
      EXPORTING
        is_dekko              =  is_dekko               " Purchasing Document Header
        is_control_record_out =  is_control_record_out  " Control record (IDoc)
      CHANGING
        ct_dekpo              =  ct_dekpo               " Table Type Update Structure EKPO
        ct_dint_edidd         =  ct_dint_edidd          " Table Type for EDIDD (IDoc Data Records)
    ).
  ENDMETHOD.
ENDCLASS.

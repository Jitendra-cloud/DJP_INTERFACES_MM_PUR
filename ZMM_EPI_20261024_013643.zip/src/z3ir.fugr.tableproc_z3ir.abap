*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3IR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3IR                .

  PERFORM TABLEPROC.

ENDFUNCTION.

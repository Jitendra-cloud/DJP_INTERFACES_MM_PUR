*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 2002.09.09 at 09:31:12 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMFGNAME........................................*
DATA:  BEGIN OF STATUS_ZMFGNAME                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMFGNAME                      .
CONTROLS: TCTRL_ZMFGNAME
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMFGNAME                      .
TABLES: ZMFGNAME                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

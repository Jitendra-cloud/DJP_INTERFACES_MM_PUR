*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMPLNTREG......................................*
DATA:  BEGIN OF STATUS_ZMMPLNTREG                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMPLNTREG                    .
CONTROLS: TCTRL_ZMMPLNTREG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMMPLNTREG                    .
TABLES: ZMMPLNTREG                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

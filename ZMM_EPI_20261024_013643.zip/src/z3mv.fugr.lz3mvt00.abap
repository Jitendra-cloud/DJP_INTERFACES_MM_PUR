*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZVNPR...........................................*
DATA:  BEGIN OF STATUS_ZVNPR                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVNPR                         .
CONTROLS: TCTRL_ZVNPR
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZVNPR                         .
TABLES: ZVNPR                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

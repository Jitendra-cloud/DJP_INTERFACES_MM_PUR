*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMATNR_PRICE...................................*
DATA:  BEGIN OF STATUS_ZMMATNR_PRICE                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMATNR_PRICE                 .
CONTROLS: TCTRL_ZMMATNR_PRICE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMMATNR_PRICE                 .
TABLES: ZMMATNR_PRICE                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

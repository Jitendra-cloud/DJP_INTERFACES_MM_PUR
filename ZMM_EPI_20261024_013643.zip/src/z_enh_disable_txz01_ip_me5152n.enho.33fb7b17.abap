"Name: \TY:CL_GRID_VIEW_MM\ME:BUILD_GRID_LAYOUT\SE:END\EI
ENHANCEMENT 0 Z_ENH_DISABLE_TXZ01_IP_ME5152N.
*BEGIN OF---> CMS#28470 E0VK9A0CYT 6/11/2015 BR TXZ01 Chg SMITHAI
    DATA: gt_zmmfld TYPE STANDARD TABLE OF zmmfld,
          gc_e10563 TYPE C LENGTH 6 VALUE 'E10563',
          gc_ekorg  TYPE C LENGTH 5 VALUE 'EKORG',
          lv_lvc_styl TYPE lvc_s_styl,
          lv_maktx TYPE makt-maktx,
          lv_matnr TYPE matnr,
          l_disable_IP(1).

    FIELD-SYMBOLS: <lt_pritem> TYPE STANDARD TABLE,
    <ls_pritem> TYPE ANY,
    <lv_ekorg>  TYPE ANY,
    <lv_werks>  TYPE ANY,
    <lv_matnr>  TYPE ANY,
    <lv_txz01>  TYPE ANY.

    IF sy-dynnr = '3212' AND ( sy-tcode = 'ME51N' OR sy-tcode = 'ME52N' OR sy-tcode = 'ME53N').
      IF GT_TABLE IS NOT INITIAL.
        ASSIGN gt_table->* TO <lt_pritem>.
        LOOP AT <lt_pritem> ASSIGNING <ls_pritem>.
          ASSIGN COMPONENT 'TXZ01' OF STRUCTURE <ls_pritem> TO <lv_txz01>.
          ASSIGN COMPONENT 'MATNR' OF STRUCTURE <ls_pritem> TO <lv_matnr>.
          ASSIGN COMPONENT 'EKORG' OF STRUCTURE <ls_pritem> TO <lv_ekorg>.
          ASSIGN COMPONENT 'WERKS' OF STRUCTURE <ls_pritem> TO <lv_werks>.
          ASSIGN COMPONENT my_layout_cell OF STRUCTURE <ls_pritem> TO <styletab>.

          IF NOT sy-subrc IS INITIAL.
            EXIT.
          ENDIF.

          LOOP AT my_dynpro_fields INTO l_dynpro_field.
            IF l_dynpro_field-fieldname = 'EKORG'.
              IF <lv_ekorg> IS ASSIGNED.
                SELECT * INTO TABLE gt_zmmfld FROM zmmfld WHERE key1 EQ gc_e10563 AND
                                                                key2 EQ gc_ekorg  AND
                                                                value1 = <lv_ekorg>.
                IF sy-subrc = 0.
*-------Check Plant / Material / P.Org combination exists.
                  CLEAR lv_matnr.
                  SELECT SINGLE a~matnr INTO lv_matnr FROM marc AS a INNER JOIN t024w AS b ON
                  a~werks = b~werks WHERE
                  a~matnr = <lv_matnr> AND
                  b~werks = <lv_werks> AND
                  b~ekorg = <lv_ekorg>.
                  IF sy-subrc = 0.
                    l_disable_IP = 'X'.
                  ELSE.
                    CLEAR l_disable_IP.
                  ENDIF. "End of Plant / Material / Combination check.
                ENDIF. " End of ZMMFLD P.Org check.
              ENDIF.
            ENDIF.
*  -------Change TXZ01 Text.
            IF l_dynpro_field-fieldname = 'MATNR' AND l_disable_IP = 'X'.
              CLEAR lv_maktx.
              SELECT SINGLE MAKTX FROM MAKT INTO lv_maktx WHERE matnr = <lv_matnr> AND
              spras = sy-langu.
              IF Sy-subrc = 0.
                IF <lv_txz01> <> lv_maktx.
*              <lv_txz01> = lv_maktx.
                  MESSAGE ID 'ZM' TYPE 'I' NUMBER '336' WITH <lv_matnr>.
                ENDIF.
              ENDIF.
            ENDIF.
*  -------Check Purchase Organization for Brazil in ZMMFLD.
            IF l_dynpro_field-fieldname = 'TXZ01' AND l_disable_IP = 'X'.
              lv_lvc_styl-fieldname = l_dynpro_field-fieldname.
              lv_lvc_styl-style     = cl_gui_alv_grid=>mc_style_disabled.
              INSERT lv_lvc_styl INTO TABLE <styletab>.
              CLEAR lv_lvc_styl.
            ENDIF.
          ENDLOOP.
          CLEAR: lv_maktx, l_disable_IP.
        ENDLOOP.
      ENDIF.
    ENDIF. "End of Check for Screen / Sy-tcode.
*END OF<--- CMS#28470 E0VK9A0CYT 8/11/2015 BR TXZ01 Chg SMITHAI

ENDENHANCEMENT.

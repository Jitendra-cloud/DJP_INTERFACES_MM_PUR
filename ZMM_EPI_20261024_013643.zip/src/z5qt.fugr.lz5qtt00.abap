*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZVQTY...........................................*
DATA:  BEGIN OF STATUS_ZVQTY                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVQTY                         .
CONTROLS: TCTRL_ZVQTY
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZVQTY                         .
TABLES: ZVQTY                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME1251_STOCKOUT
*   generation date: 2003.04.16 at 13:51:16 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME1251_STOCKOUT    .

  PERFORM TABLEPROC.

ENDFUNCTION.

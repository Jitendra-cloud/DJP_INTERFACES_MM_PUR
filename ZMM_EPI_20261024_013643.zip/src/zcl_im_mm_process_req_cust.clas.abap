class ZCL_IM_MM_PROCESS_REQ_CUST definition
  public
  final
  create public .

public section.
*"* public components of class ZCL_IM_MM_PROCESS_REQ_CUST
*"* do not include other source files here!!!

  interfaces IF_EX_ME_PROCESS_REQ_CUST .
protected section.
*"* protected components of class ZCL_IM_MM_PROCESS_REQ_CUST
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_IM_MM_PROCESS_REQ_CUST
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_IM_MM_PROCESS_REQ_CUST IMPLEMENTATION.


method if_ex_me_process_req_cust~check.

*---------------------------------------------------------------------
* Change History:                                                      *
*  Programmer        Date        Req.#     Action                      *
* =================  ========== ========== ============================*
* J.Grabowiecki     03/2014 E0V 26320   Validate Cost Center/GL Account
*                                       in ZCECV
*---------------------------------------------------------------------


*---------------------------------------------------------------------
* E0V 26320 start
* Cost Center/GL Account validation done in PROCESS_ACCOUNT. Here,
* search error messages for the one created in PROCESS_ACCOUNT. If
* found, invalidate the PR

  data: lt_evnt type mmpur_events.
  data: l_handler type ref to cl_message_handler_mm.
  data: ls_evnt type mmpur_events_line.
  data: l_message type ref to cl_message_mm.

  call method cl_message_handler_mm=>get_handler
    importing
      ex_handler = l_handler.

  call method l_handler->getlist
    importing
      ex_evnt = lt_evnt.

  loop at lt_evnt into ls_evnt.
    l_message ?= ls_evnt-event.
    if l_message->msgty = 'E'  and
       l_message->msgid = 'Z1' and
       l_message->msgno = '016'.
      ch_failed = 'X'.
      exit.
    endif.
  endloop.
* E0V 26320 end

endmethod.


method IF_EX_ME_PROCESS_REQ_CUST~CLOSE.
endmethod.


method IF_EX_ME_PROCESS_REQ_CUST~FIELDSELECTION_HEADER.
endmethod.


method IF_EX_ME_PROCESS_REQ_CUST~FIELDSELECTION_HEADER_REFKEYS.
*Begin of changes mkasina/S0VK907604/ 2000001885
  DATA:gv_bsart TYPE bsart ."VALUE 'SRVC'..

  DATA(ls_header) = im_header->get_data( ).
  gv_bsart = ls_header-bsart.
  EXPORT gv_bsart FROM gv_bsart TO MEMORY ID 'LV_DOCTYP'.
**End of changes mkasina/S0VK907604/ 2000001885
endmethod.


METHOD if_ex_me_process_req_cust~fieldselection_item.
ENDMETHOD.


METHOD if_ex_me_process_req_cust~fieldselection_item_refkeys.
*begin of changes MKASINA/S0VK907604/ 2000001885
  DATA(ls_item) = im_item->get_data( ).
  if ls_item-konnr is not initial.
  data(gv_WERKS) = ls_item-werks .
  EXPORT gv_werks FROM gv_werks TO MEMORY ID 'LV_PLANT'.
  endif.
*End of changes MKASINA/S0VK907604/ 2000001885
ENDMETHOD.


method IF_EX_ME_PROCESS_REQ_CUST~INITIALIZE.
endmethod.


METHOD if_ex_me_process_req_cust~open.
ENDMETHOD.


METHOD if_ex_me_process_req_cust~post.
ENDMETHOD.


method if_ex_me_process_req_cust~process_account.
*---------------------------------------------------------------------
* Change History:                                                      *
*  Programmer        Date        Req.#     Action                      *
* =================  ========== ========== ============================*
* J.Grabowiecki     03/2014 E0V 26320   Validate Cost Center/GL Account
*                                       in ZCECV
*---------------------------------------------------------------------

  include mm_messages_mac.

*---------------------------------------------------------------------
* E0V 26320-start

  data: ls_item type mereq_item.
  data: ls_acct type exkn.

  ls_acct = im_account_ref->get_data( ).
  ls_item = im_account_ref->get_item( )->get_data( ).


*CALL METHOD cl_message_handler_mm=>get_handler
*      IMPORTING
*        ex_handler = l_msg_handler.


  if ls_acct-kostl is not initial and
     ls_acct-sakto is not initial.

    call function 'ZMM_VALIDATE_CC_ACCT'
      exporting
        i_kokrs = ls_acct-kokrs
        i_kostl = ls_acct-kostl
        i_hkont = ls_acct-sakto
        i_bsart = ls_item-bsart
      exceptions
        invalid = 1
        others  = 2.

    if sy-subrc <> 0.
      mmpur_message_forced 'E' 'Z1' '016'
                    ls_acct-sakto ls_acct-kostl '' ''.
    endif.
  endif.
* E0V 26320-end
*---------------------------------------------------------------------


endmethod.


METHOD if_ex_me_process_req_cust~process_header.
**Begin of changes mkasina/S0VK907604/ 2000001885
**ME51N by selecting document type ‘SRVC’ and item category ‘D’
*  DATA:gv_bsart TYPE bsart VALUE 'SRVC'.
*
*  DATA(ls_header) = im_header->get_data( ).
*  gv_bsart = ls_header-bsart.
*  EXPORT gv_bsart FROM gv_bsart TO MEMORY ID 'LV_DOCTYP'.
**End of changes mkasina/S0VK907604/ 2000001885
ENDMETHOD.


METHOD if_ex_me_process_req_cust~process_item.
*&**********************************************************************
*&                                                                     *
*&             C O M P A N Y   C O N F I D E N T I A L                 *
*&                                                                     *
*&        This program is the property of International Paper.         *
*&        Care should be taken to prevent its unauthorized use.        *
*&                                                                     *
*&**********************************************************************
*&                                                                     *
*&             COPYRIGHT © 2018 by INTERNATIONAL PAPER                 *
*&                                                                     *
*&                     ALL RIGHTS RESERVED                             *
*&                                                                     *
*&                     REVISIONS COPYRIGHT ©                           *
*&                       20xx, 20yy, 20zz                              *
*&                             by                                      *
*&                     INTERNATIONAL PAPER                             *
*&                                                                     *
*&**********************************************************************
*& BADI Name     : ME_PROCESS_REQ_CUST                                 *
*& Implementation: ZMM_PROCESS_REQ_CUST                                *
*& Written by    : Mallik Aiely                                        *
*& Date written  : 07-July-2019                                        *
*& Description   : BADI implementation                                 *
*&**********************************************************************
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* =====================================================================*
* Mallik Aiely        07/09/19  E0VK9A0XCM   CD2000002854:Process PR   *
*                                            Item                      *
* =====================================================================*

*-set Catalog item on PR item for CD2000002854:Auto PR to PO
  CALL METHOD zcl_e03097_preq_catalog_item=>preq_process_item
    EXPORTING
      io_item    = im_item
      iv_count   = im_count
      io_refitem = im_ref_item.


*Start of code change by PBOMMIR on 01.23.2023
*Logic shared by Cast costa team    : PMC 120 / Enhancement name 60.030
  zcl_e03097_preq_catalog_item=>preq_process_item_brazil(
    EXPORTING
      im_item    =  im_item              " Purchase Requisition (External View)
      iv_count   =  im_count
      im_refitem =  im_ref_item             " Purchase Requisition (External View)
  ).
*Start of code change by PBOMMIR on 01.23.2023
ENDMETHOD.
ENDCLASS.

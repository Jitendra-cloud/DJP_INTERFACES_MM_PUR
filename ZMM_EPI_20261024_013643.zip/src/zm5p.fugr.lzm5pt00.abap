*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMATLGRP_DESC..................................*
DATA:  BEGIN OF STATUS_ZMMATLGRP_DESC                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMATLGRP_DESC                .
CONTROLS: TCTRL_ZMMATLGRP_DESC
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZMMATLGRP_HIER..................................*
DATA:  BEGIN OF STATUS_ZMMATLGRP_HIER                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMATLGRP_HIER                .
CONTROLS: TCTRL_ZMMATLGRP_HIER
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZMMATLGRP_DESC                .
TABLES: *ZMMATLGRP_HIER                .
TABLES: ZMMATLGRP_DESC                 .
TABLES: ZMMATLGRP_HIER                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

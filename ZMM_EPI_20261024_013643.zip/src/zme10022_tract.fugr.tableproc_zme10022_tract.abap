*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME10022_TRACT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME10022_TRACT      .

  PERFORM TABLEPROC.

ENDFUNCTION.

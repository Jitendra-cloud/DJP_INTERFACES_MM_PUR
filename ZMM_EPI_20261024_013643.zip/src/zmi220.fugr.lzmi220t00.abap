*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMI220D.........................................*
DATA:  BEGIN OF STATUS_ZMI220D                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMI220D                       .
CONTROLS: TCTRL_ZMI220D
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZMI220M.........................................*
DATA:  BEGIN OF STATUS_ZMI220M                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMI220M                       .
CONTROLS: TCTRL_ZMI220M
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZMI220D                       .
TABLES: *ZMI220M                       .
TABLES: ZMI220D                        .
TABLES: ZMI220M                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

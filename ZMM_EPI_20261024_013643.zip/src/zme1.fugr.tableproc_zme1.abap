*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME1
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME1                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 01/13/2003 at 16:25:11 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMSTKCLASS......................................*
DATA:  BEGIN OF STATUS_ZMSTKCLASS                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMSTKCLASS                    .
CONTROLS: TCTRL_ZMSTKCLASS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMSTKCLASS                    .
TABLES: ZMSTKCLASS                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

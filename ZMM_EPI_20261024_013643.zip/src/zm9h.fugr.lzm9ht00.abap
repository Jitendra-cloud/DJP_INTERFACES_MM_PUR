*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_CONTRACT_PO.................................*
DATA:  BEGIN OF STATUS_ZMM_CONTRACT_PO               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_CONTRACT_PO               .
CONTROLS: TCTRL_ZMM_CONTRACT_PO
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZMM_CONTRACT_PO               .
TABLES: ZMM_CONTRACT_PO                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

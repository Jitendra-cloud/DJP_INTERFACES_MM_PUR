"Name: \FU:CO_ZF_BANF_PROC\SE:BEGIN\EI
ENHANCEMENT 0 Z_EI_WO_REVNR_TO_PR_OUTAGE.
*-->CMS29838 E0VK9A0IWG SMITHAI 02/15/2016
*---While Create/Change/Display of Work Order, Populate Outage field in PR.
IF sy-tcode = 'IW31' OR sy-tcode = 'IW32' OR
   sy-tcode = 'IW21' OR sy-tcode = 'IW22' OR
   sy-tcode = 'IW34' OR sy-tcode = 'IW36'.
  eban_imp-zz_outage = CAUFVD-REVNR.
ENDIF.
*<--CMS29838 E0VK9A0IWG SMITHAI 02/15/2016
ENDENHANCEMENT.

"Name: \FU:MEPOBADI_FS_ITEM\SE:END\EI
ENHANCEMENT 0 ZMM_PO_FIELDCHANGES.
  "Soc by PBOMMIR  on 03.Aug.2023 for S 2000001033: PO update with Outline agreement
DATA(ls_mepoheader) = im_header->get_data( ).
DATA(ls_item)        = im_item->get_data( ).
IF ls_item-konnr IS NOT INITIAL.
  SELECT  * FROM zmmfld
         INTO  TABLE @DATA(lt_exit)
         WHERE key1   = 'ZBRAZIL_PO_AGREEMENT'
         AND   key3   IN ( 'INCLUDE' , 'TCODE' ).
  IF sy-subrc = 0 .
    SORT lt_exit BY key1.
  ENDIF.

  IF line_exists( lt_exit[ key1 = 'ZBRAZIL_PO_AGREEMENT'
                           key2 = ls_mepoheader-bukrs
                           key3 = 'INCLUDE' ] ) AND  line_exists( lt_exit[ key1 = 'ZBRAZIL_PO_AGREEMENT'
                                                                           key2 = sy-tcode
                                                                           key3 = 'TCODE' ] ) .
    READ TABLE ch_fieldselection ASSIGNING FIELD-SYMBOL(<fs_fsel>) WITH TABLE KEY metafield = 61.  "061.
    IF sy-subrc IS INITIAL.
      <fs_fsel>-fieldstatus = '*'. " Display
    ENDIF.

  ENDIF.
ENDIF.

  "Eoc by PBOMMIR  on 03.Aug.2023 for S 2000001033: PO update with Outline agreement

ENDENHANCEMENT.

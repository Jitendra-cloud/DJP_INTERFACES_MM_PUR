*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTMMLBL.........................................*
DATA:  BEGIN OF STATUS_ZTMMLBL                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTMMLBL                       .
CONTROLS: TCTRL_ZTMMLBL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTMMLBL                       .
TABLES: ZTMMLBL                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

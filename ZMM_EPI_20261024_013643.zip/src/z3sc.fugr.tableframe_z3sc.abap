*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z3SC
*   generation date: 2003.05.12 at 15:37:00 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z3SC               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

class ZCL_ME_PROCESS_PO_CUST definition
  public
  final
  create public .

public section.

  class-data GV_CLM_FLAG type ABAP_BOOL .

  class-methods PROCESS_ITEM
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_HEADER
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_POST
    importing
      !IM_EBELN type EBELN
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_ARIBA_POST
    importing
      !IM_EBELN type EBELN
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
protected section.
private section.

  class-data GC_RFSCOP type ZKEY1 value 'RFSCOP' ##NO_TEXT.
  constants GC_E04990 type ZKEY1 value 'E04990' ##NO_TEXT.
  class-data GC_E11016 type ZKEY1 value 'E11016' ##NO_TEXT.
  class-data GC_EKORG type ZKEY1 value 'EKORG' ##NO_TEXT.
  constants GC_ZMM_RFSCOP type ZKEY1 value 'ZMM_RFSCOP' ##NO_TEXT.
  constants GC_MESSAGES type ZKEY1 value 'MESSAGES' ##NO_TEXT.
  constants GC_MATERIAL_GROUP type ZKEY1 value 'MATERIAL_GROUP' ##NO_TEXT.
  constants GC_KAPPL_M type KAPPL value 'M' ##NO_TEXT.
  constants GC_KSCHL_ZRIN type KSCHA value 'ZRIN' ##NO_TEXT.

  class-methods PROCESS_ITEM_RFSCOP_E11056
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_HEADER_RFSCOP_E11163
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_RFSCOP
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_ARIBA
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_RFSCOP_E11117
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_RFSCOP_E11118
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_HEADER_RFSCOP
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_HEADER_RFSCOP_E11016
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_HEADER_RFSCOP_E11017
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_RFSCOP_E04990
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_ITEM_RFSCOP_E11185
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_HEADER_RFSCOP_E11056
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_ARIBA_PO_GRUPDATE
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_ARIBA_SUPP_UPDATE
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods ADD_PARTNER_TO_PO
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM
      !IV_LIFNR type LIFNR
      !IV_PARVW type PARVW .
  class-methods PROCESS_CLM_E10271_HEADER
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_CLM_E10271_ITEM
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_CATALOG_AUXID_E03097
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods SET_PO_AUX_PRODID
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM
      !IO_SUPP_PRODID type AVWCTXCONT .
  class-methods PROCESS_SYLVAMO
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_SYLVAMO_E11733
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_HEADER_BRAZIL
    importing
      !IM_HEADER type ref to IF_PURCHASE_ORDER_MM .
  class-methods PROCESS_ITEM_BRAZIL
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
  class-methods PROCESS_BRAZIL_NCM
    importing
      !IM_ITEM type ref to IF_PURCHASE_ORDER_ITEM_MM .
ENDCLASS.



CLASS ZCL_ME_PROCESS_PO_CUST IMPLEMENTATION.


  method add_partner_to_po.

    constants: lc_appli type char1 value 'P'.
    constants: lc_flag type char1 value 'X'.

    data: lr_header type ref to if_purchase_order_mm.
    data: ls_header type mepoheader.
    data: lt_mmpa type mmpur_t_mmpa.
    data: lt_ekpa type mmpur_t_ekpa.
    data: ls_mmpa type mmpa.
    data: ls_ekpa type ekpa.
    data: lv_pargr type pargr. "Partner determination procedure

* Get PO Header Object
    lr_header = im_item->get_header( ).

* Read PO Header Data
    ls_header = lr_header->get_data( ).

* Read PO Header Partners from Buffer

    call function 'MM_READ_PARTNERS'
      exporting
        application = lc_appli
      tables
        x_ekpa      = lt_ekpa.

    select single pargr from t161 into lv_pargr
      where bsart = ls_header-bsart
        and bstyp = ls_header-bstyp.

    if lv_pargr is not initial.

* To Ensure that Current Ordering Address Partner is already added to Partners Tab.
      read table lt_ekpa into ls_ekpa with key  parvw = iv_parvw
                                                lifn2 = iv_lifnr.

      if sy-subrc <> 0.

        loop at lt_ekpa into ls_ekpa.

          move-corresponding ls_ekpa to ls_mmpa.
          append ls_mmpa to lt_mmpa.

        endloop.

        ls_mmpa-ebeln = ls_header-ebeln.
        ls_mmpa-ekorg = ls_header-ekorg.
        ls_mmpa-parvw = iv_parvw.
        ls_mmpa-lifn2 = iv_lifnr.
        ls_mmpa-parza = 000.
        ls_mmpa-ernam = sy-uname.
        ls_mmpa-erdat = sy-datum.

        append ls_mmpa to lt_mmpa.

        if not lt_mmpa[] is initial.

*     Update Partner Tab
          call function 'MM_MAINTAIN_PARTNERS'
            exporting
              application       = lc_appli
              ebeln             = ls_header-ebeln
              bstyp             = ls_header-bstyp
              ekorg             = ls_header-ekorg
              lifnr             = ls_header-lifnr
              pargr             = lv_pargr
              screen_invisible  = lc_flag
            tables
              x_mmpa             = lt_mmpa.
        endif.

      endif.
    endif.

  endmethod.


  METHOD process_ariba.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 09/14/2018 *
* Method:       PROCESS_ARIBA                                         *
* Programmer  : Mallik Aiely                      Last Update:         *
*______________________________________________________________________*
* Description: ALL ARIBA BADI changes                                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Mallik Aiely       09/14/2018 E0V 33780  Initial transport           *
************************************************************************

*-Update Po line item Goods Receipt
    CALL METHOD zcl_me_process_po_cust=>process_ariba_po_grupdate
      EXPORTING
        im_item = im_item.

*-Update PO Line Supplier Data on extras Tab
    CALL METHOD zcl_me_process_po_cust=>process_ariba_supp_update
      EXPORTING
        im_item = im_item.

*-Update PO Line item text Supplier Aux.PArt ID on
    CALL METHOD zcl_me_process_po_cust=>process_catalog_auxid_e03097
      EXPORTING
        im_item = im_item.

  ENDMETHOD.


  METHOD process_ariba_post.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 10/17/2017 *
* Method      : PROCESS_ARIBA_POST                                     *
* Programmer  : MAIELY                            Last Update:         *
*______________________________________________________________________*
* Description: ARIBA PO POST: This method is used in ARIBA , when the  *
*              PO Post is called from BADI Method POST                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date       Req. #               Action         *
* ==================  ========    =========  ========================= *
* Mallik Aiely        03/05/2018  E0V 33780  Ariba PO Post Changes     *
************************************************************************

*-The below Memory is Exported from the BADI Shown below
*-BADI:ARBERP_INBOUND_MAPPING
*-Implementation:ZMM_ARIBA_INBOUND_MAPPING
*-Class Used :ZCL_MM_ARIBA_INBOUND_MAPPING Method:IF_ARBERP_BADI_INB_MAP~MAP_CONF_TO_BUS2012_IN_PRE

*-The below Memory is Imported In below BADI
*-BADI:ME_PROCESS_PO_CUST
*-Implementation:ZMME_PROCESS_PO_CUST
*-Class Used :ZCL_IM_MME_PROCESS_PO_CUST Method:PROCESS_ITEM
*-Local Class Used :ZCL_ME_PROCESS_PO_CUST  Method:PROCESS_ARIBA_SUPP_UPDATE

*-This Free memory statement will execute during PO Post and will execute only once per PO
    FREE MEMORY ID 'ARIBA_E10909_CONF'.

  ENDMETHOD.


  METHOD process_ariba_po_grupdate.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 03/10/2017 *
* Method      : PROCESS_ARIBA_ITEM                                     *
* Programmer  : A PUNJAALA                        Last Update:         *
*______________________________________________________________________*
* Description: ARIBA PO INBOUND CHANGES:Over writing the CSV file      *
*              coming from Ariba                                       *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date       Req. #               Action         *
* ==================  ========    =========  ========================= *
* APUNJAA             03/10/2017  E0V 31393  Initial transport         *
* Mallik Aiely        03/05/2018  E0V 33275  Split Acct: GR/ non Val GR*
*                                            issue fix for PO-inbound  *
*John William         11/16/2018  E0V 33962  GR Update Changes         *
*John William         12/20/2018  E0V 34509  Update revision code      *
*                                            uniquename in line item   *
************************************************************************

* CMS31393|ChangedBy:APUNJAA|ChangedOn:03102017|START
*->ARIBA PO INBOUND CHANGES
    DATA : t_po_lineitems TYPE TABLE OF /arba/popush_csv_lineitems,
           wa_po_linedata TYPE /arba/popush_csv_lineitems,
           wa_lineitems   TYPE /arba/po_items,
           t_lineitems    TYPE TABLE OF /arba/po_items.

    DATA(ls_mepoitem) = im_item->get_data( ).
    DATA(im_header) = im_item->get_header( ).
    DATA(ls_mepoheader) = im_header->get_data( ).

    CLEAR: wa_po_linedata, wa_lineitems.

* Import CSV strcture with addtional fields
* Start of change JWILL68 08/27/2018 CMS# 33962
*This T_PO_LINEITEMS_MEM has been exported form
*BADI: /ARBA/PO_FILE_CHANNL
* IMPLEMENTATION: ZMM_ARIBA_PO_IN
* Method: /ARBA/IF_EX_PO_FILE_CHANNL~PUBLISH_PO_CREATE
* Method: /ARBA/IF_EX_PO_FILE_CHANNL~PUBLISH_CHANGE_PO
*    IMPORT t_po_lineitems_mem TO t_po_lineitems FROM MEMORY ID 'ARIBA_CSV_ITEMDATA'.
*    IMPORT t_lineitems_mem TO t_lineitems FROM MEMORY ID 'ARIBA_CSV_ITEMDATACHG'.
* End of change JWILL68 08/27/2018 CMS# 33962
    IMPORT t_po_lineitems_mem TO t_po_lineitems FROM MEMORY ID 'ARIBA_CSV_ITEMDATA'.
    IMPORT t_lineitems_mem TO t_lineitems FROM MEMORY ID 'ARIBA_CSV_ITEMDATACHG'.

* Import Line Item data
    DATA(ls_ariba_mepoitem) = im_item->get_data( ).

* Apply changes only P2P Order types
    IF ls_mepoheader-bsart EQ 'P2P' AND sy-cprog = '/ARBA/CR_BAPI_PO_CREATE1'.

*  Read CSV strcture based on current line item
      READ TABLE t_po_lineitems INTO wa_po_linedata WITH KEY erporderid = ls_mepoheader-unsez
                                                             po_item = ls_ariba_mepoitem-ebelp.
      IF sy-subrc EQ 0.
        ls_ariba_mepoitem-mwskz = wa_po_linedata-cus_iptaxcode.
        ls_ariba_mepoitem-afnam = wa_po_linedata-cus_requester.
        ls_ariba_mepoitem-inco1 = wa_po_linedata-cus_incoterm.
        ls_ariba_mepoitem-inco2 = wa_po_linedata-incotermsdetail.
* Start of change JWILL68 08/27/2018 CMS# 33962
* Commented out as SAP team is working this issue as have to apply their change
*        ls_ariba_mepoitem-idnlf = wa_po_linedata-vend_mat.
* End of change JWILL68 08/27/2018 CMS# 33962

* Start of change JWILL68 12/20/2018 CMS# 34509
        ls_ariba_mepoitem-zz_outage = wa_po_linedata-cus_revisioncodeuniquename.
* End of change JWILL68 12/20/2018 CMS# 34509

        IF wa_po_linedata-cus_receiptflag = 'Yes'.
          ls_ariba_mepoitem-wepos = 'X'.
        ELSE.
*          ls_ariba_mepoitem-wepos = ' '.              ">33275
*          IF wa_po_linedata-distrib IS NOT INITIAL.
          ls_ariba_mepoitem-wepos = ' '.
          ls_ariba_mepoitem-weunb = ' '.
*          ENDIF.                                       "<33275
        ENDIF.
        IF wa_po_linedata-cus_griv = 'Yes'.
          ls_ariba_mepoitem-webre = 'X'.
        ELSE.
          ls_ariba_mepoitem-webre = ' '.
        ENDIF.

      ENDIF.
      CALL METHOD im_item->set_data( ls_ariba_mepoitem ).
    ENDIF.

* Apply changes only P2P Order types
    IF ls_mepoheader-bsart EQ 'P2P' AND sy-cprog = '/ARBA/CR_BAPI_PO_CHANGE'.

*  Read CSV strcture based on current line item
      READ TABLE t_lineitems INTO wa_lineitems WITH KEY ariba_item_no = ls_ariba_mepoitem-ebelp.
      IF sy-subrc EQ 0.
        ls_ariba_mepoitem-mwskz = wa_lineitems-cus_iptaxcode.
        ls_ariba_mepoitem-afnam = wa_lineitems-cus_requester.
        ls_ariba_mepoitem-inco1 = wa_lineitems-cus_incoterm.
        ls_ariba_mepoitem-inco2 = wa_lineitems-incotermsdetail.
* Start of change JWILL68 08/27/2018 CMS# 33962
* Commented out as SAP team is working this issue as have to apply their change
*        ls_ariba_mepoitem-idnlf = wa_lineitems-vend_mat.
* End of change JWILL68 08/27/2018 CMS# 33962

* Start of change JWILL68 12/20/2018 CMS# 34509
        ls_ariba_mepoitem-zz_outage = wa_lineitems-cus_revisioncodeuniquename.
* End of change JWILL68 12/20/2018 CMS# 34509

        IF wa_lineitems-cus_receiptflag = 'Yes'.
          ls_ariba_mepoitem-wepos = 'X'.
        ELSE.
*          ls_ariba_mepoitem-wepos = ' '.              ">33275
*          IF wa_po_linedata-distrib IS NOT INITIAL.
          ls_ariba_mepoitem-wepos = ' '.
          ls_ariba_mepoitem-weunb = ' '.
*          ENDIF.                                       "<33275
        ENDIF.
        IF wa_lineitems-cus_griv = 'Yes'.
          ls_ariba_mepoitem-webre = 'X'.
        ELSE.
          ls_ariba_mepoitem-webre = ' '.
        ENDIF.
      ENDIF.

      CALL METHOD im_item->set_data( ls_ariba_mepoitem ).
    ENDIF.

* CMS31393|ChangedBy:APUNJAA|ChangedOn:03102017|END
  ENDMETHOD.


  METHOD process_ariba_supp_update.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 10/16/2018 *
* Method      : PROCESS_ARIBA_ITEM                                     *
* Programmer  : MAIELY                            Last Update:         *
*______________________________________________________________________*
* Description: ARIBA PO INBOUND CHANGES:Over writing the CSV file      *
*              coming from Ariba                                       *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date       Req. #               Action         *
* ==================  ========    =========  ========================= *
* Mallik Aiely        10/16/2018  E0V 33780  Ariba:Update Supplier Data*
*                                            on extra Tab              *
************************************************************************

    DATA ct_po_item_type TYPE zmm_po_item_type_t.

    DATA(ls_mepoitem) = im_item->get_data( ).

*-The below Memory is Exported from the BADI Shown below
*-BADI:ARBERP_INBOUND_MAPPING
*-Implementation:ZMM_ARIBA_INBOUND_MAPPING
*-Class Used :ZCL_MM_ARIBA_INBOUND_MAPPING Method:IF_ARBERP_BADI_INB_MAP~MAP_CONF_TO_BUS2012_IN_PRE
    IMPORT lt_poitem_type_mem TO ct_po_item_type FROM MEMORY ID 'ARIBA_E10909_CONF'.

*-Import Line Item data
    DATA(ls_ariba_mepoitem) = im_item->get_data( ).

*-Read current line from Imported table PO/Item
    DATA(wa_po_item_type) = VALUE #( ct_po_item_type[ po_number = ls_mepoitem-ebeln
                                                      line_item = ls_mepoitem-ebelp ] OPTIONAL ).

    IF wa_po_item_type IS NOT INITIAL.

      IF wa_po_item_type-supplier_upd EQ 'X'.
        ls_ariba_mepoitem-zz_conf_part = wa_po_item_type-supplier_part.
      ENDIF.

      IF wa_po_item_type-uom_upd = 'X'.
        ls_ariba_mepoitem-zz_conf_uom = wa_po_item_type-chg_uom.
      ENDIF.

      IF wa_po_item_type-price_upd = 'X'.
        ls_ariba_mepoitem-zz_conf_price = wa_po_item_type-net_price.
      ENDIF.

      CALL METHOD im_item->set_data( ls_ariba_mepoitem ).
      CLEAR ls_ariba_mepoitem.

    ENDIF.

  ENDMETHOD.


  METHOD process_brazil_ncm.
*begin of changes MKASINA/S0VK915449/2000003244:
* Import Line Item data
    DATA(lo_headerbz) = im_item->get_header( ).
    DATA(ls_headerbz) = lo_headerbz->get_data( ).
    DATA(ls_ncm_mepoitem) = im_item->get_data( ).
    DATA lv_j_1bnbm TYPE j_1bnbm .

    SELECT SINGLE j_1bnbm
                  INTO lv_j_1bnbm
                  FROM zmm_po_br_ncm
                  WHERE bsart EQ ls_headerbz-bsart AND
                        knttp EQ ls_ncm_mepoitem-knttp AND
                        epstp EQ ls_ncm_mepoitem-pstyp AND
                        ewerk EQ ls_ncm_mepoitem-werks AND
                        bukrs EQ ls_ncm_mepoitem-bukrs AND
                        ekorg EQ ls_headerbz-ekorg AND
                        wgbez EQ ls_ncm_mepoitem-matkl.
    IF lv_j_1bnbm IS NOT INITIAL .
      ls_ncm_mepoitem-j_1bnbm = lv_j_1bnbm .
* SET Paramter
      CALL METHOD im_item->set_data( ls_ncm_mepoitem ).
    ENDIF .
**End of changes MKASINA/S0VK915449/2000003244:
  ENDMETHOD.


  METHOD PROCESS_CATALOG_AUXID_E03097.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 01/16/2020 *
* Method:       PROCESS_ITEM                                           *
* Programmer  : Mallik Aiely                   Last Update:            *
*______________________________________________________________________*
* Description : Update Item text with Auxiliary Part ID for the Catalog*
* item.                                                                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Mallik Aiely        01/16/2020        2000006119:Update Item text    *
*                                       with Cat.Aux.Part ID           *
************************************************************************

*- Export the value of  lr_text->* using Class ZCL_E03097_PREQ_CATALOG_ITEM
*- And Method SET_CATALOG_ITEM
*- Implicit Enhancement: ZMME03097_OCI_ITEM_EXPORT used in
*- Include : LMMPUR_OCI_APIF01 at Method: IMPORT_DATA
*- Import Object: BADI:  ME_PROCESS_PO_CUST Implementation: ZMME_PROCESS_PO_CUST
*- Method: PROCESS_ITEM

    DATA(lt_catalog_item) = zcl_e03097_preq_catalog_item=>get_catalog_item( ).

    DATA(ls_catalog_mepoitem) = im_item->get_data( ).

    IF ls_catalog_mepoitem IS NOT INITIAL.

      DATA(ls_pcatalog_item) = VALUE #( lt_catalog_item[ fieldname = 'NEW_ITEM-DESCRIPTION'
                                                         fieldcont = ls_catalog_mepoitem-txz01 ] OPTIONAL ).

      IF ls_pcatalog_item IS NOT INITIAL.

        DATA(ls_catalog_item) = VALUE #( lt_catalog_item[ fieldname = 'NEW_ITEM-EXT_PRODUCT_ID'
                                                    fieldindex = ls_pcatalog_item-fieldindex ]
                                                    OPTIONAL ).

        IF ls_catalog_item-fieldcont IS NOT INITIAL.

*-Set External Product ID on the item text with TDOBJECT = 'EKKO' , TDID = 'F07'
*-TDLINE = PR#Item#Supp.Aux.Part ID
          CALL METHOD zcl_me_process_po_cust=>set_po_aux_prodid
            EXPORTING
              im_item        = im_item
              io_supp_prodid = ls_catalog_item-fieldcont.

        ENDIF.

      ENDIF.

      CLEAR:ls_catalog_mepoitem, ls_pcatalog_item,ls_catalog_item,lt_catalog_item.

    ENDIF.

  ENDMETHOD.


  method PROCESS_CLM_E10271_HEADER.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2019                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_ME_PROCESS_PO_CUST           Create Date: 11/08/2019 *
* Method:       PROCESS_CLM_E10271_HEADER                              *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : This method is used to check if the vendor is a track  *
*               vendor and update the CLM flag accordingly.            *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli    11/08/2019 CD 2000003643  Initial creation        *
* ==================  ========  ======  ===============================*
************************************************************************
    DATA: ls_mepoheader TYPE mepoheader.
    gv_clm_flag = abap_false.
    IF sy-batch is INITIAL.
      ls_mepoheader = im_header->get_data( ).
      SELECT SINGLE value2 INTO @DATA(lv_parvw) FROM zmmfld WHERE
             key1 = 'E10271'
           AND key2 = 'TRACK'
           AND key3 = 'PARVW'
           AND value1 = @ls_mepoheader-ekorg.
      IF sy-subrc IS INITIAL.
        SELECT SINGLE lifnr INTO @DATA(lv_lifnr) FROM wyt3
               WHERE lifnr = @ls_mepoheader-lifnr
               AND   ekorg = @ls_mepoheader-ekorg
               AND   parvw = @lv_parvw.
        IF sy-subrc IS INITIAL.
          gv_clm_flag = abap_true.
        ELSE.
          gv_clm_flag = abap_false.
        ENDIF.
      ELSE.
        gv_clm_flag = abap_false.
      ENDIF.
    ENDIF.
  endmethod.


  method PROCESS_CLM_E10271_ITEM.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2019                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_ME_PROCESS_PO_CUST           Create Date: 11/08/2019 *
* Method:       PROCESS_CLM_E10271_ITEM                                *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : CD 2000003643 Contract Labor Management (CLM) project  *
* The item category “D” should be required at the time of PO creation. *
* The GR flag on the “Delivery” tabs should be set to active. This will*
* turn on the flag on the “Invoice” tab for “GR-Bsd IV”                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli    11/08/2019 CD 2000003643  Initial creation        *
* ==================  ========  ======  ===============================*
************************************************************************
    data(im_header) = im_item->get_header( ).
    call METHOD zcl_me_process_po_cust=>process_clm_e10271_header
      EXPORTING
        im_header = im_header .

    check gv_clm_flag eq abap_true.
    DATA: ls_mepoitem   TYPE mepoitem.

    ls_mepoitem   = im_item->get_data( ).
    SELECT * FROM zmmfld INTO table @data(lt_zmmfld)
      WHERE key1   = 'E10271'
        AND key2   = 'TRACK'.
     IF ls_mepoitem-knttp eq VALUE #( lt_zmmfld[ key1 = 'E10271'
                                       key2 = 'TRACK'
                                       key3 = 'KNTTP'
                                       value1 = ls_mepoitem-knttp
                                       ]-value1
                                       OPTIONAL ).
       ls_mepoitem-pstyp = VALUE #( lt_zmmfld[ key1 = 'E10271'
                                       key2 = 'TRACK'
                                       key3 = 'PSTYP' ]-value1
                                       OPTIONAL ).
       ls_mepoitem-wepos = VALUE #( lt_zmmfld[ key1 = 'E10271'
                                       key2 = 'TRACK'
                                       key3 = 'WEPOS' ]-value1
                                       OPTIONAL ).
     endif.
    im_item->set_data( ls_mepoitem ).
  endmethod.


  METHOD process_header.

************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/05/2018 *
* Method:       PROCESS_HEADER                                         *
* Programmer  : Mallik Aiely                   Last Update:            *
*______________________________________________________________________*
* Description : Common Method to be used for the future development in *
* BADI.                                                                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Mallik Aiely       02/20/2018         Coommon BADI Implementation    *
* ==================  ========  ======  ===============================*
*PBOMMIR             01.19.2023         PO item validation for brazil  *
* ==================  ========  ======  ===============================*
************************************************************************

    "Line added by HMALKOW CMS 33261 - E11017
    zcl_me_process_po_cust=>process_header_rfscop(
                                                im_header = im_header ).

    CALL METHOD zcl_me_process_po_cust=>process_clm_e10271_header
      EXPORTING
        im_header = im_header.

    zcl_me_process_po_cust=>process_header_brazil( im_header =  im_header ). "Added by PBOMMIR on 19.Jan.2023  SCTASK0016057

  ENDMETHOD.


  METHOD process_header_brazil.
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 01/19/2023 *
* Method:       PROCESS_HEADER_BRAZIL                                  *
* Programmer  : Praveen                           Last Update:         *
* Description : For Brazil company codes added the validation on INCO2 *
************************************************************************

    INCLUDE mm_messages_mac. "useful macros for message handling
    DATA(ls_mepoheader) = im_header->get_data( ).

    DATA:gv_bukrs TYPE zmmfld-key2,
         gv_bsart TYPE zmmfld-key3,
         lv_txt   TYPE string.

    CLEAR:gv_bukrs,gv_bsart.
    TRY.
        gv_bukrs = ls_mepoheader-bukrs.
        gv_bsart = ls_mepoheader-bsart.

        IF ls_mepoheader-inco2 IS INITIAL.

          SELECT  * FROM zmmfld
                   INTO  TABLE @DATA(lt_zmmfld)
                   WHERE key1   = 'ZBRAZIL_PO'
                   AND   key2   = @gv_bukrs
                   AND   key3   = @gv_bsart.
          IF sy-subrc = 0.
            SORT lt_zmmfld BY key1.
          ENDIF.

          LOOP AT lt_zmmfld INTO DATA(ls_zmmfld).
            CASE ls_zmmfld-key4.
              WHEN 'INCO2' OR 'PRIC'.
                lv_txt = TEXT-003.
                mmpur_message_forced  'E' '38' '000' lv_txt '' '' '' .
                im_header->invalidate( ).
                EXIT.
              WHEN OTHERS.
            ENDCASE.
          ENDLOOP.

        ENDIF.
      CATCH cx_root.
    ENDTRY.
  ENDMETHOD.


  METHOD process_header_rfscop.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/21/2018 *
* Method:       PROCESS_HEADER_RFSCOP                                  *
* Programmer  : Helena Malkowska                      Last Update      *
*______________________________________________________________________*
* Description: ALL RFSCOP BADI changes                                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Helena Malkowska    02/2018   E0V 33261 Initial transport            *
*                                                                      *
* Praveen Jutur      02/21/2018         CMS 33260  E11016 – RFSCOP     *
*                                       PO text determination          *
*                                                                      *
* Helena Malkowska    05/2018   E0V 33318 Change for E11163            *
* Keerthi Varanasi   6/13/2018 E0VK9A0X6K CMS#33090                    *
*                                         New method for E11056        *
************************************************************************

    "Line added by HMALKOW CMS 33261 - E11017
    "Fiber Supply Chain Optimization). PO Checking  whether  entered GS vendor
    "is not blocked
    zcl_me_process_po_cust=>process_header_rfscop_e11017(
                                                im_header = im_header ).

    "Line added by HMALKOW CMS 33318 - E11163
    " Read the plant for non deleted item
    zcl_me_process_po_cust=>process_header_rfscop_e11163(
                                                im_header = im_header ).

    "Copy texts from vendor master to purchase order header: PJUTUR
    zcl_me_process_po_cust=>process_header_rfscop_e11016(
                                                im_header = im_header ).

* Start of changess by KVARANA CMS#33090
* Goods Supplier check and main Vendor check in PO Change mode
    zcl_me_process_po_cust=>process_header_rfscop_e11056(
                                                im_header = im_header ).
* End of changes by KVARANA CMS#33090
  ENDMETHOD.


  METHOD process_header_rfscop_e11016.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/21/2018 *
* Method:       PROCESS_HEADER_RFSCOP_E11016                           *
* Programmer  : Praveen Jutur                     Last Update:         *
*______________________________________________________________________*
* Description: E11016 - Changes for RFSCOP (Recovered Fiber Supply     *
*                       Chain Optimization). Copy text objects from    *
*                       goods supplier to PO header texts              *
*                       1.PO text for GS should be populated in delivery
*                         text of the PO header.                       *
*                       2.Shipping instructions for GS should be       *
*                        populated in the ship. inst. tex of the PO.   *
* Assumption 1:If the text already exists because either user manually *
*             entered in dashboard transaction or coming in from vendor*
*             master of the vendor (Partner function: VN), the goods   *
*             supplier (Partner function: GS) will be append to that.  *
*             As of 02/21 this assumption yet to be finalised in the   *
*             functional spec. Any change in this assumption will      *
*             require code change.                                     *
*                                                                      *
* Assumption 2: As of 02/21 ZMMFLD entry will be maintained at purch.  *
*               org. level. Any change in this assumption will require *
*               code change.
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Praveen Jutur       02/2018   E0V 33260  Initial transport           *
************************************************************************

    CONSTANTS: lc_potxt_id       TYPE tdid     VALUE '0002',
               lc_shipinst_id    TYPE tdid     VALUE 'Z001',
               lc_delv_txt_id    TYPE tdid     VALUE 'F14',
               lc_po_shipinst_id TYPE tdid     VALUE 'F06',
               lc_vn_obj         TYPE tdobject VALUE 'LFM1',
               lc_po_obj         TYPE tdobject VALUE 'EKKO'.


    DATA: lv_avail_flag TYPE char01,
          lt_line       TYPE STANDARD TABLE OF tline,
          lt_textlines  TYPE mmpur_t_textlines,
          ls_textlines  LIKE LINE OF lt_textlines,
          lt_set_line   TYPE STANDARD TABLE OF tline,
          ls_set_line   LIKE LINE OF lt_set_line,
          lv_match      TYPE zkey1,
          lv_vn_name    TYPE thead-tdname,
          lt_line_z001  TYPE STANDARD TABLE OF tline,
          lt_line_f06   TYPE STANDARD TABLE OF tline,
          ls_line       LIKE LINE OF lt_line_f06,
          lv_gs_name    TYPE thead-tdname.

    "Read the PO header data:
    DATA(ls_mepoheader) = im_header->get_data( ).
    DATA(lt_mepoitems)  = im_header->get_items( ).

    "Enhancement makes sense if only Goods Supplier is supplied; otherwise standard config will suffice:
    CHECK ls_mepoheader-llief IS NOT INITIAL.
    lv_match = ls_mepoheader-ekorg.

    "Check if the purchasing organization is maintained in the ZMMFLD table:
    CALL FUNCTION 'Z_GET_MM_PARAMETER'
      EXPORTING
        p_key1     = 'E11016'  "Hard code needs to be replaced later when ZMMFLD table entry is finalized
        p_key2     = zcl_me_process_po_cust=>gc_rfscop
        p_key3     = zcl_me_process_po_cust=>gc_ekorg
        p_match    = lv_match
      IMPORTING
        avail_flag = lv_avail_flag.

    "Proceed only if the entry is found in the ZMMFLD table:
    CHECK lv_avail_flag IS NOT INITIAL .

    "Proceed only for PO create mode
    CHECK ls_mepoheader-ebeln IS INITIAL.

*    "Proceed only if GS is not blank
*    CHECK ls_mepoheader-llief IS NOT INITIAL.

    "Proceed only if VN Vendor is not equal to GS Goods supplier
    CHECK ls_mepoheader-lifnr NE ls_mepoheader-llief.

    "Build name object for reading texts from vendor master:
    CONCATENATE ls_mepoheader-lifnr ls_mepoheader-ekorg INTO lv_vn_name.
    CONCATENATE ls_mepoheader-llief ls_mepoheader-ekorg INTO lv_gs_name.

    " *** Logic for Delivery Text ***

    "Check if the delivery text is already flowing from the PO;
    "If that is the case, no need to read partner function text.
    CALL METHOD im_header->if_longtexts_mm~get_text
      EXPORTING
        im_tdid      = lc_delv_txt_id
      IMPORTING
        ex_textlines = lt_textlines.

    IF lt_textlines[] IS INITIAL.

      "Check if the PO header text is maintained for the goods supplier(Partner function = GS)
      CALL FUNCTION 'READ_TEXT'
        EXPORTING
          client                  = sy-mandt
          id                      = lc_potxt_id
          language                = sy-langu
          name                    = lv_gs_name
          object                  = lc_vn_obj
        TABLES
          lines                   = lt_line
        EXCEPTIONS
          id                      = 1
          language                = 2
          name                    = 3
          not_found               = 4
          object                  = 5
          reference_check         = 6
          wrong_access_to_archive = 7
          OTHERS                  = 8.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

      IF lines( lt_line ) > 0.
        ls_textlines-tdobject = lc_po_obj.
*      ls_textlines-tdid = 'ST'.          "Check if this is necessary
*      ls_textlines-tdformat  = 'SP'.     "Check if this is necessary

        LOOP AT lt_line INTO ls_set_line.
          ls_textlines-tdline = ls_set_line-tdline.
          APPEND ls_textlines TO lt_textlines.
        ENDLOOP.

        "Set the delivery text on the PO header:
        CALL METHOD im_header->if_longtexts_mm~set_text
          EXPORTING
            im_tdid      = lc_delv_txt_id
            im_textlines = lt_textlines.
        REFRESH lt_textlines.
      ENDIF.
    ENDIF.
    REFRESH lt_line.


    " *** Logic for Shipping Instructions ***
    "Check if the shipping instructions are flowing from the PO;

    "Check if the shipping instructions is maintained for the goods supplier(Partner function = GS)
    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        client                  = sy-mandt
        id                      = lc_shipinst_id
        language                = sy-langu
        name                    = lv_gs_name
        object                  = lc_vn_obj
      TABLES
        lines                   = lt_line
      EXCEPTIONS
        id                      = 1
        language                = 2
        name                    = 3
        not_found               = 4
        object                  = 5
        reference_check         = 6
        wrong_access_to_archive = 7
        OTHERS                  = 8.

    IF lines( lt_line ) > 0.

      CALL METHOD im_header->if_longtexts_mm~get_text
        EXPORTING
          im_tdid      = lc_po_shipinst_id
        IMPORTING
          ex_textlines = lt_textlines.

      "If that is the case, dont read the partner function text.
      IF lt_textlines[] IS INITIAL.

        "Collect the text coming in from Vendor as well as goods supplier:
*    if lines( lt_set_line ) > 0.
        ls_textlines-tdobject = lc_po_obj.
        LOOP AT lt_line INTO ls_set_line.
          ls_textlines-tdline = ls_set_line-tdline.
          APPEND ls_textlines TO lt_textlines.
        ENDLOOP.

        "Set the shipping instructions on the PO header:
        CALL METHOD im_header->if_longtexts_mm~set_text
          EXPORTING
            im_tdid      = lc_po_shipinst_id
            im_textlines = lt_textlines.
      ELSE.
        IF sy-cprog EQ 'ZMME11014_CREATE_PO'.

        ELSE.
          " Read VN/Z001 text
          REFRESH: lt_line_z001.
          CALL FUNCTION 'READ_TEXT'
            EXPORTING
              client                  = sy-mandt
              id                      = lc_shipinst_id
              language                = sy-langu
              name                    = lv_vn_name
              object                  = lc_vn_obj
            TABLES
              lines                   = lt_line_z001
            EXCEPTIONS
              id                      = 1
              language                = 2
              name                    = 3
              not_found               = 4
              object                  = 5
              reference_check         = 6
              wrong_access_to_archive = 7
              OTHERS                  = 8.
          IF lines( lt_line_z001 ) > 0.
            LOOP AT lt_textlines INTO ls_textlines.
              ls_line-tdline = ls_textlines-tdline.
              ls_line-tdformat = ls_textlines-tdformat.
              APPEND ls_line TO lt_line_f06.
            ENDLOOP.
            " Check if F06 = Z001 " F06: lt_textlines
            " Clear LT_textlines and copy from LT_LINE
            IF lt_line_z001[] EQ lt_line_f06[].
              REFRESH: lt_textlines.
              ls_textlines-tdobject = lc_po_obj.
              LOOP AT lt_line INTO ls_line.
                ls_textlines-tdline   = ls_line-tdline.
                ls_textlines-tdformat = ls_line-tdformat.
                APPEND ls_textlines TO lt_textlines.
              ENDLOOP.
              CALL METHOD im_header->if_longtexts_mm~set_text
                EXPORTING
                  im_tdid      = lc_po_shipinst_id
                  im_textlines = lt_textlines.
            ENDIF.
          ENDIF.

        ENDIF.

      ENDIF.

    ENDIF.

  ENDMETHOD.


  method process_header_rfscop_e11017.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/21/2018 *
* Method:       PROCESS_HEADER_RFSCOP_E11017                           *
* Programmer  : Helena Malkowska                  Last Update:         *
*______________________________________________________________________*
* Description: E11017 - Changes for project #45533 RFSCOP (Recovered   *
*              Fiber Supply Chain Optimization). PO Checking  whether  *
*              entered GS vendor is not blocked                        *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Helena Malkowska    02/2018   E0V 33261  Initial transport.          *
************************************************************************
    data: ls_zmmfld type zmmfld.
    data: lv_msgid type  symsgid.
    data: lv_msgty type  symsgty.
    data: lv_msgno type  symsgno.
    data: lv_msgv1 type  symsgv.
    data: lv_msgv2 type  symsgv.
    data: lv_msgv3 type  symsgv.
    data: lv_msgv4 type  symsgv.

    include mm_messages_mac. "useful macros for message handling

    "Get PO Header
    data(ls_mepoheader) = im_header->get_data( ).

    "Initial Check for Purchase Organization
    if zcl_mm_rfscop=>get_zmmfld_values(
                                       exporting
                                         iv_key1 = 'E11017'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'EKORG'
                                         iv_value1 = ls_mepoheader-ekorg
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                       importing
                                         es_zmmfld = ls_zmmfld ) = 'X'.

      if ls_mepoheader-llief is not initial.

        if zcl_mm_rfscop=>vendor_is_blocked(
                                       exporting
                                         iv_vendor = ls_mepoheader-llief
                                         iv_ekorg  = ls_mepoheader-ekorg
                                         iv_bukrs  = ls_mepoheader-bukrs
                                       importing
                                         ev_msgid   =  lv_msgid
                                         ev_msgty   =  lv_msgty
                                         ev_msgno   =  lv_msgno
                                         ev_msgv1   =  lv_msgv1
                                         ev_msgv2   =  lv_msgv2
                                         ev_msgv3   =  lv_msgv3
                                         ev_msgv4   =  lv_msgv4
                                          ).


          message id lv_msgid type lv_msgty number lv_msgno
                     with lv_msgv1 lv_msgv2 lv_msgv3 lv_msgv4.

          mmpur_message_forced lv_msgty lv_msgid lv_msgno
                        lv_msgv1 lv_msgv2 lv_msgv3 lv_msgv4.


        endif.
      endif.
    endif.
  endmethod.


  METHOD process_header_rfscop_e11056.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 06/13/2018 *
* Method:       PROCESS_HEADER_RFSCOP_E11056                           *
* Programmer  : Keerthi Varanasi               Last Update:            *
*______________________________________________________________________*
* Description: E11056 - PO header validations for RFSCOP (Recovered    *
*              Fiber Supply Chain Optimization).                       *
* Main Vendor check in PO Change mode and goods supplier check in      *
* Create/Change mode                                                   *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* KVARANA             6/13/2018 E0VK9A0X6U  CMS#33090 Initial transport*
************************************************************************

    DATA: ls_zmmfld TYPE zmmfld.
    CONSTANTS: lc_pstyp_0 type pstyp value '0'. " Standard
    INCLUDE mm_messages_mac. "useful macros for message handling

    "Get PO Header
    DATA(ls_mepoheader) = im_header->get_data( ).
* Get PO items
      data(lt_po_items) = im_header->get_items( ).
* Read the first item
      data(ls_po_items) = VALUE #( lt_po_items[ 1 ] optional ).
      if ls_po_items is NOT INITIAL. " CD 2000003643
        data(ls_po_item)  = ls_po_items-item->get_data( ).
      endif.

* Check if the document is PO and check Pur.Org in ZMMFLD
* and Item category is '0'
    IF ls_mepoheader-bstyp EQ 'F' AND
       ls_po_item-pstyp = lc_pstyp_0 AND " Item category is Standard
       zcl_mm_rfscop=>get_zmmfld_values(
                                       EXPORTING
                                         iv_key1 = 'E11056'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'EKORG'
                                         iv_key4 = space
                                         iv_value1 = ls_mepoheader-ekorg
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                       IMPORTING
                                         es_zmmfld = ls_zmmfld ) = 'X'.

*Main Vendor check in PO Change mode
      IF ls_mepoheader-ebeln IS NOT INITIAL.
        SELECT SINGLE lifnr FROM ekko INTO @DATA(lv_lifnr)
                                      WHERE ebeln EQ @ls_mepoheader-ebeln.
*compare EKKO vendor with PO Screen vendor
        IF sy-subrc EQ 0 AND ( lv_lifnr NE ls_mepoheader-lifnr ).
          zcl_mm_rfscop=>get_zmmfld_values(
                                        EXPORTING
                                          iv_key1 = 'E11056'
                                          iv_key2 = 'RFSCOP'
                                          iv_key3 = 'MESSAGES'
                                          iv_key4 = 'ZMM_RFSCOP'
                                          iv_key5 = '056'
                                          iv_type = 'S'
                                          iv_up_to_rows = 1
                                        IMPORTING
                                          es_zmmfld = ls_zmmfld ).
          CASE ls_zmmfld-value1.
            WHEN 'E'.
* The below is needed to see the message in log, else it is overwritten by std. SAP msg
              mmpur_context mmcnt_check_lifnr.
              mmpur_metafield mmmfd_vendor.
              mmpur_message 'E' 'ZMM_RFSCOP' '056' space space space space.
            WHEN 'W'.
              mmpur_context mmcnt_check_lifnr.
              mmpur_metafield mmmfd_vendor.
              mmpur_message 'W' 'ZMM_RFSCOP' '056' space space space space.
          ENDCASE.

        ENDIF.
      ENDIF.


*Goods Supplier check
        IF ls_mepoheader-llief IS INITIAL.  "no goods supplier
          zcl_mm_rfscop=>get_zmmfld_values(
                                        EXPORTING
                                          iv_key1 = 'E11056'
                                          iv_key2 = 'RFSCOP'
                                          iv_key3 = 'MESSAGES'
                                          iv_key4 = 'ZMM_RFSCOP'
                                          iv_key5 = '072'
                                          iv_type = 'S'
                                          iv_up_to_rows = 1
                                        IMPORTING
                                          es_zmmfld = ls_zmmfld ).
          CASE ls_zmmfld-value1.
            WHEN 'E'.
*-Goods Supplier Mandatory
              mmpur_metafield mmmfd_partners.
              mmpur_message 'E' 'ZMM_RFSCOP' '072' space space space space.
            WHEN 'W'.
              mmpur_metafield mmmfd_partners.
              mmpur_message 'W' 'ZMM_RFSCOP' '072' space space space space.
          ENDCASE.
        ENDIF.

      IF ls_mepoheader-ebeln IS NOT INITIAL.  " PO change mode ME22N
*Compare EKKO goods supplier with PO Screen goods supplier
        SELECT SINGLE llief FROM ekko INTO @DATA(lv_llief)
                                      WHERE ebeln EQ @ls_mepoheader-ebeln.

        SELECT SINGLE vbeln FROM ekes INTO @DATA(lv_ebeln)
                              WHERE ebeln = @ls_mepoheader-ebeln.

        IF sy-subrc EQ 0 AND ( ls_mepoheader-llief NE lv_llief ).

          zcl_mm_rfscop=>get_zmmfld_values(
                                       EXPORTING
                                         iv_key1 = 'E11056'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'MESSAGES'
                                         iv_key4 = 'ZMM_RFSCOP'
                                         iv_key5 = '057'
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                       IMPORTING
                                         es_zmmfld = ls_zmmfld ).
*-Message Update: Good supplier cannot be changed
          CASE ls_zmmfld-value1.
            WHEN 'E'.
              mmpur_metafield mmmfd_partners.
              mmpur_message 'E' 'ZMM_RFSCOP' '057' space space space space.
            WHEN 'W'.
              mmpur_metafield mmmfd_partners.
              mmpur_message 'W' 'ZMM_RFSCOP' '057' space space space space.
          ENDCASE.

        ENDIF.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  method process_header_rfscop_e11163.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 05/24/2018 *
* Method:       PROCESS_HEADER_RFSCOP_E11163                           *
* Programmer  : Helena Malkowska                  Last Update:         *
*______________________________________________________________________*
* Description: E11163 - Changes for project #45533 RFSCOP (Recovered   *
*              Fiber Supply Chain Optimization).                       *
*                                                                      *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Helena Malkowska    05/2018   E0V 33318  Initial transport           *
************************************************************************

    data: lt_po_items type purchase_order_items.
    data: ls_po_item type mepoitem.
    data: ls_zmmfld type zmmfld.
    data: lv_werks type ewerk.

    "Get PO Header
    data(ls_mepoheader) = im_header->get_data( ).

    "Make sure this code is executed only in PO create mode
    if ls_mepoheader-ebeln is not initial.
      exit.
    endif.

    "Initial Check for RFSCOP Purchase Organization
    if zcl_mm_rfscop=>get_zmmfld_values(
                                       exporting
                                         iv_key1 = 'E11163'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'EKORG'
                                         iv_value1 = ls_mepoheader-ekorg
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                       importing
                                         es_zmmfld = ls_zmmfld ) = 'X'.

      "Get PO items
      lt_po_items = im_header->get_items( ).

      loop at lt_po_items assigning field-symbol(<ls_po_item>).

        ls_po_item  = <ls_po_item>-item->get_data( ).
        if ls_po_item-loekz is initial.
          lv_werks = ls_po_item-werks.
          exit.
        endif.

      endloop.

      export lv_werks from lv_werks to memory id 'E11163'.

    endif.



  endmethod.


  METHOD process_item.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/05/2018 *
* Method:       PROCESS_ITEM                                           *
* Programmer  : Mallik Aiely                   Last Update:            *
*______________________________________________________________________*
* Description : Common Method to be used for the future development in *
* BADI.                                                                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Mallik Aiely      02/05/2018              Coommon BADI Implementation*
* Anil Lankapalli    04/19/2021 ESBK9A20FI  To get the correct shipping*
*                                           address and update the PO  *
*PBOMMIR            19/01/2023       PO line item validation for brazil*
*MKASINA            26/12.2025     NCM tax code update for brazil      *
************************************************************************

    CALL METHOD zcl_me_process_po_cust=>process_rfscop
      EXPORTING
        im_item = im_item.

    CALL METHOD zcl_me_process_po_cust=>process_ariba
      EXPORTING
        im_item = im_item.

    CALL METHOD zcl_me_process_po_cust=>process_clm_e10271_item
      EXPORTING
        im_item = im_item.

    CALL METHOD zcl_me_process_po_cust=>process_sylvamo
      EXPORTING
        im_item = im_item.           " PO Item External View

    zcl_me_process_po_cust=>process_item_brazil( im_item = im_item ).  "Added by PBOMMIR on 19.Jan.2023   SCTASK0016057
**begin of changes MKASINA/S0VK915449/2000003244:
    zcl_me_process_po_cust=>process_brazil_ncm( im_item = im_item ).
*End of changes MKASINA/S0VK915449/2000003244:
  ENDMETHOD.


  METHOD process_item_brazil.
****************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 01/19/2023     *
* Method:       PROCESS_ITEM_BRAZIL                                        *
* Programmer  : Praveen                           Last Update:             *
* Description : For Brazil company codes added the validation on PR & cont *
*               SCTASK0016057
****************************************************************************
*Changed By     : Praveen Kumar Bommireddy
*Requested By   : Pavan
*Created on     : 28.Nov.2023
*Transport      : S0VK905433/2000001433
*Description    : Contract value validation logic change EKPO to EKAB
****************************************************************************
    INCLUDE mm_messages_mac. "useful macros for message handling

    DATA: lt_poitem      TYPE purchase_order_items,
          lo_poitem      TYPE REF TO if_purchase_order_item_mm,
          lo_itm_d       TYPE REF TO cl_po_item_handle_mm,
          ls_poitem_data TYPE mepoitem.

    DATA:l_valor_consumo TYPE ekpo-brtwr,
         gv_bukrs        TYPE zmmfld-key2,
         gv_bsart        TYPE zmmfld-key3.

    TRY.
        CLEAR:gv_bukrs,gv_bsart,l_valor_consumo.

        DATA(lo_header) = im_item->get_header( ).
        DATA(ls_header) = lo_header->get_data( ).
        DATA(l_item)    = im_item->get_data( ).

        gv_bukrs = ls_header-bukrs.
        gv_bsart = ls_header-bsart.


        SELECT  * FROM zmmfld
                 INTO  TABLE @DATA(lt_zmmfld)
                 WHERE key1   = 'ZBRAZIL_PO'
                 AND   key2   = @gv_bukrs
                 AND   key3   = @gv_bsart.
        IF sy-subrc = 0.
          SORT lt_zmmfld BY key1.
        ENDIF.

        LOOP AT lt_zmmfld INTO DATA(ls_zmmfld).
          CASE ls_zmmfld-key4.
            WHEN 'PRREQ' OR 'PRIC'.
              IF l_item-banfn IS INITIAL OR l_item-bnfpo IS INITIAL.
                CONCATENATE TEXT-002 l_item-ebelp INTO DATA(ls_msg) SEPARATED BY space.
                mmpur_message_forced  'E' '38' '000' TEXT-001 ls_msg '' ''.
                im_item->invalidate( ).
              ENDIF.
            WHEN 'CONT'.
              IF l_item-konnr  IS INITIAL OR l_item-ktpnr IS INITIAL.
                CONCATENATE TEXT-002 l_item-ebelp INTO DATA(ls_msg1) SEPARATED BY space.
                mmpur_message_forced  'E' '38' '000' TEXT-004 ls_msg1 '' ''.
                im_item->invalidate( ).
              ENDIF.
            WHEN 'PROA'.    " Means PO has both PR & Outline agrement details if any one is blank triggering error
              IF l_item-banfn IS INITIAL OR l_item-bnfpo IS INITIAL.
                CONCATENATE TEXT-002 l_item-ebelp INTO DATA(ls_msgpa) SEPARATED BY space.
                mmpur_message_forced  'E' '38' '000' TEXT-001 ls_msgpa '' ''.
                im_item->invalidate( ).
              ENDIF.
              IF l_item-konnr  IS INITIAL OR l_item-ktpnr IS INITIAL.
                CONCATENATE TEXT-002 l_item-ebelp INTO DATA(ls_msgpa1) SEPARATED BY space.
                mmpur_message_forced  'E' '38' '000' TEXT-004 ls_msgpa1 '' ''.
                im_item->invalidate( ).
              ENDIF.
            WHEN 'CONT1'.
              DATA(lv_cflag) = abap_true.  " COntract Date & Value Validation flag
            WHEN OTHERS.
          ENDCASE.
        ENDLOOP.

        IF lv_cflag = abap_true AND ( l_item-konnr IS NOT INITIAL AND l_item-loekz = abap_false ).
**Logic shared by Cast Costa team : PMC 120 / Enhancement name 60.030
          SELECT SINGLE kdate                    " Melhoria 60.030.
                 FROM ekko
                 INTO @DATA(l_kdate)
                 WHERE ebeln EQ @l_item-konnr.
          IF sy-subrc EQ 0 AND sy-datum  GT l_kdate.  " Validade do contrato
*            MESSAGE: 'Contrato fora  da data de validade' TYPE 'E'.   " Criar uma classe para validar a mensagem.
            MESSAGE: TEXT-005  TYPE 'E'.
          ENDIF.

*SOC by pbommir on 28.Nov.2023 for S0VK905433/2000001433
          "Total Agrement Value
          SELECT SINGLE ebeln,
                        ktwrt
                  FROM ekko
                  INTO @DATA(ls_agr)
                  WHERE ebeln = @l_item-konnr.
          IF sy-subrc = 0.
            "//
          ENDIF.

          "Total value aganist PO w.r.t Agrement
          SELECT konnr,
                 ktpnr,
                 ebeln,
                 ebelp,
                 netwr,
                 loekz
            FROM ekab
            INTO TABLE @DATA(lt_ekab)
            WHERE konnr = @l_item-konnr.
          IF sy-subrc = 0.
            SORT lt_ekab BY ebeln ebelp.
          ENDIF.

          CLEAR:l_valor_consumo.
          l_valor_consumo =  REDUCE #( INIT lv_val TYPE ekab-netwr
                                       FOR ls_ekab_d IN lt_ekab
                                       NEXT lv_val = lv_val + ls_ekab_d-netwr
                                      ).

          IF sy-tcode = 'ME21N'.
            DATA(lt_items)  = lo_header->get_items( ).
            LOOP AT lt_items INTO DATA(ls_itm_d).
              lo_itm_d ?= ls_itm_d-item.
              lo_itm_d->get_data(
                IMPORTING
                  ex_data = DATA(ls_itm_t)   " Data Part
                EXCEPTIONS
                  failure = 1                " Error
                  OTHERS  = 2
              ).

              IF ls_itm_t-ebelp = l_item-ebelp.
                CONTINUE.
              ENDIF.
              l_valor_consumo = l_valor_consumo + ls_itm_t-netwr.
            ENDLOOP.
          ENDIF.


          "Cumunlating the PO value & current value in screen
          l_valor_consumo =  l_valor_consumo + l_item-netwr.


          IF l_valor_consumo GT ls_agr-ktwrt.
            mmpur_message_forced  'E' '38' '000' TEXT-006 '' '' ''.
            im_item->invalidate( ).
          ENDIF.


*          SELECT * FROM ekko
*                   INTO TABLE @DATA(lt_val_consumo)  " Melhoria 60.030.
*                   WHERE konnr EQ @l_item-konnr.
*          IF sy-subrc EQ 0 .
*            SELECT * FROM ekpo
*                     INTO TABLE @DATA(lt_ekpo)
*                     FOR ALL ENTRIES IN @lt_val_consumo
*                     WHERE ebeln EQ @lt_val_consumo-ebeln
*                     AND   loekz = @abap_false
*                     AND   konnr = @l_item-konnr.       "Add for  INC0043820 on 22.05.2023
*            IF sy-subrc EQ 0.
*
*              LOOP AT lt_ekpo ASSIGNING FIELD-SYMBOL(<fs_ekpo>).
*                IF <fs_ekpo>-ebeln = l_item-ebeln AND <fs_ekpo>-ebelp = l_item-ebelp.
*                  CONTINUE.
*                ENDIF.
*                l_valor_consumo = <fs_ekpo>-brtwr + l_valor_consumo.
*              ENDLOOP.
*
*              l_valor_consumo = l_valor_consumo + l_item-netwr.   "Considering the current net value for calculation
*
*              SELECT * FROM ekko
*                       INTO TABLE @DATA(lt_valor_consumo)
*                       FOR ALL ENTRIES IN @lt_ekpo
*                       WHERE ebeln EQ @lt_ekpo-konnr.
*              IF sy-subrc EQ 0.
*                READ TABLE lt_valor_consumo ASSIGNING FIELD-SYMBOL(<fs_valor_consumo>) INDEX 1.  " Valida o consumo
*                IF <fs_valor_consumo> IS ASSIGNED.
*                  IF l_valor_consumo GT <fs_valor_consumo>-ktwrt.
**                    MESSAGE: 'Valor de consumo excedido' TYPE 'E'.  " Criar uma classe para validar a mensagem.
*                    MESSAGE: TEXT-006 TYPE 'E'.  " Criar uma classe para validar a mensagem.
*                  ENDIF.
*                ENDIF.
*              ENDIF.
*            ENDIF.
*          ENDIF.



*EOC by pbommir on 28.Nov.2023 for S0VK905433/2000001433



        ENDIF.
        CLEAR:lv_cflag.


*SOC for 2000000869 :- S0VK902952 on 21.June.2023
*PO is greater than 3% compared to purchase requisition
        SELECT  * FROM zmmfld
               INTO TABLE @DATA(lt_limit)
               WHERE key1   = 'ZBRAZIL_PO'
               AND   key2   = @gv_bukrs
               AND   key3   IN ( 'PR_TOLERANCE', 'EX_TOLERANCE' ).
        IF sy-subrc = 0.
          SORT lt_limit BY key1.
        ENDIF.

*Tolrence check
        READ TABLE lt_limit INTO DATA(ls_limit) WITH KEY key1 = 'ZBRAZIL_PO'
                                                         key2 = gv_bukrs
                                                         key3 = 'PR_TOLERANCE'.
        IF sy-subrc = 0.
          DATA(lv_tflag) = abap_true.
        ENDIF.


        "Exclude tolerance
        "Pur.Req document type is maintained(Exclude) in ZMMFLD no need to check po document type for tolerance check
        "Pur.Req document type is not maintained(Exclude) in ZMMFLD we need to check po document type in ZMMFLD
        "for tolerance check.
*PR Document type

        SELECT SINGLE banfn,
                      bnfpo,
                      bsart,
                      preis
                 FROM eban
                 INTO @DATA(ls_eban_t)
                 WHERE banfn = @l_item-banfn
                   AND bnfpo = @l_item-bnfpo.
        IF sy-subrc = 0 AND line_exists( lt_limit[  key1 = 'ZBRAZIL_PO'
                                                    key2 = gv_bukrs
                                                    key3 = 'EX_TOLERANCE'
                                                    key4 = ls_eban_t-bsart
                                                    key5 = 'PR'
                                                   ] ) .
          CLEAR:lv_tflag.   "Excluding the tolerance check company code & document type combination.


        ELSE.
          "PO Document types
          IF line_exists( lt_limit[ key1 = 'ZBRAZIL_PO'
                                    key2 = gv_bukrs
                                    key3 = 'EX_TOLERANCE'
                                    key4 = gv_bsart
                                    key5 = 'PO'
                                  ] ) .
            CLEAR:lv_tflag.   "Excluding the tolerance check company code & document type combination
          ENDIF.


        ENDIF.


        IF lv_tflag = abap_true .
          IF l_item-banfn IS INITIAL OR l_item-bnfpo IS INITIAL.
            CONCATENATE TEXT-002 l_item-ebelp INTO DATA(ls_msg_t) SEPARATED BY space.
            mmpur_message_forced  'E' '38' '000' TEXT-001 ls_msg_t '' ''.
            im_item->invalidate( ).
          ELSE.

            SELECT SINGLE banfn,
                          bnfpo,
                          bsart,
                          preis
                     FROM eban
                     INTO @DATA(ls_eban)
                     WHERE banfn = @l_item-banfn
                       AND bnfpo = @l_item-bnfpo.
            IF sy-subrc = 0 AND ( l_item-netpr
                                       GT
                                 ( ls_eban-preis + ( ls_eban-preis * ( ls_limit-value1 / 100 ) ) )
                                ).

              mmpur_message_forced  'E' '38' '000'  TEXT-008 TEXT-007 '' ''.
              im_item->invalidate( ).
            ENDIF.

          ENDIF.
        ENDIF.
        CLEAR lv_tflag.
*EOC for 2000000869 :- S0VK902952 on 21.June.2023


      CATCH cx_root.
    ENDTRY.

  ENDMETHOD.


  METHOD process_item_rfscop_e11056.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 05/23/2018 *
* Method:       PROCESS_ITEM                                           *
* Programmer  : Sukanya                        Last Update:            *
*______________________________________________________________________*
* Description : For RF Scorp this method is used to populate the       *
* characteristic values in EKPO table .                                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Sukanya             05/23/2018        CMS:33111:PO GR Date Validate  *
* KVARANA            6/13/2018          CMS#33090 Moved the header     *
*                                       validations to header method   *
************************************************************************

********************
* To be used only inside the PO BADI (ME_PROCESS_PO_CUST)
*******************

    INCLUDE mm_messages_mac. "useful macros for message handling

    DATA: ls_zmmfld TYPE zmmfld.

    DATA(lo_header) = im_item->get_header( ).
    DATA(ls_mepoheader) = lo_header->get_data( ).
    DATA(ls_mepoitem) = im_item->get_data( ).

* Check if the document is PO and check Pur.Org in ZMMFLD                                                                                                                    PO is RFSCOP related
    IF ls_mepoheader-bstyp EQ 'F' AND
       zcl_mm_rfscop=>get_zmmfld_values(
                                       EXPORTING
                                         iv_key1 = 'E11056'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'EKORG'
                                         iv_key4 = space
                                         iv_value1 = ls_mepoheader-ekorg
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                        IMPORTING
                                         es_zmmfld = ls_zmmfld ) = 'X'.

*Latest GR date Validation
      SELECT vbeln, eindt FROM ekes INTO TABLE @DATA(lt_ekes)
                              WHERE ebeln = @ls_mepoitem-ebeln AND
                                    ebelp = @ls_mepoitem-ebelp.
      IF sy-subrc EQ 0.
        SORT lt_ekes BY eindt DESCENDING.
        DELETE ADJACENT DUPLICATES FROM lt_ekes COMPARING vbeln.

        SELECT vbeln, wbstk FROM vbuk INTO TABLE @DATA(lt_vbuk)
               FOR ALL ENTRIES IN @lt_ekes
               WHERE vbeln = @lt_ekes-vbeln.

        LOOP AT lt_ekes INTO DATA(ls_ekes).
          DATA(ls_vbuk) = VALUE #( lt_vbuk[ vbeln = ls_ekes-vbeln ] DEFAULT space ).

          IF ls_vbuk IS NOT INITIAL AND ls_vbuk-wbstk NE 'C'.

            " Latest GR date should be after last delivery date, if not error message
            IF ls_mepoitem-lewed < ls_ekes-eindt.

              zcl_mm_rfscop=>get_zmmfld_values(
                                         EXPORTING
                                           iv_key1 = 'E11056'
                                           iv_key2 = 'RFSCOP'
                                           iv_key3 = 'MESSAGES'
                                           iv_key4 = 'ZMM_RFSCOP'
                                           iv_key5 = '055'
                                           iv_type = 'S'
                                           iv_up_to_rows = 1
                                         IMPORTING
                                           es_zmmfld = ls_zmmfld ).
*- Latest GR date cannot be before <ls_ekes-eindt> from < ls_ekes-vbeln>.
              CASE ls_zmmfld-value1.
                WHEN 'E'.
                  mmpur_metafield mmmfd_latest_gr.
                  mmpur_message 'E' 'ZMM_RFSCOP' '055' ls_ekes-eindt ls_ekes-vbeln space space.
                WHEN 'W'.
                  mmpur_metafield mmmfd_latest_gr.
                  mmpur_message 'W' 'ZMM_RFSCOP' '055' ls_ekes-eindt ls_ekes-vbeln space space.
              ENDCASE.
            ENDIF.
          ENDIF.

        ENDLOOP.

      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD process_item_rfscop_e11185.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/20/2018 *
* Method:       PROCESS_ITEM                                           *
* Programmer  : Jayakumar                   Last Update:               *
*______________________________________________________________________*
* Description : For RF Scorp this method is used to populate the       *
* characteristic values in EKPO table .                                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Jayakumar           02/20/2018        CMS33090:Fill characteristic   *
*                                       values in EKPO table           *
* Mamatha       06/13/2018  E0VK9A0XF1  CMS#33258: Added Logic to fill *
*                                       grade characteristic while     *
*                                    creating PO from 'ZMM_RFPO_CREATE'*
*                                    &If BDC in 'ZMM_RFPO_CREATE' fails*
*                                    Do not update grade in EKPO       *
*                                                                      *
* Mamatha       06/19/2018  E0VK9A0XF1  CMS33311 :Changed messages from*
*                                       error to warning if  exception *
*                                      caught in VC_I_GET_CONFIGURATION*
*                                      and added logic to remove Custom*
*                                      message 60 from message log if  *
*                                      grade is maintained             *
*Mamatha       08/06/2018  E0VK9A0YSS CMS33909 clear ZFields zz_atinn  *
*                                     &zz_atwrt if no grade is found in*
*                                     the PO screen                    *
************************************************************************

    INCLUDE mm_messages_mac. "useful macros for message handling

    DATA : lt_conf   TYPE tt_conf_out,
           ls_conf   TYPE conf_out,
           ls_zmmfld TYPE zmmfld.

    DATA(lo_header) = im_item->get_header( ).
    DATA(ls_mepoheader) = lo_header->get_data( ).
    DATA(ls_mepoitem) = im_item->get_data( ).

*Begin of changes by MMALI CMS#33258
    DATA:lv_change_grade     TYPE c,
         lv_rfpocreate       TYPE c,
         lv_bdc              TYPE c,
         lr_msg_handler_mm   TYPE REF TO cl_message_handler_mm,
         lo_obj              TYPE REF TO cl_cucb,
         lr_exref            TYPE REF TO cx_cbase_error,
         lv_context          TYPE mmpur_context,
         ls_instance_version TYPE cuib_instance_version,
         lt_configuration    TYPE cuib_ibco_instance_t,
         lv_ex_msgtxt        TYPE string.

    CONSTANTS:lc_msg_pattern TYPE string VALUE 'ZMM_RFSCOP*060*',
              lc_x           TYPE c VALUE 'X',
              lc_grade       TYPE atnam VALUE 'FS_GRADE'.


    IMPORT  mv_change_grade = lv_change_grade FROM MEMORY ID 'CHANGE_GRADE_E11014'.
    IMPORT  mv_rfpocreate   = lv_rfpocreate   FROM MEMORY ID 'PO_CREATE_E11014'.
    IMPORT  mv_bdc          = lv_bdc          FROM MEMORY ID 'BDC_E11014'.
**End of changes by MMALI CMS#33258

    IF ls_mepoheader-bstyp EQ 'F' AND
       zcl_mm_rfscop=>get_zmmfld_values(
                                       EXPORTING
                                         iv_key1 = 'E11185'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'EKORG'
                                         iv_key4 = space
                                         iv_value1 = ls_mepoheader-ekorg
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                        IMPORTING
                                         es_zmmfld = ls_zmmfld ) = 'X'.

*Begin of changes by MMALI CMS#33258
*This code will be executed when PO is created through PO create from Proposal 'ZMM_RFPO_CREATE'.
*set the grade characteristic from proposal
*This logic will execute only if the refrence po and proposal has different grades

      IF  lv_rfpocreate = lc_x AND lv_change_grade = lc_x.

        CREATE OBJECT lo_obj.
        ls_instance_version-instance = ls_mepoitem-cuobj.

*get the configuration based on reference PO CUOBJ
        TRY.
            CALL METHOD lo_obj->get_configuration
              EXPORTING
                is_instance_version = ls_instance_version
              IMPORTING
                et_configuration    = lt_configuration.
*If exception occurs catch the exception message and export that message to ZMM_RFPO_CREATE

          CATCH cx_cbase_error INTO lr_exref.

            DATA(lv_getconfig_fail)       = lc_x.
            CALL METHOD lr_exref->if_message~get_text
              RECEIVING
                result = lv_ex_msgtxt.
            EXPORT  mv_ex_msgtxt  =  lv_ex_msgtxt TO MEMORY ID 'EXMSG_E11014'.
            CLEAR lv_ex_msgtxt.

*if get config fails don't update ekpo-atinn and ekpo-atwrt.

            CLEAR :ls_mepoitem-zz_atinn, ls_mepoitem-zz_atwrt.
            CALL METHOD im_item->set_data( ls_mepoitem ).

        ENDTRY.
*if get configuration doesn't fail set the configuration with the grade value from proposal

        IF lv_getconfig_fail NE lc_x.
*Get the Internal characteristic number for grade
          SELECT atinn FROM cabn INTO @DATA(lv_atinn) UP TO 1 ROWS WHERE atnam = @lc_grade.
          ENDSELECT.

          TRY.
              DATA(wa_config) = lt_configuration[ 1 ].
              DATA(lt_values) = wa_config-values.
              TRY.
                  DATA(wa_values) = lt_values[ atinn = lv_atinn ].
                  wa_values-atinn = ls_mepoitem-zz_atinn.
                  wa_values-atwrt = ls_mepoitem-zz_atwrt.
                  MODIFY lt_values FROM wa_values INDEX sy-tabix.
                  IF sy-subrc = 0.
                    wa_config-values = lt_values.
                    MODIFY lt_configuration FROM wa_config INDEX 1.
                    IF sy-subrc = 0.
                      TRY.
                          CALL METHOD lo_obj->set_configuration
                            EXPORTING
                              iv_root_instance = ls_mepoitem-cuobj
                            CHANGING
                              ct_configuration = lt_configuration.

*if set configuration fails export the exception message to PO create program

                        CATCH cx_cbase_error INTO lr_exref.
                          CALL METHOD lr_exref->if_message~get_text
                            RECEIVING
                              result = lv_ex_msgtxt.
                          EXPORT  mv_ex_msgtxt  =  lv_ex_msgtxt TO MEMORY ID 'EXMSG_E11014'.
                          CLEAR lv_ex_msgtxt.

*if set config fails don't update ekpo-atinn and ekpo-atwrt.

                          CLEAR :ls_mepoitem-zz_atinn, ls_mepoitem-zz_atwrt.
                          CALL METHOD im_item->set_data( ls_mepoitem ).

                      ENDTRY.
                    ENDIF.
                  ENDIF.
                CATCH cx_sy_itab_line_not_found.
*if no data is found in values table don't update ekpo-atinn and ekpo-atwrt.
                  CLEAR :ls_mepoitem-zz_atinn, ls_mepoitem-zz_atwrt.
                  CALL METHOD im_item->set_data( ls_mepoitem ).
              ENDTRY.
            CATCH cx_sy_itab_line_not_found.
*if no data is found in config table don't update ekpo-atinn and ekpo-atwrt.
              CLEAR :ls_mepoitem-zz_atinn, ls_mepoitem-zz_atwrt.
              CALL METHOD im_item->set_data( ls_mepoitem ).
          ENDTRY.

        ENDIF.
      ELSE.
*End of changes by MMALI CMS#33258

** Get the characteristic values
        CALL FUNCTION 'VC_I_GET_CONFIGURATION'
          EXPORTING
            instance            = ls_mepoitem-cuobj
* IMPORTING
*           /SAPMP/CONF_RECORD  =
          TABLES
            configuration       = lt_conf
*           CONFIGURATION_IDOC  =
* CHANGING
*           MILL_SE_FATTR       =
          EXCEPTIONS
            instance_not_found  = 1
            internal_error      = 2
            no_class_allocation = 3
            instance_not_valid  = 4
            OTHERS              = 5.

        IF sy-subrc <> 0.

          CASE sy-subrc.
*Begin of changes by MMALI CMS #33311 changed all the messages from Error to Warning
            WHEN '1'.
              mmpur_message 'W' 'ZMM_RFSCOP' '061' space space space space.
            WHEN '2'.
              mmpur_message 'W' 'ZMM_RFSCOP' '062' space space space space.
            WHEN '3'.
              mmpur_message 'W' 'ZMM_RFSCOP' '063' space space space space.
            WHEN '4'.
              mmpur_message 'W' 'ZMM_RFSCOP' '064' space space space space.
          ENDCASE.
*End of changes by MMALI CMS #33311

*Begin of changes by MMALI CMS#33258
*          IF lv_rfpocreate = lc_x AND lv_bdc = lc_x. "MMALI CMS33909 08/06/2018
          CLEAR :ls_mepoitem-zz_atinn, ls_mepoitem-zz_atwrt.
          CALL METHOD im_item->set_data( ls_mepoitem ).
*          ENDIF."                                    "MMALI CMS33909 08/06/2018
*End of changes by MMALI CMS#33258
        ELSE.

          READ TABLE lt_conf INTO ls_conf WITH KEY atnam = 'FS_GRADE'.

          IF sy-subrc = 0.


*** Populate in the custom fields in PO
            ls_mepoitem-zz_atinn = ls_conf-atinn.
            ls_mepoitem-zz_atwrt = ls_conf-atwrt.
            CALL METHOD im_item->set_data( ls_mepoitem ).


**Begin of changes by MMALI CMS #33311 remove the custom message added to the message log if the grade is populated
*Get all the messages in the message log

            CALL METHOD cl_message_handler_mm=>get_handler
              IMPORTING
                ex_handler = lr_msg_handler_mm.

            CALL METHOD lr_msg_handler_mm->getlist
              IMPORTING
                ex_events = DATA(lt_events).

*get the context for the message related to the grade characteristic.

            LOOP AT lt_events INTO DATA(ls_events) WHERE signature CP lc_msg_pattern.
              lv_context = ls_events-context.
            ENDLOOP.

*remove the message from the message log
            IF lv_context IS NOT INITIAL.
              mmpur_remove_msg_by_context ls_mepoitem-id lv_context.
            ENDIF.
*End of changes by MMALI CMS #33311

          ELSE.

            zcl_mm_rfscop=>get_zmmfld_values(
                                          EXPORTING
                                            iv_key1 = 'E11185'
                                            iv_key2 = 'RFSCOP'
                                            iv_key3 = 'MESSAGES'
                                            iv_key4 = 'ZMM_RFSCOP'
                                            iv_key5 = '060'
                                            iv_type = 'S'
                                            iv_up_to_rows = 1
                                          IMPORTING
                                            es_zmmfld = ls_zmmfld ).

*- Message update: Grade characteristics not maintained
            CASE ls_zmmfld-value1.
              WHEN 'E'.
                mmpur_metafield mmmfd_configuration.        " 90000030.
                mmpur_message 'E' 'ZMM_RFSCOP' '060' ls_mepoitem-ebelp space space space.
              WHEN 'W'.
                mmpur_metafield mmmfd_configuration.        "90000030.
                mmpur_message 'W' 'ZMM_RFSCOP' '060' ls_mepoitem-ebelp space space space.
            ENDCASE.

*Begin of changes by MMALI CMS#33258
*            IF  lv_rfpocreate = lc_x AND lv_bdc = lc_x. ""MMALI CMS33909 08/06/2018
            CLEAR :ls_mepoitem-zz_atinn, ls_mepoitem-zz_atwrt.
            CALL METHOD im_item->set_data( ls_mepoitem ).
*            ENDIF.                     ""MMALI CMS33909 08/06/2018
*End of changes by MMALI CMS#33258

          ENDIF.

          CLEAR : ls_mepoitem-zz_atinn , ls_mepoitem-zz_atwrt.

        ENDIF.

      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD process_post.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 10/17/2018 *
* Method:       PROCESS_POST                                           *
* Programmer  : Mallik Aiely                   Last Update:            *
*______________________________________________________________________*
* Description : Common Method to be used for the future development in *
* BADI.                                                                *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Mallik Aiely      10/17/2018  33780        Common BADI Implementation*
************************************************************************

*-Below Class/method is used to implement any development to distinguish
*-different inventory developments / MAIELY / 10172018
    CALL METHOD zcl_me_process_po_cust=>process_ariba_post
      EXPORTING
        im_ebeln  = im_ebeln
        im_header = im_header.

  ENDMETHOD.


  METHOD process_rfscop.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/06/2018 *
* Method:       PROCESS_RFSCOP                                         *
* Programmer  : Mallik Aiely                      Last Update:         *
*______________________________________________________________________*
* Description: ALL RFSCOP BADI changes                                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Mallik Aiely       02/16/2018 E0V 33184  Initial transport           *
************************************************************************

* Auto populate index name and index region for PO creation process
    CALL METHOD zcl_me_process_po_cust=>process_rfscop_e04990
      EXPORTING
        im_item = im_item.

* Latest GR date Validation
    CALL METHOD zcl_me_process_po_cust=>process_item_rfscop_e11056
      EXPORTING
        im_item = im_item.

* Populate characteristic values in EKPO table
    CALL METHOD zcl_me_process_po_cust=>process_item_rfscop_e11185
      EXPORTING
        im_item = im_item.

* Calculate miles for recovered fiber purchase order and save it
* at the item level
    CALL METHOD zcl_me_process_po_cust=>process_rfscop_e11117
      EXPORTING
        im_item = im_item.

* Populate ship-to party address on the PO items for Domestic DLK PO
    CALL METHOD zcl_me_process_po_cust=>process_rfscop_e11118
      EXPORTING
        im_item = im_item.

  ENDMETHOD.


  METHOD process_rfscop_e04990.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/16/2018 *
* Method:       PROCESS_RFSCOP_E11045                                  *
* Programmer  : Anil Lankapalli                   Last Update:         *
*______________________________________________________________________*
* Description: E11045 - This method is used in auto populating the     *
* index name and index region for PO creation process.                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ================== =========  =========  =========================== *
* Anil Lankapalli    02/16/2018 E0VK9A0W19 CMS: 33160 Initial transport*
************************************************************************

    INCLUDE mm_messages_mac. "useful macros for message handling
    DATA: lv_imsgty TYPE syst_msgty.
    DATA: lv_imsgid TYPE syst_msgid.
    DATA: lv_imsgno TYPE syst_msgno.
    DATA: lv_msgty TYPE syst_msgty.
    DATA: lv_msgid TYPE syst_msgid.
    DATA: lv_msgno TYPE syst_msgno.
    DATA: lv_rmsgty TYPE syst_msgty.
    DATA: lv_rmsgid TYPE syst_msgid.
    DATA: lv_rmsgno TYPE syst_msgno.
    DATA: lv_datab  TYPE kodatab.
    DATA: lv_ierror_flag TYPE char1. " Index error
    DATA: lv_rerror_flag TYPE char1. " Region error
    DATA: lr_msg_handler_mm   TYPE REF TO cl_message_handler_mm.
    DATA: lv_context          TYPE mmpur_context.
    DATA: lv_update TYPE char01.
    CONSTANTS:lc_msg_pat18 TYPE string VALUE 'ZMM_RFSCOP*018*',
              lc_msg_pat19 TYPE string VALUE 'ZMM_RFSCOP*019*',
              lc_msg_pat25 TYPE string VALUE 'ZMM_RFSCOP*025*'.


    DATA(ls_mepoitem) = im_item->get_data( ).
    DATA(lo_header) = im_item->get_header( ).
    DATA(ls_mepoheader) = lo_header->get_data( ).

*    BREAK alankap.
    CALL METHOD cl_message_handler_mm=>get_handler
      IMPORTING
        ex_handler = lr_msg_handler_mm.

    CALL METHOD lr_msg_handler_mm->getlist
      IMPORTING
        ex_events = DATA(lt_events).

    CLEAR lv_update.
***  Check if the Pur org of the PO is RFSCOP related
    SELECT SINGLE * INTO @DATA(ls_zmmfld) FROM zmmfld
           WHERE key1   = @gc_e04990
           AND   key2   = @gc_rfscop
           AND   key3   = @gc_ekorg
           AND   key4   = @space
           AND   value1 = @ls_mepoheader-ekorg.

    CHECK sy-subrc IS INITIAL.

    IF ls_mepoheader-bstyp = 'F' AND ls_mepoitem-pstyp EQ '0'.

** If the Validity start date is not maintained in the PO please
** consider the PO document date
      IF ls_mepoheader-kdatb IS NOT INITIAL.
        lv_datab = ls_mepoheader-kdatb.
      ELSE.
        lv_datab = ls_mepoheader-bedat.
      ENDIF.

      CLEAR lv_update.
      SELECT SINGLE * INTO ls_zmmfld FROM zmmfld
       WHERE key1   = gc_e04990
       AND   key2   = gc_rfscop
       AND   key3   = gc_material_group
       AND   value1 = ls_mepoitem-matkl.
      CHECK sy-subrc IS INITIAL.
* Get the existing conditions
      im_item->get_conditions(
        IMPORTING
          ex_conditions =  DATA(lt_tkomv)   " Conditions
      ).

* Get the condition amount for ZBXX condition if it exists
      DATA(ls_komv) = VALUE #( lt_tkomv[
                                         kschl = 'ZBXX'
                                         kinak = space ]
                                         DEFAULT space ).

*lv_update = 'X'.
*** Get the Index Name from A858 table
      SELECT SINGLE a858~zz_index_name INTO ls_mepoitem-zz_index_name
             FROM a858 INNER JOIN
             konp ON konp~knumh = a858~knumh
             WHERE a858~kappl = gc_kappl_m
             AND   a858~kschl = gc_kschl_zrin
             AND   a858~matnr = ls_mepoitem-matnr
             AND   a858~datab LE lv_datab
             AND   a858~datbi GE lv_datab
             AND   konp~loevm_ko EQ space.

      IF NOT sy-subrc IS INITIAL.
        CLEAR: ls_mepoitem-zz_index_name.
        CLEAR: ls_zmmfld.
        SELECT SINGLE * INTO ls_zmmfld FROM zmmfld
        WHERE key1   = gc_e04990
        AND   key2   = gc_rfscop
        AND   key3   = gc_messages
        AND   key4   = gc_zmm_rfscop
        AND   key5   = '018'.
        IF sy-subrc IS INITIAL.
          IF ls_komv-kbetr IS INITIAL.
            IF NOT ls_zmmfld-value1 IS INITIAL.
* In case of error message update the PO item
              lv_ierror_flag = 'X'.
              lv_imsgty = ls_zmmfld-value1.
              lv_imsgid = ls_zmmfld-key4.
              lv_imsgno = ls_zmmfld-key5.
            ENDIF.
          ENDIF.
        ENDIF.
      ELSE.
        lv_update = 'X'.
      ENDIF.

      IF ls_mepoheader-llief IS NOT INITIAL.
*** Get the Region Name from A857 table
        SELECT SINGLE a857~zz_index_region INTO ls_mepoitem-zz_index_region
               FROM a857 INNER JOIN
               konp ON konp~knumh = a857~knumh
               WHERE a857~kappl = gc_kappl_m
               AND   a857~kschl = gc_kschl_zrin
               AND   a857~lifnr = ls_mepoheader-lifnr
               AND   a857~llief = ls_mepoheader-llief
               AND   a857~werks = ls_mepoitem-werks
               AND   a857~datab LE lv_datab
               AND   a857~datbi GE lv_datab
               AND   konp~loevm_ko EQ space.

        IF sy-subrc IS NOT INITIAL.

          SELECT SINGLE a857~zz_index_region INTO ls_mepoitem-zz_index_region
               FROM a857 INNER JOIN
               konp ON konp~knumh = a857~knumh
               WHERE a857~kappl = gc_kappl_m
               AND   a857~kschl = gc_kschl_zrin
               AND   a857~lifnr = ls_mepoheader-lifnr
               AND   a857~llief = ls_mepoheader-llief
               AND   a857~werks = space
               AND   a857~datab LE lv_datab
               AND   a857~datbi GE lv_datab
               AND   konp~loevm_ko EQ space.

          IF sy-subrc IS NOT INITIAL.
            CLEAR: ls_mepoitem-zz_index_region.
* If we don't have valid index region in A857 table pass the value 99
*            ls_mepoitem-zz_index_region = '99'.
            CLEAR: ls_zmmfld.
            SELECT SINGLE * INTO ls_zmmfld FROM zmmfld
            WHERE key1  = gc_e04990
            AND   key2  = gc_rfscop
            AND   key3  = gc_messages
            AND   key4  = gc_zmm_rfscop
            AND   key5  = '019'.

            IF sy-subrc IS INITIAL.

              IF ls_komv-kbetr IS INITIAL.

                IF NOT ls_zmmfld-value1 IS INITIAL.

                  lv_rerror_flag = 'X'.
                  lv_rmsgty = ls_zmmfld-value1.
                  lv_rmsgid = ls_zmmfld-key4.
                  lv_rmsgno = ls_zmmfld-key5.
                ENDIF.
              ENDIF.
            ENDIF.
          ELSE.
            lv_update = 'X'.
          ENDIF.
        ELSE.

          lv_update = 'X'.
        ENDIF.

      ENDIF.

      IF lv_update = 'X'.
        CALL METHOD im_item->set_data( ls_mepoitem ).
      ENDIF.
      IF lv_ierror_flag EQ 'X' AND lv_rerror_flag EQ 'X'.

        SELECT SINGLE * INTO ls_zmmfld FROM zmmfld
                WHERE key1  = gc_e04990
                AND   key2  = gc_rfscop
                AND   key3  = gc_messages
                AND   key4  = gc_zmm_rfscop
                AND   key5  = '025'.
        IF sy-subrc IS INITIAL.

          "get the context for the message related to the grade characteristic.
          LOOP AT lt_events INTO DATA(ls_events) WHERE signature CP lc_msg_pat25.
            lv_context = ls_events-context.
          ENDLOOP.

          "remove the message from the message log
          IF lv_context IS NOT INITIAL.
            mmpur_remove_msg_by_context ls_mepoitem-id lv_context.
          ENDIF.

          lv_msgty = ls_zmmfld-value1.
          lv_msgid = ls_zmmfld-key4.
          lv_msgno = ls_zmmfld-key5.
*          mmpur_metafield '90000041'.
          mmpur_message lv_msgty lv_msgid lv_msgno '' '' '' ''.
        ENDIF.
      ELSE.
* Display error message if the Index name is missing
        IF lv_ierror_flag EQ 'X'.
          " get the context for the message related to the grade characteristic.
          LOOP AT lt_events INTO ls_events WHERE signature CP lc_msg_pat18.
            lv_context = ls_events-context.
          ENDLOOP.

          " remove the message from the message log
          IF lv_context IS NOT INITIAL.
            mmpur_remove_msg_by_context ls_mepoitem-id lv_context.
          ENDIF.

*          mmpur_metafield '90000041'.
          mmpur_message lv_imsgty lv_imsgid lv_imsgno '' '' '' ''.
        ENDIF.

* Display error message if the Index Region is missing
        IF lv_rerror_flag EQ 'X'.

          " get the context for the message related to the grade characteristic.
          LOOP AT lt_events INTO ls_events WHERE signature CP lc_msg_pat19.
            lv_context = ls_events-context.
          ENDLOOP.

          " remove the message from the message log
          IF lv_context IS NOT INITIAL.
            mmpur_remove_msg_by_context ls_mepoitem-id lv_context.
          ENDIF.

*          mmpur_metafield '90000042'.
          mmpur_message lv_rmsgty lv_rmsgid lv_rmsgno '' '' '' ''.
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  method process_rfscop_e11117.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/16/2018 *
* Method:       PROCESS_RFSCOP_E11117                                  *
* Programmer  : Helena Malkowska                  Last Update:         *
*______________________________________________________________________*
* Description: E11117 - Changes for project #45533 RFSCOP (Recovered   *
*              Fiber Supply Chain Optimization). Calculate miles for   *
*              recovered fiber purchase order and save it at the item  *
*              level                                                   *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Helena Malkowska    02/2018   E0V 33267  Initial transport           *
************************************************************************

    data: ls_zmmfld type zmmfld.
    data: lv_zz_zdist type zdist.
    data: lv_meins type bstme.

    data(ls_mepoitem) = im_item->get_data( ).
    data(lo_header) = im_item->get_header( ).
    data(ls_mepoheader) = lo_header->get_data( ).


    "Check if the PO is RFSCOP related
    if zcl_mm_rfscop=>get_zmmfld_values(
                                       exporting
                                         iv_key1 = 'E11117'
                                         iv_key2 = 'RFSCOP'
                                         iv_key3 = 'EKORG'
                                         iv_value1 = ls_mepoheader-ekorg
                                         iv_type = 'S'
                                         iv_up_to_rows = 1
                                       importing
                                         es_zmmfld = ls_zmmfld ) = 'X'.


      if ( ls_mepoheader-bstyp <> 'F' ).        "It is not Purchase Ord
        return.
      elseif ( ls_mepoitem-pstyp = '0' and      "It is an external PO
             ( ls_mepoitem-werks is initial or
               ls_mepoitem-evers is initial or
               ls_mepoheader-llief is initial ) ).
        return.
      elseif ( ls_mepoitem-pstyp = '7' and      "It is  STO
             ( ls_mepoitem-werks is initial or
               ls_mepoitem-evers is initial or
               ls_mepoheader-reswk is initial ) ).
        return.
      else.

        "call method get_miles
        if zcl_mm_rfscop=>get_miles(
                               exporting iv_lifnr = ls_mepoheader-llief
                                         iv_reswk = ls_mepoheader-reswk
                                         iv_werks = ls_mepoitem-werks
                                         iv_evers = ls_mepoitem-evers
                               importing
                                         ev_zz_zdist = lv_zz_zdist
                                         ev_meins    = lv_meins ) = 'X'.

          ls_mepoitem-zz_zdist = lv_zz_zdist.
          im_item->set_data( ls_mepoitem ).
        else.
          "Unable to determine miles
          message w004(zmm_rfscop).
        endif.
      endif.
    endif.

  endmethod.


    method process_rfscop_e11118.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2018                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 02/06/2018 *
* Method:       PROCESS_RFSCOP_E11118                                  *
* Programmer  : Helena Malkowska                  Last Update:         *
*______________________________________________________________________*
* Description: E11118 - Changes for project #45533 RFSCOP (Recovered   *
*              Fiber Supply Chain Optimization). Populate ship-to party*
*              address on the PO items for Domestic DLK PO.            *
*              Some logic has been moved from BADI ME_PROCESS_PO_CUST  *
*              implemtation ZMME_PROCESS_PO_CUST - method PROCESS_ITEM *
*              because the update logic is the same as for PO type     *
*              BSART = 'THD' (E3049). Thus PO items will be update if  *
*              PO is domestic DLK or PO type BSART = 'THD'             *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Helena Malkowska    02/2018   E0V 33184  Initial transport.          *
* Helena Malkowska    01/2019   E0V 34842  Fix the logic with update   *
*                                          SCHPR (estimated price flag)*
* Helena Malkowska    01/2019   E0V 34891  ZF freight forwarder will   *
*                                          be automatically populated  *
*                                          on PO partner tab           *
************************************************************************

      types: t_bsart type range of bsart.

      data: lr_bsart type t_bsart.
      data: ls_zmmfld type zmmfld.
*     data: lv_execute type char01.                "hmalkow - E0V 34842
      data: lv_update type char01.
*** hmalkow - E0V 34842 - start
      data: lv_execute_trades type char01.
      data: lv_execute_rfscop type char01.
*** hmalkow - E0V 34842 - end

      data(ls_mepoitem) = im_item->get_data( ).
      data(lo_header) = im_item->get_header( ).
      data(ls_mepoheader) = lo_header->get_data( ).

*** hmalkow - E0V 34842 - start
      select single * from zplant into @data(ls_zplant)
        where werks = @ls_mepoitem-werks.
*** hmalkow - E0V 34842 - end

      "---Check PO Type
      "Create range for PO types
      zcl_mm_rfscop=>get_zmmfld_values(
                                       exporting
                                         iv_key1 = 'E3049'
                                         iv_key2 = 'TRADES'
                                         iv_key3 = 'BSART'
                                         iv_type = 'R'
                                       importing
                                         et_zmmfld = lr_bsart ).

     if ls_mepoheader-bsart in lr_bsart[] and lr_bsart[] is not initial.
        lv_execute_trades = 'X'.
      endif.
      "---End Check PO Type

      "---Check if it is Domestic DLK process

*     if lv_execute is initial.                     "hmalkow - E0V 34842

      if zcl_mm_rfscop=>get_zmmfld_values(
                                     exporting
                                       iv_key1 = 'E11118'
                                       iv_key2 = 'RFSCOP'
                                       iv_key3 = 'EKORG'
                                       iv_value1 = ls_mepoheader-ekorg
                                       iv_type = 'S'
                                       iv_up_to_rows = 1
                                     importing
                                       es_zmmfld = ls_zmmfld ) = 'X'.

*** hmalkow - E0V 34842 - lines below commented out
*        select single * from zplant into @data(ls_zplant)
*          where werks = @ls_mepoitem-werks.
*
*       if sy-subrc = 0 and ls_zplant-type <> 'PORT'.
*** hmalkow - E0V 34842 – end lines commented out

        if ls_zplant-type <> 'PORT'.                "hmalkow - E0V 34842
          "It is Domestic DLK process
          lv_execute_rfscop = 'X'.
        endif.
      endif.
*     endif.                                        "hmalkow - E0V 34842
      "---End Check if it is Domestic DLK  process

*** E3049 - Moved logic - start
*     if lv_execute = 'X'.                          "hmalkow - E0V 34842
*** hmalkow - E0V 34842 - start
      if lv_execute_trades = 'X' or lv_execute_rfscop = 'X'.
*** hmalkow - E0V 34842 - end

        "---Get sales order data for the purchase requisition data
        clear: lv_update.

        "---Get the sales order number for the purchase req
        select vbak~vbeln up to 1 rows into @data(lv_vbeln)
          from vbak inner join ebkn on ebkn~vbeln = vbak~vbeln
          where ebkn~banfn = @ls_mepoitem-banfn
            and ebkn~bnfpo = @ls_mepoitem-bnfpo.
        endselect.

        if sy-subrc = 0.

          if ls_mepoitem-schpr is initial
*** hmalkow - E0V 34842 - start
             and ls_zplant-type <> 'PORT'
             "It is TRADES process
             and lv_execute_trades = 'X'.
*** hmalkow - E0V 34842 - end
            ls_mepoitem-schpr = 'X'.
            lv_update = 'X'.
          endif.

          "---bring the SH from Sales Order to Customer on PO Item
          select kunnr up to 1 rows into ls_mepoitem-kunnr
            from vbpa where vbeln = lv_vbeln
                        and parvw = 'WE'.
          endselect.

          "---if found update sales data then set mepoitem-customer.no
          if sy-subrc = 0.
            lv_update = 'X'.
          endif.

          if lv_update = 'X'.
            im_item->set_data( ls_mepoitem ).
          endif.

        endif.

      endif.
*** E3049 - Moved logic - end

*** hmalkow - E0V 34891 - start
      if zcl_mm_rfscop=>get_zmmfld_values(
                                     exporting
                                       iv_key1 = 'E11118'
                                       iv_key2 = 'RFSCOP'
                                       iv_key3 = 'EKORG'
                                       iv_value1 = ls_mepoheader-ekorg
                                       iv_type = 'S'
                                       iv_up_to_rows = 1
                                     importing
                                       es_zmmfld = ls_zmmfld ) = 'X'.
        "Get account assigment data
        data(lt_acc_tab) = im_item->get_accountings( ).

        read table lt_acc_tab index 1 into data(ls_acc_tab).

        if sy-subrc = 0.

          data(ls_accounting) = ls_acc_tab-accounting->get_data( ).

          "Find the ZF Freight Forwarder in Sales Order
          select single * from  vbpa into @data(ls_vbpa)
            where vbeln = @ls_accounting-vbeln
              and posnr = 000000
              and parvw = 'ZF'.

          if sy-subrc = 0.

            add_partner_to_po( exporting im_item = im_item
                                         iv_lifnr = ls_vbpa-lifnr
                                         iv_parvw = 'ZF' ).
          endif.

        endif.
      endif.

*** hmalkow - E0V 34891 - end

    endmethod.


  method PROCESS_SYLVAMO.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2021                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 04/19/2021 *
* Method:       PROCESS_SYLVAMO                                        *
* Programmer  : Anil Lankapalli                   Last Update:         *
*______________________________________________________________________*
* Description: ALL RFSCOP BADI changes                                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Anil Lankapalli    04/19/2021 ESBK9A20FI  Initial transport           *
************************************************************************

* Auto populate the customer number for PO creation process
    CALL METHOD zcl_me_process_po_cust=>process_sylvamo_e11733
      EXPORTING
        im_item =  im_item.              " PO Item External View


  endmethod.


  method PROCESS_SYLVAMO_E11733.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2021                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Program Name: ME_PROCESS_PO_CUST             Create Date: 04/19/2021 *
* Method:       PROCESS_SYLVAMO_E11733                                 *
* Programmer  : Anil Lankapalli                   Last Update:         *
*______________________________________________________________________*
* Description: Sylvamo BADI changes                                 *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #               Action            *
* ==================  ========  =========  =========================== *
* Anil Lankapalli    04/19/2021 ESBK9A20FI  To get the correct shipping*
*                                           address and update the PO  *
************************************************************************

      data: lv_update type char01.

      data(ls_mepoitem)   = im_item->get_data( ).
      data(lo_header)     = im_item->get_header( ).
      data(ls_mepoheader) = lo_header->get_data( ).

      select * into table @data(lt_zdl_fields) from zdl_fields
             where category = 'E11733_SHIP'.

       data(lv_werks) = value #( lt_zdl_fields[ fieldname = 'WERKS'
                                                lowval    = ls_mepoitem-werks  ]-lowval
                                                DEFAULT space ).
       data(lv_bsart) = value #( lt_zdl_fields[ fieldname = 'BSART'
                                                lowval    = LS_MEPOHEADER-bsart  ]-lowval
                                                DEFAULT space ).

       if not lv_werks is INITIAL and not lv_bsart IS INITIAL.

        "---Get the sales order number for the purchase req
        select vbak~vbeln up to 1 rows into @data(lv_vbeln)
          from vbak inner join ebkn on ebkn~vbeln = vbak~vbeln
          where ebkn~banfn = @ls_mepoitem-banfn
            and ebkn~bnfpo = @ls_mepoitem-bnfpo.
        endselect.

        if sy-subrc = 0.

          "---bring the SH from Sales Order to Customer on PO Item
          select kunnr up to 1 rows into ls_mepoitem-kunnr
            from vbpa where vbeln = lv_vbeln
                        and parvw = 'WE'.
          endselect.

          "---if found update sales data then set mepoitem-customer.no
          if sy-subrc = 0.
            lv_update = 'X'.
          endif.

          if lv_update = 'X'.
            im_item->set_data( ls_mepoitem ).
          endif.

        endif.

      endif.

  endmethod.


  METHOD set_po_aux_prodid.

    TYPES:BEGIN OF tt_supp_data,
            supp_part TYPE char1024,
          END OF tt_supp_data.

    DATA:lt_supp_data TYPE STANDARD TABLE OF tt_supp_data,
         lv_tdid      TYPE tdid,
         lv_texttype  TYPE mmpur_texttypes,
         lt_textlines TYPE mmpur_t_textlines.

*-Set External Product ID on the item text with TDOBJECT = 'EKKO' , TDID = 'F07'
*-TDLINE = PO#Item#Supp.Aux.Part ID
    lv_tdid = 'F07'.
    lv_texttype-tdobject = 'EKKO'.
    lv_texttype-tdid = 'F07'.

    CALL METHOD im_item->if_longtexts_mm~get_text
      EXPORTING
        im_tdid      = lv_tdid
        im_texttype  = lv_texttype
      IMPORTING
        ex_textlines = lt_textlines.

    IF lt_textlines IS INITIAL.

      SPLIT io_supp_prodid AT '|' INTO TABLE lt_supp_data.

      DATA(lv_aux_partid) = VALUE #( lt_supp_data[ 3 ]-supp_part  OPTIONAL ).

      IF lv_aux_partid IS NOT INITIAL.

        lv_tdid = 'F07'.
        APPEND VALUE mmpur_textlines( tdobject = 'EKKO' tdid = 'F07' tdformat = '*'
                                      tdline = lv_aux_partid ) TO lt_textlines.

        CALL METHOD im_item->if_longtexts_mm~set_text
          EXPORTING
            im_tdid      = lv_tdid
            im_textlines = lt_textlines.

        CLEAR lv_aux_partid.

      ENDIF.

    ENDIF.


  ENDMETHOD.
ENDCLASS.

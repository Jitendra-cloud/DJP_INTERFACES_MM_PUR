*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMINFOREC_PRICE.................................*
DATA:  BEGIN OF STATUS_ZMINFOREC_PRICE               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMINFOREC_PRICE               .
CONTROLS: TCTRL_ZMINFOREC_PRICE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMINFOREC_PRICE               .
TABLES: ZMINFOREC_PRICE                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

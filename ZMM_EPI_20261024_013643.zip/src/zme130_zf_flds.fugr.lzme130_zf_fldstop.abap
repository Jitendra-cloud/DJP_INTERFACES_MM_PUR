FUNCTION-POOL ZME130_ZF_FLDS             MESSAGE-ID SV.

* INCLUDE LZME130_ZF_FLDSD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZME130_ZF_FLDST00                      . "view rel. data dcl.

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z2BR
*   generation date: 2003.04.16 at 13:39:40 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z2BR               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z2MV
*   generation date: 2003.04.16 at 13:38:45 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z2MV                .

  PERFORM TABLEPROC.

ENDFUNCTION.

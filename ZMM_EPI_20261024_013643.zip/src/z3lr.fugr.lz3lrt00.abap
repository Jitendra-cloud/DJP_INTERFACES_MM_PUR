*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 02/25/2003 at 10:02:30 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMEXCESLOSTRSN..................................*
DATA:  BEGIN OF STATUS_ZMEXCESLOSTRSN                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMEXCESLOSTRSN                .
CONTROLS: TCTRL_ZMEXCESLOSTRSN
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMEXCESLOSTRSN                .
TABLES: ZMEXCESLOSTRSN                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

class ZCL_MM_E11554_PGRP definition
  public
  inheriting from ZCL_GRID_OBJ
  create public .

public section.

  data MS_ZPOR4 type ZPOR4 .

  methods CONSTRUCTOR
    importing
      !IV_LANGU type SPRAS default SPACE
      !IV_ZEKGRP type ZEKGRP default SPACE .
  methods READ_DB
    importing
      value(IV_LANGU) type SPRAS
      value(IV_ZEKGRP) type ZEKGRP .
  class-methods EDIT_OBJECT_MULTIPLE
    importing
      !T_OBJ type ZIF_T_GRID_OBJ optional
      !MODE type CHAR1
      !SOURCECTRL type ref to CL_GUI_OBJECT optional .

  methods ZIF_GRID_OBJ~EDIT_OBJECT
    redefinition .
  methods ZIF_GRID_OBJ~GET_WHERE
    redefinition .
  methods ZIF_GRID_OBJ~MOVE_TO_GRID
    redefinition .
protected section.
*"* protected components of class ZCL_MM_E11554_PGRP
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_MM_E11554_PGRP
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_MM_E11554_PGRP IMPLEMENTATION.


method CONSTRUCTOR.

  super->constructor( ).

  me->read_db( exporting iv_langu  = iv_langu
                         iv_zekgrp = iv_zekgrp ).

  if ms_zpor4 is initial.
    me->ms_zpor4-langu  = iv_langu.
    me->ms_zpor4-zekgrp = iv_zekgrp.
  endif.

endmethod.


method edit_object_multiple.

* N - new
* X - delete
* R - rename
* D - display
* U - change
* C - copy

  data: lo_obj    type ref to zcl_mm_e11554_pgrp.
  data: ls_obj    type zif_s_grid_obj.

  if lines( t_obj[] ) > 1 and not 'XNT' cs mode.
    message i037(zglmn).
    return.
  endif.

  if t_obj[] is initial and 'UDCXT' cs mode.
    return.
  endif.

  case mode.
    when 'T'.

    when 'N'.

      check sourcectrl is bound.

      lo_obj = new #( iv_langu  = space
                      iv_zekgrp = space ).

      lo_obj->zif_grid_obj~edit_object( exporting
                                          mode = mode
                                          sourcectrl = sourcectrl ).

    when others.

      loop at t_obj into ls_obj.
        check ls_obj-object is bound.
        lo_obj ?= ls_obj-object.
        lo_obj->zif_grid_obj~edit_object( exporting
                                            mode = mode
                                            sourcectrl = sourcectrl ).
      endloop.
  endcase.

endmethod.


method READ_DB.

  clear: ms_zpor4.
  select single * from zpor4 into ms_zpor4
    where langu  = iv_langu
      and zekgrp = iv_zekgrp.

endmethod.


method zif_grid_obj~edit_object.

* N - new
* X - delete
* R - rename
* D - display
* U - change
* C - copy

  data: ls_e     type zpor4.
  data: lo_object type ref to zcl_mm_e11554_pgrp.
  data: lv_saved(1) type c.

  case mode.

    when 'R'.

    when 'X'.

      call function 'ZMM_PGRP_DELETE'
        exporting
          is_zpor4           = me->ms_zpor4
        importing
          ev_saved           = lv_saved
        exceptions
          others            = 1.

    when 'U' or 'C' or 'N' or 'D'.

      call function 'ZMM_PGRP_EDIT'
        exporting
          is_zpor4          = me->ms_zpor4
          iv_mode           = mode
        importing
          es_zpor4          = ls_e
          ev_saved          = lv_saved
        exceptions
          others            = 1.

  endcase.

  if sy-subrc <> 0.
    message id sy-msgid type 'I' number sy-msgno
       with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  endif.

  if lv_saved = 'X'.

    if 'RUCN' cs mode.
      check ls_e is not initial.
    endif.

    if 'RCN' cs mode.
      create object lo_object
        exporting
          iv_langu = ls_e-langu
          iv_zekgrp = ls_e-zekgrp.
    endif.

    case mode.
      when 'R'.
        me->zif_grid_obj~raise_db_renamed(
                exporting new_object = lo_object ).
        e_object = lo_object.

      when 'U'.
        me->read_db( exporting iv_langu = ls_e-langu
                               iv_zekgrp = ls_e-zekgrp ).

        me->zif_grid_obj~raise_db_changed( ).

      when 'C' or 'N'.
        lo_object->zif_grid_obj~raise_db_created(
                       exporting sourcectrl = sourcectrl ).
        e_object = lo_object.

      when 'X'.
        me->zif_grid_obj~raise_db_deleted( ).
    endcase.
  endif.


endmethod.


method ZIF_GRID_OBJ~GET_WHERE.

  e_where = 'LANGU = ''&1'' and ZEKGRP = ''&2'''.
  replace '&1' with me->ms_zpor4-langu into e_where.
  replace '&2' with me->ms_zpor4-zekgrp into e_where.

endmethod.


method ZIF_GRID_OBJ~MOVE_TO_GRID.

  field-symbols: <l_field> type any.

  data: ls_zpor4 type zpor4.

  ls_zpor4 = me->ms_zpor4.

  if no_db_read is initial.
    me->read_db( exporting iv_langu  = ms_zpor4-langu
                           iv_zekgrp = ms_zpor4-zekgrp ).
  endif.

  define mv.
    assign component &1 of structure c_table_line to <l_field>.
    if sy-subrc = 0.
      <l_field> = &2.
    endif.
  end-of-definition.

  move-corresponding me->ms_zpor4 to c_table_line.
  mv 'OBJECT' me.

endmethod.
ENDCLASS.

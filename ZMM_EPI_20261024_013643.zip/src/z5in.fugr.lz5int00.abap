*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZINC1...........................................*
DATA:  BEGIN OF STATUS_ZINC1                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINC1                         .
CONTROLS: TCTRL_ZINC1
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINC1                         .
TABLES: ZINC1                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

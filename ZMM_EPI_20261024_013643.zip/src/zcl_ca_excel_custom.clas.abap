class ZCL_CA_EXCEL_CUSTOM definition
  public
  final
  create public .

*"* public components of class ZCL_CA_EXCEL_CUSTOM
*"* do not include other source files here!!!
public section.
  type-pools ABAP .
  type-pools SOI .
  type-pools ZCA01 .

  constants GC_FILE_PREFIX type STRING value 'FILE://'. "#EC NOTEXT

  methods CONSTRUCTOR
    exceptions
      NOT_INITIALIZED .
  methods EXPORT_TEMPLATE_AND_DATA
    importing
      value(IT_ABAP_DATA) type STANDARD TABLE
      value(IV_FILE_NAME) type C optional
      value(IB_CLIENT_SPECIFIED) type BOOLEAN default SPACE
    exporting
      !EV_FILE_URL type C
      !ET_CONV_ERRORS type ZCA_EXCEL_ERROR_TAB
    exceptions
      COULD_NOT_DETERMINE_SOURCE_STR
      INTERFACE_UNAVAILABLE .
  methods EXPORT_TEMPLATE_SPREADSHEET
    importing
      !IV_STRUCTURE type STRUKNAME
      value(IV_FILE_NAME) type C optional
      value(IB_CLIENT_SPECIFIED) type BOOLEAN default SPACE
    exporting
      !EV_FILE_URL type C
    exceptions
      STRUCTURE_NOT_FOUND
      INTERFACE_UNAVAILABLE .
  methods EXPORT_TEMPLATE_CUSTOM
    importing
      !IV_STRUCTURE type STRUKNAME
      !IV_FILE_NAME type C
      !IB_CLIENT_SPECIFIED type BOOLEAN default SPACE
    exporting
      !EV_FILE_URL type C
    exceptions
      STRUCTURE_NOT_FOUND
      INTERFACE_UNAVAILABLE .
  methods FREE .
  methods IMPORT_AND_CONVERT_DATA
    importing
      value(IV_FILE_URL) type C optional
      value(IB_CLIENT_SPECIFIED) type BOOLEAN default SPACE
      value(IB_DO_CONVEXIT) type BOOLEAN default SPACE
    exporting
      !ET_TABLE type STANDARD TABLE
      !ET_CONV_ERRORS type ZCA_EXCEL_ERROR_TAB
      !EV_FIRST_DATA_ROW type INT4
    exceptions
      FILE_NOT_FOUND
      INTERFACE_UNAVAILABLE
      INVALID_EXCEL_DOCUMENT
      NO_UPLOADED_DATA
      COULD_NOT_DETERMINE_TARGET
      UNKNOWN_ERROR .
protected section.
*"* protected components of class ZCL_CA_EXCEL_DOCUMENT
*"* do not include other source files here!!!
private section.
*"* private components of class ZCL_CA_EXCEL_DOCUMENT
*"* do not include other source files here!!!

  constants GC_FILTER_EXCEL type STRING
 value 'Excel Sheet (*.xls)|*.xls|'. "#EC NOTEXT
  constants GC_FONT_HEAD_LARGE type I value 10. "#EC NOTEXT
  constants GC_FONT_HEAD_SMALL type I value 8. "#EC NOTEXT
  constants GC_INPLACE type BOOLEAN value ABAP_TRUE. "#EC NOTEXT
  constants GC_PACKETS type I value 25. "#EC NOTEXT
  constants GC_RANGE_ATTR type CHAR12 value 'RANGE_ATTR'. "#EC NOTEXT
  constants:
    begin of GC_RANGE_BOUNDS, "#EC NOTEXT
      top_attr    type sy-tabix value 6,
      top_cols    type sy-tabix value 3,
      top_data    type sy-tabix value 7,
      top_dead    type sy-tabix value 1,
      top_descr   type sy-tabix value 4,
      top_down    type sy-tabix value 7,
      top_dummy   type sy-tabix value 2,
      top_field   type sy-tabix value 3,
      top_head    type sy-tabix value 1,
      top_key     type sy-tabix value 7,
      top_struc   type sy-tabix value 1,
      top_sdesc   type sy-tabix value 1,
      top_tech    type sy-tabix value 5,
      left_attr   type sy-tabix value 1,
      left_cols   type sy-tabix value 1,
      left_data   type sy-tabix value 1,
      left_descr  type sy-tabix value 1,
      left_down   type sy-tabix value 1,
      left_dummy  type sy-tabix value 1,
      left_field  type sy-tabix value 1,
      left_key    type sy-tabix value 1,
      left_head   type sy-tabix value 1,
      left_struc  type sy-tabix value 1,
      left_sdesc  type sy-tabix value 4,
      left_tech   type sy-tabix value 1,
      rows_attr   type sy-tabix value 1,
      rows_cols   type sy-tabix value 4,
      rows_data   type sy-tabix value 9999,
      rows_dead   type sy-tabix value 65536,
      rows_descr  type sy-tabix value 1,
      rows_dummy  type sy-tabix value 1,
      rows_field  type sy-tabix value 1,
      rows_head   type sy-tabix value 6,
      rows_struc  type sy-tabix value 1,
      rows_sdesc  type sy-tabix value 1,
      rows_tech   type sy-tabix value 1,
      cols_dead   type sy-tabix value 100,
      cols_struc  type sy-tabix value 3,
      cols_sdesc  type sy-tabix value 1,
    end of GC_RANGE_BOUNDS .
  constants GC_RANGE_COLS type CHAR12 value 'RANGE_COLS'. "#EC NOTEXT
  constants GC_RANGE_DATA type CHAR12 value 'RANGE_DATA'. "#EC NOTEXT
  constants GC_RANGE_DEAD type CHAR12 value 'RANGE_DEAD'. "#EC NOTEXT
  constants GC_RANGE_DESCR type CHAR12 value 'RANGE_DESCR'. "#EC NOTEXT
  constants GC_RANGE_DOWNLOAD type CHAR12
 value 'RANGE_DOWN'. "#EC NOTEXT
  constants GC_RANGE_DUMMY type CHAR12 value 'RANGE_DUMMY'. "#EC NOTEXT
  constants GC_RANGE_FIELDS type CHAR12
 value 'RANGE_FIELDS'. "#EC NOTEXT
  constants GC_RANGE_HEAD type CHAR12 value 'RANGE_HEAD'. "#EC NOTEXT
  constants GC_RANGE_KEY type CHAR12 value 'RANGE_KEY'. "#EC NOTEXT
  constants GC_RANGE_STRUC type CHAR12 value 'RANGE_STRUC'. "#EC NOTEXT
  constants GC_RANGE_STRUCDESCR type CHAR12
 value 'RANGE_STRUCD'. "#EC NOTEXT
  constants GC_RANGE_TECH type CHAR12 value 'RANGE_TECH'. "#EC NOTEXT
  constants GC_RANGE_WIDTH type CHAR12 value 'RANGE_WIDTH'. "#EC NOTEXT
  constants GC_TRANSLATE type STRING value '/_'. "#EC NOTEXT
  data GO_CONTAINER type ref to CL_GUI_CUSTOM_CONTAINER .
  data GO_CONTROL type ref to I_OI_CONTAINER_CONTROL .
  data GO_DOCUMENT type ref to I_OI_DOCUMENT_PROXY .
  data GO_ERROR type ref to I_OI_ERROR .
  data GO_SHEET type ref to I_OI_SPREADSHEET .
  data GO_TABLE type ref to I_OI_TABLE_COLLECTION .
  data GT_CONTENTS type SOI_GENERIC_TABLE .
  data GT_ERRORS type TT_ERRORS .

  methods BUILD_INTERNAL_RANGES
    importing
      value(IV_MAX_COLS) type I
      value(IV_STRUCTURE) type STRUKNAME
    exporting
      !ET_RANGES type SOI_FULL_RANGE_TABLE
      !ES_HEADER_DATA type TS_HEADER_DATA .
  methods CONVERT_COLUMN_INDEX
    importing
      value(IV_COL_INT) type INT4
    returning
      value(RV_COL_CHAR) type STRING .
  methods CONVERT_DATA
    importing
      value(IV_TYPE) type C
      value(IV_DATA) type DATA
      value(IV_CONVEXIT) type CONVEXIT optional
    exporting
      value(EO_EXCEP) type ref to CX_ROOT
    changing
      value(CV_DATA) type DATA .
  methods CONVERT_TO_INTERNAL_TABLE
    importing
      value(IB_CLIENT_SPECIFIED) type BOOLEAN default SPACE
      value(IB_DO_CONVEXIT) type BOOLEAN default SPACE
    exporting
      !ET_TABLE type STANDARD TABLE
      !ET_CONV_ERRORS type ZCA_EXCEL_ERROR_TAB
    exceptions
      NO_UPLOADED_DATA
      COULD_NOT_DETERMINE_TARGET .
  methods CREATE_DOWNLOAD_SHEET
    importing
      value(IV_STRUCTURE) type STRUKNAME
    exceptions
      INTERFACE_UNAVAILABLE .
  methods FORMAT_INTERNAL_RANGES .
  methods HANDLE_ERROR
    importing
      value(IO_ERROR) type ref to I_OI_ERROR
    returning
      value(RV_SUBRC) type SY-SUBRC .
  methods IMPORT_SPREADSHEET_DATA
    importing
      value(IV_FILE_URL) type C optional
    exceptions
      FILE_NOT_FOUND
      INTERFACE_UNAVAILABLE
      INVALID_EXCEL_DOCUMENT .
  methods INSERT_DATA_INTERVAL_RANGES
    importing
      value(IS_HEADER_DATA) type TS_HEADER_DATA .
  methods SAVE_SHEET
    importing
      value(IV_FILENAME) type STRING
    exporting
      !EV_FILE_URL type C .
  methods UPDATE_PROGRESS
    importing
      value(IV_TEXT) type C .
ENDCLASS.



CLASS ZCL_CA_EXCEL_CUSTOM IMPLEMENTATION.


method BUILD_INTERNAL_RANGES .

  data:
    ls_range     type soi_full_range_item,
    ls_rangelist type SOI_RANGE_ITEM.

  update_progress( text-m03 ).

*// Build the HEADER ranges
  ls_range-name    = gc_range_head.
  ls_range-top     = gc_range_bounds-top_head.
  ls_range-left    = gc_range_bounds-left_head.
  ls_range-rows    = gc_range_bounds-rows_head.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.

*// Build the DUMMY ranges
  ls_range-name    = gc_range_dummy.
  ls_range-top     = gc_range_bounds-top_dummy.
  ls_range-left    = gc_range_bounds-left_dummy.
  ls_range-rows    = gc_range_bounds-rows_dummy.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.

*// Build the COLUMNS range
  ls_range-name    = gc_range_cols.
  ls_range-top     = gc_range_bounds-top_cols.
  ls_range-left    = gc_range_bounds-left_cols.
  ls_range-rows    = gc_range_bounds-rows_cols.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.

*// Build the DATA range
  ls_range-name    = gc_range_data.
  ls_range-top     = gc_range_bounds-top_data.
  ls_range-left    = gc_range_bounds-left_data.
  ls_range-rows    = gc_range_bounds-rows_data.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.

*// Build the DEAD range
  ls_range-name    = gc_range_dead.
  ls_range-top     = gc_range_bounds-top_dead.
  ls_range-left    = iv_max_cols + 1.
  ls_range-rows    = gc_range_bounds-rows_dead.
  ls_range-columns = gc_range_bounds-cols_dead.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.

*// Build the STRUCTURE description range
  ls_range-name    = gc_range_struc.
  ls_range-top     = gc_range_bounds-top_struc.
  ls_range-left    = gc_range_bounds-left_struc.
  ls_range-rows    = gc_range_bounds-rows_struc.
  ls_range-columns = gc_range_bounds-cols_struc.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_struc.
  ls_rangelist-rows    = gc_range_bounds-rows_struc.
  ls_rangelist-columns = gc_range_bounds-cols_struc.
  append ls_rangelist to es_header_data-rang_struc[].

*// Build the STRUCTURE DESCR range
  ls_range-name    = gc_range_strucdescr.
  ls_range-top     = gc_range_bounds-top_sdesc.
  ls_range-left    = gc_range_bounds-left_sdesc.
  ls_range-rows    = gc_range_bounds-rows_sdesc.
  ls_range-columns = gc_range_bounds-cols_sdesc.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_strucdescr.
  ls_rangelist-rows    = gc_range_bounds-rows_sdesc.
  ls_rangelist-columns = gc_range_bounds-cols_sdesc.
  append ls_rangelist to es_header_data-rang_sdesc[].

*// Build the FIELD range
  ls_range-name    = gc_range_fields.
  ls_range-top     = gc_range_bounds-top_field.
  ls_range-left    = gc_range_bounds-left_field.
  ls_range-rows    = gc_range_bounds-rows_field.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_fields.
  ls_rangelist-rows    = gc_range_bounds-rows_field.
  ls_rangelist-columns = iv_max_cols.
  append ls_rangelist to es_header_data-rang_field[].

*// Build the DESCRIPTION range
  ls_range-name    = gc_range_descr.
  ls_range-top     = gc_range_bounds-top_descr.
  ls_range-left    = gc_range_bounds-left_descr.
  ls_range-rows    = gc_range_bounds-rows_descr.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_descr.
  ls_rangelist-rows    = gc_range_bounds-rows_descr.
  ls_rangelist-columns = iv_max_cols.
  append ls_rangelist to es_header_data-rang_descr[].

*// Build the ATTRIBUTES range
  ls_range-name    = gc_range_attr.
  ls_range-top     = gc_range_bounds-top_attr.
  ls_range-left    = gc_range_bounds-left_attr.
  ls_range-rows    = gc_range_bounds-rows_attr.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_attr.
  ls_rangelist-rows    = gc_range_bounds-rows_attr.
  ls_rangelist-columns = iv_max_cols.
  append ls_rangelist to es_header_data-rang_attr[].

*// Build the TECHNICAL range
  ls_range-name    = gc_range_tech.
  ls_range-top     = gc_range_bounds-top_tech.
  ls_range-left    = gc_range_bounds-left_tech.
  ls_range-rows    = gc_range_bounds-rows_tech.
  ls_range-columns = iv_max_cols.
  ls_range-sheet   = iv_structure.
  append ls_range to et_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_tech.
  ls_rangelist-rows    = gc_range_bounds-rows_tech.
  ls_rangelist-columns = iv_max_cols.
  append ls_rangelist to es_header_data-rang_tech[].

endmethod.


method CONSTRUCTOR .

  data:
    lv_available type i,
    lv_subrc     type sy-tabix.

*// Get the office integration control container
  CALL METHOD C_OI_CONTAINER_CONTROL_CREATOR=>GET_CONTAINER_CONTROL
    IMPORTING
      CONTROL = go_control
      ERROR   = go_error.

  lv_subrc = handle_error( go_error ).

*// Create a dummy GUI control container to hold the OI control. This
*// container is NOT tied to a screen component, therefore the 'CONTAINER'
*// reference below is a dummy container name
  CREATE OBJECT GO_CONTAINER
    EXPORTING
      CONTAINER_NAME              = 'CONTAINER'
    EXCEPTIONS
      CNTL_ERROR                  = 1
      CNTL_SYSTEM_ERROR           = 2
      CREATE_ERROR                = 3
      LIFETIME_ERROR              = 4
      LIFETIME_DYNPRO_DYNPRO_LINK = 5
      others                      = 6.

  IF SY-SUBRC <> 0.
    raise not_initialized.
  ENDIF.

*// Set the IO control in the GUI container and initialize
  CALL METHOD GO_CONTROL->INIT_CONTROL
    EXPORTING
      INPLACE_ENABLED          = gc_inplace
      INPLACE_SCROLL_DOCUMENTS = abap_true
      NO_FLUSH                 = abap_true
      R3_APPLICATION_NAME      = 'Basis'
      REGISTER_ON_CLOSE_EVENT  = abap_true
      REGISTER_ON_CUSTOM_EVENT = abap_true
      PARENT                   = GO_CONTAINER
    IMPORTING
      ERROR                    = GO_ERROR
    EXCEPTIONS
      JAVABEANNOTSUPPORTED     = 1
      others                   = 2.

  IF SY-SUBRC <> 0.
    raise not_initialized.
  ENDIF.

  lv_subrc = handle_error( go_error ).

*// Get a document proxy
  CALL METHOD GO_CONTROL->GET_DOCUMENT_PROXY
    EXPORTING
      DOCUMENT_TYPE      = SOI_DOCTYPE_EXCEL97_SHEET
    IMPORTING
      DOCUMENT_PROXY     = go_document
      ERROR              = go_error.

  lv_subrc = handle_error( go_error ).

*// Determine if there is a spreadsheet interface
  CALL METHOD GO_DOCUMENT->HAS_SPREADSHEET_INTERFACE
    IMPORTING
      IS_AVAILABLE = lv_available.

endmethod.


method CONVERT_COLUMN_INDEX .

  CONSTANTS:
    lc_alpha   type c value 'A',
    lc_letters type i value 26.

  DATA:
    lv_col_char type c,
    lv_col_int  TYPE i,
    lv_column   TYPE STRING.

  FIELD-SYMBOLS:
    <lf_hex>  TYPE X.

  IF iv_col_int > lc_letters.
    lv_col_int = iv_col_int div lc_letters.
    lv_col_char = lc_alpha.
    assign lv_col_char to <lf_hex> casting.
    <lf_hex> = <lf_hex> + lv_col_int - 1.
    concatenate lv_column lv_col_char into lv_column.
  endif.

  lv_col_int = iv_col_int mod lc_letters.
  if lv_col_int = 0.
    lv_col_int = lc_letters.
  endif.
  lv_col_char = lc_alpha.
  assign lv_col_char to <lf_hex> casting.
  <lf_hex> = <lf_hex> + lv_col_int - 1.
  concatenate lv_column lv_col_char into lv_column.
  rv_col_char = lv_column.

endmethod.


method CONVERT_DATA .

  CONSTANTS:
    lc_div_comma type char1 value ',',
    lc_div_date  type char1 value '/',
    lc_div_time  type char1 value ':',
    lc_null      type char1 value ''.

  TYPES:
    BEGIN OF TS_DATE,
      month type char2,
      day   type char2,
      year  type char4,
      hour  type char2,
      min   type char2,
      sec   type char2,
    END OF TS_DATE.

  DATA:
    ls_date   type ts_date,
    lv_date   type sydatum,
    lv_string type string,
    lv_time   type syuzeit,
    lv_func   type string.

  TRY.

  CASE iv_type.

*// Integers ----------------------------------------------------------*
    WHEN cl_abap_typedescr=>typekind_int  or
         cl_abap_typedescr=>typekind_int1 or
         cl_abap_typedescr=>typekind_int2.

      cv_data = iv_Data.

*// Dates -------------------------------------------------------------*
    WHEN cl_abap_typedescr=>typekind_date.

*//   Check for mm/dd/yyyy format and convert to yyyymmdd format
      IF iv_data CS lc_div_date.
        if strlen( iv_data ) = 10.
          split iv_data at lc_div_date into ls_date-month ls_date-day ls_date-year.
          concatenate ls_date-year ls_date-month ls_date-day into lv_date.
        elseif strlen( iv_data ) = 8.
          ls_date-year = sy-datum.
          split iv_data at lc_div_date into ls_date-month ls_date-day ls_date-year+02(02).
          concatenate ls_date-year ls_date-month ls_date-day into lv_date.
        endif.
      else.
        lv_date = iv_data.
      ENDIF.

*//   Is the date plausible in SAP?
      CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
        EXPORTING
          DATE                            = lv_date
        EXCEPTIONS
          PLAUSIBILITY_CHECK_FAILED       = 1
          OTHERS                          = 2.

      IF SY-SUBRC <> 0 and lv_date is not initial.
        lv_String = iv_Data.
        RAISE EXCEPTION TYPE CX_SY_CONVERSION_NO_DATE_TIME
          EXPORTING
            VALUE  = lv_string.
      else.
        cv_data = lv_date.
      ENDIF.

*// Times -------------------------------------------------------------*
    WHEN cl_abap_typedescr=>typekind_time.

      if iv_data cs lc_div_time.
        split iv_data at lc_div_time into ls_date-hour ls_date-min ls_date-sec.
        concatenate ls_date-hour ls_date-min ls_date-sec into lv_time.
      else.
        lv_time = iv_data.
      endif.

*//   Is the time plausible in SAP?
      CALL FUNCTION 'TIME_CHECK_PLAUSIBILITY'
        EXPORTING
          TIME                            = lv_time
        EXCEPTIONS
          PLAUSIBILITY_CHECK_FAILED       = 1
          OTHERS                          = 2.

      IF SY-SUBRC <> 0 and lv_time is not initial.
        lv_string = iv_data.
        RAISE EXCEPTION TYPE CX_SY_CONVERSION_NO_DATE_TIME
          EXPORTING
            VALUE  = lv_string.
      ELSE.
        cv_data = lv_time.
      ENDIF.

*// Packed numbers ----------------------------------------------------*
    WHEN cl_abap_typedescr=>typekind_packed OR
         cl_abap_typedescr=>typekind_float.

      lv_String = iv_data.
      TRY.
        move lv_string to cv_data.
      CATCH CX_SY_CONVERSION_NO_NUMBER.
        replace all occurrences of lc_div_comma in lv_string with lc_null.
        condense lv_string no-gaps.
        move lv_string to cv_data.
      ENDTRY.

*// Others ------------------------------------------------------------*
    WHEN others.

      lv_String = iv_data.
      TRY.
        move lv_string to cv_data.
      CATCH CX_SY_CONVERSION_NO_NUMBER.
        replace all occurrences of lc_div_comma in lv_string with lc_null.
        condense lv_string no-gaps.
        move lv_string to cv_data.
      ENDTRY.

  ENDCASE.

* if conversion exit is given, then call function module
  IF iv_convexit IS NOT INITIAL.

    CONCATENATE 'CONVERSION_EXIT_' iv_convexit '_INPUT'
      INTO lv_func.

    CALL FUNCTION lv_func
      EXPORTING
        INPUT         = cv_data
      IMPORTING
        OUTPUT        = cv_data.

  ENDIF.

  CATCH CX_ROOT INTO eo_excep.
    RETURN.
  ENDTRY.

endmethod.


method CONVERT_TO_INTERNAL_TABLE .

  data:
    lb_has_mandt type boolean,
    lv_max_cols  type i,
    ls_coor      type ts_coordinates,
    ls_err       type zca_excel_error_str,
    lo_excep     type ref to cx_root,
    lo_struc     type ref to cl_abap_structdescr,
    lo_table     type ref to CL_ABAP_TABLEDESCR,
    lo_tabline   type ref to data,
    lo_type      type ref to cl_abap_typedescr,
    lt_ddic      type DD_X031L_TABLE,
    lv_convexit  type convexit.

  field-symbols:
    <ls_comp>    type abap_compdescr,
    <ls_cont>    type SOI_GENERIC_ITEM,
    <ls_cont2>   type SOI_GENERIC_ITEM,
    <ls_data>    type any,
    <ls_tabline> type any,
    <ls_ddic>    type X031L.

*// Make sure data were uploaded
  if gt_contents[] is initial.
    raise no_uploaded_Data.
  endif.

  sort gt_contents[] by row column.

  clear et_conv_errors[].

*// Get a reference to the exporting table's structure
  create data lo_tabline like line of et_table.
  assign lo_tabline->* to <ls_tabline>.

*// Try to get the components of the exporting table using RTTI
  try.

    lo_type  = CL_ABAP_STRUCTDESCR=>DESCRIBE_BY_DATA( et_table[] ).
    lo_table ?= lo_type.
    lo_type  = lo_table->get_table_line_type( ).
    lo_struc ?= lo_type.
    lt_ddic  = lo_struc->get_ddic_object( ).
    sort lt_ddic by FIELDNAME.

  catch cx_root into lo_excep.
    raise could_not_determine_target.

  endtry.

*// Get the maximum number of columns allowed
  describe table lo_struc->components[] lines lv_max_cols.

  update_progress( text-m04 ).

*// Loop at the tabe contents to get the current ROW
  loop at gt_contents
    assigning <ls_cont>.

*// Check for a new table row
    check ls_coor-row_int <> <ls_cont>-row.
    ls_coor-row_int  = <ls_cont>-row.

*// Iterate throught the table structure and assign values
    loop at lo_struc->components[]
      assigning <ls_comp>.

*//   Use the column pointer to determine the target field
      assign component sy-tabix of structure <ls_tabline> to <ls_data>.
      check sy-subrc = 0.

*//   Collect the table column pointer
      ls_coor-col_int = sy-tabix.
      if ib_client_specified is initial.
        if <ls_comp>-name = 'MANDT'.
          lb_has_mandt = abap_true.
          continue.
        elseif lb_has_mandt = abap_true.
          ls_coor-col_int = ls_coor-col_int - 1.
        endif.
      endif.

      write ls_coor-col_int to ls_coor-col_char left-justified.
      write ls_coor-row_int to ls_coor-row_char left-justified.

*//   Read the extacted Excel data and move the data
      read table gt_contents
        assigning <ls_cont2>
        with key row    = ls_coor-row_char
                 column = ls_coor-col_char
        binary search.

      check sy-subrc = 0.

      check <ls_cont2> is assigned.

*//   get dictionary info to do conversion exit for component
      IF ib_do_convexit IS NOT INITIAL.
        read table lt_ddic assigning <ls_ddic>
                           with key FIELDNAME = <ls_comp>-NAME
                           binary search.
        IF sy-subrc = 0.
          lv_convexit = <ls_ddic>-CONVEXIT.
        ENDIF.
      ENDIF.

*//   Protect the conversion from exceptions
      try.

        CALL METHOD CONVERT_DATA
          EXPORTING
            IV_DATA     = <ls_cont2>-value
            IV_TYPE     = <ls_comp>-type_kind
            IV_CONVEXIT = lv_convexit
          IMPORTING
            EO_EXCEP  = lo_excep
          CHANGING
            CV_DATA   = <ls_data>.

*//   Handle the exception from the previous call
      if lo_excep is not initial.
        ls_err-err_row    = ls_coor-row_int + gc_range_bounds-top_data - 1.
        ls_err-err_column = <ls_comp>-name.
        ls_err-err_except = lo_excep->get_text( ).
        append ls_err to et_conv_errors[].
        clear ls_err.
      endif.

      catch cx_root into lo_excep.

        WHILE lo_excep->PREVIOUS is not initial.
          ls_err-err_row    = ls_coor-row_int + gc_range_bounds-top_data - 1.
          ls_err-err_column = <ls_comp>-name.
          ls_err-err_except = lo_excep->get_text( ).
          append ls_err to et_conv_errors[].
          clear ls_err.
          lo_excep = lo_excep->PREVIOUS.
        endwhile.
        ls_err-err_row    = ls_coor-row_int + gc_range_bounds-top_data - 1.
        ls_err-err_column = <ls_comp>-name.
        ls_err-err_except = lo_excep->get_text( ).
        append ls_err to et_conv_errors[].
        clear ls_err.

      endtry.

      unassign <ls_cont2>.

    endloop.

*// Append the entire line to the exporting table
    if <ls_tabline> is assigned.
      append <ls_tabline> to et_table[].
      clear <ls_tabline>.
    endif.

  endloop.

endmethod.


method CREATE_DOWNLOAD_SHEET .

  data:
    lv_active    type char120,
    lv_available type i,
    lv_open      type i,
    lv_subrc     type sy-subrc.

*// See if the document is already open
  CALL METHOD GO_DOCUMENT->IS_OPEN
    IMPORTING
      RET_VALUE = lv_open.

*// Create the document if not already open
  if lv_open is initial.
    GO_DOCUMENT->CLOSE_DOCUMENT( ).
  endif.

  update_progress( text-m07 ).

*// Create an Excel document
  CALL METHOD GO_DOCUMENT->CREATE_DOCUMENT
    EXPORTING
      DOCUMENT_TITLE   = 'TEST'
      NO_FLUSH         = abap_false
      OPEN_INPLACE     = gc_inplace
    IMPORTING
      ERROR            = go_error.

  lv_subrc = handle_error( go_error ).

*// Determine if there is a spreadsheet interface
  CALL METHOD GO_DOCUMENT->HAS_SPREADSHEET_INTERFACE
    IMPORTING
      IS_AVAILABLE = lv_available.

*// If there is no spreadsheet interface, exit the method
  if lv_available is initial.
    raise interface_unavailable.
  endif.

*// Get the spreadsheet interface
  CALL METHOD GO_DOCUMENT->GET_SPREADSHEET_INTERFACE
    EXPORTING
      NO_FLUSH        = abap_true
    IMPORTING
      ERROR           = go_error
      SHEET_INTERFACE = go_sheet.

  lv_subrc = handle_error( go_error ).

*// Get the active sheet name
  CALL METHOD GO_SHEET->GET_ACTIVE_SHEET
    IMPORTING
      SHEETNAME = lv_active
      ERROR     = go_error.

*// Set the sheet name to the structure name passed
  CALL METHOD GO_SHEET->SET_SHEET_NAME
    EXPORTING
      NEWNAME  = iv_structure
      OLDNAME  = lv_active
      NO_FLUSH = abap_false
    IMPORTING
      ERROR    = go_error.

  lv_subrc = handle_error( go_error ).

endmethod.


method EXPORT_TEMPLATE_AND_DATA .

  data:
    lb_has_mandt type boolean,
    lv_filename  type string,
    lv_max_cols  type i,
    lv_structure type STRUKNAME,
    lv_subrc     type sy-subrc,
    lv_tabix     type sy-tabix,
    ls_coor      type ts_coordinates,
    ls_cont      type SOI_GENERIC_ITEM,
    ls_err       type ZCA_EXCEL_ERROR_STR,
    ls_head_data type soi_generic_item,
    ls_head      type TS_HEADER_DATA,
    ls_range     type soi_full_range_item,
    ls_rangelist type SOI_RANGE_ITEM,
    ls_struc     type X030L,
    ls_table     type DD02V,
    lt_fields    type DDFIELDS,
    lt_ranges    type SOI_FULL_RANGE_TABLE,
    lo_excep     type ref to cx_root,
    lo_struc     type ref to cl_abap_structdescr,
    lo_table     type ref to CL_ABAP_TABLEDESCR,
    lo_tabline   type ref to data,
    lo_type      type ref to cl_abap_typedescr,
    lt_ddic      type DDFIELDS,
    lv_convexit  type char7.

  field-symbols:
    <ls_comp>    type abap_compdescr,
    <ls_data>    type any,
    <ls_dfies>   type DFIES,
    <ls_tabline> type any.

*// Clear the contents table
  clear gt_contents[].
  clear et_conv_errors[].

*// Get a reference to the exporting table's structure
  create data lo_tabline like line of it_abap_data.
  assign lo_tabline->* to <ls_tabline>.

*// Try to get the components of the exporting table using RTTI
  try.

    lo_type  =  CL_ABAP_STRUCTDESCR=>DESCRIBE_BY_DATA( it_abap_data[] ).
    lo_table ?= lo_type.
    lo_type  =  lo_table->get_table_line_type( ).
    lo_struc ?= lo_type.

  catch cx_root into lo_excep.
    raise could_not_determine_source_str.

  endtry.

*// Get the dictionary info about the structure
  ls_struc = lo_struc->GET_DDIC_HEADER( ).
  lt_ddic  = lo_struc->GET_DDIC_FIELD_LIST( ).
  SORT lt_ddic BY FIELDNAME.

*// Get the structure name
  lv_structure = ls_struc-tabname.

  loop at it_abap_data
    assigning <ls_tabline>.

    ls_coor-row_int = sy-tabix.

*// Iterate throught the table structure and assign values
    loop at lo_struc->components[]
      assigning <ls_comp>.

      ls_coor-col_int = lv_tabix = sy-tabix.
      if ib_client_specified is initial.
        if <ls_comp>-name = 'MANDT'.
          lb_has_mandt = abap_true.
          continue.
        elseif lb_has_mandt = abap_true.
          ls_coor-col_int = ls_coor-col_int - 1.
        endif.
      endif.

*//   Use the column pointer to determine the target field
      assign component lv_tabix of structure <ls_tabline> to <ls_data>.
      check sy-subrc = 0.

*//   Check for conversion exit
      READ TABLE lt_ddic ASSIGNING <ls_dfies>
        WITH KEY FIELDNAME = <ls_comp>-name
        BINARY SEARCH.
      CHECK sy-subrc = 0.

*//   Protect the conversion from exceptions
      try.

      ls_cont-row    = ls_coor-row_int.
      ls_cont-column = ls_coor-col_int.
      IF <ls_dfies>-convexit IS INITIAL.
        ls_cont-value  = <ls_data>.
      ELSE.
        CONCATENATE '==' <ls_dfies>-convexit INTO lv_convexit.
        write <ls_data> TO ls_cont-value
          USING EDIT MASK lv_convexit.
      ENDIF.
      shift ls_cont-value left deleting leading space.
      append ls_cont to gt_contents[].

      catch cx_root into lo_excep.
        ls_err-err_row    = ls_coor-row_int.
        ls_err-err_column = ls_coor-col_int.
        ls_err-err_except = lo_excep->get_text( ).
        append ls_err to et_conv_errors[].
        clear ls_err.

      endtry.

    endloop.

  endloop.

*// Get the table name
  CALL FUNCTION 'DDIF_TABL_GET'
    EXPORTING
      NAME                = lv_structure
      LANGU               = sy-langu
    IMPORTING
      DD02V_WA            = ls_table
    EXCEPTIONS
      ILLEGAL_INPUT       = 1
      OTHERS              = 2.

  IF SY-SUBRC <> 0.
    raise could_not_determine_source_str.
  ENDIF.

*// Build the HEAD range data for structure
  ls_head_data-row    = 1.
  ls_head_data-column = 1.
  ls_head_data-value  = lv_structure.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.
  ls_head_data-row    = 1.
  ls_head_data-column = 2.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.
  ls_head_data-row    = 1.
  ls_head_data-column = 3.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.

*// Build the structure description table
  ls_head_data-row    = 1.
  ls_head_data-column = 1.
  ls_head_data-value  = ls_table-ddtext.
  append ls_head_data to ls_head-data_sdesc[].
  clear ls_head_data.

*// Get the strcutre components of the importing table to build
*// the spreadsheet
  lt_fields[] = lo_struc->GET_DDIC_FIELD_LIST( ).

  if lt_fields[] is initial.
    raise could_not_determine_source_str.
  endif.

*// Remove the system field if not requested
  if ib_client_specified is initial.
    delete lt_fields[] where fieldname = 'MANDT'.
    if sy-subrc = 0 and ls_struc-KEYCNT > 0.
      ls_struc-KEYCNT = ls_struc-KEYCNT - 1.
    endif.
  endif.

*// Get the maximum number of columns
  describe table lt_fields lines lv_max_cols.

*// Build the field name titles and descriptions
  loop at lt_fields
    assigning <ls_dfies>.

*// Build the fieldname
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    ls_head_data-value  = <ls_dfies>-fieldname.
    append ls_head_data to ls_head-data_field[].
    clear ls_head_data.

*// Build the data attributes
    if <ls_dfies>-inttype = 'g'.
*//   For String types, make the fields artificially large
      ls_head_data-row    = 1.
      ls_head_data-column = sy-tabix.
      ls_head_data-value  = ZCA01_DIV03.
    else.
      ls_head_data-row    = 1.
      ls_head_data-column = sy-tabix.
      ls_head_data-value  = <ls_dfies>-rollname.
    endif.
    append ls_head_data to ls_head-data_tech[].
    clear ls_head_data.

*// Build the technical names
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    concatenate <ls_dfies>-datatype <ls_dfies>-leng
      into ls_head_data-value separated by space.
    append ls_head_data to ls_head-data_attr[].
    clear ls_head_data.

*// Build the field descriptions
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    ls_head_data-value  = <ls_dfies>-scrtext_m.
    IF ls_head_data-value IS INITIAL.
      ls_head_data-value = <ls_dfies>-FIELDTEXT.
    ENDIF.
    append ls_head_data to ls_head-data_descr[].
    clear ls_head_data.

  endloop.

*// OPEN THE SHEET ////////////////////////////////////////////////////*
  replace all occurrences of '/' in lv_structure with ''.

  CALL METHOD CREATE_DOWNLOAD_SHEET
    EXPORTING
      IV_STRUCTURE          = lv_structure
    EXCEPTIONS
      INTERFACE_UNAVAILABLE = 1
      others                = 2.

  IF SY-SUBRC <> 0.
    raise interface_unavailable.
  ENDIF.

*// SET RANGES ////////////////////////////////////////////////////////*

*// Build the standard Ranges
  CALL METHOD BUILD_INTERNAL_RANGES
    EXPORTING
      IV_MAX_COLS    = lv_max_cols
      IV_STRUCTURE   = lv_structure
    IMPORTING
      ET_RANGES      = lt_ranges[]
      ES_HEADER_DATA = ls_head.

*// Build the KEY range
  if ls_struc-KEYCNT > 0.
    ls_range-name    = gc_range_key.
    ls_range-top     = gc_range_bounds-top_key.
    ls_range-left    = gc_range_bounds-left_key.
    ls_range-rows    = gc_range_bounds-rows_data.
    ls_range-columns = ls_struc-KEYCNT.
    ls_range-sheet   = lv_structure.
    append ls_range to lt_ranges[].
    clear ls_range.
  endif.

*// Build the DOWNLOADABLE data range
  describe table gt_contents[] lines sy-tfill.
  ls_range-name    = gc_range_download.
  ls_range-top     = gc_range_bounds-top_down.
  ls_range-left    = gc_range_bounds-left_down.
  ls_range-rows    = sy-tfill / lv_max_cols.
  ls_range-columns = lv_max_cols.
  ls_range-sheet   = lv_structure.
  append ls_range to lt_ranges[].
  clear ls_range.
  ls_rangelist-name    = gc_range_download.
  ls_rangelist-rows    = sy-tfill / lv_max_cols.
  ls_rangelist-columns = lv_max_cols.
  append ls_rangelist to ls_head-rang_down[].
  append lines of gt_contents[] to ls_head-data_down[].

*// Build the Col Width Optimaztion range
  describe table gt_contents[] lines sy-tfill.
  ls_range-name    = gc_range_width.
  ls_range-top     = gc_range_bounds-top_cols.
  ls_range-left    = gc_range_bounds-left_cols.
  ls_range-rows    = gc_range_bounds-rows_cols + sy-tfill / lv_max_cols.
  ls_range-columns = lv_max_cols.
  ls_range-sheet   = lv_structure.
  append ls_range to lt_ranges[].

*// Insert the ranges into the current sheet
  CALL METHOD GO_SHEET->INSERT_RANGES
    EXPORTING
      NO_FLUSH = abap_false
      RANGES   = lt_ranges[]
    IMPORTING
      ERROR    = go_error.

  lv_subrc = handle_error( go_error ).

*// FORMAT THE RANGES /////////////////////////////////////////////////*

  format_internal_ranges( ).

  if ls_struc-KEYCNT > 0.
    CALL METHOD GO_SHEET->SET_COLOR
      EXPORTING
        RANGENAME = gc_range_key
        FRONT     = 1
        NO_FLUSH  = abap_false
        BACK      = 37
      IMPORTING
        ERROR     = go_error.
  endif.

*// SET THE DATA TO THE RANGES ////////////////////////////////////////*

  insert_data_interval_ranges( ls_head ).

*// SAVE THE SHEET ////////////////////////////////////////////////////*

  if iv_file_name is not initial.
    lv_filename = iv_file_name.
  else.
    lv_filename = lv_structure.
  endif.

  save_sheet( exporting iv_filename = lv_filename
              importing ev_file_url = ev_file_url ).

  replace GC_FILE_PREFIX in EV_FILE_URL with ''.
  replace all OCCURRENCES of '/' in EV_FILE_URL with '\'.

*// Close the spreadsheet
  GO_DOCUMENT->CLOSE_DOCUMENT( ).

endmethod.


method EXPORT_TEMPLATE_CUSTOM .

  data:
    lv_filename  type string,
    lv_structure type strukname,
    lv_key_cols  type i,
    lv_max_cols  type i,
    lv_subrc     type sy-subrc,
    lv_tabname   type DDOBJNAME,
    ls_head_data type soi_generic_item,
    ls_head      type TS_HEADER_DATA,
    ls_range     type soi_full_range_item,
    ls_table     type DD02V,
    lt_dfies     type DDFIELDS,
    lt_ranges    type SOI_FULL_RANGE_TABLE,
    it_zmmfld    type standard table of zmmfld,
    ls_zmmfld    type zmmfld,
    lv_tabix     type char20,
    lv_key1      type char20.

  field-symbols:
    <ls_dfies> type DFIES.

  lv_tabname = iv_structure.

  update_progress( text-m05 ).

*// Make sure the structure exists in this system
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      TABNAME        = lv_tabname
    TABLES
      DFIES_TAB      = lt_dfies[]
    EXCEPTIONS
      NOT_FOUND      = 1
      INTERNAL_ERROR = 2
      OTHERS         = 3.

  IF SY-SUBRC <> 0.
    raise structure_not_found.
  ENDIF.

*// Remove the system field if not requested
  if ib_client_specified is initial.
    delete lt_dfies[] where fieldname = 'MANDT'.
  endif.

*// Get the table name
  CALL FUNCTION 'DDIF_TABL_GET'
    EXPORTING
      NAME          = lv_tabname
      LANGU         = sy-langu
    IMPORTING
      DD02V_WA      = ls_table
    EXCEPTIONS
      ILLEGAL_INPUT = 1
      OTHERS        = 2.

  IF SY-SUBRC <> 0.
    raise structure_not_found.
  ENDIF.

*// Get the maximum number of columns
  describe table lt_dfies lines lv_max_cols.

*// Build the HEAD range data for structure
  ls_head_data-row    = 1.
  ls_head_data-column = 1.
  ls_head_data-value  = iv_structure.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.
  ls_head_data-row    = 1.
  ls_head_data-column = 2.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.
  ls_head_data-row    = 1.
  ls_head_data-column = 3.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.

*// Build the structure description table
  ls_head_data-row    = 0.
  ls_head_data-column = 0.
  ls_head_data-value  = 'ZMC1969 - Purchase Info Record Creation'.
  append ls_head_data to ls_head-data_sdesc[].
  clear ls_head_data.

  lv_key1 = iv_structure.
  select * from zmmfld into table it_zmmfld where key1 = lv_key1.
  sort it_zmmfld by key1 key2.
*// Build the field name titles and descriptions
  loop at lt_dfies
    assigning <ls_dfies>.

    lv_tabix = sy-tabix.
    condense lv_tabix no-gaps.
    IF <ls_dfies>-KEYFLAG = abap_true.
      lv_key_cols = lv_key_cols + 1.
    ENDIF.

    read table it_zmmfld into ls_zmmfld
                         with key key1 = lv_key1
                                  key2 = lv_tabix
                         binary search.

*// Build the fieldname
    ls_head_data-row    = 1.
    ls_head_data-column = lv_tabix.
    ls_head_data-value  = ls_zmmfld-value1. "<ls_dfies>-fieldname.
    append ls_head_data to ls_head-data_descr[].
    clear ls_head_data.

*// Build the field descriptions
    ls_head_data-row    = 1.
    ls_head_data-column = lv_tabix.
    ls_head_data-value  = <ls_dfies>-fieldtext.
    append ls_head_data to ls_head-data_field[].
    clear ls_head_data.

*// Build the data attributes
    ls_head_data-row    = 1.
    ls_head_data-column = lv_tabix.
    ls_head_data-value  = <ls_dfies>-rollname.
    append ls_head_data to ls_head-data_tech[].
    clear ls_head_data.

*// Build the technical names
    ls_head_data-row    = 1.
    ls_head_data-column = lv_tabix.
    ls_head_data-value  = ls_zmmfld-value2.
    append ls_head_data to ls_head-data_attr[].
    clear ls_head_data.

  endloop.

*// CREATE DOCUMENT ///////////////////////////////////////////////////*

*// Open the Excel sheet document
  lv_structure = iv_structure.
  replace all occurrences of '/' in lv_structure with ''.

  CALL METHOD CREATE_DOWNLOAD_SHEET
    EXPORTING
      IV_STRUCTURE          = lv_structure
    EXCEPTIONS
      INTERFACE_UNAVAILABLE = 1
      others                = 2.

  IF SY-SUBRC <> 0.
    raise interface_unavailable.
  ENDIF.

*// DEFINE RANGES /////////////////////////////////////////////////////*

*// Build the standard ranges
  CALL METHOD BUILD_INTERNAL_RANGES
    EXPORTING
      IV_MAX_COLS    = lv_max_cols
      IV_STRUCTURE   = lv_structure
    IMPORTING
      ET_RANGES      = lt_ranges[]
      ES_HEADER_DATA = ls_head.

*// Build the KEY range
  if lv_key_cols > 0.
    ls_range-name    = gc_range_key.
    ls_range-top     = gc_range_bounds-top_key.
    ls_range-left    = gc_range_bounds-left_key.
    ls_range-rows    = gc_range_bounds-rows_data.
    ls_range-columns = lv_key_cols.
    ls_range-sheet   = lv_structure.
    append ls_range to lt_ranges[].
    clear ls_range.
  endif.

  delete lt_ranges where name = 'RANGE_STRUC'.

*// Insert the ranges into the current sheet
  CALL METHOD GO_SHEET->INSERT_RANGES
    EXPORTING
      NO_FLUSH = abap_false
      RANGES   = lt_ranges[]
    IMPORTING
      ERROR    = go_error.

  lv_subrc = handle_error( go_error ).

*// FORMAT THE RANGES /////////////////////////////////////////////////*

  format_internal_ranges( ).

*// SET THE DATA TO THE RANGES ////////////////////////////////////////*

  insert_data_interval_ranges( ls_head ).

*// SAVE THE SHEET ////////////////////////////////////////////////////*

  if iv_file_name is not initial.
    lv_filename = iv_file_name.
  else.
    lv_filename = lv_structure.
  endif.

  save_sheet( exporting IV_FILENAME = lv_filename
              importing EV_FILE_URL = ev_file_url ).

  replace GC_FILE_PREFIX in EV_FILE_URL with ''.
  replace all OCCURRENCES of '/' in EV_FILE_URL with '\'.

*// Close the spreadsheet
  GO_DOCUMENT->CLOSE_DOCUMENT( ).

endmethod.


method EXPORT_TEMPLATE_SPREADSHEET .

  data:
    lv_filename  type string,
    lv_structure type strukname,
    lv_key_cols  type i,
    lv_max_cols  type i,
    lv_subrc     type sy-subrc,
    lv_tabname   type DDOBJNAME,
    ls_head_data type soi_generic_item,
    ls_head      type TS_HEADER_DATA,
    ls_range     type soi_full_range_item,
    ls_table     type DD02V,
    lt_dfies     type DDFIELDS,
    lt_ranges    type SOI_FULL_RANGE_TABLE.

  field-symbols:
    <ls_dfies> type DFIES.

  lv_tabname = iv_structure.

  update_progress( text-m05 ).

*// Make sure the structure exists in this system
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      TABNAME              = lv_tabname
    TABLES
      DFIES_TAB            = lt_dfies[]
    EXCEPTIONS
      NOT_FOUND            = 1
      INTERNAL_ERROR       = 2
      OTHERS               = 3.

  IF SY-SUBRC <> 0.
    raise structure_not_found.
  ENDIF.

*// Remove the system field if not requested
  if ib_client_specified is initial.
    delete lt_dfies[] where fieldname = 'MANDT'.
  endif.

*// Get the table name
  CALL FUNCTION 'DDIF_TABL_GET'
    EXPORTING
      NAME                = lv_tabname
      LANGU               = sy-langu
    IMPORTING
      DD02V_WA            = ls_table
    EXCEPTIONS
      ILLEGAL_INPUT       = 1
      OTHERS              = 2.

  IF SY-SUBRC <> 0.
    raise structure_not_found.
  ENDIF.

*// Get the maximum number of columns
  describe table lt_dfies lines lv_max_cols.

*// Build the HEAD range data for structure
  ls_head_data-row    = 1.
  ls_head_data-column = 1.
  ls_head_data-value  = iv_structure.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.
  ls_head_data-row    = 1.
  ls_head_data-column = 2.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.
  ls_head_data-row    = 1.
  ls_head_data-column = 3.
  append ls_head_data to ls_head-data_struc[].
  clear ls_head_data.

*// Build the structure description table
  ls_head_data-row    = 1.
  ls_head_data-column = 1.
  ls_head_data-value  = ls_table-ddtext.
  append ls_head_data to ls_head-data_sdesc[].
  clear ls_head_data.

*// Build the field name titles and descriptions
  loop at lt_dfies
    assigning <ls_dfies>.

    IF <ls_dfies>-KEYFLAG = abap_true.
      lv_key_cols = lv_key_cols + 1.
    ENDIF.

*// Build the fieldname
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    ls_head_data-value  = <ls_dfies>-fieldname.
    append ls_head_data to ls_head-data_field[].
    clear ls_head_data.

*// Build the data attributes
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    ls_head_data-value  = <ls_dfies>-rollname.
    append ls_head_data to ls_head-data_tech[].
    clear ls_head_data.

*// Build the technical names
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    concatenate <ls_dfies>-datatype <ls_dfies>-leng
      into ls_head_data-value separated by space.
    append ls_head_data to ls_head-data_attr[].
    clear ls_head_data.

*// Build the field descriptions
    ls_head_data-row    = 1.
    ls_head_data-column = sy-tabix.
    ls_head_data-value  = <ls_dfies>-scrtext_m.
    append ls_head_data to ls_head-data_descr[].
    clear ls_head_data.

  endloop.

*// CREATE DOCUMENT ///////////////////////////////////////////////////*

*// Open the Excel sheet document
  lv_structure = iv_structure.
  replace all occurrences of '/' in lv_structure with ''.

  CALL METHOD CREATE_DOWNLOAD_SHEET
    EXPORTING
      IV_STRUCTURE          = lv_structure
    EXCEPTIONS
      INTERFACE_UNAVAILABLE = 1
      others                = 2.

  IF SY-SUBRC <> 0.
    raise interface_unavailable.
  ENDIF.

*// DEFINE RANGES /////////////////////////////////////////////////////*

*// Build the standard ranges
  CALL METHOD BUILD_INTERNAL_RANGES
    EXPORTING
      IV_MAX_COLS    = lv_max_cols
      IV_STRUCTURE   = lv_structure
    IMPORTING
      ET_RANGES      = lt_ranges[]
      ES_HEADER_DATA = ls_head.

*// Build the KEY range
  if lv_key_cols > 0.
    ls_range-name    = gc_range_key.
    ls_range-top     = gc_range_bounds-top_key.
    ls_range-left    = gc_range_bounds-left_key.
    ls_range-rows    = gc_range_bounds-rows_data.
    ls_range-columns = lv_key_cols.
    ls_range-sheet   = lv_structure.
    append ls_range to lt_ranges[].
    clear ls_range.
  endif.

*// Insert the ranges into the current sheet
  CALL METHOD GO_SHEET->INSERT_RANGES
    EXPORTING
      NO_FLUSH = abap_false
      RANGES   = lt_ranges[]
    IMPORTING
      ERROR    = go_error.

  lv_subrc = handle_error( go_error ).

*// FORMAT THE RANGES /////////////////////////////////////////////////*

  format_internal_ranges( ).

*// SET THE DATA TO THE RANGES ////////////////////////////////////////*

  insert_data_interval_ranges( ls_head ).

*// SAVE THE SHEET ////////////////////////////////////////////////////*

  if iv_file_name is not initial.
    lv_filename = iv_file_name.
  else.
    lv_filename = lv_structure.
  endif.

  save_sheet( exporting IV_FILENAME = lv_filename
              importing EV_FILE_URL = ev_file_url ).

  replace GC_FILE_PREFIX in EV_FILE_URL with ''.
  replace all OCCURRENCES of '/' in EV_FILE_URL with '\'.

*// Close the spreadsheet
  GO_DOCUMENT->CLOSE_DOCUMENT( ).

endmethod.


method FORMAT_INTERNAL_RANGES .

  update_progress( text-m08 ).

*// Set the colors
  CALL METHOD GO_SHEET->SET_COLOR
    EXPORTING
      RANGENAME = gc_range_head
      FRONT     = 1
      NO_FLUSH  = abap_false
      BACK      = 15
    IMPORTING
      ERROR     = go_error.

  CALL METHOD GO_SHEET->SET_COLOR
    EXPORTING
      RANGENAME = gc_range_dead
      FRONT     = 1
      NO_FLUSH  = abap_false
      BACK      = 15
    IMPORTING
      ERROR     = go_error.

   CALL METHOD GO_SHEET->SET_COLOR
    EXPORTING
      RANGENAME = gc_range_struc
      FRONT     = 1
      NO_FLUSH  = abap_false
      BACK      = 12
    IMPORTING
      ERROR     = go_error.

    CALL METHOD GO_SHEET->SET_COLOR
      EXPORTING
        RANGENAME = gc_range_key
        FRONT     = 1
        NO_FLUSH  = abap_false
        BACK      = 37
      IMPORTING
        ERROR     = go_error.

*// Set the frames
  CALL METHOD GO_SHEET->SET_FRAME
    EXPORTING
      RANGENAME = gc_range_head
      TYP       = 79
      COLOR     = 1
      NO_FLUSH  = abap_false
    IMPORTING
      ERROR     = go_error.

  CALL METHOD GO_SHEET->SET_FRAME
    EXPORTING
      RANGENAME = gc_range_data
      TYP       = 127
      COLOR     = 1
      NO_FLUSH  = abap_false
    IMPORTING
      ERROR     = go_error.

*// Set the STRUC Fonts
  CALL METHOD GO_SHEET->SET_FONT
    EXPORTING
      RANGENAME = gc_range_struc
      FAMILY    = space
      SIZE      = gc_font_head_large
      BOLD      = 1
      ITALIC    = 0
      ALIGN     = 0.

*// Set the FIELDS Fonts
  CALL METHOD GO_SHEET->SET_FONT
    EXPORTING
      RANGENAME = gc_range_fields
      FAMILY    = space
      SIZE      = gc_font_head_small
      BOLD      = 1
      ITALIC    = 0
      ALIGN     = 0.

*// Set the ATTRIBUTE Fonts
  CALL METHOD GO_SHEET->SET_FONT
    EXPORTING
      RANGENAME = gc_range_descr
      FAMILY    = space
      SIZE      = gc_font_head_small
      BOLD      = 0
      ITALIC    = 1
      ALIGN     = 0.

*// Set the ATTRIBUTE Fonts
  CALL METHOD GO_SHEET->SET_FONT
    EXPORTING
      RANGENAME = gc_range_attr
      FAMILY    = space
      SIZE      = gc_font_head_small
      BOLD      = 0
      ITALIC    = 1
      ALIGN     = 0.

*// Set the TECH Fonts
  CALL METHOD GO_SHEET->SET_FONT
    EXPORTING
      RANGENAME = gc_range_tech
      FAMILY    = space
      SIZE      = gc_font_head_small
      BOLD      = 0
      ITALIC    = 1
      ALIGN     = 0.

*// Set the data range to STRING data type
  CALL METHOD GO_SHEET->SET_FORMAT
    EXPORTING
      RANGENAME = gc_range_data
      TYP       = 0
      CURRENCY  = space.

*// Hide the TECHNICAL range
  CALL METHOD GO_SHEET->HIDE_ROWS
    EXPORTING
      NAME     = gc_range_tech.

*// Hide the DUMMY range
  CALL METHOD GO_SHEET->HIDE_ROWS
    EXPORTING
      NAME     = gc_range_dummy.

endmethod.


method FREE .

*// Clean up the document
  if not go_document is initial.
    go_document->close_document( ).
    free go_document.
  endif.

*// Destroy the control
  if not go_control is initial.
    go_control->destroy_control( ).
    free go_control.
  endif.

*// Destroy the container
  if not go_container is initial.
    go_container->free( ).
    free go_container.
  endif.

*// Destroy the error object
  free go_error.

endmethod.


method HANDLE_ERROR .

  constants:
    LC_FILEOPEN_MSGID type SY-MSGID value 'SOFFICEINTEGRATION',
    LC_FILEOPEN_MSGNO type SY-MSGNO value 153.

  data:
    LO_ERROR          TYPE REF TO cx_sy_file_open,
    lv_msgid          type sy-msgid,
    lv_msgno          type sy-msgno.

  rv_subrc = 0.

  check not io_error is initial.
  check not io_error->error_code = C_OI_ERRORS=>RET_OK.

*// see if error is for file not open
  call method io_error->get_message
    importing
      message_id     = lv_msgid
      message_number = lv_msgno.

*// replace obfuscated error message text
  if lv_msgid = lc_fileopen_msgid and lv_msgno = lc_fileopen_msgno.
    message e033.
    return.
  endif.

  append io_error to gt_errors[].

  rv_subrc = 1.
  io_error->raise_message( 'E' ).

endmethod.


method IMPORT_AND_CONVERT_DATA .

  EV_FIRST_DATA_ROW = gc_range_bounds-top_data.

*// Import spreadsheet data to the object
  CALL METHOD IMPORT_SPREADSHEET_DATA
    EXPORTING
      IV_FILE_URL            = iv_file_url
    EXCEPTIONS
      FILE_NOT_FOUND         = 1
      INTERFACE_UNAVAILABLE  = 2
      INVALID_EXCEL_DOCUMENT = 3
      others                 = 4.

  case sy-subrc.
    when 0.
    when 1.
      raise file_not_found.
    when 2.
      raise interface_unavailable.
    when 3.
      raise invalid_excel_document.
    when others.
      raise unknown_error.
  endcase.

*// Attempt to convert to an internal table
  CALL METHOD CONVERT_TO_INTERNAL_TABLE
    EXPORTING
      IB_CLIENT_SPECIFIED        = ib_client_specified
      IB_DO_CONVEXIT             = ib_do_convexit
    IMPORTING
      ET_TABLE                   = et_table[]
      ET_CONV_ERRORS             = et_conv_errors[]
    EXCEPTIONS
      NO_UPLOADED_DATA           = 1
      COULD_NOT_DETERMINE_TARGET = 2
      others                     = 3.

  case sy-subrc.
    when 0.
    when 1.
      raise no_uploaded_data.
    when 2.
      raise could_not_determine_target.
    when others.
      raise unknown_error.
  endcase.

endmethod.


method IMPORT_SPREADSHEET_DATA .

  data:
    lv_action    type i,
    lv_available type i,
    lv_desktop   type string,
    lv_filename  type LOCALFILE,
    lv_rc        type i,
    lv_row       type i,
    lv_row_old   type i,
    lv_row_start type i,
    lv_subrc     type sy-subrc,
    ls_area      type SOI_AREA_ITEM,
    ls_dim       type SOI_DIMENSION_ITEM,
    lt_areas     type SOI_AREA_TABLE,
    lt_contents  type SOI_GENERIC_TABLE,
    lt_dim       type SOI_DIMENSION_TABLE,
    lt_filetab   type FILETABLE,
    lt_ranges    type SOI_RANGE_LIST.

  field-symbols:
    <ls_cont> type SOI_GENERIC_ITEM.

  if not iv_file_url is initial.

*// Prepare the file name
    search iv_file_url for gc_file_prefix.
    if sy-subrc <> 0.
      concatenate gc_file_prefix iv_file_url into lv_filename.
    else.
      lv_filename = iv_file_url.
    endif.

    replace all OCCURRENCES of '\' in lv_filename with '/'.

  else.

*// Get the desktop directory
    CALL METHOD CL_GUI_FRONTEND_SERVICES=>GET_DESKTOP_DIRECTORY
      CHANGING
        DESKTOP_DIRECTORY    = lv_desktop.

*// Get the file from the client
    CALL METHOD CL_GUI_FRONTEND_SERVICES=>FILE_OPEN_DIALOG
      EXPORTING
        DEFAULT_EXTENSION       = 'XLS'
        FILE_FILTER             = gc_filter_excel
        MULTISELECTION          = abap_false
        INITIAL_DIRECTORY       = lv_desktop
      CHANGING
        FILE_TABLE              = lt_filetab[]
        RC                      = lv_rc
        USER_ACTION             = lv_action
      EXCEPTIONS
        FILE_OPEN_DIALOG_FAILED = 1
        CNTL_ERROR              = 2
        ERROR_NO_GUI            = 3
        NOT_SUPPORTED_BY_GUI    = 4
        others                  = 5.

    IF SY-SUBRC <> 0 or lv_action = cl_gui_frontend_services=>action_cancel.
      exit.
    ENDIF.

*// Get the selected file
    read table lt_filetab
      into lv_filename
      index 1.

*// Prepare the file name
    search lv_filename for gc_file_prefix.
    if sy-subrc <> 0.
      concatenate gc_file_prefix lv_filename into lv_filename.
    endif.
    replace all OCCURRENCES of '\' in lv_filename with '/'.

  endif.

*// Synchronize the frontend URLs
  CALL FUNCTION 'DP_SYNC_URLS'.

  update_progress( text-m00 ).

*// Open document in dark mode
  CALL METHOD GO_DOCUMENT->OPEN_DOCUMENT
    EXPORTING
      DOCUMENT_URL     = lv_filename
      OPEN_INPLACE     = gc_inplace
      open_readonly    = abaP_true
      NO_FLUSH         = abap_true
    IMPORTING
      ERROR            = go_error.

  lv_subrc = handle_error( go_error ).

*// Determine if there is a spreadsheet interface
  CALL METHOD GO_DOCUMENT->HAS_SPREADSHEET_INTERFACE
    IMPORTING
      IS_AVAILABLE = lv_available.

  if lv_available is initial.
    go_document->close_document( ).
    free go_document.
    raise interface_unavailable.
  endif.

*// Get the spreadsheet interface
  CALL METHOD GO_DOCUMENT->GET_SPREADSHEET_INTERFACE
    EXPORTING
      NO_FLUSH        = abap_true
    IMPORTING
      ERROR           = go_error
      SHEET_INTERFACE = go_sheet.

  lv_subrc = handle_error( go_error ).

  if lv_subrc <> 0.
    raise interface_unavailable.
  endif.

*// Find the names of the data ranges
    CALL METHOD GO_SHEET->GET_RANGES_NAMES
      EXPORTING
        NO_FLUSH = space
      IMPORTING
        ERROR    = go_error
        RANGES   = lt_ranges[].

  lv_subrc = handle_error( go_error ).

  sort lt_ranges by name.

*// Verify the DATA range exists (verify this is an acceptable
*// Excel spreadsheet). We verify that this is the correct spreadsheet
*// template by checking for the "RANGE_DATA" range. If we do not find
*// correct range name, we raise an exception
  read table lt_ranges
    transporting no fields
    with key name = gc_range_data
    binary search.

  if sy-subrc <> 0.
    raise invalid_excel_document.
  endif.

*// Select the data range
  CALL METHOD GO_SHEET->SELECT_RANGE
    EXPORTING
      RANGENAME = gc_range_data
    IMPORTING
      ERROR     = go_error.

  lv_subrc = handle_error( go_error ).

  update_progress( text-m01 ).

*// Get the selected range corridinates
  CALL METHOD GO_SHEET->GET_SELECTED_AREAS
    IMPORTING
      AREAS     = lt_areas[]
      ERROR     = go_error.

  lv_subrc = handle_error( go_error ).

*// Get the first area
  read table lt_areas
    into ls_area
    index 1.

  if sy-subrc <> 0.
    raise invalid_excel_document.
  endif.

*// Build the initial cell dimensions to read
  ls_dim-row     = ls_area-top.
  ls_dim-column  = ls_area-left.
  ls_dim-rows    = gc_packets.
  ls_dim-columns = ls_area-columns.
  append ls_dim to lt_dim[].

  lv_row_start = ls_area-top.

  update_progress( text-m02 ).

*// Data will be extracted out of the data range in "packets" to improve
*// efficiency. The data range may contain the entire sheet, which may
*// include a lot of null cell. We will extract the data by the full width
*// of the structure, but with a limited number of rows at a time (the
*// packet size is defined with the constant GC_PACKETS). After the
*// current packet has been extracted, we delete the null data entries
*// and check that data still exists, if not we exit the loop, otherwise
*// we build the next packet dimension to extract data. Eventually, all data
*// entries will be blank and we exit the DO loop. Although we will be deleting
*// NULL entries within the data range, our conversion routine will still
*// function properly by skipping the blank entries and leaving the
*// data to the ABAP initial value.
  do.

*// Get the first "packet" of data from the sheet
    CALL METHOD GO_SHEET->GET_RANGES_DATA
      EXPORTING
        RANGESDEF = lt_dim[]
      IMPORTING
        CONTENTS  = lt_contents[]
        ERROR     = go_error
      CHANGING
        RANGES    = lt_ranges[].

    lv_subrc = handle_error( go_error ).

*// Delete all NULL entries
    delete lt_contents
      where value is initial.

*// When there are no data left, we exit the DO loop
    if lt_contents is initial.
      exit.
    endif.

*// Append entries to the global table
    append lines of lt_contents to gt_contents.

    clear: lt_contents[], lt_dim[], ls_dim.

    lv_row_start = lv_row_start + gc_packets.

*// Build the next iteration of data
    ls_dim-row     = lv_row_start.
    ls_dim-column  = ls_area-left.
    ls_dim-rows    = gc_packets.
    ls_dim-columns = ls_area-columns.
    append ls_dim to lt_dim[].

  enddo.

*// Correct the row index in the contents table - selecting
*// by packets resets the row counter, therefore we must
*// set the row back to a linear progression
  loop at gt_contents
    assigning <ls_cont>.

    if lv_row_old <> <ls_cont>-row.
      lv_row = lv_row + 1.
      lv_row_old = <ls_cont>-row.
    endif.

    write lv_row to <ls_cont>-row left-justified.

  endloop.

endmethod.


method INSERT_DATA_INTERVAL_RANGES .

  data:
    lv_subrc type sy-subrc.

  update_progress( text-m09 ).

  if not is_header_data-rang_struc[] is initial.

*// Add the header ranges data to the spreadsheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_struc[]
        CONTENTS  = is_header_data-data_struc[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

  if not is_header_data-rang_sdesc[] is initial.

*// Add the header ranges description data to the spreadsheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_sdesc[]
        CONTENTS  = is_header_data-data_sdesc[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

  if not is_header_data-rang_field[] is initial.

*// Add the field descriptions to the sheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_field[]
        CONTENTS  = is_header_data-data_field[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

  if not is_header_data-rang_attr[] is initial.

*// Add the attribute descriptions to the sheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_attr[]
        CONTENTS  = is_header_data-data_attr[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

  if not is_header_data-rang_descr[] is initial.

*// Add the TECHNICAL descriptions to the sheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_descr[]
        CONTENTS  = is_header_data-data_descr[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

  if not is_header_data-rang_tech[] is initial.

*// Add the TECHNICAL descriptions to the sheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_tech[]
        CONTENTS  = is_header_data-data_tech[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

  if not is_header_data-rang_down[] is initial.

*// Add the DATA to the sheet
    CALL METHOD GO_SHEET->SET_RANGES_DATA
      EXPORTING
        NO_FLUSH  = abap_false
        RANGES    = is_header_data-rang_down[]
        CONTENTS  = is_header_data-data_down[]
      IMPORTING
        ERROR     = go_error.

    lv_subrc = handle_error( go_error ).

  endif.

*// Maximize the column width for the data
  CALL METHOD GO_SHEET->FIT_WIDEST
    EXPORTING
      NAME     = GC_RANGE_WIDTH.

*// Protect the HEADER range
  CALL METHOD GO_SHEET->PROTECT_RANGE
    EXPORTING
      NAME     = gc_range_head
      PROTECT  = abap_false.

*// Do not protect the DATA range
  CALL METHOD GO_SHEET->PROTECT_RANGE
    EXPORTING
      NAME     = gc_range_data
      PROTECT  = abap_false.

endmethod.


method SAVE_SHEET .

  data:
    lv_desktop   type string,
    lv_filename  type string,
    lv_filepath  type string,
    lv_path      type string,
    lv_file_list type string,
    lv_subrc     type sy-subrc,
    lv_url       type LOCALFILE.

  IF iv_filename NS '\'.
    concatenate ZCL_CA_FILEPATH_HANDLER=>GC_FILTER_LIST '|'
                ZCL_CA_FILEPATH_HANDLER=>gc_filter_XLS into lv_file_list.

*  // Get the desktop directory
    CALL METHOD CL_GUI_FRONTEND_SERVICES=>GET_DESKTOP_DIRECTORY
      CHANGING
        DESKTOP_DIRECTORY    = lv_desktop.

*  // Get the target file location
    CALL METHOD CL_GUI_FRONTEND_SERVICES=>FILE_SAVE_DIALOG
      EXPORTING
        DEFAULT_EXTENSION    = 'XLS'
        DEFAULT_FILE_NAME    = iv_filename
        INITIAL_DIRECTORY    = lv_desktop
        FILE_FILTER          = lv_file_list
      CHANGING
        FILENAME             = lv_filename
        PATH                 = lv_path
        FULLPATH             = lv_filepath
      EXCEPTIONS
        CNTL_ERROR           = 1
        ERROR_NO_GUI         = 2
        NOT_SUPPORTED_BY_GUI = 3
        others               = 4.

    IF SY-SUBRC <> 0.
      GO_DOCUMENT->CLOSE_DOCUMENT( ).
      exit.
    ENDIF.

  ELSE.
    lv_filepath = iv_filename.
  ENDIF.

*// Prepare the file name
  concatenate gc_file_prefix lv_filepath into lv_url.
  replace all OCCURRENCES of '\' in lv_url with '/'.

  if not lv_url is initial.

*// Save the spreadsheet to the client
    CALL METHOD GO_DOCUMENT->SAVE_DOCUMENT_TO_URL
      EXPORTING
        URL           = lv_url
      IMPORTING
        ERROR         = go_error.

    lv_subrc = handle_error( go_error ).

    EV_FILE_URL = lv_url.

  endif.

endmethod.


method UPDATE_PROGRESS .

  CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
   EXPORTING
     TEXT             = iv_text.

endmethod.
ENDCLASS.

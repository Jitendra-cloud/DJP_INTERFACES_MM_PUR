*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMATGVALC.......................................*
DATA:  BEGIN OF STATUS_ZMATGVALC                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMATGVALC                     .
CONTROLS: TCTRL_ZMATGVALC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMATGVALC                     .
TABLES: ZMATGVALC                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

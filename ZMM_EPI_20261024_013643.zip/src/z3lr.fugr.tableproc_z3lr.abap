*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3LR
*   generation date: 2003.05.12 at 14:51:27 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3LR                .

  PERFORM TABLEPROC.

ENDFUNCTION.

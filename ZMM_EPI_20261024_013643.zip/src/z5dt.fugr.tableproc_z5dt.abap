*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5DT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5DT                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    generated viewmaintenance function pool top
*---------------------------------------------------------------------*
FUNCTION-POOL ZM9W                       MESSAGE-ID SV.

  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZM9WT00                                . "view rel. data dcl.

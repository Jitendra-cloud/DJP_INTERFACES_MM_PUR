*"* use this source file for any type declarations (class
*"* definitions, interfaces or data types) you need for method
*"* implementation or private method's signature

types:
  begin of TS_COORDINATES,
    col_int  type i,
    row_int  type i,
    col_char type char4,
    row_char type char4,
  end of TS_COORDINATES .
types:
  TT_ERRORS type table of ref to i_oi_error .
types:
  begin of TS_HEADER_DATA,
    DATA_STRUC type SOI_GENERIC_TABLE,
    RANG_STRUC type SOI_RANGE_LIST,
    DATA_FIELD type SOI_GENERIC_TABLE,
    RANG_FIELD type SOI_RANGE_LIST,
    DATA_ATTR  type SOI_GENERIC_TABLE,
    RANG_ATTR  type SOI_RANGE_LIST,
    DATA_TECH  type SOI_GENERIC_TABLE,
    RANG_TECH  type SOI_RANGE_LIST,
    DATA_DESCR type SOI_GENERIC_TABLE,
    RANG_DESCR type SOI_RANGE_LIST,
    DATA_SDESC type SOI_GENERIC_TABLE,
    RANG_SDESC type SOI_RANGE_LIST,
    RANG_DATA  type SOI_RANGE_LIST,
    DATA_DOWN  type SOI_GENERIC_TABLE,
    RANG_DOWN  type SOI_RANGE_LIST,
    DATA_KEY   type SOI_GENERIC_TABLE,
    RANG_KEY   type SOI_RANGE_LIST,
  end of TS_HEADER_DATA .

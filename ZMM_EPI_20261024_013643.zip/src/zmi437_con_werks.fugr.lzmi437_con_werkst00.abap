*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMI437_CON_WERKS................................*
DATA:  BEGIN OF STATUS_ZMI437_CON_WERKS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMI437_CON_WERKS              .
CONTROLS: TCTRL_ZMI437_CON_WERKS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMI437_CON_WERKS              .
TABLES: ZMI437_CON_WERKS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_YMM_HARBOR_RLSTK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_YMM_HARBOR_RLSTK    .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    generated viewmaintenance function pool top
*---------------------------------------------------------------------*
FUNCTION-POOL ZME03735                   MESSAGE-ID SV.

  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZME03735T00                            . "view rel. data dcl.

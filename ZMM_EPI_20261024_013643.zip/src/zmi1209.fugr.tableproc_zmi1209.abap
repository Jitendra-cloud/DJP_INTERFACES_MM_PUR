*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMI1209
*   generation date: 2003.05.20 at 13:28:59 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMI1209             .

  PERFORM TABLEPROC.

ENDFUNCTION.

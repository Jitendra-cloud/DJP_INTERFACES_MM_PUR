*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z7MP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z7MP                .

  PERFORM TABLEPROC.

ENDFUNCTION.

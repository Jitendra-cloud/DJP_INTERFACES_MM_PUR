*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3NN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3NN                .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME02954_ERRORS.................................*
DATA:  BEGIN OF STATUS_ZME02954_ERRORS               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME02954_ERRORS               .
CONTROLS: TCTRL_ZME02954_ERRORS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME02954_ERRORS               .
TABLES: ZME02954_ERRORS                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

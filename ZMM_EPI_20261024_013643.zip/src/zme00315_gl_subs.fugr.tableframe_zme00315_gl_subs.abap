*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZME00315_GL_SUBS
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZME00315_GL_SUBS   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

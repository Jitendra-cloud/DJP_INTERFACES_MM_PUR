*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMI220
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMI220              .

  PERFORM TABLEPROC.

ENDFUNCTION.

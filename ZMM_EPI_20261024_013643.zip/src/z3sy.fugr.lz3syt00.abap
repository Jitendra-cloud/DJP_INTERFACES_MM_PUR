*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMSYSID.........................................*
DATA:  BEGIN OF STATUS_ZMSYSID                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMSYSID                       .
CONTROLS: TCTRL_ZMSYSID
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMSYSID                       .
TABLES: ZMSYSID                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

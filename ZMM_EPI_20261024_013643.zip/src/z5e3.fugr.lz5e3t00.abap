*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTAXI...........................................*
DATA:  BEGIN OF STATUS_ZTAXI                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTAXI                         .
CONTROLS: TCTRL_ZTAXI
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTAXI                         .
TABLES: ZTAXI                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

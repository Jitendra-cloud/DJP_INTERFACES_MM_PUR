*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMANDTE.........................................*
DATA:  BEGIN OF STATUS_ZMANDTE                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMANDTE                       .
CONTROLS: TCTRL_ZMANDTE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMANDTE                       .
TABLES: ZMANDTE                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

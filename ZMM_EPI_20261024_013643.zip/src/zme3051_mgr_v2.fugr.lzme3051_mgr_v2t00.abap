*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME3051_MGR_V2..................................*
TABLES: ZME3051_MGR_V2, *ZME3051_MGR_V2. "view work areas
CONTROLS: TCTRL_ZME3051_MGR_V2
TYPE TABLEVIEW USING SCREEN '0001'.
DATA: BEGIN OF STATUS_ZME3051_MGR_V2. "state vector
          INCLUDE STRUCTURE VIMSTATUS.
DATA: END OF STATUS_ZME3051_MGR_V2.
* Table for entries selected to show on screen
DATA: BEGIN OF ZME3051_MGR_V2_EXTRACT OCCURS 0010.
INCLUDE STRUCTURE ZME3051_MGR_V2.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZME3051_MGR_V2_EXTRACT.
* Table for all entries loaded from database
DATA: BEGIN OF ZME3051_MGR_V2_TOTAL OCCURS 0010.
INCLUDE STRUCTURE ZME3051_MGR_V2.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZME3051_MGR_V2_TOTAL.

*.........table declarations:.................................*
TABLES: ZME3051_MGR_CREF               .

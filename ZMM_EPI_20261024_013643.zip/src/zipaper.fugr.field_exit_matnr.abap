FUNCTION FIELD_EXIT_MATNR.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     REFERENCE(INPUT)
*"  EXPORTING
*"     REFERENCE(OUTPUT)
*"----------------------------------------------------------------------
set parameter id 'MAT' field input.

output = input.

ENDFUNCTION.

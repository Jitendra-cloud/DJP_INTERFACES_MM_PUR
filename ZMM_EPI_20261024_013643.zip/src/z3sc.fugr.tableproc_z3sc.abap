*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z3SC
*   generation date: 2003.05.12 at 15:37:00 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z3SC                .

  PERFORM TABLEPROC.

ENDFUNCTION.

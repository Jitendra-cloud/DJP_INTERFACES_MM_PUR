************************************************************************
**                                                                    **
**             C O M P A N Y   C O N F I D E N T I A L                **
**                                                                    **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
**                                                                    **
************************************************************************
************************************************************************
**                                                                    **
**                    COPYRIGHT © 2020 by                             **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
**                     ALL RIGHTS RESERVED                            **
**                                                                    **
**                   REVISIONS COPYRIGHT ©                            **
**                       20xx, 20yy, 20zz                             **
**                             by                                     **
**                     INTERNATIONAL PAPER                            **
**                                                                    **
*______________________________________________________________________*
* Program Name: Class to process Outbound PO IDOC to ECM               *
*                                                                      *
* SAP Name    : CLASS: ZCL_MM_I10533_EXIT        Create Date: 08/25/20 *
*                                                                      *
* Programmer  : Anil Lankapalli                  Last Update: 09/17/20 *
*                                                                      *
*______________________________________________________________________*
* Description : This class is used to build and populate the custom    *
* segments for PO outbound IDOC for ECM. The IDOC will be generated    *
* when we create or change a PO in ECC.                                *
* Message Type: ZMM_PO_ECM_CHG & ZMM_PO_ECM_CR                         *
* Partner No.   ECM_ALE                                                *
* Output Type: ZECM                                                    *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date      Req. #      PRICEF/CR/CO             *
* ==================  ========  ==========  ================           *
* Anil Lankapalli     08/25/20   E0VK9A1FG4   CD 2000009626            *
*                                                                      *
*  Actions                                                             *
* ==========================================================           *
* Initial development                                                  *
*                                                                      *
*                                                                      *
*______________________________________________________________________*
************************************************************************
* Includes          :                                                  *
*                                                                      *
*______________________________________________________________________*
* External Calls                                                       *
*                                                                      *
*______________________________________________________________________*
* Size Limitations                                                     *
*   Max Number Recs :                                                  *
*                                                                      *
*______________________________________________________________________*
* Scheduling Issues                                                    *
*   Run Frequency   :                                                  *
*                                                                      *
*______________________________________________________________________*
* Variable Definition Key                                              *
*                                                                      *
*       Prefix                Second Char             Special          *
*   -----------------      ------------------    ------------------    *
*   GX = Global            XV = Variable         SO = Select Option    *
*   LX = Local             XS = Structure        SP = Select Parameter *
*   IX = Importing         XT = Table            TS = Type Struct.     *
*   EX = Exporting         XO = Object           TT = Table Type       *
*   CX = Changing          XR = Range            PB = Push Button      *
*   RX = Returning         XC = Constant                               *
*                          XB = Boolean                                *
*______________________________________________________________________*
************************************************************************
class ZCL_MM_I10533_EXIT definition
  public
  create public .

public section.

  types:
    tt_edidd_tab TYPE STANDARD TABLE OF edidd .
  types:
    tt_ekpo TYPE STANDARD TABLE OF uekpo .
  types:
*  types:
*    tt_cond TYPE STANDARD TABLE OF BAPIMEOUTCONDITION .
    BEGIN OF ty_konv,
        knumv TYPE knumv,
        kposn TYPE kposn,
        zaehk TYPE dzaehk,
        kschl TYPE kscha,
        kbetr type kbetr,
        kntyp TYPE kntyp,
        lifnr TYPE lifnr,
      END OF ty_konv .
  types:
    BEGIN OF ty_zmmfld,
        key1   TYPE zkey1,
        key2   TYPE zkey2,
        value1 TYPE zvalue_1,
      END OF ty_zmmfld .
  types:
    BEGIN OF ty_ekkn,
        ebeln      TYPE ebeln,
        ebelp      TYPE ebelp,
        zekkn      TYPE dzekkn,
        menge      TYPE menge_d,
        vproz      TYPE vproz,
        sakto      TYPE saknr,
        kostl      TYPE kostl,
        ps_psp_pnr TYPE ps_psp_pnr,
      END OF ty_ekkn .
  types:
    BEGIN of ty_conditions,
       ITEM TYPE ebelp,
       SERIAL_ID TYPE meout_id_konh,
       KSCHL type kschl,
       KOTXT type VTXTK,
       KPERC type bapikbetr1,
       KRATE type bapikbetr1,
       lifnr type lifnr,
    END OF TY_CONDITIONS .
  types:
    tt_conditions TYPE standard TABLE OF ty_conditions WITH DEFAULT KEY .
  types:
    tt_cond TYPE STANDARD TABLE OF ty_conditions WITH DEFAULT KEY .

  data MS_EDIDD type EDIDD .
  data MT_EDIDD type TT_EDIDD_TAB .

  methods CONSTRUCTOR
    importing
      !IS_EKKO type EKKO .
  methods BUILD_ECM_PO_IDOC
    importing
      !IS_EKKO type EKKO
    changing
      !CT_EDIDD type TT_EDIDD_TAB
      !CT_EKPO type TT_EKPO .
  PROTECTED SECTION.
    CONSTANTS c_e1edk01 TYPE edilsegtyp VALUE 'E1EDK01'.
    CONSTANTS c_z1pohd TYPE edilsegtyp VALUE 'Z1POHD'.
    CONSTANTS c_e1edp01 TYPE edilsegtyp VALUE 'E1EDP01'.
    CONSTANTS c_zmpoitm TYPE edilsegtyp VALUE 'ZMPOITM'.
    CONSTANTS c_zmpoact TYPE edilsegtyp VALUE 'ZMPOACT'.
    CONSTANTS c_e1edp04 TYPE edilsegtyp VALUE 'E1EDP04'.
    CONSTANTS c_e1edp05 TYPE edilsegtyp VALUE 'E1EDP05'.
    CONSTANTS c_z1edp05 TYPE edilsegtyp VALUE 'Z1EDP05'.
    CONSTANTS c_e1edpa1 TYPE edilsegtyp VALUE 'E1EDPA1'.
    CONSTANTS c_e1edk14 TYPE edilsegtyp VALUE 'E1EDK14'.
    CONSTANTS c_e1edk03 TYPE edilsegtyp VALUE 'E1EDK03'.
    CONSTANTS c_e1edka1 TYPE edilsegtyp VALUE 'E1EDKA1'.
    CONSTANTS c_e1edk02 TYPE edilsegtyp VALUE 'E1EDK02'.
    CONSTANTS c_e1edk18 TYPE edilsegtyp VALUE 'E1EDK18'.
    CONSTANTS c_e1edkt1 TYPE edilsegtyp VALUE 'E1EDKT1'.
    CONSTANTS c_e1edkt2 TYPE edilsegtyp VALUE 'E1EDKT2'.

    DATA mv_tabix   TYPE sy-tabix.
    DATA mv_zaehk   TYPE dzaehk.
    DATA ms_e1edk01 TYPE e1edk01.
    DATA ms_z1pohd  TYPE z1pohd.
    DATA ms_e1edp01 TYPE e1edp01.
    DATA ms_zmpoitm TYPE zmpoitm.
    DATA mv_ebelp   TYPE ebelp.
    DATA ms_zmpoact TYPE zmpoact.
    DATA ms_e1edp05 TYPE e1edp05.
    DATA ms_z1edp05 TYPE z1edp05.
    DATA ms_e1edk14 TYPE e1edk14.
    DATA ms_e1edk03 TYPE e1edk03.
    DATA ms_e1edka1 TYPE e1edka1.
    DATA ms_e1edk02 TYPE e1edk02.
    DATA ms_e1edk18 TYPE e1edk18.
    DATA ms_e1edpa1 TYPE e1edpa1.

    DATA mt_zmmfld TYPE STANDARD TABLE OF ty_zmmfld.
    DATA mt_konv TYPE STANDARD TABLE OF ty_konv.
    DATA mt_ekkn TYPE STANDARD TABLE OF ty_ekkn.

private section.

  methods POPULATE_E1EDP04
    importing
      !IT_EKPO type TT_EKPO
    changing
      !CT_EDIDD type TT_EDIDD_TAB .
  methods PROCESS_ZMPOACT .
  methods PROCESS_ZMPOITM
    importing
      !IT_EKPO type TT_EKPO .
  methods PROCESS_Z1EDP05
    importing
      !IV_EBELP type EBELP .
ENDCLASS.



CLASS ZCL_MM_I10533_EXIT IMPLEMENTATION.


  METHOD BUILD_ECM_PO_IDOC.
*---------------------------------------------------------------------*
*   Build the IDOC with custom segments
*---------------------------------------------------------------------*
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_MM_I10533_EXIT               Create Date: 09/17/2020 *
* Method:       BUILD_ECM_PO_IDOC                                    *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Method to be used for the ECM IDOC generation          *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020              Build ECM outbound PO IDOC *
*                                           with custom segments       *
************************************************************************
    DATA: ls_edidd      TYPE edidd.
    CLEAR: mv_zaehk.
    mt_edidd = ct_edidd.
    populate_e1edp04( EXPORTING
        it_ekpo = ct_ekpo
  CHANGING
    ct_edidd = mt_edidd ).
    LOOP AT mt_edidd INTO ms_edidd.
      CLEAR : mv_tabix.

      mv_tabix = sy-tabix.

      CASE ms_edidd-segnam.

        WHEN c_e1edk01. " E1EDK01
          MOVE ms_edidd-sdata TO ms_e1edk01.
          ls_edidd-segnam = c_z1pohd.
          ms_z1pohd-ernam = is_ekko-ernam.
          ls_edidd-sdata  =  ms_z1pohd.
          mv_tabix = mv_tabix + 1.
          INSERT ls_edidd INTO mt_edidd INDEX mv_tabix.
          CLEAR : mv_tabix,ls_edidd.
        WHEN c_e1edp01. " E1EDP01
          MOVE ms_edidd-sdata TO ms_e1edp01.
          process_zmpoitm( ct_ekpo ).
          process_zmpoact( ).
        WHEN c_e1edp05. " E1EDP05

          MOVE ms_edidd-sdata TO ms_e1edp05.
          process_z1edp05( iv_ebelp = mv_ebelp ).

      ENDCASE.
    ENDLOOP.

    ct_edidd = mt_edidd.

  ENDMETHOD.


  METHOD CONSTRUCTOR.

* Fetch the data from ZMMFLD table
    SELECT key1 key2 value1 INTO TABLE mt_zmmfld FROM zmmfld WHERE
          key1 = 'I10533'.

* Fetch the data from KONV table for the condition data
    SELECT knumv
           kposn
           zaehk
           kschl
           kbetr
           kntyp
           lifnr
           INTO TABLE mt_konv FROM konv
         WHERE knumv = is_ekko-knumv ORDER BY knumv.

* Fetch the data from EKKN for account assignment data
    SELECT ebeln
           ebelp
           zekkn
           menge
           vproz
           sakto
           kostl
           ps_psp_pnr
           INTO TABLE mt_ekkn FROM ekkn
          WHERE ebeln = is_ekko-ebeln.

  ENDMETHOD.


  METHOD POPULATE_E1EDP04.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_MM_I10533_EXIT               Create Date: 09/17/2020 *
* Method:       POPULATE_E1EDP04                                       *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Method to be used for the ECM IDOC generation          *
*   Populate the data for segment E1EKP04.                             *
*   This method is added with reference to SAP Note 2738464            *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020              Build ECM outbound PO IDOC *
*                                           with custom segments       *
************************************************************************

    DATA: ls_e1edp04   TYPE e1edp04,
          lv_ebelp     TYPE ebelp,
          ls_tax_edidd TYPE edidd, "dint_edidd,
          ls_ekpo      TYPE ekpo,
          ls_edidd     TYPE edidd,
          lv_segnam    TYPE edilsegtyp.

    LOOP AT ct_edidd INTO ls_edidd.

      IF lv_segnam EQ 'E1EDP03' AND ls_edidd-segnam <> 'E1EDP03'.
        CLEAR lv_segnam.
        IF   NOT  ls_e1edp04-mwskz IS INITIAL.
          ls_tax_edidd-segnam = 'E1EDP04'.
          MOVE ls_e1edp04 TO ls_tax_edidd-sdata.
          INSERT ls_tax_edidd INTO ct_edidd INDEX sy-tabix.
        ENDIF.
      ENDIF.

      IF lv_segnam EQ 'E1CUREF' AND ls_edidd-segnam <> 'E1CUREF'.
        CLEAR lv_segnam.
        IF ls_edidd-segnam NE 'E1EDP03'.
          IF   NOT  ls_e1edp04-mwskz IS INITIAL.
            ls_tax_edidd-segnam = 'E1EDP04'.
            MOVE ls_e1edp04 TO ls_tax_edidd-sdata.
            INSERT ls_tax_edidd INTO ct_edidd INDEX sy-tabix.
          ENDIF.
        ELSE.
          lv_segnam = 'E1EDP03'.
        ENDIF.
      ENDIF.

      IF lv_segnam EQ 'E1EDP02' AND ls_edidd-segnam <> 'E1EDP02'.
        CLEAR lv_segnam.
        IF ls_edidd-segnam NE 'E1CUREF' AND
           ls_edidd-segnam NE 'E1EDP03'.
          IF   NOT  ls_e1edp04-mwskz IS INITIAL.
            ls_tax_edidd-segnam = 'E1EDP04'.
            MOVE ls_e1edp04 TO ls_tax_edidd-sdata.
            INSERT ls_tax_edidd INTO ct_edidd INDEX sy-tabix.
          ENDIF.
        ELSEIF ls_edidd-segnam = 'E1CUREF'.
          lv_segnam = 'E1CUREF'.
        ELSEIF ls_edidd-segnam = 'E1EDP03'.
          lv_segnam = 'E1EDP03'.
        ENDIF.
      ENDIF.

      IF lv_segnam EQ 'E1EDP01' AND ls_edidd-segnam <> 'E1EDP02' AND
         ls_edidd-segnam <> 'E1EDP03' AND ls_edidd-segnam <> 'E1CUREF'.
        CLEAR lv_segnam.
        IF   NOT  ls_e1edp04-mwskz IS INITIAL.
          ls_tax_edidd-segnam = 'E1EDP04'.
          MOVE ls_e1edp04 TO ls_tax_edidd-sdata.
          INSERT ls_tax_edidd INTO ct_edidd INDEX sy-tabix.
        ENDIF.
      ENDIF.

      IF ls_edidd-segnam = 'E1EDP01'.
        lv_segnam = 'E1EDP01'.
        lv_ebelp = ls_edidd-sdata(5).
        READ TABLE it_ekpo WITH KEY ebelp = lv_ebelp INTO ls_ekpo.
        IF sy-subrc = 0.
          ls_e1edp04-mwskz = ls_ekpo-mwskz.
        ENDIF.
      ENDIF.

      IF ls_edidd-segnam = 'E1EDP02'.
        lv_segnam = 'E1EDP02'.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


  METHOD PROCESS_Z1EDP05.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_MM_I10533_EXIT               Create Date: 09/17/2020 *
* Method:       PROCESS_Z1EDP05                                        *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Method to be used to populate the Condition data       *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020             Populate the data for custom*
*                                          segment Z1EKP05             *
************************************************************************

    DATA: ls_edidd TYPE edidd.
    DATA: lv_kposn TYPE kposn.
    CLEAR: ms_z1edp05.
    lv_kposn = iv_ebelp.
    DATA(lv_kntyp) = VALUE #( mt_konv[ kposn = lv_kposn
                                       kschl = ms_e1edp05-kschl ]-kntyp OPTIONAL ).
    IF lv_kntyp = VALUE #( mt_zmmfld[ key2 = 'KNTYP' ]-value1 OPTIONAL ).
      do.
       mv_zaehk = mv_zaehk + 1.

       ls_edidd-segnam = c_z1edp05.

       ms_z1edp05-zaehk = mv_zaehk.
       data(ls_konv) = VALUE #( mt_konv[ kposn = lv_kposn
                                         kschl = ms_e1edp05-kschl
                                         zaehk = mv_zaehk ] OPTIONAL ).

       ms_z1edp05-vendor_no = ls_konv-lifnr.
       if not ls_konv-kbetr is INITIAL.
         ls_edidd-sdata =  ms_z1edp05.
         mv_tabix = mv_tabix + 1.
         INSERT ls_edidd INTO mt_edidd INDEX mv_tabix.
         CLEAR : mv_tabix, ls_edidd, ls_konv, lv_kntyp.
         exit.
       endif.
      ENDDO.
    ELSE.
      DELETE mt_edidd INDEX  mv_tabix.
    ENDIF.
  ENDMETHOD.


  METHOD PROCESS_ZMPOACT.

************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_MM_I10533_EXIT               Create Date: 09/17/2020 *
* Method:       PROCESS_ZMPOACT                                        *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Method to be used for building Seg: ZMPOACT data       *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020              Populate the data for custom
*                                           segment ZMPOACT to fill the*
*                                           Account Assignment data in *
*                                           Purchasing Document        *
************************************************************************

    DATA: ls_edidd TYPE edidd.
    CLEAR: ms_zmpoact.

    ls_edidd-segnam = c_zmpoact.
    LOOP AT mt_ekkn INTO DATA(ls_ekkn) WHERE ebelp = mv_ebelp.
      CLEAR: ms_zmpoact.
      ms_zmpoact-po_item     = ms_e1edp01-posex.
      ms_zmpoact-serial_no   = ls_ekkn-zekkn.
      ms_zmpoact-quantity    = ls_ekkn-menge.
      ms_zmpoact-distr_perc  = ls_ekkn-vproz.
      ms_zmpoact-gl_account  = ls_ekkn-sakto.
      ms_zmpoact-costcenter  = ls_ekkn-kostl.

      " Convert the WBS element from internal format to external format
      CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
        EXPORTING
          input  = ls_ekkn-ps_psp_pnr
        IMPORTING
          output = ms_zmpoact-wbs_element.

      ls_edidd-sdata =  ms_zmpoact.
      mv_tabix = mv_tabix + 1.
      INSERT ls_edidd INTO mt_edidd INDEX mv_tabix.
    ENDLOOP.

    CLEAR : mv_tabix,ls_edidd.
  ENDMETHOD.


  METHOD PROCESS_ZMPOITM.
************************************************************************
**             C O M P A N Y   C O N F I D E N T I A L                **
**        This program is the property of International Paper.        **
**        Care should be taken to prevent its unauthorized use.       **
************************************************************************
**                    COPYRIGHT (C) 2004 by                           **
**                     INTERNATIONAL PAPER                            **
**                     ALL RIGHTS RESERVED                            **
**                   REVISIONS COPYRIGHT (C)                          **
**                           2020                                     **
**                   by INTERNATIONAL PAPER                           **
************************************************************************
* Class Name: ZCL_MM_I10533_EXIT               Create Date: 09/17/2020 *
* Method:       PROCESS_ZMPOITM                                        *
* Programmer  : Anil Lankapalli                Last Update:            *
*______________________________________________________________________*
* Description : Method to be used for building Seg: ZMPOITM data       *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer        Date    Req. #            Action               *
* ==================  ========  ======  ===============================*
* Anil Lankapalli   09/17/2020              Populate the data for custom
*                                           segment ZMPOITM to fill the*
*                                           additional PO item data    *
************************************************************************
    DATA: ls_edidd TYPE edidd.
    DATA: lv_ebelp TYPE ebelp.
    CLEAR: mv_zaehk.
    CLEAR: ms_zmpoitm.

    lv_ebelp = ms_e1edp01-posex.
    ls_edidd-segnam = c_zmpoitm.
    DATA(ls_ekpo) = VALUE #( it_ekpo[ ebelp = lv_ebelp ] OPTIONAL ).
    ms_zmpoitm-acctasscat = ls_ekpo-knttp.
    ms_zmpoitm-vend_mat   = ls_ekpo-idnlf.
    ms_zmpoitm-gr_ind     = ls_ekpo-wepos.
    ms_zmpoitm-gr_basediv = ls_ekpo-webre.
    mv_ebelp = ls_ekpo-ebelp.

    ls_edidd-sdata =  ms_zmpoitm.
    mv_tabix = mv_tabix + 1.
    INSERT ls_edidd INTO mt_edidd INDEX mv_tabix.
    CLEAR : ls_edidd, ls_ekpo.
  ENDMETHOD.
ENDCLASS.

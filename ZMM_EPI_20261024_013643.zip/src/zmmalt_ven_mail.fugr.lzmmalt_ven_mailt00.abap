*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMALT_VEN_MAIL.................................*
DATA:  BEGIN OF STATUS_ZMMALT_VEN_MAIL               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMALT_VEN_MAIL               .
CONTROLS: TCTRL_ZMMALT_VEN_MAIL
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZMMALT_VEN_MAIL               .
TABLES: ZMMALT_VEN_MAIL                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

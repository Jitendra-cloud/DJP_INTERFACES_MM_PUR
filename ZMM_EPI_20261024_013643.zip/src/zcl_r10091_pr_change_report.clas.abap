class ZCL_R10091_PR_CHANGE_REPORT definition
  public
  final
  create public .

public section.
*"* public components of class ZCL_R10091_PR_CHANGE_REPORT
*"* do not include other source files here!!!

  data MT_SELOPTS type RSPARAMS_TT .
  data:
    s_udate        TYPE RANGE OF cdhdr-udate .
  data:
    username       TYPE RANGE OF cdhdr-username .
  data:
    objectid       TYPE RANGE OF cdhdr-objectid .
  data:
    s_banfn    TYPE RANGE OF    eban-banfn .
  data:
    s_bnfpo    TYPE RANGE OF    eban-bnfpo .
  data:
    s_loekz    TYPE RANGE OF    eban-loekz .
  data:
    s_statu    TYPE RANGE OF    eban-statu .
  data:
    s_estkz    TYPE RANGE OF    eban-estkz .
  data:
    s_frgkz    TYPE RANGE OF    eban-frgkz .
  data:
    s_frgst    TYPE RANGE OF    eban-frgst .
  data:
    s_ekgrp    TYPE RANGE OF    eban-ekgrp .
  data:
    s_ernam    TYPE RANGE OF    eban-ernam .
  data:
    s_werks    TYPE RANGE OF    eban-werks .
  data:
    s_ekorg    TYPE RANGE OF    eban-ekorg .
  data:
    s_bednr    TYPE RANGE OF    eban-bednr .
  data:
    s_badat    TYPE RANGE OF    eban-badat .
  data:
    s_lfdat    TYPE RANGE OF    eban-lfdat .
  data:
    s_erdat    TYPE RANGE OF    eban-erdat .
  data:
    s_pstyp    TYPE RANGE OF    eban-pstyp .
  data:
    s_knttp    TYPE RANGE OF    eban-knttp .
  data:
    s_lifnr    TYPE RANGE OF    eban-lifnr .
  data:
    s_banpr    TYPE RANGE OF    eban-banpr .
  data:
    s_sakto    TYPE RANGE OF    ebkn-sakto .
  data:
    s_kostl    TYPE RANGE OF    ebkn-kostl .
  data:
    s_aufnr    TYPE RANGE OF    ebkn-aufnr .
  data:
    pspsppnr   TYPE RANGE OF    ebkn-ps_psp_pnr .

  methods CONSTRUCTOR
    importing
      value(ID_CALLING_REPORT) type SYST-REPID optional .
  methods GET_DATA
    returning
      value(OUTPUT_TAB) type ZMMR10091_TABLE .
  methods SHOW_PROGRESS
    importing
      !IV_PROGRESS type I
      !IV_TEXT type CHAR255 .
protected section.
*"* protected components of class ZCL_R10091_PR_CHANGE_REPORT
*"* do not include other source files here!!!
PRIVATE SECTION.
*"* private components of class ZCL_R10091_PR_CHANGE_REPORT
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCL_R10091_PR_CHANGE_REPORT IMPLEMENTATION.


METHOD constructor.
  DATA : ls_selection   TYPE rsparams,
         s_udate_wa     LIKE LINE OF s_udate,
         username_wa    LIKE LINE OF username ,
         objectid_wa    LIKE LINE OF objectid,
         s_banfn_wa     LIKE LINE OF s_banfn ,
         s_bnfpo_wa     LIKE LINE OF s_bnfpo ,
         s_loekz_wa     LIKE LINE OF s_loekz ,
         s_statu_wa     LIKE LINE OF s_statu,
         s_estkz_wa     LIKE LINE OF s_estkz,
         s_frgkz_wa     LIKE LINE OF s_frgkz,
         s_frgst_wa     LIKE LINE OF s_frgst,
         s_ekgrp_wa     LIKE LINE OF s_ekgrp,
         s_ernam_wa     LIKE LINE OF s_ernam,
         s_werks_wa     LIKE LINE OF s_werks,
         s_ekorg_wa     LIKE LINE OF s_ekorg,
         s_bednr_wa     LIKE LINE OF s_bednr,
         s_badat_wa     LIKE LINE OF s_badat,
         s_lfdat_wa     LIKE LINE OF s_lfdat,
         s_erdat_wa     LIKE LINE OF s_erdat,
         s_pstyp_wa     LIKE LINE OF s_pstyp,
         s_knttp_wa     LIKE LINE OF s_knttp,
         s_lifnr_wa     LIKE LINE OF s_lifnr,
         s_banpr_wa     LIKE LINE OF s_banpr,
         s_sakto_wa     LIKE LINE OF s_sakto,
         s_kostl_wa     LIKE LINE OF s_kostl,
         s_aufnr_wa     LIKE LINE OF s_aufnr,
         pspsppnr_wa    LIKE LINE OF pspsppnr.



  CALL FUNCTION 'RS_REFRESH_FROM_SELECTOPTIONS'
    EXPORTING
      curr_report     = id_calling_report
    TABLES
      selection_table = me->mt_selopts.


  DELETE mt_selopts WHERE sign IS INITIAL.


  LOOP AT me->mt_selopts INTO ls_selection.
    CASE ls_selection-selname.

      WHEN 'S_UDATE'.

        s_udate_wa-sign    = ls_selection-sign.
        s_udate_wa-option  = ls_selection-option.
        s_udate_wa-low     = ls_selection-low.
        s_udate_wa-high    = ls_selection-high.
        APPEND s_udate_wa TO s_udate.

      WHEN 'USERNAME'.

        username_wa-sign   = ls_selection-sign.
        username_wa-option = ls_selection-option.
        username_wa-low    = ls_selection-low.
        username_wa-high   = ls_selection-high.
        APPEND username_wa TO username.

      WHEN 'OBJECTID'.

        objectid_wa-sign   = ls_selection-sign.
        objectid_wa-option = ls_selection-option.
        objectid_wa-low    = ls_selection-low.
        objectid_wa-high   = ls_selection-high.
        APPEND objectid_wa TO objectid.


      WHEN 'S_BANFN'.

        s_banfn_wa-sign    = ls_selection-sign.
        s_banfn_wa-option  = ls_selection-option.
        s_banfn_wa-low     = ls_selection-low.
        s_banfn_wa-high    = ls_selection-high.
        APPEND s_banfn_wa TO s_banfn .

      WHEN 'S_BNFPO'.

        s_bnfpo_wa-sign    = ls_selection-sign.
        s_bnfpo_wa-option  = ls_selection-option.
        s_bnfpo_wa-low     = ls_selection-low.
        s_bnfpo_wa-high    = ls_selection-high.
        APPEND s_bnfpo_wa TO s_bnfpo.

      WHEN 'S_LOEKZ'.

        s_loekz_wa-sign    = ls_selection-sign.
        s_loekz_wa-option  = ls_selection-option.
        s_loekz_wa-low     = ls_selection-low.
        s_loekz_wa-high    = ls_selection-high.
        APPEND s_loekz_wa TO s_loekz.

      WHEN 'S_STATU'.

        s_statu_wa-sign    = ls_selection-sign.
        s_statu_wa-option  = ls_selection-option.
        s_statu_wa-low     = ls_selection-low.
        s_statu_wa-high    = ls_selection-high.
        APPEND s_statu_wa TO s_statu.

      WHEN 'S_ESTKZ'.

        s_estkz_wa-sign    = ls_selection-sign.
        s_estkz_wa-option  = ls_selection-option.
        s_estkz_wa-low     = ls_selection-low.
        s_estkz_wa-high    = ls_selection-high.
        APPEND s_estkz_wa TO s_estkz.

      WHEN 'S_FRGKZ'.

        s_frgkz_wa-sign    = ls_selection-sign.
        s_frgkz_wa-option  = ls_selection-option.
        s_frgkz_wa-low     = ls_selection-low.
        s_frgkz_wa-high    = ls_selection-high.
        APPEND s_frgkz_wa TO s_frgkz.

      WHEN 'S_FRGST'.

        s_frgst_wa-sign    = ls_selection-sign.
        s_frgst_wa-option  = ls_selection-option.
        s_frgst_wa-low     = ls_selection-low.
        s_frgst_wa-high    = ls_selection-high.
        APPEND s_frgst_wa TO s_frgst.

      WHEN 'S_EKGRP'.

        s_ekgrp_wa-sign    = ls_selection-sign.
        s_ekgrp_wa-option  = ls_selection-option.
        s_ekgrp_wa-low     = ls_selection-low.
        s_ekgrp_wa-high    = ls_selection-high.
        APPEND s_ekgrp_wa TO s_ekgrp.

      WHEN 'S_ERNAM'.

        s_ernam_wa-sign    = ls_selection-sign.
        s_ernam_wa-option  = ls_selection-option.
        s_ernam_wa-low     = ls_selection-low.
        s_ernam_wa-high    = ls_selection-high.
        APPEND s_ernam_wa TO s_ernam.

      WHEN 'S_WERKS'.

        s_werks_wa-sign    = ls_selection-sign.
        s_werks_wa-option  = ls_selection-option.
        s_werks_wa-low     = ls_selection-low.
        s_werks_wa-high    = ls_selection-high.
        APPEND s_werks_wa TO s_werks.

      WHEN 'S_EKORG'.

        s_ekorg_wa-sign    = ls_selection-sign.
        s_ekorg_wa-option  = ls_selection-option.
        s_ekorg_wa-low     = ls_selection-low.
        s_ekorg_wa-high    = ls_selection-high.
        APPEND s_ekorg_wa TO s_ekorg.

      WHEN 'S_BEDNR'.

        s_bednr_wa-sign    = ls_selection-sign.
        s_bednr_wa-option  = ls_selection-option.
        s_bednr_wa-low     = ls_selection-low.
        s_bednr_wa-high    = ls_selection-high.
        APPEND s_bednr_wa TO s_bednr.

      WHEN 'S_BADAT'.

        s_badat_wa-sign    = ls_selection-sign.
        s_badat_wa-option  = ls_selection-option.
        s_badat_wa-low     = ls_selection-low.
        s_badat_wa-high    = ls_selection-high.
        APPEND s_badat_wa TO s_badat.

      WHEN 'S_LFDAT'.

        s_lfdat_wa-sign    = ls_selection-sign.
        s_lfdat_wa-option  = ls_selection-option.
        s_lfdat_wa-low     = ls_selection-low.
        s_lfdat_wa-high    = ls_selection-high.
        APPEND s_lfdat_wa TO s_lfdat.

      WHEN 'S_ERDAT'.

        s_erdat_wa-sign    = ls_selection-sign.
        s_erdat_wa-option  = ls_selection-option.
        s_erdat_wa-low     = ls_selection-low.
        s_erdat_wa-high    = ls_selection-high.
        APPEND s_erdat_wa TO s_erdat.

      WHEN 'S_PSTYP'.

        s_pstyp_wa-sign    = ls_selection-sign.
        s_pstyp_wa-option  = ls_selection-option.
        s_pstyp_wa-low     = ls_selection-low.
        s_pstyp_wa-high    = ls_selection-high.
        APPEND s_pstyp_wa TO s_pstyp.

      WHEN 'S_KNTTP'.

        s_knttp_wa-sign    = ls_selection-sign.
        s_knttp_wa-option  = ls_selection-option.
        s_knttp_wa-low     = ls_selection-low.
        s_knttp_wa-high    = ls_selection-high.
        APPEND s_knttp_wa TO s_knttp.

      WHEN 'S_LIFNR'.

        s_lifnr_wa-sign    = ls_selection-sign.
        s_lifnr_wa-option  = ls_selection-option.
        s_lifnr_wa-low     = ls_selection-low.
        s_lifnr_wa-high    = ls_selection-high.
        APPEND s_lifnr_wa TO s_lifnr.

      WHEN 'S_BANPR'.

        s_banpr_wa-sign    = ls_selection-sign.
        s_banpr_wa-option  = ls_selection-option.
        s_banpr_wa-low     = ls_selection-low.
        s_banpr_wa-high    = ls_selection-high.
        APPEND s_banpr_wa TO s_banpr.

      WHEN 'S_SAKTO'.

        s_sakto_wa-sign    = ls_selection-sign.
        s_sakto_wa-option  = ls_selection-option.
        s_sakto_wa-low     = ls_selection-low.
        s_sakto_wa-high    = ls_selection-high.
        APPEND s_sakto_wa TO s_sakto.

      WHEN 'S_KOSTL'.

        s_kostl_wa-sign    = ls_selection-sign.
        s_kostl_wa-option  = ls_selection-option.
        s_kostl_wa-low     = ls_selection-low.
        s_kostl_wa-high    = ls_selection-high.
        APPEND s_kostl_wa TO s_kostl.

      WHEN 'S_AUFNR'.

        s_aufnr_wa-sign    = ls_selection-sign.
        s_aufnr_wa-option  = ls_selection-option.
        s_aufnr_wa-low     = ls_selection-low.
        s_aufnr_wa-high    = ls_selection-high.
        APPEND s_aufnr_wa TO s_aufnr.

      WHEN 'PSPSPPNR'.

        pspsppnr_wa-sign    = ls_selection-sign.
        pspsppnr_wa-option  = ls_selection-option.
        pspsppnr_wa-low     = ls_selection-low.
        pspsppnr_wa-high    = ls_selection-high.
        APPEND pspsppnr_wa TO pspsppnr.



    ENDCASE.
  ENDLOOP.




















ENDMETHOD.


METHOD get_data.

*&---------------------------------------------------------------------*
*                         Constants Declarations                       *
*&---------------------------------------------------------------------*
  CONSTANTS: c_me       TYPE tcdrp-devclass VALUE 'ME',
             c_inc(1)   TYPE c VALUE 'I',
             c_eq(2)    TYPE c VALUE 'EQ',
             c_frgzu(5) TYPE c VALUE 'FRGZU',
             c_frgkz(5) TYPE c VALUE 'FRGKZ',
             c_rlwrt(5) TYPE c VALUE 'RLWRT',
             c_menge(5) TYPE c VALUE 'MENGE',
             c_preis(5) TYPE c VALUE 'PREIS',
             c_peinh(5) TYPE c VALUE 'PEINH',
             c_eban(4)  TYPE c VALUE 'EBAN',
             c_update   TYPE c VALUE 'U'.

  TYPES: BEGIN OF ty_eban,
          banfn               TYPE        banfn,
          bnfpo               TYPE        bnfpo,
          loekz               TYPE        eloek,
          statu               TYPE        banst,
          frgkz               TYPE        frgkz,
          frgst               TYPE        frgst,
          ekgrp               TYPE        ekgrp,
          ernam               TYPE        ernam,
          erdat               TYPE        aedat,
          txz01               TYPE        txz01,
          matnr               TYPE        matnr,
          werks               TYPE        ewerk,
          lgort               TYPE        lgort_d,
          bednr               TYPE        bednr,
          matkl               TYPE        matkl,
          menge               TYPE        bamng,
          meins               TYPE        bamei,
          badat               TYPE        badat,
          lfdat               TYPE        eindt,
          waers               TYPE        waers,
          preis               TYPE        bapre,
          peinh               TYPE        epein,
          pstyp               TYPE        pstyp,
          knttp               TYPE        knttp,
          lifnr               TYPE        wlief,
          flief               TYPE        flief,
          ebeln               TYPE        bstnr,
          ebelp               TYPE        bstpo,
          bedat               TYPE        bedat,
          bsmng               TYPE        bsmng,
          frggr               TYPE        frggr,
          spras               TYPE        spras,
          banpr               TYPE        banpr,
          vrtkz               TYPE        vrtkz,
          afnam               TYPE        afnam,
        END OF ty_eban.

  TYPES: BEGIN OF ty_ebkn,
           banfn               TYPE        banfn,
           bnfpo               TYPE        bnfpo,
           vproz               TYPE        vproz,
           sakto               TYPE        saknr,
           kostl               TYPE        kostl,
           aufnr               TYPE        aufnr,
           wempf               TYPE        wempf,
           ablad               TYPE        ablad,
           prctr               TYPE        prctr,
           ps_psp_pnr          TYPE        ps_psp_pnr,
         END OF ty_ebkn.

  TYPES: BEGIN OF ty_t001w,
           werks               TYPE        werks_d,
           name1(60)           TYPE        c,
           name2               TYPE        name2,
         END OF ty_t001w.

  TYPES: BEGIN OF ty_t161u,
           spras               TYPE        spras,
           frgkz               TYPE        frgkz,
           fkztx               TYPE        fkztx,
         END OF ty_t161u.

  TYPES: BEGIN OF ty_zmmatlgrp_desc,
           spras               TYPE        spras,
           matkl               TYPE        matkl,
           zcom_description    TYPE        zcom_description,
         END OF ty_zmmatlgrp_desc.

  TYPES: BEGIN OF ty_ekko,
           ebeln               TYPE        ebeln,
           lifnr               TYPE        elifn,
         END OF ty_ekko.

  TYPES: BEGIN OF ty_lfa1,
           lifnr               TYPE        lifnr,
           name1               TYPE        name1_gp,
         END OF ty_lfa1.

  TYPES: BEGIN OF ty_desvend,
           lifnr               TYPE        lifnr,
           name1               TYPE        name1_gp,
         END OF ty_desvend.

  TYPES: BEGIN OF ty_fixvend,
           lifnr               TYPE        lifnr,
           name1               TYPE        name1_gp,
         END OF ty_fixvend.

  TYPES:  BEGIN OF ty_cdhdr,
            mandant       TYPE cdhdr-mandant,
            objectclas    TYPE cdhdr-objectclas,
            objectid      TYPE eban-banfn,
            changenr      TYPE cdhdr-changenr,
            username      TYPE cdhdr-username,
            udate         TYPE cdhdr-udate,
            utime         TYPE cdhdr-utime,
            tcode         TYPE cdhdr-tcode,
            planchngnr    TYPE cdhdr-planchngnr,
            act_chngno    TYPE cdhdr-act_chngno,
            was_plannd    TYPE cdhdr-was_plannd,
            change_ind    TYPE cdhdr-change_ind,
            langu         TYPE cdhdr-langu,
            version       TYPE cdhdr-version,
        END OF ty_cdhdr.


  TYPES: BEGIN OF ty_output,
           banfn               TYPE        banfn,
           bnfpo               TYPE        bnfpo,
           loekz               TYPE        eloek,
           statu               TYPE        banst,
           frgkz               TYPE        frgkz,
           frgst               TYPE        frgst,
           ekgrp               TYPE        ekgrp,
           ernam               TYPE        ernam,
           erdat               TYPE        aedat,
           txz01               TYPE        txz01,
           matnr               TYPE        matnr,
           werks               TYPE        ewerk,
           lgort               TYPE        lgort_d,
           bednr               TYPE        bednr,
           matkl               TYPE        matkl,
           menge               TYPE        bamng,
           meins               TYPE        bamei,
           badat               TYPE        badat,
           lfdat               TYPE        eindt,
           waers               TYPE        waers,
           preis               TYPE        bapre,
           peinh               TYPE        epein,
           extvalue            TYPE        bapre,
           pstyp               TYPE        pstyp,
           knttp               TYPE        knttp,
           lifnr               TYPE        wlief,
           desname             TYPE        name1,
           flief               TYPE        flief,
           fixname             TYPE        name1,
           polifnr             TYPE        lifnr,
           actname             TYPE        name1,
           ebeln               TYPE        bstnr,
           ebelp               TYPE        bstpo,
           bedat               TYPE        bedat,
           bsmng               TYPE        bsmng,
           frggr               TYPE        frggr,
           spras               TYPE        spras,
           banpr               TYPE        banpr,
           vproz               TYPE        vproz,
*          dunit               TYPE        c,
           sakto               TYPE        saknr,
           kostl               TYPE        kostl,
           aufnr               TYPE        aufnr,
           wempf               TYPE        wempf,
           ablad               TYPE        ablad,
           prctr               TYPE        prctr,
           ps_psp_pnr          TYPE        ps_psp_pnr,
           dkobr               TYPE        abr_emp,
           name1               TYPE        name1,
           fkztx               TYPE        fkztx,
           zcom_description    TYPE        zcom_description,
           last_approver       TYPE        swl_aagt_n,
           forwarded_to        TYPE        ad_namtext,
           userid1             TYPE        actorid,
           username1           TYPE        ad_namtext,
           userid2             TYPE        actorid,
           username2           TYPE        ad_namtext,
           userid3             TYPE        actorid,
           username3           TYPE        ad_namtext,
           userid4             TYPE        actorid,
           username4           TYPE        ad_namtext,
           userid5             TYPE        actorid,
           username5           TYPE        ad_namtext,
           hdrtxt              TYPE        char255,
           itmtxt              TYPE        char255,
           itmnot              TYPE        char255,
           dlytxt              TYPE        char255,
           afnam               TYPE        afnam,
         END OF ty_output.

************************************************************************
*                 Internal Tables Declaration.                         *
************************************************************************
  DATA: it_ebkn           TYPE  TABLE OF  ty_ebkn,
        it_ekko           TYPE  TABLE OF  ty_ekko,
        it_t001w          TYPE  TABLE OF  ty_t001w,
        it_zmmatlgrp_desc TYPE  TABLE OF  ty_zmmatlgrp_desc,
        it_t161u          TYPE  TABLE OF  ty_t161u,
        it_lfa1           TYPE  TABLE OF  ty_lfa1,
        it_desvend        TYPE  TABLE OF  ty_desvend,
        it_output         TYPE  TABLE OF  ty_output,
        it_fixvend        TYPE  TABLE OF  ty_fixvend,
        it_zmordsettle    TYPE  TABLE OF  zmordsettle,
        it_taskfilter     TYPE  TABLE OF  swr_task,
        it_worklist       TYPE  TABLE OF  swr_wihdr,
        it_steplog_if     TYPE  TABLE OF  swp_logtab,
        it_agents         TYPE  TABLE OF  swworgtask,
        it_lines          TYPE  TABLE OF  tline,
        it_display        TYPE  TABLE OF  zmmr02867_display.


************************************************************************
*                 Program Varaibles Declaration.                       *
************************************************************************
  DATA: "wa_eban           TYPE  ty_eban,
        wa_ebkn           TYPE  ty_ebkn,
        wa_ekko           TYPE  ty_ekko,
        wa_t001w          TYPE  ty_t001w,
        wa_zmmatlgrp_desc TYPE  ty_zmmatlgrp_desc,
        wa_t161u          TYPE  ty_t161u,
        wa_lfa1           TYPE  ty_lfa1,
        wa_desvend        TYPE  ty_desvend,
        wa_fixvend        TYPE  ty_fixvend,
        wa_output         TYPE  zmmr10091_alv,
        wa_zmordsettle    TYPE  zmordsettle,
        gv_werks          TYPE  werks_d,
        gv_subrc          TYPE  sy-subrc,                   "#EC NEEDED
        gv_lines          TYPE  sy-tabix,
        wa_object_por     TYPE  sibflporb,
        wa_worklist       TYPE  swr_wihdr,
        wa_taskfilter     TYPE  swr_task,
        wa_steplog_if     TYPE  swp_logtab,
        wa_agents         TYPE  swworgtask,
        wa_user_addr      TYPE  addr3_val,
        wa_lines          TYPE  tline,
        wa_display        TYPE  zmmr02867_display.

  DATA : ls_selection TYPE rsparams.
  DATA: it_cdhdr        TYPE STANDARD TABLE OF cdhdr,
        it_cdhdr_temp   TYPE STANDARD TABLE OF cdhdr,
        it_cdhdr_temp1  TYPE STANDARD TABLE OF cdhdr,
        it_cdhdr_check  TYPE STANDARD TABLE OF cdhdr,
        is_cdhdr        LIKE LINE OF it_cdhdr,
        is_cdhdr_temp   LIKE LINE OF it_cdhdr,
        it_cdpos        TYPE STANDARD TABLE OF cdpos,
        it_cdpos_rlwrt  TYPE STANDARD TABLE OF cdpos,
        it_cdpos_menge  TYPE STANDARD TABLE OF cdpos,
        it_cdpos_preis  TYPE STANDARD TABLE OF cdpos,
        it_cdpos_peinh  TYPE STANDARD TABLE OF cdpos,
        it_cdpos_check  TYPE STANDARD TABLE OF cdpos,
        wa_cdhdr        LIKE LINE OF it_cdhdr,
        wa_cdpos         LIKE LINE OF it_cdpos,
        wa_cdpos_rlwrt  LIKE LINE OF it_cdpos,
        wa_cdpos_menge  LIKE LINE OF it_cdpos,
        wa_cdpos_preis  LIKE LINE OF it_cdpos,
        wa_cdpos_peinh  LIKE LINE OF it_cdpos,
        it_eban         TYPE STANDARD TABLE OF eban,
        it_eban_temp    TYPE STANDARD TABLE OF eban,
        is_eban         LIKE LINE OF it_eban,
        wa_eban         LIKE LINE OF it_eban,
        it_t024         TYPE STANDARD TABLE OF t024,
        is_t024         LIKE LINE OF it_t024,
        rg_banfn       TYPE RANGE OF eban-banfn ,
        rg_banfn_wa    LIKE LINE OF  rg_banfn,
        rg_fname       TYPE RANGE OF cdpos-fname,
        rg_fname_wa    LIKE LINE OF rg_fname,
        output_tab_wa  TYPE zmmr10091_alv,
        i_cdhdr        TYPE STANDARD TABLE OF ty_cdhdr.


  DATA:  lv_progress_percent    TYPE i,
         lv_progress_text(255)  TYPE c.

*Fill the Range table for the CDPOS Field Names

  rg_fname_wa-sign    = 'I'.
  rg_fname_wa-option  = 'EQ'.
  rg_fname_wa-low     = c_rlwrt.
  APPEND rg_fname_wa TO rg_fname .
  rg_fname_wa-low     = c_menge.
  APPEND rg_fname_wa TO rg_fname .
  rg_fname_wa-low     = c_preis.
  APPEND rg_fname_wa TO rg_fname .
  rg_fname_wa-low     = c_peinh.
  APPEND rg_fname_wa TO rg_fname .


*Display progress
  lv_progress_percent = '25'.
  lv_progress_text    = text-002.

  CALL METHOD show_progress(
    iv_progress = lv_progress_percent
    iv_text = lv_progress_text ).



  SELECT * FROM cdhdr INTO TABLE it_cdhdr
                           WHERE objectclas EQ 'BANF'
                           AND   udate      IN s_udate
                           AND   username   IN username
                           AND   objectid   IN objectid.

  IF it_cdhdr[] IS NOT INITIAL.

    SORT it_cdhdr.
*--Before Delete statement make a copy to temp table
*--we need to use this later to read CDPOS table
    it_cdhdr_temp[] = it_cdhdr[].
    DELETE ADJACENT DUPLICATES FROM it_cdhdr COMPARING objectid.
    i_cdhdr[] = it_cdhdr[].


*  Read records from EBAN
    SELECT * FROM eban
           INTO TABLE it_eban
           FOR ALL ENTRIES IN i_cdhdr
           WHERE banfn EQ i_cdhdr-objectid
*            WHERE banfn IN s_banfn
             AND bnfpo IN s_bnfpo
             AND loekz IN s_loekz
             AND statu IN s_statu
             AND estkz IN s_estkz
             AND frgkz IN s_frgkz
             AND frgst IN s_frgst
             AND ekgrp IN s_ekgrp
             AND ernam IN s_ernam
             AND werks IN s_werks
             AND ekorg IN s_ekorg
             AND bednr IN s_bednr
             AND badat IN s_badat
             AND lfdat IN s_lfdat
             AND erdat IN s_erdat
             AND pstyp IN s_pstyp
             AND knttp IN s_knttp
             AND lifnr IN s_lifnr
             AND banpr IN s_banpr.


  ELSE.
*Message
*No purchase requisitions were found that meets the selection criteria.
    MESSAGE i001. "DISPLAY LIKE 'E'.
    EXIT.


  ENDIF.



  IF it_eban[] IS NOT INITIAL.

    IF it_cdhdr_temp[] IS NOT INITIAL.
      SELECT * FROM cdpos  INTO TABLE it_cdpos
                            FOR ALL ENTRIES  IN it_cdhdr_temp
                            WHERE objectclas EQ it_cdhdr_temp-objectclas
                            AND   objectid   EQ it_cdhdr_temp-objectid
*                           AND   changenr   EQ it_cdhdr_temp-changenr
                            AND   tabname    EQ c_eban
                            AND   fname      EQ c_frgkz
                            AND   chngind    EQ c_update.

      IF it_cdpos[] IS NOT INITIAL.
        DELETE it_cdpos WHERE value_new NE 'A'.
        SORT it_cdpos DESCENDING BY objectid changenr DESCENDING tabkey ASCENDING.
        DELETE ADJACENT DUPLICATES FROM it_cdpos COMPARING objectid changenr tabkey.
      ENDIF.

    ENDIF.

*----Read records from EBKN
    SELECT banfn bnfpo vproz sakto kostl aufnr wempf ablad prctr
           ps_psp_pnr
           FROM ebkn
           INTO TABLE it_ebkn
           FOR ALL ENTRIES IN it_eban
           WHERE banfn = it_eban-banfn
             AND bnfpo = it_eban-bnfpo
             AND sakto IN s_sakto
             AND kostl IN s_kostl
             AND aufnr IN s_aufnr
             AND ps_psp_pnr IN pspsppnr.

*----Read records from T024
    SELECT * FROM t024
        INTO TABLE it_t024
        FOR ALL ENTRIES IN it_eban
        WHERE ekgrp = it_eban-ekgrp.

*----Read records from T001W
    SELECT werks name1 name2
           FROM t001w
           INTO TABLE it_t001w
           FOR ALL ENTRIES IN it_eban
           WHERE werks = it_eban-werks.

*----Read records from T161U
    SELECT spras frgkz fkztx
           FROM t161u
           INTO TABLE it_t161u
           FOR ALL ENTRIES IN it_eban
           WHERE spras = sy-langu
             AND frgkz = it_eban-frgkz.

*----Read records from ZMMATLGRP_DESC
    SELECT spras matkl zcom_description
           FROM zmmatlgrp_desc
           INTO TABLE it_zmmatlgrp_desc
           FOR ALL ENTRIES IN it_eban
           WHERE spras = sy-langu
             AND matkl = it_eban-matkl.

*----Read records from LFA1 for desired vendor
    SELECT lifnr name1
           FROM lfa1
           INTO TABLE it_desvend
           FOR ALL ENTRIES IN it_eban
           WHERE lifnr = it_eban-lifnr.

*----Read records from LFA1 for fixed vendor
    SELECT lifnr name1
           FROM lfa1
           INTO TABLE it_fixvend
           FOR ALL ENTRIES IN it_eban
           WHERE lifnr = it_eban-flief.

*-----Read records from EKKO for PO vendor
    SELECT ebeln lifnr
           FROM ekko
           INTO TABLE it_ekko
           FOR ALL ENTRIES IN it_eban
           WHERE ebeln = it_eban-ebeln.

    IF NOT it_ekko[] IS INITIAL.
      SELECT lifnr name1
             FROM lfa1
             INTO TABLE it_lfa1
             FOR ALL ENTRIES IN it_ekko
             WHERE lifnr = it_ekko-lifnr.
    ENDIF.

*Message
*No purchase requisitions were found that meets the selection criteria.
  ELSE.
    MESSAGE i001.
    EXIT.
  ENDIF.



*---Process data for output
* Build Output internal table.
  SORT it_eban[].
  DELETE it_eban WHERE banfn IS INITIAL.

  LOOP AT it_eban INTO wa_eban.


*Display progress
    lv_progress_percent = '55'.
    CONCATENATE text-001 wa_eban-banfn INTO lv_progress_text .

    CALL METHOD show_progress(
      iv_progress = lv_progress_percent
      iv_text = lv_progress_text ).




    CLEAR: wa_output,
           wa_ebkn.

    READ TABLE it_ebkn INTO wa_ebkn WITH KEY banfn = wa_eban-banfn
                                             bnfpo = wa_eban-bnfpo.
    IF sy-subrc = 0.

*Last approval date time userid
      DATA: wa_tabkey TYPE cdtabkey.
      CONCATENATE sy-mandt wa_eban-banfn wa_eban-bnfpo INTO wa_tabkey.

      CLEAR wa_cdpos.
      READ TABLE it_cdpos INTO wa_cdpos WITH KEY tabkey = wa_tabkey.
      IF sy-subrc EQ 0.
        CLEAR it_cdhdr_temp1.
        REFRESH it_cdhdr_temp1.
        SELECT * FROM cdhdr INTO TABLE it_cdhdr_temp1
                           WHERE objectclas EQ 'BANF'
*                           AND   udate      IN s_udate
*                           AND   username   IN username
                           AND   objectid   EQ wa_eban-banfn.

        CLEAR wa_cdhdr.
        READ TABLE it_cdhdr_temp1 INTO wa_cdhdr WITH KEY
                            changenr = wa_cdpos-changenr.
        IF sy-subrc EQ 0.
          wa_output-approver_id   = wa_cdhdr-username.
          wa_output-approval_date = wa_cdhdr-udate.
          wa_output-approval_time = wa_cdhdr-utime.

*--Check CDPOS Table for any changes after this approval date and time
*--IF YES Include this PR ELSE Delete from processing
*--rg_fname it_cdpos_check

          CLEAR   it_cdhdr_check.
          REFRESH it_cdhdr_check.
          SELECT * FROM cdhdr INTO TABLE it_cdhdr_check
                                WHERE objectclas  EQ 'BANF'
                                AND   objectid    EQ wa_eban-banfn
                                AND  ( udate GT wa_cdhdr-udate OR ( udate GE wa_cdhdr-udate AND utime GE wa_cdhdr-utime ) ).

          LOOP AT it_cdhdr_check INTO  is_cdhdr.
            IF is_cdhdr-udate EQ wa_cdhdr-udate AND is_cdhdr-utime EQ wa_cdhdr-utime.
*              DELETE it_cdhdr WHERE changenr = is_cdhdr-changenr.
              DELETE it_cdhdr_check .
            ENDIF.
          ENDLOOP.

          IF it_cdhdr_check[] IS NOT INITIAL.
            CLEAR it_cdpos_check.
            REFRESH it_cdpos_check.
            SELECT * FROM cdpos  INTO TABLE it_cdpos_check
                      FOR ALL ENTRIES  IN it_cdhdr_check
                      WHERE objectclas EQ it_cdhdr_check-objectclas
                                  AND   objectid   EQ it_cdhdr_check-objectid
                                  AND   changenr   EQ it_cdhdr_check-changenr
                                  AND   tabname    EQ c_eban
                                  AND   fname      IN rg_fname
                                  AND   chngind    EQ c_update
                                  AND   tabkey     EQ wa_tabkey.
          ELSE.
            CONTINUE.

          ENDIF.

*--Move it_cdpos_check to temp table for later use
*--Keep only MENGE changes
          CLEAR it_cdpos_menge.
          REFRESH it_cdpos_menge.
          it_cdpos_menge[] = it_cdpos_check[].
          DELETE it_cdpos_menge WHERE fname NE 'MENGE'.

*--Move it_cdpos_check to temp table for later use
*--Keep only PREIS changes
          CLEAR it_cdpos_preis.
          REFRESH it_cdpos_preis.
          it_cdpos_preis[] = it_cdpos_check[].
          DELETE it_cdpos_preis WHERE fname NE 'PREIS'.

*--Move it_cdpos_check to temp table for later use
*--Keep only PEINH changes
          CLEAR it_cdpos_peinh.
          REFRESH it_cdpos_peinh.
          it_cdpos_peinh[] = it_cdpos_check[].
          DELETE it_cdpos_peinh WHERE fname NE 'PEINH'.

*--Move it_cdpos_check to temp table for later use
*--Keep only RLWRT changes
          CLEAR it_cdpos_rlwrt.
          REFRESH it_cdpos_rlwrt.
          it_cdpos_rlwrt[] = it_cdpos_check[].
          DELETE it_cdpos_rlwrt WHERE fname NE 'RLWRT'.



          CALL FUNCTION 'SUSR_USER_ADDRESS_READ'
            EXPORTING
              user_name              = wa_cdhdr-username
            IMPORTING
              user_address           = wa_user_addr
            EXCEPTIONS
              user_address_not_found = 1
              OTHERS                 = 2.
          IF sy-subrc EQ 0.
            CONCATENATE wa_user_addr-name_first wa_user_addr-name_last
                         INTO wa_output-last_approver SEPARATED BY space.
          ENDIF.
        ENDIF.
      ENDIF.


*--MENGE Purchase requisition Quantity
      IF it_cdpos_menge[] IS NOT INITIAL.
        SORT it_cdpos_menge DESCENDING BY objectid changenr ASCENDING tabkey ASCENDING.
        READ TABLE it_cdpos_menge INTO wa_cdpos_menge WITH KEY tabkey = wa_tabkey.
        IF sy-subrc EQ 0.
          wa_output-menge_diff  = ( wa_eban-menge - wa_cdpos_menge-value_old ).
          wa_output-menge_appr_qty = wa_cdpos_menge-value_old.
          IF wa_cdpos_menge-value_old GT 0.
            wa_output-menge_per = ( wa_output-menge_diff / wa_cdpos_menge-value_old ) * 100.
          ENDIF.
        ENDIF.
      ELSE.
*If APPROVER_ID <> blank, then use the value from EBAN-MENGE for MENGE_APPR_QTY
        IF wa_output-approver_id IS NOT INITIAL.
          wa_output-menge_appr_qty = wa_eban-menge.
        ELSE.
          wa_output-menge_diff  = ( wa_eban-menge - wa_cdpos_menge-value_old ).
          wa_output-menge_appr_qty = wa_cdpos_menge-value_old.
        ENDIF.
      ENDIF.

*--PREIS Price in Purchase requisition
      IF it_cdpos_preis[] IS NOT INITIAL.
        SORT it_cdpos_preis DESCENDING BY objectid changenr ASCENDING tabkey ASCENDING.
        CLEAR wa_cdpos_preis.
        READ TABLE it_cdpos_preis INTO wa_cdpos_preis WITH KEY tabkey = wa_tabkey.
        IF sy-subrc EQ 0.
          wa_output-preis_diff  = ( wa_eban-preis - wa_cdpos_preis-value_old ).
          wa_output-preis_appr_item = wa_cdpos_preis-value_old.
          IF wa_cdpos_preis-value_old GT 0.
            wa_output-preis_per = ( wa_output-preis_diff / wa_cdpos_preis-value_old ) * 100.
          ENDIF.
        ENDIF.
      ELSE.
*If APPROVER_ID <> blank, then use the value from EBAN-PREIS for PREIS_APPR_ITEM
        IF wa_output-approver_id IS NOT INITIAL.
          wa_output-preis_appr_item = wa_eban-preis.
        ELSE.
          wa_output-preis_diff  = ( wa_eban-preis - wa_cdpos_preis-value_old ).
          wa_output-preis_appr_item = wa_cdpos_preis-value_old.
        ENDIF.
      ENDIF.


*--PEINH Price Unit
      IF it_cdpos_peinh[] IS NOT INITIAL.
        SORT it_cdpos_peinh DESCENDING BY objectid changenr ASCENDING tabkey ASCENDING.
        CLEAR wa_cdpos_peinh.
        READ TABLE it_cdpos_peinh INTO wa_cdpos_peinh WITH KEY tabkey = wa_tabkey.
        IF sy-subrc EQ 0.
          wa_output-peinh_diff  = ( wa_eban-peinh - wa_cdpos_peinh-value_old ).
          wa_output-peinh_appr_item = wa_cdpos_peinh-value_old.
          IF wa_cdpos_peinh-value_old GT 0.
            wa_output-peinh_per = ( wa_output-peinh_diff / wa_cdpos_peinh-value_old ) * 100.
          ENDIF.
        ENDIF.
      ELSE.
        wa_output-peinh_appr_item = wa_eban-peinh.
      ENDIF.


      wa_output-werks  =  wa_eban-werks.
      wa_output-banfn  =  wa_eban-banfn.
      wa_output-bnfpo  =  wa_eban-bnfpo.
      wa_output-banpr  =  wa_eban-banpr.
      wa_output-badat  =  wa_eban-badat.
      wa_output-ernam  =  wa_eban-ernam.
      wa_output-erdat  =  wa_eban-erdat.
      wa_output-loekz  =  wa_eban-loekz.
      wa_output-statu  =  wa_eban-statu.
      wa_output-frgkz  =  wa_eban-frgkz.
      wa_output-ekgrp  =  wa_eban-ekgrp.
      wa_output-matnr  =  wa_eban-matnr.
      wa_output-txz01  =  wa_eban-txz01.
      wa_output-matkl  =  wa_eban-matkl.
*      wa_output-lgort  =  wa_eban-lgort.
      wa_output-bednr  =  wa_eban-bednr.
      wa_output-menge  =  wa_eban-menge.
      wa_output-meins  =  wa_eban-meins.
      wa_output-lfdat  =  wa_eban-lfdat.
      wa_output-preis  =  wa_eban-preis.
      wa_output-rlwrt  =  wa_eban-rlwrt.
      wa_output-peinh  =  wa_eban-peinh.
      wa_output-afnam  =  wa_eban-afnam.
      wa_output-waers  =  wa_eban-waers.
      wa_output-pstyp  =  wa_eban-pstyp.
      wa_output-knttp  =  wa_eban-knttp.
      wa_output-ebeln  =  wa_eban-ebeln.
      wa_output-ebelp  =  wa_eban-ebelp.
      wa_output-bedat  =  wa_eban-bedat.
      wa_output-bsmng  =  wa_eban-bsmng.
      wa_output-frggr  =  wa_eban-frggr.
      wa_output-frgst  =  wa_eban-frgst.
      wa_output-lifnr  =  wa_eban-lifnr.
*        IF wa_eban-vrtkz = '1'.
*        wa_output-dunit = '%'.
*      ELSEIF wa_eban-vrtkz = '2'.
*        wa_output-dunit = wa_eban-meins.
*      ENDIF.
*      wa_output-dunit = wa_eban-meins.
      wa_output-frggr = wa_eban-frggr.
      wa_output-frgst = wa_eban-frgst.
      wa_output-ekorg = wa_eban-ekorg.
      wa_output-estkz = wa_eban-estkz.

*Based on Eban-erdat(Changed On Date) Find the the Changed By From CDHDR
      CLEAR is_cdhdr_temp.
*      READ TABLE it_cdhdr_temp INTO is_cdhdr_temp WITH KEY
*                                objectid = wa_output-banfn
*                                udate    = wa_output-erdat.
*      IF sy-subrc EQ 0.
*        wa_output-username  = is_cdhdr_temp-username.
*      ENDIF.
      CLEAR wa_output-username.
      SELECT SINGLE username FROM cdhdr INTO wa_output-username
                                WHERE objectclas EQ 'BANF'
                                AND   objectid   EQ wa_output-banfn
                                AND   udate      EQ wa_output-erdat.



      IF wa_output-statu = 'B'.
        wa_output-qtydiff = ( wa_output-menge - wa_output-bsmng ).
      ENDIF.

      IF wa_eban-peinh > 0.
*Single Unit Price
        wa_output-sing_preis = ( wa_eban-preis / wa_eban-peinh ).
        wa_output-rlwrt_itm  = wa_eban-menge * wa_output-sing_preis.
        wa_output-extvalue   = ( wa_eban-menge * wa_eban-preis ) /
                              wa_eban-peinh.
      ELSE.
        CLEAR wa_output-extvalue.
        CLEAR wa_output-sing_preis.
      ENDIF.

*-- Approved Single Unit Price APR_SING_UPR
      IF wa_output-peinh_appr_item > 0.
        wa_output-apr_sing_upr = ( wa_output-preis_appr_item / wa_output-peinh_appr_item ).
      ENDIF.

*--Diff Single Unit Price  SING_PREIS_DIFF
      wa_output-sing_preis_diff = ( wa_output-sing_preis - wa_output-apr_sing_upr ).


*-- % Diff Single Unit Price SING_PREIS_PER
      IF wa_output-apr_sing_upr > 0.
        wa_output-sing_preis_per = ( wa_output-sing_preis_diff / wa_output-apr_sing_upr ) * 100.
      ENDIF.

*RLWRT DIFFERENCE
      wa_output-rlwrt_diff  = ( wa_output-extvalue - wa_output-rlwrt ).
      DATA : lc_vproz TYPE vproz.
      IF wa_eban-rlwrt GT 0.
        wa_output-rlwrt_per = ( wa_output-rlwrt_diff / wa_eban-rlwrt ) * 100.
        CLEAR lc_vproz.
      ENDIF.


      wa_output-sakto       =  wa_ebkn-sakto.
      wa_output-kostl       =  wa_ebkn-kostl.
      wa_output-aufnr       =  wa_ebkn-aufnr.
      wa_output-ps_psp_pnr  =  wa_ebkn-ps_psp_pnr.
      wa_output-ablad       =  wa_ebkn-ablad.
      wa_output-prctr       =  wa_ebkn-prctr.
      wa_output-wempf       =  wa_ebkn-wempf.
      wa_output-vproz       =  wa_ebkn-vproz.


      CLEAR : is_t024.
      READ TABLE it_t024 INTO is_t024 WITH KEY
                      ekgrp = wa_eban-ekgrp.
      IF sy-subrc = 0.
        wa_output-eknam = is_t024-eknam.
      ENDIF.

      CLEAR : wa_t001w.
      READ TABLE it_t001w INTO wa_t001w WITH KEY
                      werks = wa_eban-werks.
      IF sy-subrc = 0.
        CONCATENATE wa_t001w-name1 wa_t001w-name2 INTO wa_output-name1
        SEPARATED BY space.
        CONCATENATE wa_t001w-name1 wa_t001w-name2 INTO wa_t001w-name1
        SEPARATED BY space.
*        wa_output-name1 = wa_t001w-name1.
      ENDIF.
      READ TABLE it_t161u INTO wa_t161u WITH KEY
                      frgkz = wa_eban-frgkz.
      IF sy-subrc = 0.
        wa_output-fkztx = wa_t161u-fkztx.
      ENDIF.
      READ TABLE it_zmmatlgrp_desc INTO wa_zmmatlgrp_desc
                          WITH KEY matkl = wa_eban-matkl.
      IF sy-subrc = 0.
        wa_output-zcom_description =
                  wa_zmmatlgrp_desc-zcom_description.
      ENDIF.

*    Desired Vendor
      wa_output-lifnr  = wa_eban-lifnr.
*    Desired Vendor Name
      READ TABLE it_desvend INTO wa_desvend WITH KEY
                                  lifnr = wa_eban-lifnr.
      IF sy-subrc = 0.
        wa_output-desname = wa_desvend-name1.
      ENDIF.
*    fixed Vendor
      wa_output-flief  = wa_eban-flief.
*    fixed Vendor Name
      READ TABLE it_fixvend INTO wa_fixvend WITH KEY
                                  lifnr = wa_eban-flief.
      IF sy-subrc = 0.
        wa_output-fixname = wa_fixvend-name1.
      ENDIF.
*   PO vendor
      READ TABLE it_ekko INTO wa_ekko WITH KEY
                                  ebeln = wa_eban-ebeln.
      IF sy-subrc = 0.
        wa_output-polifnr = wa_ekko-lifnr.
      ENDIF.
*    PO Vendor Name
      READ TABLE it_lfa1 INTO wa_lfa1 WITH KEY
                                  lifnr = wa_ekko-lifnr.
      IF sy-subrc = 0.
        wa_output-actname = wa_lfa1-name1.
      ENDIF.

    ENDIF.


    APPEND wa_output TO output_tab.
    CLEAR: wa_output,
           wa_cdpos_menge,
           wa_cdpos_preis,
           wa_cdpos_peinh.
  ENDLOOP.

  DELETE output_tab WHERE banfn IS INITIAL.
*--If No financial value change Delete from the processing
*--RLWRT_DIFF
*--MENGE_DIFF
*--PREIS_DIFF
*--PEINH_DIFF
*--SING_PREIS_DIFF
  DELETE output_tab WHERE
  ( rlwrt_diff IS INITIAL AND
    menge_diff IS INITIAL AND
    preis_diff IS INITIAL AND
    peinh_diff IS INITIAL AND
    sing_preis_diff IS INITIAL ).





ENDMETHOD.


METHOD show_progress.

  CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
    EXPORTING
      percentage = iv_progress
      text       = iv_text.

ENDMETHOD.
ENDCLASS.

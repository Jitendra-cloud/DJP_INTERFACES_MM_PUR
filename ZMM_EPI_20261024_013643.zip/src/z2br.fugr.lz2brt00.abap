*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 2002.04.29 at 14:09:04 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMBATCHR........................................*
DATA:  BEGIN OF STATUS_ZMBATCHR                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMBATCHR                      .
CONTROLS: TCTRL_ZMBATCHR
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMBATCHR                      .
TABLES: ZMBATCHR                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

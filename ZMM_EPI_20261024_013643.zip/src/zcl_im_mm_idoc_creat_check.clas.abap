class ZCL_IM_MM_IDOC_CREAT_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_EX_IDOC_CREATION_CHECK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_MM_IDOC_CREAT_CHECK IMPLEMENTATION.


  METHOD if_ex_idoc_creation_check~idoc_data_check.
************************************************************************
* Created: 02/2017                                                     *
* Author:  Helena Malkowska                                            *
*______________________________________________________________________*
* This BAdi implementation of IDOC_DATA_CHECK allows to create an IDoc *
* or not based on the control record and the IDoc data.                *
*                                                                      *
* Originally implemented for logical message type - ZMM_MAT_WITRON     *
* for Material Master interface for WITRON project.                    *
*______________________________________________________________________*
* Change History:                                                      *
*     Programmer      Date     Req. #             Action               *
* ================  ======== ========== ===============================*
* Helena Malkowska  02/2017  E0V 31275  Initial Transport              *
*                                                                      *
* Kiranmaye         1/25/2022 2000000591-Donot create IDoc*
*                   for ECM_ALE if Company code segment is missing     *
************************************************************************


    DATA: ls_e1maram   TYPE e1maram.
    DATA: ls_idoc_data TYPE edidd.
    DATA: lv_matnr     TYPE matnr.
    DATA: lv_matnrp    TYPE matnr.
    DATA: ls_zmmfld    TYPE zmmfld.
    DATA: lv_werks     TYPE werks.

    DATA:lv_lifnr    TYPE lfa1-lifnr,
         ls_e1adrmas TYPE e1adrmas.

    CASE idoc_control-mestyp.

      WHEN 'ZMM_MAT_WITRON'.

        LOOP AT idoc_data INTO ls_idoc_data.

          CASE ls_idoc_data-segnam.
            WHEN 'E1MARAM'.
              ls_e1maram = ls_idoc_data-sdata.
              "get material number from idoc data
              lv_matnr = ls_e1maram-matnr.
              EXIT.
          ENDCASE.

        ENDLOOP.

        "read ZMMFLD record for Partner number to get Plant
        SELECT *  UP TO 1 ROWS FROM zmmfld INTO ls_zmmfld
          WHERE key1 = 'I10277'
            AND value2 = idoc_control-rcvprn
            AND key3 = 'OTHER VALUES'.
        ENDSELECT.

        IF sy-subrc = 0.
          lv_werks = ls_zmmfld-key2.

          "check if material is extended to plant
          SELECT SINGLE matnr FROM marc INTO lv_matnrp
            WHERE matnr = lv_matnr AND
                  werks = lv_werks.

          IF sy-subrc <> 0.
            "IDoc will not be created
            create_idoc = space.
          ENDIF.

        ELSE.
          "IDoc will not be created
          create_idoc = space.
        ENDIF.
* start of kadhik1  S 2000000591
      WHEN 'CREMAS'.
        IF idoc_control-rcvprn = 'ECM_ALE'.

          IF NOT line_exists( idoc_data[ segnam = 'E1LFB1M' ] ).
            create_idoc = space.
          ENDIF.
        ENDIF.
* end of kadhik1  S 2000000591


*Soc by PBOMMIR on 16.Feb.2024 for SCTASK0038019
      WHEN 'ADRMAS'.
        IF idoc_control-rcvprn = 'ECM_ALE'.
           READ TABLE idoc_data INTO ls_idoc_data WITH KEY  segnam = 'E1ADRMAS'.
          IF sy-subrc = 0 AND ls_idoc_data-sdata+10(1) = 'E'.
            ls_e1adrmas =  ls_idoc_data-sdata.
            CLEAR:lv_lifnr.
            lv_lifnr = ls_e1adrmas-obj_id.
            CONDENSE lv_lifnr NO-GAPS.
            SELECT SINGLE lifnr, ktokk FROM lfa1 INTO @DATA(ls_ven_agp) WHERE  lifnr = @lv_lifnr
                                                                        AND    ktokk = 'EMPL'.
            IF sy-subrc = 0.
              create_idoc = space.
            ENDIF.
          ENDIF.
        ENDIF.
*Eoc by PBOMMIR on 16.Feb.2024 for SCTASK0038019


    ENDCASE.

  ENDMETHOD.
ENDCLASS.

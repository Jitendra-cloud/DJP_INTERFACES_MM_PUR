*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME10022_TICKETS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME10022_TICKETS    .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 01/17/2003 at 16:51:33 by user JLIN
*---------------------------------------------------------------------*
*...processing: ZMM_EQUIP_NO....................................*
DATA:  BEGIN OF STATUS_ZMM_EQUIP_NO                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_EQUIP_NO                  .
CONTROLS: TCTRL_ZMM_EQUIP_NO
            TYPE TABLEVIEW USING SCREEN '0006'.
*.........table declarations:.................................*
TABLES: *ZMM_EQUIP_NO                  .
TABLES: ZMM_EQUIP_NO                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZLIFNR_F4_HELPTOP.                " Global Data
  INCLUDE LZLIFNR_F4_HELPUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZLIFNR_F4_HELPF...                " Subroutines
* INCLUDE LZLIFNR_F4_HELPO...                " PBO-Modules
* INCLUDE LZLIFNR_F4_HELPI...                " PAI-Modules
* INCLUDE LZLIFNR_F4_HELPE...                " Events
* INCLUDE LZLIFNR_F4_HELPP...                " Local class implement.
* INCLUDE LZLIFNR_F4_HELPT99.                " ABAP Unit tests

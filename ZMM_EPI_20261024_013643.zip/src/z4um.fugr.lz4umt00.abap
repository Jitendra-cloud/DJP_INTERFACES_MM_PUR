*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMUOM_4_7_UNIQUE................................*
DATA:  BEGIN OF STATUS_ZMUOM_4_7_UNIQUE              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMUOM_4_7_UNIQUE              .
CONTROLS: TCTRL_ZMUOM_4_7_UNIQUE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMUOM_4_7_UNIQUE              .
TABLES: ZMUOM_4_7_UNIQUE               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

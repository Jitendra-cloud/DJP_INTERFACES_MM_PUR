*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMI02212_PORG...................................*
DATA:  BEGIN OF STATUS_ZMI02212_PORG                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMI02212_PORG                 .
CONTROLS: TCTRL_ZMI02212_PORG
            TYPE TABLEVIEW USING SCREEN '0002'.
*...processing: ZMM_LAST_RUN....................................*
DATA:  BEGIN OF STATUS_ZMM_LAST_RUN                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_LAST_RUN                  .
CONTROLS: TCTRL_ZMM_LAST_RUN
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMI02212_PORG                 .
TABLES: *ZMM_LAST_RUN                  .
TABLES: ZMI02212_PORG                  .
TABLES: ZMM_LAST_RUN                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

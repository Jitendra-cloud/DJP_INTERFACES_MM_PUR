*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMCHKREC.......................................*
DATA:  BEGIN OF STATUS_ZMMCHKREC                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMCHKREC                     .
CONTROLS: TCTRL_ZMMCHKREC
            TYPE TABLEVIEW USING SCREEN '0100'.
*.........table declarations:.................................*
TABLES: *ZMMCHKREC                     .
TABLES: ZMMCHKREC                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

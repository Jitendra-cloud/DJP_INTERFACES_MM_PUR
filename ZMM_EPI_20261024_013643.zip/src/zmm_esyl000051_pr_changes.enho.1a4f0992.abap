"Name: \FU:MEREQBADI_FS_ITEM\SE:END\EI
ENHANCEMENT 0 ZMM_ESYL000051_PR_CHANGES.
*
*Begin of changes mkasina/S0VK907604/ 2000001885
*Note: grey of fields for service Pr when ME51N by selecting document type ‘SRVC’ and item category ‘D’
*grey out fields Agreement in source of supply tab
*    DATA:gv_bsart TYPE bsart.
*    if ( sy-tcode = 'ME51N' OR sy-tcode = 'ME52N' OR sy-tcode = 'ME53N' ).
*      IMPORT gv_bsart TO gv_bsart FROM  MEMORY ID 'LV_DOCTYP'.
*      SELECT * FROM zmmfld INTO TABLE @DATA(lt_zmmfld)
*             WHERE key1 = 'SERVICEPR'
*             AND   key2 = 'BSART'
*             AND   key3 = 'PSTYP'
*             AND   value2 = @gv_bsart.
*IF sy-subrc = 0 OR sy-subrc <> 0.
*      READ TABLE ch_fieldselection ASSIGNING FIELD-SYMBOL(<fs_fsel>) WITH TABLE KEY metafield = 312.
*    IF sy-subrc IS INITIAL.
*      <fs_fsel>-fieldstatus = '*'. " Display
*    ENDIF.
*
*    READ TABLE ch_fieldselection  ASSIGNING <fs_fsel> WITH TABLE KEY metafield = 22.
*    IF sy-subrc IS INITIAL.
*      <fs_fsel>-fieldstatus = '*'. " Display
*    ENDIF.
*    ENDIF.
*    ENDIF.
*Begin of changes mkasina/S0VK907604/ 2000001885

ENDENHANCEMENT.

*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMMATLGRP_NOPO..................................*
DATA:  BEGIN OF STATUS_ZMMATLGRP_NOPO                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMMATLGRP_NOPO                .
CONTROLS: TCTRL_ZMMATLGRP_NOPO
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMMATLGRP_NOPO                .
TABLES: ZMMATLGRP_NOPO                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

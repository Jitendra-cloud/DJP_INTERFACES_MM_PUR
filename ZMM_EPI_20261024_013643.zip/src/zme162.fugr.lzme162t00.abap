*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 09/06/2002 at 10:51:46 by user JPIERI
*---------------------------------------------------------------------*
*...processing: ZME162_NXT_NBR..................................*
DATA:  BEGIN OF STATUS_ZME162_NXT_NBR                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME162_NXT_NBR                .
CONTROLS: TCTRL_ZME162_NXT_NBR
            TYPE TABLEVIEW USING SCREEN '0003'.
*.........table declarations:.................................*
TABLES: *ZME162_NXT_NBR                .
TABLES: ZME162_NXT_NBR                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

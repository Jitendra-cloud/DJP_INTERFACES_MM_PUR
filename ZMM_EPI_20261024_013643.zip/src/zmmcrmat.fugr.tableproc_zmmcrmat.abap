*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMMCRMAT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMMCRMAT            .

  PERFORM TABLEPROC.

ENDFUNCTION.

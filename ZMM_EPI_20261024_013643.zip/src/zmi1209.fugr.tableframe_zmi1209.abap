*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZMI1209
*   generation date: 2003.05.20 at 13:28:58 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZMI1209            .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

class ZCL_CA_DICTIONARY definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ty_po_item,
        concatenated_field TYPE char35,
      END OF ty_po_item .
  types:
    tr_po_item TYPE RANGE OF ty_po_item .
  types:
    "SELECT-OPTIONS has maximum size limit of 45 characters
    BEGIN OF ty_pir,
        concatenated_field TYPE char45,
      END OF ty_pir .
  types:
    tr_pir TYPE RANGE OF ty_pir .

  constants GC_PO_PACKAGE_SIZE type I value 1000 ##NO_TEXT.
  constants GC_PIR_PACKAGE_SIZE type I value 1000 ##NO_TEXT.
  constants GC_I10524_PACKAGE_SIZE type I value 30000 ##NO_TEXT.
protected section.
private section.
ENDCLASS.



CLASS ZCL_CA_DICTIONARY IMPLEMENTATION.
ENDCLASS.

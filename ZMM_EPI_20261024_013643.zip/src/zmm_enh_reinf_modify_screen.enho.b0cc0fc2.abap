"Name: \PR:SAPLMLSP\EX:MODIFY_SCREEN_01\EN:DIMP_GENERAL_SAPLMLSP\SE:BEGIN\EI
ENHANCEMENT 0 ZMM_ENH_REINF_MODIFY_SCREEN.

********* CMS 32804 - HMALKOW - start ********
"Changes for Brazil REINF Service Codes
   if ( sy-tcode = 'ME22N' or sy-tcode = 'ME21N' or sy-tcode = 'ME23N' ) and ( screen-name = 'ESLL-USERF1_NUM' ).
    screen-invisible = 0.
    screen-value_help = 1.
    screen-input = 1.
  endif.
********* CMS 32804 - HMALKOW - end ********

ENDENHANCEMENT.

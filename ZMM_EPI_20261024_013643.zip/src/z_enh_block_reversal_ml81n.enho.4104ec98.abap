"Name: \PR:SAPLMLSR\FO:ACCEPT_FLAG\SE:BEGIN\EI
ENHANCEMENT 0 Z_ENH_BLOCK_REVERSAL_ML81N.
*-->Begin of Change CMS-28712 SMITHAI E0VK9A0CX1 06.08.2015
If sy-tcode = 'ML81N'.
* Pruefung/Warnung Storno   "Test / Alarm Cancellation
  if not storno is initial.
*   peRFORM CHECK_COMPRESS. "No cancellation of the compressed entry sheets
    if betz-remng ne 0.
      message E388(11).
    endif.
  endif.
endif.
*<--End of Change CMS-28712 SMITHAI E0VK9A0CX1 06.08.2015
ENDENHANCEMENT.

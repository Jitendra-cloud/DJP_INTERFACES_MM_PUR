FUNCTION-POOL ZLIFNR_F4_HELP.               "MESSAGE-ID ..

* INCLUDE LZLIFNR_F4_HELPD...                " Local class definition

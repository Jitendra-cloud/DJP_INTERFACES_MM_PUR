FUNCTION zebeln_f4_help.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  TABLES
*"      SHLP_TAB TYPE  SHLP_DESCT
*"      RECORD_TAB STRUCTURE  SEAHLPRES
*"  CHANGING
*"     REFERENCE(SHLP) TYPE  SHLP_DESCR
*"     REFERENCE(CALLCONTROL) TYPE  DDSHF4CTRL
*"----------------------------------------------------------------------



*callcontrol-step = 'SELONE' -> This step is only called for
*  collective search helps.
*callcontrol-step = 'PRESEL' -> This step allows you, to influence the
*  selection conditions before they are displayed
*callcontrol-STEP = 'SELECT' -> This step may be used to overtake the
*  data selection completely.
*callcontrol-step = 'DISP' -> This step may be used to overtake the
*  DATA selection completely.
*callcontrol-step = 'EXIT' -> To exit from the block.
  TYPES : BEGIN OF ty_ebeln,
          ebeln TYPE ebeln,
          END OF ty_ebeln.

  DATA : lt_ekko TYPE STANDARD TABLE OF ty_ebeln,
         lw_ekko LIKE LINE OF lt_ekko.
  TYPES: BEGIN OF ty_ebeln1,
           sign TYPE  tvarv_sign,
    option  TYPE  tvarv_opti,
    low TYPE  rsdsselop_,
    high  TYPE  rsdsselop_,
           END OF ty_ebeln1.
  DATA lr_ebeln TYPE TABLE OF ty_ebeln1." ddshselops.
  DATA: lw_ebeln TYPE ty_ebeln1.


  DATA : ls_ddshselopt TYPE ddshselopt.

  IF callcontrol-step <> 'SELONE' AND
     callcontrol-step <> 'SELECT' AND
     callcontrol-step <> 'DISP'.
    EXIT.
  ENDIF.

  IF callcontrol-step = 'SELONE'.
    EXIT.
  ENDIF.

  IF callcontrol-step = 'SELECT'.

    READ TABLE shlp-selopt INTO ls_ddshselopt INDEX 1.

    IF sy-subrc = 0.

      lw_ebeln-sign   =  ls_ddshselopt-sign.
      lw_ebeln-option =  ls_ddshselopt-option.
      lw_ebeln-low    =  ls_ddshselopt-low.
      lw_ebeln-high   =  ls_ddshselopt-high.

      APPEND lw_ebeln TO lr_ebeln.

    ENDIF.


    SELECT ebeln UP TO callcontrol-maxrecords ROWS
      FROM ekko INTO TABLE lt_ekko
      WHERE ebeln IN lr_ebeln.

    CALL FUNCTION 'F4UT_RESULTS_MAP'
  TABLES
    shlp_tab          = shlp_tab
    record_tab        = record_tab
    source_tab        = lt_ekko
  CHANGING
    shlp              = shlp
    callcontrol       = callcontrol
  EXCEPTIONS
    illegal_structure = 1
    OTHERS            = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
    callcontrol-step = 'DISP'.
  ENDIF.

  IF callcontrol-step = 'DISP'.
    EXIT.
  ENDIF.

ENDFUNCTION.

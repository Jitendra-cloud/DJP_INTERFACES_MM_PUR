*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMRDF...........................................*
DATA:  BEGIN OF STATUS_ZMRDF                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMRDF                         .
CONTROLS: TCTRL_ZMRDF
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMRDF                         .
TABLES: ZMRDF                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

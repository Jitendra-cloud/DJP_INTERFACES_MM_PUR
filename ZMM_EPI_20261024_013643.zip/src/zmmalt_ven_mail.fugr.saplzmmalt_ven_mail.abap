*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMMALT_VEN_MAILTOP.               " Global Data
  INCLUDE LZMMALT_VEN_MAILUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMMALT_VEN_MAILF...               " Subroutines
* INCLUDE LZMMALT_VEN_MAILO...               " PBO-Modules
* INCLUDE LZMMALT_VEN_MAILI...               " PAI-Modules
* INCLUDE LZMMALT_VEN_MAILE...               " Events
* INCLUDE LZMMALT_VEN_MAILP...               " Local class implement.
* INCLUDE LZMMALT_VEN_MAILT99.               " ABAP Unit tests
  INCLUDE LZMMALT_VEN_MAILF00                     . " subprograms
  INCLUDE LZMMALT_VEN_MAILI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

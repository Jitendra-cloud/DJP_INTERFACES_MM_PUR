FUNCTION-POOL ZME130_ZH_FLDS             MESSAGE-ID SV.

* INCLUDE LZME130_ZH_FLDSD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZME130_ZH_FLDST00                      . "view rel. data dcl.

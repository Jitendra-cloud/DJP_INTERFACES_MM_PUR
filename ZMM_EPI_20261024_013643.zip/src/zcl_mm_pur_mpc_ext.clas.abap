CLASS zcl_mm_pur_mpc_ext DEFINITION
  PUBLIC
  INHERITING FROM zcl_mm_pur_mpc
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    TYPES:
      BEGIN OF ts_poit_posch,
        include TYPE zcl_mm_pur_mpc=>ts_poitem.
    TYPES:
      toschedule TYPE STANDARD TABLE OF zcl_mm_pur_mpc=>ts_poitem WITH DEFAULT KEY,
      END OF ts_poit_posch,
      tt_poit_posch TYPE STANDARD TABLE OF ts_poit_posch WITH DEFAULT KEY,

      BEGIN OF ts_po_poit_posch.
        INCLUDE TYPE zcl_mm_pur_mpc=>ts_pohead.
      TYPES:
        toitem TYPE tt_poit_posch,
      END OF ts_po_poit_posch.

    METHODS define
        REDEFINITION .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_MM_PUR_MPC_EXT IMPLEMENTATION.


  METHOD define.
*  model->set_no_conversion( abap_true ).
    super->define( ).

    model->set_schema_namespace( 'ZMM_PUR' ).

* Turn off the conversion for IDs to keep the leeding zeros. This provides the identical IDs as on the database.
*    model->get_entity_type( 'Plant' )->get_property( 'PlantCode' )->disable_conversion( ).
    model->get_entity_type( 'Partner' )->get_property( 'Vendor' )->disable_conversion( ).
    model->get_entity_type( 'Material' )->get_property( 'MaterialNo' )->disable_conversion( ).
    model->get_entity_type( 'POHead' )->get_property( 'OrderNo' )->disable_conversion( ).
    model->get_entity_type( 'POHead' )->get_property( 'Vendor' )->disable_conversion( ).
    model->get_entity_type( 'POItem' )->get_property( 'OrderNo' )->disable_conversion( ).
    model->get_entity_type( 'POItem' )->get_property( 'ItemNo' )->disable_conversion( ).
    model->get_entity_type( 'POItem' )->get_property( 'MaterialNo' )->disable_conversion( ).
    model->get_entity_type( 'POSchedule' )->get_property( 'OrderNo' )->disable_conversion( ).
    model->get_entity_type( 'POSchedule' )->get_property( 'ItemNo' )->disable_conversion( ).
  ENDMETHOD.
ENDCLASS.

*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZME162
*   generation date: 2003.05.12 at 15:52:49 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZME162             .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

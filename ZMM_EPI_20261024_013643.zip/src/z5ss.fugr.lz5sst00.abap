*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME1267_SORT_SEQ................................*
DATA:  BEGIN OF STATUS_ZME1267_SORT_SEQ              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME1267_SORT_SEQ              .
CONTROLS: TCTRL_ZME1267_SORT_SEQ
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME1267_SORT_SEQ              .
TABLES: ZME1267_SORT_SEQ               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

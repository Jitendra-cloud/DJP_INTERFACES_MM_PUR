*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZE162...........................................*
DATA:  BEGIN OF STATUS_ZE162                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZE162                         .
CONTROLS: TCTRL_ZE162
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZE162                         .
TABLES: ZE162                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

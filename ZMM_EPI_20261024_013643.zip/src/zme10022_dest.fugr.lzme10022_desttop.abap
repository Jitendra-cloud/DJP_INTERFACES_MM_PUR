FUNCTION-POOL ZME10022_DEST              MESSAGE-ID SV.

* INCLUDE LZME10022_DESTD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZME10022_DESTT00                       . "view rel. data dcl.

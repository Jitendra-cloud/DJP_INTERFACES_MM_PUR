class ZCL_E10310_RECOVERED_FIBER definition
  public
  final
  create public .

public section.

  data CL_INPUT_TABLE type ZMM_E10310_INPUT_TAB .
  data CL_RETURN type TT_BAPIRET2 .
  data CL_CALLING_PRG type SYST-REPID .

  methods CONSTRUCTOR
    importing
      value(INPUT_TAB) type ZMM_E10310_INPUT_TAB optional
      value(ID_CALLING_PRG) type SYST-REPID optional .
  methods PROCESS_EXIT
    returning
      value(RETURN) type TT_BAPIRET2 .
  methods PROCESS_E02912
    exporting
      value(RETURN) type TT_BAPIRET2
      value(OUTPUT_TAB) type ZMM_E10310_INPUT_TAB .
protected section.
private section.
ENDCLASS.



CLASS ZCL_E10310_RECOVERED_FIBER IMPLEMENTATION.


METHOD constructor.


  DATA:rg_ekorg     TYPE RANGE OF ekko-ekorg,
       rg_bwlvs     TYPE RANGE OF mseg-bwart,
       rg_vgart     TYPE RANGE OF mkpf-vgart,
       rg_call_ext  TYPE RANGE OF syst-repid,
       rg_call_prg  TYPE RANGE OF syst-repid.

  DATA: rg_ekorg_wa    LIKE LINE OF rg_ekorg,
        rg_bwlvs_wa    LIKE LINE OF rg_bwlvs,
        rg_vgart_wa    LIKE LINE OF rg_vgart,
        rg_call_prg_wa LIKE LINE OF rg_call_prg.

  DATA: it_eban           TYPE STANDARD TABLE OF eban,
        it_mkpf           TYPE STANDARD TABLE OF mkpf,
        ls_mkpf           TYPE mkpf,
        it_mseg           TYPE STANDARD TABLE OF mseg,
        ls_mseg           TYPE mseg,
        it_ekko           TYPE STANDARD TABLE OF ekko,
        ls_ekko           TYPE ekko,
        it_ekpo           TYPE STANDARD TABLE OF ekpo,
        ls_ekpo           TYPE ekpo,
        ls_input_str      TYPE zmm_e10310_input,
        input_str         TYPE zmm_e10310_input,
        it_return         TYPE STANDARD TABLE OF bapiret2,
        gc_vgart          TYPE vgart,
        gc_bwlvs1         TYPE bwlvs,
        gc_bwlvs2         TYPE bwlvs,
        ls_return         TYPE bapiret2,
        it_zmmfld_ekorg   TYPE STANDARD TABLE OF zmmfld,
        it_zmmfld_bwlvs   TYPE STANDARD TABLE OF zmmfld,
        it_zmmfld_vgart   TYPE STANDARD TABLE OF zmmfld,
        wa_zmmfld_bwlvs   TYPE zmmfld,
        wa_zmmfld_ekorg   TYPE zmmfld,
        wa_zmmfld_vgart   TYPE zmmfld.

  cl_calling_prg = id_calling_prg.

*---Fill the Calling Exit Programs
  rg_call_prg_wa-sign   = 'I'.
  rg_call_prg_wa-option = 'EQ'.
  rg_call_prg_wa-low    = 'MIGO_EXIT'.
  APPEND rg_call_prg_wa TO rg_call_ext.
  rg_call_prg_wa-low    = 'MB01_EXIT'.
  APPEND rg_call_prg_wa TO rg_call_ext.
  rg_call_prg_wa-low    = 'MBST_EXIT'.
  APPEND rg_call_prg_wa TO rg_call_ext.
  rg_call_prg_wa-low    = 'ZMME04202'.
  APPEND rg_call_prg_wa TO rg_call_ext.

*** Start modification by JWILL68 on 5/31/2018 CMS# 33255
* Add New exit program.
    rg_call_prg_wa-low    = 'ZMME11067'.
    APPEND rg_call_prg_wa TO rg_call_ext.
*** End modification by JWILL68 on 5/31/2018 CMS# 33255

*---Fill the Calling Programs
  rg_call_prg_wa-sign   = 'I'.
  rg_call_prg_wa-option = 'EQ'.
  rg_call_prg_wa-low    = 'ZME2912_GOODS_MOVEMENTS_NEW'.
  APPEND rg_call_prg_wa TO  rg_call_prg.
  rg_call_prg_wa-low    = 'ZME2912_GOODS_MOVEMENTS'.
  APPEND rg_call_prg_wa TO  rg_call_prg.
*** Start modification by PWADEHR on 7/9/2018 CMS# 33265
  rg_call_prg_wa-low    = 'ZMME11066_RF_SCALE_TICKET_GR'.
  APPEND rg_call_prg_wa TO  rg_call_prg.
*** End modification by PWADEHR on 7/9/2018 CMS# 33265
*  rg_call_prg_wa-low    = 'MBST_EXIT'.
*  APPEND rg_call_prg_wa TO rg_call_ext.



*--Transaction/Event Type VGART
  REFRESH it_zmmfld_vgart.
  SELECT * FROM zmmfld INTO TABLE it_zmmfld_vgart
      WHERE key1 = 'E10313'
      AND   key2 = 'VGART'.


  IF sy-subrc EQ 0.
    SORT it_zmmfld_vgart.
    LOOP AT it_zmmfld_vgart INTO wa_zmmfld_vgart.
      rg_vgart_wa-sign   = 'I'.
      rg_vgart_wa-option = 'EQ'.
      rg_vgart_wa-low = wa_zmmfld_vgart-value1.
      APPEND rg_vgart_wa TO rg_vgart.
      CLEAR  rg_vgart_wa.
    ENDLOOP.
  ENDIF.


*--Movement Type for Warehouse Management BWLVS
  REFRESH it_zmmfld_bwlvs.
  SELECT * FROM zmmfld INTO TABLE it_zmmfld_bwlvs
      WHERE key1 = 'E10313'
      AND   key2 = 'BWLVS'.


  IF sy-subrc EQ 0.
    SORT it_zmmfld_bwlvs.
    LOOP AT it_zmmfld_bwlvs INTO wa_zmmfld_bwlvs.
      rg_bwlvs_wa-sign   = 'I'.
      rg_bwlvs_wa-option = 'EQ'.
      rg_bwlvs_wa-low = wa_zmmfld_bwlvs-value1.
      APPEND rg_bwlvs_wa TO rg_bwlvs.
      CLEAR  rg_bwlvs_wa.
    ENDLOOP.
  ENDIF.

*--Purchasing Organization EKORG
  REFRESH : it_zmmfld_ekorg.

  SELECT * FROM zmmfld INTO TABLE it_zmmfld_ekorg
    WHERE key1 = 'E10313'
    AND   key2 = 'EKORG'.

  IF sy-subrc EQ 0.
    SORT it_zmmfld_ekorg.
    LOOP AT it_zmmfld_ekorg INTO wa_zmmfld_ekorg.
      rg_ekorg_wa-sign   = 'I'.
      rg_ekorg_wa-option = 'EQ'.
      rg_ekorg_wa-low = wa_zmmfld_ekorg-value1.
      APPEND rg_ekorg_wa TO rg_ekorg.
      CLEAR rg_ekorg_wa.
    ENDLOOP.
  ENDIF.


  IF id_calling_prg IS NOT INITIAL.

*-- object called form Transaction ( User Exit )

    IF id_calling_prg IN rg_call_ext.

      COMMIT WORK.
      WAIT UP TO 5 SECONDS. "--Time for the MSEG Table Update

      IF input_tab[] IS NOT INITIAL. "Input Table is not Empty

        CLEAR input_str.
        READ TABLE input_tab INTO input_str INDEX 1.

        IF sy-subrc EQ 0.
          IF    input_str-mat_doc IS NOT INITIAL
            AND input_str-doc_year IS NOT INITIAL.

*--Header: Material Document MKPF
            REFRESH it_mkpf[].
            SELECT * FROM mkpf INTO TABLE it_mkpf
                                 WHERE mblnr = input_str-mat_doc
                                 AND   mjahr = input_str-doc_year.
            IF it_mkpf[] IS NOT INITIAL.
*--Document Segment: Material MSEG
              REFRESH it_mseg[].
              SELECT * FROM mseg INTO TABLE it_mseg
                  FOR ALL ENTRIES IN it_mkpf
                   WHERE mblnr      = it_mkpf-mblnr
                   AND   xblnr_mkpf = it_mkpf-xblnr.

              IF it_mseg[] IS NOT INITIAL.
*--Purchasing Document Header EKK0
                REFRESH it_ekko[].
                SELECT * FROM ekko INTO TABLE it_ekko
                  FOR ALL ENTRIES IN it_mseg
                   WHERE ebeln      = it_mseg-ebeln.

*--Purchasing Document Item EKPO
                REFRESH it_ekpo[].
                SELECT * FROM ekpo INTO TABLE it_ekpo
                  FOR ALL ENTRIES IN it_mseg
                   WHERE ebeln      = it_mseg-ebeln
                   AND   ebelp      = it_mseg-ebelp.


              ENDIF.
            ENDIF.
          ELSE.
*--Material Document is Initial
*--Year is Initial

            ls_return-type   = 'E'.
            ls_return-id     = 'ZCL_E10310'.
            ls_return-number = '005'.
            ls_return-message = text-005.
            APPEND ls_return    TO cl_return.
            CLEAR  ls_return.
          ENDIF.

        ENDIF.
      ELSE.
        ls_return-type   = 'E'.
        ls_return-id     = 'ZCL_E10310'.
        ls_return-number = '001'.
        ls_return-message = text-001.
        APPEND ls_return    TO cl_return.
        CLEAR  ls_return.

      ENDIF.

*--Validations to determine if the method should be called

      CLEAR ls_mseg.

      LOOP AT it_mseg INTO ls_mseg.

        ls_input_str-mat_doc           = ls_mseg-mblnr.
        ls_input_str-doc_year          = ls_mseg-mjahr.
        ls_input_str-mat_doc_item      = ls_mseg-zeile.
        ls_input_str-mov_type          = ls_mseg-bwart.
        ls_input_str-po_number         = ls_mseg-ebeln.
        ls_input_str-po_item           = ls_mseg-ebelp.
        ls_input_str-po_werks          = ls_mseg-werks.
        ls_input_str-mseg_menge        = ls_mseg-menge.
        ls_input_str-mseg_meins        = ls_mseg-meins.
        ls_input_str-zscale_ticket     = ls_mseg-xblnr_mkpf.
        ls_input_str-mseg_lfbnr        = ls_mseg-lfbnr.
        ls_input_str-mseg_lfpos        = ls_mseg-lfpos.
        ls_input_str-mseg_lfbja        = ls_mseg-lfbja.
        ls_input_str-mseg_sgtxt        = ls_mseg-sgtxt.
        ls_input_str-zlifnr            = ls_mseg-lifnr.
        ls_input_str-zllief            = ls_mseg-llief.
        ls_input_str-zaction           = input_str-zaction.


*--Transaction Type Check
        CLEAR ls_mkpf.
        READ TABLE it_mkpf INTO ls_mkpf WITH KEY
                          mblnr = ls_mseg-mblnr
                          mjahr = ls_mseg-mjahr.
        IF sy-subrc EQ 0.

          IF ls_mkpf-vgart IN rg_vgart.

*--If the movement type 101 102
            IF ls_mseg-bwart IN rg_bwlvs.

*--Purchase Org Check
              CLEAR ls_ekko.
              READ TABLE it_ekko INTO ls_ekko WITH KEY
                                      ebeln = ls_mseg-ebeln.
              IF sy-subrc EQ 0.
*--Purchase ORG Range Table Check
                IF ls_ekko-ekorg IN rg_ekorg.

                  CLEAR ls_ekpo.
                  READ TABLE it_ekpo INTO ls_ekpo WITH KEY
                                          ebeln = ls_mseg-ebeln
                                          ebelp = ls_mseg-ebelp.
                  IF sy-subrc EQ 0.
*---"All the validations good
                    ls_input_str-ekpo_zz_lwd       = ls_ekpo-zz_lwd.
                    ls_input_str-ekpo_zz_threshold = ls_ekpo-zz_threshold.
                    ls_input_str-ekpo_zz_deduction = ls_ekpo-zz_deduction.
                    ls_input_str-ekpo_schpr        = ls_ekpo-schpr.
                    ls_input_str-zlwd_unit         = ls_ekpo-meins.
                    ls_input_str-zekorg            = ls_ekko-ekorg.
*--Vendor Master
                    IF ls_input_str-zlifnr IS NOT INITIAL.
                      SELECT SINGLE name1 FROM lfa1 INTO ls_input_str-zvendor_name
                                                WHERE  lifnr = ls_input_str-zlifnr.
                    ENDIF.

                    IF ls_input_str-zllief IS NOT INITIAL.
                      SELECT SINGLE name1 FROM lfa1 INTO ls_input_str-zsupplier_name
                                                 WHERE  lifnr = ls_input_str-zllief.
                    ENDIF.


                    APPEND ls_input_str TO cl_input_table.
                    CLEAR ls_input_str.


                  ENDIF.
                ELSE.
*---Purchase Org Check Failed
                  ls_return-type        = 'E'.
                  ls_return-id          = 'ZCL_E10310'.
                  ls_return-number      = '006'.
                  ls_return-message     = text-006.
                  ls_return-message_v1  = ls_mseg-mblnr.
                  ls_return-message_v2  = ls_mseg-zeile.
                  APPEND ls_return    TO cl_return.
                  CLEAR  ls_return.
                ENDIF.
              ENDIF.
            ELSE.
*---movement type 101 102 Check Fail
              ls_return-type        = 'E'.
              ls_return-id          = 'ZCL_E10310'.
              ls_return-number      = '004'.
              ls_return-message     = text-004.
              ls_return-message_v1  = ls_mseg-mblnr.
              ls_return-message_v2  = ls_mseg-zeile.
              APPEND ls_return    TO cl_return.
              CLEAR  ls_return.
            ENDIF.
          ELSE.
*---Transaction/Event Type VGART Check Fail
            ls_return-type       = 'E'.
            ls_return-id         = 'ZCL_E10310'.
            ls_return-number     = '003'.
            ls_return-message    = text-003.
            ls_return-message_v1 = ls_mseg-mblnr.
            ls_return-message_v2 = ls_mseg-zeile.
            APPEND ls_return    TO cl_return.
            CLEAR  ls_return.
          ENDIF.
        ENDIF.
      ENDLOOP.



*--Call From the Batch Programs or online programs
    ELSEIF id_calling_prg IN  rg_call_prg. " Call From Programs

      IF input_tab[] IS NOT INITIAL. "Input Table is Not Empty

        CLEAR input_str.
        LOOP AT input_tab INTO input_str.
*--Transaction Type Check
          IF input_str-vgart IN rg_vgart.
*--Purchase Org Check
            IF input_str-ekko_ekorg IN rg_ekorg.
*---All the validations good

              APPEND input_str TO cl_input_table.
              CLEAR ls_input_str.
            ENDIF.

          ENDIF.

        ENDLOOP.

      ELSE.
        ls_return-type   = 'E'.
        ls_return-id     = 'ZCL_E10310'.
        ls_return-number = '001'.
        ls_return-message = text-001.
        APPEND ls_return    TO cl_return.
        CLEAR  ls_return.
      ENDIF.

    ENDIF.
  ENDIF.
*  ELSE.

*--Object called form is a NULL Value
  ls_return-type   = 'E'.
  ls_return-id     = 'ZCL_E10310'.
  ls_return-number = '002'.
  ls_return-message = text-002.
  APPEND ls_return    TO cl_return.
  CLEAR  ls_return.
*if.
* ENDIF.




ENDMETHOD.


METHOD process_e02912.
*----------------------------------------------------------------------*
* Change History:                                                      *
*   Programmer     Date     Req. #                Action               *
* ============= ========   ======   ================================== *
* Parag Wadehra  10/17/2018 E0VK9A10QC CMS 34209: added logic for the  *
*                                      deletion of original entry      *

  DATA : ls_input_table          TYPE zmm_e10310_input,
         ls_e10307_table_tmp     TYPE zmm_e10310_input,
         wa_e10307_table_tmp     TYPE zmm_e10307_table,
         it_e10307_table         TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_tmp     TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_r       TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_subcred TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_others  TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_delete  TYPE STANDARD TABLE OF zmm_e10307_table,
         ls_e10307_table_others  TYPE zmm_e10307_table,
         it_zmscale_ticket       TYPE STANDARD TABLE OF zmscale_ticket,
         it_zmscale_ticket_r     TYPE STANDARD TABLE OF zmscale_ticket,
         ls_zmscale_ticket       TYPE zmscale_ticket,
         ls_e10307_table         TYPE zmm_e10307_table,
         ls_return               TYPE bapiret2,
*         lt_zstatus2             TYPE STANDARD TABLE OF dd07v,
*         ls_zstatus2             TYPE dd07v,
         lt_config               TYPE ztt_conf_out,
         lv_remainder            TYPE int4,
         gc_101                  TYPE bwart VALUE '101',
         gc_102                  TYPE bwart VALUE '102'.

  CONSTANTS: lc_key1 TYPE char6 VALUE 'E10307',
             lc_key2 TYPE char3 VALUE 'RFQ',
             lc_key3 TYPE char3 VALUE 'UPL',
             lc_key4 TYPE char6 VALUE 'STATUS'.

*** Start modification by PWADEHR on 7/27/2018 CMS# 33265
*  REFRESH lt_zstatus2[].
**---Get the domain default values ZSTATUS2
*  CALL FUNCTION 'DD_DOMA_GET'
*    EXPORTING
*      domain_name = 'ZSTATUS2'
*      langu       = sy-langu
*      withtext    = 'X'
*    TABLES
*      dd07v_tab_a = lt_zstatus2
*      dd07v_tab_n = lt_zstatus2
*    EXCEPTIONS
*      OTHERS      = 0.
*  IF lt_zstatus2[] IS NOT INITIAL.
*    SORT lt_zstatus2.
*    DELETE lt_zstatus2 WHERE ddlanguage EQ space.
*  ENDIF.
* The domain values for the fields Status is moved to table
* ZMMFLD, the values should be retrived from the table instead of
* retriving from the domain value.
  SELECT *
    FROM zmmfld
    INTO TABLE @DATA(lt_status)
    WHERE key1 = @lc_key1 AND
          key2 = @lc_key2 AND
          key3 = @lc_key3 AND
          key4 = @lc_key4 .
  IF sy-subrc <> 0.
    CLEAR lt_status.
  ENDIF.

* For filling newly added fields.
  IF cl_input_table IS NOT INITIAL.
* Retrive the record from Zmscale_ticket table for Grade and
* Grade Description.
    SELECT zscale_ticket,
           tknum,
           ebeln,
           ebelp,
           matnr
      FROM zmscale_ticket
      INTO TABLE @DATA(lt_zmscale_validate)
      FOR ALL ENTRIES IN @cl_input_table
      WHERE zscale_ticket = @cl_input_table-zscale_ticket.
    IF sy-subrc = 0.
* Retrive the record from EKPO table for Grade and
* Grade Description.
      SELECT ebeln,
             ebelp,
             zz_atinn,
             zz_atwrt,
             cuobj
        FROM ekpo
        INTO TABLE @DATA(lt_ekpo)
        FOR ALL ENTRIES IN @lt_zmscale_validate
        WHERE ebeln = @lt_zmscale_validate-ebeln AND
              ebelp = @lt_zmscale_validate-ebelp.
      IF sy-subrc = 0.
* Retrive the record from CAWN table for Grade and
* Grade Description.
        SELECT atinn,
               atzhl,
               atwrt
          FROM cawn
          INTO TABLE @DATA(lt_cawn)
          FOR ALL ENTRIES IN @lt_ekpo
          WHERE atinn = @lt_ekpo-zz_atinn AND
                atwrt = @lt_ekpo-zz_atwrt.
        IF sy-subrc = 0.
* Retrive the record from CAWNT table for Grade and
* Grade Description.
          SELECT atinn,
                 atzhl,
                 spras,
                 atwtb
            FROM cawnt
            INTO TABLE @DATA(lt_cawnt)
            FOR ALL ENTRIES IN @lt_cawn
            WHERE atinn = @lt_cawn-atinn AND
                  atzhl = @lt_cawn-atzhl AND
                  spras = @sy-langu.
          IF sy-subrc <> 0.
            CLEAR lt_cawnt.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

* Use conversion exit for Material field.
    LOOP AT lt_zmscale_validate ASSIGNING FIELD-SYMBOL(<ls_matnr>).
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <ls_matnr>-matnr
        IMPORTING
          output = <ls_matnr>-matnr.
    ENDLOOP.
    UNASSIGN <ls_matnr>.
* Check Material validation and get material text.
    IF lt_zmscale_validate IS NOT INITIAL.
      SELECT  matnr
        FROM mara
        INTO TABLE @DATA(lt_matnr)
        FOR ALL ENTRIES IN @lt_zmscale_validate
        WHERE matnr = @lt_zmscale_validate-matnr.
      IF sy-subrc = 0.
* Get material text.
        SELECT matnr,
               spras,
               maktx
          FROM makt
          INTO TABLE @DATA(lt_maktx)
          FOR ALL ENTRIES IN @lt_matnr
          WHERE matnr = @lt_matnr-matnr AND
                spras = @sy-langu.
        IF sy-subrc <> 0.
          CLEAR lt_maktx.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
*** End modification by PWADEHR on 7/27/2018 CMS# 33265
  LOOP AT cl_input_table INTO ls_input_table.
    CLEAR ls_e10307_table.

* Start modification by ALANKAP on 6/15/2015 " CMS 28556
* LWD should apply for only initial Goods receipt
*--*--101 Goods Movement Type Processing
*    IF ls_input_table-mov_type = gc_101.
    IF ls_input_table-mov_type = gc_101 AND
       ( ls_input_table-zrev_no EQ '00' OR
         ls_input_table-zrev_no IS INITIAL ) AND
            sy-tcode <> 'VL09'.                             "CMS 33265
      IF ls_input_table-ekpo_zz_lwd = 'X'.   "LWD Flag
        IF ls_input_table-mseg_menge LT ls_input_table-ekpo_zz_threshold.
          IF ls_input_table-ekpo_zz_deduction IS NOT INITIAL.

            ls_e10307_table-zmblnr         = ls_input_table-mat_doc.
            ls_e10307_table-zmblpo         = ls_input_table-mat_doc_item.
            ls_e10307_table-zmjahr         = ls_input_table-doc_year.
            ls_e10307_table-zmenge         = ls_input_table-mseg_menge.
            ls_e10307_table-zmeins         = ls_input_table-mseg_meins.
            ls_e10307_table-zscale_ticket  = ls_input_table-zscale_ticket.
            ls_e10307_table-zrev_no        = ls_input_table-zrev_no.
            ls_e10307_table-zaction        = ls_input_table-zaction.
            ls_e10307_table-zbwart         = ls_input_table-mov_type.
            ls_e10307_table-zebeln         = ls_input_table-po_number.
            ls_e10307_table-zebelp         = ls_input_table-po_item.
            ls_e10307_table-zwerks         = ls_input_table-po_werks.
            ls_e10307_table-zschpr         = ls_input_table-ekpo_schpr.
            ls_e10307_table-zlwd_stat      = ls_input_table-ekpo_zz_lwd.
            ls_e10307_table-zlwd_thr       = ls_input_table-ekpo_zz_threshold.
*           ls_e10307_table-ZLWD_UNIT      =
            ls_e10307_table-zlwd_rate      = ls_input_table-ekpo_zz_deduction.
            ls_e10307_table-zekorg         = ls_input_table-zekorg.
            ls_e10307_table-zlifnr         = ls_input_table-zlifnr.
            ls_e10307_table-zvendor_name   = ls_input_table-zvendor_name.
            ls_e10307_table-zllief         = ls_input_table-zllief.
            ls_e10307_table-zsupplier_name = ls_input_table-zsupplier_name.
*Update the ZADJ_RATE with the same value as the ZLWD_RATE when it is
* populated. This will provide AP with the rate to be used for the
* subsequent adjustment from a single field. ZDJ_RATE.
*           ls_e10307_table-zadj_rate     = ls_input_table-ekpo_zz_deduction.
            ls_e10307_table-zadj_rate
            = ( ls_e10307_table-zlwd_thr - ls_e10307_table-zmenge ) *
                ls_e10307_table-zlwd_rate.
            ls_e10307_table-zadj_type     = 'C'.
            ls_e10307_table-zadj_reason   = TEXT-t01.
            ls_e10307_table-zcr_date      = sy-datum.
            ls_e10307_table-zcr_time      = sy-uzeit.
            ls_e10307_table-zcr_name      = sy-uname.
            ls_e10307_table-zcr_call_id   = cl_calling_prg.

*--Get the Revision Number From ZMSCALE_TICKET
            REFRESH it_zmscale_ticket[].
            CLEAR   ls_zmscale_ticket.

            SELECT * FROM zmscale_ticket INTO TABLE it_zmscale_ticket
                     WHERE zscale_ticket = ls_input_table-zscale_ticket.
            IF sy-subrc EQ 0.
              SORT it_zmscale_ticket DESCENDING BY zrev_no.
              READ TABLE it_zmscale_ticket INTO ls_zmscale_ticket INDEX 1.
              ls_e10307_table-zrev_no = ls_zmscale_ticket-zrev_no.
            ENDIF.

            "Put the request on Hold  "Indicator: Estimated Price -
            "space "Indicator: Est Prc
            IF ls_input_table-ekpo_schpr EQ 'X'.
              ls_e10307_table-zstatus  = 'GR101-XEP'.
            ELSEIF ls_input_table-ekpo_schpr EQ ''.
              ls_e10307_table-zstatus = 'GR101'.
            ENDIF.

*---Status Description from the Domain Values
*            CLEAR ls_zstatus2.
            IF ls_e10307_table-zstatus IS NOT INITIAL.
*** Start modification by PWADEHR on 7/27/2018 CMS# 33265
*              READ TABLE lt_zstatus2 INTO ls_zstatus2 WITH KEY
*                          domvalue_l = ls_e10307_table-zstatus
*                          ddlanguage = 'E'.
*              IF sy-subrc EQ 0.
*                ls_e10307_table-zstatus_descr = ls_zstatus2-ddtext.
*              ENDIF.
              TRY.
                  DATA(ls_status) = lt_status[ value1 = ls_e10307_table-zstatus ].
                  ls_e10307_table-zstatus_descr = ls_status-value7.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
* Grade code and description determination.
              TRY.
                  DATA(ls_zmscale_validate) = lt_zmscale_validate[ zscale_ticket = ls_input_table-zscale_ticket ].
                  ls_e10307_table-ztknum = ls_zmscale_validate-tknum.
                CATCH cx_sy_itab_line_not_found.
                  CLEAR ls_zmscale_validate.
              ENDTRY.

* Read EKPO, CAWN, CAWNT table to get the Grade value and
* Grade value description.
              TRY.
                  DATA(ls_ekpo) = lt_ekpo[ ebeln = ls_zmscale_validate-ebeln
                                           ebelp = ls_zmscale_validate-ebelp ].
                  TRY.
                      DATA(ls_cawn) = lt_cawn[ atinn = ls_ekpo-zz_atinn
                                               atwrt = ls_ekpo-zz_atwrt ].
                      TRY.
                          DATA(ls_cawnt) = lt_cawnt[ atinn = ls_cawn-atinn
                                                     atzhl = ls_cawn-atzhl
                                                     spras = sy-langu ].
                          ls_e10307_table-zgrade       = ls_ekpo-zz_atwrt.
                          ls_e10307_table-zgrade_descr = ls_cawnt-atwtb.
                        CATCH cx_sy_itab_line_not_found.
                      ENDTRY.
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
              IF ls_ekpo-zz_atinn IS INITIAL AND
                 ls_ekpo-zz_atwrt IS INITIAL.
* Get the value from the FM.
                CALL FUNCTION 'VC_I_GET_CONFIGURATION'
                  EXPORTING
                    instance            = ls_ekpo-cuobj
                    language            = sy-langu
                  TABLES
                    configuration       = lt_config
                  EXCEPTIONS
                    instance_not_found  = 1
                    internal_error      = 2
                    no_class_allocation = 3
                    instance_not_valid  = 4
                    OTHERS              = 5.
                IF sy-subrc <> 0.
                  CLEAR lt_config.
                ENDIF.
                TRY .
                    DATA(ls_config) = lt_config[ 1 ].
                    ls_e10307_table-zgrade = ls_config-atwrt.
                    ls_e10307_table-zgrade_descr = ls_config-atwtb.
                  CATCH cx_sy_itab_line_not_found.
                ENDTRY.
              ENDIF.
              CLEAR: ls_ekpo,
                     ls_cawn,
                     ls_cawnt.
* Check Material validation and get material text.
              TRY.
                  DATA(ls_matnr) = lt_matnr[ matnr = ls_zmscale_validate-matnr ].
                  ls_e10307_table-zmatnr = ls_matnr-matnr.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
** Get material text.
              TRY .
                  DATA(ls_maktx) = lt_maktx[ matnr = ls_matnr-matnr
                                             spras = sy-langu ].
                  ls_e10307_table-zmaktx = ls_maktx-maktx.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
*** End modification by PWADEHR on 7/27/2018 CMS# 33265
            ENDIF.

            APPEND ls_e10307_table TO it_e10307_table.
            CLEAR  ls_e10307_table.
          ENDIF.
        ELSE.

        ENDIF.
      ELSE.   ""EKPO-ZZ_LWD FLAG IS BLANK

        ls_return-type        = 'E'.
        ls_return-id          = 'ZCL_E10310'.
        ls_return-number      = '007'.
        ls_return-message     = TEXT-006.
        ls_return-message_v1  = ls_input_table-mat_doc.
        ls_return-message_v2  = ls_input_table-mat_doc_item..
        APPEND ls_return    TO cl_return.
        CLEAR  ls_return.
      ENDIF.
*** Start of modification by ALANKAP on 8/24/2015 CMS 28897
    ELSEIF ls_input_table-mov_type = gc_101 AND
           ls_input_table-zrev_no GT '00'.
      SELECT SINGLE * FROM zmm_e10307_table INTO wa_e10307_table_tmp
         WHERE
         zscale_ticket       = ls_input_table-zscale_ticket

         AND ( zrev_no = '00' OR
               zrev_no = space ).

      IF sy-subrc EQ 0.
* get the scale ticket data
        SELECT * INTO TABLE it_zmscale_ticket FROM zmscale_ticket
               WHERE zscale_ticket = ls_input_table-zscale_ticket.
        IF sy-subrc IS INITIAL.
          SORT it_zmscale_ticket DESCENDING BY zscale_ticket zrev_no.
          READ TABLE it_zmscale_ticket INTO ls_zmscale_ticket INDEX 1.
          lv_remainder = ls_zmscale_ticket-zrev_no MOD 2.
          IF lv_remainder  NE 0.
            ls_zmscale_ticket-zrev_no = ls_zmscale_ticket-zrev_no + 1.
          ENDIF.
        ENDIF.
*** Copy the '00' revision to a new record
        MOVE-CORRESPONDING wa_e10307_table_tmp TO ls_e10307_table.
        ls_e10307_table-zmblnr      = ls_input_table-mat_doc.
        ls_e10307_table-zrev_no     = ls_zmscale_ticket-zrev_no. " new rev number '02' or '04'?
        ls_e10307_table-zreaction   = space.
        ls_e10307_table-zstatus     = 'GR101'.
*** Start modification by PWADEHR on 7/27/2018 CMS# 33265
        CLEAR ls_status.
        TRY.
            ls_status = lt_status[ value1 = ls_e10307_table-zstatus ].
            ls_e10307_table-zstatus_descr = ls_status-value7.
          CATCH cx_sy_itab_line_not_found.
        ENDTRY.
*        SELECT SINGLE ddtext INTO ls_e10307_table-zstatus_descr
*               FROM dd07t
*               WHERE domname    = 'ZSTATUS2'
*               AND   ddlanguage = sy-langu
*               AND   domvalue_l = ls_e10307_table-zstatus.
*** End modification by PWADEHR on 7/27/2018 CMS# 33265
        ls_e10307_table-zch_date    = sy-datum.
        ls_e10307_table-zch_time    = sy-uzeit.
        ls_e10307_table-zernam      = sy-uname.
        ls_e10307_table-zch_call_id = sy-repid.
        ls_e10307_table-ztxt01      = ls_e10307_table-zadj_reason.
*        ls_e10307_table-zadj_reason = 'Original receipt LWD applied'.
        ls_e10307_table-zadj_reason = 'Light Weight deduction for scale ticket'.
        ls_e10307_table-zadj_type = 'C'.
        CLEAR : ls_e10307_table-zbelnr, ls_e10307_table-zbuzei, ls_e10307_table-zbelnr_r, ls_e10307_table-zbuzei_r, ls_e10307_table-ztxt01.
        APPEND ls_e10307_table TO it_e10307_table.
        CLEAR  ls_e10307_table.
      ENDIF.
*** End of modification by ALANKAP on 8/24/2015 CMS 28897
    ENDIF.

* Start modification by ALANKAP on 6/15/2015 " CMS 28556
* LWD should apply for only initial Goods receipt
*--102 Goods Movement Type Processing
    IF ls_input_table-mov_type = gc_102 OR " CMS 28897
       sy-tcode = 'VL09'.
*      IF ls_input_table-mov_type = gc_102 AND
*         ls_input_table-ekpo_zz_lwd NE 'X'.
*--Get the Scale ticket details for the reversal movement and the
*--original GR
      REFRESH it_zmscale_ticket_r[].
      SELECT * FROM zmscale_ticket INTO TABLE it_zmscale_ticket_r
               WHERE zscale_ticket = ls_input_table-zscale_ticket
               AND   zgr_docno     = ls_input_table-mseg_lfbnr.
      IF sy-subrc EQ 0.
        SORT it_zmscale_ticket_r.
      ENDIF.

*--Get the Status of subsequent adjustments for the original GR document
      REFRESH:  it_e10307_table_r[],
                it_e10307_table_subcred[],
                it_e10307_table_others[].

      SELECT * FROM zmm_e10307_table INTO TABLE it_e10307_table_r
                WHERE zmblnr        = ls_input_table-mseg_lfbnr.
*               AND   zscale_ticket = ls_input_table-mseg_lfbnr.
      IF sy-subrc EQ 0.
        SORT it_e10307_table_r.
        it_e10307_table_subcred[] = it_e10307_table_r[].
        it_e10307_table_others[]  = it_e10307_table_r[].

*--Keep only No SUBCRED records
        DELETE it_e10307_table_others WHERE zstatus EQ 'SUBCRED'.
*--Keep only SUBCRED records
        DELETE it_e10307_table_subcred WHERE zstatus NE 'SUBCRED'.

        IF it_e10307_table_subcred[] IS NOT INITIAL.

          ls_e10307_table-zmblnr         = ls_input_table-mat_doc.
          ls_e10307_table-zmblpo         = ls_input_table-mat_doc_item.
          ls_e10307_table-zmjahr         = ls_input_table-doc_year.
          ls_e10307_table-zmenge         = ls_input_table-mseg_menge.
          ls_e10307_table-zmeins         = ls_input_table-mseg_meins.
*         ls_e10307_table-zscale_ticket = ls_input_table-zscale_ticket.
*         ls_e10307_table-zrev_no       = ls_input_table-zrev_no.
          ls_e10307_table-zaction        = ls_input_table-zaction.
          ls_e10307_table-zbwart         = ls_input_table-mov_type.
          ls_e10307_table-zebeln         = ls_input_table-po_number.
          ls_e10307_table-zebelp         = ls_input_table-po_item.
          ls_e10307_table-zwerks         = ls_input_table-po_werks.
          ls_e10307_table-zschpr         = ls_input_table-ekpo_schpr.
          ls_e10307_table-zlwd_stat      = ls_input_table-ekpo_zz_lwd.
          ls_e10307_table-zlwd_thr       = ls_input_table-ekpo_zz_threshold.
*         ls_e10307_table-ZLWD_UNIT     =
          ls_e10307_table-zlwd_rate      = ls_input_table-ekpo_zz_deduction.
          ls_e10307_table-zekorg         = ls_input_table-zekorg.
          ls_e10307_table-zlifnr         = ls_input_table-zlifnr.
          ls_e10307_table-zvendor_name   = ls_input_table-zvendor_name.
          ls_e10307_table-zllief         = ls_input_table-zllief.
          ls_e10307_table-zsupplier_name = ls_input_table-zsupplier_name.
*Update the ZADJ_RATE with the same value as the ZLWD_RATE when it is populated.
*This will provide AP with the rate to be used for the subsequent adjustment from a single field. ZDJ_RATE.
*         ls_e10307_table-zadj_rate     = ls_input_table-ekpo_zz_deduction.
          ls_e10307_table-zadj_rate     = ( ls_e10307_table-zlwd_thr - ls_e10307_table-zmenge ) * ls_e10307_table-zlwd_rate.
          ls_e10307_table-zadj_type     = ls_input_table-zaction.
          ls_e10307_table-zcr_date      = sy-datum.
          ls_e10307_table-zcr_time      = sy-uzeit.
          ls_e10307_table-zcr_call_id   = cl_calling_prg.
          ls_e10307_table-zcr_name      = sy-uname.
          ls_e10307_table-zstatus       = 'GR102'.

          IF ls_input_table-mseg_sgtxt  IS NOT INITIAL.
            ls_e10307_table-zadj_reason   = ls_input_table-mseg_sgtxt.
          ELSE.
            ls_e10307_table-zadj_reason   = TEXT-t02.
          ENDIF.

*** Start modification by PWADEHR on 7/27/2018 CMS# 33265
*          CLEAR ls_zstatus2.
*          IF ls_e10307_table-zstatus IS NOT INITIAL.
*            READ TABLE lt_zstatus2 INTO ls_zstatus2 WITH KEY
*                        domvalue_l = ls_e10307_table-zstatus
*                        ddlanguage = 'E'.
*            IF sy-subrc EQ 0.
*              ls_e10307_table-zstatus_descr = ls_zstatus2-ddtext.
*            ENDIF.
*          ENDIF.
          CLEAR ls_status.
          TRY.
              ls_status = lt_status[ value1 = ls_e10307_table-zstatus ].
              ls_e10307_table-zstatus_descr = ls_status-value7.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.

* Grade code and description determination.
          TRY.
              ls_zmscale_validate = lt_zmscale_validate[ zscale_ticket = ls_input_table-zscale_ticket ].
              ls_e10307_table-ztknum = ls_zmscale_validate-tknum.
            CATCH cx_sy_itab_line_not_found.
              CLEAR ls_zmscale_validate.
          ENDTRY.

* Read EKPO, CAWN, CAWNT table to get the Grade value and
* Grade value description.
          TRY.
              ls_ekpo = lt_ekpo[ ebeln = ls_zmscale_validate-ebeln
                                 ebelp = ls_zmscale_validate-ebelp ].
              TRY .
                  ls_cawn = lt_cawn[ atinn = ls_ekpo-zz_atinn
                                     atwrt = ls_ekpo-zz_atwrt ].
                  TRY .
                      ls_cawnt = lt_cawnt[ atinn = ls_cawn-atinn
                                           atzhl = ls_cawn-atzhl
                                           spras = sy-langu ].
                      ls_e10307_table-zgrade       = ls_ekpo-zz_atwrt.
                      ls_e10307_table-zgrade_descr = ls_cawnt-atwtb.
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
          IF ls_ekpo-zz_atinn IS INITIAL AND
             ls_ekpo-zz_atwrt IS INITIAL.
* Get the value from the FM.
            CALL FUNCTION 'VC_I_GET_CONFIGURATION'
              EXPORTING
                instance            = ls_ekpo-cuobj
                language            = sy-langu
              TABLES
                configuration       = lt_config
              EXCEPTIONS
                instance_not_found  = 1
                internal_error      = 2
                no_class_allocation = 3
                instance_not_valid  = 4
                OTHERS              = 5.
            IF sy-subrc <> 0.
              CLEAR lt_config.
            ENDIF.
            TRY .
                ls_config = lt_config[ 1 ].
                ls_e10307_table-zgrade       = ls_config-atwrt.
                ls_e10307_table-zgrade_descr = ls_config-atwtb.
              CATCH cx_sy_itab_line_not_found.
            ENDTRY.
          ENDIF.
          CLEAR: ls_ekpo,
                 ls_cawn,
                 ls_cawnt.
* Check Material validation and get material text.
          TRY.
              ls_matnr = lt_matnr[ matnr = ls_zmscale_validate-matnr ].
              ls_e10307_table-zmatnr = ls_matnr-matnr.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
** Get material text.
          TRY .
              ls_maktx = lt_maktx[ matnr = ls_matnr-matnr
                                   spras = sy-langu ].
              ls_e10307_table-zmaktx = ls_maktx-maktx.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
*** End modification by PWADEHR on 7/27/2018 CMS# 33265
          APPEND ls_e10307_table TO it_e10307_table.
          CLEAR  ls_e10307_table.

        ENDIF.

*--Zstatus is NOT SUBCRED - Delete all pending Requests
        IF it_e10307_table_others[] IS NOT INITIAL.
          LOOP AT it_e10307_table_others INTO ls_e10307_table_others.
            IF ls_e10307_table_others-zstatus+0(5) = 'GR101'.
              ls_e10307_table_others-zstatus = 'DELETE'.
              ls_e10307_table_others-zch_date      = sy-datum.
              ls_e10307_table_others-zch_time      = sy-uzeit.
              ls_e10307_table_others-zch_call_id   = cl_calling_prg.
              ls_e10307_table_others-zernam        = sy-uname.

*---Status Description from the Domain Values
**********************************************************************
*** Start modification by PWADEHR on 7/27/2018 CMS# 33265
*              CLEAR ls_zstatus2.
*              IF ls_e10307_table_others-zstatus IS NOT INITIAL.
*                READ TABLE lt_zstatus2 INTO ls_zstatus2 WITH KEY
*                            domvalue_l = ls_e10307_table_others-zstatus
*                            ddlanguage = 'E'.
*                IF sy-subrc EQ 0.
*                  ls_e10307_table_others-zstatus_descr = ls_zstatus2-ddtext.
*                ENDIF.
*              ENDIF.
              CLEAR ls_status.
              TRY.
                  ls_status = lt_status[ value1 = ls_e10307_table_others-zstatus ].
                  ls_e10307_table_others-zstatus_descr = ls_status-value7.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.

* Grade code and description determination.
              TRY.
                  ls_zmscale_validate = lt_zmscale_validate[ zscale_ticket = ls_input_table-zscale_ticket ].
                  ls_e10307_table_others-ztknum = ls_zmscale_validate-tknum.
                CATCH cx_sy_itab_line_not_found.
                  CLEAR ls_zmscale_validate.
              ENDTRY.

* Read EKPO, CAWN, CAWNT table to get the Grade value and
* Grade value description.
              TRY.
                  ls_ekpo = lt_ekpo[ ebeln = ls_zmscale_validate-ebeln
                                           ebelp = ls_zmscale_validate-ebelp ].
                  TRY.
                      ls_cawn = lt_cawn[ atinn = ls_ekpo-zz_atinn
                                               atwrt = ls_ekpo-zz_atwrt ].
                      TRY.
                          ls_cawnt = lt_cawnt[ atinn = ls_cawn-atinn
                                                     atzhl = ls_cawn-atzhl
                                                     spras = sy-langu ].
                          ls_e10307_table_others-zgrade       = ls_ekpo-zz_atwrt.
                          ls_e10307_table_others-zgrade_descr = ls_cawnt-atwtb.
                        CATCH cx_sy_itab_line_not_found.
                      ENDTRY.
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
              IF ls_ekpo-zz_atinn IS INITIAL AND
                 ls_ekpo-zz_atwrt IS INITIAL.
* Get the value from the FM.
                CALL FUNCTION 'VC_I_GET_CONFIGURATION'
                  EXPORTING
                    instance            = ls_ekpo-cuobj
                    language            = sy-langu
                  TABLES
                    configuration       = lt_config
                  EXCEPTIONS
                    instance_not_found  = 1
                    internal_error      = 2
                    no_class_allocation = 3
                    instance_not_valid  = 4
                    OTHERS              = 5.
                IF sy-subrc <> 0.
                  CLEAR lt_config.
                ENDIF.
                TRY .
                    ls_config = lt_config[ 1 ].
                    ls_e10307_table_others-zgrade = ls_config-atwrt.
                    ls_e10307_table_others-zgrade_descr = ls_config-atwtb.
                  CATCH cx_sy_itab_line_not_found.
                ENDTRY.
              ENDIF.
              CLEAR: ls_ekpo,
                     ls_cawn,
                     ls_cawnt.
* Check Material validation and get material text.
              TRY.
                  ls_matnr = lt_matnr[ matnr = ls_zmscale_validate-matnr ].
                  ls_e10307_table_others-zmatnr = ls_matnr-matnr.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
** Get material text.
              TRY .
                  ls_maktx = lt_maktx[ matnr = ls_matnr-matnr
                                             spras = sy-langu ].
                  ls_e10307_table_others-zmaktx = ls_maktx-maktx.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
*** End modification by PWADEHR on 7/27/2018 CMS# 33265
**********************************************************************
              APPEND ls_e10307_table_others TO it_e10307_table_delete.
              CLEAR ls_e10307_table_others.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.


  IF it_e10307_table[] IS NOT INITIAL.
    INSERT zmm_e10307_table FROM TABLE it_e10307_table.
***Begin of insertion by PWADEHR on 10/17/2018 CMS 34209
* deleting the original data record
    DELETE FROM zmm_e10307_table
      WHERE zscale_ticket = ls_zmscale_ticket-zscale_ticket
            AND zreaction = 'CDR'.
***End of insertion by PWADEHR on 10/17/2018 CMS 34209
    REFRESH it_e10307_table[]. "CMS# 33265
  ENDIF.
*** Begin of insertion by PWADEHR on 7/27/2018 CMS# 33265
  IF it_e10307_table_delete[] IS NOT INITIAL.
    UPDATE zmm_e10307_table FROM TABLE it_e10307_table_delete.
    REFRESH it_e10307_table_delete[].
  ENDIF.

  COMMIT WORK.
*** End of insertion by PWADEHR on 7/27/2018 CMS# 33265

ENDMETHOD.


METHOD process_exit.
*----------------------------------------------------------------------*
* Change History:                                                      *
*   Programmer     Date     Req. #                Action               *
* ============= ========   ======   ================================== *
* ALANKAP        9/23/2015 E0VK9A0EBH CMS 28897: If a ticket correction*
* occurs after a light Weight, Quality and/or Moisture sub credit      *
* deduction is entered in the table, the program keeps the original    *
* material document number. Therefore, the sub credits will not process*
* because there will never be an invoice against the original material *
* document. The record needs to be manually deleted and processed      *
* manually through the upload feature of this program.                 *
* If a ticket correction is made against a scale ticket that is in the *
* table the program needs to:                                          *
* 1. Update the record with the new material document number           *
* 2. Keep the original GR date                                         *
* 3. Keep the original deduct amount                                   *
*______________________________________________________________________*

  DATA : ls_input_table          TYPE zmm_e10310_input,
         ls_e10307_table_tmp     TYPE zmm_e10310_input,
         it_e10307_table         TYPE STANDARD TABLE OF zmm_e10307_table,
         wa_e10307_table_tmp     TYPE zmm_e10307_table,
         it_e10307_table_r       TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_subcred TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_others  TYPE STANDARD TABLE OF zmm_e10307_table,
         it_e10307_table_delete  TYPE STANDARD TABLE OF zmm_e10307_table,
         ls_e10307_table_others  TYPE zmm_e10307_table,
         it_zmscale_ticket       TYPE STANDARD TABLE OF zmscale_ticket,
         it_zmscale_ticket_r     TYPE STANDARD TABLE OF zmscale_ticket,
         ls_zmscale_ticket       TYPE zmscale_ticket,
         ls_e10307_table         TYPE zmm_e10307_table,
         ls_return               TYPE bapiret2,
*         lt_zstatus2             TYPE STANDARD TABLE OF dd07v,
*         ls_zstatus2             TYPE dd07v,
         lt_config               TYPE ztt_conf_out,
         lv_remainder            TYPE int4,
         gc_101                  TYPE bwart VALUE '101',
         gc_102                  TYPE bwart VALUE '102'.

  CONSTANTS: lc_key1 TYPE char6 VALUE 'E10307',
             lc_key2 TYPE char3 VALUE 'RFQ',
             lc_key3 TYPE char3 VALUE 'UPL',
             lc_key4 TYPE char6 VALUE 'STATUS'.


**********************************************************************
*** Start modification by JWILL68 on 5/31/2018 CMS# 33255
*  REFRESH lt_zstatus2[].
**---Get the domain default values ZSTATUS2
*  CALL FUNCTION 'DD_DOMA_GET'
*    EXPORTING
*      domain_name = 'ZSTATUS2'
*      langu       = sy-langu
*      withtext    = 'X'
*    TABLES
*      dd07v_tab_a = lt_zstatus2
*      dd07v_tab_n = lt_zstatus2
*    EXCEPTIONS
*      OTHERS      = 0.
*  IF lt_zstatus2[] IS NOT INITIAL.
*    SORT lt_zstatus2.
*    DELETE lt_zstatus2 WHERE ddlanguage EQ space.
*  ENDIF.

* The domain values for the fields Status is moved to table
* ZMMFLD, the values should be retrived from the table instead of
* retriving from the domain value.
  SELECT *
    FROM zmmfld
    INTO TABLE @DATA(lt_status)
    WHERE key1 = @lc_key1 AND
          key2 = @lc_key2 AND
          key3 = @lc_key3 AND
          key4 = @lc_key4 .
  IF sy-subrc <> 0.
    CLEAR lt_status.
  ENDIF.

* For filling newly added fields.
  IF cl_input_table IS NOT INITIAL.
* Retrive the record from Zmscale_ticket table for Grade and
* Grade Description.
    SELECT zscale_ticket,
           tknum,
           ebeln,
           ebelp,
           matnr
      FROM zmscale_ticket
      INTO TABLE @DATA(lt_zmscale_validate)
      FOR ALL ENTRIES IN @cl_input_table
      WHERE zscale_ticket = @cl_input_table-zscale_ticket.
    IF sy-subrc = 0.
* Retrive the record from EKPO table for Grade and
* Grade Description.
      SELECT ebeln,
             ebelp,
             zz_atinn,
             zz_atwrt,
             cuobj
        FROM ekpo
        INTO TABLE @DATA(lt_ekpo)
        FOR ALL ENTRIES IN @lt_zmscale_validate
        WHERE ebeln = @lt_zmscale_validate-ebeln AND
              ebelp = @lt_zmscale_validate-ebelp.
      IF sy-subrc = 0.
* Retrive the record from CAWN table for Grade and
* Grade Description.
        SELECT atinn,
               atzhl,
               atwrt
          FROM cawn
          INTO TABLE @DATA(lt_cawn)
          FOR ALL ENTRIES IN @lt_ekpo
          WHERE atinn = @lt_ekpo-zz_atinn AND
                atwrt = @lt_ekpo-zz_atwrt.
        IF sy-subrc = 0.
* Retrive the record from CAWNT table for Grade and
* Grade Description.
          SELECT atinn,
                 atzhl,
                 spras,
                 atwtb
            FROM cawnt
            INTO TABLE @DATA(lt_cawnt)
            FOR ALL ENTRIES IN @lt_cawn
            WHERE atinn = @lt_cawn-atinn AND
                  atzhl = @lt_cawn-atzhl AND
                  spras = @sy-langu.
          IF sy-subrc <> 0.
            CLEAR lt_cawnt.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

* Use conversion exit for Material field.
    LOOP AT lt_zmscale_validate ASSIGNING FIELD-SYMBOL(<ls_matnr>).
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = <ls_matnr>-matnr
        IMPORTING
          output = <ls_matnr>-matnr.
    ENDLOOP.
    UNASSIGN <ls_matnr>.
* Check Material validation and get material text.
    IF lt_zmscale_validate IS NOT INITIAL.
      SELECT  matnr
        FROM mara
        INTO TABLE @DATA(lt_matnr)
        FOR ALL ENTRIES IN @lt_zmscale_validate
        WHERE matnr = @lt_zmscale_validate-matnr.
      IF sy-subrc = 0.
* Get material text.
        SELECT matnr,
               spras,
               maktx
          FROM makt
          INTO TABLE @DATA(lt_maktx)
          FOR ALL ENTRIES IN @lt_matnr
          WHERE matnr = @lt_matnr-matnr AND
                spras = @sy-langu.
        IF sy-subrc <> 0.
          CLEAR lt_maktx.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
*** End modification by JWILL68 on 5/31/2018 CMS# 33255
**********************************************************************

  LOOP AT cl_input_table INTO ls_input_table.
    CLEAR ls_e10307_table.

* LWD should apply for only initial Goods receipt
*--*--101 Goods Movement Type Processing
*    IF ls_input_table-mov_type = gc_101.
    IF ls_input_table-mov_type = gc_101 AND
       ( ls_input_table-zrev_no EQ '00' OR " CMS 28556
         ls_input_table-zrev_no IS INITIAL ) AND " CMS 28556
        sy-tcode <> 'VL09'. "CMS 33255
      IF ls_input_table-ekpo_zz_lwd = 'X'.   "LWD Flag
        IF ls_input_table-mseg_menge LT ls_input_table-ekpo_zz_threshold.
          IF ls_input_table-ekpo_zz_deduction IS NOT INITIAL.

            ls_e10307_table-zmblnr         = ls_input_table-mat_doc.
            ls_e10307_table-zmblpo         = ls_input_table-mat_doc_item.
            ls_e10307_table-zmjahr         = ls_input_table-doc_year.
            ls_e10307_table-zmenge         = ls_input_table-mseg_menge.
            ls_e10307_table-zmeins         = ls_input_table-mseg_meins.
            ls_e10307_table-zscale_ticket  = ls_input_table-zscale_ticket.
            ls_e10307_table-zrev_no        = ls_input_table-zrev_no.
            ls_e10307_table-zaction        = ls_input_table-zaction.
            ls_e10307_table-zbwart         = ls_input_table-mov_type.
            ls_e10307_table-zebeln         = ls_input_table-po_number.
            ls_e10307_table-zebelp         = ls_input_table-po_item.
            ls_e10307_table-zwerks         = ls_input_table-po_werks.
            ls_e10307_table-zschpr         = ls_input_table-ekpo_schpr.
            ls_e10307_table-zlwd_stat      = ls_input_table-ekpo_zz_lwd.
            ls_e10307_table-zlwd_thr       = ls_input_table-ekpo_zz_threshold.
            ls_e10307_table-zlwd_unit      = ls_input_table-zlwd_unit.
            ls_e10307_table-zlwd_rate      = ls_input_table-ekpo_zz_deduction.
            ls_e10307_table-zekorg         = ls_input_table-zekorg.
            ls_e10307_table-zlifnr         = ls_input_table-zlifnr.
            ls_e10307_table-zvendor_name   = ls_input_table-zvendor_name.
            ls_e10307_table-zllief         = ls_input_table-zllief.
            ls_e10307_table-zsupplier_name = ls_input_table-zsupplier_name.
*update the ZADJ_RATE with the same value as the ZLWD_RATE when it is populated.
*This will provide AP with the rate to be used for the subsequent adjustment from a single field. ZDJ_RATE.
*           ls_e10307_table-zadj_rate     = ls_input_table-ekpo_zz_deduction.

            ls_e10307_table-zadj_rate = ( ls_e10307_table-zlwd_thr - ls_e10307_table-zmenge ) * ls_e10307_table-zlwd_rate.


            ls_e10307_table-zadj_type     = 'C'.
            ls_e10307_table-zadj_reason   = TEXT-t01.
            ls_e10307_table-zcr_name      = sy-uname.
            ls_e10307_table-zcr_date      = sy-datum.
            ls_e10307_table-zcr_time      = sy-uzeit.
            ls_e10307_table-zcr_call_id   = cl_calling_prg.


            IF ls_input_table-ekpo_schpr EQ 'X'.  "Put the request on Hold  "Indicator: Estimated Price
              ls_e10307_table-zstatus  = 'GR101-XEP'.
            ELSEIF ls_input_table-ekpo_schpr EQ ''.  "space "Indicator: Estimated Price
              ls_e10307_table-zstatus = 'GR101'.
            ENDIF.

*---Status Description from the Domain Values
*            CLEAR ls_zstatus2.
            IF ls_e10307_table-zstatus IS NOT INITIAL.
**********************************************************************
*** Start modification by JWILL68 on 5/31/2018 CMS# 33255
*              READ TABLE lt_zstatus2 INTO ls_zstatus2 WITH KEY
*                          domvalue_l = ls_e10307_table-zstatus
*                          ddlanguage = 'E'.
*              IF sy-subrc EQ 0.
*                ls_e10307_table-zstatus_descr = ls_zstatus2-ddtext.
*              ENDIF.
              TRY.
                  DATA(ls_status) = lt_status[ value1 = ls_e10307_table-zstatus ].
                  ls_e10307_table-zstatus_descr = ls_status-value7.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
* Grade code and description determination.
              TRY.
                  DATA(ls_zmscale_validate) = lt_zmscale_validate[ zscale_ticket = ls_input_table-zscale_ticket ].
                  ls_e10307_table-ztknum = ls_zmscale_validate-tknum.
                CATCH cx_sy_itab_line_not_found.
                  CLEAR ls_zmscale_validate.
              ENDTRY.

* Read EKPO, CAWN, CAWNT table to get the Grade value and
* Grade value description.
              TRY.
                  DATA(ls_ekpo) = lt_ekpo[ ebeln = ls_zmscale_validate-ebeln
                                           ebelp = ls_zmscale_validate-ebelp ].
                  TRY.
                      DATA(ls_cawn) = lt_cawn[ atinn = ls_ekpo-zz_atinn
                                               atwrt = ls_ekpo-zz_atwrt ].
                      TRY.
                          DATA(ls_cawnt) = lt_cawnt[ atinn = ls_cawn-atinn
                                                     atzhl = ls_cawn-atzhl
                                                     spras = sy-langu ].
                          ls_e10307_table-zgrade       = ls_ekpo-zz_atwrt.
                          ls_e10307_table-zgrade_descr = ls_cawnt-atwtb.
                        CATCH cx_sy_itab_line_not_found.
                      ENDTRY.
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
              IF ls_ekpo-zz_atinn IS INITIAL AND
                 ls_ekpo-zz_atwrt IS INITIAL.
* Get the value from the FM.
                CALL FUNCTION 'VC_I_GET_CONFIGURATION'
                  EXPORTING
                    instance            = ls_ekpo-cuobj
                    language            = sy-langu
                  TABLES
                    configuration       = lt_config
                  EXCEPTIONS
                    instance_not_found  = 1
                    internal_error      = 2
                    no_class_allocation = 3
                    instance_not_valid  = 4
                    OTHERS              = 5.
                IF sy-subrc <> 0.
                  CLEAR lt_config.
                ENDIF.
                TRY .
                    DATA(ls_config) = lt_config[ 1 ].
                    ls_e10307_table-zgrade = ls_config-atwrt.
                    ls_e10307_table-zgrade_descr = ls_config-atwtb.
                  CATCH cx_sy_itab_line_not_found.
                ENDTRY.
              ENDIF.
              CLEAR: ls_ekpo,
                     ls_cawn,
                     ls_cawnt.
* Check Material validation and get material text.
              TRY.
                  DATA(ls_matnr) = lt_matnr[ matnr = ls_zmscale_validate-matnr ].
                  ls_e10307_table-zmatnr = ls_matnr-matnr.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
** Get material text.
              TRY .
                  DATA(ls_maktx) = lt_maktx[ matnr = ls_matnr-matnr
                                             spras = sy-langu ].
                  ls_e10307_table-zmaktx = ls_maktx-maktx.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
*** End modification by JWILL68 on 5/31/2018 CMS# 33255
**********************************************************************
            ENDIF.

            APPEND ls_e10307_table TO it_e10307_table.
            CLEAR  ls_e10307_table.
          ENDIF.
        ELSE.

        ENDIF.
      ELSE.   ""EKPO-ZZ_LWD FLAG IS BLANK

        ls_return-type        = 'E'.
        ls_return-id          = 'ZCL_E10310'.
        ls_return-number      = '007'.
        ls_return-message     = TEXT-006.
        ls_return-message_v1  = ls_input_table-mat_doc.
        ls_return-message_v2  = ls_input_table-mat_doc_item..
        APPEND ls_return    TO cl_return.
        CLEAR  ls_return.
      ENDIF.
*** Start of modification by ALANKAP on 8/24/2015 CMS 28897
    ELSEIF ls_input_table-mov_type = gc_101 AND
           ls_input_table-zrev_no GT '00'.
      SELECT SINGLE * FROM zmm_e10307_table INTO wa_e10307_table_tmp
               WHERE
               zscale_ticket       = ls_input_table-zscale_ticket

               AND ( zrev_no = '00' OR
                     zrev_no = space ).

      IF sy-subrc EQ 0.
* get the scale ticket data
        SELECT * INTO TABLE it_zmscale_ticket FROM zmscale_ticket
               WHERE zscale_ticket = ls_input_table-zscale_ticket.
        IF sy-subrc IS INITIAL.
          SORT it_zmscale_ticket DESCENDING BY zscale_ticket zrev_no.
          READ TABLE it_zmscale_ticket INTO ls_zmscale_ticket INDEX 1.
          lv_remainder = ls_zmscale_ticket-zrev_no MOD 2.
          IF lv_remainder  NE 0.
            ls_zmscale_ticket-zrev_no = ls_zmscale_ticket-zrev_no + 1.
          ENDIF.
        ENDIF.
*** Copy the '00' revision to a new record
        MOVE-CORRESPONDING wa_e10307_table_tmp TO ls_e10307_table.
        ls_e10307_table-zmblnr      = ls_input_table-mat_doc.
        ls_e10307_table-zrev_no     = ls_zmscale_ticket-zrev_no. " new rev number '02' or '04'?
        ls_e10307_table-zreaction   = space.
        ls_e10307_table-zstatus     = 'GR101'.
*** Start modification by JWILL68 on 5/31/2018 CMS# 33255
        CLEAR ls_status.
        TRY.
            ls_status = lt_status[ value1 = ls_e10307_table-zstatus ].
            ls_e10307_table-zstatus_descr = ls_status-value7.
          CATCH cx_sy_itab_line_not_found.
        ENDTRY.
*        SELECT SINGLE ddtext INTO ls_e10307_table-zstatus_descr
*               FROM dd07t
*               WHERE domname    = 'ZSTATUS2'
*               AND   ddlanguage = sy-langu
*               AND   domvalue_l = ls_e10307_table-zstatus.
*** End modification by JWILL68 on 5/31/2018 CMS# 33255

        ls_e10307_table-zch_date    = sy-datum.
        ls_e10307_table-zch_time    = sy-uzeit.
        ls_e10307_table-zernam      = sy-uname.
        ls_e10307_table-zch_call_id = sy-repid.
        ls_e10307_table-ztxt01      = ls_e10307_table-zadj_reason.
        ls_e10307_table-zadj_reason = 'Original receipt LWD applied'.
        APPEND ls_e10307_table TO it_e10307_table.
        CLEAR  ls_e10307_table.
      ENDIF.
*** End of modification by ALANKAP on 8/24/2015 CMS 28897
    ENDIF.

*--102 Goods Movement Type Processing
    IF ls_input_table-mov_type = gc_102 OR " CMS 28897
        sy-tcode = 'VL09'.
*      IF ls_input_table-mov_type = gc_102 AND " CMS 28897
*   ls_input_table-ekpo_zz_lwd NE 'X'. " CMS 28556 " CMS 28897 Comented
*--Get the Scale ticket details for the reversal movement and the
*--original GR
      REFRESH it_zmscale_ticket_r[].
      SELECT * FROM zmscale_ticket INTO TABLE it_zmscale_ticket_r
               WHERE zscale_ticket = ls_input_table-zscale_ticket
               AND   zgr_docno     = ls_input_table-mseg_lfbnr.
      IF sy-subrc EQ 0.
        SORT it_zmscale_ticket_r.
      ENDIF.

*--Get the Status of subsequent adjustments for the original GR document
      REFRESH:  it_e10307_table_r[],
                it_e10307_table_subcred[],
                it_e10307_table_others[].

      SELECT * FROM zmm_e10307_table INTO TABLE it_e10307_table_r
               WHERE zmblnr        = ls_input_table-mseg_lfbnr
               AND   zmblpo        = ls_input_table-mseg_lfpos.
*               AND   zscale_ticket = ls_input_table-mseg_lfbnr.
      IF sy-subrc EQ 0.
        SORT it_e10307_table_r.
        it_e10307_table_subcred[] = it_e10307_table_r[].
        it_e10307_table_others[]  = it_e10307_table_r[].

*--Keep only No SUBCRED records
        DELETE it_e10307_table_others WHERE zstatus EQ 'SUBCRED'.
*--Keep only SUBCRED records
        DELETE it_e10307_table_subcred WHERE zstatus NE 'SUBCRED'.

        IF it_e10307_table_subcred[] IS NOT INITIAL.

          ls_e10307_table-zmblnr         = ls_input_table-mat_doc.
          ls_e10307_table-zmblpo         = ls_input_table-mat_doc_item.
          ls_e10307_table-zmjahr         = ls_input_table-doc_year.
          ls_e10307_table-zmenge         = ls_input_table-mseg_menge.
          ls_e10307_table-zmeins         = ls_input_table-mseg_meins.
          ls_e10307_table-zscale_ticket  = ls_input_table-zscale_ticket.
*         ls_e10307_table-zrev_no        = ls_input_table-zrev_no.
          ls_e10307_table-zaction        = ls_input_table-zaction.
          ls_e10307_table-zreaction      = 'CDR'.
          ls_e10307_table-zbwart         = ls_input_table-mov_type.
          ls_e10307_table-zebeln         = ls_input_table-po_number.
          ls_e10307_table-zebelp         = ls_input_table-po_item.
          ls_e10307_table-zwerks         = ls_input_table-po_werks.
          ls_e10307_table-zschpr         = ls_input_table-ekpo_schpr.
          ls_e10307_table-zlwd_stat      = ls_input_table-ekpo_zz_lwd.
          ls_e10307_table-zlwd_thr       = ls_input_table-ekpo_zz_threshold.
          ls_e10307_table-zlwd_unit      = ls_input_table-zlwd_unit.
          ls_e10307_table-zlwd_rate      = ls_input_table-ekpo_zz_deduction.
          ls_e10307_table-zekorg         = ls_input_table-zekorg.
          ls_e10307_table-zlifnr         = ls_input_table-zlifnr.
          ls_e10307_table-zvendor_name   = ls_input_table-zvendor_name.
          ls_e10307_table-zllief         = ls_input_table-zllief.
          ls_e10307_table-zsupplier_name = ls_input_table-zsupplier_name.
*update the ZADJ_RATE with the same value as the ZLWD_RATE when it is populated.
*This will provide AP with the rate to be used for the subsequent adjustment from a single field. ZDJ_RATE.
*         ls_e10307_table-zadj_rate     = ls_input_table-ekpo_zz_deduction.
          ls_e10307_table-zadj_rate = ( ls_e10307_table-zlwd_thr - ls_e10307_table-zmenge ) * ls_e10307_table-zlwd_rate.
          ls_e10307_table-zadj_type      = 'D'.
          ls_e10307_table-zcr_name       = sy-uname.
          ls_e10307_table-zcr_date       = sy-datum.
          ls_e10307_table-zcr_time       = sy-uzeit.
          ls_e10307_table-zcr_call_id    = cl_calling_prg.
          ls_e10307_table-zstatus        = 'GR102'.

          IF ls_input_table-mseg_sgtxt  IS NOT INITIAL.
            ls_e10307_table-zadj_reason   = ls_input_table-mseg_sgtxt.
          ELSE.
            ls_e10307_table-zadj_reason   = TEXT-t02.
          ENDIF.

**********************************************************************
*** Start modification by JWILL68 on 5/31/2018 CMS# 33255
*---Status Description from the Domain Values
*          CLEAR ls_zstatus2.
*          IF ls_e10307_table-zstatus IS NOT INITIAL.
*            READ TABLE lt_zstatus2 INTO ls_zstatus2 WITH KEY
*                        domvalue_l = ls_e10307_table-zstatus
*                        ddlanguage = 'E'.
*            IF sy-subrc EQ 0.
*              ls_e10307_table-zstatus_descr = ls_zstatus2-ddtext.
*            ENDIF.
*          ENDIF.
          CLEAR ls_status.
          TRY.
              ls_status = lt_status[ value1 = ls_e10307_table-zstatus ].
              ls_e10307_table-zstatus_descr = ls_status-value7.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.

* Grade code and description determination.
          TRY.
              ls_zmscale_validate = lt_zmscale_validate[ zscale_ticket = ls_input_table-zscale_ticket ].
              ls_e10307_table-ztknum = ls_zmscale_validate-tknum.
            CATCH cx_sy_itab_line_not_found.
              CLEAR ls_zmscale_validate.
          ENDTRY.

* Read EKPO, CAWN, CAWNT table to get the Grade value and
* Grade value description.
          TRY.
              ls_ekpo = lt_ekpo[ ebeln = ls_zmscale_validate-ebeln
                                 ebelp = ls_zmscale_validate-ebelp ].
              TRY .
                  ls_cawn = lt_cawn[ atinn = ls_ekpo-zz_atinn
                                     atwrt = ls_ekpo-zz_atwrt ].
                  TRY .
                      ls_cawnt = lt_cawnt[ atinn = ls_cawn-atinn
                                           atzhl = ls_cawn-atzhl
                                           spras = sy-langu ].
                      ls_e10307_table-zgrade       = ls_ekpo-zz_atwrt.
                      ls_e10307_table-zgrade_descr = ls_cawnt-atwtb.
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
          IF ls_ekpo-zz_atinn IS INITIAL AND
             ls_ekpo-zz_atwrt IS INITIAL.
* Get the value from the FM.
            CALL FUNCTION 'VC_I_GET_CONFIGURATION'
              EXPORTING
                instance            = ls_ekpo-cuobj
                language            = sy-langu
              TABLES
                configuration       = lt_config
              EXCEPTIONS
                instance_not_found  = 1
                internal_error      = 2
                no_class_allocation = 3
                instance_not_valid  = 4
                OTHERS              = 5.
            IF sy-subrc <> 0.
              CLEAR lt_config.
            ENDIF.
            TRY .
                ls_config = lt_config[ 1 ].
                ls_e10307_table-zgrade       = ls_config-atwrt.
                ls_e10307_table-zgrade_descr = ls_config-atwtb.
              CATCH cx_sy_itab_line_not_found.
            ENDTRY.
          ENDIF.
          CLEAR: ls_ekpo,
                 ls_cawn,
                 ls_cawnt.
* Check Material validation and get material text.
          TRY.
              ls_matnr = lt_matnr[ matnr = ls_zmscale_validate-matnr ].
              ls_e10307_table-zmatnr = ls_matnr-matnr.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.
** Get material text.
          TRY .
              ls_maktx = lt_maktx[ matnr = ls_matnr-matnr
                                   spras = sy-langu ].
              ls_e10307_table-zmaktx = ls_maktx-maktx.
            CATCH cx_sy_itab_line_not_found.
          ENDTRY.

*** End modification by JWILL68 on 5/31/2018 CMS# 33255
**********************************************************************
          APPEND ls_e10307_table TO it_e10307_table.
          CLEAR  ls_e10307_table.

        ENDIF.

*--Zstatus is NOT SUBCRED - Delete all pending Requests
*        REFRESH it_e10307_table_delete[].
        IF it_e10307_table_others[] IS NOT INITIAL.
          LOOP AT it_e10307_table_others INTO ls_e10307_table_others.
            IF ls_e10307_table_others-zstatus+0(5) = 'GR101'.
              ls_e10307_table_others-zstatus       = 'DELETE'.
              ls_e10307_table_others-zch_date      = sy-datum.
              ls_e10307_table_others-zch_time      = sy-uzeit.
              ls_e10307_table_others-zch_call_id   = cl_calling_prg.
              ls_e10307_table_others-zernam        = sy-uname.

*---Status Description from the Domain Values
**********************************************************************
*** Start modification by JWILL68 on 5/31/2018 CMS# 33255
*              CLEAR ls_zstatus2.
*              IF ls_e10307_table_others-zstatus IS NOT INITIAL.
*                READ TABLE lt_zstatus2 INTO ls_zstatus2 WITH KEY
*                            domvalue_l = ls_e10307_table_others-zstatus
*                            ddlanguage = 'E'.
*                IF sy-subrc EQ 0.
*                  ls_e10307_table_others-zstatus_descr = ls_zstatus2-ddtext.
*                ENDIF.
*              ENDIF.
              CLEAR ls_status.
              TRY.
                  ls_status = lt_status[ value1 = ls_e10307_table_others-zstatus ].
                  ls_e10307_table_others-zstatus_descr = ls_status-value7.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.

* Grade code and description determination.
              TRY.
                  ls_zmscale_validate = lt_zmscale_validate[ zscale_ticket = ls_input_table-zscale_ticket ].
                  ls_e10307_table_others-ztknum = ls_zmscale_validate-tknum.
                CATCH cx_sy_itab_line_not_found.
                  CLEAR ls_zmscale_validate.
              ENDTRY.

* Read EKPO, CAWN, CAWNT table to get the Grade value and
* Grade value description.
              TRY.
                  ls_ekpo = lt_ekpo[ ebeln = ls_zmscale_validate-ebeln
                                           ebelp = ls_zmscale_validate-ebelp ].
                  TRY.
                      ls_cawn = lt_cawn[ atinn = ls_ekpo-zz_atinn
                                               atwrt = ls_ekpo-zz_atwrt ].
                      TRY.
                          ls_cawnt = lt_cawnt[ atinn = ls_cawn-atinn
                                                     atzhl = ls_cawn-atzhl
                                                     spras = sy-langu ].
                          ls_e10307_table_others-zgrade       = ls_ekpo-zz_atwrt.
                          ls_e10307_table_others-zgrade_descr = ls_cawnt-atwtb.
                        CATCH cx_sy_itab_line_not_found.
                      ENDTRY.
                    CATCH cx_sy_itab_line_not_found.
                  ENDTRY.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
              IF ls_ekpo-zz_atinn IS INITIAL AND
                 ls_ekpo-zz_atwrt IS INITIAL.
* Get the value from the FM.
                CALL FUNCTION 'VC_I_GET_CONFIGURATION'
                  EXPORTING
                    instance            = ls_ekpo-cuobj
                    language            = sy-langu
                  TABLES
                    configuration       = lt_config
                  EXCEPTIONS
                    instance_not_found  = 1
                    internal_error      = 2
                    no_class_allocation = 3
                    instance_not_valid  = 4
                    OTHERS              = 5.
                IF sy-subrc <> 0.
                  CLEAR lt_config.
                ENDIF.
                TRY .
                    ls_config = lt_config[ 1 ].
                    ls_e10307_table_others-zgrade = ls_config-atwrt.
                    ls_e10307_table_others-zgrade_descr = ls_config-atwtb.
                  CATCH cx_sy_itab_line_not_found.
                ENDTRY.
              ENDIF.
              CLEAR: ls_ekpo,
                     ls_cawn,
                     ls_cawnt.
* Check Material validation and get material text.
              TRY.
                  ls_matnr = lt_matnr[ matnr = ls_zmscale_validate-matnr ].
                  ls_e10307_table_others-zmatnr = ls_matnr-matnr.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
** Get material text.
              TRY .
                  ls_maktx = lt_maktx[ matnr = ls_matnr-matnr
                                             spras = sy-langu ].
                  ls_e10307_table_others-zmaktx = ls_maktx-maktx.
                CATCH cx_sy_itab_line_not_found.
              ENDTRY.
*** End modification by JWILL68 on 5/31/2018 CMS# 33255
**********************************************************************
              APPEND ls_e10307_table_others TO it_e10307_table_delete.
              CLEAR ls_e10307_table_others.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.


*--TABLE UPDATES zmm_e10307_table

  IF it_e10307_table[] IS NOT INITIAL.
    INSERT zmm_e10307_table FROM TABLE it_e10307_table.
    REFRESH it_e10307_table[].
  ENDIF.

  IF it_e10307_table_delete[] IS NOT INITIAL.
    UPDATE zmm_e10307_table FROM TABLE it_e10307_table_delete.
    REFRESH it_e10307_table_delete[].
  ENDIF.

  COMMIT WORK.

ENDMETHOD.
ENDCLASS.

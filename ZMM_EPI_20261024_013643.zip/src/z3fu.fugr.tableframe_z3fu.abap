*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_Z3FU
*   generation date: 2003.05.12 at 15:02:04 by user CWILKIN
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_Z3FU               .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.

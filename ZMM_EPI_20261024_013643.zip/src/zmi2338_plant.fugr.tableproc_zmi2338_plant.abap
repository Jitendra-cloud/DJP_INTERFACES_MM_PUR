*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMI2338_PLANT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMI2338_PLANT       .

  PERFORM TABLEPROC.

ENDFUNCTION.

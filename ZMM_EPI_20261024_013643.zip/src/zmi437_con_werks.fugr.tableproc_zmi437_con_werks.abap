*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMI437_CON_WERKS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMI437_CON_WERKS    .

  PERFORM TABLEPROC.

ENDFUNCTION.

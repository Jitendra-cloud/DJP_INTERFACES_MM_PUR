*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME1251_STOCKOUT................................*
DATA:  BEGIN OF STATUS_ZME1251_STOCKOUT              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME1251_STOCKOUT              .
CONTROLS: TCTRL_ZME1251_STOCKOUT
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZME1251_STOCKOUT              .
TABLES: ZME1251_STOCKOUT               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

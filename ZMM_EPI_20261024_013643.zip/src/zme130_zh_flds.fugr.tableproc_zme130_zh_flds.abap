*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZME130_ZH_FLDS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZME130_ZH_FLDS      .

  PERFORM TABLEPROC.

ENDFUNCTION.

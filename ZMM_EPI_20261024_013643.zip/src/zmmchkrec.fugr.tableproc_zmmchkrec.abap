*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMMCHKREC
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMMCHKREC           .

  PERFORM TABLEPROC.

ENDFUNCTION.

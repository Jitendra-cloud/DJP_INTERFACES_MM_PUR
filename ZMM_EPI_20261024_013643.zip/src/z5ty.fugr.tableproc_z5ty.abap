*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5TY
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5TY                .

  PERFORM TABLEPROC.

ENDFUNCTION.

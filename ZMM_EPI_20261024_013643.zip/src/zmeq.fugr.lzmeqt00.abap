*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_EQUIPT_WUM..................................*
DATA:  BEGIN OF STATUS_ZMM_EQUIPT_WUM                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_EQUIPT_WUM                .
CONTROLS: TCTRL_ZMM_EQUIPT_WUM
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZMM_EQUIP_WUM...................................*
DATA:  BEGIN OF STATUS_ZMM_EQUIP_WUM                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_EQUIP_WUM                 .
CONTROLS: TCTRL_ZMM_EQUIP_WUM
            TYPE TABLEVIEW USING SCREEN '0002'.
*...processing: ZMM_SECTORT_WUM.................................*
DATA:  BEGIN OF STATUS_ZMM_SECTORT_WUM               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_SECTORT_WUM               .
CONTROLS: TCTRL_ZMM_SECTORT_WUM
            TYPE TABLEVIEW USING SCREEN '0003'.
*...processing: ZMM_SECTOR_WUM..................................*
DATA:  BEGIN OF STATUS_ZMM_SECTOR_WUM                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_SECTOR_WUM                .
CONTROLS: TCTRL_ZMM_SECTOR_WUM
            TYPE TABLEVIEW USING SCREEN '0004'.
*.........table declarations:.................................*
TABLES: *ZMM_EQUIPT_WUM                .
TABLES: *ZMM_EQUIP_WUM                 .
TABLES: *ZMM_SECTORT_WUM               .
TABLES: *ZMM_SECTOR_WUM                .
TABLES: ZMM_EQUIPT_WUM                 .
TABLES: ZMM_EQUIP_WUM                  .
TABLES: ZMM_SECTORT_WUM                .
TABLES: ZMM_SECTOR_WUM                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

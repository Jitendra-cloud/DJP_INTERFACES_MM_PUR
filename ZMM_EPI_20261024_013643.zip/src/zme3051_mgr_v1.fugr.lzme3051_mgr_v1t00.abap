*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME3051_MGR_V1..................................*
TABLES: ZME3051_MGR_V1, *ZME3051_MGR_V1. "view work areas
CONTROLS: TCTRL_ZME3051_MGR_V1
TYPE TABLEVIEW USING SCREEN '0001'.
DATA: BEGIN OF STATUS_ZME3051_MGR_V1. "state vector
          INCLUDE STRUCTURE VIMSTATUS.
DATA: END OF STATUS_ZME3051_MGR_V1.
* Table for entries selected to show on screen
DATA: BEGIN OF ZME3051_MGR_V1_EXTRACT OCCURS 0010.
INCLUDE STRUCTURE ZME3051_MGR_V1.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZME3051_MGR_V1_EXTRACT.
* Table for all entries loaded from database
DATA: BEGIN OF ZME3051_MGR_V1_TOTAL OCCURS 0010.
INCLUDE STRUCTURE ZME3051_MGR_V1.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZME3051_MGR_V1_TOTAL.

*.........table declarations:.................................*
TABLES: ZME3051_MGR_CREF               .

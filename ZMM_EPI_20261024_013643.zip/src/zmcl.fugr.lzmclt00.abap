*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMXCL...........................................*
DATA:  BEGIN OF STATUS_ZMXCL                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMXCL                         .
CONTROLS: TCTRL_ZMXCL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMXCL                         .
TABLES: ZMXCL                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z5MV
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z5MV                .

  PERFORM TABLEPROC.

ENDFUNCTION.

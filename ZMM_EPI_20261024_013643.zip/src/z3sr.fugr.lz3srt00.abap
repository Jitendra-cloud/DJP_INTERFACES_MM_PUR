*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMLSR...........................................*
DATA:  BEGIN OF STATUS_ZMLSR                         .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMLSR                         .
CONTROLS: TCTRL_ZMLSR
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMLSR                         .
TABLES: ZMLSR                          .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

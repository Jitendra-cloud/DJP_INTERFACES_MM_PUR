*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME03735........................................*
DATA:  BEGIN OF STATUS_ZME03735                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME03735                      .
CONTROLS: TCTRL_ZME03735
            TYPE TABLEVIEW USING SCREEN '0100'.
*.........table declarations:.................................*
TABLES: *ZME03735                      .
TABLES: ZME03735                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

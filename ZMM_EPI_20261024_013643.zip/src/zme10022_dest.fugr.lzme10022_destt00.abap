*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZME10022_DEST...................................*
DATA:  BEGIN OF STATUS_ZME10022_DEST                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZME10022_DEST                 .
CONTROLS: TCTRL_ZME10022_DEST
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZME10022_DEST                 .
TABLES: ZME10022_DEST                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

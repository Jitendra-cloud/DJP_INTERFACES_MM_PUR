*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMI437_CON_MATKL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMI437_CON_MATKL    .

  PERFORM TABLEPROC.

ENDFUNCTION.

*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 2003.05.12 at 15:02:06 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMM_FLWUP_STKNUM................................*
DATA:  BEGIN OF STATUS_ZMM_FLWUP_STKNUM              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_FLWUP_STKNUM              .
CONTROLS: TCTRL_ZMM_FLWUP_STKNUM
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_FLWUP_STKNUM              .
TABLES: ZMM_FLWUP_STKNUM               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

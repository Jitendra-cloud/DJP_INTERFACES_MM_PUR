*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 2002.08.29 at 14:05:24 by user CWILKIN
*---------------------------------------------------------------------*
*...processing: ZMATGVALC.......................................*
DATA:  BEGIN OF STATUS_ZMATGVALC                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMATGVALC                     .
CONTROLS: TCTRL_ZMATGVALC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMATGVALC                     .
TABLES: ZMATGVALC                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

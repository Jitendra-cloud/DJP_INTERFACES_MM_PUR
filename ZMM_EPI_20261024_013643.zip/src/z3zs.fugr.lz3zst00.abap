*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMM_MATNR_REVIEW................................*
DATA:  BEGIN OF STATUS_ZMM_MATNR_REVIEW              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMM_MATNR_REVIEW              .
CONTROLS: TCTRL_ZMM_MATNR_REVIEW
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMM_MATNR_REVIEW              .
TABLES: ZMM_MATNR_REVIEW               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .

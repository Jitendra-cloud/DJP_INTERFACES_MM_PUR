*---------------------------------------------------------------------*
*    program for:   TABLEPROC_Z4UM
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_Z4UM                .

  PERFORM TABLEPROC.

ENDFUNCTION.
